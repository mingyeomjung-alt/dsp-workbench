# 선택형 악기 및 타악기 정합 후보 사용 안내

0.1.2의 v4는 v3에서 이미 분석한 결과를 유지하고, 앵커 부족·불안정·복합 정합 보류에 한정해 원시 파형 대응을 추가 검증하는 **선택형 연구 후보**다. 기본값은 v1이다. 독립 자연 음원 성능이나 상용 성능을 검증한 엔진으로 취급하지 않는다.

## 실행

```python
from audio_regression.api import analyze_pair_with_trace

result, trace = analyze_pair_with_trace(
    "reference.wav", "processed.wav", engine="v4",
    allow_gain=True, allow_resampling=True,
)
```

입력은 기존과 같은 PCM16 모노 WAV, 파일당 2~30초·최대 10MB, 8·16·44.1·48kHz다. 실제로 허용한 변환만 선언한다. 원본·처리본·생성 결과를 덮어쓰지 않는다.

```powershell
audio-regression analyze --engine v4 --reference reference.wav --processed processed.wav --declare-gain --declare-resampling --output result.json
audio-regression check --input result.json
audio-regression report --input result.json --output review.html
audio-pipeline-check audit --engine v4 --manifest stages.json --output-dir new-audit
```

내장 `audio-pipeline-check run`에도 `--engine v4`를 쓸 수 있다. 저장 단계 감사의 입력 형식은 [SAVED_PIPELINE.md](SAVED_PIPELINE.md)를 따른다. 기존 보류·오류·후보 검토 상태를 나중의 정상 단계로 지우지 않는다.

## 추가 증명과 보류

원본의 고정 80ms 격자에서 240·480·960ms 창을 순서대로 확인한다. 처리본 전체에서 실제 경쟁 대응을 비교하고 상관 .90 이상·경쟁 차이 .03 이상을 요구한다. 창 전체의 국소 잔차도 검사해 편집을 가로지르는 부분 일치를 앵커로 쓰지 않는다. 동일 음색이라도 시간적 변화가 충분해야 위치를 구분할 수 있다.

검증된 앵커는 단조로운 오프셋 구간으로 구성한다. 그룹 전체 오프셋 편차는 3ms 이내이며 최종 대표 오프셋에서 모든 창을 다시 증명한다. 새 raw 경로는 하나의 내부 200~2000ms 삭제 또는 인접 추가 복사까지 다룬다. 두 번 이상의 전이, 파일 경계 변경, 미선언 변환, 전체 대응의 잔차·상관 실패는 보류한다. 기존 v3 성공을 보존한 경로의 사건 범위는 그대로다.

중복은 양쪽 복사 **전체**를 원본 전체에서 따로 찾아 동일한 원본 위치와 고유성을 증명한다. 가운데만 맞는 복사나 다른 곳에도 같은 구간이 있는 경우는 통과시키지 않는다. 정규 표현은 나중 인접 복사본이며 실제 편집 내력을 확정하지 않는다. 추가 복사도 최종 전역 이득에서 재검사한다.

삭제 위치가 여러 곳에서 같은 전체 파형 대응을 만들면 명시적으로 모호성 보류한다. 경계 후보 증명은 최대 128개이며 예산을 넘겨 결론을 내리지 못하면 보류한다. 순음·완전히 같은 주기 타격은 고유 대응이 없어 보류한다. `events=null`과 빈 후보 목록을 혼동하지 않는다. 전체 음질 승인과 상용 검증 표시는 계속 false다.

## 결과와 추적 기록 해석

분석 결과는 `local_content_alignment_v4`, 방법 식별자는 `raw_landmark_piecewise_alignment_with_global_uniqueness`다. 식별자는 후보 전체를 표시하며 모든 성공이 새 raw 증명 경로였다는 의미가 아니다.

`trace.proof_path`가 `preserved_v3_result`면 기존 v3 결과를 보존한 것이다. `raw_landmark_fallback`이면 추가 대응 검증을 시도했다. `fallback_attempted`, 기준선의 상태·보류 사유, 채택 앵커 수와 오프셋 그룹을 함께 읽는다. 보고서는 추적 파일을 자동으로 읽거나 출처를 인증하지 않는다.

`analysis.hop_ms=10`은 기존 기반 분석 격자 표기이며 raw 앵커 선택 격자는 추적의 `grid_ms=80`이다. raw fallback의 `normalized_path_cost`는 전체 retained match의 정규화 잔차다. 기존 v3 보존 경로의 동적 정합 비용과 같은 척도로 비교하거나 확률로 해석하지 않는다.

## 개발 확인 범위

시간 변화가 있는 합성 악기와 고유 타격의 고정 19조건에서 기대 행동은 v3 10/19→v4 19/19로 개선됐다. 정상 2/8→8/8, 삭제·복사 1/4→4/4이며 위험·모호 사례 보류는 7/7로 유지했다. 이 신호는 구현과 수정에 사용한 개발 자료다. 독립 자연음 정확도가 아니다.

기존 봉인 평가의 악기·타악기 0/12 결과와 기본 승격 기각 결정은 그대로 보존한다. 수정 결과로 그 점수를 바꿔 쓰지 않는다. 초기 개발 실패 16/19·18/19도 기록하며 기준값이나 신호를 결과에 맞춰 변경하지 않았다.
