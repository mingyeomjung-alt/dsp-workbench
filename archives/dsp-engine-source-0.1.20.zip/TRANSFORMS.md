# 선언된 DSP 변환 모델 검사

원본에 선언한 고정 변환을 적용해 기대 WAV를 만들고 실제 처리본과 비교한다. 기존 시간 분석·내장 단계 실행·저장 단계 검사는 그대로 유지하며, 별도 라이브러리와 `audio-transform-check`로 선택한다. 기본 분석 엔진은 v1이다.

## 모델과 계산 규칙

| 모델 kind | 계산 | 경계 규칙 |
| --- | --- | --- |
| `polarity_invert` | PCM 정수 부호 반전 | -32768 반전은 +32768이므로 거부 |
| `fir_binomial_3` | y[n] = x[n]/4 + x[n-1]/2 + x[n-2]/4 | 인과적 영 초기 상태, 입력 길이만 출력, 꼬리 추가 없음 |
| `pcm_quantize_12` | 16 × round(x/16) | 중간값은 짝수 쪽으로 반올림, +32768 출력 거부 |

각 모델 뒤에서 PCM16으로 반올림하고 디코딩한 값을 다음 모델에 전달한다. 자동 정규화·클리핑·리미터·파라미터 추정·임의 계수·실행 코드·외부 분석 API는 없다. 모델 순서는 중요하다. FIR은 고정 계수 평활 필터이지 임의 EQ나 원하는 Hz 차단주파수 필터가 아니다.

0.1.16부터 각 단계에서 디코딩하고 검증한 불변 PCM을 다음 단계에 그대로 전달한다. 동일 바이트를 두 번째로 디코딩하지 않을 뿐, 각 단계의 PCM16 반올림·오버플로·레이트·샘플 수 검사는 유지한다. n개 모델의 내부 출력 디코딩은 2n회에서 n회로 줄며 공개 함수의 WAV 바이트 반환 형식은 같다.

계획은 1~4개 모델과 정확한 `schema_version`, `models` 키만 받는다. 원본·처리본은 같은 레이트의 PCM16 모노 WAV이며 8·16·44.1·48 kHz, 각 2~30초다. 기대본은 원본 레이트·샘플 수를 유지한다. 처리본의 삭제·중복은 모델 일치가 아니다. 리샘플링·이득·지연·잡음·다른 반올림 규칙은 암묵적으로 허용하지 않는다.

```json
{"schema_version":1,"models":[{"kind":"fir_binomial_3"},{"kind":"pcm_quantize_12"}]}
```

## 사용

0.1.12 설치본에서 다음 명령을 사용한다. 출력 디렉터리와 보고서는 존재하지 않는 새 경로여야 한다.

```powershell
audio-transform-check compare --reference original.wav --processed actual.wav --plan models.json --output-dir new_model_run
audio-transform-check report --input new_model_run/model_result.json --output new_model_review.html
audio-transform-check check --input new_model_run/model_result.json
```

소스에서는 `python -m audio_regression.model_cli`로 실행한다. `--engine v2`부터 `v9`까지 명시적으로 선택할 수 있다. 기존 `audio-regression analyze`, `audio-pipeline-check run/audit`의 인수·기본값·계약은 바뀌지 않는다.

```python
from audio_regression.model_check import run_model_check

result = run_model_check("original.wav", "actual.wav",
                        [{"kind": "polarity_invert"}], "new_model_run")
raise SystemExit(result["summary"]["exit_code"])
```

원본·처리본 사본, 기대본, 선언, 분석, 자동 검사, 선택형 추적과 최종 결과를 보존한다. 분석 후 입력과 스냅샷을 다시 확인한다. 시작 후 실패한 자료는 삭제·자동 재시도하지 않는다. 쓰기 장애에서 모든 실패 기록이 남는다고 보장하지는 않는다. 저장 보고서와 `check`는 오디오·추적을 다시 열지 않으므로 파일의 현재 상태나 실행 진위를 증명하지 않는다.

0.1.16의 파일 읽기는 지정 경로와 열린 파일의 전후 크기·시간·식별 정보를 함께 확인한다. 읽는 도중 같은 파일의 내용이 변경되면 `model_input_changed_during_read`로 거부한다. 관측 가능한 링크·하드링크와 안전하게 읽을 수 없는 입력도 거부한다. 오류에 원본 경로를 넣지 않으며, 읽기 완료 이후 변경이나 원자적 잠금까지 보장하지 않는다.

## 결과 해석

| 코드 | 의미 |
| --- | --- |
| compare/check 0 | 전체 PCM 기대 신호와 일치하고 기존 시간 분석도 완료 |
| compare/check 1 | 기대 신호 불일치와 시간적 결함 후보가 있어 검토 필요 |
| compare/check 2 | 불일치가 설명되지 않거나 기존 시간 분석이 보류됨 |
| compare 3 | 잘못된 계획·입력·출력 또는 실행 실패 |
| report 0 / 3 | 저장 결과의 정적 보고서 생성 / 결과·출력 오류 |

동일 길이이면 원래 레이트의 모든 PCM 정수를 비교한다. 헤더·부가 청크가 달라도 PCM이 같으면 일치할 수 있다. 길이가 다르면 인덱스별 불일치 개수와 최대 오차는 `null`이다. 시간 분석의 빈 사건 목록은 한 샘플의 설명되지 않은 차이도 정상으로 바꾸지 않는다. 무음 등의 기존 보류는 PCM이 같아도 유지한다.

하위 시간 분석의 좌표는 **기대본과 실제 처리본** 기준이다. 기대본의 샘플 시간축은 원본과 같지만 FIR 경계·지연의 영향을 원본 결함의 발생 원인으로 확정하지 않는다. 같은 출력은 다른 경로에서도 나올 수 있어 모델 일치는 실행 출처 증명이 아니다. 좁은 고정 모델 호환 검사이며 전체 음질 승인·임의 DSP 지원·복구·일반 성능을 보장하지 않는다.

자체 생성 신호 재현: `python tools/run_transform_model_demo.py --output-dir examples/my_new_models_demo`. 기존 자연음·봉인 평가를 반복하지 않는다.
