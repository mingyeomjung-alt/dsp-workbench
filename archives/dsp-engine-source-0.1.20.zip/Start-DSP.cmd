@echo off
setlocal
title DSP Workbench - Local Audio Check
if not exist "%~dp0.workbench-temp" mkdir "%~dp0.workbench-temp"
if not exist "%~dp0.workbench-temp\" (
  echo A writable local temporary folder is required.
  pause
  exit /b 1
)
set "DSP_WORKBENCH_PYTHON="
if exist "%~dp0..\.venv\Scripts\python.exe" set "DSP_WORKBENCH_PYTHON=%~dp0..\.venv\Scripts\python.exe"
if exist "%~dp0.dsp-runtime\Scripts\python.exe" set "DSP_WORKBENCH_PYTHON=%~dp0.dsp-runtime\Scripts\python.exe"
if defined DSP_WORKBENCH_PYTHON goto run_local
where py >nul 2>nul
if not errorlevel 1 goto run_launcher
echo Python 3.12 with NumPy and SciPy is required on a new PC.
echo No software will be downloaded automatically. See README.md for setup.
pause
exit /b 1
:run_local
"%DSP_WORKBENCH_PYTHON%" -c "import sys; sys.path.insert(0, sys.argv.pop(1)); from audio_regression.workbench import main; raise SystemExit(main())" "%~dp0src" --work-dir "%~dp0.workbench-temp" %*
goto finished
:run_launcher
py -3.12 -c "import sys; sys.path.insert(0, sys.argv.pop(1)); from audio_regression.workbench import main; raise SystemExit(main())" "%~dp0src" --work-dir "%~dp0.workbench-temp" %*
:finished
if errorlevel 1 (
  echo The local application could not start. Check Python and the required dependencies.
  pause
  exit /b 1
)
endlocal
