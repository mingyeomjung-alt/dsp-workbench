# DSP 로컬 검사와 보관 파일 확인

0.1.14는 소스의 선택 회귀 시험을 한 번에 실행하는 도구와, 외부에 보관한 manifest 해시에 맞춰 저장 파일을 확인하는 명령을 추가한다. 기존 시간 분석·모델 검사·전대역 측정·기본 v1과 판정 기준은 바꾸지 않는다. 검사 완료는 음질 승인이나 실제 음원 정확도 검증이 아니다.

## 소스 검사 실행

Python 3.12와 프로젝트 의존성·pytest가 이미 설치된 로컬 환경에서 다음과 같이 실행한다. 아래 예시는 `dsp_engine`의 상위 프로젝트 폴더에서 실행한다. `--source-dir`은 `pyproject.toml`, `src`, `tests`, `tools`가 들어 있는 DSP 소스 폴더다. 결과 폴더는 아직 존재하지 않아야 하며 소스 폴더 내부나 그 상위 폴더와 겹칠 수 없다. 기존 결과를 덮어쓰지 않으며 경로에 `..`를 사용하지 않는다.

```powershell
python -B dsp_engine/tools/run_local_checks.py --source-dir dsp_engine --output-dir validation\local-checks-new
```

API·입력·명령·계약·보고서·파이프라인·모델·전대역·보관본 검증과 0.1.20의 다중 사례 회귀 검사를 포함한 **58개 시험 파일**을 고정 목록으로 실행한다. 전체 시험 모음이나 봉인 평가가 아니다. 새 출력에는 실행 시작 기록, 소스 전후 해시 목록, 시험 XML, 로컬 로그, 최종 `check_summary.json`을 보존한다. XML의 요약 숫자만 믿지 않고 실제 시험 항목과 파일별 수집 여부를 확인한다. 선택한 각 파일에서 건너뛰지 않은 시험이 하나 이상 실행돼야 완료로 처리한다.

도구는 실행 전후 소스·설정·선택 시험·도구 파일을 대조한다. 실행 중 바뀐 소스, 시험 누락, 시험 실패, 실행 오류는 통과하지 않는다. 외부 pytest 플러그인 자동 로드와 추가 옵션을 차단하며 실행 명령을 고정한다. 이 도구는 **사용자가 신뢰하는 소스의 시험 코드**를 실행하므로 알 수 없는 소스를 샌드박스처럼 안전하게 실행하는 기능은 아니다.

## 보관 파일만 확인

설치된 `audio-artifact-check`는 읽기 전용이다. 파일을 재생·해석·복구하거나 분석기를 실행하지 않는다. `--manifest-sha256`에는 보관 당시 별도 기록한 SHA-256을 입력한다. 검사할 manifest에서 현재 해시를 계산해 그대로 믿으면 manifest 변조를 확인할 수 없으므로, 명령에는 자동 해시 생성·재봉인 기능이 없다.

```powershell
audio-artifact-check verify --root preserved-run --manifest preserved-run\artifact_manifest.json --manifest-sha256 <externally-recorded-sha256>
```

manifest는 root 바로 아래의 JSON 파일이며 다음 구조만 받는다. `files`는 상대 경로의 정렬된 목록이고, manifest 자신만 목록에서 제외한다. 아래 해시는 형식 설명용이므로 실제 저장 파일의 보관 당시 해시로 바꿔야 한다.

```json
{
  "schema_version": 1,
  "files": [
    {"path": "result.json", "size_bytes": 100, "sha256": "0000000000000000000000000000000000000000000000000000000000000000"}
  ],
  "manifest_excludes_only_itself": true,
  "network_used": false
}
```

목록과 실제 파일의 크기·내용·전체 파일 범위를 대조한다. 누락·추가 파일, 잘못된 경로, 링크·reparse·하드링크, 읽는 동안 관측된 교체와 용량 한도를 위반하면 거부한다. 파일별 스트리밍 해시를 사용한다. manifest 1 MiB, 파일 4096개, 개별 파일 16 MiB, 전체 목록 512 MiB가 상한이다. 기존 WAV 입력 제한이나 측정 계약을 확장하는 기능은 아니다.

검사 성공은 **입력한 외부 해시에 묶인 파일과 현재 파일이 일치한다**는 뜻이다. 해시의 발행자·진위, 원래 실행 과정, 파일 내용의 의미, 악의적 파일의 안전성은 인증하지 않는다. 경로 검사와 전후 확인도 운영체제 차원의 원자적 잠금을 보장하지 않는다.

## 두 검사를 한 번에 실행

```powershell
python -B dsp_engine/tools/run_local_checks.py --source-dir dsp_engine --output-dir validation\checks-with-artifacts-new --artifact-root preserved-run --artifact-manifest preserved-run\artifact_manifest.json --artifact-manifest-sha256 <externally-recorded-sha256>
```

세 보관본 옵션은 함께 제공해야 한다. 출력 폴더는 보관본 폴더·그 내부·그 상위 폴더와도 겹칠 수 없다. 보관본을 지정하지 않으면 `not_requested`로 기록하며 보관본 확인까지 끝난 것으로 표시하지 않는다. 지정한 보관본은 시험 전후 두 번 확인하며 실패한 경우에는 코드 시험이 성공해도 전체 완료로 처리하지 않는다.

## 종료 코드 읽기

| 명령 | 코드 | 의미 |
| --- | --- | --- |
| 로컬 소스 검사 | 0 | 선택 시험과 요청한 보관본 확인 완료 |
| 로컬 소스 검사 | 1 | 시험 실패 |
| 로컬 소스 검사 | 2 | 소스·수집·보관본 확인 불충족 |
| 로컬 소스 검사 | 3 | 입력·설정·실행 오류 |
| 보관본 verify | 0 | 외부 manifest 해시에 따른 바이트 일치 |
| 보관본 verify | 2 | 보관본 검증 거부 또는 불일치 |
| 보관본 verify | 3 | 명령 인자 또는 예상 밖 실행 오류 |

기존 `audio-regression check`, `audio-transform-check`, `audio-fullband-check`의 코드 의미는 각각 유지한다. 전대역 계산 코드 0을 내용 보존 통과로 합산하지 않는다. 통합 검사 역시 `quality_verdict=not_assessed`이며 음질·상업 성능·파일 진위·실행 내력을 승인하지 않는다.
