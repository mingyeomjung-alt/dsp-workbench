# 저장된 오디오 처리 단계 검사

## 0.1.19 · 단계별 검사 방식을 명시하는 선택형 경로

기존 schema1 파일과 v1 기본값은 유지한다. 동일 엔진 검사에는 `audit --engine v10` 또는 `--engine v11`을 선택할 수 있다. FFT 변환과 변환 후 편집처럼 서로 다른 검사가 필요한 저장 파일은 schema2에서 각 단계와 원본→최종 비교를 따로 지정한다. 파일 순서·단계 이름·샘플률로 엔진이나 모델을 자동 추정하지 않는다.

```json
{
  "schema_version": 2,
  "source": "source.wav",
  "stages": [
    {"label": "FFT 변환", "output": "fft.wav", "engine": "v12", "declaration": {"allow_gain": false, "allow_resampling": true, "resampling_model": "scipy_fft_periodic_48k_16k_pcm16_postedit_v1"}},
    {"label": "이후 출력", "output": "edited.wav", "engine": "v11", "declaration": {"allow_gain": false, "allow_resampling": false}}
  ],
  "end_to_end": {"engine": "v12", "declaration": {"allow_gain": false, "allow_resampling": true, "resampling_model": "scipy_fft_periodic_48k_16k_pcm16_postedit_v1"}}
}
```

위의 WAV들은 사용자가 실제로 저장한 파일이어야 한다. v12는 48→16kHz 주기 FFT→PCM16 반올림→지원되는 변환 후 사건이라는 고정 모델만 허용한다. 이 목록은 외부 처리 명령이 아니며 `audit`이 FFT나 편집을 실행하지 않는다. schema2에는 전역 `--engine`을 추가하지 않는다. 앞선 검토·보류는 나중 단계나 최종 비교가 정상이어도 유지한다.

단계별 결과는 화면의 ‘단계 좌표 추적’에 넣거나 `audio-pipeline-check lineage --input audit_result.json --output lineage.json`, `audio-pipeline-check lineage-report --input lineage.json --output lineage.html`로 연결한다. v12 정상 결과에 정렬 구간이 없으면 시간 길이만으로 좌표를 추정하지 않는다. 시작·끝 손실은 실제 보존된 한쪽 구간만 사용한다. 새 후보 결과에는 `saved-pipeline-result-integrated-v1.schema.json`, 좌표 추적에는 `pipeline-event-lineage-integrated-v1.schema.json`을 사용하며 교차 필드·판정·좌표 연결은 Python 검증기를 함께 적용한다.

자신의 처리 코드에서 이미 만든 원본과 중간 출력 WAV를 순서대로 넣어, 시간적 결함 후보가 처음 관측된 구간을 조사하는 로컬 DSP 검사다. 도구가 처리 코드를 실행하는 `run` 명령과 달리 `audit`은 저장 파일만 읽는다. 외부 프로그램·플러그인·API·화자 모델을 실행하지 않는다.

인접 단계의 입력·출력뿐 아니라 원본과 최종 출력도 검사한다. 앞선 결함 후보·판단 보류는 이후 정상 검사로 지워지지 않는다. 파일 순서는 사용자가 제공한 목록이므로 실제 실행 순서·같은 작업에서 생성된 파일인지·결함 발생 원인은 확인되지 않는다. 지원 범위의 후보 없음도 전체 음질 승인이나 모든 결함이 없다는 뜻은 아니다.

기본 엔진은 v1이며 [정합 개선 후보](ROBUSTNESS.md)는 `audit --engine v2` 또는 Python의 `engine="v2"`로 선택한다. 결과 식별자와 단계별 추적 파일을 구분하고 서로 다른 버전의 단계 결과가 섞이면 거절한다.

저음량 문맥을 연결해 확인하는 [v3 후보](CONTEXT.md)는 `--engine v3` 또는 `engine="v3"`로 선택한다. v1 기본값과 v2는 보존하며 입력 변경·추적 저장 실패를 통과시키지 않는다.

## 파일 목록 준비

목록 파일과 입력 WAV를 같은 자료 폴더에 보관한다. 아래 예시는 `original.wav`, `resampled.wav`, `joined.wav`가 이미 있는 경우다. 경로는 목록 파일의 폴더를 기준으로 한 상대 경로이며 하위 폴더를 사용할 수 있다.

```json
{
  "schema_version": 1,
  "source": "original.wav",
  "stages": [
    {
      "label": "리샘플링 출력",
      "output": "resampled.wav",
      "declaration": {"allow_gain": false, "allow_resampling": true}
    },
    {
      "label": "구간 합치기 출력",
      "output": "joined.wav",
      "declaration": {"allow_gain": false, "allow_resampling": false}
    }
  ]
}
```

1~8단계를 지정한다. `allow_gain`은 실제 허용한 고정 이득, `allow_resampling`은 실제 허용한 정규 리샘플링에만 true로 설정한다. 검출 실패를 통과로 바꾸기 위한 설정이 아니다. 분석 프로필은 기본 범위로 고정한다. 예상 결함 위치·유형·개수나 변환 명령을 입력하지 않는다.

파일 경로는 `/`를 사용한다. 절대 경로·드라이브·상위 폴더 이동·링크·리파스 경로는 거절한다. 각 파일은 PCM16 모노 WAV, 2~30초, 8·16·44.1·48 kHz이며 기존 파일당 10 MB 제한을 유지한다. 서로 다른 발화를 비교하지 말고 같은 원본의 처리 결과를 사용한다.

## 실행

최신 패키지를 설치한 환경에서 다음 명령을 사용한다. 출력 폴더는 존재하지 않는 새 경로여야 한다.

```powershell
audio-pipeline-check audit --manifest my_audio/saved_manifest.json --output-dir my_new_audit
```

현재 소스 작업 공간에서 설치 없이 실행할 때는 다음과 같이 호출한다.

```powershell
$env:PYTHONPATH = (Resolve-Path -LiteralPath 'dsp_engine\src').Path
.\.venv\Scripts\python.exe -m audio_regression.pipeline_cli audit --manifest my_audio/saved_manifest.json --output-dir my_new_audit
```

Python 라이브러리도 제공한다.

```python
from audio_regression.saved_pipeline import audit_saved_pipeline
from audio_regression.saved_pipeline_reporting import write_saved_pipeline_html

result = audit_saved_pipeline("my_audio/saved_manifest.json", "my_new_audit")
write_saved_pipeline_html(result, "my_new_audit/review.html")
raise SystemExit(result["summary"]["exit_code"])
```

## 결과와 실패 처리

`audit_result.json`에 단계별 분석, 최초 관측, 원본·최종 비교와 입력 재확인 상태를 보관한다. `audit_report.html`은 같은 결과를 보여주는 정적 보고서다. 분석용 WAV 사본은 `inputs/000.wav`부터 순서대로 저장하며, 검사기는 이 사본끼리 비교한다. 사본과 원본의 전체 파일 해시를 기록하고 원본 경로는 결과에 넣지 않는다.

| 종료 코드 | 의미 |
| --- | --- |
| 0 | 필요한 시간적 검사 완료, 지원 범위의 후보 없음 |
| 1 | 시간적 결함 후보, 사람의 구간 검토 필요 |
| 2 | 판단 보류·분석 중단·입력 변경 등으로 검사 통과 차단 |
| 3 | 잘못된 목록·입력·출력·결과 명세 또는 파일 처리 실패 |

모든 입력을 먼저 검증한 후 새 출력 폴더에 사본을 보관한다. 분석 오류가 나면 다음 단계 검사를 멈추고 미실행으로 남긴다. 0.1.15부터 종료 전 사용자가 지정한 원본·중간 입력과 실제 분석용 사본을 모두 다시 확인해 변경되거나 읽을 수 없으면 통과를 차단한다. 사본의 관측 가능한 링크·하드링크·읽는 동안의 교체도 재확인 불가로 차단한다. 재확인은 확인 시점의 상태만 확인하며, 전체 파이프라인의 원자적 캡처나 종료 이후 파일 상태를 보장하지 않는다.

입력 재확인의 `file_indices`에서 0은 원본, 1부터는 목록의 해당 출력 단계다. 변경된 파일과 읽을 수 없는 파일이 함께 있으면 재확인 불가 상태로 차단하고 영향을 받은 인덱스를 모두 기록한다.

기존 입력·결과를 덮어쓰거나 실패 후 자동 삭제·재시도하지 않는다. 파일 시스템 장애가 발생하면 부분 결과가 남을 수 있다. 모든 기록을 저장할 수 없는 장애에서 완전한 보고서를 보장하지 않는다.

## 저장한 결과로 보고서 만들기

```powershell
audio-pipeline-check audit-report --input my_new_audit/audit_result.json --output new_audit_report.html
```

이 명령은 오디오를 다시 분석하거나 업로드하지 않는다. 결과 구조·상태·메타데이터 연결을 검증하지만 현재 디스크 WAV를 다시 읽거나 결과 진위를 증명하지 않는다. 내장 `run` 결과와 저장 파일 `audit` 결과는 별도 명세이며 각각 `report`, `audit-report`를 사용한다.

출력 폴더에는 실제 오디오 사본이 있으므로 분석 권한이 있는 파일만 사용하고 로컬 자료로 관리한다. 공유할 때 오디오와 메타데이터·해시를 확인한다. wheel과 소스 인계물에는 실행 오디오를 포함하지 않는다. 정적 HTML에는 외부 리소스·실행 스크립트·오디오 플레이어를 넣지 않는다.

## 개발 예제

```powershell
$env:PYTHONPATH = (Resolve-Path -LiteralPath 'dsp_engine\src').Path
.\.venv\Scripts\python.exe dsp_engine/tools/run_saved_pipeline_demo.py --output-dir dsp_engine/examples/my_new_saved_demo
```

자체 생성 신호로 정상 처리, 합치기 출력의 누락·중복, 무음 출력의 판단 보류를 확인한다. 파일을 만든 뒤 목록으로 검사하며, 예상 관측 위치는 검사 후 예제 도구에서만 확인한다. 독립 자연음 정확도·고객 조사 시간 절감·수요의 증명은 아니며, 기존 최종 평가 자료를 재사용하거나 검출 기준을 튜닝하지 않는다.
