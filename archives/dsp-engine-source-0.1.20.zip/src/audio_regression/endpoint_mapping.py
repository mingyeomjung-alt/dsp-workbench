"""Map terminal resampling padding to physical file time without relaxing QC.

Raw detector outputs retain their historical analysis-grid coordinates. Public
facades use this narrow output correction before returning a strict result. It
does not edit samples, events, offsets, anchors, abstentions, or trace evidence.
"""

from __future__ import annotations

from copy import deepcopy
import math

from .result_contract import ResultContractError, validate_analysis_result


_ENDPOINT_ERRORS = {
    "invalid_alignment_reference_interval",
    "invalid_alignment_processed_interval",
}
# Arithmetic equality only, not a new allowance in the result contract.
_GRID_EQUALITY_MS = 1e-9


def _terminal_grid(metadata: dict, analysis_rate: int) -> tuple[float, float, float]:
    count, rate = metadata["sample_count"], metadata["sample_rate_hz"]
    analysis_count = (count * analysis_rate + rate - 1) // rate
    physical_end = count * 1000 / rate
    grid_end = analysis_count * 1000 / analysis_rate
    padding = (analysis_count * rate - count * analysis_rate) * 1000 / (rate * analysis_rate)
    return physical_end, grid_end, padding


def _terminal_padding_only(end: float, grid_end: float, padding: float,
                           sample_period: float) -> bool:
    return (
        0 < padding < sample_period
        and math.isclose(end, grid_end, rel_tol=0, abs_tol=_GRID_EQUALITY_MS)
    )


def _finite_number(value: object) -> bool:
    if type(value) not in (int, float):
        return False
    try:
        return math.isfinite(value)
    except OverflowError:
        return False


def map_alignment_endpoints(result: dict) -> dict:
    """Return a strict result, correcting only proved ceil-resampling ends.

    Already-valid results are returned unchanged. Only two interval errors may
    enter correction. An overrun must be at that axis's exact terminal analysis
    sample and arise from its own fractional resampling padding (< one sample).
    Both axes must independently satisfy this proof. All other failures remain
    errors, including bad starts, larger/near-terminal overruns, or event errors.
    The caller's dictionary is never mutated.
    """
    try:
        return validate_analysis_result(result)
    except ResultContractError as original_error:
        if original_error.code not in _ENDPOINT_ERRORS:
            raise
        # Full validation has already checked metadata, analysis, and metrics.
        # Later segments may not yet have been visited; handle them defensively
        # and let the unchanged strict validator enforce all remaining rules.
        reference_end, reference_grid, reference_pad = _terminal_grid(
            result["reference"], result["analysis"]["sample_rate_hz"]
        )
        processed_end, processed_grid, processed_pad = _terminal_grid(
            result["processed"], result["analysis"]["sample_rate_hz"]
        )
        period = 1000 / result["analysis"]["sample_rate_hz"]
        segments = result.get("alignment_segments")
        if type(segments) is not list:
            raise original_error
        corrected = deepcopy(result)
        changed = False
        for original, mapped in zip(segments, corrected["alignment_segments"], strict=True):
            if type(original) is not dict:
                raise original_error
            interval = original.get("reference_interval_ms")
            offset = original.get("processed_offset_ms")
            if (type(interval) is not list or len(interval) != 2
                    or any(not _finite_number(value) for value in [*interval, offset])):
                raise original_error
            start, end = interval
            mapped_end = end + offset
            reference_overrun = end > reference_end
            processed_overrun = mapped_end > processed_end + _GRID_EQUALITY_MS
            if reference_overrun and not _terminal_padding_only(
                    end, reference_grid, reference_pad, period):
                raise original_error
            if processed_overrun and not _terminal_padding_only(
                    mapped_end, processed_grid, processed_pad, period):
                raise original_error
            if reference_overrun or processed_overrun:
                bounded_end = min(end, reference_end, processed_end - offset)
                if start >= bounded_end:
                    raise original_error
                mapped["reference_interval_ms"][1] = bounded_end
                changed = True
        if not changed:
            raise original_error
        return validate_analysis_result(corrected)
