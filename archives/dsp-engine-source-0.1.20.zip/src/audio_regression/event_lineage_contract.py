"""Bounded, inert storage contract for derived event-coordinate lineages.

The saved source result is validated by its unchanged pipeline contract. Every
derived field is then recomputed and compared with JSON type fidelity. The
canonical digest binds these records to each other; it is not a signature and
does not authenticate audio, files, execution order, or processing provenance.
No referenced artifact or waveform is opened by these functions.
"""

from __future__ import annotations

import json
from pathlib import Path

from .event_lineage import LineageError, MAX_SOURCE_RESULT_BYTES, build_event_lineage


MAX_LINEAGE_RESULT_BYTES = 8 * 1024 * 1024
MAX_PIPELINE_SOURCE_BYTES = MAX_SOURCE_RESULT_BYTES


def _same_json(first: object, second: object) -> bool:
    """Preserve number and boolean types instead of Python's ``True == 1``."""
    if type(first) is not type(second):
        return False
    if type(first) is dict:
        return set(first) == set(second) and all(
            _same_json(first[key], second[key]) for key in first
        )
    if type(first) is list:
        return len(first) == len(second) and all(
            _same_json(a, b) for a, b in zip(first, second)
        )
    return first == second


def validate_lineage_result(value: object) -> dict:
    """Return the original result only after exact, inert semantic rebuilding."""
    if type(value) is not dict or "source_result" not in value:
        raise LineageError("invalid_lineage_result")
    try:
        expected = build_event_lineage(value["source_result"])
        equal = _same_json(value, expected)
    except LineageError:
        raise
    except (ValueError, TypeError, OverflowError, RecursionError):
        raise LineageError("invalid_lineage_result") from None
    if not equal:
        raise LineageError("inconsistent_lineage_result")
    return value


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    value = {}
    for key, item in pairs:
        if key in value:
            raise LineageError("duplicate_json_key")
        value[key] = item
    return value


def _invalid_constant(_: str) -> None:
    raise LineageError("non_finite_metric")


def _load_json(path: str | Path, limit: int) -> object:
    try:
        with Path(path).open("rb") as stream:
            raw = stream.read(limit + 1)
    except (OSError, ValueError, TypeError):
        raise LineageError("lineage_file_read_error") from None
    if len(raw) > limit:
        raise LineageError("lineage_file_too_large")
    try:
        return json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object,
                          parse_constant=_invalid_constant)
    except LineageError:
        raise
    except (UnicodeError, ValueError, RecursionError, OverflowError):
        raise LineageError("invalid_lineage_json") from None


def load_lineage_result(path: str | Path) -> dict:
    """Read at most 8 MiB of strict UTF-8 JSON; artifact paths stay inert."""
    return validate_lineage_result(_load_json(path, MAX_LINEAGE_RESULT_BYTES))


def load_pipeline_for_lineage(path: str | Path) -> dict:
    """Load and validate one old run/audit result, without any audio access."""
    value = _load_json(path, MAX_PIPELINE_SOURCE_BYTES)
    # The builder chooses the unchanged native/saved contract and enforces the
    # source-size and event budgets. It returns a private copy; callers keep the
    # just-loaded dictionary, not the projection, as their pipeline input.
    build_event_lineage(value)
    return value


def write_lineage_result(result: dict, output: str | Path) -> Path:
    """Store a validated result exclusively, never replacing an existing file."""
    validate_lineage_result(result)
    try:
        raw = (json.dumps(result, ensure_ascii=False, allow_nan=False, indent=2)
               + "\n").encode("utf-8")
    except (ValueError, TypeError, OverflowError, RecursionError):
        raise LineageError("invalid_lineage_result") from None
    if len(raw) > MAX_LINEAGE_RESULT_BYTES:
        raise LineageError("lineage_file_too_large")
    try:
        target = Path(output)
        with target.open("xb") as stream:
            stream.write(raw)
    except FileExistsError:
        raise
    except (OSError, ValueError, TypeError):
        raise LineageError("lineage_file_write_error") from None
    return target
