"""V6 identity without weakening inherited strict temporal evidence rules.

This contract checks saved JSON only. It does not load trace sidecars, rerun
raw-waveform proof, or establish full-audio approval from candidate geometry.
"""

from copy import deepcopy

from . import result_contract as _base
from .review_contract import with_review_diagnostics
from .canonical_result_contract import validate_canonical_analysis_result

ENGINE = "local_content_alignment_v6"
METHOD = "full_copy_feasibility_with_global_source_exclusion"


@with_review_diagnostics
def validate_repeat_analysis_result(value: object) -> dict:
    """Validate separate v6 identity and the unchanged shared v5 rules."""
    if type(value) is not dict:
        raise _base.ResultContractError("invalid_result_type")
    _base._json_tree(value)
    if value.get("engine") != ENGINE:
        raise _base.ResultContractError("unsupported_engine")
    if value.get("status") != "error":
        analysis = value.get("analysis")
        if type(analysis) is not dict or analysis.get("method") != METHOD:
            raise _base.ResultContractError("invalid_analysis_method")
    shared = deepcopy(value)
    shared["engine"] = "local_content_alignment_v5"
    if value.get("status") != "error":
        shared["analysis"]["method"] = "exact_canonical_pcm_resampling_with_unique_context"
    validate_canonical_analysis_result(shared)
    return value
