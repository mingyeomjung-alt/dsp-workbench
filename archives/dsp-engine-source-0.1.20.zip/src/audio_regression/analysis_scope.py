"""Bounded, invocation-local reuse of deterministic preparation work.

No digest is used as a cache key: a caller-supplied container hash does not
prove sample identity. Only the exact immutable input objects of one active
analysis pair can share prepared samples. Public preparation still returns a
fresh writable array, never a reference to this cache.
"""

from __future__ import annotations

import asyncio
from contextvars import ContextVar
from dataclasses import dataclass, field
from functools import wraps
from threading import get_ident
from typing import Callable, ParamSpec, TypeVar

import numpy as np


_MAX_CACHED_BYTES = 8 * 1024 * 1024
_MAX_CACHED_ENTRIES = 4  # Two inputs and their two supported profiles.
_P = ParamSpec("_P")
_R = TypeVar("_R")


def _owner() -> tuple[int, int | None]:
    try:
        task = asyncio.current_task()
    except RuntimeError:  # Ordinary synchronous/library use has no event loop.
        task = None
    return get_ident(), None if task is None else id(task)


@dataclass(slots=True)
class _PreparationScope:
    reference: object
    processed: object
    owner: tuple[int, int | None]
    prepared: dict[tuple[int, str], np.ndarray] = field(default_factory=dict)
    cached_bytes: int = 0

    def contains(self, audio: object) -> bool:
        return audio is self.reference or audio is self.processed


_active_scope: ContextVar[_PreparationScope | None] = ContextVar(
    "audio_regression_preparation_scope", default=None,
)


def analysis_scope(function: Callable[_P, _R]) -> Callable[_P, _R]:
    """Reuse preparation within nested engine calls for the same input pair.

    Different pairs, threads and asynchronous tasks get separate scopes.
    Completion or an exception resets the context and drops cached audio.
    ``wraps`` retains the public callable's name, docs and inspected signature.
    """
    @wraps(function)
    def scoped(reference, processed, *args, **kwargs):
        current = _active_scope.get()
        owner = _owner()
        if (
            current is not None and current.owner == owner
            and current.reference is reference and current.processed is processed
        ):
            return function(reference, processed, *args, **kwargs)
        scope = _PreparationScope(reference, processed, owner)
        token = _active_scope.set(scope)
        try:
            return function(reference, processed, *args, **kwargs)
        finally:
            # Also clear a scope retained by a copied Context. It must not keep
            # prepared audio alive after this synchronous invocation ends.
            scope.prepared.clear()
            scope.cached_bytes = 0
            scope.reference = scope.processed = None
            _active_scope.reset(token)

    return scoped


def cached_preparation(audio: object, profile: str) -> np.ndarray | None:
    """Return an internal immutable base only inside its owning invocation."""
    scope = _active_scope.get()
    if scope is None or scope.owner != _owner() or not scope.contains(audio):
        return None
    return scope.prepared.get((id(audio), profile))


def retain_preparation(audio: object, profile: str, values: np.ndarray) -> None:
    """Keep a bounded immutable copy; never retain unrelated inputs or outputs."""
    scope = _active_scope.get()
    if scope is None or scope.owner != _owner() or not scope.contains(audio):
        return
    key = (id(audio), profile)
    if (
        key in scope.prepared or len(scope.prepared) >= _MAX_CACHED_ENTRIES
        or scope.cached_bytes + values.nbytes > _MAX_CACHED_BYTES
    ):
        return
    # A bytes-backed array cannot be made writable again with setflags.
    frozen = np.frombuffer(values.tobytes(), dtype=np.float64)
    scope.prepared[key] = frozen
    scope.cached_bytes += frozen.nbytes
