"""Static, offline HTML presentation of validated temporal analysis results."""

from html import escape
import json
from pathlib import Path
import re

from .check_policy import check_result
from .result_contract import validate_analysis_result
from .review_presenter import render_review_diagnostics


_LOCAL_PATH = re.compile(
    r"(?:[A-Za-z]:[\\/]|\\\\|file://|/(?:Users|home|tmp|mnt|var|etc)/)[^\s<>\"']*"
    r"|(?<!\S)/(?!/)[^\s<>\"']+",
    re.IGNORECASE,
)


def _e(value: object) -> str:
    """Escape every data string, omitting local paths from the shareable report."""
    return escape(_LOCAL_PATH.sub("[로컬 경로 생략]", str(value)), quote=True)


def _number(value: int | float) -> str:
    return f"{value:,.3f}".rstrip("0").rstrip(".")


def _value(value: object) -> str:
    if value is None:
        return "미제공"
    if isinstance(value, bool):
        return "예" if value else "아니요"
    if isinstance(value, (int, float)):
        return _e(f"{value:,}" if isinstance(value, int) else f"{value:.8g}")
    if isinstance(value, (dict, list)):
        return _e(json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False))
    return _e(value)


_DIAGNOSTIC_LABELS = {
    "normalized_path_cost": "정규화 경로 비용",
    "gain_estimate": "추정 이득",
    "applied_gain": "적용 이득",
    "matched_normalized_rmse": "대응 구간 정규화 RMSE",
    "matched_analysis_samples": "대응 분석 샘플 수",
    "anchor_run_count": "앵커 구간 수",
    "minimum_local_correlation": "최소 국소 상관",
    "boundary_correlation": "경계 상관",
    "offset_before_ms": "이벤트 이전 오프셋 (ms)",
    "offset_after_ms": "이벤트 이후 오프셋 (ms)",
    "copy_correlation": "원본 복사 구간 상관",
    "adjacent_copy_correlation": "인접 복사 구간 상관",
    "retained_offset_ms": "보존 구간 오프셋 (ms)",
    "retained_context_correlation": "보존된 한쪽 문맥의 상관",
    "removed_sample_count": "누락 후보 샘플 수",
    "retained_native_samples": "확인한 원래 샘플률의 보존 샘플 수",
    "all_retained_native_samples_exact": "보존된 전체 PCM 일치",
}

_STYLE = """
:root{color-scheme:light;--ink:#17243b;--muted:#53647c;--line:#dce3ec;--blue:#2554a0;--amber:#8a4b0c;--red:#a32c35}
*{box-sizing:border-box}body{margin:0;background:#eef2f7;color:var(--ink);font:15px/1.65 system-ui,-apple-system,"Segoe UI",sans-serif}
main{max-width:1100px;margin:38px auto;padding:0 24px}header{margin-bottom:24px}.eyebrow{letter-spacing:.16em;font-size:12px;font-weight:800;color:var(--blue)}
h1{font-size:32px;line-height:1.3;margin:8px 0 12px}h2{font-size:20px;margin:0 0 18px}h3{font-size:17px;margin:0 0 12px}p{margin:8px 0}.muted{color:var(--muted)}
.badges{display:flex;gap:8px;flex-wrap:wrap}.badge{padding:4px 11px;border-radius:20px;font-size:12px;font-weight:700;background:#e2e9f4;color:#244779}
.card{background:white;border:1px solid var(--line);border-radius:16px;padding:26px;margin-bottom:20px;box-shadow:0 2px 5px #17243b05}
.summary{border-left:6px solid var(--blue)}.summary.review{border-left-color:var(--red)}.summary.blocked{border-left-color:var(--amber)}
.state{font-size:13px;font-weight:800;color:var(--blue)}.review .state{color:var(--red)}.blocked .state{color:var(--amber)}.summary h2{font-size:26px;line-height:1.4;margin:6px 0 12px}
.notice{padding:18px 22px;border-radius:12px;border:1px solid #e3c394;background:#fff6e7;color:#75400b;margin-bottom:20px}.notice strong{display:block;margin-bottom:3px}
.metrics{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:20px}.metric{background:#f4f7fb;padding:13px 16px;border-radius:10px}.metric span{display:block;font-size:12px;color:var(--muted)}.metric b{font-size:20px}
.table-wrap{overflow:auto}table{border-collapse:collapse;width:100%;text-align:left}th,td{padding:11px 14px;border-bottom:1px solid var(--line);vertical-align:top}th{background:#f5f7fb;font-weight:700;font-size:13px}td:first-child{color:var(--muted);width:25%}
code{font:13px/1.6 ui-monospace,Consolas,monospace;overflow-wrap:anywhere}.hash{word-break:break-all}.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}.grid .card{height:100%}
dl{display:grid;grid-template-columns:minmax(150px,1fr) 1.3fr;gap:10px 14px;margin:0}dt{color:var(--muted);overflow-wrap:anywhere}dd{margin:0;overflow-wrap:anywhere}
.event{border:1px solid var(--line);border-radius:12px;padding:20px;margin-top:16px}.event-head{display:flex;align-items:center;gap:10px;margin-bottom:12px}.event-head h3{margin:0}.delete{background:#fbe9ec;color:var(--red)}.repeat{background:#e8edfb;color:#3756a2}
.axis{font-size:13px;color:var(--muted);margin-top:8px}svg{display:block;width:100%;height:auto}.timeline-plot{min-height:28px}.timeline-ticks{display:flex;justify-content:space-between;gap:12px;padding:0 5.532% 0 5.106%;color:var(--muted);font-size:12px;line-height:1.5}.timeline-ticks span{white-space:nowrap}.track{fill:#e5ebf3}.interval{fill:#aa3540}.source{fill:#4a66b0}.boundary{stroke:#aa3540;stroke-width:3;vector-effect:non-scaling-stroke}
details{margin-top:14px}summary{cursor:pointer;color:var(--blue);font-size:13px;font-weight:700}details dl{margin-top:12px}.scope{font-size:13px}ul{padding-left:20px}li{margin:6px 0}footer{color:var(--muted);font-size:12px;padding:6px 0 28px}
@media(max-width:700px){main{margin:20px auto;padding:0 14px}h1{font-size:26px}.card{padding:20px}.summary h2{font-size:22px}.grid{grid-template-columns:1fr;gap:0}.metrics{grid-template-columns:1fr}dl{grid-template-columns:1fr}dd{margin-bottom:7px}th,td{padding:9px}.event{padding:14px}}
@media print{body{background:white}main{margin:0;max-width:none}.card,.event,.notice{break-inside:avoid;box-shadow:none}details>dl{display:grid}summary{display:none}}
"""


def _details(items: dict) -> str:
    return "<dl>" + "".join(
        f"<dt>{_e(_DIAGNOSTIC_LABELS.get(key, key))}</dt><dd>{_value(value)}</dd>"
        for key, value in sorted(items.items())
    ) + "</dl>"


def _inputs(result: dict) -> str:
    if "reference" not in result or "processed" not in result:
        return '<section class="card"><h2>입력 정보</h2><p class="muted">오류 결과에는 입력 메타데이터가 제공되지 않았습니다.</p></section>'
    fields = [
        ("duration_ms", "길이 (ms)"), ("sample_rate_hz", "샘플률 (Hz)"),
        ("sample_count", "샘플 수"), ("channels", "채널"), ("encoding", "인코딩"),
        ("rms", "RMS"), ("peak", "피크"), ("sha256", "입력 SHA-256"),
    ]
    rows = []
    for field, label in fields:
        values = []
        for axis in ("reference", "processed"):
            value = result[axis].get(field)
            values.append(f'<code class="hash">{_value(value)}</code>' if field == "sha256" else _value(value))
        rows.append(f"<tr><td>{_e(label)}</td><td>{values[0]}</td><td>{values[1]}</td></tr>")
    return '<section class="card"><h2>입력 메타데이터</h2><div class="table-wrap"><table><thead><tr><th>항목</th><th>원본 · Reference</th><th>처리본 · Processed</th></tr></thead><tbody>' + "".join(rows) + '</tbody></table></div><p class="muted scope">해시는 분석 입력을 구별하는 기록입니다. 원본 오디오와 로컬 파일 경로는 이 보고서에 포함되지 않습니다.</p></section>'


def _configuration(result: dict) -> str:
    configuration = result.get("configuration")
    if configuration is None:
        return ""
    analysis = result["analysis"]
    items = {
        "프로필": configuration["profile"],
        "이득 변경 선언": configuration["allow_gain"],
        "리샘플링 선언": configuration["allow_resampling"],
        "최대 초기 지연 검색 (ms)": configuration["max_delay_ms"],
        "분석 샘플률 (Hz)": analysis["sample_rate_hz"],
        "분석 홉 (ms)": analysis["hop_ms"],
        "최소 이벤트 길이 (ms)": analysis["minimum_event_duration_ms"],
        "최대 누적 편집 이동 (ms)": analysis["maximum_cumulative_edit_shift_ms"],
    }
    if "resampling_model" in configuration:
        items["명시한 리샘플링 모델"] = configuration["resampling_model"]
    rows = "".join(f"<dt>{_e(label)}</dt><dd>{_value(value)}</dd>" for label, value in items.items())
    diagnostics = result.get("diagnostics", {})
    detail = _details(diagnostics) if diagnostics else '<p class="muted">진단 수치가 제공되지 않았습니다.</p>'
    return '<div class="grid"><section class="card"><h2>선언된 변환과 분석 범위</h2><dl>' + rows + '</dl><p class="muted scope">변환 선언은 사용자가 허용한 비교 조건입니다.</p></section><section class="card"><h2>진단 수치</h2>' + detail + '<p class="muted scope">상관과 비용은 진단 수치이며 보정된 확률이 아닙니다.</p></section></div>'


def _resampling_reference(result: dict) -> str:
    """Keep the derived comparison signal visibly separate from the raw input."""
    if result.get("engine") != "local_content_alignment_v12":
        return ""
    metadata = result["resampling_reference"]
    if metadata is None:
        detail = '<p>선언한 모델의 비교용 신호를 생성하지 못했습니다.</p>'
    else:
        detail = (f'<dl><dt>비교용 샘플률</dt><dd>{_value(metadata["sample_rate_hz"])} Hz</dd>'
                  f'<dt>비교용 샘플 수</dt><dd>{_value(metadata["sample_count"])}</dd>'
                  f'<dt>비교용 WAV SHA-256</dt><dd><code class="hash">{_e(metadata["sha256"])}</code></dd></dl>')
    return ('<section class="card"><h2>모델로 생성한 비교용 신호</h2>' + detail
            + '<p class="scope muted">위 입력 메타데이터의 원본은 실제 48kHz 파일입니다. 이 비교용 신호는 그 원본에 선언한 전체 기록 FFT 변환과 PCM16 반올림을 적용한 16kHz 신호이며, 원본 파일 자체가 아닙니다. 이벤트의 원본 시간은 두 신호가 공유하는 물리 시간축을 사용합니다.</p>'
            + '<p class="scope muted">출력이 선언 모델과 일치한다는 근거이지 실제 처리 순서나 결함 원인을 입증하지는 않습니다. FFT의 주기적 경계 가정이 포함되며 임의 리샘플러·필터·추가 음량 변경은 지원하지 않습니다.</p></section>')


def _timeline(axis: str, duration: float, interval: list | None = None,
              boundary: float | None = None, source: bool = False) -> str:
    """Each axis uses its own validated duration; no cross-axis time substitution."""
    label = "원본 시간축" if axis == "reference" else "처리본 시간축"
    marks = []
    if interval is not None:
        start, end = interval
        left = 48 + 840 * start / duration
        width = 840 * (end - start) / duration
        role = "source" if source else "interval"
        marks.append(f'<rect class="{role}" x="{left:.3f}" y="15" width="{width:.3f}" height="14" rx="3" data-start-ms="{start:.3f}" data-end-ms="{end:.3f}"/>')
    if boundary is not None:
        left = 48 + 840 * boundary / duration
        marks.append(f'<line class="boundary" x1="{left:.3f}" x2="{left:.3f}" y1="10" y2="34" data-boundary-ms="{boundary:.3f}"/>')
    # Labels live outside the SVG so viewBox scaling cannot shrink their text.
    # The padding percentages match the unchanged plot endpoints 48 and 888.
    return (f'<div class="axis">{_e(label)} · 0–{_e(_number(duration))} ms</div>'
            f'<svg class="timeline-plot" viewBox="0 0 940 42" role="img" '
            f'aria-label="{_e(label)}의 이벤트 위치" data-axis="{axis}" '
            f'data-duration-ms="{duration:.3f}"><rect class="track" x="48" y="15" '
            f'width="840" height="14" rx="7"/>{"".join(marks)}</svg>'
            f'<div class="timeline-ticks" data-axis="{axis}" data-duration-ms="{duration:.3f}">'
            f'<span>0 ms</span><span>{_e(_number(duration))} ms</span></div>')


def _interval_text(interval: list) -> str:
    return f"{_e(_number(interval[0]))}–{_e(_number(interval[1]))} ms ({_e(_number(interval[1] - interval[0]))} ms)"


def _events(result: dict) -> str:
    events = result.get("events")
    if events is None:
        return '<section class="card"><h2>이벤트</h2><p class="muted">판단이 보류되었거나 분석 오류가 있어 이벤트 목록을 확정하지 않았습니다.</p></section>'
    if not events:
        scope = ("전체 출력이 선언한 FFT 리샘플링·PCM16 양자화 모델과 정확히 일치합니다. 전체 음질이나 실제 처리 이력을 승인하는 결과가 아닙니다."
                 if result.get("engine") == "local_content_alignment_v12"
                 else "식별 가능한 내부 삭제·인접 복사 반복 후보에 한정된 결과입니다.")
        return '<section class="card"><h2>이벤트</h2><p>지원 범위의 시간적 결함 후보 없음</p><p class="muted scope">' + scope + '</p></section>'
    rendered = []
    for index, event in enumerate(events, 1):
        kind = event["type"]
        name = "삭제 후보" if kind == "delete" else "반복 후보"
        if kind == "delete" and event.get("location") in {"head", "tail"}:
            name = "시작부분 누락 후보" if event["location"] == "head" else "끝부분 누락 후보"
        if kind == "delete":
            interval = event["reference_interval_ms"]
            boundary = event["processed_boundary_ms"]
            locations = f'<dt>원본 삭제 후보 구간</dt><dd>{_interval_text(interval)}</dd><dt>처리본 대응 경계</dt><dd>{_e(_number(boundary))} ms</dd>'
            tracks = _timeline("reference", result["reference"]["duration_ms"], interval=interval) + _timeline("processed", result["processed"]["duration_ms"], boundary=boundary)
            convention = ('<p class="muted scope">보존된 한쪽 문맥과 전체 남은 PCM의 대응으로 확인한 후보입니다. '
                          '의도적 편집 여부나 손실 원인을 확정한 것은 아닙니다.</p>'
                          if event.get("location") in {"head", "tail"} else "")
        else:
            original = event["reference_source_interval_ms"]
            added = event["processed_added_interval_ms"]
            locations = f'<dt>원본 복사 출처 구간</dt><dd>{_interval_text(original)}</dd><dt>처리본 추가 반복 구간</dt><dd>{_interval_text(added)}</dd>'
            tracks = _timeline("reference", result["reference"]["duration_ms"], interval=original, source=True) + _timeline("processed", result["processed"]["duration_ms"], interval=added)
            convention = '<p class="muted scope">반복 위치는 인접한 복사 중 뒤쪽 구간을 표기합니다. 실제 편집 위치나 원인을 확정하지 않습니다.</p><p><code>' + _e(event.get("copy_interval_convention", "미제공")) + '</code></p>'
        rendered.append(f'<article class="event"><div class="event-head"><span class="badge {kind}">{_e(index)}</span><h3>{_e(name)}</h3><code>{_e(kind)}</code></div><dl>{locations}</dl>{tracks}{convention}<details open><summary>이벤트 진단 근거</summary>{_details(event.get("evidence", {}))}</details></article>')
    model_axis = ('<p class="muted scope">이 후보의 원본 구간은 16kHz 비교용 신호의 구간을 물리 시간으로 표시합니다. 원본 48kHz 샘플이 그 위치에서 실제로 삭제·복사됐다는 뜻은 아닙니다. 선언한 변환 뒤 편집이라는 모델 안에서의 대응입니다.</p>'
                  if result.get("engine") == "local_content_alignment_v12" else "")
    return '<section class="card"><h2>시간적 결함 후보 · ' + _e(len(events)) + '</h2><p class="muted scope">두 시간축은 각 입력의 전체 길이에 맞춰 독립적으로 표시합니다. 정확한 위치는 ms 수치를 기준으로 확인하세요.</p>' + model_axis + "".join(rendered) + '</section>'


def render_html(result: dict) -> str:
    """Validate first and render one deterministic, self-contained UTF-8 report."""
    validate_analysis_result(result)
    check = check_result(result)
    state = {0: "clear", 1: "review", 2: "blocked"}[check["exit_code"]]
    status = result["status"]
    profile = result.get("configuration", {}).get("profile")
    event_count = len(result["events"]) if isinstance(result.get("events"), list) else None
    if profile == "telephone":
        headline = "전화 프로필 · 자동 판단 보류"
    elif status == "error":
        headline = "분석 오류 · 판단 불가"
    elif status == "withheld":
        headline = "근거 부족 · 판단 보류"
    elif event_count:
        headline = "시간적 결함 후보 · 검토 필요"
    else:
        headline = "지원 범위의 시간적 결함 후보 없음"
    labels = {"clear": "지원 범위 확인", "review": "후보 검토 필요", "blocked": "자동 판단 차단"}
    badges = '<span class="badge">LOCAL · OFFLINE</span><span class="badge">DSP M4 · 정적 보고서</span>'
    candidate_notice = ""
    if result.get("engine") in {"local_content_alignment_v2", "local_content_alignment_v3", "local_content_alignment_v4", "local_content_alignment_v5", "local_content_alignment_v6", "local_content_alignment_v7", "local_content_alignment_v8", "local_content_alignment_v9", "local_content_alignment_v10", "local_content_alignment_v11", "local_content_alignment_v12"}:
        version = result["engine"].rsplit("_", 1)[1]
        description = {"v2": "PCM16 미세 정렬 취소를 재검증하는 실험적 엔진입니다. ",
                       "v3": "제한된 활성 문맥으로 미세 정렬 취소를 재검증하는 실험적 엔진입니다. ",
                       "v4": "v3 성공을 유지하고 정합 보류에서만 원시 파형 랜드마크·전역 유일성을 추가 검사하는 선택형 연구 엔진입니다. ",
                       "v5": "v4 결과를 유지하며 정확한 PCM 정상 리샘플링을 증명하는 좁은 선택형 연구 엔진입니다. 저해상도 구간은 저장된 추적 기록에서 구분합니다. ",
                       "v6": "v5 결과를 유지하고 복사 반복 보류에서만 전체 복사와 전역 대체 원본을 추가 검증하는 선택형 연구 엔진입니다. 모호한 경우에는 계속 보류합니다. ",
                       "v7": "v6 결과를 유지하고 선언된 음량 변경·16→8kHz 리샘플링·선행 무음 지연의 정확한 정상 변환만 추가 증명하는 좁은 선택형 연구 엔진입니다. 삭제·복사 보류를 통과로 바꾸는 기능은 아닙니다. ",
                       "v8": "v7 결과를 유지하고 선언된 음량 변경·16→8kHz 리샘플링·선행 무음 지연에 결합된 단일 삭제·복사의 정확한 전체 출력 증명을 추가하는 좁은 선택형 연구 엔진입니다. 사건 후보는 검토 필요이며 정상 통과가 아닙니다. ",
                       "v9": "v8 결과를 유지하고 제한된 전역 문맥 정합으로 단일 삭제·복사의 정확한 전체 출력 증명을 재검증하는 좁은 선택형 연구 엔진입니다. 사건 후보는 검토 필요이며 정상 통과가 아닙니다. ",
                       "v10": "음량·샘플률을 바꾸지 않은 같은 원본에서 50~200ms 단일 내부 삭제·인접 복사를 원래 샘플률의 전체 PCM 대응으로 확인하는 개발 중 후보입니다. 새 경로 밖에서는 기존 v9를 유지합니다. 일반 변환·20ms 결함·가장자리 손실까지 지원한다는 뜻이 아닙니다. ",
                       "v11": "음량·샘플률을 바꾸지 않은 같은 원본에서 50~2000ms 단일 시작·끝 손실을 원래 샘플률의 전체 보존 PCM과 실제 한쪽 문맥으로 확인하는 개발 중 후보입니다. 새 경로 밖에서는 v10을 유지합니다. 임의 변환·의도적 편집 여부·손실 원인을 판정하지 않습니다. ",
                       "v12": "명시한 48→16kHz 전체 기록 FFT 리샘플링과 PCM16 양자화 뒤의 정상 출력, 50~200ms 단일 내부 삭제·인접 복사, 50~2000ms 단일 시작·끝 손실을 정확한 전체 PCM 재구성으로 검증하는 개발 중 후보입니다. 지원 모델과 맞지 않으면 다른 엔진의 정상 통과로 대체하지 않습니다. "}[version]
        badges += f'<span class="badge">{_e(result["engine"])} · 선택한 실험 후보</span>'
        candidate_notice = (f'<aside class="notice"><strong>{_e(version)} · 선택한 개선 후보</strong>'
                            + description +
                            '원시 파형·앵커·이벤트의 검증 기준은 유지되며, 일반 정확도나 상용 성능을 보장하지 않습니다. '
                            '보류 결과에 제한된 추가 검사 요약이 포함되어 있으면 아래에 표시합니다. '
                            '별도 추적 기록이 있다면 저장된 진단 자료이며, 이 보고서는 그 파일을 열거나 존재를 확인하지 않습니다.</aside>')
    if profile is not None:
        badges += '<span class="badge">' + _e(profile) + ' 프로필</span>'
    telephone = '<aside class="notice"><strong>telephone · 실험적 프로필</strong>M3 고정 평가에서 목표를 충족하지 못했습니다. 이벤트가 없더라도 자동 통과로 해석할 수 없으며, 실제 통화 성능이나 상용 성능을 보장하지 않습니다.</aside>' if profile == "telephone" else ""
    reason = result.get("reason_code")
    abstention = ""
    if status == "withheld":
        abstention = '<section class="card"><h2>판단 보류 사유</h2>' + render_review_diagnostics(result) + '</section>'
    elif status == "error":
        abstention = '<section class="card"><h2>분석 오류 사유</h2><p>이 결과로 시간적 결함 여부를 판단할 수 없습니다.</p><p><code>' + _e(reason) + '</code></p></section>'
    limitations = result.get("limitations", [])
    items = '<li>식별 가능한 내부 삭제와 인접 복사 반복 후보를 다룹니다.</li><li>전체 음질, 잡음, 주파수 왜곡, 네트워크 손실 원인, 실제 통화 성능은 이 결과의 범위 밖입니다.</li>'
    items += "".join('<li>' + _e(item) + '</li>' for item in limitations)
    count = "미확정" if event_count is None else str(event_count)
    summary = f'<section class="card summary {state}"><div class="state">{_e(labels[state])}</div><h2>{_e(headline)}</h2><p class="muted">이 보고서는 저장된 분석 결과의 시간적 후보와 판단 보류 근거를 보여줍니다.</p><div class="metrics"><div class="metric"><span>분석 상태</span><b>{_e(status)}</b></div><div class="metric"><span>이벤트 후보 수</span><b>{_e(count)}</b></div><div class="metric"><span>자동 확인 종료 코드</span><b>{_e(check["exit_code"])}</b></div></div><p class="scope muted">확인 정책: <code>{_e(check["reason_code"])}</code></p></section>'
    return '<!doctype html>\n<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\'"><title>DSP 시간적 회귀 분석 보고서</title><style>' + _STYLE + '</style></head><body><main><header><div class="eyebrow">AUDIO REGRESSION / RESULT HANDOFF</div><h1>시간적 회귀 분석 보고서</h1><div class="badges">' + badges + '</div></header>' + telephone + candidate_notice + summary + abstention + _events(result) + _inputs(result) + _resampling_reference(result) + _configuration(result) + '<section class="card scope"><h2>해석 범위와 한계</h2><ul>' + items + '</ul><p>보고서 생성은 오디오를 재분석하지 않습니다. 진단 후보는 음질 승인이나 보정된 확률이 아닙니다.</p></section><footer>자체 포함 정적 HTML · 외부 연결과 원본 오디오 없이 열 수 있습니다.</footer></main></body></html>\n'


def write_html_report(result: dict, path: str | Path) -> None:
    """Create a new report exclusively; any existing output is preserved."""
    rendered = render_html(result)
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(rendered)
