"""Local pipeline execution and static-report CLI; no shell commands or network."""

import argparse
import json
from pathlib import Path
import sys

from .pipeline_runner import PipelineRunError, load_pipeline_plan, run_pipeline
from .pipeline_reporting import (
    PipelineReportError, load_pipeline_result, validate_pipeline_result,
    write_pipeline_html,
)
from .saved_pipeline import SavedPipelineError, audit_saved_pipeline
from .saved_pipeline_contract import (
    SavedPipelineContractError, load_saved_pipeline_result,
    validate_saved_pipeline_result,
)
from .saved_pipeline_reporting import write_saved_pipeline_html
from .event_lineage import LineageError, build_event_lineage
from .event_lineage_contract import (
    load_lineage_result, load_pipeline_for_lineage, write_lineage_result,
)
from .event_lineage_reporting import write_event_lineage_html


def _emit(value: dict) -> None:
    sys.stdout.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="audio-pipeline-check",
        description="Run native DSP stages or audit saved stage files locally; report temporal concerns.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run", help="Execute a bounded native DSP plan into a new local directory.")
    run.add_argument("--source", type=Path, required=True, help="Same-content source PCM16 mono WAV.")
    run.add_argument("--plan", type=Path, required=True, help="Version-1 native stage plan; no executable commands.")
    run.add_argument("--output-dir", type=Path, required=True, help="New private snapshot directory; never replaced.")
    run.add_argument("--engine", choices=tuple("v" + str(i) for i in range(1, 12)), default="v1", help="v1 baseline (default); v2-v11 are explicit candidates. Native resampling is polyphase, never the named v12 FFT model.")
    report = commands.add_parser("report", help="Render a new static report from stored pipeline JSON only.")
    report.add_argument("--input", type=Path, required=True)
    report.add_argument("--output", type=Path, required=True)
    audit = commands.add_parser("audit", help="Check caller-supplied ordered WAV files without running their processor.")
    audit.add_argument("--manifest", type=Path, required=True, help="Version-1 saved-stage manifest or version-2 explicit per-stage engine/model manifest; local relative paths only.")
    audit.add_argument("--output-dir", type=Path, required=True, help="New private snapshot directory; never replaced.")
    audit.add_argument("--engine", choices=tuple("v" + str(i) for i in range(1, 12)), default="v1", help="Global engine for schema 1; omit for schema 2, whose stages and end comparison declare their own engines and named models.")
    audit_report = commands.add_parser("audit-report", help="Render stored saved-stage audit JSON without reanalysis.")
    audit_report.add_argument("--input", type=Path, required=True)
    audit_report.add_argument("--output", type=Path, required=True)
    lineage = commands.add_parser("lineage", help="Project recorded per-event coordinates without audio reanalysis or new approval.")
    lineage.add_argument("--input", type=Path, required=True, help="Stored native-run or saved-audit JSON.")
    lineage.add_argument("--output", type=Path, required=True, help="New standalone lineage JSON; never replaced.")
    lineage_report = commands.add_parser("lineage-report", help="Render stored event lineage without opening audio or referenced paths.")
    lineage_report.add_argument("--input", type=Path, required=True)
    lineage_report.add_argument("--output", type=Path, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    saved_audit = args.command in {"audit", "audit-report"}
    try:
        if args.command in {"lineage", "lineage-report"}:
            if args.input.resolve() == args.output.resolve() or args.output.exists():
                raise FileExistsError("An output file already exists.")
            if args.command == "lineage":
                value = build_event_lineage(load_pipeline_for_lineage(args.input))
                write_lineage_result(value, args.output)
            else:
                value = load_lineage_result(args.input)
                write_event_lineage_html(value, args.output)
            _emit({"schema_version": 1, "engine": value["engine"],
                   "status": "generated_event_lineage" if args.command == "lineage" else "generated_event_lineage_html",
                   "output": str(args.output), "generation_only_not_pipeline_pass": True,
                   "original_gate_state": value["projection"]["original_summary"]["gate_state"],
                   "original_exit_code": value["projection"]["original_summary"]["exit_code"],
                   "complete_audio_approval": False, "fault_provenance_confirmed": False,
                   "network_used": False})
            return 0
        if args.command == "run":
            plan = load_pipeline_plan(args.plan)
            result = run_pipeline(args.source, plan["stages"], args.output_dir,
                                  **({"engine": args.engine} if args.engine != "v1" else {}))
            validate_pipeline_result(result)
            write_pipeline_html(result, args.output_dir / "run_report.html")
            _emit({
                "schema_version": 1, "status": result["status"],
                "gate_state": result["summary"]["gate_state"],
                "exit_code": result["summary"]["exit_code"],
                "first_concern": result["summary"]["first_concern"],
                "artifacts": {"result": str(args.output_dir / "run_result.json"),
                              "report": str(args.output_dir / "run_report.html")},
                "complete_audio_approval": False,
                "commercial_performance_validated": False,
                "fault_provenance_confirmed": False,
                "network_used": False,
                **({"engine": result["engine"]} if args.engine != "v1" else {}),
            })
            return result["summary"]["exit_code"]
        if args.command == "audit":
            result = audit_saved_pipeline(args.manifest, args.output_dir,
                                          **({"engine": args.engine} if args.engine != "v1" else {}))
            validate_saved_pipeline_result(result)
            write_saved_pipeline_html(result, args.output_dir / "audit_report.html")
            _emit({
                "schema_version": 1, "engine": result["engine"],
                "status": result["status"], "gate_state": result["summary"]["gate_state"],
                "exit_code": result["summary"]["exit_code"],
                "first_concern": result["summary"]["first_concern"],
                "input_recheck": result["input_recheck"],
                "artifacts": {"result": str(args.output_dir / "audit_result.json"),
                              "report": str(args.output_dir / "audit_report.html")},
                "complete_audio_approval": False, "commercial_performance_validated": False,
                "fault_provenance_confirmed": False, "caller_order_verified": False,
                "network_used": False,
            })
            return result["summary"]["exit_code"]
        if args.input.resolve() == args.output.resolve():
            raise FileExistsError("An output file already exists.")
        if args.command == "audit-report":
            result = load_saved_pipeline_result(args.input)
            write_saved_pipeline_html(result, args.output)
            _emit({"schema_version": 1, "status": "generated_saved_pipeline_html",
                   "output": str(args.output), "complete_audio_approval": False,
                   "caller_order_verified": False})
            return 0
        result = load_pipeline_result(args.input)
        write_pipeline_html(result, args.output)
        _emit({"schema_version": 1, "status": "generated_pipeline_html",
               "output": str(args.output), "complete_audio_approval": False})
        return 0
    except (PipelineRunError, PipelineReportError, SavedPipelineError, SavedPipelineContractError, LineageError) as exc:
        code = exc.code
    except FileExistsError:
        code = "output_exists"
    except (OSError, RuntimeError):
        code = "pipeline_file_error"
    if args.command in {"lineage", "lineage-report"}:
        _emit({"schema_version": 1, "engine": "audio_pipeline_event_lineage_v1", "status": "error",
               "reason_code": code, "exit_code": 3, "complete_audio_approval": False,
               "fault_provenance_confirmed": False, "network_used": False})
        return 3
    selected_engine = getattr(args, "engine", "v1")
    _emit({"schema_version": 1, "engine": ("audio_saved_pipeline_audit_" if saved_audit else "audio_pipeline_regression_") + selected_engine,
           "status": "error", "gate_state": "blocked", "exit_code": 3,
           "reason_code": code, "complete_audio_approval": False,
           "commercial_performance_validated": False, "network_used": False,
           "fault_provenance_confirmed": False,
           **({"caller_order_verified": False} if saved_audit else {})})
    return 3


if __name__ == "__main__":
    raise SystemExit(main())
