"""Opt-in raw-landmark fallback for identifiable non-speech correspondence.

The spectral v3 detector is unchanged. Only its representation/anchor failures
can enter this bounded fallback. Globally unique raw windows, monotone offsets,
one internal edit at most, and full retained-waveform checks are mandatory.
Periodic or identical repeated evidence cannot earn a unique correspondence.
"""

from __future__ import annotations

from copy import deepcopy
import math
from pathlib import Path

import numpy as np

from . import context_engine
from .analysis_scope import analysis_scope
from .audio import WavAudio, read_wav
from .engine import (
    RATE, EngineConfig, EngineConfigError, _corr, _locate,
    _silent_original_edge,
)
from .profiles import prepare_analysis


ENGINE = "local_content_alignment_v4"
METHOD = "raw_landmark_piecewise_alignment_with_global_uniqueness"
WINDOWS = (1920, 3840, 7680)  # 240, 480, 960 ms; fixed before development checks.
GRID = 640  # Fixed source-only 80 ms grid; never positioned from an answer key.
MIN_CORRELATION = .90
MIN_MARGIN = .03
MIN_ACTIVITY = 8 / 32768
ELIGIBLE_REASONS = frozenset({
    "insufficient_unambiguous_anchors", "unreliable_matched_content",
    "compound_or_unidentified_change", "insufficient_matched_coverage",
})


def _fail(result: dict, trace: dict, reason: str) -> tuple[dict, dict]:
    result.update(status="withheld", content_preservation_status="withheld",
                  reason_code=reason, events=None)
    result.pop("alignment_segments", None)
    trace.update(result_status="withheld", reason_code=reason)
    return result, trace


def _window_consistent(a: np.ndarray, b: np.ndarray, applied: float) -> bool:
    """Prove every local window, not an average dominated by an unchanged part."""
    if len(a) != len(b) or not len(a):
        return False
    width = min(960, len(a))
    starts = sorted(set(range(0, len(a) - width + 1, 480)) | {len(a) - width})
    for start in starts:
        left, right = a[start:start + width], b[start:start + width]
        residual_rms = float(np.sqrt(np.mean((right - applied * left) ** 2)))
        reference_rms = float(np.sqrt(np.mean((applied * left) ** 2)))
        if residual_rms > max(.08 * reference_rms, (1 + abs(applied)) / 32768):
            return False
        if max(float(np.std(left)), float(np.std(right))) > 1e-6 and _corr(left, right) < MIN_CORRELATION:
            return False
    return True


def _landmarks(x: np.ndarray, y: np.ndarray, maximum_offset: int,
               allow_gain: bool) -> tuple[list[dict], int]:
    accepted, attempted = [], 0
    for start in range(0, len(x) - WINDOWS[0] + 1, GRID):
        for width in WINDOWS:
            if start + width > len(x):
                continue
            template = x[start:start + width]
            if float(np.std(template)) < MIN_ACTIVITY:
                continue
            attempted += 1
            # Search the whole processed file, not an assumed local offset. A
            # competing repeated phrase outside a small band must remain visible.
            found = _locate(template, y, 0, len(y) - width)
            if (found is None or found["correlation"] < MIN_CORRELATION
                    or found["peak_margin"] is None or found["peak_margin"] < MIN_MARGIN):
                continue
            offset = found["start"] - start
            if abs(offset) > maximum_offset:
                continue
            target = y[found["start"]:found["start"] + width]
            gain = float(np.dot(template, target) / max(float(np.dot(template, template)), 1e-16))
            if gain <= 0 or not _window_consistent(template, target, gain if allow_gain else 1.0):
                continue
            accepted.append({"reference_start": start, "width": width, "offset": offset,
                             "correlation": found["correlation"], "rival_margin": found["peak_margin"]})
            break
    return accepted, attempted


def _groups(landmarks: list[dict]) -> list[dict]:
    groups = []
    for point in landmarks:
        if not groups or abs(point["offset"] - groups[-1]["offset"]) > 24:
            groups.append({"offset": point["offset"], "points": []})
        groups[-1]["points"].append(point)
    for group in groups:
        group["offset"] = int(round(float(np.median([p["offset"] for p in group["points"]]))))
    return groups


def _boundary(x: np.ndarray, y: np.ndarray, lower: int, upper: int,
              before: int, after: int, kind: str) -> tuple[int, float, list[tuple[int, float]]] | None:
    length = before - after if kind == "delete" else after - before
    width, best, candidates = 480, None, []
    for point in range(max(width, lower), min(len(x) - width, upper) + 1, 8):
        right = point + length if kind == "delete" else point
        left_y, right_y = point + before, right + after
        if left_y < width or right_y < 0 or right_y + width > len(y) or right + width > len(x):
            continue
        a, b = x[point - width:point], y[left_y - width:left_y]
        c, d = x[right:right + width], y[right_y:right_y + width]
        if min(float(np.std(a)), float(np.std(b)), float(np.std(c)), float(np.std(d))) < 1e-6:
            continue
        score = (_corr(a, b) + _corr(c, d)) / 2
        if score >= MIN_CORRELATION:
            candidates.append((point, score))
        if best is None or score > best[1]:
            best = (point, score)
    return (*best, candidates) if best is not None else None


def _whole_adjacent_copy(x: np.ndarray, y: np.ndarray, approximate: int,
                         length: int, before: int, allow_gain: bool) -> tuple | None:
    """Prove full copies against the whole reference, not a trimmed fragment."""
    candidates = set()
    for center in (approximate, approximate - length):
        candidates.update(range(max(0, center - 960), min(len(y) - 2 * length, center + 960) + 1, 8))
    best = None
    for first in sorted(candidates):
        score = _corr(y[first:first + length], y[first + length:first + 2 * length])
        if best is None or score > best[1]:
            best = first, score
    if best is None or best[1] < MIN_CORRELATION:
        return None
    first, pair_correlation = best
    copy_a, copy_b = y[first:first + length], y[first + length:first + 2 * length]
    if not _window_consistent(copy_a, copy_b, 1.0):
        return None
    evidence = []
    for copied in (copy_a, copy_b):
        located = _locate(copied, x, 0, len(x) - length)
        if (located is None or located["correlation"] < MIN_CORRELATION
                or located["peak_margin"] is None or located["peak_margin"] < MIN_MARGIN):
            return None
        source = located["start"]
        reference_copy = x[source:source + length]
        gain = float(np.dot(reference_copy, copied) / max(float(np.dot(reference_copy, reference_copy)), 1e-16))
        if gain <= 0 or not _window_consistent(reference_copy, copied, gain if allow_gain else 1.0):
            return None
        evidence.append(located)
    if evidence[0]["start"] != evidence[1]["start"] or first != evidence[0]["start"] + before:
        return None
    return evidence[0]["start"], first + length, {
        "correlation": min(p["correlation"] for p in evidence),
        "adjacent_copy_correlation": pair_correlation,
    }


def _prove_matches(x: np.ndarray, y: np.ndarray, spans: list[tuple[int, int, int]],
                   config: EngineConfig) -> tuple[dict | None, str | None]:
    pairs = [(x[first:last], y[first + offset:last + offset]) for first, last, offset in spans]
    count = sum(len(a) for a, _ in pairs)
    if count < max(1600, .35 * min(len(x), len(y))):
        return None, "raw_landmark_insufficient_coverage"
    denominator = sum(float(np.dot(a, a)) for a, _ in pairs)
    gain = sum(float(np.dot(a, b)) for a, b in pairs) / max(denominator, 1e-16)
    applied = gain if config.allow_gain else 1.0
    if not math.isfinite(gain) or gain <= 0:
        return None, "raw_landmark_invalid_gain"
    energy = sum(float(np.sum((b - applied * a) ** 2)) for a, b in pairs)
    nrmse = math.sqrt(energy / max(applied * applied * denominator, 1e-16))
    if nrmse > .08:
        return None, "raw_landmark_unexplained_signal_change"
    minimum = None
    for a, b in pairs:
        if not _window_consistent(a, b, applied):
            return None, "raw_landmark_unexplained_local_residual"
        width = min(960, len(a))
        starts = sorted(set(range(0, len(a) - width + 1, 480)) | {len(a) - width})
        for start in starts:
            block_a, block_b = a[start:start + width], b[start:start + width]
            if max(float(np.std(block_a)), float(np.std(block_b))) <= 1e-6:
                continue
            correlation = _corr(block_a, block_b)
            minimum = correlation if minimum is None else min(minimum, correlation)
            if correlation < MIN_CORRELATION:
                return None, "raw_landmark_unexplained_local_change"
    return {"gain_estimate": gain, "applied_gain": applied, "matched_normalized_rmse": nrmse,
            "matched_analysis_samples": count, "anchor_run_count": len(spans),
            "minimum_local_correlation": minimum, "normalized_path_cost": nrmse}, None


@analysis_scope
def analyze_buffers_with_trace(reference: WavAudio, processed: WavAudio,
                               config: EngineConfig | None = None) -> tuple[dict, dict]:
    settings = config if config is not None else EngineConfig()
    if not isinstance(settings, EngineConfig) or settings.profile != "basic":
        raise EngineConfigError("The raw-landmark candidate supports basic only.")
    baseline, _ = context_engine.analyze_buffers_with_trace(reference, processed, settings)
    result = deepcopy(baseline)
    result["engine"] = ENGINE
    result["analysis"]["method"] = METHOD
    result["limitations"].append("v3 successes are preserved; global raw-landmark proof is only used in eligible fallback cases.")
    trace = {"schema_version": 1, "engine": ENGINE, "analysis_engine": ENGINE, "method": METHOD,
             "reference_sha256": reference.sha256, "processed_sha256": processed.sha256,
             "baseline_status": baseline["status"], "baseline_reason_code": baseline["reason_code"],
             "proof_path": "preserved_v3_result",
             "fallback_attempted": False, "window_ms": [240, 480, 960], "grid_ms": 80,
             "global_rival_search": True, "minimum_rival_margin": MIN_MARGIN,
             "landmarks_attempted": 0, "landmarks_accepted": 0, "offset_groups": [],
             "result_status": baseline["status"], "reason_code": baseline["reason_code"]}
    if baseline["status"] == "analyzed" or baseline["reason_code"] not in ELIGIBLE_REASONS:
        return result, trace
    trace["fallback_attempted"] = True
    trace["proof_path"] = "raw_landmark_fallback"
    result["diagnostics"] = {}
    x, y = prepare_analysis(reference), prepare_analysis(processed)
    maximum_offset = math.ceil(settings.max_delay_ms * RATE / 1000) + 16000
    landmarks, attempted = _landmarks(x, y, maximum_offset, settings.allow_gain)
    groups = _groups(landmarks)
    trace.update(landmarks_attempted=attempted, landmarks_accepted=len(landmarks),
                 offset_groups=[{"offset_samples": g["offset"], "landmark_count": len(g["points"])} for g in groups[:32]])
    if not groups or any(len(g["points"]) < 3 for g in groups):
        return _fail(result, trace, "raw_landmark_insufficient_unique_anchors")
    if any(max(p["offset"] for p in g["points"]) - min(p["offset"] for p in g["points"]) > 24 for g in groups):
        return _fail(result, trace, "raw_landmark_unstable_group_offsets")
    if len(groups) > 2:
        return _fail(result, trace, "raw_landmark_multiple_or_unstable_transitions")
    before, after = groups[0]["offset"], groups[-1]["offset"]
    if abs(before * 1000 / RATE) > settings.max_delay_ms + 3:
        return _fail(result, trace, "initial_delay_outside_declared_search")
    if abs(after - before) > 16000:
        return _fail(result, trace, "cumulative_edit_shift_outside_budget")
    first, last = max(0, -before), min(len(x), len(y) - after)
    if first and not _silent_original_edge(reference, 0, first):
        return _fail(result, trace, "non_silent_file_edge_change")
    if before > 0 and not _silent_original_edge(processed, 0, before):
        return _fail(result, trace, "non_silent_file_edge_change")
    if last < len(x) and not _silent_original_edge(reference, last, len(x)):
        return _fail(result, trace, "non_silent_file_edge_change")
    if last + after < len(y) and not _silent_original_edge(processed, last + after, len(y)):
        return _fail(result, trace, "non_silent_file_edge_change")
    events, spans, boundary_candidates = [], [(first, last, before)], []
    if len(groups) == 2:
        kind = "delete" if before > after else "repeat"
        length = abs(after - before)
        if not 1600 <= length <= 16000:
            return _fail(result, trace, "event_outside_supported_duration")
        left, right = groups[0]["points"][-1], groups[1]["points"][0]
        lower = left["reference_start"] + left["width"] - 80
        # A repeated source can map to either identical copy. The first after-
        # offset landmark may begin inside that source; its canonical boundary
        # can be up to one copy length later, unlike a deleted reference gap.
        upper = right["reference_start"] + 80 + (length if kind == "repeat" else -length)
        if upper < lower or upper - lower > 19200:
            return _fail(result, trace, "raw_landmark_event_bracket_not_supported")
        boundary = _boundary(x, y, lower, upper, before, after, kind)
        if boundary is None or boundary[1] < MIN_CORRELATION:
            return _fail(result, trace, "event_boundary_not_supported")
        point, score, boundary_candidates = boundary
        evidence = {"boundary_correlation": score, "offset_before_ms": before / 8,
                    "offset_after_ms": after / 8}
        if kind == "delete":
            if float(np.std(x[point:point + length])) <= 1e-6:
                return _fail(result, trace, "deleted_interval_unidentifiable")
            events = [{"type": "delete", "reference_interval_ms": [point / 8, (point + length) / 8],
                       "processed_boundary_ms": (point + before) / 8, "evidence": evidence}]
            spans = [(first, point, before), (point + length, last, after)]
        else:
            copied = _whole_adjacent_copy(x, y, point + before, length, before, settings.allow_gain)
            if copied is None:
                return _fail(result, trace, "insertion_not_supported_as_repetition")
            source, added, match = copied
            if added != source + length + before:
                return _fail(result, trace, "raw_landmark_inconsistent_copy_gap")
            events = [{"type": "repeat", "reference_source_interval_ms": [source / 8, (source + length) / 8],
                       "processed_added_interval_ms": [added / 8, (added + length) / 8],
                       "copy_interval_convention": "canonical_later_adjacent_copy_not_edit_provenance",
                       "evidence": {**evidence, "copy_correlation": match["correlation"],
                                    "adjacent_copy_correlation": match["adjacent_copy_correlation"]}}]
            spans = [(first, source + length, before), (source + length, last, after)]
            # Canonical later-copy geometry excludes landmarks mapping into the
            # extra copy. Keep only complete independent windows inside each
            # retained segment, then require three and reprove every survivor.
            groups = [{**group, "points": [p for p in group["points"]
                       if start <= p["reference_start"] and p["reference_start"] + p["width"] <= end]}
                      for group, (start, end, _) in zip(groups, spans, strict=True)]
            if any(len(group["points"]) < 3 for group in groups):
                return _fail(result, trace, "raw_landmark_insufficient_canonical_copy_context")
            trace["canonical_anchor_counts"] = [len(group["points"]) for group in groups]
    if any(end <= start or start + offset < 0 or end + offset > len(y) for start, end, offset in spans):
        return _fail(result, trace, "raw_landmark_invalid_correspondence")
    for group, (start, end, offset) in zip(groups, spans, strict=True):
        if any(p["reference_start"] < start or p["reference_start"] + p["width"] > end
               or abs(p["offset"] - offset) > 24 for p in group["points"]):
            return _fail(result, trace, "raw_landmark_anchor_outside_proved_segment")
        for p in group["points"]:
            a = x[p["reference_start"]:p["reference_start"] + p["width"]]
            b = y[p["reference_start"] + offset:p["reference_start"] + offset + p["width"]]
            gain = float(np.dot(a, b) / max(float(np.dot(a, a)), 1e-16))
            if gain <= 0 or not _window_consistent(a, b, gain if settings.allow_gain else 1.0):
                return _fail(result, trace, "raw_landmark_final_offset_reproof_failed")
    diagnostics, reason = _prove_matches(x, y, spans, settings)
    if reason:
        return _fail(result, trace, reason)
    if events and events[0]["type"] == "repeat":
        event = events[0]
        source = round(event["reference_source_interval_ms"][0] * 8)
        added = round(event["processed_added_interval_ms"][0] * 8)
        if not _window_consistent(x[source:source + length], y[added:added + length], diagnostics["applied_gain"]):
            return _fail(result, trace, "raw_landmark_copy_final_gain_reproof_failed")
    if events and events[0]["type"] == "delete":
        # A periodic missing interval may admit several exact edit locations
        # even with unique context on both sides. Full waveform proof, not the
        # first tied local-correlation peak, must rule out alternative locations.
        selected = round(events[0]["reference_interval_ms"][0] * 8)
        candidates_checked = 0
        for alternative, quality in boundary_candidates:
            if abs(alternative - selected) <= 160 or quality < score - MIN_MARGIN:
                continue
            alternative_spans = [(first, alternative, before), (alternative + length, last, after)]
            if any(p["reference_start"] < start or p["reference_start"] + p["width"] > end
                   for group, (start, end, _) in zip(groups, alternative_spans, strict=True)
                   for p in group["points"]):
                continue
            candidates_checked += 1
            if candidates_checked > 128:
                return _fail(result, trace, "raw_landmark_boundary_proof_budget_exceeded")
            alternative_diagnostics, alternative_reason = _prove_matches(x, y, alternative_spans, settings)
            if alternative_reason is None:
                return _fail(result, trace, "raw_landmark_ambiguous_event_boundary")
    result.update(status="analyzed", reason_code=None, events=events,
                  content_preservation_status="defect_candidates" if events else "no_supported_defect_candidates",
                  diagnostics=diagnostics)
    result["alignment_segments"] = []
    for group, (start, end, offset) in zip(groups, spans, strict=True):
        points = group["points"]
        selected = [points[0], points[len(points) // 2], points[-1]]
        result["alignment_segments"].append({"reference_interval_ms": [start / 8, end / 8],
            "processed_offset_ms": offset / 8,
            "anchor_correlations": [p["correlation"] for p in selected]})
    trace.update(result_status="analyzed", reason_code=None)
    return result, trace


def analyze_buffers(reference: WavAudio, processed: WavAudio,
                    config: EngineConfig | None = None) -> dict:
    return analyze_buffers_with_trace(reference, processed, config)[0]


def analyze_wavs_with_trace(reference_path: str | Path, processed_path: str | Path,
                            config: EngineConfig | None = None) -> tuple[dict, dict]:
    return analyze_buffers_with_trace(read_wav(reference_path), read_wav(processed_path), config)
