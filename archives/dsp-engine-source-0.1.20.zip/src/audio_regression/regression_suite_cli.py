"""Bounded local regression-suite execution and inert static-report CLI."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys

from .regression_suite import run_regression_suite
from .regression_suite_contract import SuiteError, load_suite_result, validate_suite_result
from .regression_suite_reporting import write_suite_html


ENGINE = "audio_regression_suite_v1"
_SAFE_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}\Z")


def _emit(value: dict) -> None:
    sys.stdout.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="audio-regression-suite",
        description="Compare bounded saved baseline and candidate WAV suites locally; not complete audio approval.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    run = commands.add_parser("run", help="Analyze a manifest of existing WAV triplets into a new directory.")
    run.add_argument("--manifest", type=Path, required=True)
    run.add_argument("--output-dir", type=Path, required=True, help="New output directory; existing output is never replaced.")
    report = commands.add_parser("report", help="Render stored suite JSON only; never reopen audio or referenced paths.")
    report.add_argument("--input", type=Path, required=True)
    report.add_argument("--output", type=Path, required=True, help="New standalone HTML file; existing output is never replaced.")
    return parser


def _error(code: str) -> dict:
    return {
        "schema_version": 1,
        "engine": ENGINE,
        "status": "error",
        "reason_code": code,
        "exit_code": 3,
        "complete_audio_approval": False,
        "commercial_performance_validated": False,
        "fault_provenance_confirmed": False,
        "network_used": False,
    }


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "run":
            result = run_regression_suite(args.manifest, args.output_dir)
            validate_suite_result(result)
            write_suite_html(result, args.output_dir / "suite_report.html")
            _emit({
                "schema_version": 1,
                "engine": ENGINE,
                "status": "completed" if result["execution_complete"] else "incomplete",
                "summary": result["summary"],
                "artifacts": {
                    "result": str(args.output_dir / "suite_result.json"),
                    "report": str(args.output_dir / "suite_report.html"),
                },
                "complete_audio_approval": False,
                "commercial_performance_validated": False,
                "fault_provenance_confirmed": False,
                "network_used": False,
            })
            return result["summary"]["exit_code"]
        if args.input.resolve() == args.output.resolve() or args.output.exists():
            raise FileExistsError("An output file already exists.")
        result = load_suite_result(args.input)
        write_suite_html(result, args.output)
        _emit({
            "schema_version": 1,
            "engine": ENGINE,
            "status": "generated_regression_suite_html",
            "exit_code": 0,
            "generation_only_not_suite_pass": True,
            "original_summary": result["summary"],
            "complete_audio_approval": False,
            "commercial_performance_validated": False,
            "fault_provenance_confirmed": False,
            "network_used": False,
        })
        return 0
    except SuiteError as exc:
        candidate = getattr(exc, "code", None)
        code = candidate if type(candidate) is str and _SAFE_CODE.fullmatch(candidate) else "suite_contract_error"
    except FileExistsError:
        code = "output_exists"
    except (OSError, RuntimeError, ValueError, TypeError, OverflowError, RecursionError):
        code = "suite_file_error"
    except Exception:
        code = "suite_internal_error"
    _emit(_error(code))
    return 3


if __name__ == "__main__":
    raise SystemExit(main())
