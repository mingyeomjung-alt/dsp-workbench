"""Offline event-coordinate lineage presentation, never analysis or approval."""
from pathlib import Path

from .event_lineage_contract import validate_lineage_result
from .pipeline_reporting import _STYLE, _e


_REASONS = {
    "stage_not_analyzed": "중간 단계가 보류·오류·미실행이어서 좌표를 연결하지 않았습니다.",
    "unmapped_alignment_gap": "질의 구간 전체를 덮는 정렬 기록이 없어 빈 구간을 추정하지 않았습니다.",
    "ambiguous_alignment": "서로 다른 시간 이동량이 만나는 경계이거나 대응이 하나로 정해지지 않습니다.",
    "repeated_content_multiple_correspondences": "반복된 내용으로 대응이 여러 개일 수 있어 한 사본을 원본으로 선택하지 않았습니다.",
    "input_integrity_or_completion_unavailable": "원본 기록의 실행 완료·입력 보존 조건을 충족하지 못해 좌표 연결을 보류했습니다.",
}
_GATES = {
    "clear_supported_temporal_check": "지원 범위의 시간적 후보 없음",
    "review_required": "결함 후보 검토 필요",
    "blocked": "판단 보류 또는 실행 오류",
}


def _number(value: int | float) -> str:
    return f"{value:,.9f}".rstrip("0").rstrip(".")


def _query(query: dict | None) -> str:
    if query is None:
        return "미확정"
    if query["kind"] == "boundary":
        return f'경계 {_number(query["time_ms"])} ms'
    start, end = query["interval_ms"]
    return f"구간 {_number(start)}–{_number(end)} ms"


def _side(side: dict, title: str) -> str:
    mapped = side["status"] == "mapped"
    coordinate = _query(side["fragments"][0]) if mapped else "추적 미확정"
    reason = ("각 중간 단계의 기록된 정렬 범위 안에서 대응했습니다. 실제 실행 이력이나 샘플 동일성 증명은 아닙니다."
              if mapped else _REASONS[side["reason_code"]])
    rows = []
    for hop in side["hops"]:
        direction = "이전 단계로" if hop["direction"] == "backward" else "다음 단계로"
        rows.append(f'<tr><td>{hop["stage_index"]} · {direction}</td>'
                    f'<td>{_e(_query(hop["input_query"]))}</td>'
                    f'<td>{_e(_query(hop["output_query"]))}</td>'
                    f'<td>{_e(_REASONS.get(hop["reason_code"], "기록상 대응"))}</td></tr>')
    hops = ('<div class="table-wrap"><table><thead><tr><th>거친 단계</th><th>추적 전 좌표</th>'
            '<th>추적 후 좌표</th><th>결과</th></tr></thead><tbody>' + "".join(rows) + '</tbody></table></div>'
            if rows else '<p class="muted scope">거친 중간 단계 없음. 해당 축에서 직접 관찰된 좌표이거나 실행·입력 보존 조건 때문에 추적을 시작하지 않았습니다.</p>')
    return (f'<section><h3>{_e(title)}</h3><p><strong>{_e(coordinate)}</strong></p>'
            f'<p class="scope muted">{_e(reason)}</p>{hops}</section>')


def render_event_lineage_html(value: dict) -> str:
    """Validate and render stored JSON only; paths are inert and never opened."""
    validate_lineage_result(value)
    projection = value["projection"]
    original = projection["original_summary"]
    summary = projection["summary"]
    items = []
    stages = value["source_result"]["stages"]
    for event in projection["events"]:
        index = event["stage_index"]
        name = "삭제 후보" if event["type"] == "delete" else "반복 후보"
        reference_label = "삭제된 입력 구간" if event["type"] == "delete" else "입력의 복사 출처 구간"
        processed_label = "출력의 대응 경계" if event["type"] == "delete" else "출력의 나중 추가 사본 구간"
        items.append(
            f'<article class="card"><div class="index">관찰 단계 {index} · {_e(stages[index-1]["label"])}</div>'
            f'<h2>사건 {index}.{event["event_index"]+1} · {_e(name)}</h2>'
            f'<dl><dt>{_e(reference_label)}</dt><dd>{_e(_query(event["reference_query"]))}</dd>'
            f'<dt>{_e(processed_label)}</dt><dd>{_e(_query(event["processed_query"]))}</dd></dl>'
            '<p class="scope muted">위 좌표는 이 단계의 입력·출력 시간축입니다. 삭제된 구간을 최종 출력에 남아 있는 오디오 구간처럼 표시하지 않습니다. 반복의 나중 사본 표기는 실제 편집 출처를 확정하지 않습니다.</p>'
            '<div class="grid">' + _side(event["source_projection"], "입력 구간 → 최초 원본 시간축")
            + _side(event["final_projection"], "출력 경계·추가 구간 → 최종 시간축") + '</div></article>')
    if not items:
        items.append('<section class="card"><h2>단계별 사건 없음</h2><p>저장된 인접 단계 분석에 사건 후보가 없습니다. 전체 정상·음질 승인 또는 모든 단계의 분석 성공을 뜻하지 않습니다.</p></section>')
    source = projection["source"]
    final = projection["final"]
    final_info = (f'{_e(_number(final["duration_ms"]))} ms · {_e(final["sample_rate_hz"])} Hz'
                  if final is not None else "최종 출력 메타데이터 없음")
    integrity = ("실패가 기록되지 않음 · 현재 파일은 재확인하지 않음"
                 if projection["input_integrity"] == "no_failure_recorded" else "미완료 또는 입력 보존 실패 기록 있음")
    end_count = projection["end_to_end_event_count_not_attributed"]
    end_note = (f"원본–최종 검사에서 별도로 관측된 사건 {end_count}개는 특정 단계 사건과 합치거나 원인을 배정하지 않았습니다."
                if end_count is not None else "원본–최종 검사가 보류·오류·미실행이어서 그 사건 수는 미확정입니다. 특정 단계에 임의 배정하지 않았습니다.")
    return ('<!doctype html>\n<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
            '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\'">'
            '<title>DSP 사건별 단계 좌표 추적</title><style>' + _STYLE + '</style></head><body><main>'
            '<header><div class="eyebrow">DSP WORKBENCH / EVENT COORDINATE LINEAGE</div><h1>사건별 단계 좌표 추적</h1>'
            '<p class="muted">저장된 진단 좌표의 연결입니다. 오디오를 다시 분석하지 않습니다.</p></header>'
            '<section class="card"><h2>기존 검사 판정 유지</h2>'
            f'<p><strong>{_e(_GATES[original["gate_state"]])}</strong> · 기존 종료 코드 {_e(original["exit_code"])}</p>'
            f'<p>단계별 사건 {summary["observed_event_count"]}개 · 양쪽 추적 완료 {summary["fully_projected_count"]}개 · 일부 미확정 {summary["unresolved_event_count"]}개</p>'
            '<p class="notice">처음 관찰된 단계는 실제 원인 확정이 아닙니다. 해시·파일 순서는 생성 이력·진위 증명이 아닙니다. 미확정 좌표를 추측으로 채우지 않으며, 이 보고서는 기존 검사 판정을 완화하지 않습니다.</p></section>'
            '<section class="card"><h2>좌표 기준과 자료 상태</h2><dl>'
            f'<dt>원본</dt><dd>{_e(_number(source["duration_ms"]))} ms · {_e(source["sample_rate_hz"])} Hz</dd>'
            f'<dt>최종 출력</dt><dd>{final_info}</dd><dt>입력 보존 기록</dt><dd>{_e(integrity)}</dd>'
            f'<dt>입력 결과 JSON 해시</dt><dd><code class="hash">{_e(value["source_result_sha256"])}</code></dd></dl>'
            f'<p class="scope muted">{_e(end_note)}</p></section>'
            + "".join(items)
            + '<footer>로컬 정적 보고서 · 상관 기반 정렬 기록의 좌표 투영 · 실제 파일·오디오·외부 경로를 열지 않음 · 상용 정확도·전체 음질 승인 아님</footer></main></body></html>\n')


def write_event_lineage_html(value: dict, path: str | Path) -> None:
    rendered = render_event_lineage_html(value)
    with Path(path).open("x", encoding="utf-8", newline="\n") as output:
        output.write(rendered)
