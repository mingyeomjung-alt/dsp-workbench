"use strict";

(() => {
  const $ = (id) => document.getElementById(id);
  const MAX_FILE_BYTES = 10000000;
  const MAX_LINEAGE_BYTES = 4 * 1024 * 1024;
  const FFT_RESAMPLING_MODEL = "scipy_fft_periodic_48k_16k_pcm16_postedit_v1";
  const ENGINE_NOTES = {
    v1: "기본 비교입니다. 다른 방식은 명시된 좁은 범위에서만 추가 검증된 후보이며 실사용 정확도를 보장하지 않습니다.",
    v9: "연구용 후보입니다. 전역 문맥을 사용한 긴 구간 대응을 비교하며 실사용 성능 개선은 확정되지 않았습니다.",
    v10: "같은 샘플률의 PCM에서 내부 누락·인접 반복 50–200 ms를 전체 샘플 일치로 확인합니다. 변환 없는 파일용입니다. 이 범위 밖은 기존 비교가 사용될 수 있습니다.",
    v11: "v10의 짧은 내부 구간에 시작·끝 손실 50–2000 ms 검사를 더합니다. 같은 샘플률·변환 없는 PCM용이며, 이 범위 밖은 기존 비교가 사용될 수 있습니다.",
    v12: "전체 원본을 SciPy FFT 주기 신호 방식으로 48→16 kHz 변환하고 PCM16 반올림한 뒤 편집한 한 경로만 검사합니다. 원본 샘플 수는 3의 배수여야 합니다. 다른 필터·이득·변환 전 편집을 자동 추정하지 않습니다."
  };
  const files = { reference: null, processed: null };
  const urls = { reference: null, processed: null };
  let session = null;
  let busy = false;
  let lineageBusy = false;
  let lineageFile = null;
  let lineagePayload = null;
  let resultPayload = null;
  let listenStop = null;
  let activeAudio = null;

  function node(tag, className, text) {
    const element = document.createElement(tag);
    if (className) element.className = className;
    if (text !== undefined) element.textContent = text;
    return element;
  }

  function sizeText(bytes) {
    return bytes < 1000000 ? `${(bytes / 1000).toFixed(1)} KB` : `${(bytes / 1000000).toFixed(2)} MB`;
  }

  function timeText(ms) {
    return `${(ms / 1000).toFixed(3).replace(/0+$/, "").replace(/\.$/, "")}초`;
  }

  function validNumber(value) {
    return typeof value === "number" && Number.isFinite(value) && value >= 0;
  }

  function validInterval(interval) {
    return Array.isArray(interval) && interval.length === 2 && interval.every(validNumber) && interval[1] > interval[0];
  }

  function intervalText(interval) {
    return `${timeText(interval[0])}–${timeText(interval[1])}`;
  }

  function stopListening() {
    if (activeAudio) activeAudio.pause();
    if (listenStop) clearInterval(listenStop);
    listenStop = null;
    activeAudio = null;
  }

  function setMessage(message) {
    $("run-message").textContent = message;
  }

  function modeError() {
    const mode = $("engine-select").value;
    if (mode === "v12" && ($("allow-gain").checked || !$("allow-resampling").checked)) {
      return "FFT 방식에는 실제로 해당 48→16 kHz 변환을 수행했는지 확인하고 ‘샘플레이트를 바꿨어요’를 직접 체크하세요. 음량 변경은 함께 사용할 수 없습니다.";
    }
    if (["v10", "v11"].includes(mode) && ($("allow-gain").checked || $("allow-resampling").checked)) {
      return "선택한 정밀 검사는 변환 없는 동일 샘플률 PCM용입니다. 파일을 임의 변환하지 말고 실제 처리에 맞는 기본 비교 또는 명시적 FFT 방식을 선택하세요.";
    }
    return "";
  }

  function updateMode() {
    $("engine-note").textContent = ENGINE_NOTES[$("engine-select").value] || "지원하는 방식을 선택하세요.";
    const message = modeError();
    $("mode-warning").textContent = message;
    $("mode-warning").hidden = !message;
  }

  function setBusy(value) {
    busy = value;
    const locked = busy || lineageBusy;
    document.querySelectorAll("input, select, #settings-fieldset, .remove-file, #reset-button, #download-report, #download-json").forEach((element) => { element.disabled = locked; });
    for (const axis of ["reference", "processed"]) {
      $(`${axis}-drop`).setAttribute("aria-disabled", String(locked));
    }
    $("analyze-button").disabled = locked || !session || !files.reference || !files.processed || !!modeError();
    $("lineage-button").disabled = locked || !session || !lineageFile;
    $("lineage-report-download").disabled = locked || !lineagePayload;
    $("lineage-json-download").disabled = locked || !lineagePayload;
    $("analyze-button-label").textContent = value ? "분석 중" : "비교 검사 시작";
    $("analyze-button").querySelector(".button-spinner").hidden = !value;
    $("analyze-button").querySelector(".button-arrow").hidden = value;
    $("results-panel").setAttribute("aria-busy", String(value));
    $("run-message").classList.toggle("is-busy", value);
    $("busy-state").hidden = !value;
    $("empty-state").hidden = value || !!resultPayload;
    $("result-content").hidden = value || !resultPayload;
    $("result-actions").hidden = value || !resultPayload;
  }

  function clearError() {
    $("analysis-error").hidden = true;
    $("analysis-error-message").textContent = "";
    $("analysis-error-code").textContent = "";
  }

  function showError(message, code = "request_failed") {
    $("analysis-error-message").textContent = message;
    $("analysis-error-code").textContent = code;
    $("analysis-error").hidden = false;
    setMessage("검사 결과가 확정되지 않았습니다. 안내를 확인한 후 다시 시도하세요.");
  }

  function clearResults() {
    resultPayload = null;
    stopListening();
    $("candidate-list").replaceChildren();
    $("result-meta").replaceChildren();
    $("report-frame").removeAttribute("srcdoc");
    document.querySelector(".report-preview").open = false;
    $("result-content").hidden = true;
    $("result-actions").hidden = true;
    $("empty-state").hidden = false;
  }

  function changeFile(axis, file) {
    if (busy || lineageBusy) return;
    clearError();
    if (file && (!file.name.toLowerCase().endsWith(".wav") || file.size <= 0 || file.size > (session?.limits?.max_file_bytes || MAX_FILE_BYTES))) {
      const message = !file.name.toLowerCase().endsWith(".wav") ? "WAV 파일을 선택해 주세요. MP3·M4A 등은 지원하지 않습니다." : file.size <= 0 ? "빈 파일은 검사할 수 없습니다." : "파일 하나당 최대 10 MB까지 선택할 수 있습니다.";
      showError(message, "invalid_local_file");
      $(`${axis}-file`).value = "";
      return;
    }
    clearResults();
    if (urls[axis]) URL.revokeObjectURL(urls[axis]);
    const audio = $(`${axis}-audio`);
    audio.pause();
    audio.removeAttribute("src");
    audio.load();
    urls[axis] = null;
    files[axis] = file || null;
    $(`${axis}-drop`).classList.toggle("has-file", !!file);
    $(`${axis}-file-name`).textContent = file ? file.name : `${axis === "reference" ? "원본" : "처리본"} WAV 선택`;
    $(`${axis}-file-info`).textContent = file ? `${sizeText(file.size)} · 다른 파일로 바꾸려면 선택하세요` : "파일을 끌어 놓거나 눌러서 선택하세요";
    $(`${axis}-preview`).hidden = !file;
    if (file) {
      urls[axis] = URL.createObjectURL(file);
      audio.src = urls[axis];
    } else {
      $(`${axis}-file`).value = "";
    }
    setBusy(false);
    setMessage(files.reference && files.processed ? "파일이 준비되었습니다. 실제 처리한 내용을 선택하고 검사를 시작하세요." : "원본과 처리본을 선택하면 검사를 시작할 수 있습니다.");
  }

  async function loadSession() {
    session = null;
    $("reconnect-button").disabled = true;
    $("analyze-button").disabled = true;
    $("version-label").textContent = "연결 확인 중";
    try {
      const response = await fetch("/api/session", { cache: "no-store", credentials: "omit", headers: { Accept: "application/json" } });
      if (!response.ok) throw new Error("로컬 실행 창이 열려 있는지 확인해 주세요.");
      const data = await response.json();
      if (data.schema_version !== 1 || typeof data.token !== "string" || !data.token || typeof data.version !== "string" || data.local_only !== true) throw new Error("로컬 검사기의 연결 정보가 올바르지 않습니다.");
      session = data;
      $("version-label").textContent = `LOCAL ENGINE · ${data.version}`;
      $("connection-error").hidden = true;
      setMessage(files.reference && files.processed ? "파일이 준비되었습니다. 검사를 시작할 수 있습니다." : "원본과 처리본을 선택하면 검사를 시작할 수 있습니다.");
    } catch (error) {
      $("connection-error-message").textContent = error instanceof Error ? error.message : "실행 창을 확인하고 다시 연결해 주세요.";
      $("connection-error").hidden = false;
      $("version-label").textContent = "로컬 연결 필요";
      setMessage("로컬 검사기에 연결한 후 사용할 수 있습니다.");
    } finally {
      $("reconnect-button").disabled = false;
      setBusy(busy);
    }
  }

  function fileBase64(file) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onload = () => {
        const encoded = reader.result;
        if (typeof encoded !== "string" || !encoded.includes(",")) reject(new Error("파일을 읽지 못했습니다. 다시 선택해 주세요."));
        else resolve(encoded.slice(encoded.indexOf(",") + 1));
      };
      reader.onerror = () => reject(new Error("파일을 읽지 못했습니다. 파일 접근 권한을 확인해 주세요."));
      reader.onabort = () => reject(new Error("파일 읽기가 중단되었습니다."));
      reader.readAsDataURL(file);
    });
  }

  function metadataCard(axis, metadata) {
    const card = node("div", "meta-card");
    const label = node("h4", null);
    label.append(node("span", `axis-marker ${axis}-marker`), document.createTextNode(axis === "reference" ? "원본 · Reference" : "처리본 · Processed"));
    card.append(label, node("strong", null, files[axis]?.name || "선택한 파일"));
    if (metadata && validNumber(metadata.duration_ms) && validNumber(metadata.sample_rate_hz)) {
      card.append(node("p", null, `${timeText(metadata.duration_ms)} · ${metadata.sample_rate_hz.toLocaleString("ko-KR")} Hz · ${metadata.channels === 1 ? "모노" : "채널 정보 확인"}`));
    } else card.append(node("p", null, "입력 메타데이터가 제공되지 않았습니다."));
    return card;
  }

  function timeline(duration, interval, boundary, reference) {
    if (!validNumber(duration) || duration <= 0) return null;
    const ns = "http://www.w3.org/2000/svg";
    const svg = document.createElementNS(ns, "svg");
    svg.setAttribute("viewBox", "0 0 340 26");
    svg.setAttribute("class", "event-timeline");
    svg.setAttribute("role", "img");
    svg.setAttribute("aria-label", `${reference ? "원본" : "처리본"} ${timeText(duration)} 중 확인 위치`);
    const track = document.createElementNS(ns, "rect");
    Object.entries({ x: "1", y: "9", width: "338", height: "7", rx: "3.5", class: "timeline-track" }).forEach(([key, value]) => track.setAttribute(key, value));
    svg.append(track);
    if (validInterval(interval) && interval[1] <= duration) {
      const region = document.createElementNS(ns, "rect");
      Object.entries({ x: String(1 + 338 * interval[0] / duration), y: "9", width: String(Math.max(1, 338 * (interval[1] - interval[0]) / duration)), height: "7", rx: "2", class: reference ? "timeline-region timeline-reference" : "timeline-region" }).forEach(([key, value]) => region.setAttribute(key, value));
      svg.append(region);
    }
    if (validNumber(boundary) && boundary <= duration) {
      const line = document.createElementNS(ns, "line");
      const x = String(1 + 338 * boundary / duration);
      Object.entries({ x1: x, x2: x, y1: "4", y2: "22", class: "timeline-boundary" }).forEach(([key, value]) => line.setAttribute(key, value));
      svg.append(line);
    }
    return svg;
  }

  function listenAt(axis, startMs, endMs) {
    const audio = $(`${axis}-audio`);
    stopListening();
    if (!urls[axis]) return;
    const seek = async () => {
      try {
        const begin = Math.max(0, startMs / 1000 - 0.3);
        audio.currentTime = begin;
        activeAudio = audio;
        await audio.play();
        const stop = validNumber(endMs) ? endMs / 1000 + 0.3 : begin + 1.6;
        listenStop = setInterval(() => { if (audio.currentTime >= stop || audio.ended) stopListening(); }, 100);
        setMessage(`${axis === "reference" ? "원본" : "처리본"}의 ${timeText(startMs)} 전후를 재생합니다. 위 파일 재생기로도 직접 확인할 수 있습니다.`);
      } catch (_) {
        stopListening();
        setMessage("브라우저에서 이 파일을 재생하지 못했습니다. 원본 파일을 별도 재생기에서 확인해 주세요.");
      }
    };
    if (audio.readyState >= 1) seek();
    else {
      audio.addEventListener("loadedmetadata", seek, { once: true });
      audio.load();
    }
  }

  function axisCard(axis, label, position, subtitle, duration, interval, boundary, listenStart, listenEnd) {
    const card = node("div", "event-axis");
    const axisLabel = node("div", "event-axis-label");
    axisLabel.append(node("span", `axis-marker ${axis}-marker`), document.createTextNode(label));
    card.append(axisLabel, node("strong", null, position), node("small", null, subtitle));
    const track = timeline(duration, interval, boundary, axis === "reference");
    if (track) card.append(track);
    const button = node("button", "listen-button", "이 구간 듣기");
    button.type = "button";
    button.setAttribute("aria-label", `${axis === "reference" ? "원본" : "처리본"} ${position} 전후 듣기`);
    button.addEventListener("click", () => listenAt(axis, listenStart, listenEnd));
    card.append(button);
    return card;
  }

  function candidateCard(event, index, result) {
    if (!event || typeof event !== "object") return null;
    const deleted = event.type === "delete";
    if (!deleted && event.type !== "repeat") return null;
    const source = deleted ? event.reference_interval_ms : event.reference_source_interval_ms;
    const added = event.processed_added_interval_ms;
    const boundary = event.processed_boundary_ms;
    if (!validInterval(source) || (deleted ? !validNumber(boundary) : !validInterval(added))) return null;
    const referenceDuration = result.reference?.duration_ms;
    const processedDuration = result.processed?.duration_ms;
    if (!validNumber(referenceDuration) || !validNumber(processedDuration) || source[1] > referenceDuration || (deleted ? boundary > processedDuration : added[1] > processedDuration)) return null;
    const article = node("article", "candidate-card");
    const header = node("div", "candidate-heading");
    const title = node("h4", null);
    const eventTitle = deleted ? event.location === "head" ? "시작 손실 후보" : event.location === "tail" ? "끝 손실 후보" : "삭제 후보" : "인접 반복 후보";
    title.append(node("span", "candidate-number", String(index + 1).padStart(2, "0")), document.createTextNode(eventTitle));
    header.append(title, node("span", `candidate-type${deleted ? "" : " repeat"}`, deleted ? "MISSING INTERVAL" : "ADJACENT REPEAT"));
    const body = node("div", "candidate-body");
    const axes = node("div", "axis-grid");
    axes.append(axisCard("reference", deleted ? "원본 시간축 · 삭제 후보 구간" : "원본 시간축 · 복사 출처 구간", intervalText(source), files.reference.name, referenceDuration, source, null, source[0], source[1]));
    axes.append(deleted ? axisCard("processed", "처리본 시간축 · 대응 경계", timeText(boundary), files.processed.name, processedDuration, null, boundary, boundary, boundary + 800) : axisCard("processed", "처리본 시간축 · 추가 반복 구간", intervalText(added), files.processed.name, processedDuration, added, null, added[0], added[1]));
    const next = node("p", "next-action");
    next.append(node("strong", null, "다음 확인"), document.createTextNode(deleted ? `원본의 ${intervalText(source)}와 처리본의 ${timeText(boundary)} 전후를 들어 보세요. 해당 구간이 의도치 않게 빠졌는지 처리 단계의 자르기·이어 붙이기 설정을 확인하세요.` : `원본의 ${intervalText(source)}와 처리본의 ${intervalText(added)}를 들어 보세요. 인접 구간이 의도치 않게 두 번 포함되었는지 확인하세요.`));
    body.append(axes, next);
    body.append(node("p", "event-convention", deleted ? "각 위치는 해당 파일의 독립된 시간축입니다. 검출 위치만으로 실제 편집 원인을 확정하지 않습니다." : "반복은 인접한 복사 중 뒤쪽 구간을 표시합니다. 원본·처리본 시간축은 독립적이며 실제 복사 편집 위치를 확정하지 않습니다."));
    article.append(header, body);
    return article;
  }

  function renderResult(payload) {
    const result = payload.result;
    const exitCode = payload.check.exit_code;
    const summary = $("result-summary");
    summary.className = `result-summary${exitCode === 1 ? " review" : exitCode === 2 ? " blocked" : ""}`;
    $("result-status-icon").textContent = exitCode === 0 ? "✓" : exitCode === 1 ? "!" : "–";
    $("result-kicker").textContent = $("engine-select").value !== "v1" ? `지원 범위 제한 후보 · ${$("engine-select").value} · 실사용 성능 미확정` : "검사 완료 · 기본 엔진";
    $("result-headline").textContent = exitCode === 0 ? "시간적 후보 없음" : exitCode === 1 ? "구간 확인 필요" : "판단 보류";
    $("result-description").textContent = exitCode === 0 ? "지원 범위에서 식별 가능한 삭제·인접 반복 후보가 발견되지 않았습니다. 전체 음질이 정상이라는 뜻은 아닙니다." : exitCode === 1 ? "아래 위치에서 시간적 결함 후보가 관찰되었습니다. 각 파일을 직접 듣고 의도한 처리인지 확인하세요." : "현재 입력과 지원 범위로는 결론을 확정하지 못했습니다. 정상 또는 결함 없음으로 처리하지 마세요. 파일 형식·변환 조건과 전체 보고서의 보류 사유를 확인하세요.";
    $("result-meta").replaceChildren(metadataCard("reference", result.reference), metadataCard("processed", result.processed));
    const list = $("candidate-list");
    list.replaceChildren();
    if (exitCode === 1 && Array.isArray(result.events)) {
      let shown = 0;
      result.events.forEach((event, index) => {
        const card = candidateCard(event, index, result);
        if (card) { list.append(card); shown += 1; }
      });
      if (!shown) list.append(node("p", "no-events-note", "표시할 구간 정보가 없습니다. 전체 보고서에서 후보와 판단 근거를 확인하세요."));
    } else {
      list.append(node("p", "no-events-note", exitCode === 0 ? "다음 확인: 처리 내용이 올바르게 선언되었는지 확인하고, 필요한 경우 전체 보고서를 저장해 검사 기록으로 보관하세요." : "다음 확인: PCM16·모노·2–30초 조건과 원본·처리본의 관계를 확인하세요. 실제 수행한 음량 조절·리샘플링만 선택한 후 다시 검사하세요."));
    }
    $("report-frame").srcdoc = payload.report_html;
    resultPayload = payload;
  }

  async function analyze() {
    if (busy || lineageBusy || !session || !files.reference || !files.processed) return;
    if (modeError()) { showError(modeError(), "invalid_local_configuration"); return; }
    clearError();
    clearResults();
    stopListening();
    $("reference-audio").pause();
    $("processed-audio").pause();
    setBusy(true);
    setMessage("파일을 읽고 로컬 검사기로 전달하고 있습니다. 이 PC 밖으로 전송되지 않습니다.");
    try {
      const [reference, processed] = await Promise.all([fileBase64(files.reference), fileBase64(files.processed)]);
      const request = { reference: { name: files.reference.name, base64: reference }, processed: { name: files.processed.name, base64: processed }, allow_gain: $("allow-gain").checked, allow_resampling: $("allow-resampling").checked, engine: $("engine-select").value };
      if (request.engine === "v12") request.resampling_model = FFT_RESAMPLING_MODEL;
      const response = await fetch("/api/analyze", {
        method: "POST", cache: "no-store", credentials: "omit",
        headers: { "Content-Type": "application/json", "X-DSP-Token": session.token, Accept: "application/json" },
        body: JSON.stringify(request)
      });
      let payload;
      try { payload = await response.json(); }
      catch (_) { throw new Error("로컬 검사기의 응답을 읽지 못했습니다. 실행 창을 확인한 후 다시 시도해 주세요."); }
      if (!response.ok || payload.status === "error") {
        const error = new Error(typeof payload.message === "string" ? payload.message : "로컬 검사 요청을 완료하지 못했습니다.");
        error.code = typeof payload.code === "string" ? payload.code : `http_${response.status}`;
        throw error;
      }
      if (payload.schema_version !== 1 || payload.status !== "completed" || !payload.result || typeof payload.result !== "object" || !payload.check || payload.check.contract_valid !== true || ![0, 1, 2].includes(payload.check.exit_code) || typeof payload.report_html !== "string" || !["analyzed", "withheld", "error"].includes(payload.result.status)) {
        const error = new Error("검사 결과의 형식을 확인하지 못했습니다. 통과로 간주하지 않습니다.");
        error.code = "invalid_server_response";
        throw error;
      }
      renderResult(payload);
      setMessage(payload.check.exit_code === 2 ? "검사가 판단 보류로 끝났습니다. 아래 안내와 전체 보고서를 확인하세요." : "검사가 완료되었습니다. 아래에서 구간을 확인하고 필요한 보고서를 저장하세요.");
      $("results-panel").scrollIntoView({ behavior: window.matchMedia("(prefers-reduced-motion: reduce)").matches ? "auto" : "smooth", block: "start" });
    } catch (error) {
      showError(error instanceof Error ? error.message : "검사 중 문제가 발생했습니다.", error.code || "request_failed");
    } finally {
      setBusy(false);
    }
  }

  function download(content, type, name) {
    const url = URL.createObjectURL(new Blob([content], { type }));
    const anchor = node("a", null);
    anchor.href = url;
    anchor.download = name;
    document.body.append(anchor);
    anchor.click();
    anchor.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  }

  function clearLineage() {
    lineagePayload = null;
    $("lineage-frame").removeAttribute("srcdoc");
    $("lineage-preview").hidden = true;
    $("lineage-preview").open = false;
  }

  async function analyzeLineage() {
    if (busy || lineageBusy || !session || !lineageFile) return;
    clearLineage();
    lineageBusy = true;
    setBusy(false);
    $("lineage-button").textContent = "좌표를 연결하는 중";
    $("lineage-message").textContent = "저장된 진단 좌표만 검증합니다. 오디오나 기록 속 경로는 열지 않습니다.";
    try {
      const sourceText = new TextDecoder("utf-8", { fatal: true }).decode(await lineageFile.arrayBuffer());
      // Send the original JSON text intact: parsing/stringifying here would
      // erase duplicate keys before the strict server-side validator sees them.
      const response = await fetch("/api/lineage", {
        method: "POST", cache: "no-store", credentials: "omit",
        headers: { "Content-Type": "application/json", "X-DSP-Token": session.token, Accept: "application/json" },
        body: '{"source_result":' + sourceText + '}'
      });
      const payload = await response.json();
      if (!response.ok || payload.status === "error") throw new Error(typeof payload.message === "string" ? payload.message : "저장 단계 결과를 확인하지 못했습니다.");
      const result = payload.lineage_result;
      if (payload.schema_version !== 1 || payload.status !== "completed" || !result || result.engine !== "audio_pipeline_event_lineage_v1" || result.coordinate_projection_only !== true || result.complete_audio_approval !== false || result.commercial_performance_validated !== false || typeof payload.report_html !== "string" || !result.projection?.summary) throw new Error("좌표 추적 결과의 형식을 확인하지 못했습니다. 기존 검사 판정을 변경하지 않습니다.");
      lineagePayload = payload;
      const summary = result.projection.summary;
      $("lineage-message").textContent = `사건 ${summary.observed_event_count}개 · 양쪽 연결 ${summary.fully_projected_count}개 · 일부 미확정 ${summary.unresolved_event_count}개. 기존 검사 판정은 유지됩니다. 실제 원인·실행 이력 증명은 아닙니다.`;
      $("lineage-frame").srcdoc = payload.report_html;
      $("lineage-preview").hidden = false;
      $("lineage-preview").open = true;
    } catch (error) {
      $("lineage-message").textContent = error instanceof Error ? error.message : "좌표 추적을 완료하지 못했습니다. 정상 판정으로 처리하지 않습니다.";
    } finally {
      lineageBusy = false;
      $("lineage-button").textContent = "사건 좌표 연결";
      setBusy(false);
    }
  }

  for (const axis of ["reference", "processed"]) {
    const input = $(`${axis}-file`);
    const zone = $(`${axis}-drop`);
    input.addEventListener("change", () => { if (input.files.length) changeFile(axis, input.files[0]); });
    zone.addEventListener("click", (event) => { if (busy || lineageBusy) event.preventDefault(); });
    for (const kind of ["dragenter", "dragover"]) zone.addEventListener(kind, (event) => { event.preventDefault(); if (!busy && !lineageBusy) zone.classList.add("drag-over"); });
    zone.addEventListener("dragleave", () => zone.classList.remove("drag-over"));
    zone.addEventListener("drop", (event) => {
      event.preventDefault(); zone.classList.remove("drag-over");
      if (busy || lineageBusy) return;
      if (event.dataTransfer.files.length !== 1) { showError("각 칸에는 WAV 파일 하나씩 선택해 주세요.", "one_file_required"); return; }
      changeFile(axis, event.dataTransfer.files[0]);
    });
    $(`${axis}-audio`).addEventListener("play", () => {
      const other = $(`${axis === "reference" ? "processed" : "reference"}-audio`);
      other.pause();
    });
    $(`${axis}-audio`).addEventListener("error", () => { if (files[axis]) setMessage("미리 듣기를 지원하지 않는 파일일 수 있습니다. 실제 입력 형식은 검사 시 별도로 확인합니다."); });
  }
  document.querySelectorAll(".remove-file").forEach((button) => button.addEventListener("click", () => changeFile(button.dataset.remove, null)));
  document.querySelectorAll("#settings-fieldset input, #engine-select").forEach((input) => input.addEventListener("change", () => {
    if (resultPayload) { clearResults(); setMessage("비교 조건이 바뀌었습니다. 새 조건으로 검사를 다시 시작하세요."); }
    updateMode();
    setBusy(busy);
  }));
  $("analyze-button").addEventListener("click", analyze);
  $("reconnect-button").addEventListener("click", loadSession);
  $("reset-button").addEventListener("click", () => {
    if (busy || lineageBusy) return;
    changeFile("reference", null);
    changeFile("processed", null);
    $("allow-gain").checked = false;
    $("allow-resampling").checked = false;
    $("engine-select").value = "v1";
    updateMode();
    lineageFile = null;
    $("lineage-file").value = "";
    clearLineage();
    $("lineage-message").textContent = "단계별 결과 JSON을 선택하세요. 파일은 이 PC 밖으로 전송되지 않습니다.";
    setBusy(false);
    document.querySelector(".advanced-settings").open = false;
    clearError();
    setMessage("새 검사를 준비했습니다. 원본과 처리본을 선택해 주세요.");
    $("reference-file").focus();
  });
  $("download-report").addEventListener("click", () => { if (resultPayload && !busy) download(resultPayload.report_html, "text/html;charset=utf-8", "dsp-report.html"); });
  $("download-json").addEventListener("click", () => { if (resultPayload && !busy) download(JSON.stringify(resultPayload.result, null, 2) + "\n", "application/json;charset=utf-8", "dsp-analysis.json"); });
  $("lineage-file").addEventListener("change", () => {
    if (busy || lineageBusy) return;
    clearLineage();
    const file = $("lineage-file").files[0] || null;
    lineageFile = file && file.name.toLowerCase().endsWith(".json") && file.size > 0 && file.size <= MAX_LINEAGE_BYTES ? file : null;
    $("lineage-message").textContent = lineageFile ? "단계별 결과가 준비되었습니다. 사건 좌표 연결을 누르세요." : "1바이트 이상 4 MiB 이하인 단계별 JSON 파일 하나를 선택하세요.";
    if (!lineageFile) $("lineage-file").value = "";
    setBusy(false);
  });
  $("lineage-button").addEventListener("click", analyzeLineage);
  $("lineage-report-download").addEventListener("click", () => { if (lineagePayload && !busy && !lineageBusy) download(lineagePayload.report_html, "text/html;charset=utf-8", "dsp-event-lineage.html"); });
  $("lineage-json-download").addEventListener("click", () => { if (lineagePayload && !busy && !lineageBusy) download(JSON.stringify(lineagePayload.lineage_result, null, 2) + "\n", "application/json;charset=utf-8", "dsp-event-lineage.json"); });
  document.querySelector('a[href="#usage-guide"]').addEventListener("click", () => { $("usage-guide").open = true; });
  window.addEventListener("dragover", (event) => event.preventDefault());
  window.addEventListener("drop", (event) => event.preventDefault());
  window.addEventListener("pagehide", () => { stopListening(); Object.values(urls).forEach((url) => { if (url) URL.revokeObjectURL(url); }); });
  updateMode();
  loadSession();
})();
