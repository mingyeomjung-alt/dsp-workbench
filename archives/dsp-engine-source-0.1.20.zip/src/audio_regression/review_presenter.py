"""Safe, offline presentation of the bounded withheld-result projection.

This is presentation only: no audio, raw trace, artifact path, or file is read.
Public report entry points validate their result before using this renderer.
"""

from html import escape
import re

from .review_diagnostics import ENGINE_STAGE_LABELS, describe_reason


_LOCAL_PATH = re.compile(
    r"(?:[A-Za-z]:[\\/]|\\\\|file://|/(?:Users|home|tmp|mnt|var|etc)/)[^\s<>\"']*"
    r"|(?<!\S)/(?!/)[^\s<>\"']+", re.IGNORECASE,
)
_OUTCOMES = {
    "withheld": "추가 증명 미확보",
    "not_attempted": "추가 검사 미시도",
    "attempted_without_proof_detail": "검사 시도 기록 · 상세 근거 미기록",
}
_AVAILABILITY = {
    "not_recorded": (
        "추가 검사 기록 미제공",
        "이 결과에는 추가 검사 기록이 포함되지 않았습니다. "
        "기록이 없다는 이유만으로 미시도나 증명 실패라고 판단하지 않습니다.",
    ),
    "unavailable": (
        "추가 검사 기록 사용 불가",
        "이 결과에서 추가 검사 기록을 사용할 수 없습니다. "
        "검사가 실패했다거나 수행되지 않았다는 뜻은 아닙니다.",
    ),
}


def _e(value: object) -> str:
    return escape(_LOCAL_PATH.sub("[로컬 경로 생략]", str(value)), quote=True)


def _reason_view(code: str | None, *, primary: bool = False) -> str:
    if code is None:
        return '<p class="muted scope">이 단계의 상세 사유는 기록되지 않았습니다.</p>'
    description = describe_reason(code)
    code_view = '<code>' + _e(code) + '</code>'
    if primary:
        return (
            '<p><strong>' + _e(description["label"]) + '</strong> · ' + code_view + '</p>'
            + '<p>' + _e(description["explanation"]) + '</p>'
            + '<p class="scope"><strong>다음 확인:</strong> ' + _e(description["next_check"]) + '</p>'
        )
    return (
        '<p><strong>' + _e(description["label"]) + '</strong> · ' + code_view + '</p>'
        + '<p class="scope muted">' + _e(description["explanation"]) + '</p>'
        + '<p class="scope"><strong>다음 확인:</strong> ' + _e(description["next_check"]) + '</p>'
    )


def render_review_diagnostics(result: dict) -> str:
    """Render stored explanations, keeping the final reason independent.

    Legacy withheld results without the optional block still receive a static
    explanation of their final reason. Missing records never imply a failed
    proof, and a recorded unattempted stage never becomes a final cause.
    """
    if result.get("status") != "withheld":
        return ""
    reason = result["reason_code"]
    rendered = (
        '<div class="review-diagnostics"><section class="review-primary" '
        'data-review-primary-reason="' + _e(reason) + '"><h3>최종 판단 보류 사유</h3>'
        + _reason_view(reason, primary=True)
        + '<p class="scope muted">이 주사유는 저장된 최종 분석 결과에서 가져왔습니다. '
        '아래 추가 검사 기록을 최종 원인으로 바꾸어 해석하지 않습니다.</p></section>'
    )
    diagnostic = result.get("review_diagnostics")
    availability = diagnostic["trace_availability"] if diagnostic is not None else "not_recorded"
    rendered += '<details open class="review-stages"><summary>저장된 추가 검사 기록</summary>'
    if availability != "recorded":
        label, explanation = _AVAILABILITY[availability]
        rendered += '<h3>' + _e(label) + '</h3><p class="scope muted">' + _e(explanation) + '</p>'
    else:
        rendered += (
            '<p class="scope muted">결과 JSON에 포함된 제한된 진단 요약만 표시합니다. '
            '별도 추적 파일은 열거나 존재를 확인하지 않습니다. '
            '각 항목은 그 검사의 저장된 상태이며, 결함의 실제 발생 원인은 아닙니다.</p>'
        )
        if not diagnostic["stages"]:
            rendered += '<p class="scope muted">이 요약에는 개별 추가 검사 상태가 기록되지 않았습니다.</p>'
        rows = []
        for stage in diagnostic["stages"]:
            engine, outcome = stage["engine"], stage["outcome"]
            content = '<p><strong>' + _e(_OUTCOMES[outcome]) + '</strong></p>'
            if outcome == "not_attempted":
                content += '<p class="scope muted">미시도는 검사 실패나 결함 판정을 뜻하지 않습니다.</p>'
            elif outcome == "attempted_without_proof_detail":
                content += '<p class="scope muted">상세 증명 근거가 없어 성공·실패 여부를 추가로 추정하지 않습니다.</p>'
            content += _reason_view(stage["reason_code"])
            if stage["detail_reason_code"] is not None:
                content += '<p class="scope muted">기록된 세부 사유:</p>' + _reason_view(stage["detail_reason_code"])
            rows.append(
                '<tr data-review-stage="' + _e(engine) + '" data-review-outcome="' + _e(outcome) + '">'
                '<td>' + _e(ENGINE_STAGE_LABELS.get(engine, engine)) + '<br><code>' + _e(engine)
                + '</code></td><td>' + content + '</td></tr>'
            )
        rendered += (
            '<div class="table-wrap"><table><thead><tr><th>기록된 검사</th><th>그 단계의 상태와 설명</th>'
            '</tr></thead><tbody>' + ''.join(rows) + '</tbody></table></div>'
        )
    return (
        rendered + '</details><p class="scope muted">설명은 검토를 돕는 진단 정보입니다. '
        '자동 승인, 음질 합격 또는 결함 발생 원인 확정이 아닙니다.</p></div>'
    )
