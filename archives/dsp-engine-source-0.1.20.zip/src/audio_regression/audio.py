"""Strict PCM16 WAV I/O for the standalone audio regression engine.

Decoding preserves every PCM sample: no trimming, gain normalization, speech
gate, or resampling is performed here. The RIFF container is checked explicitly
because permissive readers can accept truncated or inconsistent WAV payloads.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
from pathlib import Path
import re
import struct

import numpy as np


SUPPORTED_SAMPLE_RATES = frozenset({8000, 16000, 44100, 48000})
MAX_FILE_BYTES = 10_000_000
MIN_DURATION_SECONDS = 2
MAX_DURATION_SECONDS = 30
_SHA256 = re.compile(r"[0-9a-f]{64}\Z")


class AudioInputError(ValueError):
    """An input rejection with a stable, non-private machine-readable code."""

    def __init__(self, code: str, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(message)


@dataclass(frozen=True, slots=True)
class WavAudio:
    """Immutable normalized PCM16 samples and a container digest.

    Direct construction requires exact PCM16 values and a caller-supplied
    lowercase SHA-256 digest. Only its format can be checked here: samples
    cannot establish the hash of a RIFF container with arbitrary metadata.
    Use ``decode_wav`` to compute the original container digest from bytes.
    To intentionally quantize float samples, use ``decode_wav(encode_wav(...))``.
    """

    samples: np.ndarray
    sample_rate_hz: int
    sha256: str

    def __post_init__(self) -> None:
        _validate_rate(self.sample_rate_hz)
        try:
            raw = np.asarray(self.samples)
            if raw.dtype.kind not in "iuf":
                raise ValueError("non-real numeric samples")
            values = np.asarray(raw, dtype=np.float64)
        except (TypeError, ValueError, OverflowError):
            raise AudioInputError("invalid_samples", "Samples must be a finite normalized mono array.") from None
        if (
            values.ndim != 1
            or not np.all(np.isfinite(values))
            or np.any(values < -1.0)
            or np.any(values > 1.0)
        ):
            raise AudioInputError("invalid_samples", "Samples must be a finite normalized mono array.")
        _validate_duration(values.size, self.sample_rate_hz)
        # PCM16 decoding divides signed integers by a power of two, so the
        # grid check is exact. Do not round, clip, or normalize direct inputs.
        scaled = values * 32768.0
        if np.any(scaled > 32767) or np.any(scaled != np.rint(scaled)):
            raise AudioInputError("non_pcm16_samples", "Direct samples must be exact normalized PCM16 values.")
        if type(self.sha256) is not str or _SHA256.fullmatch(self.sha256) is None:
            raise AudioInputError("invalid_audio_hash", "Use a lowercase 64-character SHA-256 digest.")
        object.__setattr__(self, "samples", np.frombuffer(values.tobytes(), dtype=np.float64))
        object.__setattr__(self, "sample_rate_hz", int(self.sample_rate_hz))

    def metadata(self) -> dict[str, str | int | float]:
        """Return JSON-safe measurements without raw audio or file paths."""
        return {
            "sample_rate_hz": self.sample_rate_hz,
            "sample_count": int(self.samples.size),
            "duration_ms": float(self.samples.size * 1000 / self.sample_rate_hz),
            "channels": 1,
            "encoding": "pcm16",
            "rms": float(np.sqrt(np.mean(self.samples * self.samples))),
            "peak": float(np.max(np.abs(self.samples))),
            "sha256": self.sha256,
        }


def _validate_rate(sample_rate_hz: int) -> None:
    if (
        isinstance(sample_rate_hz, bool)
        or not isinstance(sample_rate_hz, (int, np.integer))
        or sample_rate_hz not in SUPPORTED_SAMPLE_RATES
    ):
        raise AudioInputError(
            "unsupported_sample_rate", "Supported sample rates are 8, 16, 44.1, and 48 kHz."
        )


def _validate_duration(sample_count: int, sample_rate_hz: int) -> None:
    if not (
        MIN_DURATION_SECONDS * sample_rate_hz
        <= sample_count
        <= MAX_DURATION_SECONDS * sample_rate_hz
    ):
        raise AudioInputError("invalid_duration", "Audio must be between 2 and 30 seconds.")


def _invalid_wav() -> AudioInputError:
    return AudioInputError("invalid_wav", "WAV container or PCM payload is malformed.")


def decode_wav(data: bytes) -> WavAudio:
    """Decode one complete mono PCM16 RIFF/WAVE file, retaining its raw hash."""
    if not isinstance(data, bytes):
        raise _invalid_wav()
    if len(data) > MAX_FILE_BYTES:
        raise AudioInputError("file_too_large", "Audio file exceeds the 10 MB input limit.")
    if len(data) < 12 or data[:4] != b"RIFF" or data[8:12] != b"WAVE":
        raise _invalid_wav()
    if struct.unpack_from("<I", data, 4)[0] != len(data) - 8:
        raise _invalid_wav()

    fmt: bytes | None = None
    pcm: bytes | None = None
    offset = 12
    while offset < len(data):
        if len(data) - offset < 8:
            raise _invalid_wav()
        chunk_id = data[offset : offset + 4]
        chunk_size = struct.unpack_from("<I", data, offset + 4)[0]
        start = offset + 8
        end = start + chunk_size
        padded_end = end + (chunk_size & 1)
        if padded_end > len(data):
            raise _invalid_wav()
        if chunk_id == b"fmt ":
            if fmt is not None:
                raise _invalid_wav()
            fmt = data[start:end]
        elif chunk_id == b"data":
            if pcm is not None:
                raise _invalid_wav()
            pcm = data[start:end]
        offset = padded_end

    if fmt is None or pcm is None or len(fmt) < 16:
        raise _invalid_wav()
    format_code, channels, rate, byte_rate, block_align, bits = struct.unpack_from(
        "<HHIIHH", fmt
    )
    if format_code != 1 or bits != 16:
        raise AudioInputError("unsupported_encoding", "Only uncompressed PCM16 WAV is supported.")
    if channels != 1:
        raise AudioInputError("unsupported_channels", "Only mono WAV is supported.")
    _validate_rate(rate)
    # PCM fmt chunks commonly contain either 16 bytes or an empty cbSize field.
    if len(fmt) != 16:
        if len(fmt) != 18 or struct.unpack_from("<H", fmt, 16)[0] != 0:
            raise _invalid_wav()
    if block_align != 2 or byte_rate != rate * 2 or len(pcm) % 2:
        raise _invalid_wav()
    _validate_duration(len(pcm) // 2, rate)

    decoded = np.frombuffer(pcm, dtype="<i2").astype(np.float64) / 32768.0
    return WavAudio(samples=decoded, sample_rate_hz=rate, sha256=hashlib.sha256(data).hexdigest())


def read_wav(path: str | Path) -> WavAudio:
    """Read bounded bytes; filesystem failures never disclose the input path."""
    try:
        with Path(path).open("rb") as audio_file:
            data = audio_file.read(MAX_FILE_BYTES + 1)
    except (OSError, ValueError, TypeError):
        raise AudioInputError("file_read_error", "Audio file could not be read.") from None
    return decode_wav(data)


def encode_wav(samples: np.ndarray, sample_rate_hz: int) -> bytes:
    """Encode normalized samples without gain changes or out-of-range clipping.

    PCM quantization is nearest integer after scaling by 32768. Positive +1.0
    is represented by the largest PCM16 integer, 32767; negative -1.0 by -32768.
    Re-encoding decoded PCM16 samples therefore preserves the PCM payload.
    """
    _validate_rate(sample_rate_hz)
    try:
        raw = np.asarray(samples)
        if np.iscomplexobj(raw):
            raise AudioInputError("invalid_samples", "Samples must be a finite normalized mono array.")
        values = np.asarray(raw, dtype=np.float64)
    except (TypeError, ValueError, OverflowError):
        raise AudioInputError("invalid_samples", "Samples must be a finite normalized mono array.") from None
    if values.ndim != 1 or not np.all(np.isfinite(values)):
        raise AudioInputError("invalid_samples", "Samples must be a finite normalized mono array.")
    if np.any(values < -1.0) or np.any(values > 1.0):
        raise AudioInputError("invalid_samples", "Samples outside [-1, 1] are not clipped automatically.")
    rate = int(sample_rate_hz)
    _validate_duration(values.size, rate)
    pcm_values = np.minimum(np.rint(values * 32768.0), 32767).astype("<i2")
    pcm = pcm_values.tobytes()
    size = 44 + len(pcm)
    if size > MAX_FILE_BYTES:
        raise AudioInputError("file_too_large", "Audio file exceeds the 10 MB input limit.")
    return (
        b"RIFF"
        + struct.pack("<I", size - 8)
        + b"WAVEfmt "
        + struct.pack("<IHHIIHH", 16, 1, 1, rate, rate * 2, 2, 16)
        + b"data"
        + struct.pack("<I", len(pcm))
        + pcm
    )
