"""Strict inert contract for independent native-rate measurements.

Consistency of saved JSON is not proof of execution, audio quality, perceptual
equivalence, or fault provenance. No referenced audio or artifact is opened.
"""

from __future__ import annotations

import json
import math
from pathlib import Path

from .result_contract import (
    MAX_RESULT_BYTES, ResultContractError, _fields, _integer, _invalid_constant,
    _json_tree, _metadata, _number, _reject, _unique_object,
)


ENGINE = "native_fullband_measurements_v1"
MAX_FULLBAND_RESULT_BYTES = MAX_RESULT_BYTES
BAND_EDGES_HZ = (0, 250, 500, 1000, 2000, 4000, 8000, 16000, 24000)
FRAME_DURATION_MS = 100
_TOP_FIELDS = {
    "schema_version", "engine", "status", "reason_code", "reference", "processed",
    "reference_measurements", "processed_measurements", "comparison", "configuration",
    "summary", "artifacts", "complete_audio_approval", "commercial_performance_validated",
    "network_used", "fault_provenance_confirmed",
}
_AUDIO_FIELDS = {
    "dc_offset", "mean_square", "rms_dbfs", "peak_dbfs", "crest_factor",
    "rail_sample_count", "rail_sample_fraction", "longest_same_rail_run_samples",
    "bands", "frame_size_samples", "frames",
}
_BAND_FIELDS = {
    "lower_hz", "upper_hz", "effective_upper_hz", "upper_inclusive", "status",
    "mean_square", "power_fraction",
}
_PAIR_FIELDS = {
    "status", "reason_code", "unequal_sample_count", "first_changed_sample",
    "last_changed_sample", "maximum_abs_error_pcm16", "mean_square_error",
    "signal_to_residual_db", "signal_to_residual_status", "correlation",
    "correlation_status", "residual_bands", "changed_frames",
}
_PAIR_NULL_FIELDS = {
    "unequal_sample_count", "first_changed_sample", "last_changed_sample",
    "maximum_abs_error_pcm16", "mean_square_error", "signal_to_residual_db",
    "correlation", "residual_bands", "changed_frames",
}
CONFIGURATION = {
    "frame_duration_ms": 100,
    "band_edges_hz": list(BAND_EDGES_HZ),
    "spectrum": "full_record_rectangular_rfft_parseval",
    "auto_alignment": False,
    "resampling": False,
    "gain_compensation": False,
}


def _same_json(first: object, second: object) -> bool:
    if type(first) is not type(second):
        return False
    if type(first) is dict:
        return first.keys() == second.keys() and all(
            _same_json(first[key], second[key]) for key in second
        )
    if type(first) is list:
        return len(first) == len(second) and all(
            _same_json(left, right) for left, right in zip(first, second)
        )
    return first == second


def _close(first: float, second: float, *, absolute: float = 1e-18) -> bool:
    return math.isclose(first, second, rel_tol=1e-9, abs_tol=absolute)


def _bound_int(value: object, maximum: int, code: str, minimum: int = 0) -> int:
    number = _integer(value, code, minimum)
    if number > maximum:
        _reject(code)
    return number


def _db(value: object, linear: float, code: str) -> None:
    if linear == 0:
        if value is not None:
            _reject(code)
    else:
        metric = _number(value, code)
        if not _close(metric, 20 * math.log10(linear), absolute=1e-8):
            _reject(code)


def _bands(value: object, rate: int, mean_square: float, maximum: float) -> None:
    if type(value) is not list or len(value) != 8:
        _reject("invalid_fullband_bands")
    total_power = 0.0
    total_fraction = 0.0
    nyquist = rate / 2
    for index, item in enumerate(value):
        band = _fields(item, _BAND_FIELDS, code="invalid_fullband_band")
        lower, upper = BAND_EDGES_HZ[index:index + 2]
        if (type(band["lower_hz"]) is not int or band["lower_hz"] != lower
                or type(band["upper_hz"]) is not int or band["upper_hz"] != upper):
            _reject("invalid_fullband_band_edges")
        if lower >= nyquist:
            if (type(band["status"]) is not str or band["status"] != "not_available"
                    or band["effective_upper_hz"] is not None
                    or band["upper_inclusive"] is not False
                    or band["mean_square"] is not None or band["power_fraction"] is not None):
                _reject("inconsistent_unavailable_fullband_band")
            continue
        effective = min(upper, nyquist)
        if (type(band["status"]) is not str or band["status"] != "available"
                or _number(band["effective_upper_hz"], "invalid_fullband_effective_edge") != effective
                or band["upper_inclusive"] is not (effective == nyquist)):
            _reject("inconsistent_available_fullband_band")
        power = _number(band["mean_square"], "invalid_fullband_band_power", 0, maximum)
        fraction = _number(band["power_fraction"], "invalid_fullband_band_fraction", 0, 1)
        if mean_square == 0:
            if power != 0 or fraction != 0:
                _reject("inconsistent_zero_fullband_bands")
        elif not _close(fraction, power / mean_square):
            _reject("inconsistent_fullband_band_fraction")
        total_power += power
        total_fraction += fraction
    if not _close(total_power, mean_square):
        _reject("inconsistent_fullband_parseval")
    if not _close(total_fraction, 0 if mean_square == 0 else 1):
        _reject("inconsistent_fullband_fraction_sum")


def _audio_measurements(value: object, metadata: dict) -> dict:
    audio = _fields(value, _AUDIO_FIELDS, code="invalid_fullband_audio_measurements")
    count, rate = metadata["sample_count"], metadata["sample_rate_hz"]
    rms, peak = metadata["rms"], metadata["peak"]
    mean_square = _number(audio["mean_square"], "invalid_fullband_mean_square", 0, 1)
    dc = _number(audio["dc_offset"], "invalid_fullband_dc_offset", -1, 32767 / 32768)
    if (not _close(mean_square, rms * rms)
            or dc * dc > mean_square + 1e-15 or abs(dc) > peak + 1e-15
            or bool(mean_square) != bool(peak)
            or mean_square + 1e-18 < peak * peak / count):
        _reject("inconsistent_fullband_audio_moments")
    _db(audio["rms_dbfs"], rms, "inconsistent_fullband_rms_dbfs")
    _db(audio["peak_dbfs"], peak, "inconsistent_fullband_peak_dbfs")
    if rms == 0:
        if audio["crest_factor"] is not None or dc != 0:
            _reject("inconsistent_fullband_zero_signal")
    elif not _close(_number(audio["crest_factor"], "invalid_fullband_crest_factor", 1), peak / rms):
        _reject("inconsistent_fullband_crest_factor")
    rail_count = _bound_int(audio["rail_sample_count"], count, "invalid_fullband_rail_count")
    fraction = _number(audio["rail_sample_fraction"], "invalid_fullband_rail_fraction", 0, 1)
    longest = _bound_int(audio["longest_same_rail_run_samples"], rail_count,
                         "invalid_fullband_rail_run")
    if not _close(fraction, rail_count / count) or bool(longest) != bool(rail_count):
        _reject("inconsistent_fullband_rail_measurements")
    if rail_count and (peak < 32767 / 32768
                       or mean_square + 1e-15 < rail_count / count * (32767 / 32768) ** 2):
        _reject("inconsistent_fullband_rail_energy")
    if peak == 1 and rail_count == 0:
        _reject("inconsistent_fullband_rail_energy")
    _bands(audio["bands"], rate, mean_square, 1)
    frame_size = rate * FRAME_DURATION_MS // 1000
    if type(audio["frame_size_samples"]) is not int or audio["frame_size_samples"] != frame_size:
        _reject("invalid_fullband_frame_size")
    frames = audio["frames"]
    if type(frames) is not list or len(frames) != math.ceil(count / frame_size):
        _reject("invalid_fullband_frame_count")
    weighted_square, maximum_peak = 0.0, 0.0
    for index, item in enumerate(frames):
        frame = _fields(item, {"start_sample", "end_sample", "mean_square", "peak"},
                        code="invalid_fullband_frame")
        start, end = index * frame_size, min((index + 1) * frame_size, count)
        if (type(frame["start_sample"]) is not int or frame["start_sample"] != start
                or type(frame["end_sample"]) is not int or frame["end_sample"] != end):
            _reject("inconsistent_fullband_frame_geometry")
        power = _number(frame["mean_square"], "invalid_fullband_frame_power", 0, 1)
        frame_peak = _number(frame["peak"], "invalid_fullband_frame_peak", 0, 1)
        if (power > frame_peak * frame_peak + 1e-15
                or bool(power) != bool(frame_peak)
                or power + 1e-18 < frame_peak * frame_peak / (end - start)):
            _reject("inconsistent_fullband_frame_energy")
        weighted_square += power * ((end - start) / count)
        maximum_peak = max(maximum_peak, frame_peak)
    if not _close(weighted_square, mean_square) or not _close(maximum_peak, peak):
        _reject("inconsistent_fullband_frame_summary")
    return audio


def _pair_measurements(value: object, reference: dict, processed: dict,
                       reference_metrics: dict, processed_metrics: dict) -> dict:
    pair = _fields(value, _PAIR_FIELDS, code="invalid_fullband_comparison")
    rate, count = reference["sample_rate_hz"], reference["sample_count"]
    if reference["sha256"] == processed["sha256"] and reference != processed:
        _reject("inconsistent_fullband_hash_comparison")
    mismatch = ("sample_rate_mismatch" if rate != processed["sample_rate_hz"] else
                "sample_count_mismatch" if count != processed["sample_count"] else None)
    if mismatch:
        if (type(pair["status"]) is not str or pair["status"] != "withheld"
                or type(pair["reason_code"]) is not str or pair["reason_code"] != mismatch
                or any(pair[name] is not None for name in _PAIR_NULL_FIELDS)
                or type(pair["signal_to_residual_status"]) is not str
                or pair["signal_to_residual_status"] != "not_comparable"
                or type(pair["correlation_status"]) is not str
                or pair["correlation_status"] != "not_comparable"):
            _reject("inconsistent_fullband_withheld_comparison")
        return pair
    if type(pair["status"]) is not str or pair["status"] != "measured" or pair["reason_code"] is not None:
        _reject("inconsistent_fullband_measured_comparison")
    unequal = _bound_int(pair["unequal_sample_count"], count, "invalid_fullband_unequal_count")
    maximum = _bound_int(pair["maximum_abs_error_pcm16"], 65535, "invalid_fullband_maximum_error")
    mse = _number(pair["mean_square_error"], "invalid_fullband_residual_energy", 0, 4)
    if bool(unequal) != bool(maximum) or bool(unequal) != bool(mse):
        _reject("inconsistent_fullband_residual_zero")
    first, last = pair["first_changed_sample"], pair["last_changed_sample"]
    if unequal == 0:
        if first is not None or last is not None:
            _reject("inconsistent_fullband_no_changes")
        if any(reference[key] != processed[key] for key in ("rms", "peak")):
            _reject("inconsistent_fullband_identical_metadata")
        if reference_metrics["dc_offset"] != processed_metrics["dc_offset"]:
            _reject("inconsistent_fullband_identical_moments")
        if not _same_json(reference_metrics, processed_metrics):
            _reject("inconsistent_fullband_identical_measurements")
    else:
        first = _bound_int(first, count - 1, "invalid_fullband_first_changed_sample")
        last = _bound_int(last, count - 1, "invalid_fullband_last_changed_sample")
        if first > last or unequal > last - first + 1 or (unequal == 1 and first != last):
            _reject("inconsistent_fullband_changed_interval")
        unit = 1 / (32768 * 32768 * count)
        if (mse + 1e-18 < max(unequal, maximum * maximum) * unit
                or mse > unequal * maximum * maximum * unit + 1e-18):
            _reject("inconsistent_fullband_residual_energy_bounds")
    _bands(pair["residual_bands"], rate, mse, 4)
    sr_status = "zero_residual" if mse == 0 else (
        "zero_reference" if reference_metrics["mean_square"] == 0 else "finite")
    if type(pair["signal_to_residual_status"]) is not str or pair["signal_to_residual_status"] != sr_status:
        _reject("inconsistent_fullband_signal_residual_status")
    if sr_status == "finite":
        sr = _number(pair["signal_to_residual_db"], "invalid_fullband_signal_residual_db")
        expected = 10 * math.log10(reference_metrics["mean_square"] / mse)
        if not _close(sr, expected, absolute=1e-8):
            _reject("inconsistent_fullband_signal_residual_db")
    elif pair["signal_to_residual_db"] is not None:
        _reject("inconsistent_fullband_undefined_signal_residual_db")
    if type(pair["correlation_status"]) is not str or pair["correlation_status"] not in {"defined", "constant_signal"}:
        _reject("invalid_fullband_correlation_status")
    # Stable exact constants can be established from PCM metadata; generic
    # near-constant moments are not reconstructed by cancellation-prone algebra.
    definitely_constant = any(
        metrics["mean_square"] == 0 or (abs(metrics["dc_offset"]) == meta["peak"]
                                        and meta["rms"] == meta["peak"])
        for meta, metrics in ((reference, reference_metrics), (processed, processed_metrics))
    )
    if pair["correlation_status"] == "constant_signal":
        if pair["correlation"] is not None or not definitely_constant:
            _reject("inconsistent_fullband_constant_correlation")
    else:
        correlation = _number(pair["correlation"], "invalid_fullband_correlation", -1, 1)
        if definitely_constant or (unequal == 0 and not _close(correlation, 1)):
            _reject("inconsistent_fullband_correlation")
    if definitely_constant and pair["correlation_status"] != "constant_signal":
        _reject("inconsistent_fullband_constant_correlation")
    if unequal == 0 and not definitely_constant and pair["correlation_status"] != "defined":
        _reject("inconsistent_fullband_identical_correlation")
    changed = pair["changed_frames"]
    if type(changed) is not list or len(changed) > math.ceil(count / (rate // 10)):
        _reject("invalid_fullband_changed_frames")
    frame_size, total_changed, previous_start = rate // 10, 0, -1
    for item in changed:
        frame = _fields(item, {"start_sample", "end_sample", "unequal_sample_count"},
                        code="invalid_fullband_changed_frame")
        start = _bound_int(frame["start_sample"], count - 1, "invalid_fullband_changed_frame_start")
        end = _bound_int(frame["end_sample"], count, "invalid_fullband_changed_frame_end", 1)
        if start % frame_size or start <= previous_start or end != min(start + frame_size, count):
            _reject("inconsistent_fullband_changed_frame_geometry")
        changed_count = _bound_int(frame["unequal_sample_count"], end - start,
                                   "invalid_fullband_changed_frame_count", 1)
        if unequal and changed_count > min(end, last + 1) - max(start, first):
            _reject("inconsistent_fullband_changed_frame_bounds")
        total_changed += changed_count
        previous_start = start
    if total_changed != unequal or bool(changed) != bool(unequal):
        _reject("inconsistent_fullband_changed_frame_summary")
    if unequal and (not changed[0]["start_sample"] <= first < changed[0]["end_sample"]
                    or not changed[-1]["start_sample"] <= last < changed[-1]["end_sample"]):
        _reject("inconsistent_fullband_changed_frame_bounds")
    if reference["sha256"] == processed["sha256"] and (reference != processed or unequal != 0):
        _reject("inconsistent_fullband_hash_comparison")
    return pair


def derive_fullband_summary(comparison: dict) -> dict:
    """Derive measurement completion only; no quality or approval verdict."""
    if (type(comparison) is not dict or type(comparison.get("status")) is not str
            or comparison["status"] not in {"measured", "withheld"}):
        _reject("invalid_fullband_summary_inputs")
    measured = comparison["status"] == "measured"
    return {"exit_code": 0 if measured else 2,
            "meaning": "measurement_completed_no_quality_verdict" if measured else "native_pair_comparison_withheld",
            "quality_verdict": "not_assessed"}


def validate_fullband_result(value: object) -> dict:
    """Validate bounded JSON and return its original object, opening no audio."""
    if type(value) is not dict:
        _reject("invalid_fullband_result_type")
    _json_tree(value)
    result = _fields(value, _TOP_FIELDS, code="invalid_fullband_result_structure")
    if type(result["schema_version"]) is not int or result["schema_version"] != 1:
        _reject("unsupported_schema_version")
    if type(result["engine"]) is not str or result["engine"] != ENGINE:
        _reject("unsupported_fullband_engine")
    for name in ("complete_audio_approval", "commercial_performance_validated", "network_used", "fault_provenance_confirmed"):
        if result[name] is not False:
            _reject("invalid_approval_claim")
    reference, processed = (_metadata(result[name]) for name in ("reference", "processed"))
    reference_metrics = _audio_measurements(result["reference_measurements"], reference)
    processed_metrics = _audio_measurements(result["processed_measurements"], processed)
    pair = _pair_measurements(result["comparison"], reference, processed, reference_metrics, processed_metrics)
    expected_status = "measured" if pair["status"] == "measured" else "comparison_withheld"
    if (type(result["status"]) is not str or result["status"] != expected_status
            or not _same_json(result["reason_code"], pair["reason_code"])):
        _reject("inconsistent_fullband_result_status")
    if not _same_json(result["configuration"], CONFIGURATION):
        _reject("invalid_fullband_configuration")
    if not _same_json(result["summary"], derive_fullband_summary(pair)):
        _reject("inconsistent_fullband_summary")
    if not _same_json(result["artifacts"], {"reference": "input/reference.wav", "processed": "input/processed.wav"}):
        _reject("invalid_fullband_artifact_paths")
    return result


def load_fullband_result(path: str | Path) -> dict:
    """Read at most one MiB of strict UTF-8 JSON, following no stored paths."""
    try:
        with Path(path).open("rb") as stream:
            data = stream.read(MAX_FULLBAND_RESULT_BYTES + 1)
    except (OSError, ValueError, TypeError):
        raise ResultContractError("result_file_read_error") from None
    if len(data) > MAX_FULLBAND_RESULT_BYTES:
        _reject("result_file_too_large")
    try:
        value = json.loads(data.decode("utf-8"), object_pairs_hook=_unique_object,
                           parse_constant=_invalid_constant)
    except ResultContractError:
        raise
    except (UnicodeError, ValueError, RecursionError, OverflowError):
        raise ResultContractError("invalid_result_json") from None
    return validate_fullband_result(value)
