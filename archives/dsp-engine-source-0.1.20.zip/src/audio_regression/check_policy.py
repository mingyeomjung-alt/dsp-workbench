"""Fail-closed automation policy for narrow temporal diagnostics only.

An empty basic-profile candidate list may clear this supported temporal check.
It never approves complete audio, validates commercial performance, or states
probabilities. Telephone remains experimental after its M3 target miss.
"""

from __future__ import annotations

from .result_contract import ResultContractError, validate_analysis_result


def _summary(gate_state: str, reason_code: str, result: dict | None) -> dict:
    return {
        "schema_version": 1,
        "policy": "safe_automated_temporal_check_v1",
        "gate_state": gate_state,
        "exit_code": {"clear_supported_temporal_check": 0, "review_required": 1, "blocked": 2}[gate_state],
        "reason_code": reason_code,
        "contract_valid": result is not None,
        "source_status": result["status"] if result is not None else None,
        "profile": result.get("configuration", {}).get("profile") if result is not None else None,
        "content_preservation_status": result.get("content_preservation_status") if result is not None else None,
        "event_count": len(result["events"]) if result is not None and type(result.get("events")) is list else None,
        "scope": "supported_temporal_candidates_only",
        "complete_audio_approval": False,
        "commercial_performance_validated": False,
        "probability_claims": False,
    }


def blocked_contract_error(code: str) -> dict:
    """Create the same complete blocked summary for a strict JSON load failure."""
    return _summary("blocked", code, None)


def check_result(result: object) -> dict:
    """Apply the policy to a result; malformed/held/error results cannot clear."""
    try:
        valid = validate_analysis_result(result)
    except ResultContractError as exc:
        return blocked_contract_error(exc.code)
    if valid.get("configuration", {}).get("profile") == "telephone":
        return _summary("blocked", "telephone_profile_experimental_m3_target_miss", valid)
    if valid["status"] == "withheld":
        return _summary("blocked", "analysis_withheld", valid)
    if valid["status"] == "error":
        return _summary("blocked", "analysis_error", valid)
    if valid["events"]:
        return _summary("review_required", "supported_temporal_defect_candidates", valid)
    return _summary("clear_supported_temporal_check", "no_supported_temporal_defect_candidates", valid)
