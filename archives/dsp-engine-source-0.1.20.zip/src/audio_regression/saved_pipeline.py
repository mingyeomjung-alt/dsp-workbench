"""Audit saved, caller-ordered DSP outputs without executing their processors.

All named WAV files are bounded and decoded before a fresh output directory is
created. Only private byte-identical snapshots and explicit comparison settings
reach the selected pair analyzer. Version 2 additionally selects each stage
and end comparison independently; caller ordering is never provenance.
"""

from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import time
import unicodedata

from . import api
from .artifact_integrity import ArtifactVerificationError, _read_regular
from .audio import AudioInputError, MAX_FILE_BYTES, decode_wav
from .check_policy import check_result
from .result_contract import ResultContractError, validate_analysis_result


MAX_MANIFEST_BYTES = 262_144
ENGINE = "audio_saved_pipeline_audit_v1"
_SAFE_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}\Z")
_GATES = {"clear_supported_temporal_check": 0, "review_required": 1, "blocked": 2}
_RESERVED = re.compile(r"(?:con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\..*)?\Z", re.I)


class SavedPipelineError(ValueError):
    """Stable rejection codes never include input paths or exception text."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__("Saved audio pipeline could not complete: " + code + ".")


def _safe_code(exc: Exception, fallback: str) -> str:
    if isinstance(exc, (AudioInputError, ResultContractError, SavedPipelineError)):
        code = getattr(exc, "code", None)
        if type(code) is str and _SAFE_CODE.fullmatch(code):
            return code
    return fallback


def _plain_text(value: object) -> bool:
    return (type(value) is str and bool(value.strip())
            and not any(unicodedata.category(c) in {"Cc", "Cf", "Cs"} for c in value))


def _relative_wav(value: object) -> str:
    if (not _plain_text(value) or "\\" in value or value.startswith("/")
            or any(c in value for c in ':*?<>|') or not value.lower().endswith(".wav")):
        raise SavedPipelineError("invalid_manifest_path")
    parts = value.split("/")
    if any(not p or p in {".", ".."} or p.endswith((".", " ")) or _RESERVED.fullmatch(p)
           for p in parts):
        raise SavedPipelineError("invalid_manifest_path")
    return value


def _normalize_manifest(value: object) -> dict:
    if type(value) is dict and type(value.get("schema_version")) is int and value["schema_version"] == 2:
        return _normalize_mixed_manifest(value)
    if (type(value) is not dict or set(value) != {"schema_version", "source", "stages"}
            or type(value["schema_version"]) is not int or value["schema_version"] != 1
            or type(value["stages"]) is not list or not 1 <= len(value["stages"]) <= 8):
        raise SavedPipelineError("invalid_saved_manifest")
    source = _relative_wav(value["source"])
    stages = []
    for item in value["stages"]:
        if (type(item) is not dict or set(item) != {"label", "output", "declaration"}
                or not _plain_text(item["label"]) or not 1 <= len(item["label"]) <= 80):
            raise SavedPipelineError("invalid_saved_stage")
        declaration = item["declaration"]
        if (type(declaration) is not dict or set(declaration) != {"allow_gain", "allow_resampling"}
                or any(type(declaration[k]) is not bool for k in declaration)):
            raise SavedPipelineError("invalid_saved_declaration")
        stages.append({"label": item["label"], "output": _relative_wav(item["output"]),
                       "declaration": dict(declaration)})
    return {"schema_version": 1, "source": source, "stages": stages}


def _mixed_selection(value: object) -> dict:
    """An explicit comparison choice, never inferred from rates or stage names."""
    if type(value) is not dict or set(value) != {"engine", "declaration"}:
        raise SavedPipelineError("invalid_mixed_selection")
    engine, declaration = value["engine"], value["declaration"]
    if type(engine) is not str or engine not in {"v" + str(i) for i in range(1, 13)}:
        raise SavedPipelineError("invalid_engine")
    expected = {"allow_gain", "allow_resampling"}
    if engine == "v12":
        expected.add("resampling_model")
    if (type(declaration) is not dict or set(declaration) != expected
            or any(type(declaration[key]) is not bool for key in ("allow_gain", "allow_resampling"))):
        raise SavedPipelineError("invalid_saved_declaration")
    if engine == "v12":
        from .resampler_engine import MODEL
        if (declaration["allow_gain"] is not False or declaration["allow_resampling"] is not True
                or type(declaration["resampling_model"]) is not str
                or declaration["resampling_model"] != MODEL):
            raise SavedPipelineError("invalid_resampling_model_declaration")
    return {"engine": engine, "declaration": dict(declaration)}


def _normalize_mixed_manifest(value: dict) -> dict:
    if (set(value) != {"schema_version", "source", "stages", "end_to_end"}
            or type(value["stages"]) is not list or not 1 <= len(value["stages"]) <= 8):
        raise SavedPipelineError("invalid_saved_manifest")
    source, stages = _relative_wav(value["source"]), []
    for item in value["stages"]:
        if (type(item) is not dict or set(item) != {"label", "output", "engine", "declaration"}
                or not _plain_text(item["label"]) or not 1 <= len(item["label"]) <= 80):
            raise SavedPipelineError("invalid_saved_stage")
        selection = _mixed_selection({key: item[key] for key in ("engine", "declaration")})
        stages.append({"label": item["label"], "output": _relative_wav(item["output"]), **selection})
    return {"schema_version": 2, "source": source, "stages": stages,
            "end_to_end": _mixed_selection(value["end_to_end"])}


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    value = {}
    for key, item in pairs:
        if key in value:
            raise SavedPipelineError("duplicate_json_key")
        value[key] = item
    return value


def _invalid_constant(_: str) -> None:
    raise SavedPipelineError("non_finite_metric")


def _absolute_path(value: str | Path) -> Path:
    try:
        return Path(os.path.abspath(os.fspath(value)))
    except (OSError, TypeError, ValueError):
        raise SavedPipelineError("invalid_pipeline_path") from None


def _is_link(info: os.stat_result) -> bool:
    return (stat.S_ISLNK(info.st_mode)
            or bool(getattr(info, "st_file_attributes", 0)
                    & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)))


def _normal_parents(path: Path, *, output: bool = False) -> None:
    for parent in reversed(path.parents):
        try:
            info = parent.lstat()
        except FileNotFoundError:
            if output:
                continue
            raise SavedPipelineError("input_file_read_error") from None
        except OSError:
            raise SavedPipelineError("invalid_output_path" if output else "input_file_read_error") from None
        if _is_link(info):
            raise SavedPipelineError("unsafe_output_parent" if output else "unsafe_input_path")
        if not stat.S_ISDIR(info.st_mode):
            raise SavedPipelineError("invalid_output_path" if output else "input_file_read_error")


def _guarded_bytes(path: Path, limit: int) -> bytes:
    """Read once through a bounded descriptor, rejecting observable path links."""
    _normal_parents(path)
    descriptor = None
    try:
        named = path.lstat()
        if _is_link(named):
            raise SavedPipelineError("unsafe_input_path")
        if not stat.S_ISREG(named.st_mode):
            raise SavedPipelineError("input_file_read_error")
        flags = (os.O_RDONLY | getattr(os, "O_BINARY", 0) | getattr(os, "O_NOFOLLOW", 0)
                 | getattr(os, "O_NONBLOCK", 0))
        descriptor = os.open(path, flags)
        opened = os.fstat(descriptor)
        if (_is_link(opened) or not stat.S_ISREG(opened.st_mode)
                or (named.st_dev, named.st_ino) != (opened.st_dev, opened.st_ino)):
            raise SavedPipelineError("unsafe_input_path")
        with os.fdopen(descriptor, "rb") as stream:
            descriptor = None
            raw = stream.read(limit + 1)
        after = path.lstat()
        if (_is_link(after) or not stat.S_ISREG(after.st_mode)
                or (opened.st_dev, opened.st_ino) != (after.st_dev, after.st_ino)):
            raise SavedPipelineError("unsafe_input_path")
        return raw
    except SavedPipelineError:
        raise
    except (OSError, ValueError, TypeError):
        raise SavedPipelineError("input_file_read_error") from None
    finally:
        if descriptor is not None:
            os.close(descriptor)


def load_saved_manifest(path: str | Path) -> dict:
    """Load a strict bounded UTF-8 manifest; named audio is not opened yet."""
    try:
        raw = _guarded_bytes(_absolute_path(path), MAX_MANIFEST_BYTES)
    except SavedPipelineError as exc:
        if exc.code == "input_file_read_error":
            raise SavedPipelineError("manifest_file_read_error") from None
        raise
    if len(raw) > MAX_MANIFEST_BYTES:
        raise SavedPipelineError("manifest_file_too_large")
    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object,
                           parse_constant=_invalid_constant)
    except SavedPipelineError:
        raise
    except (UnicodeError, ValueError, RecursionError, OverflowError):
        raise SavedPipelineError("invalid_manifest_json") from None
    return _normalize_manifest(value)


def _preflight(manifest_path: str | Path, output_dir: str | Path):
    manifest_path, output = _absolute_path(manifest_path), _absolute_path(output_dir)
    manifest = load_saved_manifest(manifest_path)
    paths = [manifest_path.parent / manifest["source"]]
    paths.extend(manifest_path.parent / stage["output"] for stage in manifest["stages"])
    # Literal validated segments stay beneath the manifest parent without native
    # strict realpath, which may require unavailable Windows handle privileges.
    if output in paths or output == manifest_path:
        raise SavedPipelineError("input_output_alias")
    if os.path.lexists(output):
        for source in paths:
            try:
                if os.path.samefile(source, output):
                    raise SavedPipelineError("input_output_alias")
            except OSError:
                pass
        raise SavedPipelineError("output_directory_exists")
    _normal_parents(output, output=True)
    raws, metadata = [], []
    for path in paths:
        raw = _guarded_bytes(path, MAX_FILE_BYTES)
        try:
            audio = decode_wav(raw)
        except AudioInputError as exc:
            raise SavedPipelineError(_safe_code(exc, "invalid_wav")) from None
        raws.append(raw)
        metadata.append(audio.metadata())
    return output, manifest, paths, raws, metadata


def _new_bytes(path: Path, raw: bytes) -> None:
    _normal_parents(path, output=True)
    try:
        with path.open("xb") as stream:
            stream.write(raw)
    except (OSError, ValueError, TypeError):
        raise SavedPipelineError("output_write_error") from None


def _new_json(path: Path, value: dict) -> None:
    try:
        raw = (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")
    except (TypeError, ValueError, OverflowError, RecursionError):
        raise SavedPipelineError("invalid_saved_result") from None
    _new_bytes(path, raw)


def _new_folder(path: Path) -> None:
    _normal_parents(path, output=True)
    try:
        path.mkdir(exist_ok=False)
    except (OSError, ValueError):
        raise SavedPipelineError("output_write_error") from None


def _declaration(value: dict) -> dict:
    result = {"profile": "basic", "allow_gain": value["allow_gain"],
              "allow_resampling": value["allow_resampling"], "max_delay_ms": 1000.0}
    if "resampling_model" in value:
        result["resampling_model"] = value["resampling_model"]
    return result


def _analysis(reference: Path, processed: Path, declaration: dict,
              input_metadata: dict, output_metadata: dict, *, engine: str = "v1",
              trace_path: Path | None = None) -> tuple[dict, dict]:
    if engine == "v1":
        raw_analysis = api.analyze_pair(reference, processed, **declaration)
    else:
        raw_analysis, trace = api.analyze_pair_with_trace(reference, processed, **declaration, engine=engine)
        if trace_path is not None:
            _new_json(trace_path, trace)
    analysis = validate_analysis_result(raw_analysis)
    if analysis["status"] != "error" and analysis["engine"] != "local_content_alignment_" + engine:
        raise SavedPipelineError("inconsistent_analysis_engine")
    if analysis["status"] != "error":
        if (analysis["reference"] != input_metadata or analysis["processed"] != output_metadata
                or analysis["configuration"] != declaration):
            raise SavedPipelineError("inconsistent_pair_analysis")
    return analysis, check_result(analysis)


def _error(code: str) -> dict:
    return {"schema_version": 1, "status": "error", "reason_code": code}


def _save_error(output: Path, folder: str, record: dict, code: str) -> None:
    analysis = _error(code)
    record.update(status="error", analysis=analysis, check=check_result(analysis),
                  analysis_artifact=None, check_artifact=None)
    if "reason_code" in record:
        record["reason_code"] = code
    for field, name, value in (("analysis_artifact", "error.json", analysis),
                               ("check_artifact", "error_check.json", record["check"])):
        try:
            relative = folder + "/" + name
            _new_json(output / relative, value)
            record[field] = relative
        except SavedPipelineError:
            pass  # Retain started manifest, snapshots, and earlier artifacts.


def _save_analysis(output: Path, folder: str, record: dict, analysis: dict, check: dict) -> None:
    record.update(status=analysis["status"], analysis=analysis, check=check)
    if "reason_code" in record:
        record["reason_code"] = analysis["reason_code"]
    if analysis["status"] == "error":
        _save_error(output, folder, record, analysis["reason_code"])
        return
    for field, name, value in (("analysis_artifact", "analysis.json", analysis),
                               ("check_artifact", "check.json", check)):
        relative = folder + "/" + name
        _new_json(output / relative, value)
        record[field] = relative


def _summary(result: dict) -> dict:
    summary = {"gate_state": "clear_supported_temporal_check", "exit_code": 0,
               "first_concern": None, "planned_stage_count": len(result["stages"]),
               "checked_stage_count": 0, "failed_stage": None}
    records = [("stage", stage) for stage in result["stages"]]
    if result["end_to_end"] is not None:
        records.append(("end_to_end", result["end_to_end"]))
    for scope, record in records:
        if scope == "stage":
            if record["status"] != "not_run":
                summary["checked_stage_count"] += 1
            if record["status"] == "error" and summary["failed_stage"] is None:
                summary["failed_stage"] = record["index"]
        check = record["check"]
        if check is None:
            continue
        gate = check["gate_state"]
        if _GATES[gate] > summary["exit_code"]:
            summary.update(gate_state=gate, exit_code=_GATES[gate])
        if gate != "clear_supported_temporal_check" and summary["first_concern"] is None:
            category = ("execution_error" if record["status"] == "error"
                        else "withheld" if record["status"] == "withheld" else "defect_candidates")
            summary["first_concern"] = {"scope": scope,
                "stage_index": record["index"] if scope == "stage" else None,
                "stage_label": record["label"] if scope == "stage" else None,
                "category": category}
    return summary


def _runtime(start: float) -> float:
    elapsed = (time.perf_counter() - start) * 1000.0
    return max(0.0, elapsed) if math.isfinite(elapsed) else 0.0


def _recheck(paths: list[Path], metadata: list[dict], *,
             snapshots: list[Path] | None = None) -> dict:
    changed, unavailable = [], []
    for index, (path, info) in enumerate(zip(paths, metadata)):
        try:
            raw = _guarded_bytes(path, MAX_FILE_BYTES)
            if hashlib.sha256(raw).hexdigest() != info["sha256"]:
                changed.append(index)
        except SavedPipelineError:
            unavailable.append(index)
    # The analyzer reads our captured copies, not the named originals. Check
    # both using the same logical indices; neither copy can hide a changed or
    # unreadable partner. The existing inert reader also rejects observable
    # links, hard links, and identity changes without decoding audio again.
    for index, (path, info) in enumerate(zip(snapshots or [], metadata)):
        try:
            digest, _, _, _ = _read_regular(path, MAX_FILE_BYTES)
            if digest != info["sha256"]:
                changed.append(index)
        except (ArtifactVerificationError, OSError, ValueError, TypeError):
            unavailable.append(index)
    return {"status": "unavailable" if unavailable else "changed" if changed else "unchanged",
            "file_indices": sorted(set(changed + unavailable))}


def audit_saved_pipeline(manifest_path: str | Path, output_dir: str | Path, *, engine: str = "v1") -> dict:
    """Audit bounded saved outputs once, retaining private partial evidence.

No processor is run. Stage errors stop subsequent checks, not snapshot capture.
Withheld checks continue but stay blocked; later clear checks cannot erase them.
"""
    if type(engine) is not str or engine not in {"v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11"}:
        raise SavedPipelineError("invalid_engine")
    output, manifest, paths, raws, metadata = _preflight(manifest_path, output_dir)
    mixed = manifest["schema_version"] == 2
    if mixed and engine != "v1":
        raise SavedPipelineError("mixed_manifest_requires_per_stage_selection")
    result = {"schema_version": 2 if mixed else 1,
              "engine": "audio_saved_pipeline_audit_mixed_v1" if mixed else "audio_saved_pipeline_audit_" + engine,
              "status": "completed",
              "comparison_scope": "adjacent_stage_checks_and_end_to_end",
              "source": deepcopy(metadata[0]), "stages": [], "end_to_end": None,
              "input_recheck": {"status": "unchanged", "file_indices": []}, "summary": None,
              "complete_audio_approval": False, "commercial_performance_validated": False,
              "network_used": False, "fault_provenance_confirmed": False,
              "caller_order_verified": False}
    for index, spec in enumerate(manifest["stages"], 1):
        result["stages"].append({"index": index, "label": spec["label"],
            "declaration": _declaration(spec["declaration"]),
            "input": deepcopy(metadata[index - 1]), "output": deepcopy(metadata[index]),
            "input_snapshot": f"inputs/{index - 1:03d}.wav", "output_snapshot": f"inputs/{index:03d}.wav",
            "status": "not_run", "analysis": None, "check": None,
            "reason_code": "prior_stage_analysis_error", "analysis_artifact": None,
            "check_artifact": None, "runtime_ms": 0.0})
        if mixed:
            result["stages"][-1]["analysis_engine"] = spec["engine"]
    try:
        output.parent.mkdir(parents=True, exist_ok=True)
        _normal_parents(output, output=True)
        output.mkdir(exist_ok=False)
    except SavedPipelineError:
        raise
    except (OSError, ValueError):
        raise SavedPipelineError("output_directory_create_error") from None
    journal = None

    def log(event: str, **fields) -> None:
        if journal is None:
            return
        try:
            journal.write((json.dumps({"event": event, **fields}, ensure_ascii=False,
                                      allow_nan=False) + "\n").encode("utf-8"))
            journal.flush()
        except (OSError, ValueError, TypeError):
            raise SavedPipelineError("output_write_error") from None

    try:
        _new_json(output / "manifest_started.json", {
            "schema_version": result["schema_version"], "engine": result["engine"], "status": "started",
            "started_at_utc": datetime.now(timezone.utc).isoformat(),
            "source": deepcopy(metadata[0]), "source_snapshot": "inputs/000.wav",
            "stages": [{"index": stage["index"], "label": stage["label"],
                         "declaration": deepcopy(stage["declaration"]),
                         "output": deepcopy(stage["output"]), "output_snapshot": stage["output_snapshot"],
                         **({"analysis_engine": stage["analysis_engine"]} if mixed else {})}
                        for stage in result["stages"]],
            **({"end_to_end_selection": deepcopy(manifest["end_to_end"])} if mixed else {}),
            "network_used": False, "caller_order_verified": False})
        _normal_parents(output / "execution.jsonl", output=True)
        try:
            journal = (output / "execution.jsonl").open("xb")
        except OSError:
            raise SavedPipelineError("output_write_error") from None
        log("audit_started", planned_stage_count=len(result["stages"]))
        _new_folder(output / "inputs")
        _new_folder(output / "stages")
        for index, raw in enumerate(raws):
            _new_bytes(output / f"inputs/{index:03d}.wav", raw)
        log("all_inputs_snapshotted", file_count=len(raws))
        stopped = False
        for record in result["stages"]:
            if stopped:
                continue
            index, start, phase = record["index"], time.perf_counter(), "filesystem"
            folder = f"stages/{index:03d}"
            try:
                _new_folder(output / folder)
                log("stage_started", stage_index=index)
                phase = "analysis"
                selected = record.get("analysis_engine", engine)
                analysis, check = _analysis(output / record["input_snapshot"],
                                            output / record["output_snapshot"], record["declaration"],
                                            record["input"], record["output"],
                                            **({"engine": selected, "trace_path": output / folder / "trace.json"} if selected != "v1" else {}))
                phase = "filesystem"
                _save_analysis(output, folder, record, analysis, check)
            except Exception as exc:
                code = _safe_code(exc, "analysis_execution_error" if phase == "analysis" else "output_write_error")
                _save_error(output, folder, record, code)
            record["runtime_ms"] = _runtime(start)
            try:
                log("stage_finished", stage_index=index, status=record["status"],
                    reason_code=record["reason_code"], gate_state=record["check"]["gate_state"])
            except SavedPipelineError:
                _save_error(output, folder, record, "output_write_error")
            if record["status"] == "error":
                stopped = True
                result["status"] = "incomplete"
        if not stopped:
            end = {"status": "error", "analysis": None, "check": None,
                   "analysis_artifact": None, "check_artifact": None}
            result["end_to_end"] = end
            phase = "filesystem"
            try:
                _new_folder(output / "end_to_end")
                combined = {"profile": "basic", "allow_gain": any(s["declaration"]["allow_gain"] for s in result["stages"]),
                            "allow_resampling": any(s["declaration"]["allow_resampling"] for s in result["stages"]),
                            "max_delay_ms": 1000.0}
                selected = engine
                if mixed:
                    selected = manifest["end_to_end"]["engine"]
                    combined = _declaration(manifest["end_to_end"]["declaration"])
                    end.update(analysis_engine=selected, declaration=deepcopy(combined))
                phase = "analysis"
                analysis, check = _analysis(output / "inputs/000.wav",
                    output / f"inputs/{len(raws) - 1:03d}.wav", combined, metadata[0], metadata[-1],
                    **({"engine": selected, "trace_path": output / "end_to_end/trace.json"} if selected != "v1" else {}))
                phase = "filesystem"
                _save_analysis(output, "end_to_end", end, analysis, check)
            except Exception as exc:
                code = _safe_code(exc, "analysis_execution_error" if phase == "analysis" else "output_write_error")
                _save_error(output, "end_to_end", end, code)
            if end["status"] == "error":
                result["status"] = "incomplete"
        result["input_recheck"] = _recheck(paths, metadata, snapshots=[
            output / f"inputs/{index:03d}.wav" for index in range(len(metadata))])
        if result["input_recheck"]["status"] != "unchanged":
            if result["end_to_end"] is None:
                result["end_to_end"] = {"status": "error", "analysis": None, "check": None,
                                         "analysis_artifact": None, "check_artifact": None}
            try:
                if not os.path.lexists(output / "end_to_end"):
                    _new_folder(output / "end_to_end")
            except SavedPipelineError:
                pass
            code = ("input_files_changed" if result["input_recheck"]["status"] == "changed"
                    else "input_files_recheck_failed")
            # Occupied earlier error paths stay intact; null artifact pointers
            # do not misrepresent their older contents as the new recheck error.
            _save_error(output, "end_to_end", result["end_to_end"], code)
            result["status"] = "incomplete"
        if mixed and result["end_to_end"] is not None:
            result["end_to_end"].update(analysis_engine=manifest["end_to_end"]["engine"],
                declaration=_declaration(manifest["end_to_end"]["declaration"]))
        result["summary"] = _summary(result)
        from .saved_pipeline_contract import SavedPipelineContractError, validate_saved_pipeline_result
        try:
            validate_saved_pipeline_result(result)
        except SavedPipelineContractError:
            raise SavedPipelineError("invalid_saved_result") from None
        log("audit_finished", status=result["status"], gate_state=result["summary"]["gate_state"],
            exit_code=result["summary"]["exit_code"])
        _new_json(output / "audit_result.json", result)
        return result
    except SavedPipelineError as exc:
        try:
            log("audit_failed", status="incomplete", gate_state="blocked", exit_code=2, reason_code=exc.code)
        except SavedPipelineError:
            pass
        raise
    finally:
        if journal is not None:
            journal.close()
