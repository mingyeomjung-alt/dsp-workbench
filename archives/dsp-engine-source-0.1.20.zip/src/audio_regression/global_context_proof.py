"""Exhaustive quantized single-event geometry, without landmark proposals.

A fixed PCM quantization envelope can only exclude impossible geometries.
Approval still requires the unchanged bounded gain solver and independent
whole-output exact rendering. Edge and quiet alternatives are not discarded
before identifiability is decided. This narrow certificate is not provenance.
"""

from __future__ import annotations

import math
from collections import deque

import numpy as np
from scipy.signal import resample_poly

from .compound_event_proof import (
    FIR_RADIUS, GRID, POSITION_TOLERANCE, _copy_context_gate, _edited_source,
)
from .compound_gain import MAX_NODES as GAIN_MAX_NODES
from .compound_gain import PCM_STEP, _render, _valid_pcm, quantization_bound, solve_gain


MIN_CONTEXT = 480  # 60 ms on each retained side, after centered FIR support.
MAX_DELAY_HYPOTHESES = 2049
MAX_GEOMETRY_TESTS = 40_000_000
MAX_GAIN_NODES = 16384  # The v8 total gain-node budget is not increased.
MAX_EXACT_CANDIDATES = 2401  # The v8 exact candidate cap is not increased.


def _sample_intervals(reference: np.ndarray, observed: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Outward necessary positive-gain intervals; these never approve a pair.

    Near-zero source samples are conservatively skipped, rather than treated
    as evidence of a fitted gain. No whole-original peak bound is applied:
    deleting a peak can make a larger gain valid for the edited source.
    """
    lower = np.zeros(len(reference), dtype=np.float64)
    upper = np.full(len(reference), np.inf, dtype=np.float64)
    # Exact linear zeros do not need a fitted coefficient: their observed
    # value must stay within the SAME fixed quantization envelope for ANY
    # positive gain. This necessary contradiction matters for quiet prefixes.
    impossible_zero = (reference == 0) & (np.abs(observed) > quantization_bound())
    lower[impossible_zero], upper[impossible_zero] = np.inf, -np.inf
    active = np.abs(reference) >= 8 * PCM_STEP
    if np.any(active):
        a, b = reference[active], observed[active]
        error = quantization_bound()
        left, right = (b - error) / a, (b + error) / a
        lower[active] = np.nextafter(np.minimum(left, right), -np.inf)
        upper[active] = np.nextafter(np.maximum(left, right), np.inf)
    return lower, upper


def _mapped_intervals(reference: np.ndarray, target: np.ndarray, offset: int):
    """Necessary intervals at every source position for a fixed offset."""
    lower = np.full(len(reference), np.inf, dtype=np.float64)
    upper = np.full(len(reference), -np.inf, dtype=np.float64)
    first, last = max(0, -offset), min(len(reference), len(target) - offset)
    if last > first:
        lower[first:last], upper[first:last] = _sample_intervals(
            reference[first:last], target[first + offset:last + offset])
    return lower, upper


def _prefix_intervals(lower, upper):
    return (np.concatenate(([0.0], np.maximum.accumulate(lower))),
            np.concatenate(([np.inf], np.minimum.accumulate(upper))))


def _suffix_intervals(lower, upper):
    return (np.concatenate((np.maximum.accumulate(lower[::-1])[::-1], [0.0])),
            np.concatenate((np.minimum.accumulate(upper[::-1])[::-1], [np.inf])))


def _window_extrema(values, width, *, maximum):
    """All fixed-width necessary copy-interval extrema, linear deterministic work."""
    output = np.empty(len(values) - width + 1, dtype=np.float64)
    pending = deque()
    for index, value in enumerate(values):
        while pending and pending[0] <= index - width:
            pending.popleft()
        while pending and (values[pending[-1]] <= value if maximum else values[pending[-1]] >= value):
            pending.pop()
        pending.append(index)
        if index >= width - 1:
            output[index - width + 1] = values[pending[0]]
    return output


def prove_event(source, target, max_delay_samples: int) -> tuple[dict | None, dict]:
    """Search every supported delay and every 1 ms boundary, including edges.

    The reference is complete even-length 16 kHz mono PCM16. The complete
    observed 8 kHz PCM16 includes any exact leading-zero delay. The difference
    in complete lengths and each delay determines the event kind and length.
    The supported class has one delete or canonical later adjacent full copy,
    200--2000 ms. No numeric gain, edit position, or recipe is an input.
    """
    trace = {
        "search_complete": False, "reason_code": None,
        "boundary_grid_ms": 1, "fir_radius_output_samples": FIR_RADIUS,
        "minimum_informative_retained_context_samples": MIN_CONTEXT,
        "maximum_delay_hypotheses": MAX_DELAY_HYPOTHESES,
        "maximum_geometry_tests": MAX_GEOMETRY_TESTS,
        "maximum_gain_nodes": MAX_GAIN_NODES,
        "maximum_exact_candidates": MAX_EXACT_CANDIDATES,
        "delay_hypotheses_checked": 0, "geometry_candidates_checked": 0,
        "interval_excluded_candidate_count": 0, "gain_solver_calls": 0,
        "gain_nodes_used": 0, "feasible_candidate_count": 0,
        "feasible_geometries": [], "every_supported_geometry_checked": False,
        "pruning_certificate": "fixed_quantization_envelope_common_gain_intersection",
        "pruning_can_approve": False, "endpoint_alternatives_included": True,
        "leading_zero_count_is_unique_delay": False,
        "source_gate_is_arbitrary_history_proof": False,
    }

    def finish(reason, complete, proof=None):
        trace.update(reason_code=reason, search_complete=complete)
        return proof, trace

    original, observed = _valid_pcm(source), _valid_pcm(target)
    if (original is None or observed is None or len(original) % 2
            or type(max_delay_samples) is not int or max_delay_samples < 0):
        return finish("global_context_invalid_pcm_input", True)
    if np.any(observed == -1) or np.any(observed == 32767 / 32768):
        return finish("global_context_target_endpoint_not_supported", True)
    if (MAX_DELAY_HYPOTHESES <= 0 or MAX_GEOMETRY_TESTS <= 0
            or MAX_GAIN_NODES <= 0 or MAX_EXACT_CANDIDATES <= 0):
        return finish("global_context_proof_budget_exceeded", False)

    reference = resample_poly(original, 1, 2)
    count, delta = len(reference), len(observed) - len(reference)
    nonzero = np.flatnonzero(observed)
    if not len(nonzero):
        return finish("global_context_uninformative_output", True)
    # Source/filter onset can be zero. This is an upper bound, not a fitted
    # or asserted unique delay. The length equation supplies the delay residue.
    last_delay = min(max_delay_samples, int(nonzero[0]))
    delays = [delay for delay in range(delta % GRID, last_delay + 1, GRID)
              if 1600 <= abs(delta - delay) <= 16000]
    trace["supported_delay_hypothesis_count"] = len(delays)
    trace["observed_leading_zero_sample_count"] = int(nonzero[0])
    if len(delays) > MAX_DELAY_HYPOTHESES:
        return finish("global_context_proof_budget_exceeded", False)
    if not delays:
        return finish("global_context_length_or_delay_hypothesis_not_supported", True)

    # After the event, the source-to-full-output offset is always M-N,
    # independent of the hypothesized leading delay or event kind.
    suffix_samples = _mapped_intervals(reference, observed, delta)
    suffix = _suffix_intervals(*suffix_samples)
    feasible = []
    for delay in delays:
        trace["delay_hypotheses_checked"] += 1
        change = delta - delay
        kind, length = ("delete", -change) if change < 0 else ("repeat", change)
        first, last = (0, count - length) if kind == "delete" else (length, count)
        points = np.arange(first, last + 1, GRID, dtype=np.int64)
        # first is grid aligned; the source length need not be. np.arange
        # therefore visits every admissible point without inventing last.
        trace["geometry_candidates_checked"] += len(points)
        if trace["geometry_candidates_checked"] > MAX_GEOMETRY_TESTS:
            return finish("global_context_proof_budget_exceeded", False)
        prefix = _prefix_intervals(*_mapped_intervals(reference, observed, delay))
        before_ends = np.maximum(0, points - FIR_RADIUS)
        after_starts = np.minimum(count, points + FIR_RADIUS + (length if kind == "delete" else 0))
        lower = np.maximum(prefix[0][before_ends], suffix[0][after_starts])
        upper = np.minimum(prefix[1][before_ends], suffix[1][after_starts])
        if kind == "repeat" and np.any((upper >= lower) & (upper > 0)):
            # The added copy interior has the same offset as the suffix, but
            # is not included in its retained cumulative range. Its full
            # FIR-safe interior supplies necessary SAME-gain constraints.
            width = length - 2 * FIR_RADIUS
            copy_starts = points - length + FIR_RADIUS
            copy_lower = _window_extrema(suffix_samples[0], width, maximum=True)
            copy_upper = _window_extrema(suffix_samples[1], width, maximum=False)
            lower = np.maximum(lower, copy_lower[copy_starts])
            upper = np.minimum(upper, copy_upper[copy_starts])
        survivors = points[(upper >= lower) & (upper > 0)]
        trace["interval_excluded_candidate_count"] += len(points) - len(survivors)
        for point_value in survivors:
            point = int(point_value)
            # Reserve the unchanged solver's entire cap before beginning. Any
            # incomplete gain search blocks success, even after a witness.
            if (trace["gain_nodes_used"] + GAIN_MAX_NODES > MAX_GAIN_NODES
                    or trace["gain_solver_calls"] >= MAX_EXACT_CANDIDATES):
                return finish("global_context_proof_budget_exceeded", False)
            edited = _edited_source(original, point, length, kind)
            witness, gain_trace = solve_gain(edited, observed[delay:])
            trace["gain_solver_calls"] += 1
            trace["gain_nodes_used"] += gain_trace.get("nodes_visited", 0)
            if trace["gain_nodes_used"] > MAX_GAIN_NODES:
                return finish("global_context_proof_budget_exceeded", False)
            if not gain_trace.get("search_complete", False):
                trace["incomplete_gain_search_geometry"] = {
                    "kind": kind, "length": length, "point": point, "delay": delay,
                    "reason_code": gain_trace.get("reason_code")}
                return finish("global_context_gain_search_incomplete", False)
            if witness is None:
                continue
            if type(witness) is not dict:
                return finish("global_context_invalid_exact_witness", False)
            rendered, gain = witness.get("rendered"), witness.get("gain")
            if (type(gain) not in (float, int) or not math.isfinite(gain) or gain <= 0
                    or not isinstance(rendered, np.ndarray) or rendered.ndim != 1
                    or not np.array_equal(rendered, observed[delay:])):
                return finish("global_context_invalid_exact_witness", False)
            independently_rendered = _render(edited, float(gain))
            if independently_rendered is None or not np.array_equal(independently_rendered, observed[delay:]):
                return finish("global_context_invalid_exact_witness", False)
            proposal = {"point": point, "length": length, "kind": kind,
                        "delay": delay, "gain": float(gain), "rendered": rendered,
                        "gain_search_trace": gain_trace}
            feasible.append(proposal)
            trace["feasible_candidate_count"] = len(feasible)
            trace["feasible_geometries"].append({key: proposal[key] for key in ("point", "length", "kind", "delay")})
            # Different lengths/delays are distinct explanations, not jitter in
            # a canonical boundary. Quiet and periodic alternatives stay here.
            first_witness = feasible[0]
            if (any(proposal[key] != first_witness[key] for key in ("kind", "length", "delay"))
                    or point - first_witness["point"] > POSITION_TOLERANCE):
                return finish("global_context_ambiguous_geometry", False)

    trace["every_supported_geometry_checked"] = True
    if not feasible:
        return finish("global_context_no_exact_event_witness", True)
    selected = feasible[0]
    point, length, kind = selected["point"], selected["length"], selected["kind"]
    right = point + length if kind == "delete" else point
    if (point < FIR_RADIUS + MIN_CONTEXT
            or right > count - FIR_RADIUS - MIN_CONTEXT
            or any(f["point"] < FIR_RADIUS + MIN_CONTEXT
                   or f["point"] + (length if kind == "delete" else 0) > count - FIR_RADIUS - MIN_CONTEXT
                   for f in feasible)):
        return finish("global_context_endpoint_or_near_edge_alternative", True)
    floor = quantization_bound() / math.sqrt(1 - .90 ** 2)
    event_first = point if kind == "delete" else point - length
    if float(np.std(selected["gain"] * reference[event_first:event_first + length])) <= floor:
        return finish("global_context_event_source_below_quantization_resolution", True)
    if kind == "repeat":
        admitted, reason = _copy_context_gate(reference, point, length)
        trace["copy_source_gate"] = reason
        if not admitted:
            return finish("global_context_copy_source_entry_gate_not_unique", True)
    trace.update(selected_boundary_samples=point,
                 feasible_boundary_spread_samples=feasible[-1]["point"] - feasible[0]["point"],
                 gain_witness=selected["gain"], gain_is_unique_or_processing_provenance=False,
                 every_output_sample_exact=True, exact_output_sample_count=len(selected["rendered"]),
                 leading_zero_sample_count=selected["delay"])
    return finish("global_context_exact_supported_witness", True, selected)
