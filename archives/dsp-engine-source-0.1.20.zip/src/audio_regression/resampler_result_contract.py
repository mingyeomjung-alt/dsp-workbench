"""Strict result contract for an explicitly declared FFT resampling model.

Raw input metadata stays distinct from the canonical 16 kHz comparison signal.
This inert validator checks recorded geometry and claims; it neither runs a
resampler nor proves execution, signal provenance or complete audio quality.
The native short/endpoint contracts remain unchanged on a private child view.
"""

from __future__ import annotations

from copy import deepcopy
import math

from . import result_contract as _base
from .edge_event_result_contract import (
    METHOD as EDGE_METHOD, validate_edge_event_analysis_result,
)
from .review_contract import with_review_diagnostics
from .short_event_result_contract import (
    METHOD as SHORT_METHOD, _ANALYSIS_FIELDS, _near_exact,
    validate_short_event_analysis_result,
)


ENGINE = "local_content_alignment_v12"
METHOD = "declared_fft_resampling_exact_pcm_forward_proof"
MODEL = "scipy_fft_periodic_48k_16k_pcm16_postedit_v1"
PROOF_KINDS = frozenset({
    "exact_resampling_only", "native_short_event", "native_endpoint_loss", "unproved",
})
REASON_CODES = frozenset({
    "resampler_unsupported_input_path", "resampler_projection_out_of_range",
    "resampler_no_exact_supported_postedit_proof",
})
_EXTRA_FIELDS = {"resampling_reference", "proof_kind"}


def _reject(code: str) -> None:
    raise _base.ResultContractError(code)


def _configuration(value: object) -> None:
    configuration = _base._fields(value,
        {"profile", "allow_gain", "allow_resampling", "max_delay_ms", "resampling_model"},
        code="invalid_configuration")
    if configuration["profile"] != "basic":
        _reject("unsupported_profile")
    if (configuration["allow_gain"] is not False
            or configuration["allow_resampling"] is not True
            or type(configuration["resampling_model"]) is not str
            or configuration["resampling_model"] != MODEL):
        _reject("unsupported_resampler_configuration")
    _base._number(configuration["max_delay_ms"], "invalid_configuration", 0, 5000)


def _analysis(value: object) -> None:
    analysis = _base._fields(value, _ANALYSIS_FIELDS, code="invalid_analysis_method")
    expected = {"sample_rate_hz": 16000, "hop_ms": .0625, "method": METHOD,
                "minimum_event_duration_ms": 50, "maximum_cumulative_edit_shift_ms": 2000,
                "diagnostic_rules_not_calibrated_probabilities": True}
    for field, target in expected.items():
        if isinstance(target, bool):
            valid = analysis[field] is target
        elif isinstance(target, str):
            valid = type(analysis[field]) is str and analysis[field] == target
        else:
            valid = _base._number(analysis[field], "invalid_analysis_method") == target
        if not valid:
            _reject("invalid_analysis_method")
    if type(analysis["sample_rate_hz"]) is not int:
        _reject("invalid_analysis_method")


def _canonical_metadata(value: dict, reference: dict, processed: dict) -> dict | None:
    canonical = value["resampling_reference"]
    supported_path = (reference["sample_rate_hz"] == 48000
                      and processed["sample_rate_hz"] == 16000
                      and reference["sample_count"] % 3 == 0)
    if canonical is None:
        if (value["status"] != "withheld" or value["reason_code"] not in {
                "resampler_unsupported_input_path", "resampler_projection_out_of_range"}):
            _reject("missing_resampling_reference")
        if value["reason_code"] == "resampler_projection_out_of_range" and not supported_path:
            _reject("inconsistent_resampling_reference")
        if value["reason_code"] == "resampler_unsupported_input_path" and supported_path:
            _reject("inconsistent_resampling_reference")
        return None
    canonical = _base._metadata(canonical)
    if (not supported_path or canonical["sample_rate_hz"] != 16000
            or canonical["sample_count"] * 3 != reference["sample_count"]
            or not _base._same_number(canonical["duration_ms"], reference["duration_ms"])):
        _reject("inconsistent_resampling_reference")
    return canonical


def _normal(value: dict, canonical: dict, processed: dict) -> None:
    if (value["content_preservation_status"] != "no_supported_defect_candidates"
            or value["events"] != [] or type(value["events"]) is not list
            or value["alignment_segments"] != [] or type(value["alignment_segments"]) is not list
            or canonical["sample_count"] != processed["sample_count"]):
        _reject("inconsistent_resampling_only_result")
    # Exact PCM equality implies these sample measurements agree. The RIFF
    # container digest need not: the processed WAV may contain other chunks.
    if any(not math.isclose(canonical[field], processed[field], rel_tol=0, abs_tol=1e-12)
           for field in ("rms", "peak")):
        _reject("inconsistent_resampling_exact_metadata")
    diagnostics = _base._fields(value["diagnostics"], _base._DIAGNOSTIC_FIELDS,
                                code="invalid_diagnostics")
    for field, expected in (("normalized_path_cost", 0), ("gain_estimate", 1),
                            ("applied_gain", 1), ("matched_normalized_rmse", 0)):
        _near_exact(diagnostics[field], expected, "inconsistent_resampling_exact_metrics")
    if diagnostics["minimum_local_correlation"] is not None:
        _reject("inconsistent_resampling_exact_metrics")
    if _base._integer(diagnostics["anchor_run_count"], "invalid_diagnostics", 0) != 0:
        _reject("inconsistent_anchor_count")
    if (_base._integer(diagnostics["matched_analysis_samples"], "invalid_diagnostics")
            != canonical["sample_count"]):
        _reject("inconsistent_matched_sample_count")


def _native_child(value: dict, canonical: dict) -> None:
    # Validate the canonical comparison axis without relabelling actual input
    # metadata or allowing an inherited 8 kHz result to masquerade as native.
    shared = deepcopy(value)
    for field in _EXTRA_FIELDS:
        shared.pop(field)
    shared["reference"] = deepcopy(canonical)
    shared["configuration"].pop("resampling_model")
    shared["configuration"]["allow_resampling"] = False
    if value["proof_kind"] == "native_short_event":
        shared["engine"] = "local_content_alignment_v10"
        shared["analysis"]["method"] = SHORT_METHOD
        validate_short_event_analysis_result(shared)
    else:
        shared["engine"] = "local_content_alignment_v11"
        shared["analysis"]["method"] = EDGE_METHOD
        validate_edge_event_analysis_result(shared)


@with_review_diagnostics
def validate_resampler_analysis_result(value: object) -> dict:
    """Validate declared-model results without reading audio or changing input."""
    if type(value) is not dict:
        _reject("invalid_result_type")
    _base._json_tree(value)
    if value.get("engine") != ENGINE:
        _reject("unsupported_engine")
    if type(value.get("schema_version")) is not int or value["schema_version"] != 1:
        _reject("unsupported_schema_version")
    if type(value.get("status")) is not str or value["status"] not in {"analyzed", "withheld", "error"}:
        _reject("unsupported_result_status")
    if value["status"] == "error":
        _base._fields(value, {"schema_version", "engine", "status", "reason_code"})
        _base._reason(value["reason_code"])
        return value
    analyzed = value["status"] == "analyzed"
    _base._fields(value, _base._FULL_FIELDS | _EXTRA_FIELDS |
                   ({"alignment_segments"} if analyzed else set()))
    if value["complete_audio_approval"] is not False or value["commercial_performance_validated"] is not False:
        _reject("invalid_approval_claim")
    _configuration(value["configuration"])
    _analysis(value["analysis"])
    reference, processed = _base._metadata(value["reference"]), _base._metadata(value["processed"])
    if type(value["proof_kind"]) is not str or value["proof_kind"] not in PROOF_KINDS:
        _reject("unsupported_resampling_proof_kind")
    limitations = value["limitations"]
    if (type(limitations) is not list or not 1 <= len(limitations) <= 32
            or any(type(item) is not str or not 1 <= len(item) <= 2000 for item in limitations)):
        _reject("invalid_limitations")
    canonical = _canonical_metadata(value, reference, processed)
    if not analyzed:
        if (value["proof_kind"] != "unproved" or value["content_preservation_status"] != "withheld"
                or value["events"] is not None or value["diagnostics"] != {}
                or type(value["diagnostics"]) is not dict or type(value["reason_code"]) is not str
                or value["reason_code"] not in REASON_CODES):
            _reject("inconsistent_result_status")
        if (canonical is not None
                and value["reason_code"] != "resampler_no_exact_supported_postedit_proof"):
            _reject("inconsistent_resampling_reference")
        return value
    if value["reason_code"] is not None or value["proof_kind"] == "unproved":
        _reject("inconsistent_result_status")
    if canonical is None:
        _reject("missing_resampling_reference")
    if value["proof_kind"] == "exact_resampling_only":
        _normal(value, canonical, processed)
    else:
        _native_child(value, canonical)
    return value
