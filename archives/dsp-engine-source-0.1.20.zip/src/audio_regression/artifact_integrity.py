"""Bounded, inert verification of artifacts against an external digest anchor.

No audio is decoded and no saved result or processor is executed. Matching a
caller-supplied manifest digest proves byte agreement with that anchor, not the
authenticity of its author, execution provenance, or complete audio approval.
Filesystem checks reject observable aliases and changes; they are not an atomic
filesystem snapshot or protection against an adversarial storage administrator.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import stat
import unicodedata


ENGINE = "preserved_artifact_integrity_v1"
MAX_MANIFEST_BYTES = 1_048_576
MAX_FILES = 4096
MAX_FILE_BYTES = 16_777_216
MAX_TOTAL_BYTES = 536_870_912
MAX_TREE_ENTRIES = 16_384
MAX_PATH_DEPTH = 64
READ_CHUNK_BYTES = 65_536
_HEX = re.compile(r"[0-9a-f]{64}\Z")
_RESERVED = re.compile(r"(?:con|prn|aux|nul|com[1-9¹²³]|lpt[1-9¹²³])(?:\..*)?\Z", re.I)


class ArtifactVerificationError(ValueError):
    """Stable code-only errors, never private filenames or exception details."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__("Preserved artifact verification could not complete: " + code + ".")


def _reject(code: str) -> None:
    raise ArtifactVerificationError(code)


def _absolute(value: str | Path) -> Path:
    try:
        if not isinstance(value, (str, Path)):
            _reject("invalid_artifact_path")
        return Path(os.path.abspath(os.fspath(value)))
    except ArtifactVerificationError:
        raise
    except (OSError, TypeError, ValueError):
        _reject("invalid_artifact_path")


def _relative(value: object) -> str:
    if (type(value) is not str or not value or len(value) > 2048
            or value != unicodedata.normalize("NFC", value)
            or any(unicodedata.category(c) in {"Cc", "Cf", "Cs"} for c in value)
            or any(c in value for c in '\\:*?<>|"')):
        _reject("invalid_artifact_relative_path")
    parts = value.split("/")
    if (len(parts) > MAX_PATH_DEPTH
            or any(not part or part in {".", ".."} or len(part) > 255
                   or part != part.strip() or part.endswith(".")
                   or _RESERVED.fullmatch(part) for part in parts)):
        _reject("invalid_artifact_relative_path")
    return value


def _link(info: os.stat_result) -> bool:
    return (stat.S_ISLNK(info.st_mode)
            or bool(getattr(info, "st_file_attributes", 0)
                    & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)))


def _identity(info: os.stat_result) -> tuple:
    return (info.st_dev, info.st_ino, info.st_mode, info.st_nlink,
            info.st_size, info.st_mtime_ns, info.st_ctime_ns)


def _cross_identity(info: os.stat_result) -> tuple:
    # Python 3.12 Windows lstat and fstat can expose different ctime semantics
    # (birth vs metadata-change time). Compare shared fields plus birthtime
    # when available across those two origins, but retain full origin-specific
    # ctime identities for both named-before/after and descriptor-before/after.
    return (info.st_dev, info.st_ino, info.st_mode, info.st_nlink,
            info.st_size, info.st_mtime_ns,
            getattr(info, "st_birthtime_ns", info.st_ctime_ns))


def _directory(path: Path) -> os.stat_result:
    info = path.lstat()
    if _link(info) or not stat.S_ISDIR(info.st_mode):
        _reject("unsafe_artifact_path")
    return info


def _parents(path: Path) -> dict[Path, tuple]:
    # Normal directories have multiple POSIX links. Directory aliases are
    # rejected through symlink/reparse checks; regular-file hard links below
    # are rejected by requiring exactly one link.
    result = {}
    for parent in reversed(path.parents):
        info = _directory(parent)
        result[parent] = (info.st_dev, info.st_ino, info.st_mode)
    return result


def _regular(path: Path) -> os.stat_result:
    info = path.lstat()
    if _link(info) or not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        _reject("unsafe_artifact_path")
    return info


def _read_regular(path: Path, limit: int, *, collect: bool = False,
                  expected_identity: tuple | None = None) -> tuple[str, int, bytes | None, tuple]:
    """Stream at most limit + 1 bytes and observe named/descriptor identity."""
    parents = _parents(path)
    named = _regular(path)
    identity = _identity(named)
    if expected_identity is not None and identity != expected_identity:
        _reject("artifact_changed_during_verification")
    if named.st_size > limit:
        _reject("artifact_file_too_large")
    descriptor = None
    try:
        flags = (os.O_RDONLY | getattr(os, "O_BINARY", 0)
                 | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_NONBLOCK", 0))
        descriptor = os.open(path, flags)
        opened = os.fstat(descriptor)
        if (_link(opened) or not stat.S_ISREG(opened.st_mode)
                or opened.st_nlink != 1 or _cross_identity(opened) != _cross_identity(named)):
            _reject("artifact_changed_during_verification")
        descriptor_identity = _identity(opened)
        digest, count, parts = hashlib.sha256(), 0, []
        with os.fdopen(descriptor, "rb") as stream:
            descriptor = None
            while True:
                chunk = stream.read(min(READ_CHUNK_BYTES, limit - count + 1))
                if not chunk:
                    break
                count += len(chunk)
                if count > limit:
                    _reject("artifact_file_too_large")
                digest.update(chunk)
                if collect:
                    parts.append(chunk)
            if _identity(os.fstat(stream.fileno())) != descriptor_identity:
                _reject("artifact_changed_during_verification")
        if _identity(_regular(path)) != identity or _parents(path) != parents:
            _reject("artifact_changed_during_verification")
        if count != named.st_size:
            _reject("artifact_changed_during_verification")
        return digest.hexdigest(), count, b"".join(parts) if collect else None, identity
    finally:
        if descriptor is not None:
            os.close(descriptor)


def _object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            _reject("duplicate_json_key")
        result[key] = value
    return result


def _constant(_: str) -> None:
    _reject("non_finite_manifest_value")


def _manifest(raw: bytes, name: str) -> tuple[list[dict], set[str], int]:
    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=_object,
                           parse_constant=_constant)
    except ArtifactVerificationError:
        raise
    except (UnicodeError, ValueError, RecursionError, OverflowError):
        _reject("invalid_artifact_manifest_json")
    if (type(value) is not dict
            or set(value) != {"schema_version", "files", "manifest_excludes_only_itself", "network_used"}
            or type(value["schema_version"]) is not int or value["schema_version"] != 1
            or value["manifest_excludes_only_itself"] is not True
            or value["network_used"] is not False
            or type(value["files"]) is not list or len(value["files"]) > MAX_FILES):
        _reject("invalid_artifact_manifest")
    paths, directories, folded, total = [], set(), {}, 0
    for item in value["files"]:
        if type(item) is not dict or set(item) != {"path", "size_bytes", "sha256"}:
            _reject("invalid_artifact_entry")
        relative = _relative(item["path"])
        if relative.casefold() == name.casefold():
            _reject("artifact_manifest_self_entry")
        if (type(item["size_bytes"]) is not int
                or not 0 <= item["size_bytes"] <= MAX_FILE_BYTES):
            _reject("invalid_artifact_size")
        if type(item["sha256"]) is not str or not _HEX.fullmatch(item["sha256"]):
            _reject("invalid_artifact_digest")
        total += item["size_bytes"]
        if total > MAX_TOTAL_BYTES:
            _reject("artifact_total_size_exceeded")
        parts = relative.split("/")
        for index in range(1, len(parts) + 1):
            prefix = "/".join(parts[:index])
            key = prefix.casefold()
            if key in folded and folded[key] != prefix:
                _reject("artifact_path_collision")
            folded[key] = prefix
            if index < len(parts):
                directories.add(prefix)
        paths.append(relative)
    if paths != sorted(paths) or len(set(paths)) != len(paths):
        _reject("invalid_artifact_path_order")
    if set(paths) & directories:
        _reject("artifact_path_collision")
    return value["files"], directories, total


def _tree(root: Path) -> dict[str, tuple[str, tuple]]:
    result = {"": ("directory", _identity(_directory(root)))}
    folded, pending = {}, [(root, "")]
    while pending:
        directory, prefix = pending.pop()
        before = _identity(_directory(directory))
        with os.scandir(directory) as entries:
            for entry in entries:
                relative = _relative(prefix + "/" + entry.name if prefix else entry.name)
                if len(result) >= MAX_TREE_ENTRIES:
                    _reject("artifact_tree_limit_exceeded")
                key = relative.casefold()
                if key in folded:
                    _reject("artifact_path_collision")
                folded[key] = relative
                path = directory / entry.name
                info = path.lstat()
                if _link(info):
                    _reject("unsafe_artifact_path")
                if stat.S_ISDIR(info.st_mode):
                    result[relative] = ("directory", _identity(info))
                    pending.append((path, relative))
                elif stat.S_ISREG(info.st_mode) and info.st_nlink == 1:
                    result[relative] = ("file", _identity(info))
                else:
                    _reject("unsafe_artifact_path")
        if _identity(_directory(directory)) != before:
            _reject("artifact_changed_during_verification")
        if result[prefix][1] != before:
            _reject("artifact_changed_during_verification")
    return result


def _verify(root: str | Path, manifest: str | Path, expected: str) -> dict:
    if type(expected) is not str or not _HEX.fullmatch(expected):
        _reject("invalid_expected_manifest_sha256")
    root_path, manifest_path = _absolute(root), _absolute(manifest)
    root_parents = _parents(root_path)
    _directory(root_path)
    name = _relative(manifest_path.name)
    if manifest_path.parent != root_path or "/" in name or not name.endswith(".json"):
        _reject("invalid_artifact_manifest_location")
    digest, _, raw, manifest_identity = _read_regular(
        manifest_path, MAX_MANIFEST_BYTES, collect=True)
    if digest != expected:
        _reject("manifest_digest_mismatch")
    files, directories, claimed_total = _manifest(raw, name)
    before = _tree(root_path)
    expected_tree = {"": "directory", name: "file"}
    expected_tree.update({relative: "directory" for relative in directories})
    expected_tree.update({item["path"]: "file" for item in files})
    if {relative: value[0] for relative, value in before.items()} != expected_tree:
        _reject("artifact_coverage_mismatch")
    if before[name][1] != manifest_identity:
        _reject("artifact_changed_during_verification")
    streamed_total = 0
    for item in files:
        path = root_path.joinpath(*item["path"].split("/"))
        identity = before[item["path"]][1]
        if identity[4] != item["size_bytes"]:
            _reject("artifact_size_mismatch")
        file_digest, size, _, _ = _read_regular(path, item["size_bytes"], expected_identity=identity)
        streamed_total += size
        if streamed_total > MAX_TOTAL_BYTES:
            _reject("artifact_total_size_exceeded")
        if size != item["size_bytes"]:
            _reject("artifact_size_mismatch")
        if file_digest != item["sha256"]:
            _reject("artifact_digest_mismatch")
    final_digest, _, _, _ = _read_regular(
        manifest_path, MAX_MANIFEST_BYTES, expected_identity=manifest_identity)
    if final_digest != expected:
        _reject("manifest_digest_mismatch")
    if _tree(root_path) != before or _parents(root_path) != root_parents:
        _reject("artifact_changed_during_verification")
    if streamed_total != claimed_total:
        _reject("artifact_size_mismatch")
    return {"schema_version": 1, "engine": ENGINE, "status": "verified",
            "manifest_sha256": digest, "file_count": len(files), "total_bytes": streamed_total,
            "quality_verdict": "not_assessed", "authenticity_verified": False,
            "execution_provenance_verified": False, "complete_audio_approval": False,
            "commercial_performance_validated": False, "network_used": False}


def verify_artifact_manifest(root: str | Path, manifest: str | Path, *,
                             expected_manifest_sha256: str) -> dict:
    """Verify an exact artifact tree without creating, resealing, or executing it.

    ``manifest`` must identify a directly contained, lowercase ``.json`` file.
    Only that named file is excluded from coverage. The expected digest must
    come from outside the tree; this API cannot verify that external source.
    Empty artifact lists are valid only for a root containing the manifest alone.
    """
    try:
        return _verify(root, manifest, expected_manifest_sha256)
    except ArtifactVerificationError:
        raise
    except (OSError, ValueError, TypeError):
        raise ArtifactVerificationError("artifact_read_error") from None
    except Exception:
        raise ArtifactVerificationError("artifact_verification_internal_error") from None
