"""Static presentation of validated native-rate measurements, not quality QC."""

from pathlib import Path

from .fullband_contract import validate_fullband_result
from .fullband_runner import FullbandRunError
from .pipeline_runner import PipelineRunError, _absolute_path, _normal_parents
from .reporting import _STYLE, _e, _value


_REASONS = {
    "sample_rate_mismatch": "샘플레이트가 달라 원시 인덱스 쌍 비교를 보류했습니다.",
    "sample_count_mismatch": "샘플 수가 달라 원시 인덱스 쌍 비교를 보류했습니다.",
}
_RATIO_REASONS = {
    "finite": "원본 에너지 / 원시 차이 에너지 비율",
    "zero_residual": "차이 에너지가 0이므로 유한 dB 비율을 제공하지 않음",
    "zero_reference": "원본 에너지가 0이므로 유한 dB 비율을 제공하지 않음",
    "not_comparable": "입력 기하가 달라 쌍 비교하지 않음",
}
_CORRELATION_REASONS = {
    "defined": "같은 샘플 인덱스의 평균 중심 Pearson 상관",
    "constant_signal": "상수 신호의 중심 분산이 0이므로 상관을 제공하지 않음",
    "not_comparable": "입력 기하가 달라 쌍 비교하지 않음",
}


def _table(headers: tuple[str, ...], rows: list[tuple]) -> str:
    return ('<div class="table-wrap"><table><thead><tr>'
            + ''.join('<th>' + _e(item) + '</th>' for item in headers)
            + '</tr></thead><tbody>'
            + ''.join('<tr>' + ''.join('<td>' + _value(item) + '</td>' for item in row) + '</tr>' for row in rows)
            + '</tbody></table></div>')


def _bands(bands: list[dict], heading: str) -> str:
    rows = []
    for band in bands:
        upper = band["effective_upper_hz"]
        effective = ("지원되지 않음 · Nyquist 밖" if band["status"] == "not_available" else
                     f'{band["lower_hz"]}–{upper} Hz · 상단 '
                     + ("포함" if band["upper_inclusive"] else "미포함"))
        rows.append((f'{band["lower_hz"]}–{band["upper_hz"]} Hz', effective,
                     band["mean_square"], band["power_fraction"]))
    return ('<h3>' + _e(heading) + '</h3>'
            + _table(("고정 대역", "입력별 유효 대역", "평균 제곱 에너지", "전체 에너지 비율"), rows)
            + '<p class="scope muted">입력의 Nyquist를 벗어난 대역은 미제공(null)입니다. '
            '측정 가능한 무음 대역의 에너지 0과 같지 않습니다. '
            '대역 에너지는 전체 기록의 직사각 창 rFFT·Parseval 분해이며, 지각적 음질 점수가 아닙니다.</p>')


def _file_view(label: str, metadata: dict, measurements: dict) -> str:
    items = (
        ("원래 샘플레이트 (Hz)", metadata["sample_rate_hz"]),
        ("샘플 수", metadata["sample_count"]),
        ("길이 (ms)", metadata["duration_ms"]),
        ("DC 오프셋 · 선형 정규화 PCM", measurements["dc_offset"]),
        ("평균 제곱 에너지", measurements["mean_square"]),
        ("RMS (dBFS)", measurements["rms_dbfs"]),
        ("샘플 피크 (dBFS)", measurements["peak_dbfs"]),
        ("크레스트 팩터 · 선형 피크/RMS", measurements["crest_factor"]),
        ("정확한 PCM16 레일 샘플 수", measurements["rail_sample_count"]),
        ("정확한 PCM16 레일 샘플 비율", measurements["rail_sample_fraction"]),
        ("같은 부호 레일의 최장 연속 길이 (샘플)", measurements["longest_same_rail_run_samples"]),
        ("입력 SHA-256", metadata["sha256"]),
    )
    details = '<dl>' + ''.join('<dt>' + _e(name) + '</dt><dd>' + _value(value) + '</dd>' for name, value in items) + '</dl>'
    frames = [(frame["start_sample"], frame["end_sample"], frame["mean_square"], frame["peak"])
              for frame in measurements["frames"]]
    return ('<section class="card"><h2>' + _e(label) + ' · 원래 샘플레이트 측정</h2>' + details
            + '<p class="scope muted">레일은 정확한 +32767/-32768 샘플의 관찰값입니다. '
            '클리핑 가능성의 대리 지표이지 클리핑 발생·원인 확정이 아닙니다. '
            '무음의 RMS·피크 dBFS와 크레스트 팩터는 유한 값이 없어 미제공(null)입니다.</p>'
            + _bands(measurements["bands"], "대역 에너지")
            + '<details><summary>100 ms 프레임 에너지 · ' + _e(len(frames)) + '개</summary>'
            + '<p class="scope muted">샘플 경계는 이 입력의 원시 인덱스입니다. 시작 포함·끝 제외, '
            '마지막 프레임은 짧을 수 있습니다. 피크는 선형 정규화 PCM입니다.</p>'
            + _table(("시작 샘플", "끝 샘플 (제외)", "평균 제곱 에너지", "선형 샘플 피크"), frames)
            + '</details></section>')


def _pair_view(comparison: dict) -> str:
    if comparison["status"] == "withheld":
        return ('<section class="card summary blocked"><h2>쌍 비교 보류 · 개별 파일 측정 유지</h2>'
                '<p>' + _e(_REASONS[comparison["reason_code"]]) + '</p>'
                '<p><code>' + _e(comparison["reason_code"]) + '</code></p>'
                '<p class="scope muted">리샘플링·정렬·잘라내기·이득 보상을 자동 적용하지 않았습니다. '
                '쌍 비교 수치와 차이 대역·변경 프레임은 null이며 0이나 정상으로 해석하지 않습니다. '
                '두 입력의 개별 레벨·대역·프레임 측정은 아래에 남아 있습니다.</p></section>')
    items = (
        ("같은 인덱스에서 다른 샘플 수", comparison["unequal_sample_count"]),
        ("첫 변경 샘플 · 포함", comparison["first_changed_sample"]),
        ("마지막 변경 샘플 · 포함", comparison["last_changed_sample"]),
        ("최대 절대 PCM16 샘플 오차", comparison["maximum_abs_error_pcm16"]),
        ("원시 차이의 평균 제곱 에너지", comparison["mean_square_error"]),
        ("신호 대 잔차 비율 (dB) · 환경 SNR 아님", comparison["signal_to_residual_db"]),
        ("비율 해석", _RATIO_REASONS[comparison["signal_to_residual_status"]]),
        ("원시 인덱스 Pearson 상관", comparison["correlation"]),
        ("상관 해석", _CORRELATION_REASONS[comparison["correlation_status"]]),
    )
    details = '<dl>' + ''.join('<dt>' + _e(name) + '</dt><dd>' + _value(value) + '</dd>' for name, value in items) + '</dl>'
    frames = [(frame["start_sample"], frame["end_sample"], frame["unequal_sample_count"])
              for frame in comparison["changed_frames"]]
    return ('<section class="card"><h2>원시 샘플 인덱스 쌍 비교</h2>' + details
            + '<p class="scope muted">동일 샘플레이트·샘플 수의 저장 PCM만 같은 인덱스에서 뺍니다. '
            '시간 정렬·이득 보상·리샘플링을 하지 않았으므로, 정상적인 처리 변화도 차이에 포함됩니다. '
            '차이와 상관은 결함·지각적 음질·보정된 확률 또는 실제 처리 원인을 판정하지 않습니다.</p>'
            + _bands(comparison["residual_bands"], "원시 차이의 대역 에너지")
            + '<details><summary>변경 샘플이 있는 100 ms 프레임 · ' + _e(len(frames)) + '개</summary>'
            + '<p class="scope muted">시작 포함·끝 제외의 원시 샘플 인덱스입니다. '
            '삭제·반복 이벤트나 정렬된 시간 구간이 아닙니다.</p>'
            + (_table(("시작 샘플", "끝 샘플 (제외)", "다른 샘플 수"), frames) if frames else
               '<p>원시 샘플 차이 없음 · 음질 승인 아님</p>') + '</details></section>')


def render_fullband_html(result: dict) -> str:
    """Render a saved validated object only, without reopening any path."""
    validate_fullband_result(result)
    comparison = result["comparison"]
    subtitle = ('쌍 비교 계산 완료 · 차이 유무와 관계없이 음질 판정하지 않음'
                if comparison["status"] == "measured" else '개별 측정 완료 · 입력 기하 불일치로 쌍 비교 보류')
    return (
        '<!doctype html>\n<html lang="ko"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; '
        'style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\'">'
        '<title>DSP 전대역 측정 보고서</title><style>' + _STYLE + '</style></head><body><main>'
        '<header><div class="eyebrow">NATIVE RATE / MEASUREMENTS ONLY</div>'
        '<h1>전대역 측정 완료 · 음질 판정 아님</h1><span class="badge">LOCAL · OFFLINE</span>'
        '<span class="badge">저장된 JSON · 정적 HTML</span></header>'
        '<section class="card summary"><h2>' + _e(subtitle) + '</h2><p>종료 코드 <code>'
        + _e(result["summary"]["exit_code"]) + '</code>: 0은 쌍 측정 계산 완료, '
        '2는 쌍 비교 보류입니다. 차이가 커도 계산이 끝나면 0이며 승인·합격을 뜻하지 않습니다.</p>'
        '<p><code>quality_verdict: not_assessed</code> · <code>complete_audio_approval: false</code></p></section>'
        '<section class="notice"><strong>기존 시간적 분석과 별도인 측정</strong>'
        '<p>100 ms 프레임과 고정 8개 대역을 원래 샘플레이트에서 측정합니다. '
        '자동 시간 정렬·리샘플링·이득 보상을 하지 않습니다. '
        'STI·LUFS·RT60·SPL, 환경 잡음 SNR, 청각적 승인 또는 상용 성능 검증은 제공하지 않습니다.</p></section>'
        + _pair_view(comparison)
        + _file_view("원본", result["reference"], result["reference_measurements"])
        + _file_view("처리본", result["processed"], result["processed_measurements"])
        + '<section class="card"><h2>보고서의 근거와 한계</h2><p>보고서는 저장된 JSON의 구조와 '
        '수치 일관성만 검사하여 표시합니다. 오디오·스냅샷·분석 기록을 다시 열거나 재측정하지 않습니다. '
        '파일 해시는 입력 식별 기록이지 출처나 실제 결함 원인을 증명하지 않습니다.</p>'
        '<p><code>commercial_performance_validated: false</code> · '
        '<code>fault_provenance_confirmed: false</code> · <code>network_used: false</code></p>'
        '<p class="scope muted">외부 자원·실행 스크립트·클릭 가능한 입력 경로가 없는 정적 보고서입니다.</p>'
        '</section><footer>원래 샘플레이트의 측정 기록 · 전체 음질 판정 없음</footer>'
        '</main></body></html>\n'
    )


def write_fullband_html(result: dict, path: str | Path) -> None:
    """Validate and create exclusively, rejecting observable linked parents."""
    rendered = render_fullband_html(result)
    try:
        destination = _absolute_path(path)
        _normal_parents(destination)
    except PipelineRunError as exc:
        code = "unsafe_output_parent" if exc.code == "unsafe_output_parent" else "invalid_output_path"
        raise FullbandRunError(code) from None
    try:
        with destination.open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(rendered)
    except FileExistsError:
        raise FullbandRunError("output_exists") from None
    except (OSError, ValueError, TypeError):
        raise FullbandRunError("output_write_error") from None
