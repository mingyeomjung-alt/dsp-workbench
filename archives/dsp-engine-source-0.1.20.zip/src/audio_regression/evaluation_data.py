"""Deterministic M3 pair construction, separate from all detector code.

This module edits a supplied reference at a predeclared position. It never
examines signal quality to move an edit to an easier location, imports an
analysis engine, or reads/writes files. Truth labels belong to the evaluator,
not to the detector. The generated telephone pairs are synthetic transforms,
not actual telephone recordings.
"""

from __future__ import annotations

import math
from numbers import Integral, Real

import numpy as np
from scipy.signal import butter, sosfilt

from .audio import SUPPORTED_SAMPLE_RATES, WavAudio, decode_wav, encode_wav
from .profiles import telephone_transform_samples


EDIT_START_FRACTION = 0.35
DEFECT_DURATIONS_MS = (200, 400, 750)
DELAY_MS = 240
GAIN_DB = -6.0
MIN_CONTEXT_MS = 500
MIN_REFERENCE_SECONDS = 4.0
MAX_REFERENCE_SECONDS = 12.0
PHONE_RATE_HZ = 8000


def _text(name: str, value: object) -> str:
    if (
        not isinstance(value, str) or not value.strip() or len(value) > 256
        or any(ord(character) < 32 for character in value)
    ):
        raise ValueError(f"{name} must be a nonempty printable string of at most 256 characters")
    return value


def _generator_arguments(seed: object, duration_seconds: object, rate: object) -> tuple[int, float, int]:
    if isinstance(seed, bool) or not isinstance(seed, Integral) or not 0 <= seed < 2**64:
        raise ValueError("seed must be an integer between zero and 2**64 - 1")
    if (
        isinstance(rate, bool) or not isinstance(rate, Integral)
        or rate not in SUPPORTED_SAMPLE_RATES
    ):
        raise ValueError("rate must be 8000, 16000, 44100, or 48000")
    if isinstance(duration_seconds, bool) or not isinstance(duration_seconds, Real):
        raise ValueError("duration_seconds must be a finite number between 4 and 12")
    try:
        duration = float(duration_seconds)
    except (OverflowError, ValueError, TypeError):
        raise ValueError("duration_seconds must be a finite number between 4 and 12") from None
    if not math.isfinite(duration) or not MIN_REFERENCE_SECONDS <= duration <= MAX_REFERENCE_SECONDS:
        raise ValueError("duration_seconds must be a finite number between 4 and 12")
    return int(seed), duration, int(rate)


def make_confirmation_signal(
    seed: int, duration_seconds: float = 6.0, rate: int = 16000,
) -> WavAudio:
    """Make a seeded colored-noise/multiband-burst family, not M1 chirps.

    This is controlled, nonperiodic test content, not speech. Five independent
    band-noise components have independently varying smooth burst envelopes.
    Headroom is established once during source creation. The returned audio is
    already PCM16-quantized, so later exact edits cannot hide a second source
    normalization. Reserved final-evaluation seeds must not be used in tests.
    """
    actual_seed, seconds, actual_rate = _generator_arguments(seed, duration_seconds, rate)
    rng = np.random.default_rng(actual_seed)
    count = round(seconds * actual_rate)
    sample_positions = np.arange(count, dtype=np.float64)
    values = np.zeros(count, dtype=np.float64)
    # All bands fit below the lowest supported Nyquist frequency. Their shape
    # and amplitude do not depend on a detector response or expected edit.
    bands = ((180, 420), (440, 850), (900, 1450), (1500, 2200), (2250, 3150))
    for index, (low, high) in enumerate(bands):
        white = rng.standard_normal(count)
        band = sosfilt(butter(3, [low, high], btype="bandpass", fs=actual_rate, output="sos"), white)
        anchor_step = round(actual_rate * (0.083 + index * 0.017))
        anchors = np.arange(0, count + anchor_step, anchor_step)
        levels = rng.uniform(0.08, 1.0, len(anchors)) ** 2
        envelope = np.interp(sample_positions, anchors, levels)
        values += band * envelope / (1.0 + index * 0.12)
    values += rng.standard_normal(count) * 0.012
    values *= 0.18 / float(np.max(np.abs(values)))
    return decode_wav(encode_wav(values, actual_rate))


def _configuration(profile: str, reference_rate: int, *, gain: bool = False) -> dict:
    return {
        "profile": profile,
        "allow_gain": gain,
        "allow_resampling": profile == "telephone" and reference_rate != PHONE_RATE_HZ,
        "max_delay_ms": 1000.0,
    }


def _trial(
    *, reference: WavAudio, processed: np.ndarray, source_group: str,
    source_kind: str, condition: str, profile: str, expected_events: list[dict],
    scope: str = "supported", allow_gain: bool = False,
) -> dict:
    reference_bytes = encode_wav(reference.samples, reference.sample_rate_hz)
    processed_bytes = encode_wav(processed, reference.sample_rate_hz)
    if profile == "telephone":
        processed_bytes = encode_wav(
            telephone_transform_samples(decode_wav(processed_bytes)), PHONE_RATE_HZ,
        )
    result = {
        "trial_id": f"{source_group}::{profile}::{condition}",
        "source_group": source_group,
        "source_kind": source_kind,
        "condition": condition,
        "profile": profile,
        "reference_wav": reference_bytes,
        "processed_wav": processed_bytes,
        "configuration": _configuration(profile, reference.sample_rate_hz, gain=allow_gain),
        "expected_events": expected_events,
        "scope": scope,
    }
    if scope == "stress":
        result["expected_handling"] = "withheld"
    return result


def build_trials(reference: WavAudio, *, source_group: str, source_kind: str) -> list[dict]:
    """Build 16 fixed supported pairs plus six separately scored stress pairs.

    Supported pairs per profile: clean, 240 ms leading silence with -6 dB
    gain, and deletion/repetition at 200/400/750 ms. The fixed edit start is
    round(0.35 * sample_count), never selected from content. Intervals are
    half-open and reported in exact source-time milliseconds, including for
    telephone output. A repetition's extra copy is after the original source
    interval. Stress labels are not expected supported defects and must not
    be pooled into normal false-alarm or supported recall denominators.

    Original-content derivatives retain the supplied group so resampled/edited
    versions cannot be treated as independent sources. The periodic and silent
    stress references use canonical groups: their shared content is not fresh
    independent data when this builder is called for another original.
    """
    if not isinstance(reference, WavAudio):
        raise ValueError("reference must be a WavAudio input")
    group = _text("source_group", source_group)
    kind = _text("source_kind", source_kind)
    rate = reference.sample_rate_hz
    count = len(reference.samples)
    duration = count / rate
    if not MIN_REFERENCE_SECONDS <= duration <= MAX_REFERENCE_SECONDS:
        raise ValueError("evaluation reference must be between 4 and 12 seconds")
    start = round(EDIT_START_FRACTION * count)
    context = math.ceil(MIN_CONTEXT_MS * rate / 1000.0)
    longest = round(max(DEFECT_DURATIONS_MS) * rate / 1000.0)
    if start < context or start + longest > count - context:
        raise ValueError("evaluation edits require at least 500 ms of preserved context")
    values = reference.samples
    ms = lambda samples: samples * 1000.0 / rate
    results: list[dict] = []
    for profile in ("basic", "telephone"):
        def append(condition: str, samples: np.ndarray, events: list[dict], *, gain: bool = False) -> None:
            results.append(_trial(
                reference=reference, processed=samples, source_group=group, source_kind=kind,
                condition=condition, profile=profile, expected_events=events, allow_gain=gain,
            ))
        append("normal_clean", values, [])
        delay_samples = round(DELAY_MS * rate / 1000.0)
        append(
            "normal_delay240_gain_minus6db",
            np.concatenate((np.zeros(delay_samples), values * 10.0 ** (GAIN_DB / 20.0))),
            [], gain=True,
        )
        for duration_ms in DEFECT_DURATIONS_MS:
            length = round(duration_ms * rate / 1000.0)
            end = start + length
            append(f"delete_{duration_ms}ms", np.concatenate((values[:start], values[end:])), [{
                "type": "delete", "reference_interval_ms": [ms(start), ms(end)],
                "processed_boundary_ms": ms(start),
            }])
            append(f"repeat_{duration_ms}ms", np.concatenate((values[:end], values[start:end], values[end:])), [{
                "type": "repeat", "reference_source_interval_ms": [ms(start), ms(end)],
                "processed_added_interval_ms": [ms(end), ms(end + length)],
            }])

    replacement_length = round(400.0 * rate / 1000.0)
    replacement_end = start + replacement_length
    zero_replacement = values.copy()
    zero_replacement[start:replacement_end] = 0.0
    rng = np.random.default_rng(440004)
    unrelated = rng.standard_normal(replacement_length)
    unrelated *= 0.12 / float(np.max(np.abs(unrelated)))
    crop_length = round(300.0 * rate / 1000.0)
    stress_cases = (
        ("stress_zero_replacement400ms", reference, zero_replacement, kind),
        ("stress_unrelated_insert400ms", reference,
         np.concatenate((values[:start], unrelated, values[start:])), kind),
        ("stress_crop_start300ms", reference, values[crop_length:], kind),
        ("stress_crop_end300ms", reference, values[:-crop_length], kind),
    )
    for condition, actual_reference, processed, actual_kind in stress_cases:
        results.append(_trial(
            reference=actual_reference, processed=processed, source_group=group, source_kind=actual_kind,
            condition=condition, profile="basic", expected_events=[], scope="stress",
        ))
    stress_count = 4 * rate
    tone = 0.12 * np.sin(2.0 * np.pi * 600.0 * np.arange(stress_count) / rate)
    for condition, samples, canonical_group in (
        ("stress_periodic_tone4s", tone, "stress_periodic_600hz_4s"),
        ("stress_silent_pair4s", np.zeros(stress_count), "stress_silent_4s"),
    ):
        stress_reference = decode_wav(encode_wav(samples, rate))
        trial = _trial(
            reference=stress_reference, processed=stress_reference.samples,
            source_group=canonical_group, source_kind="synthetic_stress_signal", condition=condition,
            profile="basic", expected_events=[], scope="stress",
        )
        trial["trial_id"] = f"{group}::{trial['trial_id']}"
        results.append(trial)
    return results
