"""Basic-profile candidate with physically bounded PCM16 cancellation checks.

The frozen v1 detector remains unchanged. This candidate revalidates only short,
balanced DP cancellations using independently anchored raw correspondence. It
does not forgive unexplained compound edits or use scenario/ground-truth inputs.
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np

from .alignment import edit_align
from .analysis_scope import analysis_scope
from .audio import WavAudio, read_wav
from .engine import (
    ANCHOR_SAMPLES, EDGE_TOLERANCE_SAMPLES, HOP, MAX_EDIT_SHIFT_SAMPLES,
    MIN_EVENT_SAMPLES, RATE, EngineConfig, EngineConfigError,
    _adjacent_copy, _anchor, _boundary, _coalesce_transitions, _corr,
    _silent_original_edge,
)
from .features import extract_features
from .profiles import prepare_analysis


ENGINE = "local_content_alignment_v2"
METHOD = "constrained_edit_alignment_with_pcm16_cancellation_revalidation"
PCM16_STEP = 1.0 / 32768.0
CONTEXT_SAMPLES = ANCHOR_SAMPLES
MINIMUM_CORRELATION = .90
TRACE_RUN_LIMIT = 6001
REVALIDATION_POLICY = {
    "maximum_balanced_span_ms": 40.0,
    "pcm16_step": PCM16_STEP,
    "maximum_residual_steps_multiplier": 2.0,
    "rms_residual_steps_multiplier": 1.0,
    "minimum_context_correlation": MINIMUM_CORRELATION,
    "minimum_context_rms_pcm16_steps": 8.0,
    "context_duration_ms": 240.0,
    "requires_equal_axis_lengths": True,
    "requires_same_independent_anchor_offset": True,
    "file_edge_requires_exact_zero_or_end_and_zero_offset": True,
}


def _rms(samples: np.ndarray) -> float:
    return float(np.sqrt(np.mean(samples * samples))) if len(samples) else 0.0


def _finish_withheld(result: dict, trace: dict, code: str) -> tuple[dict, dict]:
    result["reason_code"] = code
    trace["result_status"] = "withheld"
    trace["withheld_branch"] = code
    return result, trace


def _trusted_matches(runs: list[dict], x: np.ndarray, y: np.ndarray,
                     settings: EngineConfig, result: dict) -> tuple[dict, float, str | None]:
    """The unchanged v1 anchor, coverage, gain and local-validation rules."""
    anchored = {}
    for index, run in enumerate(runs):
        if run["kind"] == "match":
            anchor = _anchor(run, x, y, MINIMUM_CORRELATION)
            if anchor is not None:
                anchored[index] = anchor
    if not anchored:
        return anchored, 1.0, "insufficient_unambiguous_anchors"
    if any(index not in anchored and run["kind"] == "match"
           and (run["reference_end_frame"] - run["reference_start_frame"]) * HOP >= ANCHOR_SAMPLES
           for index, run in enumerate(runs)):
        return anchored, 1.0, "unreliable_matched_content"
    first_offset = next(iter(anchored.values()))["offset_samples"]
    if any(abs(anchor["offset_samples"] - first_offset) > MAX_EDIT_SHIFT_SAMPLES
           for anchor in anchored.values()):
        return anchored, 1.0, "cumulative_edit_shift_outside_budget"
    sample_pairs = []
    for anchor in anchored.values():
        start = anchor["reference_start_frame"] * HOP + 320
        end = min(len(x), anchor["reference_end_frame"] * HOP) - 320
        offset = anchor["offset_samples"]
        start, end = max(start, -offset), min(end, len(y) - offset)
        if end > start:
            sample_pairs.append((x[start:end], y[start + offset:end + offset]))
    matched_samples = sum(len(a) for a, _ in sample_pairs)
    if matched_samples < max(1600, .35 * min(len(x), len(y))):
        return anchored, 1.0, "insufficient_matched_coverage"
    denominator = sum(float(np.dot(a, a)) for a, _ in sample_pairs)
    gain = sum(float(np.dot(a, b)) for a, b in sample_pairs) / max(denominator, 1e-16)
    applied_gain = gain if settings.allow_gain else 1.0
    residual = sum(float(np.sum((b - applied_gain * a) ** 2)) for a, b in sample_pairs)
    nrmse = math.sqrt(residual / max(applied_gain * applied_gain * denominator, 1e-16))
    result["diagnostics"].update({"gain_estimate": gain, "applied_gain": applied_gain,
                                  "matched_normalized_rmse": nrmse,
                                  "matched_analysis_samples": matched_samples,
                                  "anchor_run_count": len(anchored)})
    if gain <= 0 or not math.isfinite(gain) or nrmse > .08:
        return anchored, applied_gain, "unexplained_matched_signal_change"
    local_correlations = []
    for a, b in sample_pairs:
        width = min(960, len(a))
        for start in range(0, len(a) - width + 1, 480):
            block_a, block_b = a[start:start + width], b[start:start + width]
            if max(float(np.std(block_a)), float(np.std(block_b))) <= 1e-6:
                continue
            score = _corr(block_a, block_b)
            local_correlations.append(score)
            if score < MINIMUM_CORRELATION:
                return anchored, applied_gain, "unexplained_local_signal_change"
    result["diagnostics"]["minimum_local_correlation"] = min(local_correlations) if local_correlations else None
    return anchored, applied_gain, None


def _revalidate_compound(index: int, runs: list[dict], anchored: dict,
                         x: np.ndarray, y: np.ndarray, gain: float) -> dict:
    """Inspect one bounded cancellation without modifying either waveform."""
    run = runs[index]
    record = {"run_index": index, "span": dict(run), "accepted": False,
              "reason_code": None, "offset_samples": None,
              "maximum_absolute_residual": None, "rms_residual": None,
              "maximum_absolute_residual_bound": 2 * PCM16_STEP * (1 + abs(gain)),
              "rms_residual_bound": PCM16_STEP * (1 + abs(gain)),
              "context": []}

    def reject(code: str) -> dict:
        record["reason_code"] = code
        return record

    i0 = run["reference_start_frame"] * HOP
    i1 = min(len(x), run["reference_end_frame"] * HOP)
    j0 = run["processed_start_frame"] * HOP
    j1 = min(len(y), run["processed_end_frame"] * HOP)
    if not (0 < i1 - i0 <= EDGE_TOLERANCE_SAMPLES and i1 - i0 == j1 - j0):
        return reject("not_short_balanced_cancellation")
    before, after = anchored.get(index - 1), anchored.get(index + 1)
    is_start, is_end = index == 0, index == len(runs) - 1
    if is_start:
        if i0 != 0 or j0 != 0 or after is None or after["offset_samples"] != 0:
            return reject("file_edge_not_exactly_anchored")
        offset = 0
    elif is_end:
        if i1 != len(x) or j1 != len(y) or before is None or before["offset_samples"] != 0:
            return reject("file_edge_not_exactly_anchored")
        offset = 0
    else:
        if before is None or after is None or before["offset_samples"] != after["offset_samples"]:
            return reject("independent_anchor_offsets_not_equal")
        offset = before["offset_samples"]
    record["offset_samples"] = offset
    if j0 - i0 != offset or j1 - i1 != offset:
        return reject("compound_coordinates_not_at_anchor_offset")
    if not math.isfinite(gain) or gain <= 0:
        return reject("gain_not_positive_and_finite")
    residual = y[j0:j1] - gain * x[i0:i1]
    record["maximum_absolute_residual"] = float(np.max(np.abs(residual)))
    record["rms_residual"] = _rms(residual)
    if (record["maximum_absolute_residual"] > record["maximum_absolute_residual_bound"]
            or record["rms_residual"] > record["rms_residual_bound"]):
        return reject("suspicious_samples_exceed_pcm16_error_budget")
    contexts = []
    if before is not None:
        contexts.append(("before", i0 - CONTEXT_SAMPLES, i0))
    if after is not None:
        contexts.append(("after", i1, i1 + CONTEXT_SAMPLES))
    if not contexts:
        return reject("independent_context_missing")
    for side, first, last in contexts:
        a, b = x[max(0, first):min(len(x), last)], y[max(0, first + offset):min(len(y), last + offset)]
        if len(a) != CONTEXT_SAMPLES or len(b) != CONTEXT_SAMPLES:
            return reject("insufficient_raw_context")
        correlation = _corr(a, b)
        reference_rms, processed_rms = _rms(gain * a), _rms(b)
        context = {"side": side, "sample_count": len(a), "correlation": correlation,
                   "reference_rms_at_applied_gain": reference_rms, "processed_rms": processed_rms}
        record["context"].append(context)
        if min(reference_rms, processed_rms) < 8 * PCM16_STEP:
            return reject("raw_context_below_quantization_activity_floor")
        if correlation < MINIMUM_CORRELATION:
            return reject("raw_context_correlation_not_supported")
    # A discontinuity larger than two pointwise residual allowances cannot be
    # explained by independently bounded rounding errors at the two samples.
    first, last = max(0, i0 - 1), min(len(x), i1 + 1)
    pfirst, plast = first + offset, last + offset
    if pfirst < 0 or plast > len(y):
        return reject("continuity_coordinates_outside_audio")
    local_residual = y[pfirst:plast] - gain * x[first:last]
    max_step = float(np.max(np.abs(np.diff(local_residual)))) if len(local_residual) > 1 else 0.0
    record["maximum_residual_step"] = max_step
    if max_step > 2 * record["maximum_absolute_residual_bound"]:
        return reject("raw_boundary_continuity_not_supported")
    record["accepted"] = True
    record["reason_code"] = "pcm16_cancellation_revalidated"
    return record


def _merge_revalidated_matches(runs: list[dict], accepted: set[int]) -> list[dict]:
    output = []
    for index, original in enumerate(runs):
        run = dict(original)
        if index in accepted:
            run["kind"] = "match"
        if output and output[-1]["kind"] == run["kind"] == "match":
            previous = output[-1]
            same_offset = (previous["processed_start_frame"] - previous["reference_start_frame"]
                           == run["processed_start_frame"] - run["reference_start_frame"])
            contiguous = (previous["reference_end_frame"] == run["reference_start_frame"]
                          and previous["processed_end_frame"] == run["processed_start_frame"])
            if same_offset and contiguous:
                previous["reference_end_frame"] = run["reference_end_frame"]
                previous["processed_end_frame"] = run["processed_end_frame"]
                continue
        output.append(run)
    return output


@analysis_scope
def analyze_buffers_with_trace(reference: WavAudio, processed: WavAudio,
                               config: EngineConfig | None = None) -> tuple[dict, dict]:
    settings = config if config is not None else EngineConfig()
    if not isinstance(settings, EngineConfig) or settings.profile != "basic":
        raise EngineConfigError("The PCM16 cancellation candidate supports only the basic profile.")
    result = {
        "schema_version": 1, "engine": ENGINE,
        "status": "withheld", "content_preservation_status": "withheld",
        "reason_code": None, "events": None,
        "complete_audio_approval": False, "commercial_performance_validated": False,
        "reference": reference.metadata(), "processed": processed.metadata(),
        "configuration": {"profile": settings.profile, "allow_gain": settings.allow_gain,
                          "allow_resampling": settings.allow_resampling, "max_delay_ms": settings.max_delay_ms},
        "analysis": {"sample_rate_hz": RATE, "hop_ms": 10.0, "method": METHOD,
                     "minimum_event_duration_ms": 200, "maximum_cumulative_edit_shift_ms": 2000,
                     "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {},
        "limitations": ["Diagnostic candidates, not complete audio approval or fault provenance.",
                        "Identifiable internal deletion or adjacent-copy repetition only.",
                        "No full-band quality, network loss cause, or actual telephone performance claim."],
    }
    trace = {"schema_version": 1, "engine": "pcm16_cancellation_trace_v1",
             "analysis_engine": ENGINE, "reference_sha256": reference.sha256,
             "processed_sha256": processed.sha256, "policy": dict(REVALIDATION_POLICY),
             "raw_runs": [], "coalesced_runs": [], "revalidated_runs": [],
             "revalidations": [], "result_status": None, "withheld_branch": None,
             "trace_truncated": False}
    if reference.sample_rate_hz != processed.sample_rate_hz and not settings.allow_resampling:
        return _finish_withheld(result, trace, "resampling_not_declared")
    if min(float(np.std(reference.samples)), float(np.std(processed.samples))) <= 1e-6:
        return _finish_withheld(result, trace, "insufficient_signal_variation")
    x, y = prepare_analysis(reference, "basic"), prepare_analysis(processed, "basic")
    if min(float(np.std(x)), float(np.std(y))) <= 1e-6:
        return _finish_withheld(result, trace, "insufficient_analysis_band_signal")
    path = edit_align(extract_features(x), extract_features(y),
                      math.ceil(settings.max_delay_ms * RATE / 1000 / HOP) + MAX_EDIT_SHIFT_SAMPLES // HOP)
    if path["status"] != "aligned":
        return _finish_withheld(result, trace, path["reason_code"])
    result["diagnostics"]["normalized_path_cost"] = path["normalized_path_cost"]
    runs = _coalesce_transitions(path["runs"])
    trace["raw_runs"] = [dict(run) for run in path["runs"][:TRACE_RUN_LIMIT]]
    trace["coalesced_runs"] = [dict(run) for run in runs[:TRACE_RUN_LIMIT]]
    trace["trace_truncated"] = len(path["runs"]) > TRACE_RUN_LIMIT or len(runs) > TRACE_RUN_LIMIT
    anchored, gain, reason = _trusted_matches(runs, x, y, settings, result)
    if reason:
        return _finish_withheld(result, trace, reason)
    accepted = set()
    for index, run in enumerate(runs):
        if run["kind"] != "compound":
            continue
        record = _revalidate_compound(index, runs, anchored, x, y, gain)
        if len(trace["revalidations"]) < TRACE_RUN_LIMIT:
            trace["revalidations"].append(record)
        else:
            trace["trace_truncated"] = True
        if record["accepted"]:
            accepted.add(index)
    if accepted:
        runs = _merge_revalidated_matches(runs, accepted)
        # Repairs cannot bypass any v1 match rule; merged intervals must earn
        # fresh anchors and repeat all coverage/gain/local-signal checks.
        anchored, gain, reason = _trusted_matches(runs, x, y, settings, result)
        if reason:
            trace["revalidated_runs"] = [dict(run) for run in runs[:TRACE_RUN_LIMIT]]
            return _finish_withheld(result, trace, reason)
    trace["revalidated_runs"] = [dict(run) for run in runs[:TRACE_RUN_LIMIT]]
    first_offset = next(iter(anchored.values()))["offset_samples"]
    last_offset = list(anchored.values())[-1]["offset_samples"]
    edge_lengths = {
        ("delete", "start"): max(0, -first_offset),
        ("insert", "start"): max(0, first_offset),
        ("delete", "end"): max(0, len(x) + last_offset - len(y)),
        ("insert", "end"): max(0, len(y) - len(x) - last_offset),
    }
    events = []
    for index, run in enumerate(runs):
        if run["kind"] == "match":
            continue
        if run["kind"] == "compound":
            return _finish_withheld(result, trace, "compound_or_unidentified_change")
        i0, i1 = run["reference_start_frame"] * HOP, min(len(x), run["reference_end_frame"] * HOP)
        j0, j1 = run["processed_start_frame"] * HOP, min(len(y), run["processed_end_frame"] * HOP)
        edge = index == 0 or index == len(runs) - 1
        content = x[i0:i1] if run["kind"] == "delete" else y[j0:j1]
        if edge:
            original = reference if run["kind"] == "delete" else processed
            side = "start" if index == 0 else "end"
            padding = edge_lengths[(run["kind"], side)]
            signal_length = len(x) if run["kind"] == "delete" else len(y)
            edge_start, edge_end = (0, padding) if side == "start" else (signal_length - padding, signal_length)
            if abs(len(content) - padding) <= EDGE_TOLERANCE_SAMPLES and _silent_original_edge(original, edge_start, edge_end):
                continue
            return _finish_withheld(result, trace, "non_silent_file_edge_change")
        if max(i1 - i0, j1 - j0) <= EDGE_TOLERANCE_SAMPLES:
            continue
        if index - 1 not in anchored or index + 1 not in anchored:
            return _finish_withheld(result, trace, "compound_or_unidentified_change")
        before, after = anchored[index - 1]["offset_samples"], anchored[index + 1]["offset_samples"]
        length = before - after if run["kind"] == "delete" else after - before
        if length < MIN_EVENT_SAMPLES or length > MAX_EDIT_SHIFT_SAMPLES:
            return _finish_withheld(result, trace, "event_outside_supported_duration")
        boundary = _boundary(x, y, i0, before, after, run["kind"])
        if boundary is None or boundary[1] < MINIMUM_CORRELATION:
            return _finish_withheld(result, trace, "event_boundary_not_supported")
        point, boundary_score = boundary
        common = {"boundary_correlation": boundary_score,
                  "offset_before_ms": before * 1000 / RATE, "offset_after_ms": after * 1000 / RATE}
        if run["kind"] == "delete":
            if np.std(x[point:point + length]) <= 1e-6:
                return _finish_withheld(result, trace, "deleted_interval_unidentifiable")
            events.append({"type": "delete", "reference_interval_ms": [point * 1000 / RATE, (point + length) * 1000 / RATE],
                           "processed_boundary_ms": (point + before) * 1000 / RATE, "evidence": common})
        else:
            copied = _adjacent_copy(x, y, point + before, length, point, MINIMUM_CORRELATION)
            if copied is None:
                return _finish_withheld(result, trace, "insertion_not_supported_as_repetition")
            source, inserted_start, match = copied
            events.append({"type": "repeat", "reference_source_interval_ms": [source * 1000 / RATE, (source + length) * 1000 / RATE],
                           "processed_added_interval_ms": [inserted_start * 1000 / RATE, (inserted_start + length) * 1000 / RATE],
                           "copy_interval_convention": "canonical_later_adjacent_copy_not_edit_provenance",
                           "evidence": {**common, "copy_correlation": match["correlation"],
                                        "adjacent_copy_correlation": match["adjacent_copy_correlation"]}})
    if abs(first_offset * 1000 / RATE) > settings.max_delay_ms + 3:
        return _finish_withheld(result, trace, "initial_delay_outside_declared_search")
    result["status"] = "analyzed"
    result["content_preservation_status"] = "defect_candidates" if events else "no_supported_defect_candidates"
    result["events"] = sorted(events, key=lambda event: event.get("processed_boundary_ms", event.get("processed_added_interval_ms", [0])[0]))
    result["alignment_segments"] = [
        {"reference_interval_ms": [anchor["reference_start_frame"] * 10.0, min(len(x), anchor["reference_end_frame"] * HOP) * 1000 / RATE],
         "processed_offset_ms": anchor["offset_samples"] * 1000 / RATE,
         "anchor_correlations": [item["correlation"] for item in anchor["anchors"]]}
        for anchor in anchored.values()
    ]
    trace["result_status"] = "analyzed"
    return result, trace


def analyze_buffers(reference: WavAudio, processed: WavAudio,
                    config: EngineConfig | None = None) -> dict:
    return analyze_buffers_with_trace(reference, processed, config)[0]


def analyze_wavs_with_trace(reference_path: str | Path, processed_path: str | Path,
                            config: EngineConfig | None = None) -> tuple[dict, dict]:
    return analyze_buffers_with_trace(read_wav(reference_path), read_wav(processed_path), config)
