"""Separate v5 identity with unchanged strict shared evidence rules."""
from copy import deepcopy
from . import result_contract as _base
from .review_contract import with_review_diagnostics
from .instrument_result_contract import validate_instrument_analysis_result
ENGINE = "local_content_alignment_v5"
METHOD = "exact_canonical_pcm_resampling_with_unique_context"


@with_review_diagnostics
def validate_canonical_analysis_result(value: object) -> dict:
    if type(value) is not dict:
        raise _base.ResultContractError("invalid_result_type")
    _base._json_tree(value)
    if value.get("engine") != ENGINE:
        raise _base.ResultContractError("unsupported_engine")
    if value.get("status") != "error":
        if type(value.get("analysis")) is not dict or value["analysis"].get("method") != METHOD:
            raise _base.ResultContractError("invalid_analysis_method")
    shared = deepcopy(value)
    shared["engine"] = "local_content_alignment_v4"
    if value.get("status") != "error":
        shared["analysis"]["method"] = "raw_landmark_piecewise_alignment_with_global_uniqueness"
    validate_instrument_analysis_result(shared)
    return value
