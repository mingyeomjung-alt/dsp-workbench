"""Controlled synthetic pairs and exact edit maps, never detector input.

These signals are neither speech nor evidence of natural-audio accuracy. Time
arguments are rounded to the nearest sample using Python's ties-to-even rule.
Positive delay creates leading digital silence; it does not shift or overwrite
the reference. The map uses half-open sample intervals on both file axes.
"""

from __future__ import annotations

from dataclasses import dataclass
import hashlib
import math
from numbers import Integral, Real

import numpy as np

from .audio import encode_wav


_SUPPORTED_RATES = {8000, 16000, 44100, 48000}
_MIN_SECONDS = 2.0
_MAX_SECONDS = 30.0
_MIN_CONTEXT_SECONDS = 0.2


@dataclass(frozen=True)
class GeneratedCase:
    reference_wav: bytes
    processed_wav: bytes
    ground_truth: dict


def _integer(name: str, value: object, minimum: int, maximum: int) -> int:
    if isinstance(value, bool) or not isinstance(value, Integral):
        raise ValueError(f"{name} must be a true integer, not a boolean or float")
    result = int(value)
    if not minimum <= result <= maximum:
        raise ValueError(f"{name} must be between {minimum} and {maximum}")
    return result


def _number(name: str, value: object, minimum: float, maximum: float) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite number")
    try:
        result = float(value)
    except (OverflowError, TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be a finite number") from exc
    if not math.isfinite(result) or not minimum <= result <= maximum:
        raise ValueError(f"{name} must be finite and between {minimum} and {maximum}")
    return result


def _signal(sample_count: int, sample_rate_hz: int, seed: int) -> np.ndarray:
    """Seeded chirps, irregular envelope and noise with safe reference headroom."""
    rng = np.random.default_rng(seed)
    t = np.arange(sample_count, dtype=np.float64) / sample_rate_hz
    duration = sample_count / sample_rate_hz
    anchor_samples = max(2, round(sample_rate_hz * 0.037))
    anchor_positions = np.arange(0, sample_count + anchor_samples, anchor_samples)
    envelope = np.interp(
        np.arange(sample_count), anchor_positions, rng.uniform(0.25, 1.0, len(anchor_positions))
    )
    phases = rng.uniform(-math.pi, math.pi, 3)
    chirp_a = np.sin(2 * math.pi * (173 * t + 1301 * t * t / (2 * duration)) + phases[0])
    chirp_b = np.sin(2 * math.pi * (2519 * t - 1171 * t * t / (2 * duration)) + phases[1])
    modulation = np.sin(2 * math.pi * (619 * t + 11 * np.sin(2 * math.pi * 0.37 * t)) + phases[2])
    signal = envelope * (0.49 * chirp_a + 0.31 * chirp_b + 0.13 * modulation)
    signal += rng.normal(0.0, 0.055, sample_count)
    # Establish source headroom once, not a post-edit clipping repair.
    signal *= 0.2 / float(np.max(np.abs(signal)))
    return np.rint(signal * 32768.0) / 32768.0


def _segment(
    kind: str,
    reference_start: int | None,
    reference_end: int | None,
    processed_start: int,
    processed_end: int,
    rate: int,
) -> dict:
    def ms(sample: int | None) -> float | None:
        return None if sample is None else sample * 1000.0 / rate

    return {
        "kind": kind,
        "reference_start_sample": reference_start,
        "reference_end_sample": reference_end,
        "processed_start_sample": processed_start,
        "processed_end_sample": processed_end,
        "reference_start_ms": ms(reference_start),
        "reference_end_ms": ms(reference_end),
        "processed_start_ms": ms(processed_start),
        "processed_end_ms": ms(processed_end),
    }


def generate_case(
    kind: str = "clean",
    *,
    seed: int = 20261012,
    duration_seconds: float = 6.0,
    sample_rate_hz: int = 16000,
    delay_ms: float = 0.0,
    gain_db: float = 0.0,
    interval_start_ms: float = 2000.0,
    interval_duration_ms: float = 400.0,
) -> GeneratedCase:
    """Return a PCM16 WAV pair with a separate, JSON-serializable timing map.

    ``delete`` removes a reference interval. ``repeat`` inserts an extra copy
    immediately after that source interval. Defects need at least 200 ms of
    preserved reference on both sides, and at least 200 ms of defect duration.
    Both output files must remain 2--30 seconds. Gain is -60--60 dB and rejected
    if it would clip; it is never repaired through silent normalization.
    ``clean`` validates numeric interval fields but does not apply an edit.
    """
    if not isinstance(kind, str) or kind not in {"clean", "delete", "repeat"}:
        raise ValueError("kind must be clean, delete, or repeat")
    actual_seed = _integer("seed", seed, 0, 2**64 - 1)
    rate = _integer("sample_rate_hz", sample_rate_hz, 1, 48000)
    if rate not in _SUPPORTED_RATES:
        raise ValueError("sample_rate_hz must be 8000, 16000, 44100, or 48000")
    duration = _number("duration_seconds", duration_seconds, _MIN_SECONDS, _MAX_SECONDS)
    delay = _number("delay_ms", delay_ms, 0.0, 28000.0)
    gain = _number("gain_db", gain_db, -60.0, 60.0)
    start_ms = _number("interval_start_ms", interval_start_ms, 0.0, 30000.0)
    length_ms = _number("interval_duration_ms", interval_duration_ms, 0.0, 30000.0)

    n = round(duration * rate)
    delay_samples = round(delay * rate / 1000.0)
    start = round(start_ms * rate / 1000.0)
    length = round(length_ms * rate / 1000.0)
    end = start + length
    if kind != "clean":
        context = math.ceil(_MIN_CONTEXT_SECONDS * rate)
        if length < context:
            raise ValueError("edit interval must be at least 200 ms after sample rounding")
        if start < context or end > n - context:
            raise ValueError("edit interval needs at least 200 ms of preserved context on both sides")
    output_n = n + delay_samples + ({"clean": 0, "delete": -length, "repeat": length}[kind])
    if not round(_MIN_SECONDS * rate) <= output_n <= round(_MAX_SECONDS * rate):
        raise ValueError("processed duration must remain between 2 and 30 seconds")

    reference = _signal(n, rate, actual_seed)
    factor = 10.0 ** (gain / 20.0)
    # Check only samples that survive the edit, not removed samples.
    content = reference if kind != "delete" else np.concatenate((reference[:start], reference[end:]))
    if kind == "repeat":
        content = np.concatenate((reference[:end], reference[start:end], reference[end:]))
    gained_content = content * factor
    quantized_content = np.rint(gained_content * 32768.0)
    if (float(np.max(np.abs(gained_content))) >= 1.0
            or np.any(quantized_content > 32767)
            or np.any(quantized_content < -32768)):
        raise ValueError("gain_db would clip the processed signal")
    processed = np.concatenate((np.zeros(delay_samples, dtype=np.float64), gained_content))

    segments: list[dict] = []
    events: list[dict] = []
    if delay_samples:
        segments.append(_segment("generated_silence", None, None, 0, delay_samples, rate))
    if kind == "clean":
        segments.append(_segment("matched", 0, n, delay_samples, output_n, rate))
    elif kind == "delete":
        boundary = delay_samples + start
        segments.extend((
            _segment("matched", 0, start, delay_samples, boundary, rate),
            _segment("deleted", start, end, boundary, boundary, rate),
            _segment("matched", end, n, boundary, output_n, rate),
        ))
        events.append({
            "type": "delete",
            "reference_interval_samples": [start, end],
            "reference_interval_ms": [start * 1000.0 / rate, end * 1000.0 / rate],
            "processed_boundary_sample": boundary,
            "processed_boundary_ms": boundary * 1000.0 / rate,
        })
    else:
        copy_start = delay_samples + end
        copy_end = copy_start + length
        segments.extend((
            _segment("matched", 0, end, delay_samples, copy_start, rate),
            _segment("repetition_copy", start, end, copy_start, copy_end, rate),
            _segment("matched", end, n, copy_end, output_n, rate),
        ))
        events.append({
            "type": "repeat",
            "reference_source_interval_samples": [start, end],
            "reference_source_interval_ms": [start * 1000.0 / rate, end * 1000.0 / rate],
            "processed_added_interval_samples": [copy_start, copy_end],
            "processed_added_interval_ms": [copy_start * 1000.0 / rate, copy_end * 1000.0 / rate],
        })

    reference_wav = encode_wav(reference, rate)
    processed_wav = encode_wav(processed, rate)
    truth = {
        "schema_version": 1,
        "scenario": kind,
        "source_kind": "synthetic_test_signal",
        "evidence_scope": "controlled_signal_geometry_not_natural_audio_accuracy",
        "seed": actual_seed,
        "sample_rate_hz": rate,
        "interval_convention": "half_open",
        "rounding": "nearest_sample_ties_to_even",
        "reference_sample_count": n,
        "processed_sample_count": output_n,
        "reference_duration_ms": n * 1000.0 / rate,
        "processed_duration_ms": output_n * 1000.0 / rate,
        "delay_samples": delay_samples,
        "delay_ms": delay_samples * 1000.0 / rate,
        "gain_db": gain,
        "gain_linear": factor,
        "requested": {
            "duration_seconds": duration,
            "delay_ms": delay,
            "interval_start_ms": start_ms,
            "interval_duration_ms": length_ms,
        },
        "edit_interval_samples": None if kind == "clean" else [start, end],
        "edit_interval_ms": None if kind == "clean" else [start * 1000.0 / rate, end * 1000.0 / rate],
        "events": events,
        "correspondence_segments": segments,
        "reference_sha256": hashlib.sha256(reference_wav).hexdigest(),
        "processed_sha256": hashlib.sha256(processed_wav).hexdigest(),
    }
    return GeneratedCase(reference_wav, processed_wav, truth)
