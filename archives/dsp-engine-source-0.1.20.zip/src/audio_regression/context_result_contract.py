"""Strict opt-in v3 contract with the unchanged raw evidence restrictions.

The bounded active-context bridge has a distinct identity, but its saved result
still has the v1 metadata, raw anchors, event geometry, correlation/residual and
coverage requirements. Validation is structural and does not prove execution,
read trace files, or authorize complete audio approval.
"""

from __future__ import annotations

from copy import deepcopy

from . import result_contract as _base
from .review_contract import with_review_diagnostics


ENGINE = "local_content_alignment_v3"
METHOD = "constrained_edit_alignment_with_bounded_active_context_bridge"


@with_review_diagnostics
def validate_context_analysis_result(value: object) -> dict:
    """Check v3 identity, then all shared rules without mutating the caller."""
    if type(value) is not dict:
        raise _base.ResultContractError("invalid_result_type")
    # Bound the JSON tree before deepcopy, including cycles/nonfinite values.
    _base._json_tree(value)
    if value.get("engine") != ENGINE:
        raise _base.ResultContractError("unsupported_engine")
    if value.get("status") != "error":
        configuration = value.get("configuration")
        if type(configuration) is not dict or configuration.get("profile") != "basic":
            raise _base.ResultContractError("unsupported_profile")
        analysis = value.get("analysis")
        if type(analysis) is not dict or analysis.get("method") != METHOD:
            raise _base.ResultContractError("invalid_analysis_method")
    shared = deepcopy(value)
    shared["engine"] = _base.ENGINE
    if value.get("status") != "error":
        shared["analysis"]["method"] = "constrained_edit_alignment_with_raw_anchors"
    # This private copy is v1, so the public dispatcher cannot recurse to v3.
    _base.validate_analysis_result(shared)
    return value
