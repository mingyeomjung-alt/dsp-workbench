"""Bounded exact witness for gain -> PCM16 -> 16-to-8 kHz -> PCM16.

This is a feasibility proof for one fixed transform, not an adaptive correction.
The numeric gain need not be supplied or unique. Every successful witness must
reproduce every output PCM sample with the public SciPy resampler. Interval
arithmetic can only reject search branches; it can never approve a result.
"""

from __future__ import annotations

import math

import numpy as np
from scipy.signal import firwin, resample_poly, upfirdn


PCM_STEP = 1 / 32768
MAX_NODES = 128
MAX_DEPTH = 40
# SciPy's fixed default polyphase filter for up=1, down=2. The two leading
# zeros and eleven discarded outputs implement its exact centering convention.
_FILTER = np.concatenate((np.zeros(2), firwin(41, .5, window=("kaiser", 5))))
_ABS_FILTER = np.abs(_FILTER)
_FILTER_L1 = float(np.sum(_ABS_FILTER))
# Outward numerical padding only. Success still requires exact PCM equality.
_FLOAT_PAD = 128 * np.finfo(np.float64).eps * (_FILTER_L1 + 1)


def quantization_bound() -> float:
    """Fixed half-LSB gain-PCM/filter/final-PCM envelope, with roundoff pad."""
    return .5 * PCM_STEP * (_FILTER_L1 + 1) + _FLOAT_PAD


def _pcm(values: np.ndarray) -> np.ndarray:
    return np.minimum(np.rint(values * 32768), 32767) / 32768


def _valid_pcm(values) -> np.ndarray | None:
    try:
        raw = np.asarray(values)
        if raw.dtype.kind not in "fiu" or raw.ndim != 1 or not len(raw):
            return None
        array = np.asarray(raw, dtype=np.float64)
    except (TypeError, ValueError, OverflowError):
        return None
    if (not np.all(np.isfinite(array)) or np.any(array < -1)
            or np.any(array > 32767 / 32768)
            or not np.array_equal(_pcm(array), array)):
        return None
    return array


def _filtered(values: np.ndarray, count: int, *, absolute: bool = False) -> np.ndarray:
    coefficients = _ABS_FILTER if absolute else _FILTER
    return upfirdn(coefficients, values, up=1, down=2)[11:11 + count]


def _render(samples: np.ndarray, gain: float) -> np.ndarray | None:
    if not math.isfinite(gain) or gain <= 0:
        return None
    scaled = gain * samples
    if not np.all(np.isfinite(scaled)) or np.any(scaled < -1) or np.any(scaled > 1):
        return None
    output = resample_poly(_pcm(scaled), 1, 2)
    if (not np.all(np.isfinite(output)) or np.any(output < -1)
            or np.any(output > 1)):
        return None
    return _pcm(output)


def solve_gain(samples, target) -> tuple[dict | None, dict]:
    """Find a positive gain witness, or fail closed within a fixed budget.

    Inputs are complete mono PCM16 arrays: source at 16 kHz and target at
    8 kHz, with delay already removed by the caller's correspondence proof.
    Output endpoint codes are unsupported because their saturation bins are
    not the symmetric half-LSB bins used by this deliberately narrow proof.
    ``search_complete`` means a witness was proved or all surviving intervals
    were excluded, not that the gain itself was proved unique.
    """
    trace = {"nodes_visited": 0, "initial_gain_interval": None,
             "search_complete": False, "reason_code": None, "depth": 0,
             "max_depth": MAX_DEPTH, "max_nodes": MAX_NODES,
             "maximum_depth_visited": 0}

    def finish(reason: str, complete: bool, witness: dict | None = None):
        trace.update(reason_code=reason, search_complete=complete)
        return witness, trace

    source, output = _valid_pcm(samples), _valid_pcm(target)
    if (source is None or output is None
            or len(output) != (len(source) + 1) // 2):
        return finish("compound_gain_invalid_pcm_input", True)
    if np.any(output == -1) or np.any(output == 32767 / 32768):
        return finish("compound_gain_target_endpoint_not_supported", True)
    if MAX_NODES <= 0:
        return finish("compound_gain_search_budget_exceeded", False)
    if MAX_DEPTH < 0:
        return finish("compound_gain_search_depth_exceeded", False)

    reference = resample_poly(source, 1, 2)
    active = np.abs(reference) >= 8 * PCM_STEP
    if not np.any(active):
        return finish("compound_gain_uninformative_reference", True)

    # Q(g*x) differs from g*x by at most half an LSB in this search domain.
    # After the fixed linear filter and final PCM round, every aligned sample
    # therefore has this source-independent error bound. No fitted residual
    # or measured candidate threshold is used to enlarge it.
    error = quantization_bound()
    a, b = reference[active], output[active]
    first, second = (b - error) / a, (b + error) / a
    lower = float(np.nextafter(np.max(np.minimum(first, second)), -np.inf))
    upper = float(np.nextafter(np.min(np.maximum(first, second)), np.inf))
    lower = max(lower, float(np.nextafter(0.0, 1.0)))

    # The positive +1 PCM saturation tail would violate the half-LSB bound.
    # Exclude it in the proposal domain instead of silently increasing error.
    positive, negative = float(np.max(source)), float(np.min(source))
    if positive > 0:
        upper = min(upper, (1 - .5 * PCM_STEP) / positive)
    if negative < 0:
        upper = min(upper, -1 / negative)
    trace["initial_gain_interval"] = [lower, upper]
    if (not math.isfinite(lower) or not math.isfinite(upper)
            or upper < lower or upper <= 0):
        return finish("compound_gain_no_feasible_interval", True)

    stack = [(lower, upper, 0)]
    depth_limited = False
    while stack:
        if trace["nodes_visited"] >= MAX_NODES:
            return finish("compound_gain_search_budget_exceeded", False)
        left, right, depth = stack.pop()
        trace["nodes_visited"] += 1
        trace["depth"] = depth
        trace["maximum_depth_visited"] = max(trace["maximum_depth_visited"], depth)

        pcm_left, pcm_right = _pcm(left * source), _pcm(right * source)
        center, radius = (pcm_left + pcm_right) / 2, np.abs(pcm_right - pcm_left) / 2
        mean = _filtered(center, len(output))
        spread = _filtered(radius, len(output), absolute=True)
        minimum = np.nextafter(mean - spread - _FLOAT_PAD, -np.inf)
        maximum = np.nextafter(mean + spread + _FLOAT_PAD, np.inf)
        # Retain ties at both PCM rounding-bin endpoints. This only prunes;
        # exact np.rint behavior is checked by _render for every witness.
        if (np.any(maximum < output - .5 * PCM_STEP)
                or np.any(minimum > output + .5 * PCM_STEP)):
            continue

        middle = left + (right - left) / 2
        for proposed_gain in dict.fromkeys((middle, left, right)):
            rendered = _render(source, proposed_gain)
            if rendered is not None and np.array_equal(rendered, output):
                return finish("compound_gain_exact_witness", True,
                              {"gain": proposed_gain, "rendered": rendered})
        if middle == left or middle == right:
            # The representable interval has been fully checked at endpoints.
            continue
        if depth >= MAX_DEPTH:
            depth_limited = True
            continue
        # Both children remain; there is no top-k or best-correlation shortcut.
        stack.extend(((middle, right, depth + 1), (left, middle, depth + 1)))

    if depth_limited:
        return finish("compound_gain_search_depth_exceeded", False)
    return finish("compound_gain_no_exact_witness", True)
