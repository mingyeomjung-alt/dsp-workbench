"""Opt-in normal-only exact quantized compound-transform proof.

No numeric gain or recipe is supplied by the caller. A bounded scalar gain
feasibility solver must reproduce every observed output sample under one fixed
gain -> PCM16 -> 16-to-8k SRC -> PCM16 -> leading-zero hypothesis. This is an
explanation of observations, not processing provenance or general audio QC.
"""

from copy import deepcopy
import math
from pathlib import Path

import numpy as np

from . import repeat_engine, instrument_engine as raw
from .analysis_scope import analysis_scope
from .compound_gain import solve_gain, quantization_bound
from .audio import WavAudio, read_wav
from .engine import RATE, EngineConfig, EngineConfigError, _corr
from .profiles import prepare_analysis

ENGINE = "local_content_alignment_v7"
METHOD = "interval_gain_quantized_compound_normal_proof"
ELIGIBLE_REASONS = frozenset({"raw_landmark_unexplained_local_residual",
                            "raw_landmark_unexplained_local_change"})


@analysis_scope
def analyze_buffers_with_trace(reference: WavAudio, processed: WavAudio,
                               config: EngineConfig | None = None) -> tuple[dict, dict]:
    settings = config if config is not None else EngineConfig()
    if not isinstance(settings, EngineConfig) or settings.profile != "basic":
        raise EngineConfigError("The compound candidate supports basic only.")
    baseline, old_trace = repeat_engine.analyze_buffers_with_trace(reference, processed, settings)
    result = deepcopy(baseline)
    result["engine"] = ENGINE
    result["analysis"]["method"] = METHOD
    result["limitations"].append("v6 results preserved; new proof is normal-only declared gain/resampling, "
        "16kHz reference to 8kHz PCM16 plus nonnegative leading zeros. A bounded unknown-gain "
        "fixed forward hypothesis must explain every sample; not operation provenance, event rescue, "
        "general SRC support or full-band approval. Sub-resolution correlation summary covers informative blocks only.")
    trace = {"schema_version": 1, "engine": ENGINE, "analysis_engine": ENGINE, "method": METHOD,
             "reference_sha256": reference.sha256, "processed_sha256": processed.sha256,
             "baseline_status": baseline["status"], "baseline_reason_code": baseline["reason_code"],
             "proof_path": "preserved_v6_result", "compound_attempted": False, "compound_proved": False,
             "inherited_v6_trace": deepcopy(old_trace), "result_status": result["status"],
             "reason_code": result["reason_code"]}
    if (baseline["status"] != "withheld" or baseline["reason_code"] not in ELIGIBLE_REASONS
            or not settings.allow_gain or not settings.allow_resampling
            or reference.sample_rate_hz != 16000 or processed.sample_rate_hz != RATE):
        return result, trace
    trace["compound_attempted"] = True
    canonical_count = (len(reference.samples) + 1) // 2
    delay = len(processed.samples) - canonical_count
    if (delay < 0 or delay / 8 > settings.max_delay_ms
            or np.any(processed.samples[:delay])):
        trace["compound_failure"] = "length_or_leading_zero_hypothesis_not_supported"
        return result, trace
    x, y = prepare_analysis(reference), processed.samples[delay:]
    # Real globally unique active windows, not repeated synthetic correlations.
    landmarks, attempted = raw._landmarks(x, processed.samples,
        math.ceil(settings.max_delay_ms * 8) + 16000, True)
    groups = raw._groups(landmarks)
    trace.update(landmarks_attempted=attempted, landmarks_accepted=len(landmarks))
    if (len(groups) != 1 or groups[0]["offset"] != delay or len(groups[0]["points"]) < 3
            or any(p["offset"] != delay for p in groups[0]["points"])):
        trace["compound_failure"] = "unique_normal_context_not_supported"
        return result, trace
    witness, search_trace = solve_gain(reference.samples, y)
    trace["gain_search_trace"] = search_trace
    if witness is None:
        trace["compound_failure"] = search_trace["reason_code"]
        return result, trace
    rendered, gain = witness["rendered"], witness["gain"]
    if len(rendered) != len(y) or not np.array_equal(rendered, y):
        trace["compound_failure"] = "whole_output_exact_proof_failed"
        return result, trace
    applied = gain * x
    nrmse = float(np.linalg.norm(y - applied) / max(np.linalg.norm(applied), 1e-16))
    if nrmse > .08:
        trace["compound_failure"] = "global_residual_not_supported"
        return result, trace
    width = min(960, len(x))
    starts = sorted(set(range(0, len(x) - width + 1, 480)) | {len(x) - width})
    # The exact model covers all quiet samples too. Only the correlation summary
    # separates blocks below the mathematically bounded quantization resolution.
    floor = quantization_bound() / math.sqrt(1 - .90 ** 2)
    raw_minimum, informative_minimum, low_count = None, None, 0
    for start in starts:
        a, b = applied[start:start + width], y[start:start + width]
        correlation = _corr(a, b)
        raw_minimum = correlation if raw_minimum is None else min(raw_minimum, correlation)
        if float(np.std(a)) <= floor:
            low_count += 1
            continue
        informative_minimum = correlation if informative_minimum is None else min(informative_minimum, correlation)
        if correlation < .90:
            trace["compound_failure"] = "informative_local_correlation_not_supported"
            return result, trace
    if informative_minimum is None:
        trace["compound_failure"] = "informative_context_missing"
        return result, trace
    points = groups[0]["points"]
    selected = [points[0], points[len(points) // 2], points[-1]]
    result.update(status="analyzed", content_preservation_status="no_supported_defect_candidates",
        reason_code=None, events=[], diagnostics={"gain_estimate": gain, "applied_gain": gain,
        "matched_normalized_rmse": nrmse, "matched_analysis_samples": len(x), "anchor_run_count": 1,
        "minimum_local_correlation": informative_minimum, "normalized_path_cost": nrmse},
        alignment_segments=[{"reference_interval_ms": [0.0, len(x) / 8],
                             "processed_offset_ms": delay / 8,
                             "anchor_correlations": [p["correlation"] for p in selected]}])
    trace.update(proof_path="compound_normal_exact_forward", compound_proved=True,
        result_status="analyzed", reason_code=None, exact_output_sample_count=len(y),
        leading_zero_sample_count=delay, every_output_sample_exact=True,
        raw_minimum_local_correlation=raw_minimum, informative_minimum_local_correlation=informative_minimum,
        low_information_block_count=low_count, low_information_std_ceiling=floor,
        quantization_error_bound=quantization_bound(), gain_witness=gain,
        gain_is_unique_or_processing_provenance=False)
    return result, trace


def analyze_buffers(reference: WavAudio, processed: WavAudio, config: EngineConfig | None = None) -> dict:
    return analyze_buffers_with_trace(reference, processed, config)[0]


def analyze_wavs_with_trace(reference_path: str | Path, processed_path: str | Path,
                            config: EngineConfig | None = None) -> tuple[dict, dict]:
    return analyze_buffers_with_trace(read_wav(reference_path), read_wav(processed_path), config)
