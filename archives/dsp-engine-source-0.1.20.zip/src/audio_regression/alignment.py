"""Constrained monotone edit alignment with explicit unmatched frame runs.

Each match advances both axes by one frame. A gap advances exactly one axis;
there is no free stretching of time. Row-wise prefix minima implement the
linear-gap dynamic program without a Python inner loop over all frame pairs.
Only legal search-band directions and row states are stored. The original
full-matrix dot product is retained to keep its floating-point reduction order;
cost transformations reuse that matrix rather than allocate dense copies.
"""

import operator

import numpy as np

from .features import FeatureTrack


def edit_align(reference: FeatureTrack, processed: FeatureTrack, maximum_shift_frames: int) -> dict:
    x, y = reference.features, processed.features
    n, m = len(x), len(y)
    gap_cost = 0.18
    # Retain the old first-row slice's index semantics for direct callers:
    # a fractional radius smaller than m raises TypeError, while a larger
    # floating radius may be accepted because min(m, radius) is integral.
    initial_end = operator.index(min(m, maximum_shift_frames) + 1)
    if not abs(n - m) <= maximum_shift_frames:
        return {"status": "withheld", "reason_code": "alignment_outside_search_band"}
    # Integer grid legality depends only on floor(radius). Capping an infinite
    # or very large accepted radius avoids unnecessary integer-sized buffers.
    radius = max(n, m) if maximum_shift_frames >= max(n, m) else int(np.floor(maximum_shift_frames))
    # Log-band vectors are normalized. Silence uses an explicit separate cost.
    costs = x @ y.T
    np.clip(costs, -1.0, 1.0, out=costs)
    np.subtract(1.0, costs, out=costs)
    inactive_x = reference.frame_rms < 1e-5
    inactive_y = processed.frame_rms < 1e-5
    # Open index meshes have O(n+m) storage, unlike dense boolean pair masks.
    costs[np.ix_(inactive_x, inactive_y)] = 0.0
    costs[np.ix_(inactive_x, ~inactive_y)] = 0.8
    costs[np.ix_(~inactive_x, inactive_y)] = 0.8
    band_width = min(m + 1, 2 * radius + 1)
    directions = np.full((n + 1, band_width), 255, dtype=np.uint8)
    columns = np.arange(initial_end)
    previous = columns.astype(np.float64) * gap_cost
    directions[0, :columns.size] = 2
    previous_start = 0
    for i in range(1, n + 1):
        start = max(0, i - radius)
        end = min(m, i + radius) + 1
        columns = np.arange(start, end)
        # Each successive band moves by at most one column. One infinity on
        # either side represents the previous row's illegal cells exactly.
        padded = np.empty(previous.size + 2, dtype=np.float64)
        padded[0] = padded[-1] = np.inf
        padded[1:-1] = previous
        vertical = padded[columns - previous_start + 1] + gap_cost
        diagonal = np.full(columns.size, np.inf, dtype=np.float64)
        first_match = 1 if start == 0 else 0
        match_columns = columns[first_match:]
        diagonal[first_match:] = (
            padded[match_columns - previous_start] + costs[i - 1, match_columns - 1]
        )
        base = np.minimum(diagonal, vertical)
        # current[j] = min(base[k] + (j-k)*gap_cost), for every k<=j.
        current = np.minimum.accumulate(base - columns * gap_cost) + columns * gap_cost
        choices = np.where(diagonal <= vertical, 0, 1).astype(np.uint8)
        if start == 0:
            choices[0] = 1
        choices[current < base - 1e-10] = 2
        choices[~np.isfinite(current)] = 255
        directions[i, :columns.size] = choices
        previous = current
        previous_start = start
    final_cost = previous[m - previous_start]
    if not np.isfinite(final_cost):
        return {"status": "withheld", "reason_code": "alignment_outside_search_band"}
    i, j = n, m
    reverse = []
    while i or j:
        direction = int(directions[i, j - max(0, i - radius)])
        if direction == 0:
            reverse.append(("match", i - 1, j - 1))
            i -= 1
            j -= 1
        elif direction == 1:
            reverse.append(("delete", i - 1, j))
            i -= 1
        elif direction == 2:
            reverse.append(("insert", i, j - 1))
            j -= 1
        else:
            return {"status": "withheld", "reason_code": "alignment_path_unavailable"}
    operations = list(reversed(reverse))
    runs = []
    for operation, i, j in operations:
        di, dj = (1, 1) if operation == "match" else ((1, 0) if operation == "delete" else (0, 1))
        if runs and runs[-1]["kind"] == operation:
            runs[-1]["reference_end_frame"] = i + di
            runs[-1]["processed_end_frame"] = j + dj
        else:
            runs.append({
                "kind": operation,
                "reference_start_frame": i,
                "reference_end_frame": i + di,
                "processed_start_frame": j,
                "processed_end_frame": j + dj,
            })
    return {
        "status": "aligned", "runs": runs,
        "normalized_path_cost": float(final_cost / max(n, m)),
        "gap_cost": gap_cost, "maximum_shift_frames": maximum_shift_frames,
    }
