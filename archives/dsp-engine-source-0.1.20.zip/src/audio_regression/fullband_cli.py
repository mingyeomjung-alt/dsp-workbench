"""Explicit native-rate measurements; exit zero is not an audio-quality pass."""

import argparse
import json
from pathlib import Path
import re
import sys

from .fullband_contract import load_fullband_result, validate_fullband_result
from .fullband_reporting import write_fullband_html
from .fullband_runner import FullbandRunError, run_fullband_measurement
from .result_contract import ResultContractError


ENGINE = "native_fullband_measurements_v1"
_SAFE_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}\Z")


def _emit(value: dict) -> None:
    sys.stdout.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="audio-fullband-check",
        description="Measure original-rate PCM16 WAV levels and bands locally; no quality verdict.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    measure = commands.add_parser("measure", help="Create a fresh native-rate measurement snapshot.")
    measure.add_argument("--reference", type=Path, required=True)
    measure.add_argument("--processed", type=Path, required=True)
    measure.add_argument("--output-dir", type=Path, required=True)
    report = commands.add_parser("report", help="Render stored JSON only; never reopen audio or artifacts.")
    report.add_argument("--input", type=Path, required=True)
    report.add_argument("--output", type=Path, required=True)
    return parser


def _error(code: str) -> dict:
    return {
        "schema_version": 1, "engine": ENGINE, "status": "error",
        "reason_code": code, "exit_code": 3, "quality_verdict": "not_assessed",
        "complete_audio_approval": False, "commercial_performance_validated": False,
        "fault_provenance_confirmed": False, "network_used": False,
    }


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "measure":
            result = run_fullband_measurement(args.reference, args.processed, args.output_dir)
            validate_fullband_result(result)
            _emit(result)
            # Any measured difference is still exit 0. This is measurement
            # completion, not a pass, temporal proof, or downstream approval.
            return result["summary"]["exit_code"]
        result = load_fullband_result(args.input)
        write_fullband_html(result, args.output)
        _emit({
            "schema_version": 1, "engine": ENGINE, "status": "generated_fullband_html",
            "exit_code": 0, "quality_verdict": "not_assessed",
            "complete_audio_approval": False, "commercial_performance_validated": False,
            "fault_provenance_confirmed": False, "network_used": False,
        })
        return 0
    except (FullbandRunError, ResultContractError) as exc:
        candidate = getattr(exc, "code", None)
        code = candidate if type(candidate) is str and _SAFE_CODE.fullmatch(candidate) else "fullband_measurement_error"
    except FileExistsError:
        code = "output_exists"
    except (OSError, RuntimeError, ValueError, TypeError, OverflowError, RecursionError):
        code = "fullband_file_error"
    except Exception:
        code = "fullband_internal_error"
    _emit(_error(code))
    return 3


if __name__ == "__main__":
    raise SystemExit(main())
