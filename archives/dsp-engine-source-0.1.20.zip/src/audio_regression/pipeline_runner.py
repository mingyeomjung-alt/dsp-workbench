"""Local, fail-closed orchestration of the fixed DSP transform allowlist.

Only saved adjacent WAV pairs and the original-to-final pair reach the existing
analyzer. Transform instructions are never diagnostic truth or provenance.
The caller owns a fresh output directory; no file is overwritten or removed.
"""

from __future__ import annotations

from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import time

from . import api, pipeline_transforms
from .artifact_integrity import ArtifactVerificationError, _read_regular
from .audio import AudioInputError, MAX_FILE_BYTES, read_wav
from .check_policy import check_result
from .result_contract import ResultContractError, validate_analysis_result


MAX_PLAN_BYTES = 262_144
ENGINE = "audio_pipeline_regression_v1"
_SAFE_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}\Z")
_GATES = {"clear_supported_temporal_check": 0, "review_required": 1, "blocked": 2}


class PipelineRunError(ValueError):
    """A stable rejection code without paths, source content, or exception text."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__("Audio pipeline could not complete: " + code + ".")


def _safe_code(exc: Exception, fallback: str) -> str:
    if isinstance(exc, (AudioInputError, ResultContractError,
                        pipeline_transforms.PipelineTransformError, PipelineRunError)):
        code = getattr(exc, "code", None)
        if type(code) is str and _SAFE_CODE.fullmatch(code):
            return code
    return fallback


def _normalize_stages(stages: object) -> list[dict]:
    if type(stages) is not list or not 1 <= len(stages) <= 8:
        raise PipelineRunError("invalid_pipeline_stages")
    normalized = []
    for stage in stages:
        try:
            normalized.append(pipeline_transforms.validate_stage(stage))
        except pipeline_transforms.PipelineTransformError as exc:
            raise PipelineRunError(_safe_code(exc, "invalid_stage")) from None
    return normalized


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise PipelineRunError("duplicate_json_key")
        result[key] = value
    return result


def _invalid_constant(_: str) -> None:
    raise PipelineRunError("non_finite_metric")


def load_pipeline_plan(path: str | Path) -> dict:
    """Load a bounded strict UTF-8 plan with only schema version and stages."""
    try:
        with Path(path).open("rb") as stream:
            raw = stream.read(MAX_PLAN_BYTES + 1)
    except (OSError, ValueError, TypeError):
        raise PipelineRunError("plan_file_read_error") from None
    if len(raw) > MAX_PLAN_BYTES:
        raise PipelineRunError("plan_file_too_large")
    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object,
                           parse_constant=_invalid_constant)
    except PipelineRunError:
        raise
    except (UnicodeError, ValueError, RecursionError, OverflowError):
        raise PipelineRunError("invalid_plan_json") from None
    if (type(value) is not dict or set(value) != {"schema_version", "stages"}
            or type(value["schema_version"]) is not int or value["schema_version"] != 1):
        raise PipelineRunError("invalid_pipeline_plan")
    return {"schema_version": 1, "stages": _normalize_stages(value["stages"])}


def _absolute_path(value: str | Path) -> Path:
    try:
        return Path(os.path.abspath(os.fspath(value)))
    except (OSError, TypeError, ValueError):
        raise PipelineRunError("invalid_pipeline_path") from None


def _is_link(info: os.stat_result) -> bool:
    return (stat.S_ISLNK(info.st_mode)
            or bool(getattr(info, "st_file_attributes", 0)
                    & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)))


def _normal_parents(path: Path) -> None:
    """Reject observable symlinks and Windows junction/reparse parents."""
    for parent in reversed(path.parents):
        try:
            info = parent.lstat()
        except FileNotFoundError:
            continue
        except OSError:
            raise PipelineRunError("invalid_output_path") from None
        if _is_link(info):
            raise PipelineRunError("unsafe_output_parent")
        if not stat.S_ISDIR(info.st_mode):
            raise PipelineRunError("invalid_output_path")


def _new_bytes(path: Path, raw: bytes) -> None:
    _normal_parents(path)
    try:
        with path.open("xb") as stream:
            stream.write(raw)
    except (OSError, ValueError, TypeError):
        raise PipelineRunError("output_write_error") from None


def _json_bytes(value: dict) -> bytes:
    try:
        return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2)
                + "\n").encode("utf-8")
    except (TypeError, ValueError, OverflowError, RecursionError):
        raise PipelineRunError("invalid_pipeline_result") from None


def _new_json(path: Path, value: dict) -> None:
    _new_bytes(path, _json_bytes(value))


def _bounded_bytes(path: Path) -> bytes:
    try:
        with path.open("rb") as stream:
            return stream.read(MAX_FILE_BYTES + 1)
    except (OSError, ValueError, TypeError):
        raise PipelineRunError("file_read_error") from None


def _preflight(source: str | Path, stages: object, output_dir: str | Path):
    normalized = _normalize_stages(stages)
    source_path, output_path = _absolute_path(source), _absolute_path(output_dir)
    try:
        # Windows can permit reading/stat while denying the native handle used
        # by strict realpath. Non-strict resolution retains that usable path.
        source_info = source_path.stat()
        source_resolved = source_path.resolve(strict=False)
    except (OSError, RuntimeError):
        raise PipelineRunError("file_read_error") from None
    if not stat.S_ISREG(source_info.st_mode):
        raise PipelineRunError("file_read_error")
    try:
        if source_resolved == output_path.resolve(strict=False):
            raise PipelineRunError("input_output_alias")
    except (OSError, RuntimeError):
        raise PipelineRunError("invalid_output_path") from None
    if os.path.lexists(output_path):
        try:
            alias = os.path.samefile(source_path, output_path)
        except OSError:
            alias = False  # A dangling link is still an occupied destination.
        if alias:
            raise PipelineRunError("input_output_alias")
        raise PipelineRunError("output_directory_exists")
    _normal_parents(output_path)
    try:
        original = read_wav(source_path)
    except AudioInputError as exc:
        raise PipelineRunError(_safe_code(exc, "file_read_error")) from None
    raw = _bounded_bytes(source_path)
    if hashlib.sha256(raw).hexdigest() != original.sha256:
        raise PipelineRunError("source_changed_during_preflight")
    return source_path, output_path, normalized, original, raw


def _declaration(info: object, kind: str) -> dict:
    if type(info) is not dict or info.get("kind") != kind:
        raise PipelineRunError("invalid_transform_result")
    declaration = info.get("declared_comparison")
    if (type(declaration) is not dict
            or set(declaration) != {"profile", "allow_gain", "allow_resampling", "max_delay_ms"}
            or declaration["profile"] != "basic"
            or any(type(declaration[key]) is not bool for key in ("allow_gain", "allow_resampling"))
            or declaration["allow_gain"] != (kind == "gain")
            or declaration["allow_resampling"] != (kind == "resample")
            or type(declaration["max_delay_ms"]) not in (int, float)
            or declaration["max_delay_ms"] != 1000.0):
        raise PipelineRunError("invalid_transform_result")
    # Only these four declared comparison values can reach the frozen analyzer.
    return {key: declaration[key] for key in
            ("profile", "allow_gain", "allow_resampling", "max_delay_ms")}


def _analysis(reference: Path, processed: Path, declaration: dict,
              input_metadata: dict, output_metadata: dict, *, engine: str = "v1",
              trace_path: Path | None = None) -> tuple[dict, dict]:
    if engine == "v1":
        raw_analysis = api.analyze_pair(reference, processed, **declaration)
    else:
        raw_analysis, trace = api.analyze_pair_with_trace(reference, processed, **declaration, engine=engine)
        if trace_path is not None:
            _new_json(trace_path, trace)
    analysis = validate_analysis_result(raw_analysis)
    if analysis["status"] != "error" and analysis["engine"] != "local_content_alignment_" + engine:
        raise PipelineRunError("inconsistent_analysis_engine")
    if analysis["status"] != "error":
        if (analysis["reference"] != input_metadata or analysis["processed"] != output_metadata
                or analysis["configuration"] != declaration):
            raise PipelineRunError("inconsistent_pair_analysis")
    return analysis, check_result(analysis)


def _stage_record(index: int, spec: dict, input_metadata: dict, snapshot: str) -> dict:
    return {"index": index, "label": spec.get("label", f"Stage {index}"),
            "operation": deepcopy(spec), "input": deepcopy(input_metadata), "output": None,
            "status": "not_run", "analysis": None, "check": None,
            "input_snapshot": snapshot, "output_snapshot": None,
            "analysis_artifact": None, "check_artifact": None,
            "reason_code": "prior_stage_execution_error", "runtime_ms": 0.0}


def _error_envelope(code: str) -> dict:
    return {"schema_version": 1, "status": "error", "reason_code": code}


def _save_error(output: Path, folder: str, record: dict, code: str) -> None:
    record.update(status="error", analysis=_error_envelope(code),
                  check=check_result(_error_envelope(code)))
    if "reason_code" in record:
        record["reason_code"] = code
    record["analysis_artifact"] = record["check_artifact"] = None
    for field, name, value in (("analysis_artifact", "error.json", record["analysis"]),
                               ("check_artifact", "error_check.json", record["check"])):
        try:
            relative = folder + "/" + name
            _new_json(output / relative, value)
            record[field] = relative
        except PipelineRunError:
            # The started manifest and append-only journal retain earlier evidence.
            pass


def _observe(result: dict, check: dict, scope: str, index: int | None = None,
             label: str | None = None, execution_error: bool = False) -> None:
    summary = result["summary"]
    gate = check["gate_state"]
    if _GATES[gate] > _GATES[summary["gate_state"]]:
        summary.update(gate_state=gate, exit_code=_GATES[gate])
    if gate != "clear_supported_temporal_check" and summary["first_concern"] is None:
        category = ("execution_error" if execution_error or check["source_status"] == "error"
                    else "withheld" if check["source_status"] == "withheld"
                    else "defect_candidates")
        summary["first_concern"] = {"scope": scope, "stage_index": index,
                                    "stage_label": label, "category": category}


def _runtime(start: float) -> float:
    elapsed = (time.perf_counter() - start) * 1000.0
    return max(0.0, elapsed) if math.isfinite(elapsed) else 0.0


def _snapshot_recheck(output: Path, result: dict) -> str | None:
    """Observe every captured WAV once more before storing a completed run.

    Reuse the inert bounded reader so unchanged bytes behind an observable
    link, alias, or unstable read do not count as a preserved regular file.
    This is a synchronous recheck, not an atomic capture or a file lock.
    """
    snapshots = [(output / "input/source.wav", result["source"])]
    snapshots.extend((output / stage["output_snapshot"], stage["output"])
                     for stage in result["stages"] if stage["output"] is not None)
    changed = unavailable = False
    for path, metadata in snapshots:
        try:
            digest, _, _, _ = _read_regular(path, MAX_FILE_BYTES)
            changed |= digest != metadata["sha256"]
        except (ArtifactVerificationError, OSError, ValueError, TypeError):
            unavailable = True
    return ("snapshot_recheck_failed" if unavailable else
            "snapshot_changed_during_run" if changed else None)


def run_pipeline(source: str | Path, stages: list[dict], output_dir: str | Path, *, engine: str = "v1") -> dict:
    """Run allowed transforms once in a new directory, retaining partial evidence.

    Invalid plans, unreadable input, and unsafe destinations fail before output
    creation. Once execution starts, stage failures produce a blocked incomplete
    result and leave following stages unrun. Filesystem failures never clear.
    """
    if type(engine) is not str or engine not in {"v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11"}:
        raise PipelineRunError("invalid_engine")
    source_path, output, specs, original, raw = _preflight(source, stages, output_dir)
    result = {"schema_version": 1, "engine": "audio_pipeline_regression_" + engine, "status": "completed",
              "source": original.metadata(),
              "comparison_scope": "adjacent_stage_checks_and_end_to_end", "stages": [],
              "end_to_end": None,
              "summary": {"gate_state": "clear_supported_temporal_check", "exit_code": 0,
                          "first_concern": None, "planned_stage_count": len(specs),
                          "executed_stage_count": 0, "failed_stage": None},
              "complete_audio_approval": False, "commercial_performance_validated": False,
              "network_used": False, "fault_provenance_confirmed": False}
    try:
        output.parent.mkdir(parents=True, exist_ok=True)
        _normal_parents(output)
        output.mkdir(exist_ok=False)
    except PipelineRunError:
        raise
    except (OSError, ValueError):
        raise PipelineRunError("output_directory_create_error") from None

    journal = None

    def log(event: str, **fields) -> None:
        if journal is None:
            return
        try:
            journal.write((json.dumps({"event": event, **fields}, ensure_ascii=False,
                                      allow_nan=False) + "\n").encode("utf-8"))
            journal.flush()
        except (OSError, ValueError, TypeError):
            raise PipelineRunError("output_write_error") from None

    try:
        _new_json(output / "manifest_started.json",
                  {"schema_version": 1, "engine": result["engine"], "status": "started",
                   "started_at_utc": datetime.now(timezone.utc).isoformat(),
                   "source": original.metadata(), "stages": deepcopy(specs),
                   "source_snapshot": "input/source.wav", "network_used": False})
        _normal_parents(output / "execution.jsonl")
        try:
            journal = (output / "execution.jsonl").open("xb")
        except OSError:
            raise PipelineRunError("output_write_error") from None
        log("run_started", planned_stage_count=len(specs))
        try:
            (output / "input").mkdir()
            (output / "stages").mkdir()
            _new_bytes(output / "input/source.wav", raw)
        except OSError:
            raise PipelineRunError("output_write_error") from None

        previous_snapshot, previous_metadata = "input/source.wav", original.metadata()
        combined = {"profile": "basic", "allow_gain": False,
                    "allow_resampling": False, "max_delay_ms": 1000.0}
        stopped = False
        for index, spec in enumerate(specs, start=1):
            record = _stage_record(index, spec, previous_metadata, previous_snapshot)
            result["stages"].append(record)
            if stopped:
                continue
            start, phase = time.perf_counter(), "filesystem"
            folder = f"stages/{index:03d}"
            result["summary"]["executed_stage_count"] += 1
            try:
                _normal_parents(output / folder)
                (output / folder).mkdir()
                log("stage_started", stage_index=index)
                phase = "input"
                stage_input = read_wav(output / previous_snapshot)
                if stage_input.metadata() != previous_metadata:
                    raise PipelineRunError("snapshot_changed_during_run")
                phase = "transform"
                wav_bytes, info = pipeline_transforms.execute_stage(stage_input, deepcopy(spec))
                if type(wav_bytes) is not bytes:
                    raise PipelineRunError("invalid_transform_result")
                declaration = _declaration(info, spec["kind"])
                phase = "filesystem"
                output_snapshot = folder + "/output.wav"
                _new_bytes(output / output_snapshot, wav_bytes)
                phase = "input"
                stage_output = read_wav(output / output_snapshot)
                record.update(output=stage_output.metadata(), output_snapshot=output_snapshot)
                previous_snapshot, previous_metadata = output_snapshot, stage_output.metadata()
                combined["allow_gain"] |= declaration["allow_gain"]
                combined["allow_resampling"] |= declaration["allow_resampling"]
                phase = "analysis"
                analysis, check = _analysis(output / record["input_snapshot"],
                                            output / output_snapshot, declaration,
                                            record["input"], record["output"],
                                            **({"engine": engine, "trace_path": output / folder / "trace.json"} if engine != "v1" else {}))
                record.update(status=analysis["status"], analysis=analysis, check=check,
                              reason_code=analysis["reason_code"])
                phase = "filesystem"
                if analysis["status"] == "error":
                    _save_error(output, folder, record, analysis["reason_code"])
                    stopped = True
                else:
                    for field, filename, value in (("analysis_artifact", "analysis.json", analysis),
                                                   ("check_artifact", "check.json", check)):
                        relative = folder + "/" + filename
                        _new_json(output / relative, value)
                        record[field] = relative
            except Exception as exc:
                fallback = {"analysis": "analysis_execution_error", "transform": "transform_execution_error",
                            "filesystem": "output_write_error", "input": "snapshot_read_error"}[phase]
                code = _safe_code(exc, fallback)
                _save_error(output, folder, record, code)
                stopped = True
            record["runtime_ms"] = _runtime(start)
            if stopped:
                result["status"] = "incomplete"
                result["summary"]["failed_stage"] = index
            try:
                log("stage_finished", stage_index=index, status=record["status"],
                    reason_code=record["reason_code"], gate_state=record["check"]["gate_state"])
            except PipelineRunError:
                _save_error(output, folder, record, "output_write_error")
                stopped = True
                result["status"] = "incomplete"
                result["summary"]["failed_stage"] = index
            _observe(result, record["check"], "stage", index, record["label"], record["status"] == "error")

        if not stopped:
            end = {"status": "error", "analysis": None, "check": None,
                   "analysis_artifact": None, "check_artifact": None}
            result["end_to_end"] = end
            try:
                _normal_parents(output / "end_to_end")
                (output / "end_to_end").mkdir()
                analysis, check = _analysis(output / "input/source.wav", output / previous_snapshot,
                                            combined, original.metadata(), previous_metadata,
                                            **({"engine": engine, "trace_path": output / "end_to_end/trace.json"} if engine != "v1" else {}))
                end.update(status=analysis["status"], analysis=analysis, check=check)
                if analysis["status"] == "error":
                    _save_error(output, "end_to_end", end, analysis["reason_code"])
                    result["status"] = "incomplete"
                else:
                    for field, filename, value in (("analysis_artifact", "analysis.json", analysis),
                                                   ("check_artifact", "check.json", check)):
                        relative = "end_to_end/" + filename
                        _new_json(output / relative, value)
                        end[field] = relative
                _observe(result, end["check"], "end_to_end", execution_error=end["status"] == "error")
            except Exception as exc:
                code = _safe_code(exc, "analysis_execution_error")
                _save_error(output, "end_to_end", end, code)
                _observe(result, end["check"], "end_to_end", execution_error=True)
                result["status"] = "incomplete"

        # Read the original named input again, without restoring or modifying it.
        try:
            changed = hashlib.sha256(_bounded_bytes(source_path)).hexdigest() != original.sha256
        except PipelineRunError:
            changed = True
        recheck_reason = _snapshot_recheck(output, result)
        # Keep the existing named-source reason when both the source and one
        # of our private snapshots changed during this synchronous run.
        if changed:
            recheck_reason = "source_changed_during_run"
        if recheck_reason is not None:
            if result["end_to_end"] is None:
                result["end_to_end"] = {"status": "error", "analysis": None, "check": None,
                                         "analysis_artifact": None, "check_artifact": None}
            try:
                if not os.path.lexists(output / "end_to_end"):
                    (output / "end_to_end").mkdir()
            except OSError:
                pass
            _save_error(output, "end_to_end", result["end_to_end"], recheck_reason)
            if (result["summary"]["first_concern"] is not None
                    and result["summary"]["first_concern"]["scope"] == "end_to_end"):
                result["summary"]["first_concern"] = None
            _observe(result, result["end_to_end"]["check"], "end_to_end", execution_error=True)
            result["status"] = "incomplete"
        log("run_finished", status=result["status"], gate_state=result["summary"]["gate_state"],
            exit_code=result["summary"]["exit_code"])
        _new_json(output / "run_result.json", result)
        return result
    except PipelineRunError as exc:
        # Exclusive output creation and durable prior evidence are intentionally
        # retained. There is no automatic retry, deletion, or result-as-pass.
        try:
            log("run_failed", status="incomplete", gate_state="blocked", exit_code=2,
                reason_code=exc.code)
        except PipelineRunError:
            pass
        raise
    finally:
        if journal is not None:
            journal.close()
