"""Declared whole-record Fourier resampling followed by one exact PCM edit.

This candidate models one named operation, not an inferred or fitted family
of filters.  The complete 48 kHz record is treated as periodic and projected
onto a 16 kHz Fourier grid, then rounded to PCM16 before any temporal edit.
An explanation must reproduce every processed sample.  Unsupported paths do
not fall through to a legacy engine which might ignore the declaration.
"""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import numpy as np
from scipy.fft import irfft, rfft

from . import edge_event_engine
from .analysis_scope import analysis_scope
from .audio import WavAudio, decode_wav, encode_wav, read_wav
from .engine import EngineConfig, EngineConfigError


ENGINE = "local_content_alignment_v12"
METHOD = "declared_fft_resampling_exact_pcm_forward_proof"
MODEL = "scipy_fft_periodic_48k_16k_pcm16_postedit_v1"
SOURCE_RATE = 48000
TARGET_RATE = 16000
MIN_EVENT_MS = 50
MAX_EVENT_MS = 2000
_LIMITATION = (
    "This explicitly declared model supports a complete periodic-record Fourier "
    "resampling from 48kHz to 16kHz, then nearest-ties-to-even PCM16 rounding, "
    "then at most one supported native PCM temporal edit. The source count "
    "must be divisible by three. No fitted gain, delay, filter, clipping, "
    "window, arbitrary resampler, or edit before resampling is supported. "
    "Short internal deletion or canonical later adjacent copy is limited to "
    "50-200ms; one head or tail loss is limited to 50-2000ms. Every retained "
    "output sample must match exactly and informative unique native contexts "
    "are required for an event. Coordinates refer to physical time, not "
    "individual 48kHz source samples. Signal correspondence establishes "
    "neither processing provenance, intent, whole-audio quality nor approval."
)


class ResamplingProjectionError(ValueError):
    """A fixed, private-content-free reason why the declared model cannot run."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


def validate_configuration(config: EngineConfig, resampling_model: str) -> None:
    """Reject invalid declarations before callers open either input file."""
    if (
        not isinstance(config, EngineConfig)
        or config.profile != "basic"
        or config.allow_gain is not False
        or config.allow_resampling is not True
        or type(resampling_model) is not str
        or resampling_model != MODEL
    ):
        raise EngineConfigError(
            "The v12 candidate requires basic, no gain, declared resampling, "
            f"and resampling_model {MODEL}."
        )


def render_resampling_reference(reference: WavAudio) -> WavAudio:
    """Render the fixed 3:1 real Fourier projection and commit PCM16 rounding.

    The real spectrum is truncated to the target bandwidth.  An even target
    length has one unpaired Nyquist bin: the two source bins at that frequency
    must be merged before inverse transformation.  An odd target length has
    no unpaired target Nyquist bin.  There is no padding, phase fitting, time
    shift, normalization, clipping, or conversion to a data-dependent length.
    SciPy's FFT is a numerical primitive here; signal.resample is not called.
    """
    if (
        type(reference) is not WavAudio
        or reference.sample_rate_hz != SOURCE_RATE
        or len(reference.samples) % 3
    ):
        raise ResamplingProjectionError("resampler_unsupported_input_path")
    count = len(reference.samples) // 3
    spectrum = rfft(reference.samples)[: count // 2 + 1].copy()
    if count % 2 == 0:
        spectrum[-1] *= 2.0
    projected = irfft(spectrum / 3.0, n=count, overwrite_x=True)
    rounded = np.rint(projected * 32768.0)
    if (
        not np.all(np.isfinite(rounded))
        or np.any(rounded < -32768)
        or np.any(rounded > 32767)
    ):
        raise ResamplingProjectionError("resampler_projection_out_of_range")
    return decode_wav(encode_wav(rounded / 32768.0, TARGET_RATE))


def _initial_result(reference: WavAudio, processed: WavAudio,
                    config: EngineConfig) -> dict:
    return {
        "schema_version": 1,
        "engine": ENGINE,
        "status": "withheld",
        "content_preservation_status": "withheld",
        "reason_code": None,
        "events": None,
        "complete_audio_approval": False,
        "commercial_performance_validated": False,
        "reference": reference.metadata(),
        "processed": processed.metadata(),
        "resampling_reference": None,
        "proof_kind": "unproved",
        "configuration": {
            "profile": config.profile,
            "allow_gain": config.allow_gain,
            "allow_resampling": config.allow_resampling,
            "max_delay_ms": config.max_delay_ms,
            "resampling_model": MODEL,
        },
        "analysis": {
            "sample_rate_hz": TARGET_RATE,
            "hop_ms": 1000 / TARGET_RATE,
            "method": METHOD,
            "minimum_event_duration_ms": MIN_EVENT_MS,
            "maximum_cumulative_edit_shift_ms": MAX_EVENT_MS,
            "diagnostic_rules_not_calibrated_probabilities": True,
        },
        "diagnostics": {},
        "limitations": [
            "Diagnostic candidates, not complete audio approval or fault provenance.",
            _LIMITATION,
        ],
    }


@analysis_scope
def analyze_buffers_with_trace(reference: WavAudio, processed: WavAudio,
                               config: EngineConfig | None = None, *,
                               resampling_model: str) -> tuple[dict, dict]:
    settings = config if config is not None else EngineConfig()
    validate_configuration(settings, resampling_model)
    if type(reference) is not WavAudio or type(processed) is not WavAudio:
        raise EngineConfigError("The declared resampler requires validated PCM16 WAV inputs.")
    result = _initial_result(reference, processed, settings)
    trace = {
        "schema_version": 1,
        "engine": ENGINE,
        "analysis_engine": ENGINE,
        "method": METHOD,
        "proof_path": "declared_fft_postedit",
        "reference_sha256": reference.sha256,
        "processed_sha256": processed.sha256,
        "resampling_model": MODEL,
        "proof_attempted": False,
        "proof_proved": False,
        "proof_kind": "unproved",
        "every_output_sample_exact": False,
        "reason_code": None,
        "result_status": "withheld",
    }

    def failure(reason: str) -> tuple[dict, dict]:
        result["reason_code"] = reason
        trace["reason_code"] = reason
        return result, trace

    if processed.sample_rate_hz != TARGET_RATE:
        return failure("resampler_unsupported_input_path")
    try:
        canonical = render_resampling_reference(reference)
    except ResamplingProjectionError as exc:
        return failure(exc.code)
    result["resampling_reference"] = canonical.metadata()
    trace.update(
        proof_attempted=True,
        canonical_reference_sha256=canonical.sha256,
        canonical_reference_sample_count=len(canonical.samples),
        transform_order="whole_record_fft_then_pcm16_then_postedit",
        spectral_nyquist_bin_merged=len(canonical.samples) % 2 == 0,
        source_sample_count=len(reference.samples),
        target_sample_count=len(canonical.samples),
    )
    if np.array_equal(canonical.samples, processed.samples):
        result.update(
            status="analyzed",
            content_preservation_status="no_supported_defect_candidates",
            events=[],
            proof_kind="exact_resampling_only",
            alignment_segments=[],
            diagnostics={
                "gain_estimate": 1.0,
                "applied_gain": 1.0,
                "matched_normalized_rmse": 0.0,
                "matched_analysis_samples": len(canonical.samples),
                "anchor_run_count": 0,
                # Equality certifies the complete declared transform.  No
                # local correlation windows were measured on this path.
                "minimum_local_correlation": None,
                "normalized_path_cost": 0.0,
            },
        )
    else:
        difference = abs(len(canonical.samples) - len(processed.samples))
        if not MIN_EVENT_MS * TARGET_RATE <= difference * 1000 <= MAX_EVENT_MS * TARGET_RATE:
            return failure("resampler_no_exact_supported_postedit_proof")
        native_settings = EngineConfig(profile="basic", allow_gain=False,
                                       allow_resampling=False,
                                       max_delay_ms=settings.max_delay_ms)
        native, native_trace = edge_event_engine.analyze_buffers_with_trace(
            canonical, processed, native_settings)
        # v11 has inherited heuristic and exact paths.  Only a new exact
        # native certificate is eligible; inherited normal/event results are
        # deliberately NOT an escape from this declared resampler contract.
        if native_trace.get("endpoint_loss_proved") is True:
            proof_kind = "native_endpoint_loss"
            proved_trace = native_trace
        else:
            child_trace = native_trace.get("inherited_v10_trace", {})
            proof_kind = "native_short_event"
            proved_trace = child_trace
        trace["postedit_trace"] = deepcopy(native_trace)
        if not (
            native["status"] == "analyzed"
            and native["content_preservation_status"] == "defect_candidates"
            and type(native.get("events")) is list
            and len(native["events"]) == 1
            and proved_trace.get("every_output_sample_exact") is True
            and proved_trace.get("all_retained_native_samples_exact") is True
            and (proof_kind == "native_endpoint_loss"
                 or proved_trace.get("short_event_proved") is True)
        ):
            return failure("resampler_no_exact_supported_postedit_proof")
        result.update(
            status="analyzed",
            content_preservation_status="defect_candidates",
            events=deepcopy(native["events"]),
            diagnostics=deepcopy(native["diagnostics"]),
            alignment_segments=deepcopy(native["alignment_segments"]),
            proof_kind=proof_kind,
        )
    trace.update(
        proof_proved=True,
        proof_kind=result["proof_kind"],
        result_status="analyzed",
        every_output_sample_exact=True,
        exact_output_sample_count=len(processed.samples),
        edit_intent_or_cause_established=False,
    )
    return result, trace


def analyze_buffers(reference: WavAudio, processed: WavAudio,
                    config: EngineConfig | None = None, *,
                    resampling_model: str) -> dict:
    return analyze_buffers_with_trace(
        reference, processed, config, resampling_model=resampling_model)[0]


def analyze_wavs_with_trace(reference_path: str | Path, processed_path: str | Path,
                            config: EngineConfig | None = None, *,
                            resampling_model: str) -> tuple[dict, dict]:
    settings = config if config is not None else EngineConfig()
    validate_configuration(settings, resampling_model)
    return analyze_buffers_with_trace(
        read_wav(reference_path), read_wav(processed_path), settings,
        resampling_model=resampling_model)
