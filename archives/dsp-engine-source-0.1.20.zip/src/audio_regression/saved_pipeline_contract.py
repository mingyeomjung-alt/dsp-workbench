"""Strict inert contract for audits of caller-ordered saved audio outputs.

This validates saved diagnostics only. It neither opens referenced snapshots nor
confirms that the caller's files came from the claimed processing order.
"""

from __future__ import annotations

import json
from pathlib import Path

from . import pipeline_reporting as _native


MAX_SAVED_PIPELINE_RESULT_BYTES = 4 * 1024 * 1024
ENGINE = "audio_saved_pipeline_audit_v1"
_ANALYSIS_ENGINES = {ENGINE: "local_content_alignment_v1",
                     "audio_saved_pipeline_audit_v2": "local_content_alignment_v2",
                     "audio_saved_pipeline_audit_v3": "local_content_alignment_v3",
                     "audio_saved_pipeline_audit_v4": "local_content_alignment_v4",
                     "audio_saved_pipeline_audit_v5": "local_content_alignment_v5",
                     "audio_saved_pipeline_audit_v6": "local_content_alignment_v6",
                     "audio_saved_pipeline_audit_v7": "local_content_alignment_v7",
                     "audio_saved_pipeline_audit_v8": "local_content_alignment_v8",
                     "audio_saved_pipeline_audit_v9": "local_content_alignment_v9",
                     "audio_saved_pipeline_audit_v10": "local_content_alignment_v10",
                     "audio_saved_pipeline_audit_v11": "local_content_alignment_v11"}
_TOP = {"schema_version", "engine", "status", "comparison_scope", "source", "stages",
        "end_to_end", "input_recheck", "summary", "complete_audio_approval",
        "commercial_performance_validated", "network_used", "fault_provenance_confirmed",
        "caller_order_verified"}
_STAGE = {"index", "label", "declaration", "input", "output", "input_snapshot",
          "output_snapshot", "status", "analysis", "check", "reason_code",
          "analysis_artifact", "check_artifact", "runtime_ms"}
_END = {"status", "analysis", "check", "analysis_artifact", "check_artifact"}
_SUMMARY = {"gate_state", "exit_code", "first_concern", "planned_stage_count",
            "checked_stage_count", "failed_stage"}
_DECLARATION = {"profile", "allow_gain", "allow_resampling", "max_delay_ms"}
_GATES = {0: "clear_supported_temporal_check", 1: "review_required", 2: "blocked"}
_RECHECK_ERRORS = {"changed": "input_files_changed", "unavailable": "input_files_recheck_failed"}


class SavedPipelineContractError(ValueError):
    """Stable, non-private saved-result rejection code."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__("Saved audio pipeline result violates its contract.")


def _reject(code: str) -> None:
    raise SavedPipelineContractError(code)


def _declaration(value: object) -> dict:
    declaration = _native._fields(value, _DECLARATION, "invalid_stage_declaration")
    if (declaration["profile"] != "basic"
            or any(type(declaration[name]) is not bool for name in ("allow_gain", "allow_resampling"))):
        _reject("invalid_stage_declaration")
    if _native._number(declaration["max_delay_ms"], "invalid_stage_declaration") != 1000.0:
        _reject("invalid_stage_declaration")
    return declaration


def _mixed_declaration(value: object, engine: object) -> dict:
    if type(engine) is not str or engine not in {"v" + str(i) for i in range(1, 13)}:
        _reject("unsupported_analysis_engine")
    expected = _DECLARATION | ({"resampling_model"} if engine == "v12" else set())
    declaration = _native._fields(value, expected, "invalid_stage_declaration")
    basic = {key: declaration[key] for key in _DECLARATION}
    _declaration(basic)
    if engine == "v12":
        from .resampler_engine import MODEL
        if (declaration["allow_gain"] is not False or declaration["allow_resampling"] is not True
                or type(declaration["resampling_model"]) is not str
                or declaration["resampling_model"] != MODEL):
            _reject("invalid_resampling_model_declaration")
    return declaration


def _explicit_configuration(analysis: dict, declaration: dict) -> None:
    if analysis["status"] != "error" and not _native._same_json(analysis["configuration"], declaration):
        _reject("inconsistent_analysis_configuration")


def _artifacts(item: dict, folder: str) -> None:
    names = ("error.json", "error_check.json") if item["status"] == "error" else ("analysis.json", "check.json")
    for field, filename in zip(("analysis_artifact", "check_artifact"), names):
        if item[field] is None and item["status"] == "error":
            continue
        if _native._relative_path(item[field]) != folder + "/" + filename:
            _reject("inconsistent_analysis_artifact")


def _validate(value: object) -> dict:
    _native._tree(value)
    result = _native._fields(value, _TOP, "invalid_saved_pipeline_structure")
    mixed = result.get("schema_version") == 2 and result.get("engine") == "audio_saved_pipeline_audit_mixed_v1"
    if type(result["schema_version"]) is not int or result["schema_version"] != (2 if mixed else 1):
        _reject("unsupported_schema_version")
    if type(result["engine"]) is not str or (not mixed and result["engine"] not in _ANALYSIS_ENGINES):
        _reject("unsupported_engine")
    analysis_engine = None if mixed else _ANALYSIS_ENGINES[result["engine"]]
    if type(result["status"]) is not str or result["status"] not in {"completed", "incomplete"}:
        _reject("unsupported_saved_pipeline_status")
    if result["comparison_scope"] != "adjacent_stage_checks_and_end_to_end":
        _reject("unsupported_comparison_scope")
    for name in ("complete_audio_approval", "commercial_performance_validated", "network_used",
                 "fault_provenance_confirmed", "caller_order_verified"):
        if result[name] is not False:
            _reject("invalid_approval_claim")
    source = _native._metadata(result["source"])
    stages = result["stages"]
    if type(stages) is not list or not 1 <= len(stages) <= 8:
        _reject("invalid_saved_pipeline_stages")

    recheck = _native._fields(result["input_recheck"], {"status", "file_indices"}, "invalid_input_recheck")
    if (type(recheck["status"]) is not str
            or recheck["status"] not in {"unchanged", "changed", "unavailable"}
            or type(recheck["file_indices"]) is not list):
        _reject("invalid_input_recheck")
    indices = recheck["file_indices"]
    for index in indices:
        _native._integer(index, "invalid_input_recheck", 0, len(stages))
    if indices != sorted(set(indices)) or bool(indices) != (recheck["status"] != "unchanged"):
        _reject("invalid_input_recheck")

    latest = source
    failed_stage = None
    checked = worst = 0
    first_concern = None
    allow_gain = allow_resampling = False
    for index, item in enumerate(stages, 1):
        stage = _native._fields(item, _STAGE | ({"analysis_engine"} if mixed else set()), "invalid_saved_pipeline_stage")
        if type(stage["index"]) is not int or stage["index"] != index:
            _reject("inconsistent_stage_index")
        _native._label(stage["label"])
        declaration = (_mixed_declaration(stage["declaration"], stage["analysis_engine"])
                       if mixed else _declaration(stage["declaration"]))
        allow_gain |= declaration["allow_gain"]
        allow_resampling |= declaration["allow_resampling"]
        _native._number(stage["runtime_ms"], "invalid_stage_runtime")
        if _native._metadata(stage["input"]) != latest:
            _reject("broken_saved_pipeline_chain")
        output = _native._metadata(stage["output"])
        if (_native._relative_path(stage["input_snapshot"]) != f"inputs/{index - 1:03d}.wav"
                or _native._relative_path(stage["output_snapshot"]) != f"inputs/{index:03d}.wav"):
            _reject("broken_saved_snapshot_chain")
        latest = output
        status = stage["status"]
        if type(status) is not str or status not in {"analyzed", "withheld", "error", "not_run"}:
            _reject("unsupported_stage_status")
        if status == "not_run":
            if (failed_stage is None or stage["runtime_ms"] != 0
                    or stage["reason_code"] != "prior_stage_analysis_error"
                    or any(stage[name] is not None for name in
                           ("analysis", "check", "analysis_artifact", "check_artifact"))):
                _reject("inconsistent_not_run_stage")
            continue
        if failed_stage is not None:
            _reject("analysis_after_failed_stage")
        checked += 1
        _artifacts(stage, f"stages/{index:03d}")
        check = _native._analysis_check(stage["analysis"], stage["check"], status,
                                        stage["input"], output,
                                        "local_content_alignment_" + stage["analysis_engine"] if mixed else analysis_engine)
        if mixed:
            _explicit_configuration(stage["analysis"], declaration)
        else:
            _native._configuration(stage["analysis"], declaration["allow_gain"], declaration["allow_resampling"])
        if status == "analyzed":
            if stage["reason_code"] is not None:
                _reject("inconsistent_stage_reason")
        else:
            _native._reason(stage["reason_code"])
            if stage["reason_code"] != stage["analysis"]["reason_code"]:
                _reject("inconsistent_stage_reason")
        worst = max(worst, check["exit_code"])
        first_concern = first_concern or _native._concern("stage", stage, check, status)
        if status == "error":
            failed_stage = index

    end = result["end_to_end"]
    end_error = False
    if end is None:
        if failed_stage is None or recheck["status"] != "unchanged":
            _reject("missing_end_to_end_check")
    else:
        end = _native._fields(end, _END | ({"analysis_engine", "declaration"} if mixed else set()), "invalid_end_to_end_check")
        if mixed:
            end_declaration = _mixed_declaration(end["declaration"], end["analysis_engine"])
        if type(end["status"]) is not str or end["status"] not in {"analyzed", "withheld", "error"}:
            _reject("unsupported_end_to_end_status")
        _artifacts(end, "end_to_end")
        check = _native._analysis_check(end["analysis"], end["check"], end["status"], source, latest,
                                        "local_content_alignment_" + end["analysis_engine"] if mixed else analysis_engine)
        if mixed:
            _explicit_configuration(end["analysis"], end_declaration)
        else:
            _native._configuration(end["analysis"], allow_gain, allow_resampling)
        reason = end["analysis"].get("reason_code")
        if recheck["status"] != "unchanged":
            if end["status"] != "error" or reason != _RECHECK_ERRORS[recheck["status"]]:
                _reject("inconsistent_input_recheck_error")
        elif reason in set(_RECHECK_ERRORS.values()):
            _reject("inconsistent_input_recheck_error")
        if failed_stage is not None and (end["status"] != "error"
                                         or reason not in set(_RECHECK_ERRORS.values())):
            _reject("end_to_end_after_failed_stage")
        worst = max(worst, check["exit_code"])
        first_concern = first_concern or _native._concern("end_to_end", None, check, end["status"])
        end_error = end["status"] == "error"
    expected_status = "incomplete" if failed_stage is not None or end_error else "completed"
    if result["status"] != expected_status:
        _reject("inconsistent_saved_pipeline_status")
    summary = _native._fields(result["summary"], _SUMMARY, "invalid_saved_pipeline_summary")
    _native._integer(summary["exit_code"], "invalid_summary_exit_code", 0, 2)
    _native._integer(summary["planned_stage_count"], "invalid_summary_count", 1, 8)
    _native._integer(summary["checked_stage_count"], "invalid_summary_count", 1, 8)
    if summary["failed_stage"] is not None:
        _native._integer(summary["failed_stage"], "invalid_failed_stage", 1, len(stages))
    if summary["first_concern"] is not None:
        concern = _native._fields(summary["first_concern"], {"scope", "stage_index", "stage_label", "category"},
                                  "invalid_first_concern")
        if concern["stage_label"] is not None:
            _native._label(concern["stage_label"])
    if (summary["exit_code"] != worst or summary["gate_state"] != _GATES[worst]
            or not _native._same_json(summary["first_concern"], first_concern)
            or summary["failed_stage"] != failed_stage or summary["planned_stage_count"] != len(stages)
            or summary["checked_stage_count"] != checked):
        _reject("inconsistent_saved_pipeline_summary")
    return result


def validate_saved_pipeline_result(value: object) -> dict:
    """Return the original validated result without inspecting referenced files."""
    try:
        return _validate(value)
    except _native.PipelineReportError as exc:
        raise SavedPipelineContractError(exc.code) from None


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    value = {}
    for key, item in pairs:
        if key in value:
            _reject("duplicate_json_key")
        value[key] = item
    return value


def _invalid_constant(_: str) -> None:
    _reject("non_finite_metric")


def load_saved_pipeline_result(path: str | Path) -> dict:
    """Load bounded strict UTF-8 JSON, never following its snapshot references."""
    try:
        with Path(path).open("rb") as stream:
            raw = stream.read(MAX_SAVED_PIPELINE_RESULT_BYTES + 1)
    except (OSError, ValueError, TypeError):
        raise SavedPipelineContractError("result_file_read_error") from None
    if len(raw) > MAX_SAVED_PIPELINE_RESULT_BYTES:
        _reject("result_file_too_large")
    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object,
                           parse_constant=_invalid_constant)
    except SavedPipelineContractError:
        raise
    except (UnicodeError, ValueError, RecursionError, OverflowError):
        raise SavedPipelineContractError("invalid_result_json") from None
    return validate_saved_pipeline_result(value)
