"""Validated, offline regression-suite presentation; no audio or path reopening."""

from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path

from .check_policy import check_result
from .regression_suite_contract import validate_suite_result
from .reporting import _STYLE as _ANALYSIS_STYLE, _e, render_html


_STYLE = _ANALYSIS_STYLE + """
.suite-metrics{grid-template-columns:repeat(3,1fr)}.suite-states{display:grid;grid-template-columns:1fr 1fr;gap:14px}
.suite-state{background:#f4f7fb;border:1px solid var(--line);border-radius:10px;padding:16px}.suite-state b{display:block;font-size:20px;margin-top:5px}
.case-status{display:flex;gap:8px;flex-wrap:wrap}.case-heading{scroll-margin-top:20px}.suite-case>h2{margin-top:5px}.suite-case table td:first-child{width:auto}
.suite-index td:first-child{width:auto}.suite-index a{color:var(--blue);font-weight:700;text-decoration:underline}.delta-list{margin:8px 0 16px}
.analysis-detail{border:1px solid var(--line);border-radius:12px;padding:18px;background:#f7f9fc;margin:14px 0}.analysis-detail>header{margin-bottom:14px}
.analysis-detail h1{font-size:23px}.analysis-detail .card{padding:18px}.analysis-detail .summary h2{font-size:21px}.analysis-detail .metrics{grid-template-columns:repeat(3,1fr)}
@media(max-width:700px){.suite-metrics,.suite-states,.analysis-detail .metrics{grid-template-columns:1fr}.analysis-detail{padding:10px}}
"""
_STYLE_DIGEST = base64.b64encode(hashlib.sha256(_STYLE.encode("utf-8")).digest()).decode("ascii")
_CSP = ("default-src 'none'; style-src 'sha256-" + _STYLE_DIGEST
        + "'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'; object-src 'none'")
_GATES = {
    "clear_supported_temporal_check": "지원 범위의 시간적 후보 없음",
    "review_required": "현재 결함 후보 검토 필요",
    "blocked": "현재 판단 보류·검사 오류",
}
_REGRESSIONS = {
    "new_candidates": "신규 후보 관측 · 검토 필요",
    "no_new_candidates_observed": "신규 후보 미관측 · 품질 승인 아님",
    "inconclusive": "버전 간 변화 비교 불가",
}
_STATUSES = {"completed": "검사 실행 완료", "error": "실행 오류", "not_run": "미실행"}
_AXES = {
    "raw_reference_time_ms": "실제 원본 시간축 (ms)",
    "canonical_reference_time_ms": "선언한 변환의 비교용 원본 시간축 (ms) · 원본 샘플 위치 아님",
    None: "공통 좌표 미확정",
}
_INTEGRITY = {"verified": "기록한 입력·스냅샷 보존 확인", "failed": "입력 또는 스냅샷 보존 실패", "not_checked": "입력 보존 확인 미완료"}


def _indices(values: list[int]) -> str:
    return ", ".join(str(value + 1) for value in values) or "없음"


def _analysis_detail(value: dict | None, title: str) -> str:
    if value is None:
        return f'<p class="scope muted">{_e(title)} 분석 결과 없음. 사건 없음으로 해석하지 않습니다.</p>'
    # This is generated only by the strict, existing analysis renderer. Its data
    # strings are escaped and local paths redacted. Never accept stored HTML,
    # follow artifact paths, or reopen referenced WAV files here.
    document = render_html(value)
    body = document.partition("<body><main>")[2].rpartition("</main></body>")[0]
    if not body:
        raise RuntimeError("Analysis renderer returned an unexpected static document.")
    return (f'<details><summary>{_e(title)} · 저장된 분석 상세</summary>'
            f'<div class="analysis-detail">{body}</div></details>')


def _priority(case: dict) -> int:
    if case["status"] != "completed":
        return 0
    if case["delta"]["status"] == "inconclusive":
        return 1
    if case["delta"]["new_candidates"]:
        return 2
    if case["delta"]["persistent_pairs"]:
        return 3
    return 4


def _case_gate(case: dict) -> str:
    analysis = case["candidate_analysis"]
    return "blocked" if case["status"] != "completed" or analysis is None else check_result(analysis)["gate_state"]


def _delta_description(delta: dict) -> str:
    if delta["status"] == "inconclusive":
        return "비교 불가 · 새 후보 없음으로 처리하지 않음"
    return (f'신규 {len(delta["new_candidates"])} · 유지 {len(delta["persistent_pairs"])}'
            f' · 이번 미관측 {len(delta["not_observed_now"])}')


def _case_article(case: dict, manifest_case: dict, index: int) -> str:
    delta = case["delta"]
    gate = _case_gate(case)
    reason = case["reason_code"] or delta["reason_code"]
    pairs = ", ".join(
        f'기준 {pair["baseline_event_index"] + 1} ↔ 새 출력 {pair["candidate_event_index"] + 1}'
        for pair in delta["persistent_pairs"]
    ) or "없음"
    change = (
        '<dl class="delta-list"><dt>신규 후보 · new</dt><dd>새 출력 사건 '
        + _e(_indices(delta["new_candidates"]))
        + '</dd><dt>유지 후보 · persistent</dt><dd>' + _e(pairs)
        + '</dd><dt>이번 미관측 · not_observed_now</dt><dd>기준 사건 '
        + _e(_indices(delta["not_observed_now"])) + '</dd></dl>'
        if delta["status"] == "compared" else
        '<p class="notice">inconclusive · 좌표·분석·보존 조건이 충분하지 않아 사건을 신규·유지·이번 미관측으로 배정하지 않았습니다.</p>'
    )
    configuration = json.dumps(manifest_case["configuration"], ensure_ascii=False, sort_keys=True, allow_nan=False)
    return (
        f'<article class="card suite-case"><div class="eyebrow">CASE {index + 1}</div>'
        f'<h2 class="case-heading" id="case-{index}">{_e(case["case_id"])}</h2>'
        f'<div class="case-status"><span class="badge">{_e(_STATUSES[case["status"]])}</span>'
        f'<span class="badge">{_e(_GATES[gate])}</span></div>'
        '<h3>현재 새 출력 검사</h3>'
        f'<p>{_e(_GATES[gate])}</p><h3>기준 대비 사건 변화</h3>'
        f'<p><strong>{_e(_delta_description(delta))}</strong></p>'
        f'<p class="scope muted">대조 좌표: {_e(_AXES[delta["coordinate_axis"]])}. 사건 번호는 각 상세 분석의 1번부터 시작합니다.</p>'
        + change
        + (f'<p class="scope">보류·오류 코드: <code>{_e(reason)}</code></p>' if reason is not None else "")
        + '<p class="scope muted">유지된 후보는 정상으로 바뀐 것이 아닙니다. 이번 미관측은 실제 결함 수정·음질 개선의 확정이 아닙니다. 의도적인 편집 여부도 판정하지 않습니다.</p>'
        + '<details><summary>이 사례의 고정 검사 설정</summary><p><code>' + _e(configuration) + '</code></p></details>'
        + _analysis_detail(case["baseline_analysis"], "기준 출력")
        + _analysis_detail(case["candidate_analysis"], "새 출력") + '</article>'
    )


def render_suite_html(value: dict) -> str:
    """Render validated embedded JSON only, with no file/audio/network access."""
    validate_suite_result(value)
    summary = value["summary"]
    manifest = value["manifest"]
    manifest_by_id = {case["case_id"]: case for case in manifest["cases"]}
    ordered = sorted(enumerate(value["cases"]), key=lambda item: (_priority(item[1]), item[0]))
    rows = []
    articles = []
    for index, case in ordered:
        rows.append(
            f'<tr><td><a href="#case-{index}">{_e(case["case_id"])}</a></td>'
            f'<td>{_e(_STATUSES[case["status"]])}</td><td>{_e(_GATES[_case_gate(case)])}</td>'
            f'<td>{_e(_delta_description(case["delta"]))}</td></tr>'
        )
        articles.append(_case_article(case, manifest_by_id[case["case_id"]], index))
    metrics = (
        ("시험 사례", summary["case_count"]), ("신규 후보", summary["new_candidate_count"]),
        ("유지 후보", summary["persistent_candidate_count"]), ("이번 미관측", summary["not_observed_now_count"]),
        ("변화 비교 불가 사례", summary["inconclusive_case_count"]), ("실행 오류·미실행", summary["error_count"] + summary["not_run_count"]),
    )
    metric_html = "".join(f'<div class="metric"><span>{_e(label)}</span><b>{_e(count)}</b></div>' for label, count in metrics)
    issues = value["input_integrity"]["issues"]
    issue_html = ("<ul>" + "".join(
        '<li>' + _e(item["case_id"] or "시험 목록") + ' · ' + _e(item["role"]) + ' · '
        + _e(item["scope"]) + ' · <code>' + _e(item["reason_code"]) + '</code></li>'
        for item in issues
    ) + "</ul>" if issues else '<p class="scope muted">보존 오류가 기록되지 않았습니다. 보고서 생성 시 실제 파일을 다시 확인하지 않습니다.</p>')
    return (
        '<!doctype html>\n<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
        f'<meta http-equiv="Content-Security-Policy" content="{_CSP}">'
        '<title>DSP 시험 묶음 회귀 검사</title><style>' + _STYLE + '</style></head><body><main>'
        '<header><div class="eyebrow">DSP WORKBENCH / SAVED WAV REGRESSION SUITE</div><h1>시험 묶음 회귀 검사</h1>'
        '<p class="muted">기준 버전과 새 버전에서 관측한 시간적 후보를 대조합니다. 검사 완료와 음질 승인은 다릅니다.</p></header>'
        '<section class="card"><h2>' + _e(manifest["suite_id"]) + '</h2>'
        '<dl><dt>기준 버전</dt><dd>' + _e(manifest["baseline_version"]) + '</dd><dt>새 버전</dt><dd>' + _e(manifest["candidate_version"])
        + '</dd><dt>실행 순회</dt><dd>' + ("모든 사례 순회 완료 · 분석 성공과 다름" if value["execution_complete"] else "순회 미완료 · 미실행 또는 중단 있음")
        + '</dd><dt>실행한 도구 버전</dt><dd>' + _e(value["producer_version"])
        + '</dd><dt>시험 목록 SHA-256</dt><dd><code class="hash">' + _e(value["manifest_sha256"]) + '</code></dd></dl></section>'
        '<section class="card"><h2>서로 다른 두 가지 상태</h2><div class="suite-states">'
        '<div class="suite-state">현재 새 출력 검사<b>' + _e(_GATES[summary["current_gate_state"]])
        + '</b></div><div class="suite-state">기준 대비 변화<b>' + _e(_REGRESSIONS[summary["regression_state"]])
        + '</b></div></div><p>시험 종료 코드 <strong>' + _e(summary["exit_code"])
        + '</strong> · 기존 후보가 유지되면 신규 후보가 없어도 정상 통과로 바꾸지 않습니다.</p>'
        '<div class="metrics suite-metrics">' + metric_html + '</div></section>'
        '<aside class="notice"><strong>해석 제한</strong>검출 범위 안의 시간적 내용 변화만 다룹니다. 발음·자연스러움·전체 음질·원인·상용 정확도는 승인하지 않습니다. '
        '판단 보류는 성공이 아니며, 이번 미관측은 개선 확정이 아닙니다. 기준 출력도 오류를 포함할 수 있습니다. 이 보고서는 저장된 JSON만 표시합니다.</aside>'
        '<section class="card"><h2>검토 우선 목록</h2><p class="scope muted">실행 문제 → 변화 비교 불가 → 신규 후보 → 유지 후보 순서입니다.</p>'
        '<div class="table-wrap"><table class="suite-index"><thead><tr><th>사례</th><th>실행 상태</th><th>현재 검사</th><th>기준 대비 변화</th></tr></thead><tbody>'
        + "".join(rows) + '</tbody></table></div></section>'
        '<section class="card"><h2>입력 보존 기록</h2><p><strong>' + _e(_INTEGRITY[value["input_integrity"]["status"]])
        + '</strong></p>' + issue_html + '</section>' + "".join(articles)
        + '<footer>로컬 정적 보고서 · JavaScript·외부 요청·오디오 재분석 없음 · 경로·오디오를 다시 열지 않음 · 기준 자동 갱신 없음</footer></main></body></html>\n'
    )


def write_suite_html(value: dict, path: str | Path) -> None:
    """Validate before creating a new report; preserve every existing output."""
    rendered = render_suite_html(value)
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(rendered)
