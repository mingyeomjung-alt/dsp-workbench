"""Frozen M3 comparison controls, not typed local-defect detectors.

The controls measure an anomaly in a file pair. They cannot name or localize a
deletion or repetition, and deliberately return ``events=None``. Their anomaly
task must be scored separately from the engine's event-localization task.

All methods use the same declared analysis profile as the candidate. The
constant-offset ablation additionally uses its feature representation and raw
anchor/window checks, but never runs edit alignment or repairs a local offset.
Rules below are fixed diagnostic rules, not thresholds selected on final data.
"""

from __future__ import annotations

import math

import numpy as np

from .audio import AudioInputError, WavAudio
from .baseline import (
    ANALYSIS_RATE_HZ, MIN_CORRELATION, MIN_PEAK_MARGIN, PEAK_EXCLUSION_MS,
    _lag_scores,
)
from .engine import EngineConfig, EngineConfigError, HOP, _anchor, _corr
from .features import extract_features
from .profiles import prepare_analysis


BASELINE_METHODS = frozenset({"direct_difference", "global_only", "no_local_alignment"})
ANOMALY_NRMSE_BY_PROFILE = {"basic": 0.08, "telephone": 0.25}
DURATION_TOLERANCE_MS = 40.0


def _comparison_metrics(x: np.ndarray, y: np.ndarray, allow_gain: bool) -> dict:
    count = min(len(x), len(y))
    a, b = x[:count], y[:count]
    energy = float(np.dot(a, a))
    gain = float(np.dot(a, b) / max(energy, 1e-16))
    applied = gain if allow_gain else 1.0
    residual = float(np.dot(b - applied * a, b - applied * a))
    return {
        "normalized_rmse": math.sqrt(residual / max(applied * applied * energy, 1e-16)),
        "rmse": math.sqrt(residual / count),
        "gain_estimate": gain,
        "applied_gain": applied,
        "sample_count": count,
        "comparison_duration_ms": count * 1000 / ANALYSIS_RATE_HZ,
    }


def _global_candidate(x: np.ndarray, y: np.ndarray, max_delay_ms: float) -> dict:
    lags, scores, starts, ends = _lag_scores(x, y, max_delay_ms)
    if not len(scores) or not np.any(np.isfinite(scores)):
        return {"reason_code": "insufficient_overlap"}
    index = int(np.argmax(scores))
    lag, score = int(lags[index]), float(scores[index])
    exclusion = round(PEAK_EXCLUSION_MS * ANALYSIS_RATE_HZ / 1000)
    rivals = scores[(np.abs(lags - lag) > exclusion) & np.isfinite(scores)]
    alternate = float(np.max(rivals)) if len(rivals) else None
    margin = score - alternate if alternate is not None else None
    result = {
        "reason_code": None, "lag_samples": lag,
        "reference_start_sample": int(starts[index]),
        "reference_end_sample": int(ends[index]),
        "correlation": score, "alternative_correlation": alternate,
        "peak_margin": margin,
    }
    if score < MIN_CORRELATION:
        result["reason_code"] = "weak_correspondence"
    elif margin is not None and margin < MIN_PEAK_MARGIN:
        result["reason_code"] = "ambiguous_alignment"
    elif max_delay_ms > 0 and abs(lag) == round(max_delay_ms * ANALYSIS_RATE_HZ / 1000):
        result["reason_code"] = "delay_at_search_boundary"
    return result


def _constant_offset_checks(x: np.ndarray, y: np.ndarray, candidate: dict, profile: str) -> dict:
    """Shared features and anchors at one constant offset; no local path."""
    lag = candidate["lag_samples"]
    first, last = candidate["reference_start_sample"], candidate["reference_end_sample"]
    reference_track, processed_track = extract_features(x), extract_features(y)
    reference_frames = np.arange(math.ceil(first / HOP), last // HOP, dtype=np.int64)
    processed_frames = reference_frames + round(lag / HOP)
    valid = (processed_frames >= 0) & (processed_frames < len(processed_track.features))
    reference_frames, processed_frames = reference_frames[valid], processed_frames[valid]
    active = (
        (reference_track.frame_rms[reference_frames] >= 1e-5)
        & (processed_track.frame_rms[processed_frames] >= 1e-5)
    )
    products = np.sum(
        reference_track.features[reference_frames[active]]
        * processed_track.features[processed_frames[active]], axis=1,
    )
    detail = {
        "feature_method": "shared_log_band_shape_at_constant_offset",
        "constant_offset_feature_frame_count": int(len(reference_frames)),
        "constant_offset_active_feature_frame_count": int(np.count_nonzero(active)),
        "mean_constant_offset_feature_cost": (
            float(np.mean(1.0 - np.clip(products, -1, 1))) if len(products) else None
        ),
        "local_alignment_enabled": False,
        "minimum_local_correlation": None,
        "anchor_offset_samples": None,
        "reason_code": None,
    }
    if not len(reference_frames):
        detail["reason_code"] = "insufficient_unambiguous_anchors"
        return detail
    run = {
        "kind": "match", "reference_start_frame": int(reference_frames[0]),
        "reference_end_frame": int(reference_frames[-1]) + 1,
        "processed_start_frame": int(processed_frames[0]),
        "processed_end_frame": int(processed_frames[-1]) + 1,
    }
    minimum_corr = 0.90 if profile == "basic" else 0.82
    anchor = _anchor(run, x, y, minimum_corr)
    if anchor is None or abs(anchor["offset_samples"] - lag) > 24:
        detail["reason_code"] = "insufficient_unambiguous_anchors"
        return detail
    detail["anchor_offset_samples"] = anchor["offset_samples"]
    # Edge margins match the candidate's retained-run verification. No local
    # re-alignment, gain fitting per window, or substituted waveform is used.
    first, last = first + 320, last - 320
    width = min(960, last - first)
    if width <= 0:
        detail["reason_code"] = "insufficient_overlap"
        return detail
    positions = sorted(set(range(first, last - width + 1, 480)) | {last - width})
    correlations = []
    for position in positions:
        a, b = x[position:position + width], y[position + lag:position + lag + width]
        if max(float(np.std(a)), float(np.std(b))) <= 1e-6:
            continue
        correlations.append(_corr(a, b))
    detail["minimum_local_correlation"] = min(correlations) if correlations else None
    if not correlations or min(correlations) < minimum_corr:
        detail["reason_code"] = "unexplained_local_signal_change"
    return detail


def _unaligned_edges(reference: WavAudio, processed: WavAudio, x: np.ndarray,
                     y: np.ndarray, candidate: dict) -> dict:
    """Audit original PCM edges without mistaking best-lag cropping for proof.

    Exact original zeros can establish padding; filtered analysis ringing must
    not establish or erase that evidence. Unknown nonzero edge content is not
    silently accepted, even if the overlapping samples are identical.
    """
    first, last, lag = (
        candidate["reference_start_sample"], candidate["reference_end_sample"],
        candidate["lag_samples"],
    )
    edges = []
    for name, audio, intervals in (
        ("reference", reference, [(0, first), (last, len(x))]),
        ("processed", processed, [(0, first + lag), (last + lag, len(y))]),
    ):
        for side, (start, end) in zip(("prefix", "tail"), intervals):
            if end <= start:
                continue
            original_first = max(0, round(start * audio.sample_rate_hz / ANALYSIS_RATE_HZ))
            original_last = min(len(audio.samples), round(end * audio.sample_rate_hz / ANALYSIS_RATE_HZ))
            exact_zero = not np.any(audio.samples[original_first:original_last])
            duration = (end - start) * 1000 / ANALYSIS_RATE_HZ
            edges.append({
                "file": name, "side": side, "duration_ms": duration,
                "original_pcm_exact_silence": bool(exact_zero),
                "outside_edge_tolerance": duration > DURATION_TOLERANCE_MS,
            })
    return {
        "edges": edges,
        "all_unaligned_edges_demonstrably_silent": all(
            edge["original_pcm_exact_silence"] for edge in edges
        ),
        "unexplained_non_silent_edge": any(
            edge["outside_edge_tolerance"] and not edge["original_pcm_exact_silence"]
            for edge in edges
        ),
        "evidence_source": "original_pcm_exact_zeros_not_filtered_analysis",
    }


def evaluate_baseline(
    reference: WavAudio,
    processed: WavAudio,
    config: EngineConfig,
    *,
    method: str,
) -> dict:
    """Measure one frozen control without labels, edit hints, or answer keys.

    ``measurement_available`` means numerical comparison metrics exist. A
    withheld control may retain those metrics but has no anomaly decision.
    Direct difference may measure weakly corresponding files; it does not infer
    that they contain the same content. Periodic alignment ambiguity is withheld
    by the shared identifiability gate without applying that offset to its NRMSE.
    """
    if not isinstance(reference, WavAudio) or not isinstance(processed, WavAudio):
        raise AudioInputError("invalid_audio", "Use WavAudio inputs.")
    if not isinstance(config, EngineConfig):
        raise EngineConfigError("Use EngineConfig.")
    if not isinstance(method, str) or method not in BASELINE_METHODS:
        raise EngineConfigError("Use a supported comparison baseline method.")
    threshold = ANOMALY_NRMSE_BY_PROFILE[config.profile]
    duration_difference = (
        len(processed.samples) * 1000 / processed.sample_rate_hz
        - len(reference.samples) * 1000 / reference.sample_rate_hz
    )
    result = {
        "schema_version": 1, "engine": "frozen_comparison_controls_v1",
        "method": method, "status": "withheld", "reason_code": None,
        "content_preservation_status": "not_assessed_by_comparison_baseline",
        "events": None, "measurement_available": False, "anomaly_candidate": None,
        "complete_audio_approval": False, "commercial_performance_validated": False,
        "reference": reference.metadata(), "processed": processed.metadata(),
        "configuration": {
            "profile": config.profile, "allow_gain": config.allow_gain,
            "allow_resampling": config.allow_resampling, "max_delay_ms": config.max_delay_ms,
        },
        "analysis": {
            "sample_rate_hz": ANALYSIS_RATE_HZ,
            "fixed_normalized_rmse_threshold": threshold,
            "fixed_duration_difference_threshold_ms": DURATION_TOLERANCE_MS,
            "diagnostic_rules_not_calibrated_probabilities": True,
            "local_alignment_enabled": False,
            "ablation_diagnostic": method == "no_local_alignment",
            "shared_identifiability_gate": True,
        },
        "metrics": {
            "raw": None, "comparison": None, "normalized_rmse": None,
            "estimated_delay_ms": None, "duration_difference_ms": duration_difference,
            "absolute_duration_difference_ms": abs(duration_difference),
        },
        "diagnostics": {},
        "limitations": [
            "Anomaly screening only; typed defect localization is not assessed.",
            "Event precision/recall are undefined for these controls, not zero.",
            "A low residual or no anomaly is not proof of content preservation.",
            "Analysis uses the declared 8 kHz profile, not full-band input quality.",
            "Direct difference cannot account for normal global delay and is a trivial control.",
            "Global controls allow only demonstrably silent original PCM edge padding.",
            "Nonzero codec ringing at original edges may prevent the padding allowance.",
        ],
    }
    if reference.sample_rate_hz != processed.sample_rate_hz and not config.allow_resampling:
        result["reason_code"] = "resampling_not_declared"
        return result
    if min(float(np.std(reference.samples)), float(np.std(processed.samples))) <= 1e-6:
        result["reason_code"] = "insufficient_signal_variation"
        return result
    x, y = prepare_analysis(reference, config.profile), prepare_analysis(processed, config.profile)
    if min(float(np.std(x)), float(np.std(y))) <= 1e-6:
        result["reason_code"] = "insufficient_analysis_band_signal"
        return result
    result["metrics"]["raw"] = _comparison_metrics(x, y, False)
    result["measurement_available"] = True
    candidate = _global_candidate(x, y, config.max_delay_ms)
    result["diagnostics"]["global_correspondence"] = candidate
    if method == "direct_difference":
        if candidate["reason_code"] == "ambiguous_alignment":
            result["reason_code"] = "ambiguous_alignment"
            return result
        comparison = _comparison_metrics(x, y, config.allow_gain)
    else:
        if candidate["reason_code"] is not None:
            result["reason_code"] = candidate["reason_code"]
            return result
        first, last, lag = (
            candidate["reference_start_sample"], candidate["reference_end_sample"],
            candidate["lag_samples"],
        )
        comparison = _comparison_metrics(x[first:last], y[first + lag:last + lag], config.allow_gain)
        result["metrics"]["estimated_delay_ms"] = lag * 1000 / ANALYSIS_RATE_HZ
    result["metrics"]["comparison"] = comparison
    result["metrics"]["normalized_rmse"] = comparison["normalized_rmse"]
    if comparison["gain_estimate"] <= 0 or not math.isfinite(comparison["gain_estimate"]):
        result["reason_code"] = "unsupported_gain_or_polarity"
        return result
    if method == "no_local_alignment":
        checks = _constant_offset_checks(x, y, candidate, config.profile)
        result["diagnostics"]["constant_offset_checks"] = checks
        if checks["reason_code"] is not None:
            result["reason_code"] = checks["reason_code"]
            return result
    duration_anomaly = abs(duration_difference) > DURATION_TOLERANCE_MS
    edge_anomaly = False
    if method != "direct_difference":
        edge_audit = _unaligned_edges(reference, processed, x, y, candidate)
        result["diagnostics"]["unaligned_edge_audit"] = edge_audit
        duration_anomaly = duration_anomaly and not edge_audit["all_unaligned_edges_demonstrably_silent"]
        edge_anomaly = edge_audit["unexplained_non_silent_edge"]
    result["status"] = "analyzed"
    result["anomaly_candidate"] = bool(
        comparison["normalized_rmse"] > threshold
        or duration_anomaly or edge_anomaly
    )
    result["diagnostics"]["anomaly_reasons"] = [
        reason for condition, reason in (
            (comparison["normalized_rmse"] > threshold, "comparison_residual_exceeds_fixed_rule"),
            (duration_anomaly, "unexplained_duration_difference_exceeds_fixed_rule"),
            (edge_anomaly, "unaligned_non_silent_file_edge"),
        ) if condition
    ]
    return result
