"""Local temporal-content candidates from observed signal correspondence.

No ground-truth map, expected event count, edit position, or scenario name is an
input. Candidate events require both sides of the edit to have reliable raw
signal anchors. This diagnostic prototype is not a general audio approval tool.
"""

from dataclasses import dataclass
import math
from pathlib import Path

import numpy as np
from scipy.signal import correlate

from .alignment import edit_align
from .analysis_scope import analysis_scope
from .audio import WavAudio, read_wav
from .baseline import BaselineConfig, BaselineConfigError
from .features import extract_features
from .profiles import prepare_analysis


RATE = 8000
HOP = 80
MIN_EVENT_SAMPLES = 1600
MAX_EDIT_SHIFT_SAMPLES = 16000
ANCHOR_SAMPLES = 1920
EDGE_TOLERANCE_SAMPLES = 320


class EngineConfigError(ValueError):
    def __init__(self, message: str):
        self.code = "invalid_configuration"
        super().__init__(message)


@dataclass(frozen=True)
class EngineConfig:
    profile: str = "basic"
    allow_gain: bool = False
    allow_resampling: bool = False
    max_delay_ms: float = 1000.0

    def __post_init__(self):
        if not isinstance(self.profile, str) or self.profile not in {"basic", "telephone"}:
            raise EngineConfigError("Use basic or telephone profile.")
        try:
            settings = BaselineConfig(self.allow_resampling, self.allow_gain, self.max_delay_ms)
        except BaselineConfigError as exc:
            raise EngineConfigError(str(exc)) from None
        object.__setattr__(self, "max_delay_ms", settings.max_delay_ms)


def _corr(x: np.ndarray, y: np.ndarray) -> float:
    if len(x) != len(y) or len(x) < 2:
        return 0.0
    a, b = x - np.mean(x), y - np.mean(y)
    denominator = float(np.sqrt(np.dot(a, a) * np.dot(b, b)))
    return float(np.clip(np.dot(a, b) / denominator, -1, 1)) if denominator > 1e-16 else 0.0


def _locate(template: np.ndarray, target: np.ndarray, start: int, end: int) -> dict | None:
    """Find a raw sample match in a bounded search, retaining rival peaks."""
    first, last = max(0, int(start)), min(len(target) - len(template), int(end))
    if last < first or np.std(template) < 1e-6:
        return None
    search = target[first:last + len(template)]
    centered = template - np.mean(template)
    products = correlate(search, centered, mode="valid", method="fft")
    sums = np.concatenate(([0.0], np.cumsum(search)))
    squares = np.concatenate(([0.0], np.cumsum(search * search)))
    length = len(template)
    total = sums[length:] - sums[:-length]
    variance = np.maximum(0.0, squares[length:] - squares[:-length] - total * total / length)
    denominator = np.sqrt(variance * np.dot(centered, centered))
    scores = np.divide(products, denominator, out=np.zeros_like(products), where=denominator > 1e-16)
    scores = np.clip(scores, -1, 1)
    best = int(np.argmax(scores))
    rivals = scores[np.abs(np.arange(len(scores)) - best) > 160]
    alternative = float(np.max(rivals)) if len(rivals) else None
    return {
        "start": first + best, "correlation": float(scores[best]),
        "peak_margin": float(scores[best] - alternative) if alternative is not None else None,
    }


def _anchor(run: dict, x: np.ndarray, y: np.ndarray, minimum_corr: float) -> dict | None:
    start, end = run["reference_start_frame"] * HOP, min(len(x), run["reference_end_frame"] * HOP)
    length = end - start
    if length < ANCHOR_SAMPLES:
        return None
    offset = (run["processed_start_frame"] - run["reference_start_frame"]) * HOP
    window = min(1600, length - 640)
    points = sorted(set(round(start + fraction * (length - window)) for fraction in (.2, .5, .8)))
    matches = []
    for point in points:
        candidate = _locate(x[point:point + window], y, point + offset - 320, point + offset + 320)
        if (candidate is None or candidate["correlation"] < minimum_corr
                or (candidate["peak_margin"] is not None and candidate["peak_margin"] < .03)):
            return None
        matches.append({"reference_sample": point, "processed_sample": candidate["start"],
                        "correlation": candidate["correlation"]})
    offsets = [match["processed_sample"] - match["reference_sample"] for match in matches]
    if max(offsets) - min(offsets) > 24:
        return None
    return {**run, "offset_samples": int(round(float(np.median(offsets)))), "anchors": matches}


def _boundary(x: np.ndarray, y: np.ndarray, predicted: int, before: int, after: int, kind: str):
    delta = before - after if kind == "delete" else after - before
    if delta <= 0:
        return None
    window = 480
    best = None
    for point in range(max(window, predicted - 960), min(len(x) - window, predicted + 960) + 1, 8):
        right = point + delta if kind == "delete" else point
        left_target, right_target = point + before, right + after
        if left_target < window or right_target < 0 or right_target + window > len(y) or right + window > len(x):
            continue
        quality = (_corr(x[point - window:point], y[left_target - window:left_target])
                   + _corr(x[right:right + window], y[right_target:right_target + window])) / 2
        if best is None or quality > best[1]:
            best = (point, quality)
    return best


def _copy_source(x: np.ndarray, y: np.ndarray, start: int, length: int, reference_boundary: int):
    trim = min(320, length // 5)
    template = y[start + trim:start + length - trim]
    candidate = _locate(template, x, reference_boundary - length - 2400 + trim,
                        reference_boundary + 2400 + trim)
    if candidate is None:
        return None
    source = candidate["start"] - trim
    if source < 0 or source + length > len(x):
        return None
    return source, candidate


def _adjacent_copy(x: np.ndarray, y: np.ndarray, approximate: int, length: int,
                   reference_boundary: int, minimum_corr: float):
    # Within identical adjacent copies the edit boundary itself is not audible.
    # Locate the *whole repeated pair* rather than treating a DP tie as truth.
    candidates = set()
    for center in (approximate, approximate - length):
        candidates.update(range(max(0, center - 960), min(len(y) - 2 * length, center + 960) + 1, 8))
    best = None
    for start in sorted(candidates):
        score = _corr(y[start:start + length], y[start + length:start + 2 * length])
        if best is None or score > best[1]:
            best = (start, score)
    if best is None or best[1] < minimum_corr:
        return None
    first_copy = best[0]
    match = _copy_source(x, y, first_copy, length, reference_boundary)
    if match is None or match[1]["correlation"] < minimum_corr or (
            match[1]["peak_margin"] is not None and match[1]["peak_margin"] < .03):
        return None
    source, evidence = match
    if min(abs(source - reference_boundary), abs(source + length - reference_boundary)) > 960:
        return None
    return source, first_copy + length, {**evidence, "adjacent_copy_correlation": best[1]}


def _withheld(result: dict, code: str) -> dict:
    result["reason_code"] = code
    return result


def _coalesce_transitions(runs: list[dict]) -> list[dict]:
    """Keep short window-edge fragments together, without hiding mixed edits."""
    output, pending = [], []
    def flush():
        if not pending:
            return
        kinds = {run["kind"] for run in pending if run["kind"] != "match"}
        # At most 40 ms of intervening apparent matches can be window leakage.
        small_matches = sum(run["reference_end_frame"] - run["reference_start_frame"]
                            for run in pending if run["kind"] == "match")
        deleted = sum(run["reference_end_frame"] - run["reference_start_frame"]
                      for run in pending if run["kind"] == "delete")
        inserted = sum(run["processed_end_frame"] - run["processed_start_frame"]
                       for run in pending if run["kind"] == "insert")
        pure_or_boundary_leakage = len(kinds) == 1 or (
            len(kinds) == 2 and min(deleted, inserted) * HOP <= EDGE_TOLERANCE_SAMPLES
            and abs(deleted - inserted) * HOP >= MIN_EVENT_SAMPLES)
        if kinds and small_matches * HOP <= EDGE_TOLERANCE_SAMPLES:
            kind = ("delete" if deleted > inserted else "insert") if pure_or_boundary_leakage else "compound"
            output.append({"kind": kind,
                           "reference_start_frame": pending[0]["reference_start_frame"],
                           "reference_end_frame": pending[-1]["reference_end_frame"],
                           "processed_start_frame": pending[0]["processed_start_frame"],
                           "processed_end_frame": pending[-1]["processed_end_frame"]})
        elif kinds:
            output.append({"kind": "compound",
                           "reference_start_frame": pending[0]["reference_start_frame"],
                           "reference_end_frame": pending[-1]["reference_end_frame"],
                           "processed_start_frame": pending[0]["processed_start_frame"],
                           "processed_end_frame": pending[-1]["processed_end_frame"]})
        else:
            output.extend(pending)
        pending.clear()
    for run in runs:
        long_match = run["kind"] == "match" and (
            run["reference_end_frame"] - run["reference_start_frame"]) * HOP >= ANCHOR_SAMPLES
        if long_match:
            flush()
            output.append(run)
        else:
            pending.append(run)
    flush()
    return output


def _silent_original_edge(audio: WavAudio, start: int, end: int) -> bool:
    first = round(start * audio.sample_rate_hz / RATE)
    last = min(len(audio.samples), round(end * audio.sample_rate_hz / RATE))
    # Exact original PCM zeros, not filter-induced ringing or quiet speech.
    return last >= first and not np.any(audio.samples[first:last])


@analysis_scope
def analyze_buffers(reference: WavAudio, processed: WavAudio, config: EngineConfig | None = None) -> dict:
    settings = config if config is not None else EngineConfig()
    if not isinstance(settings, EngineConfig):
        raise EngineConfigError("Use EngineConfig.")
    result = {
        "schema_version": 1, "engine": "local_content_alignment_v1",
        "status": "withheld", "content_preservation_status": "withheld",
        "reason_code": None, "events": None,
        "complete_audio_approval": False,
        "commercial_performance_validated": False,
        "reference": reference.metadata(), "processed": processed.metadata(),
        "configuration": {"profile": settings.profile, "allow_gain": settings.allow_gain,
                          "allow_resampling": settings.allow_resampling, "max_delay_ms": settings.max_delay_ms},
        "analysis": {"sample_rate_hz": RATE, "hop_ms": 10.0,
                     "method": "constrained_edit_alignment_with_raw_anchors",
                     "minimum_event_duration_ms": 200,
                     "maximum_cumulative_edit_shift_ms": 2000,
                     "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {},
        "limitations": ["Diagnostic candidates, not complete audio approval or fault provenance.",
                        "Identifiable internal deletion or adjacent-copy repetition only.",
                        "No full-band quality, network loss cause, or actual telephone performance claim."],
    }
    if reference.sample_rate_hz != processed.sample_rate_hz and not settings.allow_resampling:
        return _withheld(result, "resampling_not_declared")
    if min(float(np.std(reference.samples)), float(np.std(processed.samples))) <= 1e-6:
        return _withheld(result, "insufficient_signal_variation")
    x, y = prepare_analysis(reference, settings.profile), prepare_analysis(processed, settings.profile)
    if min(float(np.std(x)), float(np.std(y))) <= 1e-6:
        return _withheld(result, "insufficient_analysis_band_signal")
    ref_features, proc_features = extract_features(x), extract_features(y)
    shift = math.ceil(settings.max_delay_ms * RATE / 1000 / HOP) + MAX_EDIT_SHIFT_SAMPLES // HOP
    path = edit_align(ref_features, proc_features, shift)
    if path["status"] != "aligned":
        return _withheld(result, path["reason_code"])
    result["diagnostics"]["normalized_path_cost"] = path["normalized_path_cost"]
    runs = _coalesce_transitions(path["runs"])
    minimum_corr = .90 if settings.profile == "basic" else .82
    anchored = {}
    for index, run in enumerate(runs):
        if run["kind"] == "match":
            anchor = _anchor(run, x, y, minimum_corr)
            if anchor is not None:
                anchored[index] = anchor
    if not anchored:
        return _withheld(result, "insufficient_unambiguous_anchors")
    # Validate all sufficiently long match runs; never approve a small matching
    # island inside an otherwise unexplained change.
    if any(index not in anchored and run["kind"] == "match"
           and (run["reference_end_frame"] - run["reference_start_frame"]) * HOP >= ANCHOR_SAMPLES
           for index, run in enumerate(runs)):
        return _withheld(result, "unreliable_matched_content")
    first_offset = next(iter(anchored.values()))["offset_samples"]
    last_offset = list(anchored.values())[-1]["offset_samples"]
    if any(abs(anchor["offset_samples"] - first_offset) > MAX_EDIT_SHIFT_SAMPLES
           for anchor in anchored.values()):
        return _withheld(result, "cumulative_edit_shift_outside_budget")
    edge_lengths = {
        ("delete", "start"): max(0, -first_offset),
        ("insert", "start"): max(0, first_offset),
        ("delete", "end"): max(0, len(x) + last_offset - len(y)),
        ("insert", "end"): max(0, len(y) - len(x) - last_offset),
    }
    sample_pairs = []
    for anchor in anchored.values():
        start = anchor["reference_start_frame"] * HOP + 320
        end = min(len(x), anchor["reference_end_frame"] * HOP) - 320
        offset = anchor["offset_samples"]
        start, end = max(start, -offset), min(end, len(y) - offset)
        if end > start:
            sample_pairs.append((x[start:end], y[start + offset:end + offset]))
    matched_samples = sum(len(a) for a, _ in sample_pairs)
    if matched_samples < max(1600, .35 * min(len(x), len(y))):
        return _withheld(result, "insufficient_matched_coverage")
    denominator = sum(float(np.dot(a, a)) for a, _ in sample_pairs)
    gain = sum(float(np.dot(a, b)) for a, b in sample_pairs) / max(denominator, 1e-16)
    applied_gain = gain if settings.allow_gain else 1.0
    residual = sum(float(np.sum((b - applied_gain * a) ** 2)) for a, b in sample_pairs)
    nrmse = math.sqrt(residual / max(applied_gain * applied_gain * denominator, 1e-16))
    result["diagnostics"].update({"gain_estimate": gain, "applied_gain": applied_gain,
                                  "matched_normalized_rmse": nrmse,
                                  "matched_analysis_samples": matched_samples,
                                  "anchor_run_count": len(anchored)})
    if gain <= 0 or not math.isfinite(gain) or nrmse > (.08 if settings.profile == "basic" else .25):
        return _withheld(result, "unexplained_matched_signal_change")
    # A long pair's average error can hide a short substituted region. Verify
    # local raw correspondence throughout every retained match, not only anchors.
    local_correlations = []
    for a, b in sample_pairs:
        width = min(960, len(a))
        for start in range(0, len(a) - width + 1, 480):
            block_a, block_b = a[start:start + width], b[start:start + width]
            if max(float(np.std(block_a)), float(np.std(block_b))) <= 1e-6:
                continue
            score = _corr(block_a, block_b)
            local_correlations.append(score)
            if score < minimum_corr:
                return _withheld(result, "unexplained_local_signal_change")
    result["diagnostics"]["minimum_local_correlation"] = min(local_correlations) if local_correlations else None
    events = []
    for index, run in enumerate(runs):
        if run["kind"] == "match":
            continue
        if run["kind"] == "compound":
            return _withheld(result, "compound_or_unidentified_change")
        i0, i1 = run["reference_start_frame"] * HOP, min(len(x), run["reference_end_frame"] * HOP)
        j0, j1 = run["processed_start_frame"] * HOP, min(len(y), run["processed_end_frame"] * HOP)
        edge = index == 0 or index == len(runs) - 1
        content = x[i0:i1] if run["kind"] == "delete" else y[j0:j1]
        if edge:
            original = reference if run["kind"] == "delete" else processed
            side = "start" if index == 0 else "end"
            padding = edge_lengths[(run["kind"], side)]
            signal_length = len(x) if run["kind"] == "delete" else len(y)
            edge_start, edge_end = (0, padding) if side == "start" else (signal_length - padding, signal_length)
            if abs(len(content) - padding) <= EDGE_TOLERANCE_SAMPLES and _silent_original_edge(original, edge_start, edge_end):
                continue
            return _withheld(result, "non_silent_file_edge_change")
        if max(i1 - i0, j1 - j0) <= EDGE_TOLERANCE_SAMPLES:
            continue
        # The gap must sit directly between long reliable matches on both axes.
        if index - 1 not in anchored or index + 1 not in anchored:
            return _withheld(result, "compound_or_unidentified_change")
        before, after = anchored[index - 1]["offset_samples"], anchored[index + 1]["offset_samples"]
        length = before - after if run["kind"] == "delete" else after - before
        if length < MIN_EVENT_SAMPLES or length > MAX_EDIT_SHIFT_SAMPLES:
            return _withheld(result, "event_outside_supported_duration")
        boundary = _boundary(x, y, i0, before, after, run["kind"])
        if boundary is None or boundary[1] < minimum_corr:
            return _withheld(result, "event_boundary_not_supported")
        point, boundary_score = boundary
        common = {"boundary_correlation": boundary_score,
                  "offset_before_ms": before * 1000 / RATE,
                  "offset_after_ms": after * 1000 / RATE}
        if run["kind"] == "delete":
            if np.std(x[point:point + length]) <= 1e-6:
                return _withheld(result, "deleted_interval_unidentifiable")
            events.append({"type": "delete", "reference_interval_ms": [point * 1000 / RATE, (point + length) * 1000 / RATE],
                           "processed_boundary_ms": (point + before) * 1000 / RATE, "evidence": common})
        else:
            inserted_start = point + before
            copied = _adjacent_copy(x, y, inserted_start, length, point, minimum_corr)
            if copied is None:
                return _withheld(result, "insertion_not_supported_as_repetition")
            source, inserted_start, match = copied
            events.append({"type": "repeat", "reference_source_interval_ms": [source * 1000 / RATE, (source + length) * 1000 / RATE],
                           "processed_added_interval_ms": [inserted_start * 1000 / RATE, (inserted_start + length) * 1000 / RATE],
                           "copy_interval_convention": "canonical_later_adjacent_copy_not_edit_provenance",
                           "evidence": {**common, "copy_correlation": match["correlation"],
                                        "adjacent_copy_correlation": match["adjacent_copy_correlation"]}})
    first_anchor = next(iter(anchored.values()))
    if abs(first_anchor["offset_samples"] * 1000 / RATE) > settings.max_delay_ms + 3:
        return _withheld(result, "initial_delay_outside_declared_search")
    result["status"] = "analyzed"
    result["content_preservation_status"] = "defect_candidates" if events else "no_supported_defect_candidates"
    result["events"] = sorted(events, key=lambda event: event.get("processed_boundary_ms", event.get("processed_added_interval_ms", [0])[0]))
    result["alignment_segments"] = [
        {"reference_interval_ms": [anchor["reference_start_frame"] * 10.0, min(len(x), anchor["reference_end_frame"] * HOP) * 1000 / RATE],
         "processed_offset_ms": anchor["offset_samples"] * 1000 / RATE,
         "anchor_correlations": [item["correlation"] for item in anchor["anchors"]]}
        for anchor in anchored.values()
    ]
    return result


def analyze_wavs(reference_path: str | Path, processed_path: str | Path, config: EngineConfig | None = None) -> dict:
    return analyze_buffers(read_wav(reference_path), read_wav(processed_path), config)
