"""Fixed analysis profiles and a controlled G.711 mu-law fixture transform.

Profiles are declarations, not adaptive equalizers. Original samples remain
unchanged. The telephone profile applies the same fixed 300--3400 Hz filter to
both sides, and only permits conclusions about that analysis band.

The integer compander follows the G.711 bias/segment/complement mapping, with
the negative-input minus-one convention checked against WebRTC's ITU-bitexact
reference implementation. This is not the continuous log(1 + mu*x) approximation.
Reference: https://chromium.googlesource.com/external/webrtc/stable/webrtc/+/master/modules/audio_coding/codecs/g711/g711.h
"""

from __future__ import annotations

import math

import numpy as np
from scipy.signal import butter, resample_poly, sosfiltfilt

from .audio import AudioInputError, WavAudio
from .analysis_scope import cached_preparation, retain_preparation


ANALYSIS_RATE_HZ = 8_000
ANALYSIS_PROFILES = frozenset({"basic", "telephone"})
TELEPHONE_LOW_HZ = 300.0
TELEPHONE_HIGH_HZ = 3_400.0
TELEPHONE_FILTER_ORDER = 6
# A fixed digital design, never estimated from either input file. Applying it
# forwards and backwards gives zero phase and squares its amplitude response.
_TELEPHONE_SOS = butter(
    TELEPHONE_FILTER_ORDER,
    [TELEPHONE_LOW_HZ, TELEPHONE_HIGH_HZ],
    btype="bandpass", fs=ANALYSIS_RATE_HZ, output="sos",
)
_ULAW_BIAS = 132
_SEGMENT_LIMITS = np.array([256, 512, 1024, 2048, 4096, 8192, 16384, 32768])


class AnalysisProfileError(ValueError):
    """An invalid declared profile, distinct from an invalid audio input."""

    def __init__(self, message: str) -> None:
        self.code = "invalid_configuration"
        super().__init__(message)


def _normalized_array(samples: np.ndarray) -> np.ndarray:
    try:
        raw = np.asarray(samples)
        if np.iscomplexobj(raw) or raw.dtype.kind == "b":
            raise ValueError("not real audio")
        values = np.asarray(raw, dtype=np.float64)
    except (TypeError, ValueError, OverflowError):
        raise AudioInputError(
            "invalid_samples", "Samples must be a finite normalized mono array."
        ) from None
    if (
        values.ndim != 1 or values.size == 0
        or not np.all(np.isfinite(values))
        or np.any(values < -1.0) or np.any(values > 1.0)
    ):
        raise AudioInputError(
            "invalid_samples", "Samples must be a finite normalized mono array."
        )
    return values


def prepare_analysis(audio: WavAudio, profile: str = "basic") -> np.ndarray:
    """Return a new float64 mono array at 8 kHz without altering ``audio``.

    The basic profile only resamples. Telephone analysis also applies a fixed
    zero-phase bandpass to *both* inputs. There is no trimming, gain change,
    codec decoding guess, learned mapping, or clipping repair. Filter output
    can exceed normalized PCM bounds and is never silently limited.
    """
    if not isinstance(audio, WavAudio):
        raise AudioInputError("invalid_audio", "Use a WavAudio input.")
    if not isinstance(profile, str) or profile not in ANALYSIS_PROFILES:
        raise AnalysisProfileError("Use the basic or telephone analysis profile.")
    # Native-rate basic preparation is already a cheap copy. Reuse only work
    # that actually resamples or filters, and preserve the public fresh-array
    # contract even while nested candidate engines share a preparation scope.
    costly = audio.sample_rate_hz != ANALYSIS_RATE_HZ or profile == "telephone"
    if costly:
        cached = cached_preparation(audio, profile)
        if cached is not None:
            return np.array(cached, dtype=np.float64, copy=True)
    values = np.array(audio.samples, dtype=np.float64, copy=True)
    if audio.sample_rate_hz != ANALYSIS_RATE_HZ:
        divisor = math.gcd(audio.sample_rate_hz, ANALYSIS_RATE_HZ)
        values = resample_poly(
            values, ANALYSIS_RATE_HZ // divisor,
            audio.sample_rate_hz // divisor,
        ).astype(np.float64, copy=False)
    if profile == "telephone":
        values = sosfiltfilt(_TELEPHONE_SOS, values)
    if costly:
        retain_preparation(audio, profile, values)
    return np.asarray(values, dtype=np.float64)


def _bounded_integer_array(values: np.ndarray, low: int, high: int) -> np.ndarray:
    try:
        raw = np.asarray(values)
    except (TypeError, ValueError, OverflowError):
        raise AudioInputError(
            "invalid_samples", "Use a nonempty mono integer array in codec range."
        ) from None
    if (
        raw.ndim != 1 or raw.size == 0 or raw.dtype.kind not in "iu"
        or np.any(raw < low) or np.any(raw > high)
    ):
        raise AudioInputError(
            "invalid_samples", "Use a nonempty mono integer array in codec range."
        )
    return raw.astype(np.int32, copy=True)


def encode_mulaw_pcm16(pcm: np.ndarray) -> np.ndarray:
    """Encode integer PCM16 samples as uint8 G.711 mu-law, with no zero trap.

    Compander saturation at the largest G.711 segment is part of the codec,
    not input clipping repair. Non-PCM16 integers are rejected before encoding.
    """
    linear = _bounded_integer_array(pcm, -32768, 32767)
    negative = linear < 0
    magnitude = np.where(negative, -linear - 1, linear) + _ULAW_BIAS
    segments = np.searchsorted(_SEGMENT_LIMITS, magnitude, side="right")
    safe_segments = np.minimum(segments, 7)
    mantissas = (magnitude >> (safe_segments + 3)) & 15
    packed = (safe_segments << 4) | mantissas
    packed = np.where(segments >= 8, 127, packed)
    masks = np.where(negative, 127, 255)
    return (packed ^ masks).astype(np.uint8)


def decode_mulaw_bytes(codes: np.ndarray) -> np.ndarray:
    """Decode unsigned-byte G.711 mu-law into signed PCM16 integers."""
    encoded = _bounded_integer_array(codes, 0, 255)
    packed = encoded ^ 255
    exponent = (packed >> 4) & 7
    magnitude = (((packed & 15) << 3) + _ULAW_BIAS) << exponent
    decoded = np.where(packed & 128, _ULAW_BIAS - magnitude, magnitude - _ULAW_BIAS)
    return decoded.astype(np.int16)


def g711_mulaw_roundtrip(samples: np.ndarray) -> np.ndarray:
    """Controlled normalized PCM16 -> mu-law -> PCM16 transform, no filtering.

    Audio levels are preserved except for codec quantization. Values outside
    [-1,1] are rejected. The normalized +1 endpoint maps to PCM16 +32767,
    matching WAV encoding; no peak or RMS normalization is performed.
    """
    values = _normalized_array(samples)
    pcm = np.minimum(np.rint(values * 32768.0), 32767).astype(np.int16)
    return decode_mulaw_bytes(encode_mulaw_pcm16(pcm)).astype(np.float64) / 32768.0


def telephone_transform_samples(audio: WavAudio) -> np.ndarray:
    """Return a synthetic 8 kHz bandlimited mu-law fixture without writing files.

    This controlled transformation is not a real telephone call, packet-loss
    simulation, standardized telephone response, or conformance certification.
    If filtering creates values outside PCM range, fixture creation rejects
    them rather than hiding overload with a normalizer or limiter.
    """
    return g711_mulaw_roundtrip(prepare_analysis(audio, "telephone"))
