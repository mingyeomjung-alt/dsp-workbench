"""Small, explicit reference-rendering models; never inferred from audio.

Each declaration is a fixed, parameter-free operation. Models retain the
original sample rate and sample count, so coordinates remain on the original
sample grid, but the rendered signal is not the original signal's identity.
In particular, the causal FIR has a startup transient and a one-sample group
delay; preserving coordinates is not a claim of perceptual equivalence.

Operations run in PCM integer units and round to PCM16, ties to even, after
every step. A value which rounds outside [-32768, 32767] is rejected, never
clipped, wrapped, normalized, or limited. No model fitting, inference, network
access, or changes to the temporal analysis engines occur here.
"""

from __future__ import annotations

import numpy as np

from .audio import (
    AudioInputError,
    MAX_DURATION_SECONDS,
    MIN_DURATION_SECONDS,
    SUPPORTED_SAMPLE_RATES,
    WavAudio,
    decode_wav,
    encode_wav,
)


MODEL_KINDS = frozenset({"polarity_invert", "fir_binomial_3", "pcm_quantize_12"})
MAX_MODELS = 4


class ModelTransformError(ValueError):
    """A rejection with a stable code and no caller-derived private content."""

    def __init__(self, code: str, message: str | None = None) -> None:
        self.code = code
        self.message = message if message is not None else code
        super().__init__(self.message)


def validate_models(models: object) -> list[dict[str, str]]:
    """Return a fresh JSON-safe list of 1–4 exact, fixed-kind declarations.

    Exact built-in types and cardinality checks precede field access. No
    recursive walk, conversion, repr, or traversal of unknown payloads occurs.
    Thus cyclic structures and oversized declarations are rejected, not read
    as implicit parameters or searched for a recognized operation.
    """
    if type(models) is not list or not 1 <= len(models) <= MAX_MODELS:
        raise ModelTransformError("invalid_models", "Declare one to four fixed transform models.")
    normalized: list[dict[str, str]] = []
    for spec in models:
        if type(spec) is not dict or len(spec) != 1:
            raise ModelTransformError("invalid_models", "Each model must contain only its fixed kind.")
        key = next(iter(spec))
        if type(key) is not str or key != "kind":
            raise ModelTransformError("invalid_models", "Each model must contain only its fixed kind.")
        kind = spec["kind"]
        if type(kind) is not str or len(kind) > 32 or kind not in MODEL_KINDS:
            raise ModelTransformError("invalid_models", "The declared transform model kind is unsupported.")
        normalized.append({"kind": kind})
    return normalized


def validate_model_plan(value: object) -> dict:
    """Validate the exact version-1 plan envelope without executing a model."""
    if type(value) is not dict or len(value) != 2:
        raise ModelTransformError("invalid_model_plan", "A transform plan requires its version and models.")
    if any(type(key) is not str or len(key) > 32 or key not in {"schema_version", "models"} for key in value):
        raise ModelTransformError("invalid_model_plan", "A transform plan contains an unsupported field.")
    if type(value["schema_version"]) is not int or value["schema_version"] != 1:
        raise ModelTransformError("invalid_model_plan", "Only transform plan schema version 1 is supported.")
    return {"schema_version": 1, "models": validate_models(value["models"])}


def _validated_audio(audio: object) -> WavAudio:
    if type(audio) is not WavAudio:
        raise ModelTransformError("invalid_audio", "Transform rendering requires validated mono PCM16 audio.")
    # Bound arrays before reusing WavAudio's strict finite/grid/hash checks.
    # This also rejects a deliberately forged dataclass without scanning an
    # oversized or arbitrary nested object. Ordinary WavAudio is immutable.
    try:
        samples = audio.samples
        rate = audio.sample_rate_hz
        digest = audio.sha256
    except AttributeError:
        raise ModelTransformError("invalid_audio", "Transform rendering requires validated mono PCM16 audio.") from None
    if (
        type(samples) is not np.ndarray
        or samples.dtype != np.dtype(np.float64)
        or samples.ndim != 1
        or type(rate) is not int
        or rate not in SUPPORTED_SAMPLE_RATES
        or not MIN_DURATION_SECONDS * rate <= samples.size <= MAX_DURATION_SECONDS * rate
    ):
        raise ModelTransformError("invalid_audio", "Transform rendering requires validated mono PCM16 audio.")
    try:
        return WavAudio(samples=samples, sample_rate_hz=rate, sha256=digest)
    except AudioInputError:
        raise ModelTransformError("invalid_audio", "Transform rendering requires validated mono PCM16 audio.") from None


def _pcm_step(audio: WavAudio, kind: str) -> tuple[bytes, WavAudio]:
    pcm = audio.samples * 32768.0
    if kind == "polarity_invert":
        transformed = -pcm
    elif kind == "fir_binomial_3":
        # Causal, zero-state, length-preserving fixed FIR. Values outside the
        # file before index zero are exactly zero; no final tail is appended.
        transformed = pcm * 0.25
        transformed[1:] += pcm[:-1] * 0.5
        transformed[2:] += pcm[:-2] * 0.25
    else:
        # A signed PCM16 container with amplitudes on a 12-bit quantizer's
        # integer grid. The positive endpoint may round to +32768: reject it.
        transformed = np.rint(pcm / 16.0) * 16.0

    rounded = np.rint(transformed)
    if not np.all(np.isfinite(rounded)) or np.any(rounded < -32768) or np.any(rounded > 32767):
        raise ModelTransformError(
            "model_output_out_of_range", "The model output cannot be represented without PCM16 clipping."
        )
    try:
        output = encode_wav(rounded / 32768.0, audio.sample_rate_hz)
        # Re-decode every step, rather than retaining unquantized intermediates.
        decoded = decode_wav(output)
    except AudioInputError:
        raise ModelTransformError("invalid_model_output", "The model output is not a supported PCM16 WAV.") from None
    if decoded.sample_rate_hz != audio.sample_rate_hz or decoded.samples.size != audio.samples.size:
        raise ModelTransformError("invalid_model_output", "The model output changed its sample geometry.")
    return output, decoded


def render_models(audio: WavAudio, models: list) -> bytes:
    """Render declared models in order, without modifying inputs or geometry.

    Supported inputs are mono PCM16 at 8/16/44.1/48 kHz, 2–30 seconds. The
    result is WAV bytes, not a verdict, inverse transform, or reconstruction of
    missing content. Every step commits its ties-to-even PCM16 quantization;
    the next step therefore sees that decoded PCM, not the unrounded float.
    """
    declared = validate_models(models)
    current = _validated_audio(audio)
    output: bytes
    for model in declared:
        # Reuse the validated immutable decode of this exact step. A second
        # decode of the same bytes cannot add another PCM quantization step.
        output, current = _pcm_step(current, model["kind"])
    return output
