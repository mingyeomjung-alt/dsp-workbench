"""Standalone DSP utilities; no speaker models or remote analysis APIs."""

__version__ = "0.1.20"

