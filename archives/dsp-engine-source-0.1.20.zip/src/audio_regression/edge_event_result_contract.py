"""Strict opt-in v11 contract for exact, one-sided endpoint-loss witnesses.

The inherited v10 branch keeps its actual method, grid and restrictions.
Native v11 evidence describes only the retained side: it does not invent a
second anchor, infer an edit's intent, read audio, or certify overall quality.
"""

from __future__ import annotations

from copy import deepcopy
import math

from . import result_contract as _base
from .review_contract import with_review_diagnostics
from .short_event_result_contract import (
    METHOD as INHERITED_METHOD, _ANALYSIS_FIELDS, _near_exact, _sample_coordinate,
    validate_short_event_analysis_result,
)


ENGINE = "local_content_alignment_v11"
METHOD = "endpoint_loss_exact_pcm_forward_proof"


def _reject(code: str) -> None:
    raise _base.ResultContractError(code)


def _inherited(value: dict, *, withheld_native: bool = False) -> None:
    shared = deepcopy(value)
    shared["engine"] = "local_content_alignment_v10"
    if withheld_native:
        # Withheld envelopes have no event geometry. Reuse the unchanged
        # inherited contract for bounded metadata and diagnostics, not claims
        # about which grid executed. The original method is checked separately.
        shared["analysis"].update(method=INHERITED_METHOD, sample_rate_hz=8000,
                                   hop_ms=10, minimum_event_duration_ms=200)
    validate_short_event_analysis_result(shared)


def _native_analyzed(value: dict, reference: dict, processed: dict) -> None:
    if (value["reason_code"] is not None or value["content_preservation_status"] != "defect_candidates"
            or type(value["events"]) is not list or len(value["events"]) != 1):
        _reject("inconsistent_result_status")
    event = _base._fields(value["events"][0],
        {"type", "location", "reference_interval_ms", "processed_boundary_ms", "evidence"},
        code="invalid_event_structure")
    if event["type"] != "delete" or type(event["type"]) is not str:
        _reject("unsupported_event_type")
    if type(event["location"]) is not str or event["location"] not in {"head", "tail"}:
        _reject("unsupported_endpoint_location")
    rate = reference["sample_rate_hz"]
    delta = reference["duration_ms"] - processed["duration_ms"]
    removed = reference["sample_count"] - processed["sample_count"]
    start, end = _base._interval(event["reference_interval_ms"], reference["duration_ms"],
                                  "invalid_reference_interval")
    for coordinate in (start, end):
        _sample_coordinate(coordinate, rate)
    if not 50 - 1e-9 <= end - start <= 2000 + 1e-9:
        _reject("unsupported_event_duration")
    head = event["location"] == "head"
    expected_interval = (0, delta) if head else (processed["duration_ms"], reference["duration_ms"])
    if not all(_base._same_number(a, b) for a, b in zip((start, end), expected_interval, strict=True)):
        _reject("inconsistent_endpoint_geometry")
    boundary = _base._number(event["processed_boundary_ms"], "invalid_processed_boundary",
                              0, processed["duration_ms"])
    if not _base._same_number(boundary, 0 if head else processed["duration_ms"]):
        _reject("inconsistent_endpoint_geometry")
    evidence = _base._fields(event["evidence"],
        {"retained_offset_ms", "retained_context_correlation", "removed_sample_count",
         "retained_native_samples", "all_retained_native_samples_exact"}, code="invalid_event_evidence")
    offset = -delta if head else 0
    if not _base._same_number(_base._number(evidence["retained_offset_ms"], "invalid_event_evidence"), offset):
        _reject("inconsistent_endpoint_offset")
    _near_exact(evidence["retained_context_correlation"], 1, "inconsistent_endpoint_exact_evidence")
    if (evidence["all_retained_native_samples_exact"] is not True
            or _base._integer(evidence["removed_sample_count"], "invalid_event_evidence") != removed
            or _base._integer(evidence["retained_native_samples"], "invalid_event_evidence") != processed["sample_count"]):
        _reject("inconsistent_endpoint_sample_counts")
    diagnostics = _base._fields(value["diagnostics"], _base._DIAGNOSTIC_FIELDS, code="invalid_diagnostics")
    for name, expected in (("normalized_path_cost", 0), ("gain_estimate", 1), ("applied_gain", 1),
                           ("matched_normalized_rmse", 0), ("minimum_local_correlation", 1)):
        _near_exact(diagnostics[name], expected, "inconsistent_endpoint_exact_metrics")
    if _base._integer(diagnostics["anchor_run_count"], "invalid_diagnostics") != 1:
        _reject("inconsistent_anchor_count")
    if _base._integer(diagnostics["matched_analysis_samples"], "invalid_diagnostics") != processed["sample_count"]:
        _reject("inconsistent_matched_sample_count")
    segments = value["alignment_segments"]
    if type(segments) is not list or len(segments) != 1:
        _reject("invalid_alignment_segments")
    segment = _base._fields(segments[0],
        {"reference_interval_ms", "processed_offset_ms", "anchor_correlations"}, code="invalid_alignment_segments")
    expected_retained = (delta, reference["duration_ms"]) if head else (0, processed["duration_ms"])
    actual = _base._interval(segment["reference_interval_ms"], reference["duration_ms"],
                              "invalid_alignment_reference_interval")
    if (not all(_base._same_number(a, b) for a, b in zip(actual, expected_retained, strict=True))
            or not _base._same_number(_base._number(segment["processed_offset_ms"], "invalid_alignment_offset"), offset)):
        _reject("inconsistent_endpoint_full_coverage")
    correlations = segment["anchor_correlations"]
    if type(correlations) is not list or len(correlations) != 3:
        _reject("invalid_anchor_correlations")
    for correlation in correlations:
        _near_exact(correlation, 1, "inconsistent_endpoint_exact_evidence")


@with_review_diagnostics
def validate_edge_event_analysis_result(value: object) -> dict:
    """Validate a one-sided native witness or unchanged inherited v10 result."""
    if type(value) is not dict:
        _reject("invalid_result_type")
    _base._json_tree(value)
    if value.get("engine") != ENGINE:
        _reject("unsupported_engine")
    if type(value.get("schema_version")) is not int or value["schema_version"] != 1:
        _reject("unsupported_schema_version")
    if type(value.get("status")) is not str or value["status"] not in {"analyzed", "withheld", "error"}:
        _reject("unsupported_result_status")
    if value["status"] == "error":
        _inherited(value)
        return value
    analysis = _base._fields(value.get("analysis"), _ANALYSIS_FIELDS, code="invalid_analysis_method")
    if analysis["method"] == INHERITED_METHOD:
        _inherited(value)
        return value
    if (analysis["method"] != METHOD
            or analysis["diagnostic_rules_not_calibrated_probabilities"] is not True
            or _base._number(analysis["minimum_event_duration_ms"], "invalid_analysis_method") != 50
            or _base._number(analysis["maximum_cumulative_edit_shift_ms"], "invalid_analysis_method") != 2000):
        _reject("invalid_analysis_method")
    _base._fields(value, _base._FULL_FIELDS |
                   ({"alignment_segments"} if value["status"] == "analyzed" else set()))
    if value["complete_audio_approval"] is not False or value["commercial_performance_validated"] is not False:
        _reject("invalid_approval_claim")
    reference, processed = _base._metadata(value["reference"]), _base._metadata(value["processed"])
    rate = reference["sample_rate_hz"]
    analysis_rate = _base._integer(analysis["sample_rate_hz"], "invalid_analysis_method")
    hop = _base._number(analysis["hop_ms"], "invalid_analysis_method")
    if analysis_rate != rate or not math.isclose(hop, 1000 / rate, rel_tol=0, abs_tol=1e-12):
        _reject("invalid_analysis_method")
    configuration = _base._fields(value["configuration"],
        {"profile", "allow_gain", "allow_resampling", "max_delay_ms"}, code="invalid_configuration")
    if configuration["profile"] != "basic":
        _reject("unsupported_profile")
    if configuration["allow_gain"] is not False or configuration["allow_resampling"] is not False:
        _reject("unsupported_endpoint_configuration")
    _base._number(configuration["max_delay_ms"], "invalid_configuration", 0, 5000)
    delta = (reference["sample_count"] - processed["sample_count"]) * 1000 / rate
    if processed["sample_rate_hz"] != rate or not 50 - 1e-9 <= delta <= 2000 + 1e-9:
        _reject("unsupported_endpoint_configuration")
    limitations = value["limitations"]
    if (type(limitations) is not list or not 1 <= len(limitations) <= 32
            or any(type(item) is not str or not 1 <= len(item) <= 2000 for item in limitations)):
        _reject("invalid_limitations")
    if value["status"] == "withheld":
        _inherited(value, withheld_native=True)
    else:
        _native_analyzed(value, reference, processed)
    return value
