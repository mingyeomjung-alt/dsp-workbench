"""Opt-in native PCM proof for one short internal deletion or adjacent copy.

This is a deliberately narrow additional path, not a lower frame threshold in
the legacy aligner.  Every possible single-edit boundary is checked by native
sample prefix/suffix correspondence; the retained output is then independently
reconstructed.  Ambiguous or transformed inputs never become a clear result
through this path.  Other input scopes preserve the unchanged v9 engine.
"""

from copy import deepcopy
from pathlib import Path

import numpy as np

from . import global_context_engine
from .analysis_scope import analysis_scope
from .audio import WavAudio, read_wav
from .engine import EngineConfig, EngineConfigError, _corr


ENGINE = "local_content_alignment_v10"
METHOD = "short_event_exact_pcm_forward_proof"
MIN_EVENT_MS = 50
MAX_EVENT_MS = 200
CONTEXT_MS = 120
MAX_BOUNDARY_AMBIGUITY_MS = 1
_LIMITATION = (
    "v9 is preserved outside the new scope. The new path explains one 50-200ms "
    "internal deletion or canonical later adjacent full-copy at native PCM16 "
    "sample resolution, same sample rate and basic profile, with no declared "
    "gain or resampling. Every retained sample, including quiet samples and "
    "file endpoints, must match exactly. Unique informative 120ms flank "
    "contexts and at most 1ms boundary ambiguity are required. This is a "
    "bounded signal explanation, not edit provenance or complete audio approval."
)


def _eligible(reference: WavAudio, processed: WavAudio, settings: EngineConfig) -> bool:
    rate = reference.sample_rate_hz
    difference = abs(len(reference.samples) - len(processed.samples))
    eligible = (
        settings.profile == "basic"
        and not settings.allow_gain and not settings.allow_resampling
        and rate == processed.sample_rate_hz
        and MIN_EVENT_MS * rate <= difference * 1000 <= MAX_EVENT_MS * rate
    )
    if not eligible:
        return False
    # Exact zero padding/trimming is an already supported normal transform,
    # not an inserted copy or a content deletion. Preserve its v9 behavior,
    # but only after checking the entire retained native signal. A quiet or
    # changed nonzero endpoint must not escape into legacy no-event output.
    longer, shorter = ((reference.samples, processed.samples) if
                       len(reference.samples) > len(processed.samples) else
                       (processed.samples, reference.samples))
    if ((not np.any(longer[:difference]) and np.array_equal(longer[difference:], shorter))
            or (not np.any(longer[-difference:]) and np.array_equal(longer[:-difference], shorter))):
        return False
    return True


def _initial_result(reference: WavAudio, processed: WavAudio, settings: EngineConfig) -> dict:
    rate = reference.sample_rate_hz
    return {
        "schema_version": 1, "engine": ENGINE, "status": "withheld",
        "content_preservation_status": "withheld", "reason_code": None,
        "events": None, "complete_audio_approval": False,
        "commercial_performance_validated": False,
        "reference": reference.metadata(), "processed": processed.metadata(),
        "configuration": {"profile": settings.profile, "allow_gain": settings.allow_gain,
                          "allow_resampling": settings.allow_resampling,
                          "max_delay_ms": settings.max_delay_ms},
        "analysis": {"sample_rate_hz": rate, "hop_ms": 1000 / rate,
                     "method": METHOD, "minimum_event_duration_ms": MIN_EVENT_MS,
                     "maximum_cumulative_edit_shift_ms": 2000,
                     "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {},
        "limitations": ["Diagnostic candidates, not complete audio approval or fault provenance.",
                        _LIMITATION],
    }


def _matching_prefix(left: np.ndarray, right: np.ndarray) -> int:
    length = min(len(left), len(right))
    different = np.flatnonzero(left[:length] != right[:length])
    return int(different[0]) if len(different) else length


def _geometry_bounds(x: np.ndarray, y: np.ndarray) -> tuple[int, int, int, int]:
    """All single-edit boundaries are exactly the closed [first, last] range.

    For deletion the boundary is measured on the shorter processed axis; for
    insertion it is on the shorter reference axis.  Prefix and suffix tests
    include the complete endpoints, not only sparse local anchors.
    """
    common_length = min(len(x), len(y))
    prefix = _matching_prefix(x, y)
    suffix = _matching_prefix(x[::-1], y[::-1])
    return common_length - suffix, prefix, prefix, suffix


def _pcm_bytes(samples: np.ndarray) -> bytes:
    # WavAudio construction has already checked the exact PCM16 integer grid.
    return (samples * 32768).astype("<i2").tobytes()


def _occurrences(template: bytes, target: bytes) -> list[int]:
    """Return at most two exact sample-aligned matches, not byte-shift aliases."""
    found = []
    start = 0
    while len(found) < 2:
        point = target.find(template, start)
        if point < 0:
            break
        if point % 2 == 0:
            found.append(point // 2)
        start = point + 1
    return found


def _context_proof(x: np.ndarray, y: np.ndarray, spans: list[tuple[int, int, int]],
                   rate: int, left_context_end: int, right_context_start: int) -> tuple[dict | None, str | None]:
    width = max(2, round(CONTEXT_MS * rate / 1000))
    if left_context_end < width or right_context_start + width > len(x):
        return None, "short_event_insufficient_internal_context"
    x_bytes, y_bytes = _pcm_bytes(x), _pcm_bytes(y)
    contexts = []
    for start, offset in ((left_context_end - width, spans[0][2]),
                          (right_context_start, spans[1][2])):
        template = x[start:start + width]
        if float(np.std(template)) <= 1e-6:
            return None, "short_event_uninformative_context"
        pattern = _pcm_bytes(template)
        original_occurrences = _occurrences(pattern, x_bytes)
        processed_occurrences = _occurrences(pattern, y_bytes)
        if original_occurrences != [start] or processed_occurrences != [start + offset]:
            return None, "short_event_nonunique_context"
        contexts.append({"reference_start_sample": start,
                         "processed_start_sample": start + offset,
                         "sample_count": width,
                         "reference_match_count": len(original_occurrences),
                         "processed_match_count": len(processed_occurrences)})
    return {"context_samples": width, "context_matches": contexts}, None


def _correlations(x: np.ndarray, y: np.ndarray, spans: list[tuple[int, int, int]],
                  rate: int) -> list[list[float]] | None:
    """Measure three distinct informative windows on each retained side."""
    output = []
    width = max(2, round(40 * rate / 1000))
    for first, last, offset in spans:
        if last - first < 3 * width:
            return None
        positions = sorted({first, (first + last - width) // 2, last - width})
        scores = []
        for start in positions:
            a, b = x[start:start + width], y[start + offset:start + offset + width]
            if float(np.std(a)) <= 1e-6:
                return None
            score = _corr(a, b)
            if score < .90:
                return None
            scores.append(score)
        output.append(scores)
    return output


@analysis_scope
def analyze_buffers_with_trace(reference: WavAudio, processed: WavAudio,
                               config: EngineConfig | None = None) -> tuple[dict, dict]:
    settings = config if config is not None else EngineConfig()
    if not isinstance(settings, EngineConfig) or settings.profile != "basic":
        raise EngineConfigError("The short-event candidate supports basic only.")
    if not _eligible(reference, processed, settings):
        baseline, old_trace = global_context_engine.analyze_buffers_with_trace(reference, processed, settings)
        result = deepcopy(baseline)
        result["engine"], result["analysis"]["method"] = ENGINE, METHOD
        result["limitations"].append(_LIMITATION)
        return result, {"schema_version": 1, "engine": ENGINE, "analysis_engine": ENGINE,
                        "method": METHOD, "reference_sha256": reference.sha256,
                        "processed_sha256": processed.sha256,
                        "proof_path": "preserved_v9_result", "short_event_attempted": False,
                        "short_event_proved": False, "inherited_v9_trace": deepcopy(old_trace),
                        "baseline_status": baseline["status"],
                        "baseline_reason_code": baseline["reason_code"],
                        "result_status": result["status"], "reason_code": result["reason_code"]}

    result = _initial_result(reference, processed, settings)
    x, y = reference.samples, processed.samples
    rate = reference.sample_rate_hz
    trace = {"schema_version": 1, "engine": ENGINE, "analysis_engine": ENGINE, "method": METHOD,
             "reference_sha256": reference.sha256, "processed_sha256": processed.sha256,
             "proof_path": "native_pcm_short_single_edit", "short_event_attempted": True,
             "short_event_proved": False, "native_sample_rate_hz": rate,
             "reference_sample_count": len(x), "processed_sample_count": len(y),
             "search_complete": False, "every_output_sample_exact": False}

    def failure(reason: str) -> tuple[dict, dict]:
        result["reason_code"] = reason
        trace.update(result_status="withheld", reason_code=reason)
        return result, trace

    if min(float(np.std(x)), float(np.std(y))) <= 1e-6:
        return failure("short_event_insufficient_signal_variation")
    first, last, prefix, suffix = _geometry_bounds(x, y)
    trace.update(prefix_equal_sample_count=prefix, suffix_equal_sample_count=suffix,
                 single_edit_boundary_min_sample=first, single_edit_boundary_max_sample=last,
                 search_complete=True, every_supported_geometry_checked=True)
    if first > last:
        return failure("short_event_no_complete_single_edit_explanation")
    length = abs(len(x) - len(y))
    kind = "delete" if len(x) > len(y) else "repeat"
    if kind == "delete":
        candidates = np.arange(first, last + 1, dtype=np.int64)
    else:
        # A copy is not inferred merely from insertion length. For every
        # prefix/suffix-compatible insertion point, prove that the entire
        # inserted block is the immediately preceding source block.
        first = max(first, length)
        if first > last:
            return failure("short_event_insertion_not_adjacent_copy")
        unequal = x != y[length:length + len(x)]
        cumulative = np.concatenate(([0], np.cumsum(unequal, dtype=np.int64)))
        points = np.arange(first, last + 1, dtype=np.int64)
        candidates = points[(cumulative[points] - cumulative[points - length]) == 0]
    trace["supported_geometry_count"] = int(len(candidates))
    if not len(candidates):
        return failure("short_event_insertion_not_adjacent_copy")
    ambiguity = int(candidates[-1] - candidates[0])
    trace["supported_boundary_span_samples"] = ambiguity
    if ambiguity * 1000 > MAX_BOUNDARY_AMBIGUITY_MS * rate:
        return failure("short_event_ambiguous_single_edit_geometry")
    point = int(candidates[0] if kind == "delete" else candidates[-1])
    right = point + length if kind == "delete" else point
    context_left = point if kind == "delete" else point - length
    spans = [(0, point, 0), (right, len(x), -length if kind == "delete" else length)]
    contexts, reason = _context_proof(x, y, spans, rate, context_left, right)
    if contexts is None:
        return failure(reason)
    event_source = x[point:right] if kind == "delete" else x[point - length:point]
    if float(np.std(event_source)) <= 1e-6:
        return failure("short_event_uninformative_event_content")
    rendered = (np.concatenate((x[:point], x[right:])) if kind == "delete" else
                np.concatenate((x[:point], x[point - length:point], x[point:])))
    if not np.array_equal(rendered, y):
        return failure("short_event_whole_output_reconstruction_failed")
    correlations = _correlations(x, y, spans, rate)
    if correlations is None:
        return failure("short_event_insufficient_informative_retained_windows")
    before, after = 0.0, (-length if kind == "delete" else length) * 1000 / rate
    width = round(CONTEXT_MS * rate / 1000)
    left_corr = _corr(x[context_left - width:context_left], y[context_left - width:context_left])
    right_corr = _corr(x[right:right + width], y[right + spans[1][2]:right + spans[1][2] + width])
    evidence = {"boundary_correlation": min(left_corr, right_corr),
                "offset_before_ms": before, "offset_after_ms": after}
    if kind == "delete":
        event = {"type": "delete", "reference_interval_ms": [point * 1000 / rate, right * 1000 / rate],
                 "processed_boundary_ms": point * 1000 / rate, "evidence": evidence}
    else:
        original = y[point - length:point]
        added = y[point:point + length]
        copy_corr = _corr(event_source, added)
        adjacent = _corr(original, added)
        event = {"type": "repeat", "reference_source_interval_ms": [(point - length) * 1000 / rate,
                                                                      point * 1000 / rate],
                 "processed_added_interval_ms": [point * 1000 / rate, (point + length) * 1000 / rate],
                 "copy_interval_convention": "canonical_later_adjacent_copy_not_edit_provenance",
                 "evidence": {**evidence, "copy_correlation": copy_corr,
                              "adjacent_copy_correlation": adjacent}}
    matched = len(y) if kind == "delete" else len(x)
    minimum_corr = min(value for values in correlations for value in values)
    result.update(status="analyzed", reason_code=None, content_preservation_status="defect_candidates",
                  events=[event], alignment_segments=[], diagnostics={
                      "gain_estimate": 1.0, "applied_gain": 1.0, "matched_normalized_rmse": 0.0,
                      "matched_analysis_samples": matched, "anchor_run_count": 2,
                      "minimum_local_correlation": minimum_corr, "normalized_path_cost": 0.0})
    for (start, end, offset), scores in zip(spans, correlations, strict=True):
        result["alignment_segments"].append({"reference_interval_ms": [start * 1000 / rate, end * 1000 / rate],
            "processed_offset_ms": offset * 1000 / rate, "anchor_correlations": scores})
    trace.update(short_event_proved=True, result_status="analyzed", reason_code=None,
                 event_kind=kind, event_boundary_sample=point, event_length_samples=length,
                 exact_output_sample_count=len(y), every_output_sample_exact=True,
                 all_retained_native_samples_exact=True, complete_endpoints_included=True,
                 informative_context_proof=contexts, matched_native_samples=matched,
                 canonical_copy_is_edit_provenance=False)
    return result, trace


def analyze_buffers(reference: WavAudio, processed: WavAudio, config: EngineConfig | None = None) -> dict:
    return analyze_buffers_with_trace(reference, processed, config)[0]


def analyze_wavs_with_trace(reference_path: str | Path, processed_path: str | Path,
                            config: EngineConfig | None = None) -> tuple[dict, dict]:
    return analyze_buffers_with_trace(read_wav(reference_path), read_wav(processed_path), config)
