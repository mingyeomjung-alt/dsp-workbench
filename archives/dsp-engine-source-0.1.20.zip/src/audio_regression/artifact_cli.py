"""Read-only integrity verification against an externally retained SHA-256.

Exit zero means the listed bytes match the pinned manifest, not authentic
execution, audio approval, or commercial/performance validation.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import re
import sys

from .artifact_integrity import ArtifactVerificationError, verify_artifact_manifest


_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}\Z")


class _ArgumentsError(ValueError):
    pass


class _Parser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        # argparse's message can contain the caller's local path or token.
        raise _ArgumentsError("invalid_cli_arguments")


def _parser() -> argparse.ArgumentParser:
    parser = _Parser(
        prog="audio-artifact-check",
        description="Verify preserved files against an external manifest digest; never execute audio.",
    )
    commands = parser.add_subparsers(dest="command", required=True, parser_class=_Parser)
    verify = commands.add_parser("verify", help="Read and hash files only; no resealing or recovery.")
    verify.add_argument("--root", type=Path, required=True)
    verify.add_argument("--manifest", type=Path, required=True)
    verify.add_argument("--manifest-sha256", required=True)
    return parser


def _emit(value: dict) -> None:
    sys.stdout.write(json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n")


def _error(code: str, exit_code: int) -> dict:
    return {
        "schema_version": 1,
        "engine": "preserved_artifact_integrity_v1",
        "status": "not_verified" if exit_code == 2 else "error",
        "reason_code": code,
        "exit_code": exit_code,
        "quality_verdict": "not_assessed",
        "authenticity_verified": False,
        "execution_provenance_verified": False,
        "complete_audio_approval": False,
        "commercial_performance_validated": False,
        "network_used": False,
    }


def main(argv: list[str] | None = None) -> int:
    try:
        args = _parser().parse_args(argv)
        result = verify_artifact_manifest(
            args.root, args.manifest, expected_manifest_sha256=args.manifest_sha256,
        )
        _emit({**result, "exit_code": 0})
        return 0
    except _ArgumentsError:
        _emit(_error("invalid_cli_arguments", 3))
        return 3
    except ArtifactVerificationError as error:
        candidate = getattr(error, "code", None)
        code = candidate if type(candidate) is str and _CODE.fullmatch(candidate) else "artifact_verification_error"
        _emit(_error(code, 2))
        return 2
    except Exception:
        _emit(_error("artifact_internal_error", 3))
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
