"""Offline presentation of an explicit expected-signal comparison.

Only the bounded, validated saved result is used. No audio, trace, model file,
artifact, or referenced local path is reopened by these report functions.
"""

from html import escape
from pathlib import Path
import re

from .model_contract import validate_model_result
from .model_check import ModelCheckError
from .pipeline_runner import PipelineRunError, _absolute_path, _normal_parents
from .reporting import _STYLE
from .review_presenter import render_review_diagnostics


_LOCAL_PATH = re.compile(
    r"(?:[A-Za-z]:[\\/]|\\\\|file://|/(?:Users|home|tmp|mnt|var|etc)/)[^\s<>\"']*"
    r"|(?<!\S)/(?!/)[^\s<>\"']+", re.IGNORECASE,
)
_MODELS = {
    "polarity_invert": "극성 반전",
    "fir_binomial_3": "고정 3탭 FIR · 1/4, 1/2, 1/4",
    "pcm_quantize_12": "고정 PCM12 양자화",
}
_MODEL_DETAILS = {
    "polarity_invert": "PCM16 정수 부호 반전 · −32768 입력은 범위 초과로 거부",
    "fir_binomial_3": "인과적 영 상태 · 길이/샘플률 유지 · 1샘플 군지연 · 끝 꼬리 미추가",
    "pcm_quantize_12": "PCM16 정수 격자 16단위 · ties-to-even 반올림 · 범위 초과 거부",
}
_SUMMARY_TITLES = {
    "declared_model_matched": "선언한 모델과 PCM16 일치 · 좁은 검사 완료",
    "temporal_defect_candidates": "시간적 결함 후보 · 검토 필요",
    "temporal_comparison_withheld": "시간 비교 판단 보류",
    "declared_model_unexplained_difference": "선언한 모델로 설명되지 않는 차이 · 판단 보류",
}


def _e(value: object) -> str:
    return escape(_LOCAL_PATH.sub("[로컬 경로 생략]", str(value)), quote=True)


def _n(value: int | float) -> str:
    return f"{value:,.3f}".rstrip("0").rstrip(".")


def _plan(result: dict) -> str:
    rows = []
    for index, model in enumerate(result["model_plan"]["models"], 1):
        rows.append(
            '<tr><td>' + _e(index) + '</td><td>' + _e(_MODELS.get(model["kind"], model["kind"]))
            + '</td><td>' + _e(_MODEL_DETAILS[model["kind"]]) + '</td></tr>'
        )
    return (
        '<section class="card"><h2>선언한 모델 · 실행 순서</h2><div class="table-wrap"><table>'
        '<thead><tr><th>순서</th><th>모델</th><th>고정한 사양</th></tr></thead><tbody>'
        + ''.join(rows) + '</tbody></table></div>'
        '<p class="scope muted">모델은 위 순서대로 적용합니다. 이 사양으로 만든 기대 신호를 실제 처리본과 비교하며, '
        '매 단계마다 PCM16 ties-to-even 양자화를 적용합니다. 관찰된 결과를 보고 모델을 자동 추정하거나 '
        '바꾸지 않으며, 범위 초과를 클리핑으로 숨기지 않습니다.</p></section>'
    )


def _metadata(result: dict) -> str:
    fields = (
        ("sample_rate_hz", "샘플률 (Hz)"), ("sample_count", "샘플 수"),
        ("duration_ms", "길이 (ms)"), ("channels", "채널"),
        ("encoding", "인코딩"), ("rms", "RMS"), ("peak", "피크"),
        ("sha256", "파일 SHA-256"),
    )
    rows = []
    for field, label in fields:
        cells = []
        for name in ("source", "expected", "processed"):
            value = result[name][field]
            rendered = _n(value) if type(value) in (int, float) else value
            cells.append('<td><code class="hash">' + _e(rendered) + '</code></td>')
        rows.append('<tr><td>' + _e(label) + '</td>' + ''.join(cells) + '</tr>')
    return (
        '<section class="card"><h2>입력과 기대 신호 기록</h2><div class="table-wrap"><table>'
        '<thead><tr><th>항목</th><th>모델 입력</th><th>기대 신호</th><th>실제 처리본</th></tr></thead><tbody>'
        + ''.join(rows) + '</tbody></table></div>'
        '<p class="scope muted">해시는 저장된 파일을 구별하는 기록입니다. 보고서를 생성할 때 해당 파일을 열거나 '
        '현재 디스크 파일의 무결성을 다시 확인하지 않습니다.</p></section>'
    )


def _events(analysis: dict) -> str:
    if analysis["status"] == "withheld":
        return '<p>기대 신호와 실제 처리본의 시간적 판단은 보류되었습니다.</p>' + render_review_diagnostics(analysis)
    if not analysis["events"]:
        return (
            '<p>지원 범위의 시간적 결함 후보 없음</p>'
            '<p class="scope muted">이 하위 결과가 선언한 모델의 전체 PCM16 일치를 뜻하지는 않습니다. '
            '상단의 모델 비교 판정이 우선합니다.</p>'
        )
    rows = []
    for event in analysis["events"]:
        if event["type"] == "delete":
            interval = event["reference_interval_ms"]
            expected = f'{_n(interval[0])}–{_n(interval[1])} ms (삭제 후보 구간)'
            actual = f'{_n(event["processed_boundary_ms"])} ms (대응 경계)'
            label = "삭제 후보"
        else:
            interval = event["reference_source_interval_ms"]
            expected = f'{_n(interval[0])}–{_n(interval[1])} ms (복사 출처)'
            interval = event["processed_added_interval_ms"]
            actual = f'{_n(interval[0])}–{_n(interval[1])} ms (뒤쪽 인접 복사)'
            label = "반복 후보"
        rows.append('<tr><td>' + _e(label) + '</td><td>' + _e(expected) + '</td><td>' + _e(actual) + '</td></tr>')
    return (
        '<div class="table-wrap"><table><thead><tr><th>후보</th><th>기대 신호 시간축</th>'
        '<th>실제 처리본 시간축</th></tr></thead><tbody>' + ''.join(rows) + '</tbody></table></div>'
        '<p class="scope muted">좌표는 기대 신호와 실제 처리본의 독립된 시간축입니다. 같은 길이의 선언 모델은 '
        '모델 입력과 기대 신호의 좌표를 유지하지만, 실제 결함의 원인이나 편집 행위를 확정하지 않습니다.</p>'
    )


def render_model_html(result: dict) -> str:
    """Render validated saved diagnostics; the strict top-level gate stays first."""
    validate_model_result(result)
    summary, comparison = result["summary"], result["comparison"]
    state = {0: "clear", 1: "review", 2: "blocked"}[summary["exit_code"]]
    title = _SUMMARY_TITLES[summary["reason_code"]]
    exact = "일치" if comparison["exact_pcm16_match"] else "불일치"
    unequal = comparison["unequal_sample_count"]
    maximum = comparison["maximum_abs_error_pcm16"]
    unequal_text = "길이 불일치 · 미계산" if unequal is None else str(unequal)
    maximum_text = "길이 불일치 · 미계산" if maximum is None else str(maximum)
    analysis = result["analysis"]
    return (
        '<!doctype html>\n<html lang="ko"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; '
        'style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\'">'
        '<title>명시적 DSP 모델 비교 보고서</title><style>' + _STYLE + '</style></head><body><main>'
        '<header><div class="eyebrow">DECLARED DSP MODEL / STORED RESULT</div>'
        '<h1>명시적 DSP 모델 비교 보고서</h1><span class="badge">LOCAL · OFFLINE</span>'
        '<span class="badge">기대 신호 ↔ 실제 처리본</span></header>'
        '<section class="card summary ' + state + '" data-model-gate="' + _e(summary["gate_state"]) + '">'
        '<div class="state">모델 비교 · 최상위 판정</div><h2>' + _e(title) + '</h2>'
        '<p class="scope">사유: <code>' + _e(summary["reason_code"]) + '</code></p>'
        '<div class="metrics"><div class="metric"><span>종료 코드</span><b>' + _e(summary["exit_code"])
        + '</b></div><div class="metric"><span>기대·실제 PCM16</span><b>' + _e(exact)
        + '</b></div><div class="metric"><span>다른 샘플 수</span><b>'
        + _e(unequal_text) + '</b></div></div>'
        '<p>최대 절대 PCM16 정수 차이: <strong>' + _e(maximum_text) + '</strong></p>'
        '<p class="scope muted">전체 PCM16 불일치는 하위 시간 검사에서 후보가 없더라도 해제되지 않습니다. '
        '코드 0은 선언한 모델과 이 입력쌍의 제한된 검사만 완료했다는 뜻이며 전체 음질 승인이 아닙니다.</p></section>'
        + _plan(result) + _metadata(result)
        + '<section class="card"><h2>기대 신호 ↔ 실제 처리본 · 시간 검사</h2>'
        '<p class="scope muted">선택한 분석 엔진: <code>' + _e(analysis["engine"]) + '</code> · '
        '하위 종료 코드 ' + _e(result["temporal_check"]["exit_code"]) + '. '
        '분석은 8 kHz 대역 제한 시간 비교이며, 입력 원래 샘플률의 전대역 음질 분석이 아닙니다.</p>'
        + _events(analysis) + '</section>'
        '<section class="card notice"><h2>해석 범위와 보존</h2><p>명시적으로 선언한 극성·FIR·PCM 양자화 모델의 '
        '기대 출력과 실제 처리본을 비교합니다. 일반 코덱이나 임의 필터를 자동 식별하지 않습니다.</p>'
        '<p>모델 일치와 시간적 후보는 진단 정보입니다. 전체 음질 승인, 상용 성능 검증, 보정된 확률 또는 '
        '결함 원인 확정이 아닙니다.</p><p class="scope muted">저장된 JSON만 표시합니다. 오디오·추적 파일·모델 파일을 '
        '열거나 재분석하지 않습니다. 절대 경로, 오디오, 실행 스크립트와 외부 자원은 포함하지 않습니다.</p></section>'
        '<footer>자체 포함 정적 HTML · 선언 사양과 저장된 비교 결과만 표시</footer></main></body></html>\n'
    )


def write_model_html(result: dict, path: str | Path) -> None:
    """Create an exclusive standalone HTML file after validation."""
    rendered = render_model_html(result)
    try:
        destination = _absolute_path(path)
        _normal_parents(destination)
    except PipelineRunError:
        raise ModelCheckError("unsafe_model_report_path") from None
    with destination.open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(rendered)
