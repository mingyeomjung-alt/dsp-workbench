"""Handoff commands around the strict, physical-time analysis CLI."""

import argparse
import json
from pathlib import Path
import sys

from . import cli as legacy_cli
from .check_policy import blocked_contract_error, check_result
from .reporting import write_html_report
from .result_contract import ResultContractError, load_analysis_result


def _emit(value: dict) -> None:
    sys.stdout.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="audio-regression",
        description="Local temporal candidate analysis, offline reports, and conservative checks.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    for name, help_text in (
        ("generate", "Create a new synthetic pair (unchanged M3 command)."),
        ("compare", "Measure the global baseline (unchanged M3 command)."),
        ("analyze", "Analyze temporal candidates with strict physical-time endpoints."),
    ):
        commands.add_parser(name, help=help_text, add_help=False)
    report = commands.add_parser("report", help="Create a new offline HTML report from a stored analysis result.")
    report.add_argument("--input", type=Path, required=True, help="Stored analysis-result JSON; audio is not reanalyzed.")
    report.add_argument("--output", type=Path, required=True, help="New HTML file; an existing file is never replaced.")
    check = commands.add_parser("check", help="Check a stored analysis result: clear=0, review=1, blocked=2.")
    check.add_argument("--input", type=Path, required=True, help="Stored analysis-result JSON; telephone is experimental and blocked.")
    return parser


def _check_load_error(code: str) -> dict:
    # Reuse the policy's invalid-input envelope, retaining the loader's cause.
    summary = blocked_contract_error(code)
    summary["status"] = "error"
    return summary


def main(argv: list[str] | None = None) -> int:
    """Delegate every legacy argument unchanged; handle only report and check."""
    arguments = list(sys.argv[1:] if argv is None else argv)
    if arguments and arguments[0] in {"generate", "compare", "analyze"}:
        return legacy_cli.main(arguments)
    args = _parser().parse_args(arguments)
    try:
        if args.command == "report" and args.input.resolve() == args.output.resolve():
            raise FileExistsError("An output file already exists.")
        result = load_analysis_result(args.input)
        if args.command == "check":
            summary = check_result(result)
            _emit(summary)
            return summary["exit_code"]
        write_html_report(result, args.output)
        _emit({"schema_version": 1, "status": "generated_html", "output": str(args.output)})
        return 0
    except ResultContractError as exc:
        code = exc.code
    except FileExistsError:
        code = "output_exists"
    except OSError:
        code = "file_write_error" if args.command == "report" else "file_read_error"
    if args.command == "check":
        _emit(_check_load_error(code))
        return 2
    _emit({"schema_version": 1, "status": "error", "reason_code": code})
    return 3


if __name__ == "__main__":
    raise SystemExit(main())
