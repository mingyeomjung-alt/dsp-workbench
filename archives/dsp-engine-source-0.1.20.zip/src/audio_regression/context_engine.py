"""Opt-in basic-profile candidate with bounded active-context bridges.

The original v1 and PCM16 candidate v2 remain unchanged. A bridge repairs only
short balanced cancellations when nearby quiet context prevents the ordinary
v2 proof. Every sample in the selected bracket is checked; no audio is changed.
"""

from __future__ import annotations

import math
from pathlib import Path

import numpy as np

from .alignment import edit_align
from .analysis_scope import analysis_scope
from .audio import WavAudio, read_wav
from .engine import (
    EDGE_TOLERANCE_SAMPLES, HOP, MAX_EDIT_SHIFT_SAMPLES, MIN_EVENT_SAMPLES,
    RATE, EngineConfig, EngineConfigError, _adjacent_copy, _boundary,
    _coalesce_transitions, _corr, _locate, _silent_original_edge,
)
from .features import extract_features
from .profiles import prepare_analysis
from .robust_engine import (
    CONTEXT_SAMPLES, MINIMUM_CORRELATION, PCM16_STEP, REVALIDATION_POLICY,
    TRACE_RUN_LIMIT, _finish_withheld, _merge_revalidated_matches,
    _revalidate_compound, _rms, _trusted_matches,
)


ENGINE = "local_content_alignment_v3"
METHOD = "constrained_edit_alignment_with_bounded_active_context_bridge"
MAXIMUM_BRIDGE_SAMPLES = 1200 * RATE // 1000
MINIMUM_ACTIVITY = 8 * PCM16_STEP
BRIDGE_POLICY = {
    "maximum_cluster_duration_ms": 1200.0,
    "maximum_context_extent_ms": 1200.0,
    "maximum_compound_duration_ms": 40.0,
    "context_duration_ms": 240.0,
    "outward_scan_hop_ms": 10.0,
    "minimum_context_rms_pcm16_steps": 8.0,
    "minimum_context_correlation": .90,
    "minimum_rival_peak_margin": .03,
    "measured_rival_peak_evidence_required": True,
    "raw_search_radius_ms": 40.0,
    "maximum_residual_steps_multiplier": 2.0,
    "rms_residual_steps_multiplier": 1.0,
    "only_ordinary_low_activity_failure_is_eligible": True,
    "original_runs_and_independent_anchors_only": True,
    "first_active_window_only": True,
    "internal_both_sided_clusters_only": True,
    "every_bracket_sample_including_intermediate_matches_is_checked": True,
    "fixed_bracket_final_gain_reproof_required": True,
    "fresh_merged_anchor_requires_exact_proven_offset": True,
}


def _coordinates(run: dict, x: np.ndarray, y: np.ndarray) -> tuple[int, int, int, int]:
    return (run["reference_start_frame"] * HOP,
            min(len(x), run["reference_end_frame"] * HOP),
            run["processed_start_frame"] * HOP,
            min(len(y), run["processed_end_frame"] * HOP))


def _eligible_compound(run: dict) -> bool:
    reference = run["reference_end_frame"] - run["reference_start_frame"]
    processed = run["processed_end_frame"] - run["processed_start_frame"]
    return run["kind"] == "compound" and 0 < reference * HOP <= EDGE_TOLERANCE_SAMPLES and reference == processed


def _frame_offset(run: dict) -> int:
    return (run["processed_start_frame"] - run["reference_start_frame"]) * HOP


def _bounded_clusters(runs: list[dict]) -> list[tuple[int, int]]:
    """Earliest-first maximal eligible clusters from the original coalesced runs.

    Only equal-axis, same-offset matches may separate compounds. A cluster is
    never allowed to cross a real gap, large compound, or a net offset change.
    """
    clusters, index = [], 0
    while index < len(runs):
        if not _eligible_compound(runs[index]):
            index += 1
            continue
        first = last = index
        offset = _frame_offset(runs[first])
        cursor = index + 1
        previous = runs[index]
        while cursor < len(runs):
            run = runs[cursor]
            contiguous = (previous["reference_end_frame"] == run["reference_start_frame"]
                          and previous["processed_end_frame"] == run["processed_start_frame"])
            balanced = (run["reference_end_frame"] - run["reference_start_frame"]
                        == run["processed_end_frame"] - run["processed_start_frame"])
            if not contiguous or not balanced or _frame_offset(run) != offset:
                break
            if run["kind"] == "compound":
                if not _eligible_compound(run):
                    break
                span = (run["reference_end_frame"] - runs[first]["reference_start_frame"]) * HOP
                if span > MAXIMUM_BRIDGE_SAMPLES:
                    break
                last = cursor
            elif run["kind"] != "match":
                break
            previous = run
            cursor += 1
        clusters.append((first, last))
        index = last + 1
    return clusters


def _raw_window(first: int, last: int, offset: int, x: np.ndarray,
                y: np.ndarray, gain: float, side: str) -> dict:
    record = {"side": side, "reference_interval_samples": [first, last],
              "processed_interval_samples": [first + offset, last + offset],
              "reference_rms_at_applied_gain": None, "processed_rms": None,
              "correlation": None, "located_processed_start_sample": None,
              "rival_peak_margin": None, "accepted": False, "reason_code": None}
    if first < 0 or last > len(x) or first + offset < 0 or last + offset > len(y) or last - first != CONTEXT_SAMPLES:
        record["reason_code"] = "context_coordinates_outside_audio"
        return record
    a, b = x[first:last], y[first + offset:last + offset]
    record["reference_rms_at_applied_gain"], record["processed_rms"] = _rms(gain * a), _rms(b)
    if min(record["reference_rms_at_applied_gain"], record["processed_rms"]) < MINIMUM_ACTIVITY:
        record["reason_code"] = "raw_context_below_quantization_activity_floor"
        return record
    record["correlation"] = _corr(a, b)
    if record["correlation"] < MINIMUM_CORRELATION:
        record["reason_code"] = "first_active_context_correlation_not_supported"
        return record
    record["accepted"] = True
    return record


def _check_selected_window(window: dict, outer: dict, offset: int,
                           x: np.ndarray, y: np.ndarray, gain: float) -> dict:
    """Verify one fixed active window. This function never selects a new one."""
    first, last = window["reference_interval_samples"]
    record = _raw_window(first, last, offset, x, y, gain, window["side"])
    if not record["accepted"]:
        return record
    oi0, oi1, oj0, oj1 = _coordinates(outer, x, y)
    if first < oi0 or last > oi1 or first + offset < oj0 or last + offset > oj1:
        record.update(accepted=False, reason_code="selected_window_outside_original_outer_match")
        return record
    expected = first + offset
    located = _locate(x[first:last], y, max(oj0, expected - EDGE_TOLERANCE_SAMPLES),
                      min(oj1 - CONTEXT_SAMPLES, expected + EDGE_TOLERANCE_SAMPLES))
    if located is not None:
        record["located_processed_start_sample"] = located["start"]
        record["rival_peak_margin"] = located["peak_margin"]
    if (located is None or located["start"] != expected
            or located["correlation"] < MINIMUM_CORRELATION
            or located["peak_margin"] is None or located["peak_margin"] < .03):
        record.update(accepted=False, reason_code="first_active_context_not_unique_at_proven_offset")
        return record
    record["reason_code"] = "active_context_independently_revalidated"
    return record


def _select_bracket(side: str, first: int, last: int, outer: dict, offset: int,
                    x: np.ndarray, y: np.ndarray, gain: float) -> tuple[dict | None, dict]:
    oi0, oi1, oj0, oj1 = _coordinates(outer, x, y)
    scan = {"side": side, "scanned_window_count": 0, "selected": None, "reason_code": None}
    if side == "before":
        closest = first - CONTEXT_SAMPLES
        lower = max(oi0, first - MAXIMUM_BRIDGE_SAMPLES, -offset)
        candidates = range(closest, lower - 1, -HOP)
    else:
        closest = last
        upper = min(oi1 - CONTEXT_SAMPLES, last + MAXIMUM_BRIDGE_SAMPLES - CONTEXT_SAMPLES,
                    len(y) - offset - CONTEXT_SAMPLES)
        candidates = range(closest, upper + 1, HOP)
    for start in candidates:
        end = start + CONTEXT_SAMPLES
        if start < oi0 or end > oi1 or start + offset < oj0 or end + offset > oj1:
            continue
        scan["scanned_window_count"] += 1
        candidate = _raw_window(start, end, offset, x, y, gain, side)
        if candidate["reason_code"] == "raw_context_below_quantization_activity_floor":
            continue
        # Activity selects the window, not correlation. A bad first active
        # window ends the proof; never search for a more favorable later one.
        selected = _check_selected_window(candidate, outer, offset, x, y, gain)
        scan["selected"], scan["reason_code"] = selected, selected["reason_code"]
        return selected, scan
    scan["reason_code"] = "no_active_context_within_bounded_original_match"
    return None, scan


def _whole_bracket_proof(first: int, last: int, offset: int, x: np.ndarray,
                         y: np.ndarray, gain: float) -> dict:
    record = {"reference_interval_samples": [first, last],
              "processed_interval_samples": [first + offset, last + offset],
              "sample_count": last - first, "applied_gain": gain,
              "maximum_absolute_residual": None, "rms_residual": None,
              "maximum_residual_step": None,
              "maximum_absolute_residual_bound": 2 * PCM16_STEP * (1 + abs(gain)),
              "rms_residual_bound": PCM16_STEP * (1 + abs(gain)),
              "accepted": False, "reason_code": None}
    if (not math.isfinite(gain) or gain <= 0 or first < 1 or last >= len(x)
            or first + offset < 1 or last + offset >= len(y) or last <= first):
        record["reason_code"] = "whole_bracket_coordinates_or_gain_not_supported"
        return record
    residual = y[first + offset:last + offset] - gain * x[first:last]
    record["maximum_absolute_residual"] = float(np.max(np.abs(residual)))
    record["rms_residual"] = _rms(residual)
    if (record["maximum_absolute_residual"] > record["maximum_absolute_residual_bound"]
            or record["rms_residual"] > record["rms_residual_bound"]):
        record["reason_code"] = "whole_bracket_samples_exceed_pcm16_error_budget"
        return record
    extended = y[first + offset - 1:last + offset + 1] - gain * x[first - 1:last + 1]
    record["maximum_residual_step"] = float(np.max(np.abs(np.diff(extended))))
    if record["maximum_residual_step"] > 2 * record["maximum_absolute_residual_bound"]:
        record["reason_code"] = "whole_bracket_boundary_continuity_not_supported"
        return record
    record.update(accepted=True, reason_code="whole_bracket_pcm16_residual_revalidated")
    return record


def _bridge_cluster(first_index: int, last_index: int, runs: list[dict], anchored: dict,
                    ordinary: dict[int, dict], x: np.ndarray, y: np.ndarray, gain: float) -> dict:
    record = {"first_run_index": first_index, "last_run_index": last_index,
              "compound_run_indices": [], "accepted": False, "reason_code": None,
              "offset_samples": None, "initial_applied_gain": gain,
              "scans": [], "whole_bracket": None, "final_gain_reproof": None}

    def reject(code: str) -> dict:
        record["reason_code"] = code
        return record

    if first_index < 1 or last_index >= len(runs) - 1:
        return reject("bridge_is_not_internal_and_both_sided")
    cluster = runs[first_index:last_index + 1]
    if not cluster or not _eligible_compound(cluster[0]) or not _eligible_compound(cluster[-1]):
        return reject("bridge_cluster_not_bounded_balanced_cancellations")
    low_activity = False
    for index in range(first_index, last_index + 1):
        run = runs[index]
        if run["kind"] == "compound":
            if not _eligible_compound(run):
                return reject("bridge_cluster_not_bounded_balanced_cancellations")
            record["compound_run_indices"].append(index)
            prior = ordinary.get(index)
            if prior is None or (not prior["accepted"] and prior["reason_code"] != "raw_context_below_quantization_activity_floor"):
                return reject("ordinary_failure_is_not_only_low_context_activity")
            low_activity |= not prior["accepted"]
        elif run["kind"] != "match":
            return reject("bridge_cluster_crosses_edit_or_unsupported_compound")
    if not low_activity:
        return reject("ordinary_low_activity_failure_not_present")
    before, after = anchored.get(first_index - 1), anchored.get(last_index + 1)
    if before is None or after is None or before["offset_samples"] != after["offset_samples"]:
        return reject("bridge_independent_outer_anchor_offsets_not_equal")
    offset = before["offset_samples"]
    record["offset_samples"] = offset
    all_runs = runs[first_index - 1:last_index + 2]
    previous = None
    for run in all_runs:
        i0, i1, j0, j1 = _coordinates(run, x, y)
        if i1 <= i0 or i1 - i0 != j1 - j0 or j0 - i0 != offset or j1 - i1 != offset:
            return reject("bridge_coordinates_not_contiguous_at_proven_offset")
        if previous is not None and (previous[1] != i0 or previous[3] != j0):
            return reject("bridge_coordinates_not_contiguous_at_proven_offset")
        previous = i0, i1, j0, j1
    first, _, _, _ = _coordinates(cluster[0], x, y)
    _, last, _, _ = _coordinates(cluster[-1], x, y)
    if last - first > MAXIMUM_BRIDGE_SAMPLES:
        return reject("bridge_cluster_duration_outside_budget")
    if not math.isfinite(gain) or gain <= 0:
        return reject("bridge_gain_not_positive_and_finite")
    left, scan = _select_bracket("before", first, last, runs[first_index - 1], offset, x, y, gain)
    record["scans"].append(scan)
    if left is None or not left["accepted"]:
        return reject(scan["reason_code"])
    right, scan = _select_bracket("after", first, last, runs[last_index + 1], offset, x, y, gain)
    record["scans"].append(scan)
    if right is None or not right["accepted"]:
        return reject(scan["reason_code"])
    proof = _whole_bracket_proof(left["reference_interval_samples"][0],
                                 right["reference_interval_samples"][1], offset, x, y, gain)
    record["whole_bracket"] = proof
    if not proof["accepted"]:
        return reject(proof["reason_code"])
    record.update(accepted=True, reason_code="bounded_active_context_bridge_revalidated")
    return record


def _final_bridge_proof(record: dict, original_runs: list[dict], final_anchors: dict,
                        x: np.ndarray, y: np.ndarray, gain: float) -> dict:
    first, last = record["whole_bracket"]["reference_interval_samples"]
    offset = record["offset_samples"]
    covering = [anchor for anchor in final_anchors.values()
                if anchor["reference_start_frame"] * HOP <= first
                and min(len(x), anchor["reference_end_frame"] * HOP) >= last]
    reproof = {"applied_gain": gain, "accepted": False, "reason_code": None,
               "merged_anchor_offsets_samples": [anchor["offset_samples"] for anchor in covering],
               "contexts": [], "whole_bracket": None}
    if len(covering) != 1 or covering[0]["offset_samples"] != offset:
        reproof["reason_code"] = "fresh_merged_anchor_does_not_have_exact_proven_offset"
        return reproof
    for scan, index in zip(record["scans"], (record["first_run_index"] - 1, record["last_run_index"] + 1)):
        context = _check_selected_window(scan["selected"], original_runs[index], offset, x, y, gain)
        reproof["contexts"].append(context)
        if not context["accepted"]:
            reproof["reason_code"] = context["reason_code"]
            return reproof
    proof = _whole_bracket_proof(first, last, offset, x, y, gain)
    reproof["whole_bracket"] = proof
    reproof.update(accepted=proof["accepted"], reason_code=proof["reason_code"])
    return reproof


@analysis_scope
def analyze_buffers_with_trace(reference: WavAudio, processed: WavAudio,
                               config: EngineConfig | None = None) -> tuple[dict, dict]:
    settings = config if config is not None else EngineConfig()
    if not isinstance(settings, EngineConfig) or settings.profile != "basic":
        raise EngineConfigError("The bounded active-context candidate supports only the basic profile.")
    result = {
        "schema_version": 1, "engine": ENGINE,
        "status": "withheld", "content_preservation_status": "withheld",
        "reason_code": None, "events": None,
        "complete_audio_approval": False, "commercial_performance_validated": False,
        "reference": reference.metadata(), "processed": processed.metadata(),
        "configuration": {"profile": settings.profile, "allow_gain": settings.allow_gain,
                          "allow_resampling": settings.allow_resampling, "max_delay_ms": settings.max_delay_ms},
        "analysis": {"sample_rate_hz": RATE, "hop_ms": 10.0, "method": METHOD,
                     "minimum_event_duration_ms": 200, "maximum_cumulative_edit_shift_ms": 2000,
                     "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {},
        "limitations": ["Diagnostic candidates, not complete audio approval or fault provenance.",
                        "Identifiable internal deletion or adjacent-copy repetition only.",
                        "No full-band quality, network loss cause, or actual telephone performance claim."],
    }
    trace = {"schema_version": 1, "engine": "bounded_active_context_trace_v1",
             "analysis_engine": ENGINE, "reference_sha256": reference.sha256,
             "processed_sha256": processed.sha256,
             "policy": {"ordinary": dict(REVALIDATION_POLICY), "bridge": dict(BRIDGE_POLICY)},
             "raw_runs": [], "coalesced_runs": [], "revalidated_runs": [],
             "revalidations": [], "bridge_attempts": [], "result_status": None,
             "withheld_branch": None, "trace_truncated": False}
    if reference.sample_rate_hz != processed.sample_rate_hz and not settings.allow_resampling:
        return _finish_withheld(result, trace, "resampling_not_declared")
    if min(float(np.std(reference.samples)), float(np.std(processed.samples))) <= 1e-6:
        return _finish_withheld(result, trace, "insufficient_signal_variation")
    x, y = prepare_analysis(reference, "basic"), prepare_analysis(processed, "basic")
    if min(float(np.std(x)), float(np.std(y))) <= 1e-6:
        return _finish_withheld(result, trace, "insufficient_analysis_band_signal")
    path = edit_align(extract_features(x), extract_features(y),
                      math.ceil(settings.max_delay_ms * RATE / 1000 / HOP) + MAX_EDIT_SHIFT_SAMPLES // HOP)
    if path["status"] != "aligned":
        return _finish_withheld(result, trace, path["reason_code"])
    result["diagnostics"]["normalized_path_cost"] = path["normalized_path_cost"]
    original_runs = _coalesce_transitions(path["runs"])
    trace["raw_runs"] = [dict(run) for run in path["runs"][:TRACE_RUN_LIMIT]]
    trace["coalesced_runs"] = [dict(run) for run in original_runs[:TRACE_RUN_LIMIT]]
    trace["trace_truncated"] = len(path["runs"]) > TRACE_RUN_LIMIT or len(original_runs) > TRACE_RUN_LIMIT
    original_anchors, gain, reason = _trusted_matches(original_runs, x, y, settings, result)
    if reason:
        return _finish_withheld(result, trace, reason)
    accepted, ordinary = set(), {}
    for index, run in enumerate(original_runs):
        if run["kind"] != "compound":
            continue
        record = _revalidate_compound(index, original_runs, original_anchors, x, y, gain)
        ordinary[index] = record
        if len(trace["revalidations"]) < TRACE_RUN_LIMIT:
            trace["revalidations"].append(record)
        else:
            trace["trace_truncated"] = True
        if record["accepted"]:
            accepted.add(index)
    # All clusters and their proof sources are frozen original runs/anchors.
    # Repairs from earlier clusters cannot create evidence for later clusters.
    accepted_bridges = []
    for first, last in _bounded_clusters(original_runs):
        if not any(not ordinary[index]["accepted"] and ordinary[index]["reason_code"] == "raw_context_below_quantization_activity_floor"
                   for index in range(first, last + 1) if original_runs[index]["kind"] == "compound"):
            continue
        record = _bridge_cluster(first, last, original_runs, original_anchors, ordinary, x, y, gain)
        if len(trace["bridge_attempts"]) < TRACE_RUN_LIMIT:
            trace["bridge_attempts"].append(record)
        else:
            trace["trace_truncated"] = True
        if record["accepted"]:
            accepted.update(record["compound_run_indices"])
            accepted_bridges.append(record)
    runs = _merge_revalidated_matches(original_runs, accepted) if accepted else original_runs
    anchored = original_anchors
    if accepted:
        anchored, final_gain, reason = _trusted_matches(runs, x, y, settings, result)
        if reason:
            trace["revalidated_runs"] = [dict(run) for run in runs[:TRACE_RUN_LIMIT]]
            return _finish_withheld(result, trace, reason)
        for record in accepted_bridges:
            reproof = _final_bridge_proof(record, original_runs, anchored, x, y, final_gain)
            record["final_gain_reproof"] = reproof
            if not reproof["accepted"]:
                trace["revalidated_runs"] = [dict(run) for run in runs[:TRACE_RUN_LIMIT]]
                return _finish_withheld(result, trace, "active_context_bridge_final_gain_reproof_failed")
        gain = final_gain
    trace["revalidated_runs"] = [dict(run) for run in runs[:TRACE_RUN_LIMIT]]
    first_offset = next(iter(anchored.values()))["offset_samples"]
    last_offset = list(anchored.values())[-1]["offset_samples"]
    edge_lengths = {
        ("delete", "start"): max(0, -first_offset),
        ("insert", "start"): max(0, first_offset),
        ("delete", "end"): max(0, len(x) + last_offset - len(y)),
        ("insert", "end"): max(0, len(y) - len(x) - last_offset),
    }
    events = []
    for index, run in enumerate(runs):
        if run["kind"] == "match":
            continue
        if run["kind"] == "compound":
            return _finish_withheld(result, trace, "compound_or_unidentified_change")
        i0, i1, j0, j1 = _coordinates(run, x, y)
        edge = index == 0 or index == len(runs) - 1
        content = x[i0:i1] if run["kind"] == "delete" else y[j0:j1]
        if edge:
            original = reference if run["kind"] == "delete" else processed
            side = "start" if index == 0 else "end"
            padding = edge_lengths[(run["kind"], side)]
            signal_length = len(x) if run["kind"] == "delete" else len(y)
            edge_start, edge_end = (0, padding) if side == "start" else (signal_length - padding, signal_length)
            if abs(len(content) - padding) <= EDGE_TOLERANCE_SAMPLES and _silent_original_edge(original, edge_start, edge_end):
                continue
            return _finish_withheld(result, trace, "non_silent_file_edge_change")
        if max(i1 - i0, j1 - j0) <= EDGE_TOLERANCE_SAMPLES:
            continue
        if index - 1 not in anchored or index + 1 not in anchored:
            return _finish_withheld(result, trace, "compound_or_unidentified_change")
        before, after = anchored[index - 1]["offset_samples"], anchored[index + 1]["offset_samples"]
        length = before - after if run["kind"] == "delete" else after - before
        if length < MIN_EVENT_SAMPLES or length > MAX_EDIT_SHIFT_SAMPLES:
            return _finish_withheld(result, trace, "event_outside_supported_duration")
        boundary = _boundary(x, y, i0, before, after, run["kind"])
        if boundary is None or boundary[1] < MINIMUM_CORRELATION:
            return _finish_withheld(result, trace, "event_boundary_not_supported")
        point, boundary_score = boundary
        common = {"boundary_correlation": boundary_score,
                  "offset_before_ms": before * 1000 / RATE, "offset_after_ms": after * 1000 / RATE}
        if run["kind"] == "delete":
            if np.std(x[point:point + length]) <= 1e-6:
                return _finish_withheld(result, trace, "deleted_interval_unidentifiable")
            events.append({"type": "delete", "reference_interval_ms": [point * 1000 / RATE, (point + length) * 1000 / RATE],
                           "processed_boundary_ms": (point + before) * 1000 / RATE, "evidence": common})
        else:
            copied = _adjacent_copy(x, y, point + before, length, point, MINIMUM_CORRELATION)
            if copied is None:
                return _finish_withheld(result, trace, "insertion_not_supported_as_repetition")
            source, inserted_start, match = copied
            events.append({"type": "repeat", "reference_source_interval_ms": [source * 1000 / RATE, (source + length) * 1000 / RATE],
                           "processed_added_interval_ms": [inserted_start * 1000 / RATE, (inserted_start + length) * 1000 / RATE],
                           "copy_interval_convention": "canonical_later_adjacent_copy_not_edit_provenance",
                           "evidence": {**common, "copy_correlation": match["correlation"],
                                        "adjacent_copy_correlation": match["adjacent_copy_correlation"]}})
    if abs(first_offset * 1000 / RATE) > settings.max_delay_ms + 3:
        return _finish_withheld(result, trace, "initial_delay_outside_declared_search")
    result["status"] = "analyzed"
    result["content_preservation_status"] = "defect_candidates" if events else "no_supported_defect_candidates"
    result["events"] = sorted(events, key=lambda event: event.get("processed_boundary_ms", event.get("processed_added_interval_ms", [0])[0]))
    result["alignment_segments"] = [
        {"reference_interval_ms": [anchor["reference_start_frame"] * 10.0, min(len(x), anchor["reference_end_frame"] * HOP) * 1000 / RATE],
         "processed_offset_ms": anchor["offset_samples"] * 1000 / RATE,
         "anchor_correlations": [item["correlation"] for item in anchor["anchors"]]}
        for anchor in anchored.values()
    ]
    trace["result_status"] = "analyzed"
    return result, trace


def analyze_buffers(reference: WavAudio, processed: WavAudio,
                    config: EngineConfig | None = None) -> dict:
    return analyze_buffers_with_trace(reference, processed, config)[0]


def analyze_wavs_with_trace(reference_path: str | Path, processed_path: str | Path,
                            config: EngineConfig | None = None) -> tuple[dict, dict]:
    return analyze_buffers_with_trace(read_wav(reference_path), read_wav(processed_path), config)
