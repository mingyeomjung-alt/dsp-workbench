"""V7 identity with inherited strict geometry and no full-audio approval.

This inert JSON contract does not prove the raw interval-gain forward model,
open a trace sidecar, or establish general acoustic or commercial performance.
The new engine preserves v6 results and has a normal-only compound fallback.
"""

from copy import deepcopy

from . import result_contract as _base
from .review_contract import with_review_diagnostics
from .repeat_result_contract import validate_repeat_analysis_result

ENGINE = "local_content_alignment_v7"
METHOD = "interval_gain_quantized_compound_normal_proof"


@with_review_diagnostics
def validate_compound_analysis_result(value: object) -> dict:
    """Validate separate v7 identity using unchanged shared v6 rules."""
    if type(value) is not dict:
        raise _base.ResultContractError("invalid_result_type")
    _base._json_tree(value)
    if value.get("engine") != ENGINE:
        raise _base.ResultContractError("unsupported_engine")
    if value.get("status") != "error":
        analysis = value.get("analysis")
        if type(analysis) is not dict or analysis.get("method") != METHOD:
            raise _base.ResultContractError("invalid_analysis_method")
    shared = deepcopy(value)
    shared["engine"] = "local_content_alignment_v6"
    if value.get("status") != "error":
        shared["analysis"]["method"] = "full_copy_feasibility_with_global_source_exclusion"
    validate_repeat_analysis_result(shared)
    return value
