"""Exact-coordinate differences of two already validated temporal diagnostics.

This is not waveform comparison, fuzzy event alignment, edit provenance, or a
quality verdict.  Only equal event type/location and exact reference geometry
are persistent.  Duplicate exact matches are ambiguous; no tolerance, overlap
heuristic or nearest-neighbour pairing may turn them into persistence.
"""

from __future__ import annotations

from fractions import Fraction

from .check_policy import check_result
from .regression_suite_contract import SuiteError, normalize_suite_configuration, _digest
from .result_contract import ResultContractError, validate_analysis_result


def _inconclusive(reason: str) -> dict:
    return {"status": "inconclusive", "reason_code": reason, "coordinate_axis": None,
            "new_candidates": [], "persistent_pairs": [], "not_observed_now": []}


def _number(value: int | float) -> Fraction:
    return Fraction(str(value))


def _event_key(event: dict) -> tuple:
    repeat = event["type"] == "repeat"
    interval = tuple(map(_number, event["reference_source_interval_ms" if repeat else "reference_interval_ms"]))
    insertion = None
    if repeat:
        # The canonical later-adjacent copy has an explicit before-offset.  This
        # uses that witness, never the later output time as a source coordinate.
        insertion = (_number(event["processed_added_interval_ms"][0])
                     - _number(event["evidence"]["offset_before_ms"]))
        if insertion != interval[1]:
            raise ValueError("unresolved_source_insertion_boundary")
    return (event["type"], event.get("location", "internal"), interval,
            interval[1] - interval[0], insertion,
            event.get("copy_interval_convention"))


def _overlapping_unmatched_geometry(before: list[tuple], after: list[tuple]) -> bool:
    """Non-identical overlapping source witnesses are not two proven edits."""
    for old in before:
        for new in after:
            if old == new or old[0] != new[0]:
                continue
            left, right = old[2], new[2]
            if max(left[0], right[0]) < min(left[1], right[1]):
                return True
    return False


def compare_case_results(baseline: object, candidate: object, configuration: object,
                         source_sha256: object) -> dict:
    """Return observed-event delta or an empty, fail-closed inconclusive result.

The input dictionaries are never modified and no audio/path is opened.  Valid
JSON contracts cannot authenticate audio: the runner separately checks hashes.
"""
    try:
        configuration = normalize_suite_configuration(configuration)
        _digest(source_sha256)
    except SuiteError:
        return _inconclusive("invalid_suite_comparison_declaration")
    try:
        baseline = validate_analysis_result(baseline)
        candidate = validate_analysis_result(candidate)
    except (ResultContractError, TypeError, ValueError, OverflowError, RecursionError):
        return _inconclusive("invalid_analysis_result")
    if any(result["status"] != "analyzed" or check_result(result)["exit_code"] == 2
           for result in (baseline, candidate)):
        return _inconclusive("analysis_not_comparable")
    expected_engine = "local_content_alignment_" + configuration["engine"]
    expected_configuration = {"profile": "basic", **{key: configuration[key] for key in
                               ("allow_gain", "allow_resampling", "max_delay_ms")}}
    if configuration["engine"] == "v12":
        expected_configuration["resampling_model"] = configuration["resampling_model"]
    for result in (baseline, candidate):
        if (result["engine"] != expected_engine or result["configuration"] != expected_configuration):
            return _inconclusive("analysis_configuration_mismatch")
        if result["reference"]["sha256"] != source_sha256:
            return _inconclusive("source_identity_mismatch")
    if baseline["reference"] != candidate["reference"]:
        return _inconclusive("source_metadata_mismatch")
    canonical = configuration["engine"] == "v12"
    if canonical:
        if (baseline.get("resampling_reference") is None
                or baseline["resampling_reference"] != candidate.get("resampling_reference")):
            return _inconclusive("canonical_reference_mismatch")
    # A result's effective method/grid is independent of its public engine.
    # Inherited 8k/200ms and native sample-grid/50ms views must not silently
    # claim that each covered the other's event population.
    identical_input_witness = any(result["reference"] == result["processed"]
                                  for result in (baseline, candidate))
    if baseline["analysis"] != candidate["analysis"] and not identical_input_witness:
        return _inconclusive("effective_analysis_scope_mismatch")
    try:
        before_keys = [_event_key(event) for event in baseline["events"]]
        after_keys = [_event_key(event) for event in candidate["events"]]
    except (ValueError, KeyError, TypeError, ZeroDivisionError):
        return _inconclusive("event_reference_geometry_unresolved")
    if len(set(before_keys)) != len(before_keys) or len(set(after_keys)) != len(after_keys):
        return _inconclusive("ambiguous_exact_event_matching")
    if _overlapping_unmatched_geometry(before_keys, after_keys):
        return _inconclusive("ambiguous_event_geometry_change")
    before_index = {key: index for index, key in enumerate(before_keys)}
    after_index = {key: index for index, key in enumerate(after_keys)}
    persistent = [{"baseline_event_index": index, "candidate_event_index": after_index[key]}
                  for index, key in enumerate(before_keys) if key in after_index]
    return {
        "status": "compared", "reason_code": None,
        "coordinate_axis": "canonical_reference_time_ms" if canonical else "raw_reference_time_ms",
        "new_candidates": [index for index, key in enumerate(after_keys) if key not in before_index],
        "persistent_pairs": persistent,
        "not_observed_now": [index for index, key in enumerate(before_keys) if key not in after_index],
    }
