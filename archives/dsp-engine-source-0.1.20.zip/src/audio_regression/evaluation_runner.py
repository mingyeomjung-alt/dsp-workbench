"""One-use locked M3 evaluation, separate from all detector implementations."""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys

import numpy as np
import scipy

from .audio import decode_wav, read_wav
from .evaluation_data import build_trials, make_confirmation_signal
from .evaluation_metrics import aggregate_trials, score_trial


METHODS = ("candidate", "direct_difference", "global_only", "no_local_alignment")
PUBLIC_SPEAKERS = ("251", "1462", "1988", "2035", "2803", "5338", "5895", "6241")
CONFIRMATION_SEEDS = (90101, 90102, 90103, 90104, 90105, 90106)
PACKAGE = Path(__file__).resolve().parent
WORKSPACE = PACKAGE.parents[2]
TARGETS = {"event_precision_minimum": .90, "event_recall_minimum": .90,
           "normal_false_alarm_maximum": .05, "normal_coverage_minimum": .90,
           "median_primary_boundary_error_maximum_ms": 100.0, "median_rtf_maximum": 1.0,
           "comparable_normal_coverage_tolerance": .05}


def _sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _new_json(path, value):
    with Path(path).open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def _inside(root, relative):
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()):
        raise ValueError("Evaluation path escapes its suite.")
    return path


def prepare_suite(output_dir: Path):
    """Construct and hash trials before seeing any detector output."""
    root = output_dir.resolve()
    root.mkdir(parents=True, exist_ok=False)
    (root / "pairs").mkdir()
    provenance_path = WORKSPACE / ".third_party/mini_librispeech_holdout_20261006/dataset/provenance.json"
    provenance = json.loads(provenance_path.read_text(encoding="utf-8"))
    development = json.loads((WORKSPACE / "validation/dsp_m2_execution_20261012.json").read_text(encoding="utf-8"))
    excluded = {development["examples"]["public_source_sha256"]}
    source_records, sources = [], []
    for speaker in PUBLIC_SPEAKERS:
        item = next(row for row in provenance["recordings"][speaker]["enroll"]
                    if 4000 <= row["duration_ms"] <= 12000)
        path = provenance_path.parent / item["file"]
        if _sha(path) != item["sha256"] or item["sha256"] in excluded:
            raise ValueError("Public source integrity or development-overlap violation.")
        audio = read_wav(path)
        group = "public_" + speaker
        sources.append((audio, group, "public_speech"))
        source_records.append({"source_group": group, "source_kind": "public_speech",
                               "sha256": audio.sha256, "source_member": item["source_member"],
                               "source_path": str(path.relative_to(WORKSPACE)),
                               "source_url": "https://www.openslr.org/31/", "license": "CC BY 4.0",
                               "selection": "first enrollment in metadata order with duration4–12seconds, fixed speaker list",
                               "previous_voiceguard_use": True, "previous_dsp_detector_use": False})
    for seed in CONFIRMATION_SEEDS:
        audio = make_confirmation_signal(seed)
        group = "confirmation_signal_" + str(seed)
        sources.append((audio, group, "synthetic_confirmation"))
        source_records.append({"source_group": group, "source_kind": "synthetic_confirmation",
                               "sha256": audio.sha256, "seed": seed,
                               "family": "colored_noise_and_multiband_bursts_not_M1_chirps"})
    all_rows, seen_stress = [], set()
    for audio, group, kind in sources:
        for trial in build_trials(audio, source_group=group, source_kind=kind):
            ref_bytes, proc_bytes = trial.pop("reference_wav"), trial.pop("processed_wav")
            ref_hash, proc_hash = hashlib.sha256(ref_bytes).hexdigest(), hashlib.sha256(proc_bytes).hexdigest()
            dedup = (ref_hash, proc_hash, json.dumps(trial["configuration"], sort_keys=True))
            if trial["scope"] == "stress":
                if dedup in seen_stress:
                    continue
                seen_stress.add(dedup)
            safe_id = hashlib.sha256(trial["trial_id"].encode()).hexdigest()[:24]
            pair = root / "pairs" / safe_id
            pair.mkdir()
            with (pair / "reference.wav").open("xb") as stream:
                stream.write(ref_bytes)
            with (pair / "processed.wav").open("xb") as stream:
                stream.write(proc_bytes)
            all_rows.append({**trial, "reference_path": str((pair / "reference.wav").relative_to(root)),
                             "processed_path": str((pair / "processed.wav").relative_to(root)),
                             "reference_sha256": ref_hash, "processed_sha256": proc_hash,
                             "input_duration_ms": max(decode_wav(ref_bytes).metadata()["duration_ms"],
                                                      decode_wav(proc_bytes).metadata()["duration_ms"])})
    protocol = {"schema_version": 1, "prepared_on": "2026-10-12", "methods": list(METHODS),
                "targets": TARGETS, "sources": source_records, "excluded_development_source_sha256": sorted(excluded),
                "rules": {"final_uses": 1, "retune_after_confirmation": False,
                          "event_iou_minimum": .5, "withheld_defects_count_as_missed": True,
                          "stress_separate_from_supported_metrics": True,
                          "identifiability": "source content not screened for favorable outcomes; fixed edit35percent with500mscontext; every supported trial retained even if detector holds",
                          "bootstrap_unit": "original_source_group", "bootstrap_resamples": 2000,
                          "bootstrap_seed": 20261013,
                          "minimum_groups": {"public_speech": 8, "synthetic_confirmation": 6},
                          "baseline_localization_metrics": "not_applicable_not_zero",
                          "comparison_task": "shared file-pair anomaly flag; report localization separately",
                          "adoption_scope": "prototype point targets only, not population accuracy or commercial release"},
                "supported_trial_count": sum(row["scope"] == "supported" for row in all_rows),
                "stress_trial_count": sum(row["scope"] == "stress" for row in all_rows),
                "licensed_source_attribution": "Mini LibriSpeech subset of LibriSpeech by Vassil Panayotov, Daniel Povey, Guoguo Chen and Sanjeev Khudanpur; LibriVox source audiobooks; CC BY4.0",
                "source_selection_and_pattern_limits": "8 English reading clips and6controlled sources, fixed edit positions and synthetic telephone transformations, not real-call data"}
    _new_json(root / "protocol.json", protocol)
    _new_json(root / "manifest.json", all_rows)
    jobs = [{"trial_id": row["trial_id"], "reference_path": str(_inside(root, row["reference_path"])),
             "processed_path": str(_inside(root, row["processed_path"])), "configuration": row["configuration"]}
            for row in all_rows]
    _new_json(root / "worker_jobs.json", jobs)
    files = {str(path.relative_to(root)): _sha(path) for path in sorted(root.rglob("*.wav"))}
    files.update({name: _sha(root / name) for name in ("protocol.json", "manifest.json", "worker_jobs.json")})
    code = {str(path.relative_to(WORKSPACE)): _sha(path) for path in sorted(PACKAGE.glob("*.py"))}
    freeze = {"schema_version": 1, "locked_at_utc": datetime.now(timezone.utc).isoformat(),
              "status": "locked_before_any_final_output", "dataset_sha256": files, "code_sha256": code,
              "targets": TARGETS, "final_uses": 1, "retune_allowed": False,
              "environment": {"python": platform.python_version(), "numpy": np.__version__,
                              "scipy": scipy.__version__,
                              "platform": platform.platform(), "processor": platform.processor()}}
    _new_json(root / "freeze.json", freeze)
    return {"status": "locked", "supported_trials": protocol["supported_trial_count"],
            "stress_trials": protocol["stress_trial_count"], "source_groups": len(sources),
            "freeze_sha256": _sha(root / "freeze.json")}


def verify_freeze(root):
    freeze = json.loads((root / "freeze.json").read_text(encoding="utf-8"))
    for name, expected in freeze["dataset_sha256"].items():
        if _sha(_inside(root, name)) != expected:
            raise ValueError("Frozen dataset changed.")
    for name, expected in freeze["code_sha256"].items():
        path = _inside(WORKSPACE, name)
        if _sha(path) != expected:
            raise ValueError("Frozen code changed.")
    return freeze


def _anomaly_summary(rows):
    normal = defective = hits = false_alarms = normal_assessed = held = 0
    for row in rows:
        result = row["result"]
        if row.get("method") == "candidate":
            flag = bool(result["events"]) if result.get("status") == "analyzed" else None
        else:
            flag = result.get("anomaly_candidate")
        expected = bool(row["expected_events"])
        held += flag is None
        if expected:
            defective += 1
            hits += flag is True
        else:
            normal += 1
            normal_assessed += flag is not None
            false_alarms += flag is True
    ratio = lambda a, b: a / b if b else None
    return {"trial_count": len(rows), "source_group_count": len({row["source_group"] for row in rows}),
            "defect_trial_count": defective, "detected_defect_trial_count": hits,
            "anomaly_recall": ratio(hits, defective), "normal_trial_count": normal,
            "normal_false_alarm_count": false_alarms, "normal_false_alarm_rate": ratio(false_alarms, normal),
            "normal_assessed_count": normal_assessed, "normal_coverage": ratio(normal_assessed, normal),
            "withheld_count": held, "withheld_rate": ratio(held, len(rows))}


def _anomaly_bootstrap(candidate, baseline):
    baseline_map = {row["trial_id"]: row for row in baseline}
    if set(baseline_map) != {row["trial_id"] for row in candidate}:
        raise ValueError("Comparison trials differ.")
    for row in candidate:
        other = baseline_map[row["trial_id"]]
        if any(row[key] != other[key] for key in ("source_group", "source_kind", "condition", "profile", "expected_events")):
            raise ValueError("Comparison trial grouping or truth differs.")
    groups = sorted({row["source_group"] for row in candidate})
    quantities = []
    for rows in (candidate, baseline):
        summaries = [_anomaly_summary([row for row in rows if row["source_group"] == group]) for group in groups]
        quantities.append(np.array([[summary[key] for key in (
            "detected_defect_trial_count", "defect_trial_count", "normal_false_alarm_count",
            "normal_trial_count", "normal_assessed_count")] for summary in summaries], dtype=np.int64))
    rng = np.random.default_rng(20261013)
    samples = {"anomaly_recall": [], "normal_false_alarm_rate": [], "normal_coverage": []}
    for _ in range(2000):
        indices = rng.integers(0, len(groups), size=len(groups))
        sums = [values[indices].sum(axis=0) for values in quantities]
        for metric, numerator, denominator in (("anomaly_recall", 0, 1), ("normal_false_alarm_rate", 2, 3), ("normal_coverage", 4, 3)):
            if sums[0][denominator] and sums[1][denominator]:
                samples[metric].append(float(sums[0][numerator] / sums[0][denominator] - sums[1][numerator] / sums[1][denominator]))
    c, b = _anomaly_summary(candidate), _anomaly_summary(baseline)
    return {"unit": "original_source_group", "source_group_count": len(groups), "resamples": 2000,
            "descriptive_only": True, "zero_observed_errors_do_not_establish_zero_population_error": True,
            "metrics": {metric: {"candidate": c[metric], "baseline": b[metric],
                                 "difference": c[metric] - b[metric] if c[metric] is not None and b[metric] is not None else None,
                                 "ci95": np.quantile(values, [.025, .975]).tolist() if values else None}
                        for metric, values in samples.items()}}


def _technical_decision(candidate_rows, controls, execution_errors):
    checks = []
    for kind in ("public_speech", "synthetic_confirmation"):
        for profile in ("basic", "telephone"):
            rows = [row for row in candidate_rows if row["source_kind"] == kind and row["profile"] == profile]
            values = aggregate_trials(rows)["overall"]
            for name, actual, limit, minimum in (
                ("precision", values["event_precision"], .9, True),
                ("recall", values["event_recall"], .9, True),
                ("normal_false_alarm", values["normal_false_alarm_rate"], .05, False),
                ("normal_coverage", values["normal_coverage"], .9, True),
                ("median_boundary_error_ms", values["median_primary_boundary_error_ms"], 100., False),
                ("median_rtf", values["median_rtf"], 1., False),
            ):
                passed = actual is not None and (actual >= limit if minimum else actual <= limit)
                checks.append({"source_kind": kind, "profile": profile, "check": name, "value": actual,
                               "limit": limit, "passed": passed})
    if execution_errors:
        status = "insufficient_execution_evidence"
    else:
        status = "prototype_point_targets_met" if all(check["passed"] for check in checks) else "prototype_point_targets_not_met"
    comparisons = {}
    for method, baseline_rows in controls.items():
        c, b = _anomaly_summary(candidate_rows), _anomaly_summary(baseline_rows)
        comparable = (c["normal_false_alarm_rate"] is not None and b["normal_false_alarm_rate"] is not None
                      and c["normal_coverage"] is not None and b["normal_coverage"] is not None
                      and max(c["normal_false_alarm_rate"], b["normal_false_alarm_rate"]) <= .05
                      and min(c["normal_coverage"], b["normal_coverage"]) >= .9
                      and abs(c["normal_coverage"] - b["normal_coverage"]) <= .05)
        strata = []
        for kind in ("public_speech", "synthetic_confirmation"):
            for profile in ("basic", "telephone"):
                first = _anomaly_summary([row for row in candidate_rows if row["source_kind"] == kind and row["profile"] == profile])
                second = _anomaly_summary([row for row in baseline_rows if row["source_kind"] == kind and row["profile"] == profile])
                eligible = (first["normal_false_alarm_rate"] is not None and second["normal_false_alarm_rate"] is not None
                            and first["normal_coverage"] is not None and second["normal_coverage"] is not None
                            and max(first["normal_false_alarm_rate"], second["normal_false_alarm_rate"]) <= .05
                            and min(first["normal_coverage"], second["normal_coverage"]) >= .9
                            and abs(first["normal_coverage"] - second["normal_coverage"]) <= .05)
                strata.append({"source_kind": kind, "profile": profile, "comparable": eligible,
                               "candidate": first, "baseline": second})
        comparisons[method] = {"comparable_false_alarm_and_coverage_conditions": comparable and all(cell["comparable"] for cell in strata),
                               "strata": strata,
                               "anomaly_recall_difference": c["anomaly_recall"] - b["anomaly_recall"],
                               "localization_comparison": "not_applicable_baseline_has_no_typed_events"}
    return {"status": status, "checks": checks, "shared_task_comparisons": comparisons,
            "commercial_adoption": False, "competitor_superiority": False,
            "retune_after_result": False, "next_action": "handoff prototype and limitations; no threshold repair on this final corpus"}


def run_suite(suite: Path):
    root = suite.resolve()
    freeze = verify_freeze(root)
    # O_EXCL token is permanent, including failed/partial runs. No automatic replay.
    _new_json(root / "run_claim.json", {"status": "consumed", "freeze_sha256": _sha(root / "freeze.json"),
                                       "started_at_utc": datetime.now(timezone.utc).isoformat(), "uses": 1})
    manifest = json.loads((root / "manifest.json").read_text(encoding="utf-8"))
    (root / "outputs").mkdir()
    environment = dict(os.environ)
    environment.update({"OPENBLAS_NUM_THREADS": "1", "OMP_NUM_THREADS": "1", "MKL_NUM_THREADS": "1",
                        "NUMEXPR_NUM_THREADS": "1", "PYTHONPATH": str(PACKAGE.parent), "PYTHONIOENCODING": "utf-8"})
    results, metadata = {}, {}
    for method in METHODS:
        print(json.dumps({"phase": "method_started", "method": method}), flush=True)
        output = root / "outputs" / (method + ".jsonl")
        subprocess.run([sys.executable, "-m", "audio_regression.evaluation_worker", "--jobs", str(root / "worker_jobs.json"),
                        "--output", str(output), "--method", method], env=environment, check=True)
        rows = [json.loads(line) for line in output.read_text(encoding="utf-8").splitlines()]
        by_id = {row["trial_id"]: row for row in rows}
        if len(by_id) != len(manifest):
            raise ValueError("Worker has missing or duplicate trials.")
        results[method] = [{**trial, **by_id[trial["trial_id"]], "method": method} for trial in manifest]
        metadata[method] = json.loads(output.with_suffix(".metadata.json").read_text(encoding="utf-8"))
    verify_freeze(root)
    supported = {method: [row for row in rows if row["scope"] == "supported"] for method, rows in results.items()}
    candidate = supported["candidate"]
    controls = {method: rows for method, rows in supported.items() if method != "candidate"}
    common = {}
    for method, rows in supported.items():
        common[method] = {"overall": _anomaly_summary(rows), "by_source_kind": {
            kind: _anomaly_summary([row for row in rows if row["source_kind"] == kind])
            for kind in sorted({row["source_kind"] for row in rows})}, "by_profile": {
            profile: _anomaly_summary([row for row in rows if row["profile"] == profile])
            for profile in ("basic", "telephone")}}
    bootstrap = {method: {kind: _anomaly_bootstrap(
        [row for row in candidate if row["source_kind"] == kind],
        [row for row in rows if row["source_kind"] == kind])
        for kind in ("public_speech", "synthetic_confirmation")} for method, rows in controls.items()}
    stress = [row for row in results["candidate"] if row["scope"] == "stress"]
    failures = []
    for row in candidate:
        score = score_trial(row["expected_events"], row["result"])
        if score["false_positive_events"] or score["false_negative_events"] or score["withheld"]:
            failures.append({"trial_id": row["trial_id"], "source_group": row["source_group"], "condition": row["condition"],
                             "profile": row["profile"], "reason_code": row["result"].get("reason_code"), "score": score})
    report = {"schema_version": 1, "milestone": "DSP-M3", "status": "completed",
              "freeze_sha256": _sha(root / "freeze.json"), "final_uses": 1,
              "candidate_localization": aggregate_trials(candidate), "shared_anomaly_task": common,
              "paired_source_group_bootstrap": bootstrap, "method_execution": metadata,
              "stress": {"trial_count": len(stress), "withheld_count": sum(row["result"]["status"] == "withheld" for row in stress),
                         "by_condition": {condition: {"trial_count": sum(row["condition"] == condition for row in stress),
                                                       "withheld_count": sum(row["condition"] == condition and row["result"]["status"] == "withheld" for row in stress)}
                                          for condition in sorted({row["condition"] for row in stress})}},
              "failures": failures, "decision": _technical_decision(candidate, controls, sum(item["execution_error_count"] for item in metadata.values())),
              "limitations": ["Only8Englishreading originals and6controlled sources; derivative trials are dependent.",
                              "Fixed35percent edits and synthetic telephone codec do not establish real-call performance.",
                              "Point-target decision and bootstrap intervals are corpus descriptions, not commercial accuracy evidence.",
                              "Baseline anomaly detection and candidate typed localization are different tasks."]}
    report["limitations"].append("Single local run and fixed method order; operating-system file-cache effects and CPU scheduling are not controlled.")
    _new_json(root / "report.json", report)
    _new_json(root / "run_completion.json", {"status": "completed", "completed_at_utc": datetime.now(timezone.utc).isoformat(),
                                            "report_sha256": _sha(root / "report.json"), "final_uses": 1})
    print(json.dumps({"status": "completed", "decision": report["decision"]["status"],
                      "localization": report["candidate_localization"]["overall"], "report": str(root / "report.json")}), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("prepare", "run"))
    parser.add_argument("--suite", type=Path, required=True)
    args = parser.parse_args()
    if args.action == "prepare":
        print(json.dumps(prepare_suite(args.suite)), flush=True)
    else:
        run_suite(args.suite)


if __name__ == "__main__":
    main()
