"""Strict opt-in v4 contract; stored results retain all v1 evidence rules.

The raw-landmark candidate has a separate identity, not relaxed geometry or
approval semantics. Trace sidecars are never loaded by this validator.
"""

from __future__ import annotations

from copy import deepcopy

from . import result_contract as _base
from .review_contract import with_review_diagnostics


ENGINE = "local_content_alignment_v4"
METHOD = "raw_landmark_piecewise_alignment_with_global_uniqueness"


@with_review_diagnostics
def validate_instrument_analysis_result(value: object) -> dict:
    """Validate the candidate identity and the unchanged shared evidence rules."""
    if type(value) is not dict:
        raise _base.ResultContractError("invalid_result_type")
    _base._json_tree(value)
    if value.get("engine") != ENGINE:
        raise _base.ResultContractError("unsupported_engine")
    if value.get("status") != "error":
        configuration = value.get("configuration")
        if type(configuration) is not dict or configuration.get("profile") != "basic":
            raise _base.ResultContractError("unsupported_profile")
        analysis = value.get("analysis")
        if type(analysis) is not dict or analysis.get("method") != METHOD:
            raise _base.ResultContractError("invalid_analysis_method")
    shared = deepcopy(value)
    shared["engine"] = _base.ENGINE
    if value.get("status") != "error":
        shared["analysis"]["method"] = "constrained_edit_alignment_with_raw_anchors"
    _base.validate_analysis_result(shared)
    return value
