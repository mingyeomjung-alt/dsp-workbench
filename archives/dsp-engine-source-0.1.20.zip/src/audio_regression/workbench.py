"""Private, loopback-only browser workbench for the existing DSP engine.

The browser sends two WAV files to this process on the same computer. Each
request uses an isolated temporary directory, which is removed before a reply
is sent. No account, saved history, remote analysis or automatic approval is
introduced. Host, Origin and a per-session token protect the local endpoint
from unrelated web pages; this is not a remotely deployable web service.
"""

from __future__ import annotations

import argparse
import base64
import binascii
import hashlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from importlib import resources
import json
from pathlib import Path
import secrets
import socket
import tempfile
import threading
import webbrowser

from . import __version__
from .api import analyze_pair
from .audio import (AudioInputError, MAX_FILE_BYTES, MAX_DURATION_SECONDS,
                    MIN_DURATION_SECONDS, SUPPORTED_SAMPLE_RATES, decode_wav)
from .check_policy import check_result
from .event_lineage import LineageError, MAX_SOURCE_RESULT_BYTES, build_event_lineage
from .event_lineage_reporting import render_event_lineage_html
from .pipeline_reporting import _STYLE as _PIPELINE_STYLE
from .reporting import _STYLE, render_html
from .resampler_engine import MODEL as _FFT_RESAMPLING_MODEL
from .result_contract import validate_analysis_result


MAX_REQUEST_BYTES = 27_000_000
MAX_LINEAGE_REQUEST_BYTES = MAX_SOURCE_RESULT_BYTES + 64
READ_TIMEOUT_SECONDS = 15
_MAX_BASE64_CHARS = 4 * ((MAX_FILE_BYTES + 2) // 3)
_REQUEST_FIELDS = {"reference", "processed", "allow_gain", "allow_resampling", "engine"}
_ASSETS = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/app.js": ("app.js", "text/javascript; charset=utf-8"),
    "/app.css": ("app.css", "text/css; charset=utf-8"),
}
_REPORT_STYLE_HASH = base64.b64encode(hashlib.sha256(_STYLE.encode("utf-8")).digest()).decode("ascii")
_PIPELINE_STYLE_HASH = base64.b64encode(hashlib.sha256(_PIPELINE_STYLE.encode("utf-8")).digest()).decode("ascii")
_CSP = ("default-src 'none'; script-src 'self'; "
        f"style-src 'self' 'sha256-{_REPORT_STYLE_HASH}' 'sha256-{_PIPELINE_STYLE_HASH}'; "
        "connect-src 'self'; img-src 'self' data:; media-src blob:; "
        "frame-src 'self'; frame-ancestors 'none'; base-uri 'none'; "
        "form-action 'none'; object-src 'none'")


class _RequestError(Exception):
    def __init__(self, status: int, code: str, message: str) -> None:
        self.status = status
        self.code = code
        self.message = message
        super().__init__(code)


def _invalid_json(*_args: object) -> None:
    raise ValueError("Invalid JSON")


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def _read_json_object(raw: bytes) -> dict:
    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object,
                           parse_constant=_invalid_json)
    except (UnicodeError, ValueError, RecursionError):
        raise _RequestError(400, "invalid_json", "요청 형식을 읽을 수 없습니다. 파일을 다시 선택해 주세요.") from None
    if type(value) is not dict:
        raise _RequestError(400, "invalid_request", "요청 항목은 JSON 객체여야 합니다.")
    return value


def _read_request_json(raw: bytes) -> dict:
    value = _read_json_object(raw)
    if set(value) not in (_REQUEST_FIELDS, _REQUEST_FIELDS | {"resampling_model"}):
        raise _RequestError(400, "invalid_request", "분석 요청의 항목이 올바르지 않습니다. 화면을 새로 열어 주세요.")
    if any(type(value[key]) is not bool for key in ("allow_gain", "allow_resampling")):
        raise _RequestError(400, "invalid_request", "변환 허용 설정을 다시 확인해 주세요.")
    if type(value["engine"]) is not str or value["engine"] not in {"v1", "v9", "v10", "v11", "v12"}:
        raise _RequestError(400, "invalid_engine", "지원되는 분석 방식을 목록에서 선택해 주세요.")
    if value["engine"] == "v12":
        if (type(value.get("resampling_model")) is not str
                or value["resampling_model"] != _FFT_RESAMPLING_MODEL
                or value["allow_gain"] or not value["allow_resampling"]):
            raise _RequestError(400, "invalid_resampling_configuration", "FFT 48→16 kHz 방식에는 해당 변환 선언이 필요합니다. 음량 변경은 지원하지 않습니다.")
    elif "resampling_model" in value:
        raise _RequestError(400, "invalid_resampling_configuration", "명시적 리샘플링 모델은 FFT 48→16 kHz 방식에서만 사용할 수 있습니다.")
    return value


def _read_lineage_request_json(raw: bytes) -> dict:
    if len(raw) > MAX_LINEAGE_REQUEST_BYTES:
        raise _RequestError(413, "request_too_large", "단계 결과 JSON은 4 MiB 이하여야 합니다.")
    value = _read_json_object(raw)
    if set(value) != {"source_result"} or type(value["source_result"]) is not dict:
        raise _RequestError(400, "invalid_lineage_request", "저장된 파이프라인 실행·검사 결과 JSON 하나를 선택해 주세요.")
    return value["source_result"]


def _validate_fft_audio(reference: bytes, processed: bytes) -> None:
    """Reject incompatible declared inputs before creating temporary files."""
    source, output = decode_wav(reference), decode_wav(processed)
    if (source.sample_rate_hz != 48000 or output.sample_rate_hz != 16000
            or len(source.samples) % 3 != 0):
        raise _RequestError(400, "unsupported_resampling_input", "이 방식은 원본 48 kHz→처리본 16 kHz이며 원본 샘플 수가 3의 배수인 경우만 지원합니다. 파일을 자동 변환하지 않습니다.")


def _audio_bytes(value: object, label: str) -> bytes:
    if type(value) is not dict or set(value) != {"name", "base64"}:
        raise _RequestError(400, "invalid_file", f"{label} 파일을 다시 선택해 주세요.")
    name, encoded = value["name"], value["base64"]
    # The original name is metadata only: it is never used as a filesystem path,
    # reflected in a response or printed in the server log.
    if type(name) is not str or not 1 <= len(name) <= 255 or any(ord(ch) < 32 for ch in name):
        raise _RequestError(400, "invalid_file", f"{label} 파일 이름을 확인하고 다시 선택해 주세요.")
    if type(encoded) is not str or not encoded:
        raise _RequestError(400, "invalid_file", f"{label} 파일이 비어 있거나 읽을 수 없습니다.")
    if len(encoded) > _MAX_BASE64_CHARS:
        raise _RequestError(413, "file_too_large", f"{label} 파일은 10 MB 이하여야 합니다.")
    try:
        decoded = base64.b64decode(encoded, validate=True)
    except (ValueError, binascii.Error):
        raise _RequestError(400, "invalid_file_encoding", f"{label} 파일을 읽을 수 없습니다. 다시 선택해 주세요.") from None
    if not decoded:
        raise _RequestError(400, "invalid_file", f"{label} 파일이 비어 있습니다.")
    if len(decoded) > MAX_FILE_BYTES:
        raise _RequestError(413, "file_too_large", f"{label} 파일은 10 MB 이하여야 합니다.")
    try:
        decode_wav(decoded)
    except AudioInputError as exc:
        messages = {
            "unsupported_channels": "모노(1채널) WAV가 필요합니다. 파일을 자동 변환하지는 않습니다.",
            "unsupported_encoding": "압축하지 않은 16비트 PCM WAV가 필요합니다.",
            "unsupported_sample_rate": "샘플률이 8, 16, 44.1 또는 48 kHz인 WAV가 필요합니다.",
            "invalid_duration": "파일 길이는 2초 이상 30초 이하여야 합니다.",
            "file_too_large": "파일 크기는 10 MB 이하여야 합니다.",
        }
        message = messages.get(exc.code, "WAV 형식이 올바르지 않거나 파일이 손상되었습니다.")
        raise _RequestError(400, exc.code, f"{label}: {message}") from None
    return decoded


class WorkbenchServer(ThreadingHTTPServer):
    """A server that can only bind IPv4 loopback, never an external interface."""

    daemon_threads = True
    request_queue_size = 8

    def __init__(self, *, port: int = 0, work_dir: str | Path | None = None) -> None:
        if type(port) is not int or not 0 <= port <= 65535:
            raise ValueError("Port must be between 0 and 65535.")
        self._owned_work_dir: tempfile.TemporaryDirectory | None = None
        if work_dir is None:
            self._owned_work_dir = tempfile.TemporaryDirectory(prefix="dsp-workbench-")
            self.work_dir = Path(self._owned_work_dir.name)
        else:
            # No user filename contributes to a request path. Avoid requiring
            # platform-specific realpath privileges for an already named root.
            self.work_dir = Path(work_dir).absolute()
            if not self.work_dir.exists():
                raise FileNotFoundError("Work directory must already exist.")
            if not self.work_dir.is_dir():
                raise ValueError("Work directory must be an existing directory.")
        self.session_token = secrets.token_urlsafe(32)
        self.analysis_lock = threading.BoundedSemaphore(1)
        try:
            super().__init__(("127.0.0.1", port), _WorkbenchHandler)
        except BaseException:
            if self._owned_work_dir is not None:
                self._owned_work_dir.cleanup()
            raise

    @property
    def origin(self) -> str:
        return f"http://127.0.0.1:{self.server_port}"

    def server_close(self) -> None:
        super().server_close()
        # Running daemon request threads own their request directory lifetime;
        # normal shutdown should wait for the sole active analysis before cleanup.
        with self.analysis_lock:
            if self._owned_work_dir is not None:
                self._owned_work_dir.cleanup()

    def handle_error(self, request: object, client_address: object) -> None:
        # Do not print tracebacks containing uploaded data or temporary paths.
        return


class _WorkbenchHandler(BaseHTTPRequestHandler):
    server: WorkbenchServer
    server_version = "DSPWorkbench"
    sys_version = ""
    protocol_version = "HTTP/1.0"

    def setup(self) -> None:
        super().setup()
        self.connection.settimeout(READ_TIMEOUT_SECONDS)

    def log_message(self, format: str, *args: object) -> None:
        return

    def _send(self, status: int, data: bytes, content_type: str) -> None:
        self.close_connection = True
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Content-Security-Policy", _CSP)
        self.send_header("Connection", "close")
        self.end_headers()
        if self.command != "HEAD":
            try:
                self.wfile.write(data)
            except (BrokenPipeError, ConnectionError, socket.timeout):
                pass

    def _json(self, status: int, value: dict) -> None:
        raw = json.dumps(value, ensure_ascii=False, allow_nan=False, separators=(",", ":")).encode("utf-8")
        self._send(status, raw, "application/json; charset=utf-8")

    def _error(self, status: int, code: str, message: str) -> None:
        self._json(status, {"schema_version": 1, "status": "error", "code": code, "message": message})

    def send_error(self, code: int, message: str | None = None, explain: str | None = None) -> None:
        # Also sanitize HTTP parser errors; never reflect its request line.
        self._error(code, "invalid_http_request", "요청을 처리할 수 없습니다. 화면을 다시 열어 주세요.")

    def _valid_host(self) -> bool:
        hosts = self.headers.get_all("Host", [])
        if hosts != [f"127.0.0.1:{self.server.server_port}"]:
            self._error(403, "invalid_host", "이 컴퓨터에서 연 작업 화면으로만 접속할 수 있습니다.")
            return False
        return True

    def do_GET(self) -> None:
        if not self._valid_host():
            return
        if self.path == "/api/session":
            self._json(200, {
                "schema_version": 1, "token": self.server.session_token,
                "version": __version__, "local_only": True,
                "limits": {"max_file_bytes": MAX_FILE_BYTES, "min_seconds": MIN_DURATION_SECONDS,
                           "max_seconds": MAX_DURATION_SECONDS,
                           "sample_rates": sorted(SUPPORTED_SAMPLE_RATES)},
            })
            return
        asset = _ASSETS.get(self.path)
        if asset is None:
            self._error(404, "not_found", "요청한 화면을 찾을 수 없습니다.")
            return
        filename, content_type = asset
        try:
            data = resources.files("audio_regression").joinpath("workbench_assets", filename).read_bytes()
        except (OSError, ValueError):
            self._error(503, "assets_unavailable", "작업 화면 파일이 없습니다. 설치 패키지를 다시 확인해 주세요.")
            return
        self._send(200, data, content_type)

    def _authenticate(self) -> None:
        if self.headers.get_all("Origin", []) != [self.server.origin]:
            raise _RequestError(403, "invalid_origin", "다른 웹사이트에서는 분석을 요청할 수 없습니다. 작업 화면에서 다시 시도해 주세요.")
        tokens = self.headers.get_all("X-DSP-Token", [])
        if len(tokens) != 1 or not secrets.compare_digest(tokens[0].encode("utf-8"), self.server.session_token.encode("ascii")):
            raise _RequestError(403, "invalid_session", "작업 화면의 연결이 만료되었습니다. 새로고침한 뒤 다시 시도해 주세요.")

    def _content_length(self, limit: int = MAX_REQUEST_BYTES) -> int:
        if self.headers.get_all("Transfer-Encoding", []):
            raise _RequestError(400, "invalid_request", "지원하지 않는 전송 형식입니다.")
        lengths = self.headers.get_all("Content-Length", [])
        if len(lengths) != 1 or not lengths[0].isascii() or not lengths[0].isdecimal():
            raise _RequestError(411, "content_length_required", "파일 전송 길이를 확인할 수 없습니다. 다시 시도해 주세요.")
        if len(lengths[0]) > 10:
            raise _RequestError(413, "request_too_large", "선택한 파일의 전체 크기가 너무 큽니다.")
        length = int(lengths[0])
        if length > limit:
            raise _RequestError(413, "request_too_large", "선택한 파일의 전체 크기가 너무 큽니다.")
        if length == 0:
            raise _RequestError(400, "invalid_request", "두 WAV 파일을 선택해 주세요.")
        content_types = self.headers.get_all("Content-Type", [])
        if len(content_types) != 1 or content_types[0].lower().replace(" ", "") not in {
            "application/json", "application/json;charset=utf-8"
        }:
            raise _RequestError(415, "unsupported_media_type", "지원하지 않는 요청 형식입니다. 작업 화면에서 다시 시도해 주세요.")
        return length

    def do_POST(self) -> None:
        if not self._valid_host():
            return
        if self.path not in {"/api/analyze", "/api/lineage"}:
            self._error(404, "not_found", "요청한 분석 기능을 찾을 수 없습니다.")
            return
        acquired = False
        try:
            self._authenticate()
            lineage_request = self.path == "/api/lineage"
            length = self._content_length(MAX_LINEAGE_REQUEST_BYTES if lineage_request else MAX_REQUEST_BYTES)
            acquired = self.server.analysis_lock.acquire(blocking=False)
            if not acquired:
                raise _RequestError(429, "analysis_busy", "이미 분석 중입니다. 현재 분석이 끝난 뒤 다시 시도해 주세요.")
            try:
                raw = self.rfile.read(length)
            except (socket.timeout, TimeoutError):
                raise _RequestError(408, "request_timeout", "파일 전송 시간이 초과되었습니다. 다시 시도해 주세요.") from None
            if len(raw) != length:
                raise _RequestError(400, "incomplete_request", "파일 전송이 끝나지 않았습니다. 다시 시도해 주세요.")
            if lineage_request:
                source = _read_lineage_request_json(raw)
                try:
                    lineage = build_event_lineage(source)
                    response = {"schema_version": 1, "status": "completed",
                                "lineage_result": lineage,
                                "report_html": render_event_lineage_html(lineage)}
                except LineageError:
                    raise _RequestError(400, "invalid_lineage_source", "유효한 저장 단계 결과가 아닙니다. 단일 파일 비교 JSON이나 수정된 좌표는 사용할 수 없습니다.") from None
                self._json(200, response)
                return
            request = _read_request_json(raw)
            reference = _audio_bytes(request["reference"], "원본")
            processed = _audio_bytes(request["processed"], "처리본")
            options = {"allow_gain": request["allow_gain"],
                       "allow_resampling": request["allow_resampling"], "engine": request["engine"]}
            if request["engine"] == "v12":
                _validate_fft_audio(reference, processed)
                options["resampling_model"] = request["resampling_model"]
            with tempfile.TemporaryDirectory(prefix="analysis-", dir=self.server.work_dir) as request_dir:
                reference_path = Path(request_dir) / "reference.wav"
                processed_path = Path(request_dir) / "processed.wav"
                for path, audio in ((reference_path, reference), (processed_path, processed)):
                    with path.open("xb") as output:
                        output.write(audio)
                result = validate_analysis_result(analyze_pair(
                    reference_path, processed_path, **options,
                ))
                response = {"schema_version": 1, "status": "completed", "result": result,
                            "check": check_result(result), "report_html": render_html(result)}
            # Temporary audio is already removed before returning a result.
            self._json(200, response)
        except _RequestError as exc:
            self._error(exc.status, exc.code, exc.message)
        except Exception:
            self._error(500, "analysis_failed", "분석을 완료하지 못했습니다. 결과를 통과로 처리하지 않았습니다. 파일 형식과 처리 조건을 확인해 주세요.")
        finally:
            if acquired:
                self.server.analysis_lock.release()

    def do_OPTIONS(self) -> None:
        self._error(403, "cross_origin_disabled", "다른 웹사이트에서의 요청은 허용하지 않습니다.")

    def do_HEAD(self) -> None:
        self._error(405, "method_not_allowed", "지원하지 않는 요청 방식입니다.")

    def do_PUT(self) -> None:
        self._error(405, "method_not_allowed", "지원하지 않는 요청 방식입니다.")

    do_DELETE = do_PUT
    do_PATCH = do_PUT
    do_TRACE = do_PUT


def create_server(*, port: int = 0, work_dir: str | Path | None = None) -> WorkbenchServer:
    """Create a loopback server; callers start ``serve_forever`` themselves."""
    return WorkbenchServer(port=port, work_dir=work_dir)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="이 컴퓨터에서만 실행하는 DSP 오디오 비교 작업 화면")
    parser.add_argument("--port", type=int, default=0, help="사용할 로컬 포트 (기본: 자동 선택)")
    parser.add_argument("--no-browser", action="store_true", help="브라우저를 자동으로 열지 않음")
    parser.add_argument("--work-dir", type=Path, help="임시 분석에 쓸 기존 폴더 (종료 후 음성 파일은 남기지 않음)")
    args = parser.parse_args(argv)
    try:
        server = create_server(port=args.port, work_dir=args.work_dir)
    except (OSError, ValueError):
        print("작업 화면을 시작할 수 없습니다. 포트와 임시 폴더 설정을 확인해 주세요.")
        return 2
    print(f"DSP 작업 화면: {server.origin}/", flush=True)
    print("이 컴퓨터 안에서만 처리합니다. 종료하려면 이 창에서 Ctrl+C를 누르세요.", flush=True)
    if not args.no_browser:
        try:
            webbrowser.open(server.origin + "/")
        except Exception:
            print("브라우저를 자동으로 열지 못했습니다. 위 주소를 직접 열어 주세요.", flush=True)
    try:
        server.serve_forever(poll_interval=0.2)
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
