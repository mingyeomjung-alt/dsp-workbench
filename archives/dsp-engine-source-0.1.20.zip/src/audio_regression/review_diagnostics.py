"""Bounded, inert explanations of existing withholding decisions.

Only fixed engine headers and named failure fields are inspected. This module
does not validate arbitrary trace content, load audio, rerun an engine, infer a
fault's origin, or change the original analysis result or trace.
"""

from __future__ import annotations

import re


ENGINE_STAGE_LABELS = {
    "local_content_alignment_v1": "기본 시간 정합",
    "local_content_alignment_v2": "PCM16 미세 정합 재검증",
    "local_content_alignment_v3": "제한된 활성 문맥 재검증",
    "local_content_alignment_v4": "원시 파형 랜드마크 증명",
    "local_content_alignment_v5": "정확한 정상 리샘플링 증명",
    "local_content_alignment_v6": "전체 복사 반복 증명",
    "local_content_alignment_v7": "정확한 복합 정상 변환 증명",
    "local_content_alignment_v8": "제한된 문맥의 단일 이벤트 증명",
    "local_content_alignment_v9": "전역 문맥의 단일 이벤트 증명",
    "local_content_alignment_v10": "원래 샘플률의 짧은 단일 이벤트 증명",
    "local_content_alignment_v11": "원래 샘플률의 시작·끝 손실 증명",
    "local_content_alignment_v12": "명시한 FFT 리샘플링과 변환 후 편집 증명",
}

_BASE_CODES = frozenset({
    "resampling_not_declared", "insufficient_signal_variation",
    "insufficient_analysis_band_signal", "alignment_outside_search_band",
    "alignment_path_unavailable", "insufficient_unambiguous_anchors",
    "unreliable_matched_content", "cumulative_edit_shift_outside_budget",
    "insufficient_matched_coverage", "unexplained_matched_signal_change",
    "unexplained_local_signal_change", "compound_or_unidentified_change",
    "non_silent_file_edge_change", "event_outside_supported_duration",
    "event_boundary_not_supported", "deleted_interval_unidentifiable",
    "insertion_not_supported_as_repetition", "initial_delay_outside_declared_search",
})
_PCM_CODES = frozenset({
    "not_short_balanced_cancellation", "file_edge_not_exactly_anchored",
    "independent_anchor_offsets_not_equal", "compound_coordinates_not_at_anchor_offset",
    "gain_not_positive_and_finite", "suspicious_samples_exceed_pcm16_error_budget",
    "independent_context_missing", "insufficient_raw_context",
    "raw_context_below_quantization_activity_floor", "raw_context_correlation_not_supported",
    "continuity_coordinates_outside_audio", "raw_boundary_continuity_not_supported",
    "pcm16_cancellation_revalidated",
})
_BRIDGE_CODES = frozenset({
    "context_coordinates_outside_audio", "first_active_context_correlation_not_supported",
    "selected_window_outside_original_outer_match",
    "first_active_context_not_unique_at_proven_offset", "active_context_independently_revalidated",
    "no_active_context_within_bounded_original_match",
    "whole_bracket_coordinates_or_gain_not_supported",
    "whole_bracket_samples_exceed_pcm16_error_budget",
    "whole_bracket_boundary_continuity_not_supported", "whole_bracket_pcm16_residual_revalidated",
    "bridge_is_not_internal_and_both_sided", "bridge_cluster_not_bounded_balanced_cancellations",
    "ordinary_failure_is_not_only_low_context_activity",
    "bridge_cluster_crosses_edit_or_unsupported_compound", "ordinary_low_activity_failure_not_present",
    "bridge_independent_outer_anchor_offsets_not_equal",
    "bridge_coordinates_not_contiguous_at_proven_offset", "bridge_cluster_duration_outside_budget",
    "bridge_gain_not_positive_and_finite", "bounded_active_context_bridge_revalidated",
    "fresh_merged_anchor_does_not_have_exact_proven_offset",
    "active_context_bridge_final_gain_reproof_failed",
})
_LANDMARK_CODES = frozenset({
    "raw_landmark_insufficient_coverage", "raw_landmark_invalid_gain",
    "raw_landmark_unexplained_signal_change", "raw_landmark_unexplained_local_residual",
    "raw_landmark_unexplained_local_change", "raw_landmark_insufficient_unique_anchors",
    "raw_landmark_unstable_group_offsets", "raw_landmark_multiple_or_unstable_transitions",
    "raw_landmark_event_bracket_not_supported", "raw_landmark_inconsistent_copy_gap",
    "raw_landmark_insufficient_canonical_copy_context", "raw_landmark_invalid_correspondence",
    "raw_landmark_anchor_outside_proved_segment", "raw_landmark_final_offset_reproof_failed",
    "raw_landmark_copy_final_gain_reproof_failed", "raw_landmark_boundary_proof_budget_exceeded",
    "raw_landmark_ambiguous_event_boundary", "repeat_feasibility_ambiguous_geometry",
    "repeat_feasibility_proof_budget_exceeded",
})
_COMPOUND_CODES = frozenset({
    "length_or_leading_zero_hypothesis_not_supported", "unique_normal_context_not_supported",
    "whole_output_exact_proof_failed", "global_residual_not_supported",
    "informative_local_correlation_not_supported", "informative_context_missing",
    "compound_gain_invalid_pcm_input", "compound_gain_target_endpoint_not_supported",
    "compound_gain_search_budget_exceeded", "compound_gain_search_depth_exceeded",
    "compound_gain_uninformative_reference", "compound_gain_no_feasible_interval",
    "compound_gain_exact_witness", "compound_gain_no_exact_witness",
})
_EVENT_CODES = frozenset({
    "copy_source_not_active", "copy_source_interior_not_active",
    "copy_source_ncc_entry_gate_not_unique", "supported_source_ncc_gate",
    "deleted_source_not_active", "event_source_below_quantization_resolution",
    "compound_event_unique_stable_context_not_supported",
    "compound_event_length_or_leading_zero_hypothesis_not_supported",
    "compound_event_context_bracket_not_supported", "compound_event_whole_output_exact_proof_failed",
    "compound_event_insufficient_fir_safe_anchors", "compound_event_final_anchor_reproof_failed",
    "compound_event_informative_retained_proof_failed", "compound_event_boundary_reproof_failed",
    "compound_event_copy_interior_reproof_failed", "compound_event_invalid_supported_geometry",
    "compound_event_length_hypothesis_not_supported", "compound_event_no_supported_boundary",
    "compound_event_proof_budget_exceeded", "compound_event_gain_search_incomplete",
    "compound_event_invalid_exact_witness", "compound_event_ambiguous_boundary",
    "compound_event_no_exact_event_witness", "compound_event_exact_supported_witness",
})
_GLOBAL_CODES = frozenset({
    "global_context_whole_output_exact_proof_failed", "global_context_informative_retained_proof_failed",
    "global_context_informative_side_context_missing", "global_context_boundary_reproof_failed",
    "global_context_copy_interior_reproof_failed", "global_context_invalid_pcm_input",
    "global_context_target_endpoint_not_supported", "global_context_proof_budget_exceeded",
    "global_context_uninformative_output", "global_context_length_or_delay_hypothesis_not_supported",
    "global_context_gain_search_incomplete", "global_context_invalid_exact_witness",
    "global_context_ambiguous_geometry", "global_context_no_exact_event_witness",
    "global_context_endpoint_or_near_edge_alternative",
    "global_context_event_source_below_quantization_resolution",
    "global_context_copy_source_entry_gate_not_unique", "global_context_exact_supported_witness",
})
_SHORT_CODES = frozenset({
    "short_event_insufficient_signal_variation", "short_event_no_complete_single_edit_explanation",
    "short_event_insertion_not_adjacent_copy", "short_event_ambiguous_single_edit_geometry",
    "short_event_insufficient_internal_context", "short_event_uninformative_context",
    "short_event_nonunique_context", "short_event_uninformative_event_content",
    "short_event_whole_output_reconstruction_failed", "short_event_insufficient_informative_retained_windows",
})
KNOWN_REASON_CODES = (_BASE_CODES | _PCM_CODES | _BRIDGE_CODES | _LANDMARK_CODES
                      | _COMPOUND_CODES | _EVENT_CODES | _GLOBAL_CODES)
# Existing v1-v9 schemas keep their frozen enum; only v10 stages accept these.
V10_REASON_CODES = _SHORT_CODES
V11_REASON_CODES = frozenset({
    "endpoint_loss_no_complete_single_deletion_explanation",
    "endpoint_loss_ambiguous_single_deletion_geometry",
    "endpoint_loss_insufficient_signal_variation",
    "endpoint_loss_uninformative_removed_content",
    "endpoint_loss_insufficient_retained_context",
    "endpoint_loss_uninformative_retained_context",
    "endpoint_loss_nonunique_retained_context",
    "endpoint_loss_whole_output_reconstruction_failed",
})
V12_REASON_CODES = frozenset({
    "resampler_unsupported_input_path",
    "resampler_projection_out_of_range",
    "resampler_no_exact_supported_postedit_proof",
})
_ALL_REASON_CODES = KNOWN_REASON_CODES | V10_REASON_CODES | V11_REASON_CODES | V12_REASON_CODES

_BUDGET_CODES = frozenset(code for code in _ALL_REASON_CODES if
                         "budget_exceeded" in code or "search_depth_exceeded" in code
                         or "gain_search_incomplete" in code)
_AMBIGUOUS_CODES = frozenset(code for code in _ALL_REASON_CODES if
                            "ambiguous" in code or "not_unique" in code)
_INFORMATION_CODES = frozenset(code for code in _ALL_REASON_CODES if
                              "insufficient" in code or "uninformative" in code
                              or "below_quantization" in code or "context_missing" in code
                              or code.endswith("not_active")
                              or code in {"insufficient_signal_variation",
                                          "no_active_context_within_bounded_original_match"})
_EDGE_CODES = frozenset(code for code in _ALL_REASON_CODES if
                       "endpoint" in code or "file_edge" in code or "near_edge" in code)
_SUCCESS_CODES = frozenset({
    "pcm16_cancellation_revalidated", "active_context_independently_revalidated",
    "whole_bracket_pcm16_residual_revalidated", "bounded_active_context_bridge_revalidated",
    "compound_gain_exact_witness", "supported_source_ncc_gate",
    "compound_event_exact_supported_witness", "global_context_exact_supported_witness",
})
SUCCESS_REASON_CODES = _SUCCESS_CODES
_HASH = re.compile(r"[0-9a-f]{64}\Z")
_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}\Z")


def describe_reason(code: object) -> dict:
    """Return fixed Korean wording; never echo unknown or private strings."""
    if type(code) is not str or code not in _ALL_REASON_CODES:
        return {"label": "상세 사유 미제공", "explanation": "알려진 진단 사유로 설명할 수 있는 기록이 없습니다.",
                "next_check": "기존 보류 상태를 유지하고 입력 형식과 선언한 처리 조건을 확인하세요."}
    if code == "resampling_not_declared":
        return {"label": "리샘플링 선언 누락", "explanation": "원본과 처리본의 샘플률이 다르지만 리샘플링을 허용하지 않았습니다.",
                "next_check": "실제로 리샘플링한 같은 원본의 처리본인지 확인하고 해당 변환만 명시하세요."}
    if code in V12_REASON_CODES:
        return {"label": "선언한 리샘플링 경로의 정확한 증명 미충족",
                "explanation": "48→16kHz 전체 기록 FFT 변환과 변환 뒤 단일 편집이라는 고정된 조건으로 전체 출력을 재구성하지 못했습니다.",
                "next_check": "선언한 필터·양자화·처리 순서와 샘플 수를 확인하세요. 다른 리샘플러나 변환 전 편집을 이 모델로 통과시키지 마세요."}
    if code in _BUDGET_CODES:
        return {"label": "제한된 증명 검색 미완료", "explanation": "고정된 검색 횟수나 깊이 한도 안에서 필요한 증명을 끝내지 못했습니다. 결함이 없다는 뜻이 아닙니다.",
                "next_check": "원본과 처리본의 관계 및 지원 범위를 확인하세요. 결과를 통과시키려고 검색 한도나 판정 기준을 바꾸지 마세요."}
    if code in _AMBIGUOUS_CODES:
        return {"label": "대응 관계가 모호함", "explanation": "지원 범위 안에서 대응 위치나 복사 출처를 하나로 식별할 근거가 충분하지 않습니다.",
                "next_check": "반복·주기적 구간과 여러 가능한 대응 위치를 직접 확인하세요. 임의의 위치를 정답으로 선택하지 마세요."}
    if code in _INFORMATION_CODES:
        return {"label": "식별 정보 부족", "explanation": "활성 신호나 독립 문맥이 부족해 필요한 시간적 대응 증명을 확보하지 못했습니다.",
                "next_check": "무음·아주 작은 신호·짧은 문맥 및 원본과 처리본이 같은 내용인지 확인하세요."}
    if code in _EDGE_CODES:
        return {"label": "가장자리 또는 끝점 조건 미지원", "explanation": "파일 가장자리 변화나 PCM 끝점 조건이 이 좁은 증명의 지원 범위를 벗어납니다.",
                "next_check": "선행·후행 구간과 포화된 샘플을 확인하세요. 실제 편집 원인이나 전체 음질을 이 기록으로 단정하지 마세요."}
    if code in _SUCCESS_CODES:
        return {"label": "국소 증명 기록", "explanation": "일부 증명 단계의 근거만 확인된 기록입니다. 전체 분석의 보류 상태를 해제하는 뜻이 아닙니다.",
                "next_check": "최종 보류 사유와 다른 미충족 단계도 함께 확인하세요."}
    if code in {"alignment_outside_search_band", "cumulative_edit_shift_outside_budget",
                "initial_delay_outside_declared_search", "event_outside_supported_duration",
                "bridge_cluster_duration_outside_budget"}:
        return {"label": "지원 시간 범위 밖", "explanation": "지연·이벤트 길이·누적 이동량이 선언한 검색 범위나 고정된 지원 범위에 맞지 않습니다.",
                "next_check": "두 파일의 길이와 실제 처리 이력을 확인하고 지원 범위 안의 동일 원본-처리본 쌍을 사용하세요."}
    return {"label": "지원되는 파형 증명 미충족", "explanation": "선언된 변환과 고정된 파형·문맥 증명 조건만으로 이 대응을 확인하지 못했습니다. 결함 발생 원인을 확정한 결과가 아닙니다.",
            "next_check": "같은 원본의 처리본인지와 실제 처리 조건을 확인하고 해당 구간을 직접 검토하세요. 상관이나 잔차 기준을 완화해 통과시키지 마세요."}


def _known(value: object) -> str | None:
    return value if type(value) is str and value in KNOWN_REASON_CODES else None


def _hash(value: object) -> bool:
    return type(value) is str and _HASH.fullmatch(value) is not None


def _code(value: object) -> bool:
    return type(value) is str and len(value) <= 128 and _CODE.fullmatch(value) is not None


def _stage(engine: str, outcome: str, reason: str | None = None,
           detail: str | None = None) -> dict:
    return {"engine": engine, "outcome": outcome, "reason_code": reason,
            "detail_reason_code": detail if detail != reason else None}


def _detail(trace: dict, number: int, reason: str) -> str | None:
    """Read at most two fixed nested dictionaries, never arbitrary descendants."""
    if number == 7:
        proof = trace.get("gain_search_trace")
        code = _known(proof.get("reason_code")) if type(proof) is dict else None
        return code if code not in _SUCCESS_CODES else None
    if number not in (8, 9):
        return None
    proof = trace.get("event_proof_trace")
    if type(proof) is not dict:
        return None
    if number == 8:
        deep = _known(proof.get("incomplete_gain_search_reason"))
    else:
        incomplete = proof.get("incomplete_gain_search_geometry")
        deep = _known(incomplete.get("reason_code")) if type(incomplete) is dict else None
    if deep and deep != reason and deep not in _SUCCESS_CODES:
        return deep
    direct = _known(proof.get("reason_code"))
    return direct if direct not in _SUCCESS_CODES else None


def _project(trace: object, number: int, expected_reason: object,
             reference_hash: str, processed_hash: str, visited: set[int]) -> list[dict] | None:
    if type(trace) is not dict or id(trace) in visited or len(visited) >= 12:
        return None
    visited.add(id(trace))
    engine = f"local_content_alignment_v{number}"
    trace_engine = {2: "pcm16_cancellation_trace_v1", 3: "bounded_active_context_trace_v1"}.get(number, engine)
    if type(trace.get("schema_version")) is not int or trace["schema_version"] != 1:
        return None
    headers = {"engine": trace_engine, "analysis_engine": engine,
               "reference_sha256": reference_hash, "processed_sha256": processed_hash,
               "result_status": "withheld"}
    if any(type(trace.get(key)) is not str or trace[key] != value for key, value in headers.items()):
        return None
    code_key = "withheld_branch" if number in (2, 3) else "reason_code"
    if not _code(trace.get(code_key)) or trace[code_key] != expected_reason:
        return None
    if number in (2, 3):
        if type(trace.get("trace_truncated")) is not bool:
            return None
        code = _known(trace[code_key])
        return ([_stage(engine, "withheld", code)] if code and code not in _SUCCESS_CODES
                else [_stage(engine, "attempted_without_proof_detail")])
    if number == 12:
        if (trace.get("method") != "declared_fft_resampling_exact_pcm_forward_proof"
                or trace.get("resampling_model") != "scipy_fft_periodic_48k_16k_pcm16_postedit_v1"
                or trace.get("proof_path") != "declared_fft_postedit"
                or type(trace.get("proof_attempted")) is not bool
                or trace.get("proof_proved") is not False):
            return None
        code = trace["reason_code"] if trace["reason_code"] in V12_REASON_CODES else None
        return ([_stage(engine, "withheld", code)] if code is not None
                else [_stage(engine, "attempted_without_proof_detail")])
    if number == 11:
        if (trace.get("method") != "endpoint_loss_exact_pcm_forward_proof"
                or type(trace.get("endpoint_loss_attempted")) is not bool
                or trace.get("endpoint_loss_proved") is not False):
            return None
        if trace["endpoint_loss_attempted"]:
            if trace.get("proof_path") != "native_pcm_endpoint_loss":
                return None
            code = trace["reason_code"] if trace["reason_code"] in V11_REASON_CODES else None
            return ([_stage(engine, "withheld", code)] if code is not None
                    else [_stage(engine, "attempted_without_proof_detail")])
        if (trace.get("proof_path") != "preserved_v10_result"
                or trace.get("baseline_status") != "withheld"
                or trace.get("baseline_reason_code") != expected_reason):
            return None
        stages = _project(trace.get("inherited_v10_trace"), 10, expected_reason,
                          reference_hash, processed_hash, visited)
        return None if stages is None else stages + [_stage(engine, "not_attempted")]
    if number == 10:
        if (trace.get("method") != "short_event_exact_pcm_forward_proof"
                or type(trace.get("short_event_attempted")) is not bool
                or trace.get("short_event_proved") is not False):
            return None
        if trace["short_event_attempted"]:
            if trace.get("proof_path") != "native_pcm_short_single_edit":
                return None
            code = trace["reason_code"] if trace["reason_code"] in V10_REASON_CODES else None
            return ([_stage(engine, "withheld", code)] if code in _SHORT_CODES
                    else [_stage(engine, "attempted_without_proof_detail")])
        if (trace.get("proof_path") != "preserved_v9_result"
                or trace.get("baseline_status") != "withheld"
                or trace.get("baseline_reason_code") != expected_reason):
            return None
        stages = _project(trace.get("inherited_v9_trace"), 9, expected_reason,
                          reference_hash, processed_hash, visited)
        return None if stages is None else stages + [_stage(engine, "not_attempted")]
    if (type(trace.get("baseline_status")) is not str or trace["baseline_status"] != "withheld"
            or not _code(trace.get("baseline_reason_code"))):
        return None
    flag, proved, paths = {
        4: ("fallback_attempted", None, ("preserved_v3_result", "raw_landmark_fallback")),
        5: ("canonical_attempted", "canonical_proved", ("preserved_v4_result", "preserved_v4_result")),
        6: ("repeat_attempted", None, ("preserved_v5_result", "full_copy_feasibility")),
        7: ("compound_attempted", "compound_proved", ("preserved_v6_result", "preserved_v6_result")),
        8: ("compound_event_attempted", "compound_event_proved", ("preserved_v7_result", "preserved_v7_result")),
        9: ("global_context_attempted", "global_context_proved", ("preserved_v8_result", "preserved_v8_result")),
    }[number]
    attempted = trace.get(flag)
    if (type(attempted) is not bool or type(trace.get("proof_path")) is not str
            or trace["proof_path"] != paths[int(attempted)]
            or (proved is not None and trace.get(proved) is not False)):
        return None
    stages = []
    if number > 4:
        stages = _project(trace.get(f"inherited_v{number - 1}_trace"), number - 1,
                          trace["baseline_reason_code"], reference_hash, processed_hash, visited)
        if stages is None:
            return None
    if not attempted:
        # A skipped proof preserves baseline evidence; its reason is not a new
        # stage failure. v4 has no recorded v3 trace to reconstruct.
        if trace[code_key] != trace["baseline_reason_code"]:
            return None
        stages.append(_stage(engine, "not_attempted"))
    elif number in (5, 6):
        code = _known(trace[code_key])
        explicit = number == 6 and code in {
            "repeat_feasibility_ambiguous_geometry", "repeat_feasibility_proof_budget_exceeded"}
        stages.append(_stage(engine, "withheld", code) if explicit
                      else _stage(engine, "attempted_without_proof_detail"))
    elif number == 4:
        code = _known(trace[code_key])
        stages.append(_stage(engine, "withheld", code) if code and code not in _SUCCESS_CODES
                      else _stage(engine, "attempted_without_proof_detail"))
    else:
        failure_key = {7: "compound_failure", 8: "compound_event_failure", 9: "global_context_failure"}[number]
        failure = _known(trace.get(failure_key))
        if failure is None or failure in _SUCCESS_CODES:
            stages.append(_stage(engine, "attempted_without_proof_detail"))
        else:
            stages.append(_stage(engine, "withheld", failure, _detail(trace, number, failure)))
    return stages


def build_review_diagnostics(result: dict, trace: object = None) -> dict:
    """Build explanatory metadata for a validated withheld result only.

    Unavailable or malformed trace projections fail closed to an empty stage
    list. Neither an unavailable trace nor a diagnostic changes core decisions.
    Unknown trace fields are ignored without traversing them.
    """
    if (type(result) is not dict or type(result.get("status")) is not str
            or result["status"] != "withheld" or type(result.get("engine")) is not str
            or result["engine"] not in ENGINE_STAGE_LABELS):
        raise ValueError("Review diagnostics require a supported withheld analysis result.")
    engine = result["engine"]
    block = {"schema_version": 1, "selected_engine": engine, "result_status": "withheld",
             "primary_reason_code": result.get("reason_code"), "trace_availability": "not_recorded",
             "diagnostic_only": True, "fault_provenance_confirmed": False, "stages": []}
    if trace is None:
        if engine != "local_content_alignment_v1":
            block["trace_availability"] = "unavailable"
        return block
    block["trace_availability"] = "unavailable"
    if engine == "local_content_alignment_v1":
        return block
    reference, processed = result.get("reference"), result.get("processed")
    if type(reference) is not dict or type(processed) is not dict:
        return block
    reference_hash, processed_hash = reference.get("sha256"), processed.get("sha256")
    if not _hash(reference_hash) or not _hash(processed_hash):
        return block
    stages = _project(trace, int(engine.rsplit("v", 1)[1]), result.get("reason_code"),
                      reference_hash, processed_hash, set())
    if stages is not None:
        block.update(trace_availability="recorded", stages=stages)
    return block
