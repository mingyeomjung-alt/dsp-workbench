"""Strict local regression-suite manifests and inert result validation.

No path is opened by normalization.  Names are portable relative WAV paths;
the runner additionally resolves them against its declared input directory.
Manifest hashes identify a declaration, not file provenance or approval.
"""

from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import math
import os
from pathlib import Path
import re
import unicodedata

from .resampler_result_contract import MODEL


MAX_SUITE_MANIFEST_BYTES = 131_072
MAX_SUITE_RESULT_BYTES = 8_388_608
SUITE_ENGINE = "audio_regression_suite_v1"
SUPPORTED_SUITE_ENGINES = frozenset({"v1", "v9", "v10", "v11", "v12"})
_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,63}\Z")
_HASH = re.compile(r"[0-9a-f]{64}\Z")
_RESERVED = frozenset({"con", "prn", "aux", "nul", "clock$", "conin$", "conout$"}
                      | {prefix + str(n) for prefix in ("com", "lpt") for n in range(1, 10)}
                      | {prefix + n for prefix in ("com", "lpt") for n in "¹²³"})
_CONFIG_FIELDS = {"engine", "allow_gain", "allow_resampling", "max_delay_ms", "resampling_model"}


class SuiteError(ValueError):
    """Stable rejection code; user paths and content never enter its text."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__("Audio regression suite rejected: " + code + ".")


def _reject(code: str) -> None:
    raise SuiteError(code)


def _fields(value: object, required: set[str], code: str) -> dict:
    if type(value) is not dict or set(value) != required:
        _reject(code)
    return value


def _identifier(value: object) -> str:
    if type(value) is not str or _ID.fullmatch(value) is None:
        _reject("invalid_suite_identifier")
    return value


def _plain_text(value: object) -> str:
    if (type(value) is not str or not 1 <= len(value) <= 80 or value.strip() != value
            or any(unicodedata.category(char).startswith("C") or char in "\u2028\u2029" for char in value)):
        _reject("invalid_suite_version")
    return value


def _digest(value: object) -> str:
    if type(value) is not str or _HASH.fullmatch(value) is None:
        _reject("invalid_suite_sha256")
    return value


def _relative_wav(value: object) -> str:
    if (type(value) is not str or not 1 <= len(value) <= 240 or "\\" in value
            or unicodedata.normalize("NFC", value) != value or not value.lower().endswith(".wav")):
        _reject("invalid_suite_audio_path")
    for part in value.split("/"):
        if (not part or len(part) > 100 or part in {".", ".."} or part[-1:] in {".", " "}
                or any(char in '<>:"|?*' or unicodedata.category(char).startswith("C") for char in part)
                or part.split(".", 1)[0].rstrip(" .").casefold() in _RESERVED):
            _reject("invalid_suite_audio_path")
    return value


def normalize_suite_configuration(value: object) -> dict:
    """Return a detached exact declaration; profile is fixed to basic elsewhere."""
    configuration = _fields(value, _CONFIG_FIELDS, "invalid_suite_configuration")
    if (type(configuration["engine"]) is not str or configuration["engine"] not in SUPPORTED_SUITE_ENGINES
            or any(type(configuration[field]) is not bool for field in ("allow_gain", "allow_resampling"))):
        _reject("invalid_suite_configuration")
    delay = configuration["max_delay_ms"]
    try:
        valid_delay = type(delay) in (int, float) and math.isfinite(delay) and 0 <= delay <= 5000
    except OverflowError:
        valid_delay = False
    if not valid_delay:
        _reject("invalid_suite_configuration")
    if configuration["engine"] == "v12":
        if (configuration["allow_gain"] is not False or configuration["allow_resampling"] is not True
                or type(configuration["resampling_model"]) is not str or configuration["resampling_model"] != MODEL):
            _reject("invalid_suite_resampling_declaration")
    elif configuration["resampling_model"] is not None:
        _reject("invalid_suite_resampling_declaration")
    return deepcopy(configuration)


def normalize_suite_manifest(value: object) -> dict:
    """Validate an inert manifest, retaining order and returning a private copy."""
    manifest = _fields(value, {"schema_version", "suite_id", "baseline_version", "candidate_version", "cases"},
                       "invalid_suite_manifest")
    if type(manifest["schema_version"]) is not int or manifest["schema_version"] != 1:
        _reject("unsupported_suite_schema_version")
    _identifier(manifest["suite_id"])
    _plain_text(manifest["baseline_version"])
    _plain_text(manifest["candidate_version"])
    cases = manifest["cases"]
    if type(cases) is not list or not 1 <= len(cases) <= 20:
        _reject("invalid_suite_case_count")
    seen = set()
    for case in cases:
        case = _fields(case, {"case_id", "source", "baseline", "candidate", "configuration"}, "invalid_suite_case")
        name = _identifier(case["case_id"])
        if name.casefold() in seen:
            _reject("duplicate_suite_case_id")
        seen.add(name.casefold())
        for field in ("source", "baseline", "candidate"):
            audio = _fields(case[field], {"path", "sha256"}, "invalid_suite_audio_declaration")
            _relative_wav(audio["path"])
            _digest(audio["sha256"])
        normalize_suite_configuration(case["configuration"])
    # Also caps pathological Unicode strings without ever reading a path.
    if len(_canonical_bytes(manifest)) > MAX_SUITE_MANIFEST_BYTES:
        _reject("suite_manifest_too_large")
    return deepcopy(manifest)


def _canonical_bytes(value: object) -> bytes:
    try:
        return json.dumps(value, ensure_ascii=False, allow_nan=False, sort_keys=True,
                          separators=(",", ":")).encode("utf-8")
    except (TypeError, ValueError, UnicodeError, OverflowError, RecursionError):
        _reject("invalid_suite_json")


def canonical_manifest_sha256(manifest: object) -> str:
    return hashlib.sha256(_canonical_bytes(normalize_suite_manifest(manifest))).hexdigest()


def _pairs(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            _reject("duplicate_suite_json_key")
        result[key] = value
    return result


def _load(path: str | Path, maximum: int) -> object:
    from .artifact_integrity import ArtifactVerificationError, _read_regular

    try:
        supplied = os.fspath(path)
        if type(supplied) is not str or not supplied or ".." in Path(supplied).parts:
            _reject("invalid_suite_json_path")
        _hash, _size, data, _identity = _read_regular(Path(os.path.abspath(supplied)), maximum, collect=True)
        return json.loads(data.decode("utf-8"), object_pairs_hook=_pairs,
                          parse_constant=lambda _value: _reject("non_finite_suite_json"))
    except SuiteError:
        raise
    except ArtifactVerificationError:
        _reject("unsafe_or_unavailable_suite_json")
    except (OSError, UnicodeError, ValueError, RecursionError):
        _reject("invalid_suite_json")


def load_suite_manifest(path: str | Path) -> dict:
    return normalize_suite_manifest(_load(path, MAX_SUITE_MANIFEST_BYTES))


def incomplete_case_delta() -> dict:
    """The only allowed delta for a case that did not complete execution."""
    return {"status": "inconclusive", "reason_code": "case_not_completed", "coordinate_axis": None,
            "new_candidates": [], "persistent_pairs": [], "not_observed_now": []}


def build_suite_summary(result: dict) -> dict:
    """Derive both independent verdict axes; never promote a hold into success.

    The caller supplies validated case records.  validate_suite_result checks
    every input and recomputes this summary before accepting a saved artifact.
    """
    from .check_policy import check_result

    cases = result["cases"]
    completed = sum(case["status"] == "completed" for case in cases)
    errors = sum(case["status"] == "error" for case in cases)
    not_run = sum(case["status"] == "not_run" for case in cases)
    inconclusive = sum(case["delta"]["status"] == "inconclusive" for case in cases)
    new_count = sum(len(case["delta"]["new_candidates"]) for case in cases)
    persistent = sum(len(case["delta"]["persistent_pairs"]) for case in cases)
    not_observed = sum(len(case["delta"]["not_observed_now"]) for case in cases)
    current_codes = [check_result(case["candidate_analysis"])["exit_code"]
                     if case["status"] == "completed" and case["candidate_analysis"] is not None else 2
                     for case in cases]
    integrity = result["input_integrity"]["status"]
    current = max(current_codes, default=2) if integrity == "verified" else 2
    regression = ("inconclusive" if inconclusive or completed != len(cases) or integrity != "verified"
                  else "new_candidates" if new_count else "no_new_candidates_observed")
    exit_code = (3 if errors or integrity == "failed" else
                 2 if not result["execution_complete"] or regression == "inconclusive" or current == 2 else
                 1 if current == 1 or new_count else 0)
    return {
        "case_count": len(cases), "completed_count": completed, "error_count": errors,
        "not_run_count": not_run, "new_candidate_count": new_count,
        "persistent_candidate_count": persistent, "not_observed_now_count": not_observed,
        "inconclusive_case_count": inconclusive,
        "current_gate_state": {0: "clear_supported_temporal_check", 1: "review_required", 2: "blocked"}[current],
        "regression_state": regression, "exit_code": exit_code,
    }


def _reason(value: object) -> None:
    if type(value) is not str or re.fullmatch(r"[a-z][a-z0-9_]{0,127}", value) is None:
        _reject("invalid_suite_reason_code")


def _same_json(first: object, second: object) -> bool:
    # JSON textual comparison deliberately distinguishes true, 1 and 1.0 in
    # derived counters/indices, unlike Python's ordinary container equality.
    return _canonical_bytes(first) == _canonical_bytes(second)


def _bound_analysis(value: object, declaration: dict, role: str) -> dict:
    from .result_contract import ResultContractError, validate_analysis_result

    try:
        analysis = validate_analysis_result(value)
    except (ResultContractError, TypeError, ValueError, RecursionError, OverflowError):
        _reject("invalid_suite_analysis")
    configuration = declaration["configuration"]
    expected_engine = "local_content_alignment_" + configuration["engine"]
    if analysis.get("engine", expected_engine) != expected_engine:
        _reject("suite_analysis_engine_mismatch")
    if analysis["status"] != "error":
        expected = {"profile": "basic", **{key: configuration[key] for key in
                    ("allow_gain", "allow_resampling", "max_delay_ms")}}
        if configuration["engine"] == "v12":
            expected["resampling_model"] = configuration["resampling_model"]
        if analysis["configuration"] != expected:
            _reject("suite_analysis_configuration_mismatch")
        if (analysis["reference"]["sha256"] != declaration["source"]["sha256"]
                or analysis["processed"]["sha256"] != declaration[role]["sha256"]):
            _reject("suite_analysis_audio_identity_mismatch")
    return analysis


def validate_suite_result(value: object) -> dict:
    """Validate and recompute an inert saved suite without opening any audio."""
    from .regression_suite_diff import compare_case_results

    result = _fields(value, {"schema_version", "engine", "producer_version", "manifest", "manifest_sha256",
                             "execution_complete", "cases", "input_integrity", "summary",
                             "complete_audio_approval", "commercial_performance_validated"},
                     "invalid_suite_result")
    if type(result["schema_version"]) is not int or result["schema_version"] != 1:
        _reject("unsupported_suite_schema_version")
    if type(result["engine"]) is not str or result["engine"] != SUITE_ENGINE:
        _reject("unsupported_suite_engine")
    _plain_text(result["producer_version"])
    for claim in ("complete_audio_approval", "commercial_performance_validated"):
        if result[claim] is not False:
            _reject("invalid_suite_approval_claim")
    manifest = normalize_suite_manifest(result["manifest"])
    if result["manifest_sha256"] != canonical_manifest_sha256(manifest):
        _reject("suite_manifest_digest_mismatch")
    if type(result["execution_complete"]) is not bool:
        _reject("invalid_suite_completion_flag")
    cases = result["cases"]
    if type(cases) is not list or len(cases) != len(manifest["cases"]):
        _reject("inconsistent_suite_case_count")
    audio_identities = {}
    for case, declaration in zip(cases, manifest["cases"], strict=True):
        case = _fields(case, {"case_id", "status", "reason_code", "baseline_analysis", "candidate_analysis", "delta"},
                       "invalid_suite_case_result")
        if case["case_id"] != declaration["case_id"]:
            _reject("inconsistent_suite_case_order")
        if type(case["status"]) is not str or case["status"] not in {"completed", "error", "not_run"}:
            _reject("invalid_suite_case_status")
        if case["status"] == "completed":
            if case["reason_code"] is not None:
                _reject("inconsistent_suite_case_reason")
            for role in ("baseline", "candidate"):
                analysis = _bound_analysis(case[role + "_analysis"], declaration, role)
                if analysis["status"] == "error":
                    _reject("completed_suite_case_contains_error")
            expected_delta = compare_case_results(case["baseline_analysis"], case["candidate_analysis"],
                                                  declaration["configuration"], declaration["source"]["sha256"])
        else:
            _reason(case["reason_code"])
            for role in ("baseline", "candidate"):
                if case[role + "_analysis"] is not None:
                    if case["status"] == "not_run":
                        _reject("not_run_suite_case_contains_analysis")
                    _bound_analysis(case[role + "_analysis"], declaration, role)
            expected_delta = incomplete_case_delta()
        if not _same_json(case["delta"], expected_delta):
            _reject("inconsistent_suite_delta")
        for role in ("baseline", "candidate"):
            analysis = case[role + "_analysis"]
            if analysis is None or analysis["status"] == "error":
                continue
            for key in ("reference", "processed", "resampling_reference"):
                metadata = analysis.get(key)
                if metadata is None:
                    continue
                digest = metadata["sha256"]
                if digest in audio_identities and audio_identities[digest] != metadata:
                    _reject("conflicting_suite_audio_metadata")
                audio_identities[digest] = metadata
    integrity = _fields(result["input_integrity"], {"status", "issues"}, "invalid_suite_input_integrity")
    if type(integrity["status"]) is not str or integrity["status"] not in {"verified", "failed", "not_checked"}:
        _reject("invalid_suite_input_integrity")
    issues = integrity["issues"]
    if type(issues) is not list or len(issues) > 121 or bool(issues) != (integrity["status"] == "failed"):
        _reject("invalid_suite_integrity_issues")
    ids = {case["case_id"] for case in cases}
    seen = set()
    for issue in issues:
        issue = _fields(issue, {"case_id", "role", "scope", "reason_code"}, "invalid_suite_integrity_issue")
        if (type(issue["role"]) is not str or issue["role"] not in {"manifest", "source", "baseline", "candidate"}
                or type(issue["scope"]) is not str or issue["scope"] not in {"input", "snapshot"}
                or (issue["case_id"] is None) != (issue["role"] == "manifest")
                or (issue["case_id"] is not None and (type(issue["case_id"]) is not str or issue["case_id"] not in ids))):
            _reject("invalid_suite_integrity_issue")
        _reason(issue["reason_code"])
        key = (issue["case_id"], issue["role"], issue["scope"], issue["reason_code"])
        if key in seen:
            _reject("duplicate_suite_integrity_issue")
        seen.add(key)
    # Completion records traversal, not success or input integrity.  A fully
    # visited suite containing case errors may complete but must still exit 3.
    if ((any(case["status"] == "not_run" for case in cases) and result["execution_complete"])
            or (all(case["status"] == "completed" for case in cases) and not result["execution_complete"])):
        _reject("inconsistent_suite_completion_flag")
    if not _same_json(result["summary"], build_suite_summary(result)):
        _reject("inconsistent_suite_summary")
    if len(_canonical_bytes(result)) > MAX_SUITE_RESULT_BYTES:
        _reject("suite_result_too_large")
    return result


def load_suite_result(path: str | Path) -> dict:
    return validate_suite_result(_load(path, MAX_SUITE_RESULT_BYTES))
