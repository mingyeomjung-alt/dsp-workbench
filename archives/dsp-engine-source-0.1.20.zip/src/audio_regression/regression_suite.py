"""Run a bounded, pinned old/new temporal regression suite on saved WAVs.

The detectors and their gates are reused unchanged. No processor is executed,
no baseline is updated, and no audio leaves this machine. Guarded reads and
end-of-run checks detect observable changes; they are not an atomic filesystem
snapshot or a claim of authentic execution history.
"""
from __future__ import annotations

from copy import deepcopy
import json
import os
from pathlib import Path
import re

from . import __version__, api
from .artifact_integrity import ArtifactVerificationError, _read_regular
from .audio import MAX_FILE_BYTES, decode_wav
from .regression_suite_contract import (
    MAX_SUITE_MANIFEST_BYTES, MAX_SUITE_RESULT_BYTES,
    SuiteError, build_suite_summary, canonical_manifest_sha256,
    normalize_suite_manifest, validate_suite_result,
)
from .regression_suite_diff import compare_case_results
from .result_contract import validate_analysis_result
from .saved_pipeline import SavedPipelineError, _normal_parents


MAX_TOTAL_INPUT_BYTES = 256 * 1024 * 1024
_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}\Z")
_ROLES = ("source", "baseline", "candidate")


def _code(exc: Exception, fallback: str) -> str:
    value = getattr(exc, "code", None)
    return value if type(value) is str and _CODE.fullmatch(value) else fallback


def _path(value: str | Path) -> Path:
    try:
        raw = os.fspath(value)
        if type(raw) is not str or not raw or ".." in Path(raw).parts:
            raise SuiteError("invalid_suite_path")
        return Path(os.path.abspath(raw))
    except (TypeError, ValueError, OSError):
        raise SuiteError("invalid_suite_path") from None


def _read(path: Path, limit: int, *, identity: tuple | None = None) -> dict:
    try:
        digest, count, raw, observed = _read_regular(
            path, limit, collect=True, expected_identity=identity)
        return {"sha256": digest, "size": count, "raw": raw, "identity": observed}
    except (ArtifactVerificationError, OSError, ValueError) as exc:
        raise SuiteError(_code(exc, "suite_input_read_error")) from None


def _object(pairs: list[tuple[str, object]]) -> dict:
    result = {}
    for key, value in pairs:
        if key in result:
            raise SuiteError("duplicate_json_key")
        result[key] = value
    return result


def _constant(_: str) -> None:
    raise SuiteError("non_finite_manifest_value")


def _parse_manifest(raw: bytes) -> dict:
    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=_object,
                           parse_constant=_constant)
        return normalize_suite_manifest(value)
    except SuiteError:
        raise
    except (UnicodeError, ValueError, RecursionError, OverflowError):
        raise SuiteError("invalid_suite_manifest_json") from None


def load_suite_manifest(path: str | Path) -> dict:
    """Read one strict manifest without opening any of its named audio files."""
    return _parse_manifest(_read(_path(path), MAX_SUITE_MANIFEST_BYTES)["raw"])


def _new_bytes(path: Path, raw: bytes) -> None:
    try:
        _normal_parents(path, output=True)
        with path.open("xb") as stream:
            stream.write(raw)
    except (SavedPipelineError, OSError, ValueError):
        raise SuiteError("suite_output_write_error") from None


def _json_bytes(value: dict) -> bytes:
    try:
        return (json.dumps(value, ensure_ascii=False, allow_nan=False,
                           indent=2) + "\n").encode("utf-8")
    except (TypeError, ValueError, OverflowError, RecursionError):
        raise SuiteError("invalid_suite_result") from None


def _new_folder(path: Path, *, parents: bool = False) -> None:
    try:
        _normal_parents(path, output=True)
        path.mkdir(parents=parents, exist_ok=False)
    except (SavedPipelineError, OSError, ValueError):
        raise SuiteError("suite_output_write_error") from None


def _preflight(manifest_path: str | Path, output_dir: str | Path):
    path, output = _path(manifest_path), _path(output_dir)
    raw_manifest = _read(path, MAX_SUITE_MANIFEST_BYTES)
    manifest = _parse_manifest(raw_manifest["raw"])
    if os.path.lexists(output):
        raise SuiteError("suite_output_exists")
    try:
        _normal_parents(output, output=True)
    except SavedPipelineError:
        raise SuiteError("unsafe_suite_output_path") from None
    sources, items, total = {}, [], 0
    for case in manifest["cases"]:
        record = {}
        for role in _ROLES:
            spec = case[role]
            source = path.parent.joinpath(*spec["path"].split("/"))
            if output == source or output in source.parents or output == path or output in path.parents:
                raise SuiteError("suite_input_output_overlap")
            if source not in sources:
                sources[source] = _read(source, MAX_FILE_BYTES)
            observed = sources[source]
            if observed["sha256"] != spec["sha256"]:
                raise SuiteError("suite_expected_hash_mismatch")
            total += observed["size"]
            if total > MAX_TOTAL_INPUT_BYTES:
                raise SuiteError("suite_input_budget_exceeded")
            record[role] = {"path": source, **observed}
        items.append(record)
    return path, raw_manifest, output, manifest, items


def _declaration(configuration: dict) -> dict:
    result = {"profile": "basic", "allow_gain": configuration["allow_gain"],
              "allow_resampling": configuration["allow_resampling"],
              "max_delay_ms": configuration["max_delay_ms"]}
    if configuration["resampling_model"] is not None:
        result["resampling_model"] = configuration["resampling_model"]
    return result


def _analyze(source: Path, processed: Path, configuration: dict,
             reference_metadata: dict, processed_metadata: dict) -> dict:
    declaration = _declaration(configuration)
    value = validate_analysis_result(api.analyze_pair(
        source, processed, engine=configuration["engine"], **declaration))
    if value["status"] == "error":
        raise SuiteError(value["reason_code"])
    if (value["engine"] != "local_content_alignment_" + configuration["engine"]
            or value["configuration"] != declaration
            or value["reference"] != reference_metadata
            or value["processed"] != processed_metadata):
        raise SuiteError("suite_analysis_input_mismatch")
    return value


def _unfinished(case: dict, reason: str = "case_not_run") -> dict:
    return {"case_id": case["case_id"], "status": "not_run", "reason_code": reason,
            "baseline_analysis": None, "candidate_analysis": None,
            "delta": {"status": "inconclusive", "reason_code": "case_not_completed",
                      "coordinate_axis": None, "new_candidates": [],
                      "persistent_pairs": [], "not_observed_now": []}}


def _recheck(manifest_path: Path, manifest_read: dict, manifest: dict,
             inputs: list[dict], snapshots: list[dict]) -> dict:
    checks = [(None, "manifest", "input", manifest_path, manifest_read,
               MAX_SUITE_MANIFEST_BYTES)]
    for case, original, frozen in zip(manifest["cases"], inputs, snapshots):
        for role in _ROLES:
            checks.append((case["case_id"], role, "input", original[role]["path"],
                           original[role], MAX_FILE_BYTES))
            if role in frozen:
                checks.append((case["case_id"], role, "snapshot", frozen[role]["path"],
                               frozen[role], MAX_FILE_BYTES))
    issues = []
    for case_id, role, scope, path, expected, limit in checks:
        try:
            current = _read(path, limit, identity=expected["identity"])
            if current["sha256"] != expected["sha256"] or current["size"] != expected["size"]:
                raise SuiteError("suite_input_changed")
        except SuiteError as exc:
            issues.append({"case_id": case_id, "role": role, "scope": scope,
                           "reason_code": exc.code})
    return {"status": "failed" if issues else "verified", "issues": issues}


def run_regression_suite(manifest_path: str | Path, output_dir: str | Path) -> dict:
    """Analyze at most 20 pinned cases and write only to an exclusive new folder.

    The manifest and every expected byte hash are preflighted before creation.
    A malformed WAV or analysis failure is recorded per case and does not hide
    later cases. Snapshots are retained in the output for reproducibility and
    must be handled as authorized local audio, not public reports.
    """
    path, manifest_read, output, manifest, inputs = _preflight(manifest_path, output_dir)
    _new_folder(output, parents=True)
    _new_bytes(output / "suite_manifest.json", _json_bytes(manifest))
    _new_folder(output / "inputs")
    snapshots = [{} for _ in inputs]
    result = {"schema_version": 1, "engine": "audio_regression_suite_v1",
              "producer_version": __version__, "manifest": deepcopy(manifest),
              "manifest_sha256": canonical_manifest_sha256(manifest),
              "execution_complete": False,
              "cases": [_unfinished(case) for case in manifest["cases"]],
              "input_integrity": {"status": "not_checked", "issues": []},
              "complete_audio_approval": False, "commercial_performance_validated": False}
    for index, (spec, original) in enumerate(zip(manifest["cases"], inputs)):
        record = result["cases"][index]
        try:
            folder = output / "inputs" / f"{index + 1:03d}"
            _new_folder(folder)
            metadata = {}
            for role in _ROLES:
                target = folder / (role + ".wav")
                _new_bytes(target, original[role]["raw"])
                frozen = _read(target, MAX_FILE_BYTES)
                if frozen["sha256"] != original[role]["sha256"]:
                    raise SuiteError("suite_snapshot_hash_mismatch")
                snapshots[index][role] = {"path": target,
                                          **{key: value for key, value in frozen.items() if key != "raw"}}
                metadata[role] = decode_wav(frozen["raw"]).metadata()
            for role in ("baseline", "candidate"):
                record[role + "_analysis"] = _analyze(
                    snapshots[index]["source"]["path"], snapshots[index][role]["path"],
                    spec["configuration"], metadata["source"], metadata[role])
            record.update(status="completed", reason_code=None,
                          delta=compare_case_results(record["baseline_analysis"],
                                                     record["candidate_analysis"],
                                                     spec["configuration"],
                                                     spec["source"]["sha256"]))
        except KeyboardInterrupt:
            record.update(status="error", reason_code="suite_execution_interrupted")
            break
        except Exception as exc:
            record.update(status="error", reason_code=_code(exc, "suite_analysis_execution_error"))
    else:
        result["execution_complete"] = True
    result["input_integrity"] = _recheck(path, manifest_read, manifest, inputs, snapshots)
    result["summary"] = build_suite_summary(result)
    result = validate_suite_result(result)
    raw = _json_bytes(result)
    if len(raw) > MAX_SUITE_RESULT_BYTES:
        raise SuiteError("suite_result_too_large")
    _new_bytes(output / "suite_result.json", raw)
    return result
