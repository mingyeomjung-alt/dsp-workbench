"""Bounded native DSP operations for local development pipeline regressions.

Every stage works on immutable decoded mono samples and emits a strictly
validated PCM16 WAV. Split/join orders are explicit assembly instructions;
omitting or repeating chunks never declares the resulting edit acceptable.
"""

from __future__ import annotations

import math
import unicodedata

import numpy as np
from scipy.signal import resample_poly

from .audio import (
    AudioInputError,
    MAX_DURATION_SECONDS,
    MIN_DURATION_SECONDS,
    SUPPORTED_SAMPLE_RATES,
    WavAudio,
    decode_wav,
    encode_wav,
)


class PipelineTransformError(ValueError):
    """A stage rejection with a stable, non-private machine-readable code."""

    def __init__(self, code: str, message: str | None = None) -> None:
        self.code = code
        self.message = message if message is not None else code
        super().__init__(self.message)


def _invalid_stage(message: str) -> PipelineTransformError:
    return PipelineTransformError("invalid_stage", message)


def validate_stage(spec: dict) -> dict:
    """Return a fresh JSON-safe stage specification, rejecting extra fields.

    Integer parameters require actual integers, and booleans are never numeric
    parameters. The only optional fields are a 1–80 character label without
    control, format, or surrogate characters and, for split/join, a list of at most
    2,000 nonnegative chunk indices.
    """
    if not isinstance(spec, dict):
        raise _invalid_stage("A pipeline stage must be an object.")
    kind = spec.get("kind")
    if type(kind) is not str or kind not in {"resample", "gain", "split_join"}:
        raise _invalid_stage("Supported stage kinds are resample, gain, and split_join.")

    fields = {
        "resample": {"kind", "label", "target_rate_hz"},
        "gain": {"kind", "label", "gain_db"},
        "split_join": {"kind", "label", "segment_ms", "order"},
    }
    if any(key not in fields[kind] for key in spec):
        raise _invalid_stage("The pipeline stage contains an unknown field.")
    normalized = {"kind": kind}
    if "label" in spec:
        label = spec["label"]
        if (
            type(label) is not str
            or not 1 <= len(label) <= 80
            or not label.strip()
            or any(unicodedata.category(character) in {"Cc", "Cf", "Cs"} for character in label)
        ):
            raise _invalid_stage("A stage label must contain 1 to 80 characters without controls.")
        normalized["label"] = label

    if kind == "resample":
        rate = spec.get("target_rate_hz")
        if type(rate) is not int or rate not in SUPPORTED_SAMPLE_RATES:
            raise _invalid_stage("The target sample rate must be 8000, 16000, 44100, or 48000.")
        normalized["target_rate_hz"] = rate
    elif kind == "gain":
        gain_db = spec.get("gain_db")
        if type(gain_db) not in (int, float):
            raise _invalid_stage("Gain must be a finite number between -60 and 20 dB.")
        try:
            gain = float(gain_db)
        except (OverflowError, ValueError):
            raise _invalid_stage("Gain must be a finite number between -60 and 20 dB.") from None
        if not math.isfinite(gain) or not -60.0 <= gain <= 20.0:
            raise _invalid_stage("Gain must be a finite number between -60 and 20 dB.")
        normalized["gain_db"] = gain
    else:
        segment_ms = spec.get("segment_ms")
        if type(segment_ms) is not int or not 200 <= segment_ms <= 30_000:
            raise _invalid_stage("The segment duration must be an integer from 200 to 30000 ms.")
        normalized["segment_ms"] = segment_ms
        if "order" in spec:
            order = spec["order"]
            if (
                type(order) is not list
                or len(order) > 2_000
                or any(type(index) is not int or index < 0 for index in order)
            ):
                raise _invalid_stage("Chunk order must be at most 2000 nonnegative integer indices.")
            normalized["order"] = list(order)
    return normalized


def _validate_output_duration(sample_count: int, rate: int) -> None:
    if not MIN_DURATION_SECONDS * rate <= sample_count <= MAX_DURATION_SECONDS * rate:
        raise PipelineTransformError("invalid_duration", "Stage output must be between 2 and 30 seconds.")


def _split_join(audio: WavAudio, stage: dict) -> np.ndarray:
    # The nearest whole sample defines a fixed chunk length. Every remainder
    # sample is retained in the final, possibly shorter, chunk.
    segment_samples = round(audio.sample_rate_hz * stage["segment_ms"] / 1000)
    chunks = [
        audio.samples[start : start + segment_samples]
        for start in range(0, audio.samples.size, segment_samples)
    ]
    order = stage.get("order", range(len(chunks)))
    if any(index >= len(chunks) for index in order):
        raise PipelineTransformError("invalid_order", "Chunk order references an unavailable input chunk.")
    sample_count = sum(chunks[index].size for index in order)
    _validate_output_duration(sample_count, audio.sample_rate_hz)
    # Validate cardinality before allocating: repetition can otherwise produce
    # much more than the permitted 30 seconds of output.
    return np.concatenate([chunks[index] for index in order])


def execute_stage(audio: WavAudio, spec: dict) -> tuple[bytes, dict]:
    """Run one native stage without mutating, normalizing, or clipping input.

    Output samples are encoded through the existing strict PCM16 writer, then
    decoded to verify the complete WAV container and the 2–30 second contract.
    """
    stage = validate_stage(spec)
    if not isinstance(audio, WavAudio):
        raise PipelineTransformError("invalid_audio", "A stage requires decoded WAV audio.")

    kind = stage["kind"]
    rate = audio.sample_rate_hz
    if kind == "resample":
        target_rate = stage["target_rate_hz"]
        divisor = math.gcd(rate, target_rate)
        samples = resample_poly(audio.samples, target_rate // divisor, rate // divisor)
        rate = target_rate
    elif kind == "gain":
        samples = audio.samples * 10.0 ** (stage["gain_db"] / 20.0)
    else:
        samples = _split_join(audio, stage)

    _validate_output_duration(samples.size, rate)
    try:
        output_wav = encode_wav(samples, rate)
        decode_wav(output_wav)
    except AudioInputError as error:
        raise PipelineTransformError(error.code, error.message) from None

    operation_info = {
        "kind": kind,
        "parameters": {key: value for key, value in stage.items() if key not in {"kind", "label"}},
        "declared_comparison": {
            "profile": "basic",
            "allow_gain": kind == "gain",
            "allow_resampling": kind == "resample",
            "max_delay_ms": 1000.0,
        },
    }
    return output_wav, operation_info
