"""Inert, fail-closed contract for an explicitly declared DSP model check.

This validates a saved diagnostic record, not the execution of a model. It never
opens referenced audio or traces, infers a processing plan, approves complete
audio, or establishes fault provenance. Existing temporal contracts are reused
without changing their geometry, thresholds, or approval semantics.
"""

from __future__ import annotations

import json
from pathlib import Path

from .check_policy import check_result
from .result_contract import (
    MAX_RESULT_BYTES, ResultContractError, _fields, _integer, _invalid_constant,
    _json_tree, _metadata, _number, _reject, _unique_object,
    validate_analysis_result,
)
from .transform_models import ModelTransformError, validate_model_plan


ENGINE = "declared_transform_check_v1"
MAX_MODEL_RESULT_BYTES = MAX_RESULT_BYTES
_ANALYSIS_ENGINES = frozenset(f"local_content_alignment_v{index}" for index in range(1, 10))
_TOP_FIELDS = {
    "schema_version", "engine", "status", "model_plan", "source", "expected",
    "processed", "comparison", "analysis", "temporal_check", "summary",
    "artifacts", "complete_audio_approval", "commercial_performance_validated",
    "network_used", "fault_provenance_confirmed",
}
_COMPARISON_FIELDS = {"exact_pcm16_match", "unequal_sample_count", "maximum_abs_error_pcm16"}
_SUMMARY_FIELDS = {"gate_state", "exit_code", "reason_code"}
_ARTIFACT_PATHS = {
    "source": "input/source.wav",
    "processed": "input/processed.wav",
    "expected": "expected/output.wav",
    "analysis": "analysis.json",
    "temporal_check": "temporal_check.json",
}


def _same_json(first: object, second: object) -> bool:
    """Compare bounded built-in JSON without serializing private payloads."""
    if type(first) is not type(second):
        return False
    if type(first) is dict:
        return first.keys() == second.keys() and all(
            _same_json(first[key], second[key]) for key in second
        )
    if type(first) is list:
        return len(first) == len(second) and all(
            _same_json(left, right) for left, right in zip(first, second)
        )
    return first == second


def derive_model_summary(comparison: dict, temporal_check: dict) -> dict:
    """Derive the narrow gate after validating its two bounded control inputs.

    A matched expected waveform cannot clear a withheld temporal comparison.
    This helper is not a substitute for validating the complete result record.
    """
    if (type(comparison) is not dict or type(comparison.get("exact_pcm16_match")) is not bool
            or type(temporal_check) is not dict or type(temporal_check.get("exit_code")) is not int
            or temporal_check["exit_code"] not in {0, 1, 2}):
        _reject("invalid_model_summary_inputs")
    exact, temporal_exit = comparison["exact_pcm16_match"], temporal_check["exit_code"]
    if exact and temporal_exit == 1:
        _reject("inconsistent_exact_temporal_candidates")
    if temporal_exit == 2:
        return {"gate_state": "blocked", "exit_code": 2,
                "reason_code": "temporal_comparison_withheld"}
    if exact:
        return {"gate_state": "clear_declared_model_check", "exit_code": 0,
                "reason_code": "declared_model_matched"}
    if temporal_exit == 1:
        return {"gate_state": "review_required", "exit_code": 1,
                "reason_code": "temporal_defect_candidates"}
    return {"gate_state": "blocked", "exit_code": 2,
            "reason_code": "declared_model_unexplained_difference"}


def validate_model_result(value: object) -> dict:
    """Return the original validated object, without reading any artifacts.

    The original, expected and processed metadata are strictly bound to the
    existing temporal child. Byte hashes are not PCM equality: harmless RIFF
    container differences can change a hash without changing audio samples.
    """
    if type(value) is not dict:
        _reject("invalid_model_result_type")
    _json_tree(value)
    result = _fields(value, _TOP_FIELDS, code="invalid_model_result_structure")
    if type(result["schema_version"]) is not int or result["schema_version"] != 1:
        _reject("unsupported_schema_version")
    if type(result["engine"]) is not str or result["engine"] != ENGINE:
        _reject("unsupported_model_engine")
    if type(result["status"]) is not str or result["status"] != "completed":
        _reject("unsupported_model_result_status")
    for field in ("complete_audio_approval", "commercial_performance_validated",
                  "network_used", "fault_provenance_confirmed"):
        if result[field] is not False:
            _reject("invalid_approval_claim")
    try:
        validate_model_plan(result["model_plan"])
    except ModelTransformError as exc:
        raise ResultContractError(exc.code) from None

    source, expected, processed = (_metadata(result[name]) for name in ("source", "expected", "processed"))
    if (source["sample_rate_hz"] != expected["sample_rate_hz"]
            or expected["sample_rate_hz"] != processed["sample_rate_hz"]):
        _reject("inconsistent_model_sample_rate")
    if source["sample_count"] != expected["sample_count"]:
        _reject("inconsistent_model_expected_length")
    comparison = _fields(result["comparison"], _COMPARISON_FIELDS, code="invalid_model_comparison")
    if type(comparison["exact_pcm16_match"]) is not bool:
        _reject("invalid_model_comparison")
    same_count = expected["sample_count"] == processed["sample_count"]
    unequal, error = comparison["unequal_sample_count"], comparison["maximum_abs_error_pcm16"]
    if same_count:
        _integer(unequal, "invalid_unequal_sample_count", 0)
        _integer(error, "invalid_maximum_pcm16_error", 0)
        if unequal > expected["sample_count"]:
            _reject("invalid_unequal_sample_count")
        if error > 65535:
            _reject("invalid_maximum_pcm16_error")
        if bool(unequal) != bool(error):
            _reject("inconsistent_model_comparison")
    elif unequal is not None or error is not None:
        _reject("inconsistent_model_comparison")
    exact = same_count and unequal == 0 and error == 0
    if comparison["exact_pcm16_match"] is not exact:
        _reject("inconsistent_model_comparison")
    if exact and any(expected[name] != processed[name] for name in ("rms", "peak")):
        _reject("inconsistent_model_exact_metadata")
    if expected["sha256"] == processed["sha256"] and (expected != processed or not exact):
        _reject("inconsistent_model_hash_comparison")

    child = validate_analysis_result(result["analysis"])
    if child["status"] == "error":
        _reject("model_child_analysis_error")
    if child["engine"] not in _ANALYSIS_ENGINES:
        _reject("unsupported_model_analysis_engine")
    if child["reference"] != expected or child["processed"] != processed:
        _reject("inconsistent_model_analysis_metadata")
    configuration = child["configuration"]
    if (configuration["profile"] != "basic" or configuration["allow_gain"] is not False
            or configuration["allow_resampling"] is not False
            or _number(configuration["max_delay_ms"], "invalid_model_analysis_configuration") != 1000):
        _reject("invalid_model_analysis_configuration")
    temporal = check_result(child)
    if not _same_json(result["temporal_check"], temporal):
        _reject("inconsistent_model_temporal_check")
    summary = _fields(result["summary"], _SUMMARY_FIELDS, code="invalid_model_summary")
    if type(summary["exit_code"]) is not int or summary["exit_code"] not in {0, 1, 2}:
        _reject("invalid_model_summary_exit_code")
    if not _same_json(summary, derive_model_summary(comparison, temporal)):
        _reject("inconsistent_model_summary")

    artifacts = _fields(result["artifacts"], set(_ARTIFACT_PATHS) | {"trace"}, code="invalid_model_artifacts")
    if any(artifacts[name] != path for name, path in _ARTIFACT_PATHS.items()):
        _reject("invalid_model_artifact_path")
    trace_path = None if child["engine"] == "local_content_alignment_v1" else "trace.json"
    if artifacts["trace"] != trace_path:
        _reject("invalid_model_artifact_path")
    return result


def load_model_result(path: str | Path) -> dict:
    """Load at most one MiB of strict UTF-8 JSON; follow no referenced paths."""
    try:
        with Path(path).open("rb") as stream:
            data = stream.read(MAX_MODEL_RESULT_BYTES + 1)
    except (OSError, ValueError, TypeError):
        raise ResultContractError("result_file_read_error") from None
    if len(data) > MAX_MODEL_RESULT_BYTES:
        _reject("result_file_too_large")
    try:
        value = json.loads(data.decode("utf-8"), object_pairs_hook=_unique_object,
                           parse_constant=_invalid_constant)
    except ResultContractError:
        raise
    except (UnicodeError, ValueError, RecursionError, OverflowError):
        raise ResultContractError("invalid_result_json") from None
    return validate_model_result(value)
