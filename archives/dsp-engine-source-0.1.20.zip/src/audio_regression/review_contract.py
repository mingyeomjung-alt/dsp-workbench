"""Optional, strictly bounded explanations for existing withheld results.

This contract validates stored explanatory metadata only. It never reads a
trace or audio file, proves that a stage ran, changes a diagnostic decision,
or establishes fault provenance. Legacy results need no explanation field.
"""

from __future__ import annotations

from functools import wraps


_BLOCK_FIELDS = {
    "schema_version", "selected_engine", "result_status", "primary_reason_code",
    "trace_availability", "diagnostic_only", "fault_provenance_confirmed", "stages",
}
_STAGE_FIELDS = {"engine", "outcome", "reason_code", "detail_reason_code"}
_ENGINES = tuple(f"local_content_alignment_v{version}" for version in range(1, 13))
_OUTCOMES = {"withheld", "not_attempted", "attempted_without_proof_detail"}
_AVAILABILITY = {"recorded", "not_recorded", "unavailable"}


def _reject(code: str) -> None:
    # Lazy import avoids a cycle when the central and candidate validators
    # import this decorator during their own module initialization.
    from .result_contract import ResultContractError
    raise ResultContractError(code)


def validate_review_diagnostics(value: object, result: dict) -> dict:
    """Validate a block against its already-valid, original withheld result."""
    from .result_contract import _reason
    from .review_diagnostics import (
        KNOWN_REASON_CODES, SUCCESS_REASON_CODES, V10_REASON_CODES, V11_REASON_CODES, V12_REASON_CODES,
    )

    if result["status"] != "withheld":
        _reject("review_diagnostics_not_supported_for_status")
    if type(value) is not dict or set(value) != _BLOCK_FIELDS:
        _reject("invalid_review_diagnostics_structure")
    if type(value["schema_version"]) is not int or value["schema_version"] != 1:
        _reject("unsupported_review_diagnostics_version")
    if (type(value["selected_engine"]) is not str
            or value["selected_engine"] != result["engine"]):
        _reject("inconsistent_review_diagnostics_engine")
    if value["result_status"] != "withheld":
        _reject("inconsistent_review_diagnostics_status")
    _reason(value["primary_reason_code"])
    if value["primary_reason_code"] != result["reason_code"]:
        _reject("inconsistent_review_diagnostics_reason")
    if (type(value["trace_availability"]) is not str
            or value["trace_availability"] not in _AVAILABILITY):
        _reject("invalid_review_trace_availability")
    if value["diagnostic_only"] is not True or value["fault_provenance_confirmed"] is not False:
        _reject("invalid_review_diagnostics_claim")
    stages = value["stages"]
    selected_is_v12 = result["engine"] == "local_content_alignment_v12"
    selected_is_v11 = result["engine"] == "local_content_alignment_v11"
    selected_is_v10 = result["engine"] == "local_content_alignment_v10"
    allowed_engines = (_ENGINES if selected_is_v12 else _ENGINES[:11] if selected_is_v11
                       else _ENGINES[:10] if selected_is_v10 else _ENGINES[:9])
    if type(stages) is not list or len(stages) > len(allowed_engines):
        _reject("invalid_review_diagnostics_stages")
    if value["trace_availability"] != "recorded" and stages:
        _reject("inconsistent_review_trace_availability")
    maximum = _ENGINES.index(result["engine"]) + 1
    previous = 0
    for stage in stages:
        if type(stage) is not dict or set(stage) != _STAGE_FIELDS:
            _reject("invalid_review_stage_structure")
        if type(stage["engine"]) is not str or stage["engine"] not in allowed_engines:
            _reject("invalid_review_stage_engine")
        version = _ENGINES.index(stage["engine"]) + 1
        if not previous < version <= maximum:
            _reject("unordered_review_diagnostics_stages")
        previous = version
        if type(stage["outcome"]) is not str or stage["outcome"] not in _OUTCOMES:
            _reject("invalid_review_stage_outcome")
        reason, detail = stage["reason_code"], stage["detail_reason_code"]
        allowed_reasons = KNOWN_REASON_CODES
        if (selected_is_v10 or selected_is_v11 or selected_is_v12) and stage["engine"] == _ENGINES[9]:
            allowed_reasons |= V10_REASON_CODES
        if (selected_is_v11 or selected_is_v12) and stage["engine"] == _ENGINES[10]:
            allowed_reasons |= V11_REASON_CODES
        if selected_is_v12 and stage["engine"] == _ENGINES[11]:
            allowed_reasons |= V12_REASON_CODES
        if stage["outcome"] == "withheld":
            if (type(reason) is not str or reason not in allowed_reasons
                    or reason in SUCCESS_REASON_CODES):
                _reject("invalid_review_stage_reason")
            if detail is not None and (type(detail) is not str or detail not in allowed_reasons
                                       or detail in SUCCESS_REASON_CODES):
                _reject("invalid_review_stage_detail_reason")
        elif reason is not None or detail is not None:
            _reject("inconsistent_review_stage_reason")
    return value


def with_review_diagnostics(validator):
    """Add an optional explanation without relaxing the decorated core rules.

    A bounded JSON tree is checked before making a shallow, field-stripped
    view. The existing validator runs on that view unchanged. This prevents
    candidate validators' private engine rewrites from rewriting explanatory
    identity too, and returns the caller's original object without mutation.
    """
    @wraps(validator)
    def validate(value: object) -> dict:
        if type(value) is not dict or "review_diagnostics" not in value:
            return validator(value)
        from .result_contract import _json_tree
        _json_tree(value)
        core = {key: item for key, item in value.items() if key != "review_diagnostics"}
        validator(core)
        validate_review_diagnostics(value["review_diagnostics"], value)
        return value

    return validate
