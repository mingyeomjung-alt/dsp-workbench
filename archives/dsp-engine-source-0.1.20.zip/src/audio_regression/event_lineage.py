"""Conservative coordinate projection over recorded adjacent-stage diagnostics.

No audio or artifact path is opened.  The stored alignments are diagnostic
correspondences, not authenticated processing history or sample provenance.
Missing coverage and competing copy correspondences are never interpolated.
"""

from __future__ import annotations

from copy import deepcopy
from fractions import Fraction
import hashlib
import json

from .pipeline_reporting import PipelineReportError, validate_pipeline_result
from .saved_pipeline_contract import SavedPipelineContractError, validate_saved_pipeline_result


ENGINE = "audio_pipeline_event_lineage_v1"
MAX_SOURCE_RESULT_BYTES = 4 * 1024 * 1024
MAX_LINEAGE_EVENTS = 256
REASON_CODES = frozenset({
    "stage_not_analyzed", "unmapped_alignment_gap", "ambiguous_alignment",
    "repeated_content_multiple_correspondences",
    "input_integrity_or_completion_unavailable",
})
_RUN_ENGINES = frozenset("audio_pipeline_regression_v" + str(i) for i in range(1, 12))
_AUDIT_ENGINES = (frozenset("audio_saved_pipeline_audit_v" + str(i) for i in range(1, 12))
                  | {"audio_saved_pipeline_audit_mixed_v1"})


class LineageError(ValueError):
    """Stable rejection codes without saved paths or input exception text."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__("Recorded event coordinates could not be projected: " + code + ".")


def _validated_source(value: object) -> dict:
    if type(value) is not dict or type(value.get("engine")) is not str:
        raise LineageError("invalid_lineage_source_result")
    try:
        if value["engine"] in _RUN_ENGINES:
            return validate_pipeline_result(value)
        if value["engine"] in _AUDIT_ENGINES:
            return validate_saved_pipeline_result(value)
    except (PipelineReportError, SavedPipelineContractError, RecursionError,
            OverflowError, TypeError, ValueError):
        raise LineageError("invalid_lineage_source_result") from None
    raise LineageError("invalid_lineage_source_result")


def _canonical_digest(value: dict) -> str:
    """Bound canonical serialization before copying an entire saved result."""
    digest = hashlib.sha256()
    size = 0
    try:
        chunks = json.JSONEncoder(ensure_ascii=False, sort_keys=True,
                                  separators=(",", ":"), allow_nan=False).iterencode(value)
        for chunk in chunks:
            raw = chunk.encode("utf-8")
            size += len(raw)
            if size > MAX_SOURCE_RESULT_BYTES:
                raise LineageError("source_result_too_large")
            digest.update(raw)
    except LineageError:
        raise
    except (UnicodeError, TypeError, ValueError, OverflowError, RecursionError):
        raise LineageError("invalid_lineage_source_result") from None
    return digest.hexdigest()


def _fraction(value: int | float) -> Fraction:
    # The exact saved decimal coordinate is the only available evidence.  A
    # tolerance here could silently bridge a real unrecorded interval.
    return Fraction(str(value))


class _UnrepresentableCoordinate(ValueError):
    """Rounding an intermediate JSON number must not bridge a later gap."""


def _number(value: Fraction) -> int | float:
    if value.denominator == 1:
        return value.numerator
    number = float(value)
    if _fraction(number) != value:
        raise _UnrepresentableCoordinate
    return number


def _interval(start: Fraction, stop: Fraction) -> dict:
    return {"kind": "interval", "interval_ms": [_number(start), _number(stop)]}


def _boundary(point: Fraction) -> dict:
    return {"kind": "boundary", "time_ms": _number(point)}


def _repeat_intersects(query: dict, event: dict, direction: str) -> bool:
    if event["type"] != "repeat":
        return False
    field = ("reference_source_interval_ms" if direction == "forward"
             else "processed_added_interval_ms")
    start, stop = map(_fraction, event[field])
    if query["kind"] == "boundary":
        return start <= _fraction(query["time_ms"]) <= stop
    left, right = map(_fraction, query["interval_ms"])
    return max(left, start) < min(right, stop)


def _mapped_query(query: dict, analysis: dict, direction: str) -> tuple[dict | None, str | None]:
    if any(_repeat_intersects(query, event, direction) for event in analysis["events"]):
        return None, "repeated_content_multiple_correspondences"
    for event in analysis["events"]:
        if event["type"] != "delete":
            continue
        start, stop = map(_fraction, event["reference_interval_ms"])
        point = _fraction(event["processed_boundary_ms"])
        if direction == "forward":
            if query["kind"] == "boundary":
                removed = start < _fraction(query["time_ms"]) < stop
            else:
                left, right = map(_fraction, query["interval_ms"])
                removed = max(left, start) < min(right, stop)
            if removed:
                return None, "unmapped_alignment_gap"
        elif query["kind"] == "boundary":
            if _fraction(query["time_ms"]) == point:
                return None, "ambiguous_alignment"
        else:
            left, right = map(_fraction, query["interval_ms"])
            if left < point < right:
                return None, "ambiguous_alignment"
    # Legacy contracts validate anchors and events separately.  A broad anchor
    # must not override an event merely because this particular query is far
    # from the edit itself.  Reject contradictory recorded stage geometry.
    for segment in analysis["alignment_segments"]:
        left, right = map(_fraction, segment["reference_interval_ms"])
        offset = _fraction(segment["processed_offset_ms"])
        for event in analysis["events"]:
            evidence = event["evidence"]
            if event.get("location") in {"head", "tail"}:
                # Endpoint certificates record one retained side, not invented
                # before/after contexts on the missing side.
                expected = _fraction(evidence["retained_offset_ms"])
                start, stop = map(_fraction, event["reference_interval_ms"])
                if max(left, start) < min(right, stop) or offset != expected:
                    return None, "ambiguous_alignment"
                continue
            before = _fraction(evidence["offset_before_ms"])
            after = _fraction(evidence["offset_after_ms"])
            if event["type"] == "delete":
                start, stop = map(_fraction, event["reference_interval_ms"])
                if right <= start:
                    expected = before
                elif left >= stop:
                    expected = after
                else:
                    return None, "ambiguous_alignment"
            else:
                pivot = _fraction(event["reference_source_interval_ms"][1])
                if right <= pivot:
                    expected = before
                elif left >= pivot:
                    expected = after
                else:
                    return None, "ambiguous_alignment"
            if offset != expected:
                return None, "ambiguous_alignment"
    segments = []
    for segment in analysis["alignment_segments"]:
        start, stop = map(_fraction, segment["reference_interval_ms"])
        offset = _fraction(segment["processed_offset_ms"])
        if direction == "backward":
            start, stop, offset = start + offset, stop + offset, -offset
        segments.append((start, stop, offset))
    target = analysis["processed"] if direction == "forward" else analysis["reference"]
    limit = _fraction(target["duration_ms"])
    if query["kind"] == "boundary":
        point = _fraction(query["time_ms"])
        offsets = {offset for start, stop, offset in segments if start <= point <= stop}
        if not offsets:
            return None, "unmapped_alignment_gap"
        if len(offsets) != 1:
            return None, "ambiguous_alignment"
        mapped = point + offsets.pop()
        if not 0 <= mapped <= limit:
            return None, "unmapped_alignment_gap"
        return _boundary(mapped), None

    left, right = map(_fraction, query["interval_ms"])
    coverage = sorted((max(left, start), min(right, stop), offset)
                      for start, stop, offset in segments
                      if max(left, start) < min(right, stop))
    cursor, selected_offset = left, None
    for start, stop, offset in coverage:
        if start > cursor:
            return None, "unmapped_alignment_gap"
        if start < cursor:
            return None, "ambiguous_alignment"
        if selected_offset is not None and selected_offset != offset:
            return None, "ambiguous_alignment"
        selected_offset, cursor = offset, stop
    if cursor != right or selected_offset is None:
        return None, "unmapped_alignment_gap"
    start, stop = left + selected_offset, right + selected_offset
    if not 0 <= start < stop <= limit:
        return None, "unmapped_alignment_gap"
    return _interval(start, stop), None


def _project(query: dict, stages: list[dict], direction: str, integrity: bool) -> dict:
    if not integrity:
        return {"status": "unresolved", "reason_code": "input_integrity_or_completion_unavailable",
                "fragments": [], "hops": []}
    current, hops = deepcopy(query), []
    for stage in stages:
        reference, processed = stage["input"], stage["output"]
        input_metadata, output_metadata = ((reference, processed) if direction == "forward"
                                           else (processed, reference))
        # A globally incomplete result is already excluded above, so missing
        # output metadata cannot be used to invent a hash on this branch.
        if input_metadata is None or output_metadata is None:
            return {"status": "unresolved", "reason_code": "stage_not_analyzed",
                    "fragments": [], "hops": hops}
        if stage["status"] != "analyzed":
            output_query, reason = None, "stage_not_analyzed"
        else:
            try:
                output_query, reason = _mapped_query(current, stage["analysis"], direction)
            except _UnrepresentableCoordinate:
                output_query, reason = None, "ambiguous_alignment"
        hops.append({"stage_index": stage["index"], "direction": direction,
                     "input_sha256": input_metadata["sha256"],
                     "output_sha256": output_metadata["sha256"],
                     "input_query": deepcopy(current), "output_query": deepcopy(output_query),
                     "reason_code": reason})
        if reason is not None:
            return {"status": "unresolved", "reason_code": reason,
                    "fragments": [], "hops": hops}
        current = output_query
    return {"status": "mapped", "reason_code": None,
            "fragments": [deepcopy(current)], "hops": hops}


def _event_queries(event: dict) -> tuple[dict, dict]:
    if event["type"] == "delete":
        return ({"kind": "interval", "interval_ms": deepcopy(event["reference_interval_ms"])},
                {"kind": "boundary", "time_ms": event["processed_boundary_ms"]})
    return ({"kind": "interval", "interval_ms": deepcopy(event["reference_source_interval_ms"])},
            {"kind": "interval", "interval_ms": deepcopy(event["processed_added_interval_ms"])})


def _derive(source: dict) -> dict:
    stages = source["stages"]
    integrity = (source["status"] == "completed"
                 and source.get("input_recheck", {"status": "unchanged"})["status"] == "unchanged")
    observed = sum(len(stage["analysis"]["events"]) for stage in stages
                   if stage["status"] == "analyzed")
    if observed > MAX_LINEAGE_EVENTS:
        raise LineageError("lineage_event_budget_exceeded")
    events = []
    for position, stage in enumerate(stages):
        if stage["status"] != "analyzed":
            continue
        for index, event in enumerate(stage["analysis"]["events"]):
            reference_query, processed_query = _event_queries(event)
            events.append({"stage_index": stage["index"], "event_index": index,
                           "type": event["type"], "reference_query": reference_query,
                           "processed_query": processed_query,
                           "source_projection": _project(reference_query, list(reversed(stages[:position])),
                                                         "backward", integrity),
                           "final_projection": _project(processed_query, stages[position + 1:],
                                                        "forward", integrity)})
    end = source["end_to_end"]
    end_count = (len(end["analysis"]["events"])
                 if end is not None and end["status"] == "analyzed" else None)
    source_count = sum(event["source_projection"]["status"] == "mapped" for event in events)
    final_count = sum(event["final_projection"]["status"] == "mapped" for event in events)
    full_count = sum(event["source_projection"]["status"] == "mapped"
                     and event["final_projection"]["status"] == "mapped" for event in events)
    return {
        "input_pipeline_engine": source["engine"], "stage_count": len(stages),
        "event_scope": "adjacent_stage_events_only",
        "end_to_end_event_count_not_attributed": end_count,
        "source": deepcopy(source["source"]), "final": deepcopy(stages[-1]["output"]),
        "original_summary": deepcopy(source["summary"]),
        "input_integrity": "no_failure_recorded" if integrity else "failure_recorded",
        "events": events,
        "summary": {"observed_event_count": len(events), "source_projected_count": source_count,
                    "final_projected_count": final_count, "fully_projected_count": full_count,
                    "unresolved_event_count": len(events) - full_count},
    }


def derive_event_lineage_projection(source_result: object) -> dict:
    """Validate a saved result and project recorded coordinates without I/O."""
    source = _validated_source(source_result)
    _canonical_digest(source)
    return _derive(deepcopy(source))


def build_event_lineage(source_result: object) -> dict:
    """Build a detached, reproducible diagnostic sidecar; never grant approval."""
    source = _validated_source(source_result)
    digest = _canonical_digest(source)
    copied = deepcopy(source)
    return {
        "schema_version": 1, "engine": ENGINE, "status": "generated",
        "source_result": copied, "source_result_sha256": digest,
        "projection": _derive(copied), "coordinate_projection_only": True,
        "artifact_authenticity_verified": False, "fault_provenance_confirmed": False,
        "caller_order_verified": False, "complete_audio_approval": False,
        "commercial_performance_validated": False, "network_used": False,
    }
