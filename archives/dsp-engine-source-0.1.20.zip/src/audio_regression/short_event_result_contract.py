"""Strict opt-in v10 contract for native PCM short-edit certificates.

The native grid has separate 50--200 ms, single-edit, full-coverage geometry.
The inherited 8 kHz grid keeps every v9 restriction, including its 200 ms
event floor. This validator reads no waveform or trace and proves neither
execution, edit provenance, whole-audio quality nor commercial performance.
"""

from __future__ import annotations

from copy import deepcopy
import math

from . import result_contract as _base
from .global_context_result_contract import validate_global_context_analysis_result
from .review_contract import with_review_diagnostics


ENGINE = "local_content_alignment_v10"
METHOD = "short_event_exact_pcm_forward_proof"
_ANALYSIS_FIELDS = {
    "sample_rate_hz", "hop_ms", "method", "minimum_event_duration_ms",
    "maximum_cumulative_edit_shift_ms", "diagnostic_rules_not_calibrated_probabilities",
}


def _reject(code: str) -> None:
    raise _base.ResultContractError(code)


def _inherited(value: dict) -> None:
    """Run unchanged v9 rules on a private identity/grid-normalized copy."""
    shared = deepcopy(value)
    shared["engine"] = "local_content_alignment_v9"
    if shared.get("status") != "error":
        shared["analysis"]["method"] = "global_context_quantized_event_forward_proof"
        shared["analysis"]["minimum_event_duration_ms"] = 200
        shared["analysis"]["sample_rate_hz"] = 8000
        shared["analysis"]["hop_ms"] = 10
    validate_global_context_analysis_result(shared)


def _near_exact(value: object, expected: float, code: str) -> None:
    metric = _base._number(value, code, 0, 1)
    if not math.isclose(metric, expected, rel_tol=0, abs_tol=1e-12):
        _reject(code)


def _sample_coordinate(value: float, rate: int) -> None:
    samples = value * rate / 1000
    if not math.isclose(samples, round(samples), rel_tol=0, abs_tol=1e-7):
        _reject("short_event_coordinate_not_on_native_grid")


def _native_event(value: object, reference: dict, processed: dict) -> tuple[float, float, float]:
    if (type(value) is not dict or type(value.get("type")) is not str
            or value["type"] not in {"delete", "repeat"}):
        _reject("unsupported_event_type")
    repeat = value["type"] == "repeat"
    fields = ({"type", "reference_source_interval_ms", "processed_added_interval_ms",
               "copy_interval_convention", "evidence"} if repeat else
              {"type", "reference_interval_ms", "processed_boundary_ms", "evidence"})
    event = _base._fields(value, fields, code="invalid_event_structure")
    source_key = "reference_source_interval_ms" if repeat else "reference_interval_ms"
    start, end = _base._interval(event[source_key], reference["duration_ms"],
                                  "invalid_reference_interval")
    length = end - start
    if not 50 - 1e-9 <= length <= 200 + 1e-9:
        _reject("unsupported_event_duration")
    if start <= 0 or end >= reference["duration_ms"]:
        _reject("short_event_not_internal")
    for coordinate in (start, end):
        _sample_coordinate(coordinate, reference["sample_rate_hz"])
    evidence = _base._evidence(event["evidence"], repeat, 0.9)
    for name, metric in evidence.items():
        if name.endswith("correlation"):
            _near_exact(metric, 1, "inconsistent_short_event_exact_evidence")
    if not _base._same_number(evidence["offset_before_ms"], 0):
        _reject("inconsistent_short_event_offset")
    expected_offset = length if repeat else -length
    if not _base._same_number(evidence["offset_after_ms"], expected_offset):
        _reject("inconsistent_short_event_offset")
    if repeat:
        added_start, added_end = _base._interval(event["processed_added_interval_ms"],
                                                 processed["duration_ms"],
                                                 "invalid_processed_interval")
        if (not _base._same_number(added_start, end)
                or not _base._same_number(added_end, end + length)):
            _reject("inconsistent_repeat_geometry")
        if event["copy_interval_convention"] != "canonical_later_adjacent_copy_not_edit_provenance":
            _reject("unsupported_copy_interval_convention")
    else:
        boundary = _base._number(event["processed_boundary_ms"], "invalid_processed_boundary",
                                 0, processed["duration_ms"])
        if not _base._same_number(boundary, start):
            _reject("inconsistent_delete_geometry")
    delta = processed["duration_ms"] - reference["duration_ms"]
    if not _base._same_number(delta, expected_offset):
        _reject("inconsistent_short_event_length_delta")
    return start, end, expected_offset


def _native_analyzed(value: dict, reference: dict, processed: dict) -> None:
    _base._fields(value, _base._FULL_FIELDS | {"alignment_segments"})
    if value["complete_audio_approval"] is not False or value["commercial_performance_validated"] is not False:
        _reject("invalid_approval_claim")
    if (value["reason_code"] is not None or type(value["events"]) is not list
            or len(value["events"]) != 1
            or value["content_preservation_status"] != "defect_candidates"):
        _reject("inconsistent_result_status")
    limitations = value["limitations"]
    if (type(limitations) is not list or not 1 <= len(limitations) <= 32
            or any(type(item) is not str or not 1 <= len(item) <= 2000 for item in limitations)):
        _reject("invalid_limitations")
    diagnostics = _base._fields(value["diagnostics"], _base._DIAGNOSTIC_FIELDS,
                                code="invalid_diagnostics")
    for name, expected in (("normalized_path_cost", 0), ("gain_estimate", 1),
                           ("applied_gain", 1), ("matched_normalized_rmse", 0),
                           ("minimum_local_correlation", 1)):
        _near_exact(diagnostics[name], expected, "inconsistent_short_event_exact_metrics")
    if _base._integer(diagnostics["anchor_run_count"], "invalid_diagnostics") != 2:
        _reject("inconsistent_anchor_count")
    count = _base._integer(diagnostics["matched_analysis_samples"], "invalid_diagnostics")
    if count != min(reference["sample_count"], processed["sample_count"]):
        _reject("inconsistent_matched_sample_count")
    start, end, offset = _native_event(value["events"][0], reference, processed)
    segments = value["alignment_segments"]
    if type(segments) is not list or len(segments) != 2:
        _reject("invalid_alignment_segments")
    left_end = end if offset > 0 else start
    expected = [([0, left_end], 0), ([end, reference["duration_ms"]], offset)]
    for segment, (interval, expected_offset) in zip(segments, expected, strict=True):
        segment = _base._fields(segment, {"reference_interval_ms", "processed_offset_ms",
                                           "anchor_correlations"}, code="invalid_alignment_segments")
        actual = _base._interval(segment["reference_interval_ms"], reference["duration_ms"],
                                  "invalid_alignment_reference_interval")
        if (not all(_base._same_number(first, second) for first, second in zip(actual, interval, strict=True))
                or not _base._same_number(_base._number(segment["processed_offset_ms"],
                                                        "invalid_alignment_offset"), expected_offset)):
            _reject("inconsistent_short_event_full_coverage")
        correlations = segment["anchor_correlations"]
        if type(correlations) is not list or len(correlations) != 3:
            _reject("invalid_anchor_correlations")
        for correlation in correlations:
            _near_exact(correlation, 1, "inconsistent_short_event_exact_evidence")


@with_review_diagnostics
def validate_short_event_analysis_result(value: object) -> dict:
    """Validate native short-edit or unchanged inherited v9 evidence rules."""
    if type(value) is not dict:
        _reject("invalid_result_type")
    _base._json_tree(value)
    if value.get("engine") != ENGINE:
        _reject("unsupported_engine")
    if type(value.get("schema_version")) is not int or value["schema_version"] != 1:
        _reject("unsupported_schema_version")
    if type(value.get("status")) is not str or value["status"] not in {"analyzed", "withheld", "error"}:
        _reject("unsupported_result_status")
    if value["status"] == "error":
        _inherited(value)
        return value
    analysis = _base._fields(value.get("analysis"), _ANALYSIS_FIELDS, code="invalid_analysis_method")
    if (analysis["method"] != METHOD
            or analysis["diagnostic_rules_not_calibrated_probabilities"] is not True
            or _base._number(analysis["maximum_cumulative_edit_shift_ms"], "invalid_analysis_method") != 2000):
        _reject("invalid_analysis_method")
    minimum_duration = _base._number(analysis["minimum_event_duration_ms"], "invalid_analysis_method")
    rate = _base._integer(analysis["sample_rate_hz"], "invalid_analysis_method")
    hop = _base._number(analysis["hop_ms"], "invalid_analysis_method")
    if rate == 8000 and hop == 10:
        if minimum_duration != 200:
            _reject("invalid_analysis_method")
        _inherited(value)
        return value
    _base._fields(value, _base._FULL_FIELDS |
                   ({"alignment_segments"} if value["status"] == "analyzed" else set()))
    reference, processed = _base._metadata(value["reference"]), _base._metadata(value["processed"])
    if (minimum_duration != 50 or rate != reference["sample_rate_hz"]
            or not math.isclose(hop, 1000 / rate, rel_tol=0, abs_tol=1e-12)):
        _reject("invalid_analysis_method")
    configuration = _base._fields(value["configuration"],
        {"profile", "allow_gain", "allow_resampling", "max_delay_ms"}, code="invalid_configuration")
    if configuration["profile"] != "basic":
        _reject("unsupported_profile")
    if configuration["allow_gain"] is not False or configuration["allow_resampling"] is not False:
        _reject("unsupported_short_event_configuration")
    _base._number(configuration["max_delay_ms"], "invalid_configuration", 0, 5000)
    delta = abs(processed["sample_count"] - reference["sample_count"]) * 1000 / rate
    if (processed["sample_rate_hz"] != rate or not 50 - 1e-9 <= delta <= 200 + 1e-9):
        _reject("unsupported_short_event_configuration")
    if value["status"] == "withheld":
        _inherited(value)
    else:
        _native_analyzed(value, reference, processed)
    return value
