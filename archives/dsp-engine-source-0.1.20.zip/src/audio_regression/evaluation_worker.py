"""Isolated timed worker. Jobs contain files/configuration, never truth labels."""

import argparse
import ctypes
import json
import os
from pathlib import Path
import platform
import time

from .audio import read_wav
from .engine import EngineConfig, analyze_buffers
from .evaluation_baselines import evaluate_baseline


def peak_resident_bytes():
    if os.name == "nt":
        from ctypes import wintypes
        class Counters(ctypes.Structure):
            _fields_ = [("cb", wintypes.DWORD), ("faults", wintypes.DWORD)] + [
                (name, ctypes.c_size_t) for name in (
                    "peak_working_set", "working_set", "peak_paged", "paged",
                    "peak_nonpaged", "nonpaged", "pagefile", "peak_pagefile")]
        kernel = ctypes.WinDLL("kernel32", use_last_error=True)
        kernel.GetCurrentProcess.restype = wintypes.HANDLE
        psapi = ctypes.WinDLL("psapi", use_last_error=True)
        psapi.GetProcessMemoryInfo.argtypes = [wintypes.HANDLE, ctypes.POINTER(Counters), wintypes.DWORD]
        counters = Counters()
        counters.cb = ctypes.sizeof(counters)
        if psapi.GetProcessMemoryInfo(kernel.GetCurrentProcess(), ctypes.byref(counters), counters.cb):
            return int(counters.peak_working_set)
        return None
    import resource
    peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss
    return int(peak if platform.system() == "Darwin" else peak * 1024)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--jobs", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--method", required=True)
    args = parser.parse_args()
    jobs = json.loads(args.jobs.read_text(encoding="utf-8"))
    metadata_path = args.output.with_suffix(".metadata.json")
    if args.output.exists() or metadata_path.exists():
        raise FileExistsError("Worker outputs already exist.")
    error_count = 0
    with args.output.open("x", encoding="utf-8") as stream:
        for index, job in enumerate(jobs):
            start = time.perf_counter()
            try:
                reference = read_wav(job["reference_path"])
                processed = read_wav(job["processed_path"])
                config = EngineConfig(**job["configuration"])
                result = (analyze_buffers(reference, processed, config)
                          if args.method == "candidate"
                          else evaluate_baseline(reference, processed, config, method=args.method))
            except Exception as exc:
                error_count += 1
                result = {"status": "withheld", "events": None,
                          "reason_code": "evaluation_execution_error",
                          "exception_type": type(exc).__name__}
            runtime_ms = (time.perf_counter() - start) * 1000
            row = {"trial_id": job["trial_id"], "runtime_ms": runtime_ms, "result": result}
            stream.write(json.dumps(row, ensure_ascii=False, allow_nan=False) + "\n")
            stream.flush()
            if (index + 1) % 32 == 0:
                print(json.dumps({"method": args.method, "completed": index + 1, "total": len(jobs)}), flush=True)
    metadata = {"method": args.method, "trial_count": len(jobs), "execution_error_count": error_count,
                "peak_process_resident_bytes": peak_resident_bytes(),
                "memory_scope": "whole_isolated_method_worker_including_imports_and_jobs",
                "timing_scope": "per_trial_file_read_and_analysis_excluding_process_startup",
                "thread_environment": {key: os.environ.get(key) for key in
                                       ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS")}}
    with metadata_path.open("x", encoding="utf-8") as stream:
        json.dump(metadata, stream, indent=2, allow_nan=False)
    print(json.dumps(metadata), flush=True)


if __name__ == "__main__":
    main()
