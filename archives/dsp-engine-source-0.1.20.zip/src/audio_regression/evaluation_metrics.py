"""Independent event scoring, with abstentions retained in all denominators.

Deletion localization is scored on the reference axis; repetition localization
is scored on the processed added-copy axis. Secondary coordinates never rescue
an incorrect primary interval. Bootstrap samples original source groups, not
the dependent transformed trials within each source. These descriptive intervals
do not establish population or real-world accuracy for a small source corpus.
"""

from __future__ import annotations

import math
from numbers import Integral, Real

import numpy as np
from scipy.optimize import linear_sum_assignment


IOU_THRESHOLD = 0.5
_PRIMARY_KEY = {"delete": "reference_interval_ms", "repeat": "processed_added_interval_ms"}


def _number(value: object, name: str, *, positive: bool = False) -> float:
    if isinstance(value, bool) or not isinstance(value, Real):
        raise ValueError(f"{name} must be a finite number")
    try:
        number = float(value)
    except (OverflowError, TypeError, ValueError):
        raise ValueError(f"{name} must be a finite number") from None
    if not math.isfinite(number) or number < 0 or (positive and number == 0):
        raise ValueError(f"{name} must be finite and {'positive' if positive else 'nonnegative'}")
    return number


def _interval(value: object, name: str) -> tuple[float, float]:
    if not isinstance(value, (list, tuple)) or len(value) != 2:
        raise ValueError(f"{name} must contain exactly two boundaries")
    start, end = (_number(part, name) for part in value)
    if start >= end:
        raise ValueError(f"{name} must have start < end")
    return start, end


def _validate_events(events: object, name: str) -> list[dict]:
    if not isinstance(events, list):
        raise ValueError(f"{name} must be a list")
    for event in events:
        if not isinstance(event, dict):
            raise ValueError(f"{name} must contain event objects")
        kind = event.get("type")
        if not isinstance(kind, str) or kind not in _PRIMARY_KEY:
            raise ValueError(f"{name} contains an unsupported event type")
        _interval(event.get(_PRIMARY_KEY[kind]), f"{name}.{_PRIMARY_KEY[kind]}")
        if "processed_boundary_ms" in event:
            _number(event["processed_boundary_ms"], f"{name}.processed_boundary_ms")
        if "reference_source_interval_ms" in event:
            _interval(event["reference_source_interval_ms"], f"{name}.reference_source_interval_ms")
    return events


def _iou(first: tuple[float, float], second: tuple[float, float]) -> float:
    overlap = max(0.0, min(first[1], second[1]) - max(first[0], second[0]))
    return overlap / (max(first[1], second[1]) - min(first[0], second[0]))


def score_trial(expected_events: list[dict], result: dict) -> dict:
    """Match same-type events one-to-one, maximizing accepted IoU sum.

    Every unmatched expected event is a false negative, including on withheld
    trials or methods that do not produce an event list. A normal withheld trial
    has no false alarm *observation* and is explicitly not assessed.
    """
    truth = _validate_events(expected_events, "expected_events")
    if not isinstance(result, dict) or not isinstance(result.get("status"), str):
        raise ValueError("result must have a string status")
    event_output = result.get("events")
    withheld = event_output is None or result["status"] not in {"analyzed", "measured"}
    if event_output is not None and withheld:
        raise ValueError("unmeasured results must not report an event list")
    predicted = [] if withheld else _validate_events(event_output, "result.events")
    matches: list[dict] = []
    for kind, key in _PRIMARY_KEY.items():
        expected_indices = [i for i, event in enumerate(truth) if event["type"] == kind]
        predicted_indices = [i for i, event in enumerate(predicted) if event["type"] == kind]
        if not expected_indices or not predicted_indices:
            continue
        scores = np.array([
            [_iou(_interval(truth[i][key], key), _interval(predicted[j][key], key))
             for j in predicted_indices]
            for i in expected_indices
        ], dtype=np.float64)
        accepted_scores = np.where(scores >= IOU_THRESHOLD, scores, 0.0)
        rows, columns = linear_sum_assignment(accepted_scores, maximize=True)
        for row, column in zip(rows.tolist(), columns.tolist(), strict=True):
            if accepted_scores[row, column] == 0:
                continue
            expected_index, predicted_index = expected_indices[row], predicted_indices[column]
            expected, actual = truth[expected_index], predicted[predicted_index]
            boundaries = [abs(a - b) for a, b in zip(
                _interval(expected[key], key), _interval(actual[key], key), strict=True)]
            secondary = None
            if kind == "delete" and "processed_boundary_ms" in expected and "processed_boundary_ms" in actual:
                secondary = [abs(float(expected["processed_boundary_ms"]) - float(actual["processed_boundary_ms"]))]
            elif kind == "repeat" and "reference_source_interval_ms" in expected and "reference_source_interval_ms" in actual:
                secondary = [abs(a - b) for a, b in zip(
                    _interval(expected["reference_source_interval_ms"], "reference_source_interval_ms"),
                    _interval(actual["reference_source_interval_ms"], "reference_source_interval_ms"), strict=True)]
            matches.append({
                "type": kind, "expected_index": expected_index, "predicted_index": predicted_index,
                "iou": float(scores[row, column]), "primary_axis": key,
                "primary_boundary_errors_ms": boundaries, "secondary_boundary_errors_ms": secondary,
            })
    matches.sort(key=lambda match: match["expected_index"])
    primary_errors = [error for match in matches for error in match["primary_boundary_errors_ms"]]
    deletion_errors = [error for match in matches if match["type"] == "delete"
                       for error in (match["secondary_boundary_errors_ms"] or [])]
    repeat_source_errors = [error for match in matches if match["type"] == "repeat"
                            for error in (match["secondary_boundary_errors_ms"] or [])]
    normal = not truth
    return {
        "expected_event_count": len(truth), "predicted_event_count": len(predicted),
        "true_positive_events": len(matches), "false_positive_events": len(predicted) - len(matches),
        "false_negative_events": len(truth) - len(matches), "withheld": withheld,
        "normal_trial": normal, "normal_assessed": normal and not withheld,
        "normal_false_alarm": (bool(predicted) if not withheld else None) if normal else None,
        "matches": matches, "primary_boundary_errors_ms": primary_errors,
        "deletion_processed_boundary_errors_ms": deletion_errors,
        "repeat_reference_source_boundary_errors_ms": repeat_source_errors,
    }


def _ratio(numerator: int | float, denominator: int | float) -> float | None:
    return float(numerator / denominator) if denominator else None


def _median(values: list[float]) -> float | None:
    return float(np.median(values)) if values else None


def _scored_rows(rows: list[dict]) -> list[dict]:
    if not isinstance(rows, list):
        raise ValueError("rows must be a list")
    scored = []
    seen = set()
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("rows must contain objects")
        for key in ("trial_id", "source_group", "source_kind", "condition", "profile"):
            if not isinstance(row.get(key), str) or not row[key]:
                raise ValueError(f"{key} must be a nonempty string")
        if row["trial_id"] in seen:
            raise ValueError("trial_id must be unique")
        seen.add(row["trial_id"])
        runtime = _number(row.get("runtime_ms"), "runtime_ms")
        duration = _number(row.get("input_duration_ms"), "input_duration_ms", positive=True)
        rtf = runtime / duration
        if not math.isfinite(rtf):
            raise ValueError("runtime_ms / input_duration_ms must remain finite")
        scored.append({**row, "score": score_trial(row.get("expected_events"), row.get("result")),
                       "rtf": rtf})
    return scored


def _summary(rows: list[dict]) -> dict:
    scores = [row["score"] for row in rows]
    tp = sum(score["true_positive_events"] for score in scores)
    fp = sum(score["false_positive_events"] for score in scores)
    fn = sum(score["false_negative_events"] for score in scores)
    normal_count = sum(score["normal_trial"] for score in scores)
    normal_assessed = sum(score["normal_assessed"] for score in scores)
    normal_false_alarms = sum(score["normal_false_alarm"] is True for score in scores)
    withheld = sum(score["withheld"] for score in scores)
    return {
        "trial_count": len(rows), "source_group_count": len({row["source_group"] for row in rows}),
        "expected_event_count": tp + fn, "predicted_event_count": tp + fp,
        "true_positive_events": tp, "false_positive_events": fp, "false_negative_events": fn,
        "event_precision": _ratio(tp, tp + fp), "event_recall": _ratio(tp, tp + fn),
        "normal_trial_count": normal_count, "normal_assessed_count": normal_assessed,
        "normal_false_alarm_count": normal_false_alarms,
        "normal_withheld_count": normal_count - normal_assessed,
        "normal_false_alarm_rate": _ratio(normal_false_alarms, normal_count),
        "normal_assessed_false_alarm_rate": _ratio(normal_false_alarms, normal_assessed),
        "normal_coverage": _ratio(normal_assessed, normal_count),
        "withheld_count": withheld, "withheld_rate": _ratio(withheld, len(rows)),
        "coverage": _ratio(len(rows) - withheld, len(rows)),
        "matched_event_count": tp,
        "primary_boundary_error_count": sum(len(score["primary_boundary_errors_ms"]) for score in scores),
        "median_primary_boundary_error_ms": _median([value for score in scores for value in score["primary_boundary_errors_ms"]]),
        "median_deletion_processed_boundary_error_ms": _median([value for score in scores for value in score["deletion_processed_boundary_errors_ms"]]),
        "median_repeat_reference_source_boundary_error_ms": _median([value for score in scores for value in score["repeat_reference_source_boundary_errors_ms"]]),
        "median_rtf": _median([row["rtf"] for row in rows]),
        "maximum_rtf": max((row["rtf"] for row in rows), default=None),
    }


def aggregate_trials(rows: list[dict]) -> dict:
    """Summarize full-denominator results overall and in predeclared strata.

    ``normal_false_alarm_rate`` is observed false alarms / all normal trials.
    Withheld trials are not called correct; coverage and the assessed-only rate
    are returned beside it. Event recall includes every withheld truth event.
    Boundary medians describe matched events only, alongside match counts.
    """
    scored = _scored_rows(rows)
    summary = {"schema_version": 1, "iou_threshold": IOU_THRESHOLD, "overall": _summary(scored)}
    for key in ("source_kind", "condition", "profile"):
        summary[f"by_{key}"] = {
            label: _summary([row for row in scored if row[key] == label])
            for label in sorted({row[key] for row in scored})
        }
    return summary


def paired_group_bootstrap(candidate_rows: list[dict], baseline_rows: list[dict], *,
                           resamples: int = 2000, seed: int = 20261013) -> dict:
    """Paired candidate-minus-baseline percentile intervals by original source.

    A drawn source retains all of its conditions/trials. Sources with different
    trial counts keep those counts; this estimates the corpus trial-weighted
    metric, not an independent-trial confidence interval. Undefined bootstrap
    metrics are excluded and their counts are explicitly reported.

    Comparison-only baselines that do not localize events are not comparable
    in this API. Their anomaly flags require a separate shared-task evaluation;
    a missing localization feature must not be presented as zero recall.
    """
    if isinstance(resamples, bool) or not isinstance(resamples, Integral) or not 1 <= resamples <= 100000:
        raise ValueError("resamples must be an integer between 1 and 100000")
    if isinstance(seed, bool) or not isinstance(seed, Integral) or not 0 <= seed < 2**64:
        raise ValueError("seed must be an integer between 0 and 2**64 - 1")
    candidate = _scored_rows(candidate_rows)
    baseline = _scored_rows(baseline_rows)
    for row in candidate + baseline:
        output = row["result"]
        content_status = output.get("content_preservation_status", "")
        explicitly_unassessed = isinstance(content_status, str) and content_status.startswith("not_assessed_by_")
        comparison_only = output.get("events") is None and any(
            key in output for key in ("anomaly_candidate", "measurement_available"))
        if explicitly_unassessed or comparison_only:
            raise ValueError("event bootstrap requires localization-capable methods in both arms; use a shared anomaly-task evaluation for comparison-only baselines")
    baseline_by_id = {row["trial_id"]: row for row in baseline}
    if {row["trial_id"] for row in candidate} != set(baseline_by_id):
        raise ValueError("candidate and baseline must contain exactly the same trial IDs")
    for row in candidate:
        other = baseline_by_id[row["trial_id"]]
        for key in ("source_group", "source_kind", "condition", "profile", "expected_events", "input_duration_ms"):
            if row[key] != other[key]:
                raise ValueError(f"paired trial {row['trial_id']} differs in {key}")
    groups = sorted({row["source_group"] for row in candidate})
    metrics = ("event_recall", "normal_false_alarm_rate", "normal_coverage")
    candidate_all, baseline_all = _summary(candidate), _summary(baseline)
    sampled = {metric: [] for metric in metrics}
    if groups:
        # Precompute source-level sufficient counts: keep dependent trials together
        # and avoid expanding the whole corpus for every bootstrap replicate.
        count_keys = ("true_positive_events", "expected_event_count", "normal_false_alarm_count", "normal_trial_count", "normal_assessed_count")
        counts = []
        for rows in (candidate, baseline):
            grouped_summaries = [_summary([row for row in rows if row["source_group"] == group])
                                 for group in groups]
            counts.append(np.array([
                [summary[key] for key in count_keys] for summary in grouped_summaries
            ], dtype=np.int64))
        rng = np.random.default_rng(int(seed))
        for _ in range(int(resamples)):
            draw = rng.integers(0, len(groups), size=len(groups))
            selected = [values[draw].sum(axis=0) for values in counts]
            for metric, numerator_index, denominator_index in (
                ("event_recall", 0, 1), ("normal_false_alarm_rate", 2, 3), ("normal_coverage", 4, 3)
            ):
                first = _ratio(selected[0][numerator_index], selected[0][denominator_index])
                second = _ratio(selected[1][numerator_index], selected[1][denominator_index])
                if first is not None and second is not None:
                    sampled[metric].append(first - second)
    intervals = {}
    for metric in metrics:
        values = sampled[metric]
        first, second = candidate_all[metric], baseline_all[metric]
        intervals[metric] = {
            "candidate": first, "baseline": second,
            "difference": first - second if first is not None and second is not None else None,
            "ci95": np.quantile(values, [.025, .975]).tolist() if values else None,
            "valid_resamples": len(values), "undefined_resamples": int(resamples) - len(values),
        }
    return {
        "schema_version": 1, "unit": "original_source_group", "paired": True,
        "difference_direction": "candidate_minus_baseline", "source_group_count": len(groups),
        "resamples": int(resamples), "seed": int(seed), "method": "paired_source_cluster_percentile",
        "descriptive_only": True,
        "limitations": ["Transformed trials from one source are not independent samples.",
                        "Small corpus intervals do not establish population or real-world performance."],
        "metrics": intervals,
    }
