"""Opt-in exhaustive global-context exact quantized event candidate (v9)."""

from copy import deepcopy
import math
from pathlib import Path

import numpy as np

from . import compound_event_engine
from .analysis_scope import analysis_scope
from .audio import WavAudio, read_wav
from .compound_event_engine import _retained_summary
from .compound_event_proof import FIR_RADIUS, GRID, _edited_source
from .compound_gain import _render, quantization_bound
from .engine import RATE, EngineConfig, EngineConfigError, _corr
from .global_context_proof import MIN_CONTEXT, prove_event
from .profiles import prepare_analysis


ENGINE = "local_content_alignment_v9"
METHOD = "global_context_quantized_event_forward_proof"
ELIGIBLE_REASONS = frozenset({
    "raw_landmark_unexplained_local_residual", "raw_landmark_unexplained_local_change",
    "insertion_not_supported_as_repetition", "raw_landmark_event_bracket_not_supported",
    "raw_landmark_insufficient_unique_anchors",
    "non_silent_file_edge_change",
    "raw_landmark_unexplained_signal_change",
})


@analysis_scope
def analyze_buffers_with_trace(reference: WavAudio, processed: WavAudio,
                               config: EngineConfig | None = None) -> tuple[dict, dict]:
    settings = config if config is not None else EngineConfig()
    if not isinstance(settings, EngineConfig) or settings.profile != "basic":
        raise EngineConfigError("The global-context candidate supports basic only.")
    baseline, old_trace = compound_event_engine.analyze_buffers_with_trace(reference, processed, settings)
    result = deepcopy(baseline)
    result["engine"], result["analysis"]["method"] = ENGINE, METHOD
    result["limitations"].append(
        "v8 preserved; new rescue exhaustively checks every fixed quantized single delete or canonical "
        "adjacent full-copy geometry, including endpoint alternatives, at 1ms grid and 200-2000ms. "
        "Necessary common-gain quantization envelopes only prune; every supported survivor needs the "
        "unchanged bounded gain solver and independent exact all-output rendering. Narrow fixed "
        "PCM16 gain/SRC16-to-8/leading-zero explanation, not arbitrary history, provenance or full-band approval.")
    trace = {"schema_version": 1, "engine": ENGINE, "analysis_engine": ENGINE, "method": METHOD,
             "reference_sha256": reference.sha256, "processed_sha256": processed.sha256,
             "baseline_status": baseline["status"], "baseline_reason_code": baseline["reason_code"],
             "proof_path": "preserved_v8_result", "global_context_attempted": False,
             "global_context_proved": False, "inherited_v8_trace": deepcopy(old_trace),
             "result_status": result["status"], "reason_code": result["reason_code"]}
    if (baseline["status"] != "withheld" or baseline["reason_code"] not in ELIGIBLE_REASONS
            or not settings.allow_gain or not settings.allow_resampling
            or reference.sample_rate_hz != 16000 or processed.sample_rate_hz != RATE
            or len(reference.samples) % 2):
        return result, trace
    trace["global_context_attempted"] = True

    def failure(reason):
        trace["global_context_failure"] = reason
        return result, trace

    proof, proof_trace = prove_event(reference.samples, processed.samples, math.floor(settings.max_delay_ms * 8))
    trace["event_proof_trace"] = proof_trace
    if proof is None:
        return failure(proof_trace["reason_code"])
    if type(proof) is not dict or not proof_trace.get("search_complete") or not proof_trace.get("every_supported_geometry_checked"):
        return failure("global_context_whole_output_exact_proof_failed")
    point, length, kind, delay = (proof.get(key) for key in ("point", "length", "kind", "delay"))
    gain, rendered = proof.get("gain"), proof.get("rendered")
    x, y = prepare_analysis(reference), processed.samples
    if (any(type(value) is not int for value in (point, length, delay))
            or kind not in {"delete", "repeat"} or point % GRID or length % GRID
            or not 1600 <= length <= 16000 or delay < 0 or delay / 8 > settings.max_delay_ms
            or np.any(y[:delay]) or type(gain) not in (float, int) or not math.isfinite(gain) or gain <= 0
            or not isinstance(rendered, np.ndarray) or rendered.ndim != 1
            or not np.array_equal(rendered, y[delay:])):
        return failure("global_context_whole_output_exact_proof_failed")
    right = point + length if kind == "delete" else point
    if (point < MIN_CONTEXT + FIR_RADIUS or right > len(x) - MIN_CONTEXT - FIR_RADIUS
            or (kind == "repeat" and point - length < 0)):
        return failure("global_context_whole_output_exact_proof_failed")
    reconstructed = _render(_edited_source(reference.samples, point, length, kind), float(gain))
    if reconstructed is None or not np.array_equal(reconstructed, y[delay:]):
        return failure("global_context_whole_output_exact_proof_failed")
    after = delay + (-length if kind == "delete" else length)
    spans = [(0, point, delay), (right, len(x), after)]
    safe = [(0, point - FIR_RADIUS, delay), (right + FIR_RADIUS, len(x), after)]
    summary = _retained_summary(x, y, safe, gain)
    if summary is None:
        return failure("global_context_informative_retained_proof_failed")
    # Three measured summaries on each retained side, not fabricated landmarks.
    correlations = []
    floor = quantization_bound() / math.sqrt(1 - .90 ** 2)
    for first, last, offset in safe:
        width = min(MIN_CONTEXT, last - first)
        measured = []
        starts = sorted(set(range(first, last - width + 1, 160)) | {last - width})
        for start in starts:
            a, b = gain * x[start:start + width], y[start + offset:start + offset + width]
            if float(np.std(a)) > floor:
                correlation = _corr(a, b)
                if correlation < .90:
                    return failure("global_context_informative_retained_proof_failed")
                measured.append((start, correlation))
        if len(measured) < 3:
            return failure("global_context_informative_side_context_missing")
        # Three distinct observed windows, not globally unique landmarks.
        selected = [measured[0], measured[len(measured) // 2], measured[-1]]
        correlations.append([value for _, value in selected])
    left_a, right_a = gain * x[point - FIR_RADIUS - MIN_CONTEXT:point - FIR_RADIUS], gain * x[right + FIR_RADIUS:right + FIR_RADIUS + MIN_CONTEXT]
    left_b = y[point + delay - FIR_RADIUS - MIN_CONTEXT:point + delay - FIR_RADIUS]
    right_b = y[right + after + FIR_RADIUS:right + after + FIR_RADIUS + MIN_CONTEXT]
    boundary_correlation = (_corr(left_a, left_b) + _corr(right_a, right_b)) / 2
    if boundary_correlation < .90:
        return failure("global_context_boundary_reproof_failed")
    evidence = {"boundary_correlation": boundary_correlation,
                "offset_before_ms": delay / 8, "offset_after_ms": after / 8}
    if kind == "delete":
        event = {"type": "delete", "reference_interval_ms": [point / 8, (point + length) / 8],
                 "processed_boundary_ms": (point + delay) / 8, "evidence": evidence}
    else:
        first = point - length
        interior = slice(first + FIR_RADIUS, point - FIR_RADIUS)
        copy_a = y[first + delay + FIR_RADIUS:point + delay - FIR_RADIUS]
        copy_b = y[point + delay + FIR_RADIUS:point + delay + length - FIR_RADIUS]
        source_correlation = min(_corr(gain * x[interior], copy_a), _corr(gain * x[interior], copy_b))
        adjacent = _corr(copy_a, copy_b)
        if float(np.std(gain * x[interior])) <= floor or source_correlation < .90 or adjacent < .90:
            return failure("global_context_copy_interior_reproof_failed")
        event = {"type": "repeat", "reference_source_interval_ms": [first / 8, point / 8],
                 "processed_added_interval_ms": [(point + delay) / 8, (point + delay + length) / 8],
                 "copy_interval_convention": "canonical_later_adjacent_copy_not_edit_provenance",
                 "evidence": {**evidence, "copy_correlation": source_correlation,
                              "adjacent_copy_correlation": adjacent}}
    nrmse = summary["matched_normalized_rmse"]
    result.update(status="analyzed", reason_code=None, content_preservation_status="defect_candidates",
                  events=[event], diagnostics={"gain_estimate": gain, "applied_gain": gain,
                  "matched_normalized_rmse": nrmse, "matched_analysis_samples": summary["matched_analysis_samples"],
                  "anchor_run_count": 2, "minimum_local_correlation": summary["minimum_local_correlation"],
                  "normalized_path_cost": nrmse}, alignment_segments=[])
    for (first, last, offset), values in zip(spans, correlations, strict=True):
        result["alignment_segments"].append({"reference_interval_ms": [first / 8, last / 8],
            "processed_offset_ms": offset / 8, "anchor_correlations": values})
    trace.update(proof_path="global_context_event_exact_forward", global_context_proved=True,
                 result_status="analyzed", reason_code=None, event_kind=kind,
                 every_output_sample_exact=True, exact_output_sample_count=len(rendered),
                 leading_zero_sample_count=delay, gain_witness=gain,
                 gain_is_unique_or_processing_provenance=False,
                 correspondence_summary_is_unique_landmark_certificate=False,
                 informative_retained_summary=summary, boundary_correlation=boundary_correlation,
                 exact_proof_includes_fir_boundaries_and_quiet_samples=True)
    return result, trace


def analyze_buffers(reference: WavAudio, processed: WavAudio, config: EngineConfig | None = None) -> dict:
    return analyze_buffers_with_trace(reference, processed, config)[0]


def analyze_wavs_with_trace(reference_path: str | Path, processed_path: str | Path,
                            config: EngineConfig | None = None) -> tuple[dict, dict]:
    return analyze_buffers_with_trace(read_wav(reference_path), read_wav(processed_path), config)
