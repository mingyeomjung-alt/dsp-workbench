"""Explicit native DSP-model comparison CLI; local files, no replacement."""

import argparse
import json
from pathlib import Path
import re
import sys

from .model_check import ModelCheckError, load_model_plan, run_model_check
from .model_contract import load_model_result, validate_model_result
from .model_reporting import write_model_html
from .result_contract import ResultContractError


_ENGINE = "declared_transform_check_v1"
_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}\Z")


def _emit(value: dict) -> None:
    sys.stdout.write(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n")


def _error(code: object, *, exit_code: int) -> dict:
    safe_code = code if type(code) is str and _CODE.fullmatch(code) else "internal_model_check_error"
    return {
        "schema_version": 1, "engine": _ENGINE, "status": "error",
        "gate_state": "blocked", "exit_code": exit_code, "reason_code": safe_code,
        "contract_valid": False,
        "complete_audio_approval": False, "commercial_performance_validated": False,
        "network_used": False, "fault_provenance_confirmed": False,
    }


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="audio-transform-check",
        description="Compare a caller-declared native DSP model's expected PCM16 output with an actual file.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    compare = commands.add_parser("compare", help="Run an explicit bounded model into a new private snapshot directory.")
    compare.add_argument("--reference", type=Path, required=True, help="Model input PCM16 mono WAV.")
    compare.add_argument("--processed", type=Path, required=True, help="Actual processed PCM16 mono WAV.")
    compare.add_argument("--plan", type=Path, required=True, help="Version-1 model plan; no executable commands.")
    compare.add_argument("--output-dir", type=Path, required=True, help="New output directory; never replaced.")
    compare.add_argument("--engine", choices=tuple(f"v{index}" for index in range(1, 10)), default="v1",
                         help="v1 baseline (default); v2–v9 are explicitly selected research candidates.")
    report = commands.add_parser("report", help="Write a new standalone HTML report using stored JSON only.")
    report.add_argument("--input", type=Path, required=True)
    report.add_argument("--output", type=Path, required=True)
    check = commands.add_parser("check", help="Validate stored model JSON and return its fail-closed summary.")
    check.add_argument("--input", type=Path, required=True)
    return parser


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    failure_exit = 2 if args.command == "check" else 3
    try:
        if args.command == "compare":
            plan = load_model_plan(args.plan)
            result = run_model_check(args.reference, args.processed, plan["models"], args.output_dir,
                                     **({"engine": args.engine} if args.engine != "v1" else {}))
            validate_model_result(result)
            _emit(result)
            return result["summary"]["exit_code"]
        if args.command == "report":
            if args.input.resolve() == args.output.resolve() or args.output.exists():
                raise FileExistsError()
            result = load_model_result(args.input)
            write_model_html(result, args.output)
            _emit({
                "schema_version": 1, "engine": _ENGINE, "status": "generated_model_html",
                "complete_audio_approval": False, "commercial_performance_validated": False,
                "network_used": False, "fault_provenance_confirmed": False,
            })
            return 0
        result = load_model_result(args.input)
        summary = {
            "schema_version": 1, "engine": _ENGINE, "status": "checked_saved_model_result",
            **result["summary"], "contract_valid": True,
            "complete_audio_approval": False, "commercial_performance_validated": False,
            "network_used": False, "fault_provenance_confirmed": False,
        }
        _emit(summary)
        return summary["exit_code"]
    except (ModelCheckError, ResultContractError) as exc:
        code = exc.code
    except FileExistsError:
        code = "output_exists"
    except (OSError, RuntimeError):
        code = "model_file_error"
    except Exception:
        # No exception messages, paths, raw inputs, or traceback reach stdout.
        code = "internal_model_check_error"
    _emit(_error(code, exit_code=failure_exit))
    return failure_exit


if __name__ == "__main__":
    raise SystemExit(main())
