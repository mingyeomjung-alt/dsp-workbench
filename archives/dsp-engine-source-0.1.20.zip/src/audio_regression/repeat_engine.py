"""Opt-in full-copy feasibility proof; v1--v5 and their results stay intact.

Raw NCC proposes competitors, never decides uniqueness by a peak margin. Each
source competitor is checked against complete local waveform and centered
energy residual bounds. The latter makes the exhaustive >=.90 NCC prefilter
sound for this deliberately narrow evidence class. Budget exhaustion withholds.
"""

from copy import deepcopy
import math
from pathlib import Path

import numpy as np
from scipy.signal import correlate

from . import canonical_engine, instrument_engine as raw
from .analysis_scope import analysis_scope
from .audio import WavAudio, read_wav
from .engine import RATE, EngineConfig, EngineConfigError, _corr, _silent_original_edge
from .profiles import prepare_analysis

ENGINE = "local_content_alignment_v6"
METHOD = "full_copy_feasibility_with_global_source_exclusion"
MAX_PROOFS = 1000
POSITION_TOLERANCE = 160  # Existing 20 ms identifiability convention, not provenance.


class _BudgetExceeded(Exception):
    pass


class _ProofBudget:
    def __init__(self):
        self.used = 0

    def take(self):
        if self.used >= MAX_PROOFS:
            raise _BudgetExceeded
        self.used += 1


def _candidate_positions(approximate: int, length: int, total: int):
    # Fill the gap between the former two 120 ms neighborhoods as well.
    return range(max(0, approximate - length - 960), min(total - 2 * length, approximate + 960) + 1, 8)


def _copy_fit(a: np.ndarray, b: np.ndarray, allow_gain: bool):
    if len(a) != len(b) or len(a) < 1600 or min(float(np.std(a)), float(np.std(b))) < 1e-6:
        return None
    correlation = _corr(a, b)
    if correlation < .90:
        return None
    gain = float(np.dot(a, b) / max(float(np.dot(a, a)), 1e-16))
    applied = gain if allow_gain else 1.0
    if not math.isfinite(gain) or gain <= 0:
        return None
    a0, b0 = a - np.mean(a), b - np.mean(b)
    centered_nrmse = float(np.linalg.norm(b0 - applied * a0) / max(np.linalg.norm(applied * a0), 1e-16))
    if centered_nrmse > .08 or not raw._window_consistent(a, b, applied):
        return None
    return {"correlation": correlation, "gain": gain, "centered_nrmse": centered_nrmse}


def _source_unique(x: np.ndarray, copied: np.ndarray, source: int,
                   allow_gain: bool, budget: _ProofBudget) -> bool:
    """All sample positions, not just peaks or a top-k shortlist.

Centered NRMSE <=.08 with positive gain implies NCC >=sqrt(1-.08**2).
Thus .90 (with roundoff slack) cannot exclude an admissible rival. Identical
and gain-equivalent distant sources are rejected even with unique context.
"""
    length = len(copied)
    centered = copied - np.mean(copied)
    target = x - np.mean(x)  # NCC invariant; avoid cancellation from global DC.
    products = correlate(target, centered, mode="valid", method="fft")
    sums = np.concatenate(([0.0], np.cumsum(target)))
    squares = np.concatenate(([0.0], np.cumsum(target * target)))
    total = sums[length:] - sums[:-length]
    variance = np.maximum(0.0, squares[length:] - squares[:-length] - total * total / length)
    error_bound = 64 * np.finfo(float).eps * len(target) * max(float(squares[-1]), 1e-16)
    if np.any(variance <= 16 * error_bound):
        # Do not certify a global exclusion from ill-conditioned rolling NCC.
        return False
    template_energy = float(np.dot(centered, centered))
    denominator_lower = np.sqrt(np.maximum(0.0, variance - error_bound) * template_energy)
    product_error = 64 * np.finfo(float).eps * len(target) * math.sqrt(float(squares[-1]) * template_energy)
    # Retain candidates using an upper NCC estimate, rather than potentially
    # underestimating a rival from FFT and cumulative-sum roundoff.
    upper_scores = np.divide(products + product_error, denominator_lower,
                             out=np.ones_like(products), where=denominator_lower > 1e-16)
    rivals = np.flatnonzero(upper_scores >= .90 - 1e-10)
    for position in rivals:
        if abs(int(position) - source) <= POSITION_TOLERANCE:
            continue
        budget.take()
        if _copy_fit(x[position:position + length], copied, allow_gain) is not None:
            return False
    return True


def _prove_copy_candidate(x, y, first, length, before, after, groups, settings, budget):
    source = first - before
    start, end = max(0, -before), min(len(x), len(y) - after)
    divider = source + length
    if source < start or divider >= end or first < 0 or first + 2 * length > len(y):
        return None
    copy_a, copy_b = y[first:first + length], y[first + length:first + 2 * length]
    # The fixed >=.90 pair condition is a cheap proposal filter. The budget is
    # for full proofs, not for inspecting every clearly unrelated grid position.
    if _corr(copy_a, copy_b) < .90:
        return None
    budget.take()
    pair = _copy_fit(copy_a, copy_b, False)
    if pair is None:
        return None
    fits = [_copy_fit(x[source:divider], copied, settings.allow_gain) for copied in (copy_a, copy_b)]
    if any(fit is None for fit in fits):
        return None
    spans = [(start, divider, before), (divider, end, after)]
    if divider - 480 < start or divider + 480 > end:
        return None
    boundary_correlation = (_corr(x[divider - 480:divider], y[divider + before - 480:divider + before])
                            + _corr(x[divider:divider + 480], y[divider + after:divider + after + 480])) / 2
    if boundary_correlation < .90:
        return None
    proved_groups = []
    for group, (left, right, offset) in zip(groups, spans, strict=True):
        points = [p for p in group["points"] if left <= p["reference_start"]
                  and p["reference_start"] + p["width"] <= right]
        if len(points) < 3 or any(abs(p["offset"] - offset) > 24 for p in points):
            return None
        for p in points:
            a = x[p["reference_start"]:p["reference_start"] + p["width"]]
            b = y[p["reference_start"] + offset:p["reference_start"] + offset + p["width"]]
            gain = float(np.dot(a, b) / max(float(np.dot(a, a)), 1e-16))
            if gain <= 0 or not raw._window_consistent(a, b, gain if settings.allow_gain else 1.0):
                return None
        proved_groups.append({**group, "points": points})
    diagnostics, reason = raw._prove_matches(x, y, spans, settings)
    if reason or not raw._window_consistent(x[source:divider], copy_b, diagnostics["applied_gain"]):
        return None
    for copied in (copy_a, copy_b):
        if not _source_unique(x, copied, source, settings.allow_gain, budget):
            return None
    return {"source": source, "first": first, "added": first + length,
            "spans": spans, "groups": proved_groups, "diagnostics": diagnostics,
            "correlation": min(fit["correlation"] for fit in fits),
            "boundary_correlation": boundary_correlation,
            "adjacent_copy_correlation": pair["correlation"],
            "centered_nrmse": max(fit["centered_nrmse"] for fit in fits)}


@analysis_scope
def analyze_buffers_with_trace(reference: WavAudio, processed: WavAudio,
                               config: EngineConfig | None = None) -> tuple[dict, dict]:
    settings = config if config is not None else EngineConfig()
    if not isinstance(settings, EngineConfig) or settings.profile != "basic":
        raise EngineConfigError("The full-copy candidate supports basic only.")
    baseline, old_trace = canonical_engine.analyze_buffers_with_trace(reference, processed, settings)
    result = deepcopy(baseline)
    result["engine"] = ENGINE
    result["analysis"]["method"] = METHOD
    result["limitations"].append("v5 preserved; eligible repeats require complete-copy centered residual proof, "
        "global feasible-source exclusion, unique retained context and bounded exhaustive search. "
        "A narrow diagnostic proof, not general music validation or edit provenance.")
    trace = {"schema_version": 1, "engine": ENGINE, "analysis_engine": ENGINE, "method": METHOD,
             "reference_sha256": reference.sha256, "processed_sha256": processed.sha256,
             "baseline_status": baseline["status"], "baseline_reason_code": baseline["reason_code"],
             "proof_path": "preserved_v5_result", "repeat_attempted": False,
             "candidate_proofs_attempted": 0, "feasible_candidate_count": 0,
             "feasible_geometry_cluster_count": 0,
             "proof_budget": MAX_PROOFS, "global_source_search": "every_sample_ncc_prefilter_then_full_proof",
             "centered_residual_ceiling": .08, "inherited_v5_trace": deepcopy(old_trace),
             "result_status": result["status"], "reason_code": result["reason_code"]}
    if baseline["status"] != "withheld" or baseline["reason_code"] != "insertion_not_supported_as_repetition":
        return result, trace
    trace.update(repeat_attempted=True, proof_path="full_copy_feasibility")
    x, y = prepare_analysis(reference), prepare_analysis(processed)
    points, _ = raw._landmarks(x, y, math.ceil(settings.max_delay_ms * 8) + 16000, settings.allow_gain)
    groups = raw._groups(points)
    if (len(groups) != 2 or any(len(g["points"]) < 3 for g in groups)
            or any(max(p["offset"] for p in g["points"]) - min(p["offset"] for p in g["points"]) > 24 for g in groups)):
        return result, trace
    before, after = groups[0]["offset"], groups[1]["offset"]
    length = after - before
    if not 1600 <= length <= 16000 or abs(before / 8) > settings.max_delay_ms + 3:
        return result, trace
    start, end = max(0, -before), min(len(x), len(y) - after)
    if ((start and not _silent_original_edge(reference, 0, start))
            or (before > 0 and not _silent_original_edge(processed, 0, before))
            or (end < len(x) and not _silent_original_edge(reference, end, len(x)))
            or (end + after < len(y) and not _silent_original_edge(processed, end + after, len(y)))):
        return result, trace
    left, right = groups[0]["points"][-1], groups[1]["points"][0]
    lower = left["reference_start"] + left["width"] - 80
    upper = right["reference_start"] + 80 + length
    if upper < lower or upper - lower > 19200:
        return result, trace
    boundary = raw._boundary(x, y, lower, upper, before, after, "repeat")
    if boundary is None or boundary[1] < .90:
        return result, trace
    budget, feasible = _ProofBudget(), []
    try:
        for first in _candidate_positions(boundary[0] + before, length, len(y)):
            proof = _prove_copy_candidate(x, y, first, length, before, after, groups, settings, budget)
            if proof is not None:
                feasible.append(proof)
                if max(p["source"] for p in feasible) - min(p["source"] for p in feasible) > POSITION_TOLERANCE:
                    trace.update(candidate_proofs_attempted=budget.used, feasible_candidate_count=len(feasible),
                                 feasible_geometry_cluster_count=2)
                    return raw._fail(result, trace, "repeat_feasibility_ambiguous_geometry")
    except _BudgetExceeded:
        trace.update(candidate_proofs_attempted=budget.used, feasible_candidate_count=len(feasible),
                     feasible_geometry_cluster_count=int(bool(feasible)))
        return raw._fail(result, trace, "repeat_feasibility_proof_budget_exceeded")
    trace.update(candidate_proofs_attempted=budget.used, feasible_candidate_count=len(feasible),
                 feasible_geometry_cluster_count=int(bool(feasible)))
    if not feasible:
        return result, trace
    # Selection happens only after exhaustive feasibility and uniqueness proof.
    best = max(feasible, key=lambda p: (p["adjacent_copy_correlation"], p["correlation"], -p["centered_nrmse"]))
    source, added = best["source"], best["added"]
    evidence = {"boundary_correlation": best["boundary_correlation"], "offset_before_ms": before / 8,
                "offset_after_ms": after / 8, "copy_correlation": best["correlation"],
                "adjacent_copy_correlation": best["adjacent_copy_correlation"]}
    event = {"type": "repeat", "reference_source_interval_ms": [source / 8, (source + length) / 8],
             "processed_added_interval_ms": [added / 8, (added + length) / 8],
             "copy_interval_convention": "canonical_later_adjacent_copy_not_edit_provenance", "evidence": evidence}
    result.update(status="analyzed", reason_code=None, content_preservation_status="defect_candidates",
                  events=[event], diagnostics=best["diagnostics"], alignment_segments=[])
    for group, (first, last, offset) in zip(best["groups"], best["spans"], strict=True):
        pts = group["points"]
        selected = [pts[0], pts[len(pts) // 2], pts[-1]]
        result["alignment_segments"].append({"reference_interval_ms": [first / 8, last / 8],
            "processed_offset_ms": offset / 8, "anchor_correlations": [p["correlation"] for p in selected]})
    trace.update(result_status="analyzed", reason_code=None, centered_copy_nrmse=best["centered_nrmse"],
                 canonical_anchor_counts=[len(g["points"]) for g in best["groups"]])
    return result, trace


def analyze_buffers(reference: WavAudio, processed: WavAudio, config: EngineConfig | None = None) -> dict:
    return analyze_buffers_with_trace(reference, processed, config)[0]


def analyze_wavs_with_trace(reference_path: str | Path, processed_path: str | Path,
                            config: EngineConfig | None = None) -> tuple[dict, dict]:
    return analyze_buffers_with_trace(read_wav(reference_path), read_wav(processed_path), config)
