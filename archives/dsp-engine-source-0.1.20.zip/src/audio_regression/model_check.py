"""Explicit, fixed-model reference projection without changing any detector.

The original alone is transformed. Expected and observed PCM samples are
compared exactly; an empty temporal candidate list cannot clear a residual.
Fresh snapshots bind the child analysis to expected, not original, audio.
"""
from __future__ import annotations

from copy import deepcopy
import hashlib
import json
import os
from pathlib import Path
import re
import stat

import numpy as np

from . import api
from .artifact_integrity import ArtifactVerificationError, _identity, _read_regular
from .audio import AudioInputError, MAX_FILE_BYTES, decode_wav
from .check_policy import check_result
from .model_contract import derive_model_summary, validate_model_result
from .pipeline_runner import (
    PipelineRunError, _absolute_path, _is_link,
    _new_bytes, _new_json, _normal_parents,
)
from .result_contract import ResultContractError, validate_analysis_result
from .transform_models import ModelTransformError, render_models, validate_model_plan, validate_models


MAX_MODEL_PLAN_BYTES = 65_536
_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}\Z")
_ENGINES = frozenset(f"v{i}" for i in range(1, 10))


class ModelCheckError(ValueError):
    """A local rejection; no source text or local path is exposed."""
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__("Declared model check could not complete: " + code + ".")


def _code(error: Exception, fallback: str) -> str:
    if isinstance(error, (ModelCheckError, ModelTransformError, AudioInputError,
                          PipelineRunError, ResultContractError)):
        code = getattr(error, "code", None)
        if type(code) is str and _CODE.fullmatch(code):
            return code
    return fallback


def _unique_object(pairs):
    value = {}
    for key, item in pairs:
        if key in value:
            raise ModelCheckError("duplicate_json_key")
        value[key] = item
    return value


def _invalid_constant(_):
    raise ModelCheckError("non_finite_model_plan")


def load_model_plan(path: str | Path) -> dict:
    """Read a strict bounded plan, never an executable or a remote resource."""
    try:
        with Path(path).open("rb") as stream:
            raw = stream.read(MAX_MODEL_PLAN_BYTES + 1)
    except (OSError, TypeError, ValueError):
        raise ModelCheckError("model_plan_read_error") from None
    if len(raw) > MAX_MODEL_PLAN_BYTES:
        raise ModelCheckError("model_plan_too_large")
    try:
        value = json.loads(raw.decode("utf-8"), object_pairs_hook=_unique_object,
                           parse_constant=_invalid_constant)
        return validate_model_plan(value)
    except ModelCheckError:
        raise
    except ModelTransformError as error:
        raise ModelCheckError(_code(error, "invalid_model_plan")) from None
    except (UnicodeError, ValueError, TypeError, RecursionError, OverflowError):
        raise ModelCheckError("invalid_model_plan_json") from None


def _checked_input_bytes(named: Path) -> bytes:
    """Read one stable regular file, rejecting observable aliases and edits.

    Named and descriptor identities are checked around the bounded read. This
    is not a lock or an atomic filesystem snapshot; later edits remain outside
    this synchronous observation window.
    """
    try:
        _normal_parents(named)
        info = named.lstat()
        if _is_link(info) or not stat.S_ISREG(info.st_mode):
            raise ModelCheckError("invalid_model_input_file")
        _, _, raw, identity = _read_regular(named, MAX_FILE_BYTES, collect=True)
        _normal_parents(named)
        if identity != _identity(info):
            raise ModelCheckError("model_input_changed_during_read")
    except ModelCheckError:
        raise
    except ArtifactVerificationError as error:
        code = {
            "unsafe_artifact_path": "invalid_model_input_file",
            "artifact_changed_during_verification": "model_input_changed_during_read",
            "artifact_file_too_large": "file_too_large",
        }.get(error.code, "file_read_error")
        raise ModelCheckError(code) from None
    except PipelineRunError as error:
        raise ModelCheckError(_code(error, "unsafe_model_input_path")) from None
    except (OSError, ValueError):
        raise ModelCheckError("file_read_error") from None
    return raw


def _input(path: str | Path):
    named = _absolute_path(path)
    raw = _checked_input_bytes(named)
    return named, raw, decode_wav(raw)


def _comparison(expected, processed) -> dict:
    if expected.samples.size != processed.samples.size:
        return {"exact_pcm16_match": False, "unequal_sample_count": None,
                "maximum_abs_error_pcm16": None}
    # Exact decoded PCM integers, independent of RIFF metadata or 8kHz features.
    left = (expected.samples * 32768).astype(np.int32)
    right = (processed.samples * 32768).astype(np.int32)
    residual = np.abs(left - right)
    count = int(np.count_nonzero(residual))
    return {"exact_pcm16_match": count == 0, "unequal_sample_count": count,
            "maximum_abs_error_pcm16": int(residual.max())}


def run_model_check(reference: str | Path, processed: str | Path,
                    models: list[dict], output_dir: str | Path, *, engine: str = "v1") -> dict:
    """Check a declared same-rate, same-count forward model in a fresh folder.

    A model match is narrow compatibility, not full audio approval or original
    content recovery. Child coordinates refer to expected and observed audio.
    Input changes and output failures never become an approved stored result.
    Partial artifacts remain after a started run fails; there is no cleanup,
    retry, source modification, normalizer, learned fitting or executable plan.
    """
    started = False
    output = None
    try:
        if type(engine) is not str or engine not in _ENGINES:
            raise ModelCheckError("invalid_engine")
        normalized = validate_models(models)
        source_path, source_raw, source_audio = _input(reference)
        processed_path, processed_raw, processed_audio = _input(processed)
        if source_audio.sample_rate_hz != processed_audio.sample_rate_hz:
            raise ModelCheckError("unsupported_model_rate_pair")
        output = _absolute_path(output_dir)
        if os.path.lexists(output):
            raise ModelCheckError("output_directory_exists")
        _normal_parents(output)
        # Render before creating output so an invalid or overflowing model
        # leaves no started run. This is NOT the observed audio generator.
        expected_raw = render_models(source_audio, normalized)
        expected_audio = decode_wav(expected_raw)
        if (expected_audio.sample_rate_hz != source_audio.sample_rate_hz
                or expected_audio.samples.size != source_audio.samples.size):
            raise ModelCheckError("inconsistent_model_output")
        comparison = _comparison(expected_audio, processed_audio)
        output.parent.mkdir(parents=True, exist_ok=True)
        _normal_parents(output)
        output.mkdir(exist_ok=False)
        started = True
        plan = {"schema_version": 1, "models": normalized}
        _new_json(output / "manifest_started.json", {
            "schema_version": 1, "engine": "declared_transform_check_v1", "status": "started",
            "model_plan": deepcopy(plan), "source": source_audio.metadata(),
            "processed": processed_audio.metadata(), "selected_temporal_engine": engine,
            "network_used": False, "fault_provenance_confirmed": False,
        })
        (output / "input").mkdir()
        (output / "expected").mkdir()
        artifacts = {"source": "input/source.wav", "processed": "input/processed.wav",
                     "expected": "expected/output.wav", "analysis": "analysis.json",
                     "temporal_check": "temporal_check.json",
                     "trace": None if engine == "v1" else "trace.json"}
        for name, raw in (("source", source_raw), ("processed", processed_raw),
                          ("expected", expected_raw)):
            _new_bytes(output / artifacts[name], raw)
        analysis, trace = api.analyze_pair_with_trace(
            output / artifacts["expected"], output / artifacts["processed"],
            engine=engine, profile="basic", allow_gain=False, allow_resampling=False,
            max_delay_ms=1000.0,
        )
        validate_analysis_result(analysis)
        if analysis["status"] == "error":
            raise ModelCheckError("temporal_comparison_error")
        if analysis["engine"] != "local_content_alignment_" + engine:
            raise ModelCheckError("inconsistent_model_analysis_engine")
        temporal = check_result(analysis)
        result = {
            "schema_version": 1, "engine": "declared_transform_check_v1", "status": "completed",
            "model_plan": deepcopy(plan), "source": source_audio.metadata(),
            "expected": expected_audio.metadata(), "processed": processed_audio.metadata(),
            "comparison": comparison, "analysis": analysis, "temporal_check": temporal,
            "summary": derive_model_summary(comparison, temporal), "artifacts": artifacts,
            "complete_audio_approval": False, "commercial_performance_validated": False,
            "network_used": False, "fault_provenance_confirmed": False,
        }
        validate_model_result(result)
        _new_json(output / artifacts["analysis"], analysis)
        _new_json(output / artifacts["temporal_check"], temporal)
        if artifacts["trace"] is not None:
            _new_json(output / artifacts["trace"], trace)
        # Recheck both named inputs and every audio snapshot after analysis.
        # Later external edits are outside this synchronous execution window.
        for path, metadata in ((source_path, result["source"]),
                               (processed_path, result["processed"]),
                               (output / artifacts["source"], result["source"]),
                               (output / artifacts["processed"], result["processed"]),
                               (output / artifacts["expected"], result["expected"])):
            if hashlib.sha256(_checked_input_bytes(path)).hexdigest() != metadata["sha256"]:
                raise ModelCheckError("model_input_or_snapshot_changed_during_run")
        _new_json(output / "model_result.json", result)
        return result
    except Exception as error:
        code = _code(error, "model_check_execution_error")
        if started and output is not None:
            try:
                _new_json(output / "run_failed.json", {
                    "schema_version": 1, "status": "error", "reason_code": code,
                    "gate_state": "blocked", "exit_code": 2,
                })
            except (PipelineRunError, OSError):
                pass  # Durable earlier evidence is retained, never removed.
        raise ModelCheckError(code) from None
