"""Opt-in exact native-PCM explanation for one head or tail content loss.

This path is deliberately separate from internal-edit alignment. It checks
every possible single-deletion geometry, requires one unambiguous endpoint,
and reconstructs the complete retained output. The original v10 behavior is
preserved for exact zero-only endpoint transforms and exact internal edits.
An unexplained eligible shortening is withheld rather than passed to a
legacy path which could ignore a quiet changed endpoint.
"""

from copy import deepcopy
from pathlib import Path

import numpy as np

from . import short_event_engine
from .analysis_scope import analysis_scope
from .audio import WavAudio, read_wav
from .engine import EngineConfig, EngineConfigError, _corr


ENGINE = "local_content_alignment_v11"
METHOD = "endpoint_loss_exact_pcm_forward_proof"
MIN_EVENT_MS = 50
MAX_EVENT_MS = 2000
CONTEXT_MS = 120
_LIMITATION = (
    "v10 is preserved outside the new endpoint-loss scope. The new path "
    "explains one 50-2000ms head or tail deletion at native PCM16 sample "
    "resolution, same sample rate and basic profile, with no declared gain "
    "or resampling. The full retained output must match exactly, the removed "
    "content and one-sided 120ms context must be informative, and every "
    "possible single-deletion boundary must identify the same exact endpoint. "
    "Zero-only edge trimming remains an inherited normal transform. This "
    "signal correspondence does not establish intent, cause, edit provenance "
    "or complete audio approval."
)


def _eligible(reference: WavAudio, processed: WavAudio, settings: EngineConfig) -> bool:
    rate = reference.sample_rate_hz
    difference = len(reference.samples) - len(processed.samples)
    return (
        settings.profile == "basic" and not settings.allow_gain
        and not settings.allow_resampling and rate == processed.sample_rate_hz
        and MIN_EVENT_MS * rate <= difference * 1000 <= MAX_EVENT_MS * rate
    )


def _exact_zero_trim(x: np.ndarray, y: np.ndarray, length: int) -> bool:
    return (
        (not np.any(x[:length]) and np.array_equal(x[length:], y))
        or (not np.any(x[-length:]) and np.array_equal(x[:-length], y))
    )


def _inherited(reference: WavAudio, processed: WavAudio,
               settings: EngineConfig, scope_reason: str) -> tuple[dict, dict]:
    baseline, old_trace = short_event_engine.analyze_buffers_with_trace(reference, processed, settings)
    result = deepcopy(baseline)
    # The native or inherited v10 analysis grid describes the actual path.
    # Only the public opt-in identity is changed; old payloads stay untouched.
    result["engine"] = ENGINE
    result["limitations"].append(_LIMITATION)
    trace = {
        "schema_version": 1, "engine": ENGINE, "analysis_engine": ENGINE,
        "method": METHOD, "reference_sha256": reference.sha256,
        "processed_sha256": processed.sha256, "proof_path": "preserved_v10_result",
        "endpoint_loss_attempted": False, "endpoint_loss_proved": False,
        "scope_reason": scope_reason, "inherited_v10_trace": deepcopy(old_trace),
        "baseline_status": baseline["status"], "baseline_reason_code": baseline["reason_code"],
        "result_status": result["status"], "reason_code": result["reason_code"],
    }
    return result, trace


def _initial_result(reference: WavAudio, processed: WavAudio, settings: EngineConfig) -> dict:
    rate = reference.sample_rate_hz
    return {
        "schema_version": 1, "engine": ENGINE, "status": "withheld",
        "content_preservation_status": "withheld", "reason_code": None,
        "events": None, "complete_audio_approval": False,
        "commercial_performance_validated": False,
        "reference": reference.metadata(), "processed": processed.metadata(),
        "configuration": {"profile": settings.profile, "allow_gain": settings.allow_gain,
                          "allow_resampling": settings.allow_resampling,
                          "max_delay_ms": settings.max_delay_ms},
        "analysis": {"sample_rate_hz": rate, "hop_ms": 1000 / rate,
                     "method": METHOD, "minimum_event_duration_ms": MIN_EVENT_MS,
                     "maximum_cumulative_edit_shift_ms": MAX_EVENT_MS,
                     "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {},
        "limitations": ["Diagnostic candidates, not complete audio approval or fault provenance.",
                        _LIMITATION],
    }


def _retained_context(x: np.ndarray, y: np.ndarray, side: str, length: int,
                      rate: int) -> tuple[dict | None, str | None]:
    width = max(3, round(CONTEXT_MS * rate / 1000))
    if len(y) < width:
        return None, "endpoint_loss_insufficient_retained_context"
    reference_start = length if side == "head" else len(y) - width
    processed_start = 0 if side == "head" else len(y) - width
    template = x[reference_start:reference_start + width]
    if float(np.std(template)) <= 1e-6:
        return None, "endpoint_loss_uninformative_retained_context"
    # Check exact native sample-aligned occurrences, not byte-shift aliases.
    pattern = short_event_engine._pcm_bytes(template)
    reference_matches = short_event_engine._occurrences(pattern, short_event_engine._pcm_bytes(x))
    processed_matches = short_event_engine._occurrences(pattern, short_event_engine._pcm_bytes(y))
    if reference_matches != [reference_start] or processed_matches != [processed_start]:
        return None, "endpoint_loss_nonunique_retained_context"
    # These measured windows all belong to the retained side. No missing-side
    # offset or anchor is invented for the absent head/tail context.
    scores = []
    for indices in np.array_split(np.arange(width), 3):
        a = template[indices]
        b = y[processed_start + indices]
        if float(np.std(a)) <= 1e-6:
            return None, "endpoint_loss_uninformative_retained_context"
        scores.append(_corr(a, b))
    correlation = _corr(template, y[processed_start:processed_start + width])
    return {
        "context_samples": width, "reference_start_sample": reference_start,
        "processed_start_sample": processed_start, "reference_match_count": 1,
        "processed_match_count": 1, "context_correlation": correlation,
        "retained_window_correlations": scores,
    }, None


@analysis_scope
def analyze_buffers_with_trace(reference: WavAudio, processed: WavAudio,
                               config: EngineConfig | None = None) -> tuple[dict, dict]:
    settings = config if config is not None else EngineConfig()
    if not isinstance(settings, EngineConfig) or settings.profile != "basic":
        raise EngineConfigError("The endpoint-loss candidate supports basic only.")
    if not _eligible(reference, processed, settings):
        return _inherited(reference, processed, settings, "outside_native_endpoint_loss_scope")
    x, y = reference.samples, processed.samples
    rate, length = reference.sample_rate_hz, len(x) - len(y)
    if _exact_zero_trim(x, y, length):
        return _inherited(reference, processed, settings, "exact_zero_only_edge_trim")

    first, last, prefix, suffix = short_event_engine._geometry_bounds(x, y)
    # A supported exact internal edit must keep M1/v9 behavior, including its
    # real native or analysis-grid metadata. Non-exact or endpoint-ambiguous
    # shortening cannot escape through this fallback.
    if first <= last and 0 < first <= last < len(y):
        return _inherited(reference, processed, settings, "exact_internal_deletion_geometry")

    result = _initial_result(reference, processed, settings)
    trace = {
        "schema_version": 1, "engine": ENGINE, "analysis_engine": ENGINE, "method": METHOD,
        "reference_sha256": reference.sha256, "processed_sha256": processed.sha256,
        "proof_path": "native_pcm_endpoint_loss", "endpoint_loss_attempted": True,
        "endpoint_loss_proved": False, "native_sample_rate_hz": rate,
        "reference_sample_count": len(x), "processed_sample_count": len(y),
        "search_complete": True, "every_supported_geometry_checked": True,
        "prefix_equal_sample_count": prefix, "suffix_equal_sample_count": suffix,
        "single_deletion_boundary_min_sample": first,
        "single_deletion_boundary_max_sample": last,
        "supported_geometry_count": max(0, last - first + 1),
        "every_output_sample_exact": False, "all_retained_native_samples_exact": False,
    }

    def failure(reason: str) -> tuple[dict, dict]:
        result["reason_code"] = reason
        trace.update(result_status="withheld", reason_code=reason)
        return result, trace

    if min(float(np.std(x)), float(np.std(y))) <= 1e-6:
        return failure("endpoint_loss_insufficient_signal_variation")
    if first > last:
        return failure("endpoint_loss_no_complete_single_deletion_explanation")
    if first != last or first not in {0, len(y)}:
        return failure("endpoint_loss_ambiguous_single_deletion_geometry")
    side = "head" if first == 0 else "tail"
    start, end = (0, length) if side == "head" else (len(y), len(x))
    removed = x[start:end]
    if not np.any(removed) or float(np.std(removed)) <= 1e-6:
        return failure("endpoint_loss_uninformative_removed_content")
    rendered = x[length:] if side == "head" else x[:-length]
    if not np.array_equal(rendered, y):
        return failure("endpoint_loss_whole_output_reconstruction_failed")
    context, reason = _retained_context(x, y, side, length, rate)
    if context is None:
        return failure(reason)
    offset = -length if side == "head" else 0
    event = {
        "type": "delete", "location": side,
        "reference_interval_ms": [start * 1000 / rate, end * 1000 / rate],
        "processed_boundary_ms": 0.0 if side == "head" else len(y) * 1000 / rate,
        "evidence": {
            "retained_offset_ms": offset * 1000 / rate,
            "retained_context_correlation": context["context_correlation"],
            "removed_sample_count": length, "retained_native_samples": len(y),
            "all_retained_native_samples_exact": True,
        },
    }
    retained_start, retained_end = (length, len(x)) if side == "head" else (0, len(y))
    scores = context["retained_window_correlations"]
    result.update(
        status="analyzed", reason_code=None, content_preservation_status="defect_candidates",
        events=[event], diagnostics={
            "gain_estimate": 1.0, "applied_gain": 1.0, "matched_normalized_rmse": 0.0,
            "matched_analysis_samples": len(y), "anchor_run_count": 1,
            "minimum_local_correlation": min(scores), "normalized_path_cost": 0.0,
        }, alignment_segments=[{
            "reference_interval_ms": [retained_start * 1000 / rate, retained_end * 1000 / rate],
            "processed_offset_ms": offset * 1000 / rate, "anchor_correlations": scores,
        }],
    )
    trace.update(
        endpoint_loss_proved=True, result_status="analyzed", reason_code=None,
        event_kind="delete", event_location=side, event_boundary_sample=first,
        event_length_samples=length, exact_output_sample_count=len(y),
        every_output_sample_exact=True, all_retained_native_samples_exact=True,
        complete_endpoints_included=True, informative_context_proof=context,
        matched_native_samples=len(y), edit_intent_or_cause_established=False,
    )
    return result, trace


def analyze_buffers(reference: WavAudio, processed: WavAudio, config: EngineConfig | None = None) -> dict:
    return analyze_buffers_with_trace(reference, processed, config)[0]


def analyze_wavs_with_trace(reference_path: str | Path, processed_path: str | Path,
                            config: EngineConfig | None = None) -> tuple[dict, dict]:
    return analyze_buffers_with_trace(read_wav(reference_path), read_wav(processed_path), config)
