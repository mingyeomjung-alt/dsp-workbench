"""Original-sample-grid PCM measurements, separate from temporal verdicts.

No alignment, resampling, gain fitting, windowing, detrending, FFT padding,
denoising, or automatic repair occurs here. Spectral powers are a partition of
the complete record's one-sided DFT energy, not a perceptual quality score.
Rail occupancy is only an endpoint proxy; it does not establish clipping's
cause. The signal-to-residual ratio compares two supplied files, not speech
with ambient noise. Measurements cannot approve audio or identify a speaker.
"""

from __future__ import annotations

import math

import numpy as np

from .audio import (
    AudioInputError,
    MAX_DURATION_SECONDS,
    MIN_DURATION_SECONDS,
    SUPPORTED_SAMPLE_RATES,
    WavAudio,
)


FRAME_DURATION_MS = 100
BAND_EDGES_HZ = (0, 250, 500, 1000, 2000, 4000, 8000, 16000, 24000)
_PCM_SCALE = 32768.0
_PARSEVAL_RTOL = 1e-12
_PARSEVAL_ATOL = 1e-27


class FullbandMetricError(ValueError):
    """A fixed-code measurement rejection without caller-derived details."""

    def __init__(self, code: str, message: str | None = None) -> None:
        self.code = code
        self.message = message if message is not None else code
        super().__init__(self.message)


def _validated_audio(audio: object) -> WavAudio:
    # Recheck direct and deliberately forged dataclass instances. Bound exact
    # fields before reading samples, reject mutable sources, and let WavAudio
    # validate finite values, exact PCM16 grid and hash format. Reconstruction
    # takes an immutable snapshot; it never rounds or normalizes a signal.
    if type(audio) is not WavAudio:
        raise FullbandMetricError("invalid_audio", "Measurements require immutable mono PCM16 audio.")
    try:
        samples = audio.samples
        rate = audio.sample_rate_hz
        digest = audio.sha256
    except AttributeError:
        raise FullbandMetricError("invalid_audio", "Measurements require immutable mono PCM16 audio.") from None
    if (
        type(samples) is not np.ndarray
        or samples.dtype != np.dtype(np.float64)
        or samples.ndim != 1
        or samples.flags.writeable
        or type(rate) is not int
        or rate not in SUPPORTED_SAMPLE_RATES
        or not MIN_DURATION_SECONDS * rate <= samples.size <= MAX_DURATION_SECONDS * rate
        or type(digest) is not str
        or len(digest) != 64
    ):
        raise FullbandMetricError("invalid_audio", "Measurements require immutable mono PCM16 audio.")
    try:
        return WavAudio(samples=samples, sample_rate_hz=rate, sha256=digest)
    except AudioInputError:
        raise FullbandMetricError("invalid_audio", "Measurements require immutable mono PCM16 audio.") from None


def _mean_square(values: np.ndarray) -> float:
    return float(np.mean(values * values, dtype=np.float64))


def _spectral_bands(values: np.ndarray, rate: int) -> list[dict]:
    """Partition an unpadded whole-record DFT, preserving DC and Nyquist.

    Each bin has |X[k]|²/N² power. Positive-frequency bins are doubled
    except the even-length Nyquist bin. Band membership uses the bin center,
    lower-inclusive/upper-exclusive except the available terminal band,
    which includes Nyquist. For odd N there is no Nyquist bin. Parseval and
    partition checks use relative tolerance 1e-12 and absolute 1e-27.
    """
    count = values.size
    spectrum = np.fft.rfft(values)
    powers = (spectrum.real * spectrum.real + spectrum.imag * spectrum.imag) / (count * count)
    powers[1:] *= 2.0
    if count % 2 == 0:
        powers[-1] *= 0.5
    direct_power = _mean_square(values)
    spectral_power = float(np.sum(powers, dtype=np.float64))
    if not math.isfinite(spectral_power) or not math.isclose(
        direct_power, spectral_power, rel_tol=_PARSEVAL_RTOL, abs_tol=_PARSEVAL_ATOL
    ):
        raise FullbandMetricError("numerical_measurement_error", "Spectral energy could not be verified.")
    # Integer products are exactly representable within the bounded record
    # size. Dividing k*rate by N keeps exact edge bins (including Nyquist)
    # on their defined edge rather than perturbing them through 1/rate.
    centers = np.arange(powers.size, dtype=np.float64) * rate / count
    nyquist = rate / 2.0
    bands: list[dict] = []
    available_power = 0.0
    for lower, upper in zip(BAND_EDGES_HZ[:-1], BAND_EDGES_HZ[1:]):
        if lower >= nyquist:
            bands.append({
                "lower_hz": lower,
                "upper_hz": upper,
                "effective_upper_hz": None,
                "upper_inclusive": False,
                "status": "not_available",
                "mean_square": None,
                "power_fraction": None,
            })
            continue
        effective_upper = min(float(upper), nyquist)
        inclusive = effective_upper == nyquist
        within = (centers >= lower) & (
            (centers <= effective_upper) if inclusive else (centers < effective_upper)
        )
        power = float(np.sum(powers[within], dtype=np.float64))
        available_power += power
        bands.append({
            "lower_hz": lower,
            "upper_hz": upper,
            "effective_upper_hz": effective_upper,
            "upper_inclusive": inclusive,
            "status": "available",
            "mean_square": power,
            "power_fraction": 0.0,
        })
    if not math.isclose(
        spectral_power, available_power, rel_tol=_PARSEVAL_RTOL, abs_tol=_PARSEVAL_ATOL
    ):
        raise FullbandMetricError("numerical_measurement_error", "Spectral bands could not be verified.")
    if available_power > 0.0:
        for band in bands:
            if band["status"] == "available":
                band["power_fraction"] = band["mean_square"] / available_power
    return bands


def _frames(values: np.ndarray, frame_size: int) -> list[dict]:
    frames: list[dict] = []
    for start in range(0, values.size, frame_size):
        end = min(start + frame_size, values.size)
        frame = values[start:end]
        frames.append({
            "start_sample": start,
            "end_sample": end,
            "mean_square": _mean_square(frame),
            "peak": float(np.max(np.abs(frame))),
        })
    return frames


def _longest_same_rail_run(pcm: np.ndarray) -> int:
    longest = 0
    for rail in (-32768, 32767):
        # Each positive transition starts a run and each negative transition
        # ends it. Opposite-sign rails are different runs, even when adjacent.
        mask = (pcm == rail).astype(np.int8)
        endpoints = np.flatnonzero(np.diff(mask, prepend=np.int8(0), append=np.int8(0)))
        if endpoints.size:
            longest = max(longest, int(np.max(endpoints[1::2] - endpoints[::2])))
    return longest


def measure_audio(audio: WavAudio) -> dict:
    """Measure one unchanged, original-rate PCM16 record of 2–30 seconds.

    dBFS uses normalized PCM amplitude (32768 integer units = one). Zero RMS
    or peak has no finite logarithm, so it is null. Frame end coordinates are
    exclusive; a final partial 100 ms frame is retained, never discarded.
    """
    validated = _validated_audio(audio)
    values = validated.samples
    pcm = (values * _PCM_SCALE).astype(np.int32)
    mean_square = _mean_square(values)
    peak = float(np.max(np.abs(values)))
    rail_count = int(np.count_nonzero((pcm == -32768) | (pcm == 32767)))
    frame_size = validated.sample_rate_hz // 10
    return {
        "dc_offset": float(np.mean(values, dtype=np.float64)),
        "mean_square": mean_square,
        "rms_dbfs": 10.0 * math.log10(mean_square) if mean_square > 0.0 else None,
        "peak_dbfs": 20.0 * math.log10(peak) if peak > 0.0 else None,
        "crest_factor": peak / math.sqrt(mean_square) if mean_square > 0.0 else None,
        "rail_sample_count": rail_count,
        "rail_sample_fraction": rail_count / int(values.size),
        "longest_same_rail_run_samples": _longest_same_rail_run(pcm),
        "bands": _spectral_bands(values, validated.sample_rate_hz),
        "frame_size_samples": frame_size,
        "frames": _frames(values, frame_size),
    }


def _not_comparable(reason: str) -> dict:
    return {
        "status": "withheld",
        "reason_code": reason,
        "unequal_sample_count": None,
        "first_changed_sample": None,
        "last_changed_sample": None,
        "maximum_abs_error_pcm16": None,
        "mean_square_error": None,
        "signal_to_residual_db": None,
        "signal_to_residual_status": "not_comparable",
        "correlation": None,
        "correlation_status": "not_comparable",
        "residual_bands": None,
        "changed_frames": None,
    }


def measure_pair(reference: WavAudio, processed: WavAudio) -> dict:
    """Compare equal raw sample grids; mismatched geometry is withheld.

    Coordinates are sample indices, never aligned temporal-engine endpoints.
    Differences use int32 PCM units so full-range rail differences cannot
    wrap. The residual can reach ±65535 PCM16 units; it is not PCM16 audio.
    Correlation is mean-centered Pearson, with undefined constants left null.
    """
    left = _validated_audio(reference)
    right = _validated_audio(processed)
    if left.sample_rate_hz != right.sample_rate_hz:
        return _not_comparable("sample_rate_mismatch")
    if left.samples.size != right.samples.size:
        return _not_comparable("sample_count_mismatch")
    count = left.samples.size
    left_pcm = (left.samples * _PCM_SCALE).astype(np.int32)
    right_pcm = (right.samples * _PCM_SCALE).astype(np.int32)
    residual_pcm = right_pcm - left_pcm
    changed = residual_pcm != 0
    unequal_count = int(np.count_nonzero(changed))
    residual = residual_pcm.astype(np.float64) / _PCM_SCALE
    residual_power = _mean_square(residual)
    reference_power = _mean_square(left.samples)
    if residual_power == 0.0:
        ratio = None
        ratio_status = "zero_residual"
    elif reference_power == 0.0:
        ratio = None
        ratio_status = "zero_reference"
    else:
        ratio = 10.0 * (math.log10(reference_power) - math.log10(residual_power))
        ratio_status = "finite"
    left_centered = left.samples - float(np.mean(left.samples, dtype=np.float64))
    right_centered = right.samples - float(np.mean(right.samples, dtype=np.float64))
    left_variance = _mean_square(left_centered)
    right_variance = _mean_square(right_centered)
    if left_variance == 0.0 or right_variance == 0.0:
        correlation = None
        correlation_status = "constant_signal"
    else:
        covariance = float(np.mean(left_centered * right_centered, dtype=np.float64))
        correlation = max(-1.0, min(1.0, covariance / math.sqrt(left_variance * right_variance)))
        correlation_status = "defined"
    changed_frames: list[dict] = []
    frame_size = left.sample_rate_hz // 10
    for start in range(0, count, frame_size):
        end = min(start + frame_size, count)
        frame_count = int(np.count_nonzero(changed[start:end]))
        if frame_count:
            changed_frames.append({
                "start_sample": start,
                "end_sample": end,
                "unequal_sample_count": frame_count,
            })
    return {
        "status": "measured",
        "reason_code": None,
        "unequal_sample_count": unequal_count,
        "first_changed_sample": int(np.argmax(changed)) if unequal_count else None,
        "last_changed_sample": count - 1 - int(np.argmax(changed[::-1])) if unequal_count else None,
        "maximum_abs_error_pcm16": int(np.max(np.abs(residual_pcm))),
        "mean_square_error": residual_power,
        "signal_to_residual_db": ratio,
        "signal_to_residual_status": ratio_status,
        "correlation": correlation,
        "correlation_status": correlation_status,
        "residual_bands": _spectral_bands(residual, left.sample_rate_hz),
        "changed_frames": changed_frames,
    }
