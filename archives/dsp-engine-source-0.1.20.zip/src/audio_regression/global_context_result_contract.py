"""Separate v9 identity with unchanged strict v8 result geometry.

This inert validator does not read a waveform or trace, establish the exact
forward witness, approve whole-audio quality or prove commercial performance.
The opt-in engine preserves v8 and attempts a bounded global-context rescue.
"""

from copy import deepcopy

from . import result_contract as _base
from .review_contract import with_review_diagnostics
from .compound_event_result_contract import validate_compound_event_analysis_result

ENGINE = "local_content_alignment_v9"
METHOD = "global_context_quantized_event_forward_proof"


@with_review_diagnostics
def validate_global_context_analysis_result(value: object) -> dict:
    """Return the original object only after unchanged v8 evidence checks."""
    if type(value) is not dict:
        raise _base.ResultContractError("invalid_result_type")
    _base._json_tree(value)
    if value.get("engine") != ENGINE:
        raise _base.ResultContractError("unsupported_engine")
    if value.get("status") != "error":
        analysis = value.get("analysis")
        if type(analysis) is not dict or analysis.get("method") != METHOD:
            raise _base.ResultContractError("invalid_analysis_method")
    shared = deepcopy(value)
    shared["engine"] = "local_content_alignment_v8"
    if value.get("status") != "error":
        shared["analysis"]["method"] = "exact_quantized_compound_event_forward_proof"
    validate_compound_event_analysis_result(shared)
    return value
