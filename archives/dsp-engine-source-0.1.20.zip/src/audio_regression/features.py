"""Gain-invariant short-time features for paired-audio correspondence.

This is an analysis representation, not a voice detector or an audio-quality
score. The v0 engine works at 8 kHz with 24 equal-width FFT bands over the
shared telephone band (300 <= f < 3400 Hz). Each frame is centered on its
reported sample index. Missing boundary samples are zero-padded; frame RMS
uses only samples actually present in the input.

Band powers are divided by their sum before flooring at 1e-8 and taking logs.
The log vector is centered across bands and L2-normalized. Consequently a
nonzero constant gain, including polarity inversion, does not change spectral
shape. Absolute activity remains available separately through ``frame_rms``.
Raw samples are never modified or substituted by these features.
"""

from __future__ import annotations

from dataclasses import dataclass
import numbers

import numpy as np


ANALYSIS_SAMPLE_RATE_HZ = 8000
MIN_FREQUENCY_HZ = 300.0
MAX_FREQUENCY_HZ = 3400.0
BAND_COUNT = 24
RELATIVE_POWER_FLOOR = 1e-8


class FeatureInputError(ValueError):
    """Invalid analysis input or unsupported feature configuration."""

    def __init__(self, code: str, message: str) -> None:
        self.code = code
        self.message = message
        super().__init__(message)


def _readonly(values: np.ndarray, dtype: np.dtype | type) -> np.ndarray:
    """Use immutable backing bytes, not merely a reversible write flag."""
    converted = np.asarray(values, dtype=dtype)
    return np.frombuffer(converted.tobytes(), dtype=dtype).reshape(converted.shape)


def _validate_rate(sample_rate_hz: int) -> None:
    if (
        isinstance(sample_rate_hz, (bool, np.bool_))
        or not isinstance(sample_rate_hz, (int, np.integer))
        or sample_rate_hz != ANALYSIS_SAMPLE_RATE_HZ
    ):
        raise FeatureInputError("unsupported_sample_rate", "Features require an 8 kHz analysis buffer.")


def _sample_count(milliseconds: float, *, minimum: float, maximum: float) -> int:
    if isinstance(milliseconds, (bool, np.bool_)) or not isinstance(milliseconds, numbers.Real):
        raise FeatureInputError("invalid_configuration", "Frame settings must be finite numeric milliseconds.")
    try:
        duration = float(milliseconds)
    except (ValueError, OverflowError):
        raise FeatureInputError("invalid_configuration", "Frame settings must be finite numeric milliseconds.") from None
    if not np.isfinite(duration) or not minimum <= duration <= maximum:
        raise FeatureInputError("invalid_configuration", "Frame settings are outside the supported analysis range.")
    exact_samples = duration * ANALYSIS_SAMPLE_RATE_HZ / 1000
    samples = round(exact_samples)
    if not np.isclose(exact_samples, samples, rtol=0, atol=1e-9):
        raise FeatureInputError("invalid_configuration", "Frame settings must land on integer sample positions.")
    return int(samples)


@dataclass(frozen=True, slots=True)
class FeatureTrack:
    features: np.ndarray
    centers_samples: np.ndarray
    frame_rms: np.ndarray
    sample_rate_hz: int
    hop_samples: int
    window_samples: int

    def __post_init__(self) -> None:
        _validate_rate(self.sample_rate_hz)
        if (
            isinstance(self.hop_samples, (bool, np.bool_))
            or isinstance(self.window_samples, (bool, np.bool_))
            or not isinstance(self.hop_samples, (int, np.integer))
            or not isinstance(self.window_samples, (int, np.integer))
            or not 40 <= self.hop_samples <= 160
            or not 160 <= self.window_samples <= 640
            or self.window_samples % 2 != 0
            or self.window_samples < 2 * self.hop_samples
        ):
            raise FeatureInputError("invalid_configuration", "Unsupported feature frame geometry.")
        try:
            raw_features = np.asarray(self.features)
            raw_centers = np.asarray(self.centers_samples)
            raw_rms = np.asarray(self.frame_rms)
            if (
                np.iscomplexobj(raw_features)
                or np.iscomplexobj(raw_rms)
                or raw_centers.dtype.kind not in "iu"
            ):
                raise ValueError("invalid arrays")
            features = np.asarray(raw_features, dtype=np.float64)
            centers = np.asarray(raw_centers, dtype=np.int64)
            rms = np.asarray(raw_rms, dtype=np.float64)
        except (TypeError, ValueError, OverflowError):
            raise FeatureInputError("invalid_features", "Feature track arrays are malformed.") from None
        if (
            features.ndim != 2
            or features.shape[1] != BAND_COUNT
            or centers.ndim != 1
            or rms.ndim != 1
            or features.shape[0] != centers.size
            or rms.size != centers.size
            or centers.size == 0
            or not np.array_equal(centers, np.arange(centers.size, dtype=np.int64) * self.hop_samples)
            or not np.all(np.isfinite(features))
            or not np.all(np.isfinite(rms))
            or np.any(rms < 0)
        ):
            raise FeatureInputError("invalid_features", "Feature track arrays are malformed.")
        object.__setattr__(self, "features", _readonly(features, np.float64))
        object.__setattr__(self, "centers_samples", _readonly(centers, np.int64))
        object.__setattr__(self, "frame_rms", _readonly(rms, np.float64))
        object.__setattr__(self, "sample_rate_hz", int(self.sample_rate_hz))
        object.__setattr__(self, "hop_samples", int(self.hop_samples))
        object.__setattr__(self, "window_samples", int(self.window_samples))


def extract_features(
    samples: np.ndarray,
    sample_rate_hz: int = ANALYSIS_SAMPLE_RATE_HZ,
    *,
    hop_ms: float = 10.0,
    window_ms: float = 40.0,
) -> FeatureTrack:
    """Return centered log-band shape plus independent digital RMS activity.

    Supported hops are 5--20 ms and windows 20--80 ms, landing on integral
    samples. Windows must contain an even number of samples and be at least
    twice the hop. Input must be a nonempty, finite, one-dimensional numeric
    real array; duration and normalized PCM range are checked by WAV I/O, not
    silently applied here.
    """
    _validate_rate(sample_rate_hz)
    hop = _sample_count(hop_ms, minimum=5.0, maximum=20.0)
    window = _sample_count(window_ms, minimum=20.0, maximum=80.0)
    if window % 2 != 0 or window < 2 * hop:
        raise FeatureInputError("invalid_configuration", "A window must be even and at least twice the hop.")
    try:
        raw = np.asarray(samples)
        if raw.dtype.kind not in "fiu" or np.iscomplexobj(raw):
            raise ValueError("non-real numeric input")
        values = np.asarray(raw, dtype=np.float64)
    except (TypeError, ValueError, OverflowError):
        raise FeatureInputError("invalid_samples", "Analysis samples must be a nonempty finite real mono array.") from None
    if values.ndim != 1 or values.size == 0 or not np.all(np.isfinite(values)):
        raise FeatureInputError("invalid_samples", "Analysis samples must be a nonempty finite real mono array.")

    centers = np.arange(0, values.size, hop, dtype=np.int64)
    # Scaling only inside feature calculation avoids overflow for otherwise
    # valid finite inputs. RMS is restored to the caller's digital scale.
    peak = float(np.max(np.abs(values)))
    scaled = values / peak if peak > 0 else np.zeros_like(values)
    half = window // 2
    padded = np.pad(scaled, (half, half), mode="constant")
    frames = np.lib.stride_tricks.sliding_window_view(padded, window)[centers].copy()
    positions = centers[:, None] + np.arange(-half, half, dtype=np.int64)[None, :]
    present = (positions >= 0) & (positions < values.size)
    counts = np.count_nonzero(present, axis=1)
    rms = np.sqrt(np.sum(frames * frames, axis=1) / counts) * peak

    # Remove each frame's DC only from present samples. Padding must remain
    # zero, so a constant input does not create false spectral activity at the
    # recording boundaries. Absolute DC remains included in raw frame RMS.
    mean = np.sum(frames, axis=1) / counts
    frames -= mean[:, None] * present
    frames *= np.hanning(window)[None, :]
    spectrum = np.fft.rfft(frames, axis=1)
    power = spectrum.real * spectrum.real + spectrum.imag * spectrum.imag
    frequencies = np.fft.rfftfreq(window, d=1 / ANALYSIS_SAMPLE_RATE_HZ)
    edges = np.linspace(MIN_FREQUENCY_HZ, MAX_FREQUENCY_HZ, BAND_COUNT + 1)
    bands = np.empty((centers.size, BAND_COUNT), dtype=np.float64)
    for index in range(BAND_COUNT):
        selected = (frequencies >= edges[index]) & (frequencies < edges[index + 1])
        bands[:, index] = np.mean(power[:, selected], axis=1)

    totals = np.sum(bands, axis=1)
    active = totals > 0
    features = np.zeros_like(bands)
    if np.any(active):
        log_shape = np.log(np.maximum(bands[active] / totals[active, None], RELATIVE_POWER_FLOOR))
        log_shape -= np.mean(log_shape, axis=1, keepdims=True)
        norms = np.linalg.norm(log_shape, axis=1, keepdims=True)
        features[active] = np.divide(
            log_shape, norms, out=np.zeros_like(log_shape), where=norms > 1e-12
        )
    return FeatureTrack(features, centers, rms, int(sample_rate_hz), hop, window)
