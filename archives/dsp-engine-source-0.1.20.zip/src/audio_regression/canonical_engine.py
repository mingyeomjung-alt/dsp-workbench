"""Opt-in exact PCM normal-resampling proof; unchanged v4 otherwise.

No enlarged residual budget, fitted transform, event rescue or full-band claim.
Every output sample must equal the declared canonical nearest PCM16 sequence.
"""

from copy import deepcopy
import math
from pathlib import Path
import numpy as np
from . import instrument_engine
from .analysis_scope import analysis_scope
from .audio import WavAudio, read_wav
from .engine import EngineConfig, EngineConfigError, RATE, _corr
from .profiles import prepare_analysis

ENGINE = "local_content_alignment_v5"
METHOD = "exact_canonical_pcm_resampling_with_unique_context"
PCM_STEP = 1 / 32768
LOW_INFORMATION_STD = PCM_STEP / (2 * math.sqrt(1 - .90 ** 2))
ELIGIBLE_REASONS = frozenset({"raw_landmark_unexplained_local_residual",
                            "raw_landmark_unexplained_local_change"})


@analysis_scope
def analyze_buffers_with_trace(reference: WavAudio, processed: WavAudio,
                               config: EngineConfig | None = None) -> tuple[dict, dict]:
    settings = config if config is not None else EngineConfig()
    if not isinstance(settings, EngineConfig) or settings.profile != "basic":
        raise EngineConfigError("The canonical candidate supports basic only.")
    baseline, old_trace = instrument_engine.analyze_buffers_with_trace(reference, processed, settings)
    result = deepcopy(baseline)
    result["engine"] = ENGINE
    result["analysis"]["method"] = METHOD
    result["limitations"].append("v4 preserved; exact canonical normal-only resampling proof "
        "requires higher-rate reference to 8kHz PCM16, no declared gain/timing edits. "
        "Sub-resolution correlation is not a probability or full-band approval.")
    trace = {"schema_version": 1, "engine": ENGINE, "analysis_engine": ENGINE, "method": METHOD,
             "proof_path": "preserved_v4_result", "baseline_status": baseline["status"],
             "baseline_reason_code": baseline["reason_code"], "canonical_attempted": False,
             "canonical_proved": False, "reference_sha256": reference.sha256,
             "processed_sha256": processed.sha256, "inherited_v4_trace": deepcopy(old_trace),
             "result_status": result["status"], "reason_code": result["reason_code"]}
    if (baseline["status"] != "withheld" or baseline["reason_code"] not in ELIGIBLE_REASONS
            or not settings.allow_resampling or settings.allow_gain
            or reference.sample_rate_hz <= RATE or processed.sample_rate_hz != RATE):
        return result, trace
    trace["canonical_attempted"] = True
    x, y = prepare_analysis(reference), prepare_analysis(processed)
    if len(x) != len(y) or len(x) < 1600:
        return result, trace
    expected = np.minimum(np.rint(x * 32768), 32767) / 32768
    if not np.array_equal(expected, y) or float(np.max(np.abs(y - x))) > PCM_STEP / 2:
        return result, trace
    landmarks, attempted = instrument_engine._landmarks(
        x, y, math.ceil(settings.max_delay_ms * RATE / 1000) + 16000, False)
    groups = instrument_engine._groups(landmarks)
    if (len(groups) != 1 or groups[0]["offset"] != 0 or len(groups[0]["points"]) < 3
            or any(p["offset"] != 0 for p in groups[0]["points"])):
        return result, trace
    width = min(960, len(x))
    starts = sorted(set(range(0, len(x) - width + 1, 480)) | {len(x) - width})
    raw_minimum, informative_minimum, low_information = None, None, 0
    for start in starts:
        a, b = x[start:start + width], y[start:start + width]
        if float(np.sqrt(np.mean((b - a) ** 2))) > max(.08 * float(np.sqrt(np.mean(a ** 2))), 2 * PCM_STEP):
            return result, trace
        correlation = _corr(a, b)
        raw_minimum = correlation if raw_minimum is None else min(raw_minimum, correlation)
        if max(float(np.std(a)), float(np.std(b))) <= LOW_INFORMATION_STD:
            low_information += 1
            continue  # Whole-file exact equality includes these samples too.
        informative_minimum = correlation if informative_minimum is None else min(informative_minimum, correlation)
        if correlation < .90:
            return result, trace
    nrmse = float(np.sqrt(np.sum((y - x) ** 2) / max(float(np.dot(x, x)), 1e-16)))
    if nrmse > .08 or informative_minimum is None:
        return result, trace
    points = groups[0]["points"]
    selected = [points[0], points[len(points) // 2], points[-1]]
    result.update(status="analyzed", content_preservation_status="no_supported_defect_candidates",
        reason_code=None, events=[], diagnostics={"gain_estimate": 1.0, "applied_gain": 1.0,
        "matched_normalized_rmse": nrmse, "matched_analysis_samples": len(x), "anchor_run_count": 1,
        "minimum_local_correlation": informative_minimum, "normalized_path_cost": nrmse},
        alignment_segments=[{"reference_interval_ms": [0.0, len(x) / 8], "processed_offset_ms": 0.0,
                             "anchor_correlations": [p["correlation"] for p in selected]}])
    trace.update(proof_path="canonical_resampling_exact_pcm", canonical_proved=True,
        result_status="analyzed", reason_code=None, low_information_block_count=low_information,
        raw_minimum_local_correlation=raw_minimum, informative_minimum_local_correlation=informative_minimum,
        exact_pcm_proof_sample_count=len(x), max_absolute_residual=float(np.max(np.abs(y - x))),
        maximum_quantization_residual=PCM_STEP / 2, low_information_std_ceiling=LOW_INFORMATION_STD,
        landmarks_attempted=attempted, landmarks_accepted=len(points))
    return result, trace


def analyze_buffers(reference: WavAudio, processed: WavAudio,
                    config: EngineConfig | None = None) -> dict:
    return analyze_buffers_with_trace(reference, processed, config)[0]


def analyze_wavs_with_trace(reference_path: str | Path, processed_path: str | Path,
                            config: EngineConfig | None = None) -> tuple[dict, dict]:
    return analyze_buffers_with_trace(read_wav(reference_path), read_wav(processed_path), config)
