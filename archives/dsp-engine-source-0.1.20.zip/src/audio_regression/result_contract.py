"""Strict, dependency-free contract for existing local temporal result JSON.

Validation checks a diagnostic artifact; it does not read audio, rerun a
detector, or turn signal correlation into a probability. The tiny CLI error
envelope is the only branch that may omit the local engine identifier.
"""

from __future__ import annotations

import json
import math
from pathlib import Path
import re

from .review_contract import with_review_diagnostics


MAX_RESULT_BYTES = 1_048_576
ENGINE = "local_content_alignment_v1"
_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}\Z")
_HASH = re.compile(r"[0-9a-f]{64}\Z")
_EPSILON_MS = 1e-6
# Frozen engine tolerances: 320 analysis samples for ignored window leakage,
# and 24 analysis samples for the spread of raw anchor offsets.
_WINDOW_LEAKAGE_MS = 40.0
_RAW_ANCHOR_TOLERANCE_MS = 3.0
_FULL_FIELDS = {
    "schema_version", "engine", "status", "content_preservation_status",
    "reason_code", "events", "complete_audio_approval",
    "commercial_performance_validated", "reference", "processed",
    "configuration", "analysis", "diagnostics", "limitations",
}
_DIAGNOSTIC_FIELDS = {
    "normalized_path_cost", "gain_estimate", "applied_gain",
    "matched_normalized_rmse", "matched_analysis_samples",
    "anchor_run_count", "minimum_local_correlation",
}


class ResultContractError(ValueError):
    """A stable, non-private rejection code; input values are never echoed."""

    def __init__(self, code: str, message: str | None = None) -> None:
        self.code = code
        super().__init__(message or "Analysis result violates the result contract.")


def _reject(code: str) -> None:
    raise ResultContractError(code)


def _fields(value: object, required: set[str], optional: set[str] | None = None,
            code: str = "invalid_result_structure") -> dict:
    if type(value) is not dict:
        _reject(code)
    if not required.issubset(value):
        _reject("missing_result_field")
    if set(value) - required - (optional or set()):
        _reject("unexpected_result_field")
    return value


def _number(value: object, code: str, minimum: float | None = None,
            maximum: float | None = None) -> int | float:
    if type(value) not in (int, float):
        _reject(code)
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite:
        _reject("non_finite_metric")
    if minimum is not None and value < minimum:
        _reject(code)
    if maximum is not None and value > maximum:
        _reject(code)
    return value


def _integer(value: object, code: str, minimum: int = 1) -> int:
    if type(value) is not int or value < minimum:
        _reject(code)
    return value


def _same_number(first: int | float, second: int | float) -> bool:
    return math.isclose(first, second, rel_tol=1e-12, abs_tol=_EPSILON_MS)


def _json_tree(value: object, depth: int = 0, budget: list[int] | None = None) -> None:
    """Reject non-JSON objects, cycles/deep trees, and hidden nonfinite metrics."""
    remaining = budget if budget is not None else [20_000]
    remaining[0] -= 1
    if depth > 24 or remaining[0] < 0:
        _reject("result_structure_too_large")
    if value is None or type(value) in (str, bool):
        return
    if type(value) in (int, float):
        _number(value, "invalid_numeric_metric")
    elif type(value) is list:
        for item in value:
            _json_tree(item, depth + 1, remaining)
    elif type(value) is dict:
        for key, item in value.items():
            if type(key) is not str:
                _reject("invalid_json_value")
            _json_tree(item, depth + 1, remaining)
    else:
        _reject("invalid_json_value")


def _reason(value: object) -> None:
    if type(value) is not str or _CODE.fullmatch(value) is None:
        _reject("invalid_reason_code")


def _metadata(value: object) -> dict:
    metadata = _fields(value, {"sample_rate_hz", "sample_count", "duration_ms",
                               "channels", "encoding", "rms", "peak", "sha256"},
                       code="invalid_audio_metadata")
    rate = _integer(metadata["sample_rate_hz"], "invalid_audio_metadata")
    if rate not in {8000, 16000, 44100, 48000}:
        _reject("invalid_audio_metadata")
    count = _integer(metadata["sample_count"], "invalid_audio_metadata")
    duration = _number(metadata["duration_ms"], "invalid_audio_metadata", 2000, 30000)
    if not 2 * rate <= count <= 30 * rate or not _same_number(duration, count * 1000 / rate):
        _reject("inconsistent_audio_duration")
    if type(metadata["channels"]) is not int or metadata["channels"] != 1:
        _reject("invalid_audio_metadata")
    if metadata["encoding"] != "pcm16":
        _reject("invalid_audio_metadata")
    rms = _number(metadata["rms"], "invalid_audio_metadata", 0, 1)
    peak = _number(metadata["peak"], "invalid_audio_metadata", 0, 1)
    if rms > peak + 1e-12:
        _reject("invalid_audio_metadata")
    if type(metadata["sha256"]) is not str or _HASH.fullmatch(metadata["sha256"]) is None:
        _reject("invalid_audio_metadata")
    return metadata


def _interval(value: object, duration: float, code: str) -> tuple[int | float, int | float]:
    if type(value) is not list or len(value) != 2:
        _reject(code)
    start = _number(value[0], code, 0, duration)
    end = _number(value[1], code, 0, duration)
    if start >= end:
        _reject(code)
    return start, end


def _evidence(value: object, repeat: bool, minimum_correlation: float) -> dict:
    fields = {"boundary_correlation", "offset_before_ms", "offset_after_ms"}
    if repeat:
        fields |= {"copy_correlation", "adjacent_copy_correlation"}
    evidence = _fields(value, fields, code="invalid_event_evidence")
    for name, metric in evidence.items():
        _number(metric, "invalid_event_evidence", minimum_correlation if name.endswith("correlation") else None,
                1 if name.endswith("correlation") else None)
    return evidence


def _event(value: object, reference_duration: float, processed_duration: float,
           minimum_correlation: float) -> tuple[float, float]:
    if (type(value) is not dict or type(value.get("type")) is not str
            or value["type"] not in {"delete", "repeat"}):
        _reject("unsupported_event_type")
    repeat = value["type"] == "repeat"
    fields = ({"type", "reference_source_interval_ms", "processed_added_interval_ms",
               "copy_interval_convention", "evidence"} if repeat else
              {"type", "reference_interval_ms", "processed_boundary_ms", "evidence"})
    event = _fields(value, fields, code="invalid_event_structure")
    evidence = _evidence(event["evidence"], repeat, minimum_correlation)
    if repeat:
        source_start, source_end = _interval(event["reference_source_interval_ms"], reference_duration,
                                             "invalid_reference_interval")
        start, end = _interval(event["processed_added_interval_ms"], processed_duration,
                               "invalid_processed_interval")
        length = end - start
        if (not _same_number(length, source_end - source_start)
                or start + _EPSILON_MS < length):
            _reject("inconsistent_repeat_geometry")
        if abs(start - source_end - evidence["offset_before_ms"]) > _RAW_ANCHOR_TOLERANCE_MS + _EPSILON_MS:
            _reject("inconsistent_repeat_mapping")
        if event["copy_interval_convention"] != "canonical_later_adjacent_copy_not_edit_provenance":
            _reject("unsupported_copy_interval_convention")
        shift = evidence["offset_after_ms"] - evidence["offset_before_ms"]
    else:
        source_start, source_end = _interval(event["reference_interval_ms"], reference_duration,
                                             "invalid_reference_interval")
        start = end = _number(event["processed_boundary_ms"], "invalid_processed_boundary",
                              0, processed_duration)
        length = source_end - source_start
        if not (_same_number(start, source_start + evidence["offset_before_ms"])
                and _same_number(start, source_end + evidence["offset_after_ms"])):
            _reject("inconsistent_delete_geometry")
        shift = evidence["offset_before_ms"] - evidence["offset_after_ms"]
    if not 200 <= length <= 2000:
        _reject("unsupported_event_duration")
    if not _same_number(length, shift):
        _reject("inconsistent_event_offset")
    return start, end


def _segments(value: object, reference_duration: float, processed_duration: float,
              no_events: bool, max_delay_ms: float, minimum_correlation: float) -> int:
    if type(value) is not list or not 1 <= len(value) <= 512:
        _reject("invalid_alignment_segments")
    previous_end = -1.0
    previous_processed_end = -1.0
    offsets = []
    for item in value:
        segment = _fields(item, {"reference_interval_ms", "processed_offset_ms", "anchor_correlations"},
                          code="invalid_alignment_segments")
        start, end = _interval(segment["reference_interval_ms"], reference_duration,
                               "invalid_alignment_reference_interval")
        offset = _number(segment["processed_offset_ms"], "invalid_alignment_offset")
        if (start < previous_end or start + offset < -_EPSILON_MS
                or end + offset > processed_duration + _EPSILON_MS):
            _reject("invalid_alignment_processed_interval")
        if start + offset + _EPSILON_MS < previous_processed_end:
            _reject("unordered_or_overlapping_alignment")
        if no_events and previous_end >= 0 and start - previous_end > _WINDOW_LEAKAGE_MS + _EPSILON_MS:
            _reject("unexplained_empty_event_alignment_gap")
        previous_end = end
        previous_processed_end = end + offset
        offsets.append(offset)
        correlations = segment["anchor_correlations"]
        if type(correlations) is not list or len(correlations) != 3:
            _reject("invalid_anchor_correlations")
        for correlation in correlations:
            _number(correlation, "invalid_anchor_correlations", minimum_correlation, 1)
    if abs(offsets[0]) > max_delay_ms + _RAW_ANCHOR_TOLERANCE_MS + _EPSILON_MS:
        _reject("initial_alignment_outside_declared_search")
    if no_events and max(offsets) - min(offsets) > _WINDOW_LEAKAGE_MS + _EPSILON_MS:
        _reject("unexplained_empty_event_offset_change")
    if any(abs(offset - offsets[0]) > 2000 + _EPSILON_MS for offset in offsets):
        _reject("alignment_outside_cumulative_edit_budget")
    return len(value)


@with_review_diagnostics
def validate_analysis_result(value: object) -> dict:
    """Return the original validated dictionary or raise ResultContractError.

    Version-1 results retain their original strict contract. Explicit opt-in
    local_content_alignment_v2 through v12 use separate candidate contracts.
    Existing CLI errors have exactly schema_version, status, and reason_code;
    their optional engine field, if supplied, must identify the local engine.
    """
    if type(value) is not dict:
        _reject("invalid_result_type")
    if type(value.get("engine")) is str and value["engine"] == "local_content_alignment_v12":
        from .resampler_result_contract import validate_resampler_analysis_result
        return validate_resampler_analysis_result(value)
    if type(value.get("engine")) is str and value["engine"] == "local_content_alignment_v11":
        from .edge_event_result_contract import validate_edge_event_analysis_result
        return validate_edge_event_analysis_result(value)
    if type(value.get("engine")) is str and value["engine"] == "local_content_alignment_v10":
        from .short_event_result_contract import validate_short_event_analysis_result
        return validate_short_event_analysis_result(value)
    if type(value.get("engine")) is str and value["engine"] == "local_content_alignment_v9":
        from .global_context_result_contract import validate_global_context_analysis_result
        return validate_global_context_analysis_result(value)
    if type(value.get("engine")) is str and value["engine"] == "local_content_alignment_v8":
        from .compound_event_result_contract import validate_compound_event_analysis_result
        return validate_compound_event_analysis_result(value)
    if type(value.get("engine")) is str and value["engine"] == "local_content_alignment_v7":
        from .compound_result_contract import validate_compound_analysis_result
        return validate_compound_analysis_result(value)
    if type(value.get("engine")) is str and value["engine"] == "local_content_alignment_v6":
        from .repeat_result_contract import validate_repeat_analysis_result
        return validate_repeat_analysis_result(value)
    if type(value.get("engine")) is str and value["engine"] == "local_content_alignment_v5":
        from .canonical_result_contract import validate_canonical_analysis_result
        return validate_canonical_analysis_result(value)
    if type(value.get("engine")) is str and value["engine"] == "local_content_alignment_v2":
        from .robust_result_contract import validate_robust_analysis_result
        return validate_robust_analysis_result(value)
    if type(value.get("engine")) is str and value["engine"] == "local_content_alignment_v3":
        from .context_result_contract import validate_context_analysis_result
        return validate_context_analysis_result(value)
    if type(value.get("engine")) is str and value["engine"] == "local_content_alignment_v4":
        from .instrument_result_contract import validate_instrument_analysis_result
        return validate_instrument_analysis_result(value)
    _json_tree(value)
    if type(value.get("schema_version")) is not int or value["schema_version"] != 1:
        _reject("unsupported_schema_version")
    if type(value.get("status")) is not str or value["status"] not in {"analyzed", "withheld", "error"}:
        _reject("unsupported_result_status")
    if "engine" in value and value["engine"] != ENGINE:
        _reject("unsupported_engine")
    if value["status"] == "error":
        _fields(value, {"schema_version", "status", "reason_code"}, {"engine"})
        _reason(value["reason_code"])
        return value
    if value.get("engine") != ENGINE:
        _reject("unsupported_engine")
    analyzed = value["status"] == "analyzed"
    _fields(value, _FULL_FIELDS | ({"alignment_segments"} if analyzed else set()))
    for field in ("complete_audio_approval", "commercial_performance_validated"):
        if value[field] is not False:
            _reject("invalid_approval_claim")
    reference, processed = _metadata(value["reference"]), _metadata(value["processed"])
    configuration = _fields(value["configuration"], {"profile", "allow_gain", "allow_resampling", "max_delay_ms"},
                            code="invalid_configuration")
    if type(configuration["profile"]) is not str or configuration["profile"] not in {"basic", "telephone"}:
        _reject("unsupported_profile")
    if any(type(configuration[name]) is not bool for name in ("allow_gain", "allow_resampling")):
        _reject("invalid_configuration")
    _number(configuration["max_delay_ms"], "invalid_configuration", 0, 5000)
    analysis = _fields(value["analysis"], {"sample_rate_hz", "hop_ms", "method", "minimum_event_duration_ms",
                                          "maximum_cumulative_edit_shift_ms", "diagnostic_rules_not_calibrated_probabilities"},
                       code="invalid_analysis_method")
    if (type(analysis["sample_rate_hz"]) is not int or analysis["sample_rate_hz"] != 8000
            or analysis["method"] != "constrained_edit_alignment_with_raw_anchors"
            or analysis["diagnostic_rules_not_calibrated_probabilities"] is not True):
        _reject("invalid_analysis_method")
    for name, expected in (("hop_ms", 10), ("minimum_event_duration_ms", 200),
                           ("maximum_cumulative_edit_shift_ms", 2000)):
        if _number(analysis[name], "invalid_analysis_method") != expected:
            _reject("invalid_analysis_method")
    diagnostics = _fields(value["diagnostics"], _DIAGNOSTIC_FIELDS if analyzed else set(),
                          set() if analyzed else _DIAGNOSTIC_FIELDS, code="invalid_diagnostics")
    for name, metric in diagnostics.items():
        if name in {"matched_analysis_samples", "anchor_run_count"}:
            _integer(metric, "invalid_diagnostics", 1 if analyzed else 0)
        elif name == "minimum_local_correlation":
            if metric is not None:
                _number(metric, "invalid_diagnostics", -1, 1)
        else:
            _number(metric, "invalid_diagnostics", 0 if name in {"normalized_path_cost", "matched_normalized_rmse"} else None)
    limitations = value["limitations"]
    if (type(limitations) is not list or not 1 <= len(limitations) <= 32
            or any(type(item) is not str or not 1 <= len(item) <= 2000 for item in limitations)):
        _reject("invalid_limitations")
    if not analyzed:
        if value["events"] is not None or value["content_preservation_status"] != "withheld":
            _reject("inconsistent_result_status")
        _reason(value["reason_code"])
        return value
    if (value["reason_code"] is not None or type(value["events"]) is not list
            or len(value["events"]) > 256):
        _reject("inconsistent_result_status")
    expected_content_status = "defect_candidates" if value["events"] else "no_supported_defect_candidates"
    if value["content_preservation_status"] != expected_content_status:
        _reject("inconsistent_result_status")
    if reference["sample_rate_hz"] != processed["sample_rate_hz"] and not configuration["allow_resampling"]:
        _reject("undeclared_resampling_in_analyzed_result")
    minimum_correlation = .90 if configuration["profile"] == "basic" else .82
    maximum_residual = .08 if configuration["profile"] == "basic" else .25
    if (diagnostics["matched_normalized_rmse"] > maximum_residual
            or (diagnostics["minimum_local_correlation"] is not None
                and diagnostics["minimum_local_correlation"] < minimum_correlation)):
        _reject("inconsistent_analyzed_metrics")
    previous_end = -1.0
    for event in value["events"]:
        start, end = _event(event, reference["duration_ms"], processed["duration_ms"], minimum_correlation)
        if start + _EPSILON_MS < previous_end:
            _reject("unordered_or_overlapping_events")
        previous_end = end
    segment_count = _segments(value["alignment_segments"], reference["duration_ms"], processed["duration_ms"],
                              not value["events"], configuration["max_delay_ms"], minimum_correlation)
    if diagnostics["anchor_run_count"] != segment_count:
        _reject("inconsistent_anchor_count")
    maximum_matched = math.ceil(min(reference["duration_ms"], processed["duration_ms"]) * 8)
    if not max(1600, .35 * maximum_matched) <= diagnostics["matched_analysis_samples"] <= maximum_matched:
        _reject("inconsistent_matched_sample_count")
    if diagnostics["gain_estimate"] <= 0 or diagnostics["applied_gain"] <= 0:
        _reject("invalid_analyzed_gain")
    expected_gain = diagnostics["gain_estimate"] if configuration["allow_gain"] else 1
    if not _same_number(diagnostics["applied_gain"], expected_gain):
        _reject("inconsistent_applied_gain")
    return value


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    value = {}
    for key, item in pairs:
        if key in value:
            _reject("duplicate_json_key")
        value[key] = item
    return value


def _invalid_constant(_: str) -> None:
    _reject("non_finite_metric")


def load_analysis_result(path: str | Path) -> dict:
    """Read at most one MiB of UTF-8 JSON, then enforce the strict contract.

    No raw audio is loaded, no referenced paths are followed, and filesystem or
    parsing errors never disclose the source path or file content.
    """
    try:
        with Path(path).open("rb") as stream:
            data = stream.read(MAX_RESULT_BYTES + 1)
    except (OSError, ValueError, TypeError):
        raise ResultContractError("result_file_read_error") from None
    if len(data) > MAX_RESULT_BYTES:
        _reject("result_file_too_large")
    try:
        value = json.loads(data.decode("utf-8"), object_pairs_hook=_unique_object,
                           parse_constant=_invalid_constant)
    except ResultContractError:
        raise
    except (UnicodeError, ValueError, RecursionError, OverflowError):
        raise ResultContractError("invalid_result_json") from None
    return validate_analysis_result(value)
