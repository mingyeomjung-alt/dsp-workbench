"""Bounded all-output feasibility for one canonical source edit and one gain.

Every 1 ms boundary inside the supplied supported-context bracket is visited.
The fixed quantized forward model, not a correlation score, decides feasibility.
This class excludes arbitrary insertion histories and is not edit provenance.
"""

from __future__ import annotations

import math

import numpy as np
from scipy.signal import resample_poly

from . import instrument_engine as raw
from .compound_gain import MAX_NODES as GAIN_MAX_NODES, _render, _valid_pcm, quantization_bound, solve_gain
from .engine import _locate


GRID = 8  # 1 ms at the comparison rate; 16 source samples.
FIR_RADIUS = 10  # 41 taps at 16 kHz, centered 1:2 output support.
MAX_CANDIDATES = 2401
MAX_GAIN_NODES = 16384
POSITION_TOLERANCE = 160  # 20 ms, fixed identifiability convention.


def _edited_source(source: np.ndarray, point: int, length: int, kind: str) -> np.ndarray:
    first, count = 2 * point, 2 * length
    if kind == "delete":
        return np.concatenate((source[:first], source[first + count:]))
    return np.concatenate((source[:first], source[first - count:first], source[first:]))


def _copy_context_gate(reference: np.ndarray, point: int, length: int) -> tuple[bool, str]:
    """Conservative supported-source gate, not arbitrary-history exclusion.

    A full copied span has to be active and its FIR-safe interior globally
    unique under the existing fixed raw-NCC entry criteria. All feasible edit
    geometries still need exact forward proof; this gate never approves one.
    """
    first = point - length
    copied = reference[first:point]
    if len(copied) != length or float(np.std(copied)) <= 1e-6:
        return False, "copy_source_not_active"
    interior = reference[first + FIR_RADIUS:point - FIR_RADIUS]
    if len(interior) < 3 or float(np.std(interior)) <= 1e-6:
        return False, "copy_source_interior_not_active"
    located = _locate(interior, reference, 0, len(reference) - len(interior))
    if (located is None or located["start"] != first + FIR_RADIUS
            or located["correlation"] < raw.MIN_CORRELATION
            or located["peak_margin"] is None
            or located["peak_margin"] < raw.MIN_MARGIN):
        return False, "copy_source_ncc_entry_gate_not_unique"
    return True, "supported_source_ncc_gate"


def prove_event(source, target, kind: str, length: int, lower: int, upper: int) -> tuple[dict | None, dict]:
    """Return an exact witness only after exhaustive supported-grid exclusion.

    ``point`` is deletion start or canonical repeat divider, both at 8 kHz.
    The repeat source is exactly ``[point-length, point]`` in the reference.
    Inputs are complete PCM16 arrays, 16 kHz reference and delay-free 8 kHz
    target. A gain-search budget/depth failure prevents uniqueness, even if a
    different geometry already has a witness. No best-score or top-k cutoff.
    """
    trace = {"search_complete": False, "reason_code": None,
             "boundary_grid_ms": 1, "fir_radius_output_samples": FIR_RADIUS,
             "supported_boundary_bracket_samples": [lower, upper],
             "maximum_candidates": MAX_CANDIDATES,
             "maximum_gain_nodes": MAX_GAIN_NODES,
             "candidates_checked": 0, "gain_nodes_used": 0,
             "feasible_candidate_count": 0, "feasible_boundary_samples": [],
             "source_gate_rejected_count": 0,
             "source_gate": "active_full_source_and_global_raw_ncc_interior_entry_gate",
             "source_gate_is_arbitrary_history_proof": False,
             "every_supported_boundary_checked": False}

    def finish(reason: str, complete: bool, proof: dict | None = None):
        trace.update(reason_code=reason, search_complete=complete)
        return proof, trace

    original, observed = _valid_pcm(source), _valid_pcm(target)
    if (original is None or observed is None or len(original) % 2
            or kind not in {"delete", "repeat"}
            or any(type(v) is not int for v in (length, lower, upper))
            or not 1600 <= length <= 16000 or length % GRID
            or lower < 0 or upper < lower):
        return finish("compound_event_invalid_supported_geometry", True)
    count = len(original) // 2
    expected = count - length if kind == "delete" else count + length
    if len(observed) != expected:
        return finish("compound_event_length_hypothesis_not_supported", True)
    first = ((lower + GRID - 1) // GRID) * GRID
    last = (upper // GRID) * GRID
    candidate_count = max(0, (last - first) // GRID + 1)
    trace["supported_candidate_count"] = candidate_count
    if not candidate_count:
        return finish("compound_event_no_supported_boundary", True)
    if MAX_CANDIDATES <= 0 or candidate_count > MAX_CANDIDATES or MAX_GAIN_NODES <= 0:
        return finish("compound_event_proof_budget_exceeded", False)

    reference = resample_poly(original, 1, 2)
    feasible: list[dict] = []
    floor = quantization_bound() / math.sqrt(1 - .90 ** 2)
    for point in range(first, last + 1, GRID):
        trace["candidates_checked"] += 1
        if (point <= 0 or point >= count
                or (kind == "delete" and point + length >= count)
                or (kind == "repeat" and point - length < 0)):
            continue
        if kind == "repeat":
            admitted, reason = _copy_context_gate(reference, point, length)
            if not admitted:
                trace["source_gate_rejected_count"] += 1
                trace["last_source_gate_rejection"] = reason
                continue
        elif float(np.std(reference[point:point + length])) <= 1e-6:
            trace["source_gate_rejected_count"] += 1
            trace["last_source_gate_rejection"] = "deleted_source_not_active"
            continue
        # The remaining gain-node budget is deterministic. Each individual
        # solver has its own fixed 128-node cap and never returns a partial
        # result as a successful witness.
        # Reserve the unchanged solver's entire node cap before starting it;
        # a call cannot run past the fixed total budget and then be counted.
        if trace["gain_nodes_used"] + GAIN_MAX_NODES > MAX_GAIN_NODES:
            return finish("compound_event_proof_budget_exceeded", False)
        edited = _edited_source(original, point, length, kind)
        witness, gain_trace = solve_gain(edited, observed)
        trace["gain_nodes_used"] += gain_trace.get("nodes_visited", 0)
        if trace["gain_nodes_used"] > MAX_GAIN_NODES:
            return finish("compound_event_proof_budget_exceeded", False)
        if not gain_trace.get("search_complete", False):
            trace["incomplete_gain_search_boundary_samples"] = point
            trace["incomplete_gain_search_reason"] = gain_trace.get("reason_code")
            return finish("compound_event_gain_search_incomplete", False)
        if witness is None:
            continue
        rendered, gain = witness.get("rendered"), witness.get("gain")
        if (type(gain) not in (float, int) or not math.isfinite(gain) or gain <= 0
                or not isinstance(rendered, np.ndarray)
                or rendered.ndim != 1 or len(rendered) != len(observed)
                or not np.array_equal(rendered, observed)):
            return finish("compound_event_invalid_exact_witness", False)
        independently_rendered = _render(edited, float(gain))
        if independently_rendered is None or not np.array_equal(independently_rendered, observed):
            return finish("compound_event_invalid_exact_witness", False)
        source_interval = (point, point + length) if kind == "delete" else (point - length, point)
        if float(np.std(gain * reference[slice(*source_interval)])) <= floor:
            trace["source_gate_rejected_count"] += 1
            trace["last_source_gate_rejection"] = "event_source_below_quantization_resolution"
            continue
        feasible.append({"point": point, "length": length, "kind": kind,
                         "gain": float(gain), "rendered": rendered,
                         "gain_search_trace": gain_trace})
        trace["feasible_boundary_samples"].append(point)
        trace["feasible_candidate_count"] = len(feasible)
        if feasible[-1]["point"] - feasible[0]["point"] > POSITION_TOLERANCE:
            return finish("compound_event_ambiguous_boundary", False)

    trace["every_supported_boundary_checked"] = True
    if not feasible:
        return finish("compound_event_no_exact_event_witness", True)
    # Selection is deterministic only after all admitted geometries have been
    # checked. Gain is a witness, not a unique coefficient or provenance claim.
    selected = feasible[0]
    trace["feasible_boundary_spread_samples"] = feasible[-1]["point"] - feasible[0]["point"]
    trace["selected_boundary_samples"] = selected["point"]
    trace["gain_witness"] = selected["gain"]
    trace["gain_is_unique_or_processing_provenance"] = False
    trace["every_output_sample_exact"] = True
    trace["exact_output_sample_count"] = len(observed)
    return finish("compound_event_exact_supported_witness", True, selected)
