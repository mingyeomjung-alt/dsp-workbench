"""Direct global alignment baseline, not a content-preservation decision.

Positive delay means the processed file is later than the reference. Correlation
is overlap-normalized and mean-centered per lag. A single global offset cannot
localize deletion or repetition: no defect event list is produced in M1.
"""

from dataclasses import dataclass
import math
from numbers import Real
from pathlib import Path

import numpy as np
from scipy.signal import correlate, correlation_lags, resample_poly

from .audio import WavAudio, read_wav


ANALYSIS_RATE_HZ = 8_000
MIN_OVERLAP_SECONDS = 1.5
MIN_CORRELATION = 0.35
MIN_PEAK_MARGIN = 0.03
PEAK_EXCLUSION_MS = 20.0
MIN_CENTERED_RMS = 1e-6


class BaselineConfigError(ValueError):
    def __init__(self, message: str):
        self.code = "invalid_configuration"
        super().__init__(message)


@dataclass(frozen=True)
class BaselineConfig:
    allow_resampling: bool = False
    allow_gain: bool = False
    max_delay_ms: float = 1_000.0

    def __post_init__(self) -> None:
        if type(self.allow_resampling) is not bool or type(self.allow_gain) is not bool:
            raise BaselineConfigError("Transformation declarations must be boolean.")
        if isinstance(self.max_delay_ms, bool) or not isinstance(self.max_delay_ms, Real):
            raise BaselineConfigError("max_delay_ms must be finite and between 0 and 5000.")
        try:
            maximum_delay = float(self.max_delay_ms)
        except (OverflowError, TypeError, ValueError):
            raise BaselineConfigError("max_delay_ms must be finite and between 0 and 5000.") from None
        if not math.isfinite(maximum_delay) or not 0 <= maximum_delay <= 5_000:
            raise BaselineConfigError("max_delay_ms must be finite and between 0 and 5000.")
        object.__setattr__(self, "max_delay_ms", maximum_delay)


def _analysis_samples(audio: WavAudio) -> np.ndarray:
    if audio.sample_rate_hz == ANALYSIS_RATE_HZ:
        return np.asarray(audio.samples, dtype=np.float64)
    divisor = math.gcd(audio.sample_rate_hz, ANALYSIS_RATE_HZ)
    return resample_poly(
        audio.samples, ANALYSIS_RATE_HZ // divisor,
        audio.sample_rate_hz // divisor,
    ).astype(np.float64, copy=False)


def _metrics(reference: np.ndarray, processed: np.ndarray) -> dict:
    count = min(len(reference), len(processed))
    x, y = reference[:count], processed[:count]
    ref_rms = float(np.sqrt(np.mean(x * x)))
    processed_rms = float(np.sqrt(np.mean(y * y)))
    rmse = float(np.sqrt(np.mean((y - x) ** 2)))
    return {
        "rmse": rmse,
        "normalized_rmse": rmse / max(ref_rms, 1e-12),
        "reference_rms": ref_rms,
        "processed_rms": processed_rms,
        "sample_count": count,
        "domain": "analysis_samples_at_8000_hz",
    }


def _prefix(values: np.ndarray) -> np.ndarray:
    return np.concatenate(([0.0], np.cumsum(values, dtype=np.float64)))


def _lag_scores(x: np.ndarray, y: np.ndarray, max_delay_ms: float):
    # scipy correlate(y, x) yields positive lag when y follows x.
    all_products = correlate(y, x, mode="full", method="fft")
    all_lags = correlation_lags(len(y), len(x), mode="full")
    maximum_lag = round(max_delay_ms * ANALYSIS_RATE_HZ / 1_000)
    ref_start = np.maximum(0, -all_lags)
    ref_end = np.minimum(len(x), len(y) - all_lags)
    overlap = ref_end - ref_start
    minimum_overlap = max(
        round(MIN_OVERLAP_SECONDS * ANALYSIS_RATE_HZ),
        math.ceil(0.5 * min(len(x), len(y))),
    )
    keep = (np.abs(all_lags) <= maximum_lag) & (overlap >= minimum_overlap)
    lags = all_lags[keep]
    starts, ends, counts = ref_start[keep], ref_end[keep], overlap[keep]
    if not len(lags):
        return lags, np.array([], dtype=np.float64), starts, ends
    y_starts, y_ends = starts + lags, ends + lags
    sx, sy = _prefix(x), _prefix(y)
    sxx, syy = _prefix(x * x), _prefix(y * y)
    sums_x, sums_y = sx[ends] - sx[starts], sy[y_ends] - sy[y_starts]
    energy_x = np.maximum(0.0, sxx[ends] - sxx[starts] - sums_x ** 2 / counts)
    energy_y = np.maximum(0.0, syy[y_ends] - syy[y_starts] - sums_y ** 2 / counts)
    denominators = np.sqrt(energy_x * energy_y)
    covariance = all_products[keep] - sums_x * sums_y / counts
    scores = np.full(len(lags), -np.inf, dtype=np.float64)
    valid = ((energy_x / counts > MIN_CENTERED_RMS ** 2)
             & (energy_y / counts > MIN_CENTERED_RMS ** 2))
    scores[valid] = np.clip(covariance[valid] / denominators[valid], -1.0, 1.0)
    return lags, scores, starts, ends


def compare_buffers(
    reference: WavAudio,
    processed: WavAudio,
    config: BaselineConfig | None = None,
) -> dict:
    """Measure a global offset without accepting ground truth or event hints."""
    settings = config if config is not None else BaselineConfig()
    if not isinstance(settings, BaselineConfig):
        raise BaselineConfigError("Use a BaselineConfig instance.")
    result = {
        "schema_version": 1,
        "engine": "global_alignment_baseline_v1",
        "status": "withheld",
        "reason_code": None,
        "content_preservation_status": "not_assessed_by_global_baseline",
        "events": None,
        "reference": reference.metadata(),
        "processed": processed.metadata(),
        "configuration": {
            "allow_resampling": settings.allow_resampling,
            "allow_gain": settings.allow_gain,
            "max_delay_ms": settings.max_delay_ms,
        },
        "analysis": {
            "sample_rate_hz": ANALYSIS_RATE_HZ,
            "method": "overlap_centered_normalized_cross_correlation",
            "minimum_correlation": MIN_CORRELATION,
            "minimum_peak_margin": MIN_PEAK_MARGIN,
            "peak_exclusion_ms": PEAK_EXCLUSION_MS,
            "thresholds_are_uncalibrated_diagnostics": True,
            "analysis_resampling_applied": (
                reference.sample_rate_hz != ANALYSIS_RATE_HZ
                or processed.sample_rate_hz != ANALYSIS_RATE_HZ
            ),
        },
        "alignment": {
            "estimated_delay_ms": None,
            "correlation": None,
            "alternative_correlation": None,
            "gain_estimate": None,
            "applied_gain": None,
            "overlap_ms": None,
            "ambiguous": False,
        },
        "metrics": {"raw": None, "aligned": None},
        "diagnostics": {},
        "limitations": [
            "Global offset only; local deletion and repetition are not assessed.",
            "A measured correlation is not a probability or a pass decision.",
            "Difference metrics use 8 kHz analysis samples, not full-band input samples.",
            "Codec robustness and natural-audio performance are not validated.",
        ],
    }
    if (reference.sample_rate_hz != processed.sample_rate_hz
            and not settings.allow_resampling):
        result["reason_code"] = "resampling_not_declared"
        return result
    # Do not let resampling boundary transients manufacture alignment evidence
    # from a constant/DC source. Inspect the unprocessed samples first.
    if min(float(np.std(reference.samples)), float(np.std(processed.samples))) <= MIN_CENTERED_RMS:
        result["reason_code"] = "insufficient_signal_energy"
        return result
    x, y = _analysis_samples(reference), _analysis_samples(processed)
    result["metrics"]["raw"] = _metrics(x, y)
    if min(float(np.std(x)), float(np.std(y))) <= MIN_CENTERED_RMS:
        result["reason_code"] = "insufficient_signal_energy"
        return result
    lags, scores, starts, ends = _lag_scores(x, y, settings.max_delay_ms)
    if not len(scores) or not np.any(np.isfinite(scores)):
        result["reason_code"] = "insufficient_overlap"
        return result
    best_index = int(np.argmax(scores))
    best_lag, best_score = int(lags[best_index]), float(scores[best_index])
    separated = np.abs(lags - best_lag) > round(PEAK_EXCLUSION_MS * ANALYSIS_RATE_HZ / 1_000)
    alternate_scores = scores[separated & np.isfinite(scores)]
    alternate = float(np.max(alternate_scores)) if len(alternate_scores) else None
    margin = best_score - alternate if alternate is not None else None
    result["alignment"]["correlation"] = best_score
    result["alignment"]["alternative_correlation"] = alternate
    result["diagnostics"] = {
        "best_candidate_delay_ms": best_lag * 1_000 / ANALYSIS_RATE_HZ,
        "peak_margin": margin,
        "searched_lag_count": len(lags),
    }
    if best_score < MIN_CORRELATION:
        result["reason_code"] = "weak_correspondence"
        return result
    if margin is not None and margin < MIN_PEAK_MARGIN:
        result["alignment"]["ambiguous"] = True
        result["reason_code"] = "ambiguous_alignment"
        return result
    if settings.max_delay_ms > 0 and abs(best_lag) == round(
        settings.max_delay_ms * ANALYSIS_RATE_HZ / 1_000
    ):
        # The best value may be outside the search budget; do not certify it.
        result["reason_code"] = "delay_at_search_boundary"
        return result
    start, end = int(starts[best_index]), int(ends[best_index])
    aligned_x, aligned_y = x[start:end], y[start + best_lag:end + best_lag]
    gain = float(np.dot(aligned_x, aligned_y) / np.dot(aligned_x, aligned_x))
    if not math.isfinite(gain) or gain <= 0:
        result["reason_code"] = "unsupported_gain_or_polarity"
        return result
    applied_gain = gain if settings.allow_gain else 1.0
    result["status"] = "measured"
    result["alignment"].update({
        "estimated_delay_ms": best_lag * 1_000 / ANALYSIS_RATE_HZ,
        "gain_estimate": gain,
        "applied_gain": applied_gain,
        "overlap_ms": (end - start) * 1_000 / ANALYSIS_RATE_HZ,
        "reference_overlap_start_ms": start * 1_000 / ANALYSIS_RATE_HZ,
        "processed_overlap_start_ms": (start + best_lag) * 1_000 / ANALYSIS_RATE_HZ,
    })
    result["metrics"]["aligned"] = _metrics(applied_gain * aligned_x, aligned_y)
    return result


def compare_wavs(
    reference_path: str | Path,
    processed_path: str | Path,
    config: BaselineConfig | None = None,
) -> dict:
    return compare_buffers(read_wav(reference_path), read_wav(processed_path), config)
