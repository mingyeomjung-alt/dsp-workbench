"""Local file-pair CLI; output files are created exclusively, never replaced."""

import argparse
import json
import math
from pathlib import Path
import sys

from .audio import AudioInputError
from .baseline import BaselineConfig, BaselineConfigError, compare_wavs
from .fixtures import generate_case
from .engine import EngineConfigError
from .api import analyze_pair
from .result_contract import ResultContractError, _metadata, validate_analysis_result


def _json_text(value: dict) -> str:
    return json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n"


def _validate_comparison_result(result: dict) -> None:
    """Guard the global baseline envelope, without adding a pass decision."""
    required = {
        "schema_version", "engine", "status", "reason_code",
        "content_preservation_status", "events", "reference", "processed",
        "configuration", "analysis", "alignment", "metrics", "diagnostics",
        "limitations",
    }
    if set(result) != required:
        raise ResultContractError("invalid_comparison_result_structure")
    if (result["events"] is not None
            or result["content_preservation_status"] != "not_assessed_by_global_baseline"):
        raise ResultContractError("invalid_comparison_result_structure")
    for field in ("reference", "processed", "configuration", "analysis",
                  "alignment", "metrics", "diagnostics"):
        if type(result[field]) is not dict:
            raise ResultContractError("invalid_comparison_result_structure")
    # Both commands read strict WAV files. Reuse their existing metadata
    # contract so malformed/private payloads cannot masquerade as measurements.
    _metadata(result["reference"])
    _metadata(result["processed"])
    if (type(result["limitations"]) is not list or not result["limitations"]
            or any(type(item) is not str for item in result["limitations"])):
        raise ResultContractError("invalid_comparison_result_structure")
    if result["status"] == "withheld":
        validate_analysis_result({"schema_version": 1, "status": "error",
                                  "reason_code": result["reason_code"]})
        return
    if result["reason_code"] is not None:
        raise ResultContractError("inconsistent_result_status")
    for name in ("estimated_delay_ms", "correlation", "gain_estimate",
                 "applied_gain", "overlap_ms"):
        value = result["alignment"].get(name)
        if type(value) not in (int, float):
            raise ResultContractError("invalid_comparison_metric")
        try:
            finite = math.isfinite(value)
        except OverflowError:
            finite = False
        if not finite:
            raise ResultContractError("non_finite_metric")
        if (name == "correlation" and not -1 <= value <= 1
                or name in {"gain_estimate", "applied_gain", "overlap_ms"} and value <= 0):
            raise ResultContractError("invalid_comparison_metric")
    if any(type(result["metrics"].get(name)) is not dict for name in ("raw", "aligned")):
        raise ResultContractError("invalid_comparison_result_structure")


def _validated_result_text(result: object, args: argparse.Namespace) -> str:
    """Reject malformed engine responses before stdout or output creation."""
    if type(result) is not dict:
        raise ResultContractError("invalid_result_type")
    if type(result.get("schema_version")) is not int or result["schema_version"] != 1:
        raise ResultContractError("unsupported_schema_version")
    expected_engine = (
        f"local_content_alignment_{args.engine}" if args.command == "analyze"
        else "global_alignment_baseline_v1" if args.command == "compare" else None
    )
    if "engine" in result and result["engine"] != expected_engine:
        raise ResultContractError("unsupported_engine")
    if result.get("status") == "error":
        # Baseline errors may identify that baseline; validate the unchanged
        # tiny error envelope separately from the temporal engine contract.
        validate_analysis_result({key: value for key, value in result.items() if key != "engine"})
    elif args.command == "analyze":
        validate_analysis_result(result)
    elif args.command == "compare":
        if type(result.get("status")) is not str or result["status"] not in {"measured", "withheld"}:
            raise ResultContractError("unsupported_result_status")
        if result.get("engine") != expected_engine:
            raise ResultContractError("unsupported_engine")
        _validate_comparison_result(result)
    else:
        required = {"schema_version", "status", "source_kind", "reference", "processed",
                    "ground_truth", "limitation"}
        if (set(result) != required or result["status"] != "generated"
                or result["source_kind"] != "synthetic_test_signal"
                or any(type(result[field]) is not str for field in
                       ("reference", "processed", "ground_truth", "limitation"))):
            raise ResultContractError("invalid_generation_result")
    try:
        return _json_text(result)
    except (ValueError, TypeError, RecursionError, OverflowError):
        raise ResultContractError("invalid_result_json") from None


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="audio-regression",
        description="Local diagnostic content candidates and global alignment baseline.",
    )
    commands = parser.add_subparsers(dest="command", required=True)
    generate = commands.add_parser("generate", help="Create a new synthetic test pair directory.")
    generate.add_argument("--output-dir", type=Path, required=True)
    generate.add_argument("--kind", choices=("clean", "delete", "repeat"), default="clean")
    generate.add_argument("--seed", type=int, default=20261012)
    generate.add_argument("--duration-seconds", type=float, default=6.0)
    generate.add_argument("--sample-rate-hz", type=int, default=16000)
    generate.add_argument("--delay-ms", type=float, default=0.0)
    generate.add_argument("--gain-db", type=float, default=0.0)
    generate.add_argument("--interval-start-ms", type=float, default=2000.0)
    generate.add_argument("--interval-duration-ms", type=float, default=400.0)
    compare = commands.add_parser("compare", help="Measure a global delay and differences.")
    compare.add_argument("--reference", type=Path, required=True)
    compare.add_argument("--processed", type=Path, required=True)
    compare.add_argument("--declare-resampling", action="store_true")
    compare.add_argument("--declare-gain", action="store_true")
    compare.add_argument("--max-delay-ms", type=float, default=1000.0)
    compare.add_argument("--output", type=Path)
    analyze = commands.add_parser("analyze", help="Localize supported internal deletion or repetition candidates.")
    analyze.add_argument("--reference", type=Path, required=True)
    analyze.add_argument("--processed", type=Path, required=True)
    analyze.add_argument("--profile", choices=("basic", "telephone"), default="basic")
    analyze.add_argument("--engine", choices=("v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12"), default="v1",
                         help="v1 baseline (default); v2 through v12 are explicit research candidates.")
    analyze.add_argument("--declare-resampling", action="store_true")
    analyze.add_argument("--resampling-model", help="Explicit v12 resampler ID; never inferred from the files.")
    analyze.add_argument("--declare-gain", action="store_true")
    analyze.add_argument("--max-delay-ms", type=float, default=1000.0)
    analyze.add_argument("--output", type=Path)
    return parser


def _generate(args: argparse.Namespace) -> dict:
    # Validate and render first. No personal recordings or model downloads.
    case = generate_case(
        args.kind, seed=args.seed, duration_seconds=args.duration_seconds,
        sample_rate_hz=args.sample_rate_hz, delay_ms=args.delay_ms,
        gain_db=args.gain_db, interval_start_ms=args.interval_start_ms,
        interval_duration_ms=args.interval_duration_ms,
    )
    truth_text = _json_text(case.ground_truth)
    destination = args.output_dir.resolve()
    destination.mkdir(parents=True, exist_ok=False)
    reference = destination / "reference.wav"
    processed = destination / "processed.wav"
    truth = destination / "ground_truth.json"
    with reference.open("xb") as stream:
        stream.write(case.reference_wav)
    with processed.open("xb") as stream:
        stream.write(case.processed_wav)
    with truth.open("x", encoding="utf-8") as stream:
        stream.write(truth_text)
    return {
        "schema_version": 1,
        "status": "generated",
        "source_kind": "synthetic_test_signal",
        "reference": str(reference),
        "processed": str(processed),
        "ground_truth": str(truth),
        "limitation": "Generated fixtures are not independent natural-audio performance evidence.",
    }


def main(argv: list[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    try:
        if args.command == "generate":
            result = _generate(args)
            result_text = _validated_result_text(result, args)
        else:
            # Comparator cannot read ground_truth.json or scenario parameters.
            if args.output is not None and args.output.exists():
                raise FileExistsError("An output file already exists.")
            if args.command == "analyze":
                result = analyze_pair(
                    args.reference, args.processed,
                    profile=args.profile, allow_resampling=args.declare_resampling,
                    allow_gain=args.declare_gain, max_delay_ms=args.max_delay_ms,
                    **({"engine": args.engine} if args.engine != "v1" else {}),
                    **({"resampling_model": args.resampling_model} if args.resampling_model is not None else {}),
                )
            else:
                result = compare_wavs(
                    args.reference, args.processed,
                    BaselineConfig(
                        allow_resampling=args.declare_resampling,
                        allow_gain=args.declare_gain,
                        max_delay_ms=args.max_delay_ms,
                    ),
                )
            result_text = _validated_result_text(result, args)
            if args.output is not None:
                with args.output.open("x", encoding="utf-8") as stream:
                    stream.write(result_text)
        sys.stdout.write(result_text)
        return {"error": 3, "withheld": 2}.get(result["status"], 0)
    except (AudioInputError, BaselineConfigError, EngineConfigError) as exc:
        error = {"schema_version": 1, "status": "error", "reason_code": exc.code}
    except ResultContractError as exc:
        error = {"schema_version": 1, "status": "error", "reason_code": exc.code}
    except FileExistsError:
        error = {"schema_version": 1, "status": "error", "reason_code": "output_exists"}
    except ValueError:
        code = "invalid_generation_parameters" if args.command == "generate" else "internal_processing_error"
        error = {"schema_version": 1, "status": "error", "reason_code": code}
    except OSError:
        error = {"schema_version": 1, "status": "error", "reason_code": "file_write_error"}
    except Exception:
        # Unexpected engine failures are not successful analyses and must not
        # disclose exception text, private file paths, or a traceback.
        error = {"schema_version": 1, "status": "error", "reason_code": "internal_processing_error"}
    sys.stdout.write(_json_text(error))
    return 3

