"""Strict saved pipeline results and an offline, static Korean handoff report.

This module presents saved diagnostics. It never reads audio, reruns analysis,
follows artifact paths, or treats the earliest observed concern as its cause.
"""

from __future__ import annotations

from html import escape
import json
import math
from pathlib import Path, PurePosixPath
import re
import unicodedata

from .check_policy import check_result
from .pipeline_transforms import PipelineTransformError, validate_stage
from .result_contract import ResultContractError, validate_analysis_result
from .review_presenter import render_review_diagnostics


MAX_PIPELINE_RESULT_BYTES = 4 * 1024 * 1024
ENGINE = "audio_pipeline_regression_v1"
_ANALYSIS_ENGINES = {ENGINE: "local_content_alignment_v1",
                     "audio_pipeline_regression_v2": "local_content_alignment_v2",
                     "audio_pipeline_regression_v3": "local_content_alignment_v3",
                     "audio_pipeline_regression_v4": "local_content_alignment_v4",
                     "audio_pipeline_regression_v5": "local_content_alignment_v5",
                     "audio_pipeline_regression_v6": "local_content_alignment_v6",
                     "audio_pipeline_regression_v7": "local_content_alignment_v7",
                     "audio_pipeline_regression_v8": "local_content_alignment_v8",
                     "audio_pipeline_regression_v9": "local_content_alignment_v9",
                     "audio_pipeline_regression_v10": "local_content_alignment_v10",
                     "audio_pipeline_regression_v11": "local_content_alignment_v11"}
_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}\Z")
_HASH = re.compile(r"[0-9a-f]{64}\Z")
_GATES = {0: "clear_supported_temporal_check", 1: "review_required", 2: "blocked"}
_TOP = {"schema_version", "engine", "status", "source", "comparison_scope", "stages",
        "end_to_end", "summary", "complete_audio_approval", "commercial_performance_validated",
        "network_used", "fault_provenance_confirmed"}
_STAGE = {"index", "label", "operation", "input", "output", "status", "analysis", "check",
          "input_snapshot", "output_snapshot", "analysis_artifact", "check_artifact",
          "reason_code", "runtime_ms"}
_SUMMARY = {"gate_state", "exit_code", "first_concern", "planned_stage_count",
            "executed_stage_count", "failed_stage"}
_METADATA = {"sample_rate_hz", "sample_count", "duration_ms", "channels", "encoding",
             "rms", "peak", "sha256"}
_LOCAL_PATH = re.compile(
    r"(?:[A-Za-z]:[\\/]|\\\\|file://|/(?:Users|home|tmp|mnt|var|etc)/)[^\s<>\"']*"
    r"|(?<!\S)/(?!/)[^\s<>\"']+", re.IGNORECASE,
)


class PipelineReportError(ValueError):
    """A stable rejection code that does not disclose saved input content."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__("Pipeline result violates the report contract.")


def _reject(code: str) -> None:
    raise PipelineReportError(code)


def _fields(value: object, expected: set[str], code: str = "invalid_pipeline_structure") -> dict:
    if type(value) is not dict or set(value) != expected:
        _reject(code)
    return value


def _number(value: object, code: str, minimum: float = 0, maximum: float | None = None) -> int | float:
    if type(value) not in (int, float):
        _reject(code)
    try:
        finite = math.isfinite(value)
    except OverflowError:
        finite = False
    if not finite:
        _reject("non_finite_metric")
    if value < minimum or (maximum is not None and value > maximum):
        _reject(code)
    return value


def _tree(value: object, depth: int = 0, budget: list[int] | None = None) -> None:
    remaining = [100_000] if budget is None else budget
    remaining[0] -= 1
    if depth > 32 or remaining[0] < 0:
        _reject("pipeline_structure_too_large")
    if value is None or type(value) is bool:
        return
    if type(value) is str:
        if len(value) > 16_384:
            _reject("pipeline_structure_too_large")
        return
    if type(value) in (int, float):
        _number(value, "invalid_numeric_value", -1e100, 1e100)
    elif type(value) is list:
        for item in value:
            _tree(item, depth + 1, remaining)
    elif type(value) is dict:
        for key, item in value.items():
            if type(key) is not str or len(key) > 256:
                _reject("invalid_json_value")
            _tree(item, depth + 1, remaining)
    else:
        _reject("invalid_json_value")


def _integer(value: object, code: str, minimum: int, maximum: int) -> int:
    if type(value) is not int or not minimum <= value <= maximum:
        _reject(code)
    return value


def _label(value: object) -> None:
    if (type(value) is not str or not 1 <= len(value) <= 80 or not value.strip()
            or any(unicodedata.category(char) in {"Cc", "Cf", "Cs"} for char in value)):
        _reject("invalid_stage_label")


def _reason(value: object) -> None:
    if type(value) is not str or _CODE.fullmatch(value) is None:
        _reject("invalid_reason_code")


def _relative_path(value: object) -> str:
    if (type(value) is not str or not 1 <= len(value) <= 240 or "\\" in value
            or ":" in value or "%" in value or "?" in value or "#" in value
            or any(unicodedata.category(char) in {"Cc", "Cf", "Cs"} for char in value)):
        _reject("unsafe_artifact_path")
    path = PurePosixPath(value)
    if (path.is_absolute() or any(part in {"", ".", ".."} for part in value.split("/"))
            or str(path) != value or any(part.endswith((".", " ")) for part in path.parts)):
        _reject("unsafe_artifact_path")
    return value


def _metadata(value: object) -> dict:
    data = _fields(value, _METADATA, "invalid_audio_metadata")
    rate = _integer(data["sample_rate_hz"], "invalid_audio_metadata", 1, 48000)
    if rate not in {8000, 16000, 44100, 48000}:
        _reject("invalid_audio_metadata")
    count = _integer(data["sample_count"], "invalid_audio_metadata", 2 * rate, 30 * rate)
    duration = _number(data["duration_ms"], "invalid_audio_metadata", 2000, 30000)
    if not math.isclose(duration, count * 1000 / rate, rel_tol=1e-12, abs_tol=1e-6):
        _reject("inconsistent_audio_duration")
    if type(data["channels"]) is not int or data["channels"] != 1 or data["encoding"] != "pcm16":
        _reject("invalid_audio_metadata")
    rms = _number(data["rms"], "invalid_audio_metadata", 0, 1)
    peak = _number(data["peak"], "invalid_audio_metadata", 0, 1)
    if rms > peak + 1e-12 or type(data["sha256"]) is not str or not _HASH.fullmatch(data["sha256"]):
        _reject("invalid_audio_metadata")
    return data


def _same_json(first: object, second: object) -> bool:
    """JSON equality preserves number and boolean types in policy fields."""
    if type(first) is not type(second):
        return False
    if type(first) is dict:
        return set(first) == set(second) and all(_same_json(first[key], second[key]) for key in first)
    if type(first) is list:
        return len(first) == len(second) and all(_same_json(a, b) for a, b in zip(first, second))
    return first == second


def _operation_output(operation: dict, source: dict, output: dict) -> None:
    """Check deterministic count/rate geometry without loading any audio."""
    rate = source["sample_rate_hz"]
    count = source["sample_count"]
    kind = operation["kind"]
    if kind == "resample":
        target = operation["target_rate_hz"]
        expected_count = (count * target + rate - 1) // rate
        expected_rate = target
    elif kind == "split_join":
        chunk = round(rate * operation["segment_ms"] / 1000)
        chunk_count = (count + chunk - 1) // chunk
        order = operation.get("order", range(chunk_count))
        if any(index >= chunk_count for index in order):
            _reject("inconsistent_operation_output")
        expected_count = sum(min(chunk, count - index * chunk) for index in order)
        expected_rate = rate
    else:
        expected_count, expected_rate = count, rate
    if output["sample_count"] != expected_count or output["sample_rate_hz"] != expected_rate:
        _reject("inconsistent_operation_output")


def _analysis_check(analysis: object, saved_check: object, status: str,
                    reference: dict, processed: dict | None,
                    analysis_engine: str = "local_content_alignment_v1") -> dict:
    try:
        valid = validate_analysis_result(analysis)
    except ResultContractError as exc:
        raise PipelineReportError("analysis_" + exc.code) from None
    if valid["status"] != status:
        _reject("inconsistent_analysis_status")
    # Generic engine-less errors are allowed, but an explicit identity must
    # match the enclosing pipeline even when that branch is already blocked.
    if valid.get("engine", analysis_engine) != analysis_engine:
        _reject("inconsistent_analysis_engine")
    expected_check = check_result(valid)
    if type(saved_check) is not dict or not _same_json(saved_check, expected_check):
        _reject("inconsistent_saved_check")
    if status != "error" and (valid["reference"] != reference or valid["processed"] != processed):
        _reject("inconsistent_analysis_metadata")
    return expected_check


def _configuration(analysis: dict, allow_gain: bool, allow_resampling: bool) -> None:
    if analysis["status"] == "error":
        return
    expected = {"profile": "basic", "allow_gain": allow_gain,
                "allow_resampling": allow_resampling, "max_delay_ms": 1000.0}
    if analysis["configuration"] != expected:
        _reject("inconsistent_analysis_configuration")


def _concern(scope: str, stage: dict | None, check: dict, status: str) -> dict | None:
    if check["exit_code"] == 0:
        return None
    category = ("execution_error" if status == "error" else
                "defect_candidates" if check["exit_code"] == 1 else "withheld")
    return {"scope": scope, "stage_index": stage["index"] if stage else None,
            "stage_label": stage["label"] if stage else None, "category": category}


def validate_pipeline_result(value: object) -> dict:
    """Validate a saved pipeline, including canonical checks and sticky summary.

    The original dictionary is returned. Artifact names remain inert metadata;
    validation neither opens them nor establishes that the files still exist.
    """
    _tree(value)
    result = _fields(value, _TOP)
    if type(result["schema_version"]) is not int or result["schema_version"] != 1:
        _reject("unsupported_schema_version")
    if type(result["engine"]) is not str or result["engine"] not in _ANALYSIS_ENGINES:
        _reject("unsupported_engine")
    analysis_engine = _ANALYSIS_ENGINES[result["engine"]]
    if type(result["status"]) is not str or result["status"] not in {"completed", "incomplete"}:
        _reject("unsupported_pipeline_status")
    if result["comparison_scope"] != "adjacent_stage_checks_and_end_to_end":
        _reject("unsupported_comparison_scope")
    for name in ("complete_audio_approval", "commercial_performance_validated", "network_used",
                 "fault_provenance_confirmed"):
        if result[name] is not False:
            _reject("invalid_approval_claim")
    source = _metadata(result["source"])
    stages = result["stages"]
    if type(stages) is not list or not 1 <= len(stages) <= 8:
        _reject("invalid_pipeline_stages")
    latest = source
    latest_snapshot = "input/source.wav"
    failed_stage = None
    executed = 0
    worst = 0
    first_concern = None
    for index, item in enumerate(stages, 1):
        stage = _fields(item, _STAGE, "invalid_pipeline_stage")
        if type(stage["index"]) is not int or stage["index"] != index:
            _reject("inconsistent_stage_index")
        _label(stage["label"])
        try:
            operation = validate_stage(stage["operation"])
        except PipelineTransformError:
            raise PipelineReportError("invalid_stage_operation") from None
        if not _same_json(operation, stage["operation"]):
            _reject("unnormalized_stage_operation")
        if "label" in operation and operation["label"] != stage["label"]:
            _reject("inconsistent_stage_label")
        _number(stage["runtime_ms"], "invalid_stage_runtime", 0, 86_400_000)
        if _metadata(stage["input"]) != latest:
            _reject("broken_pipeline_chain")
        if _relative_path(stage["input_snapshot"]) != latest_snapshot:
            _reject("broken_snapshot_chain")
        status = stage["status"]
        if type(status) is not str or status not in {"analyzed", "withheld", "error", "not_run"}:
            _reject("unsupported_stage_status")
        if status == "not_run":
            if (failed_stage is None or stage["runtime_ms"] != 0
                    or stage["reason_code"] != "prior_stage_execution_error"
                    or any(stage[name] is not None for name in
                           ("output", "output_snapshot", "analysis", "check", "analysis_artifact", "check_artifact"))):
                _reject("inconsistent_not_run_stage")
            continue
        if failed_stage is not None:
            _reject("execution_after_failed_stage")
        executed += 1
        output = stage["output"]
        if output is None:
            if status != "error" or stage["output_snapshot"] is not None:
                _reject("missing_stage_output")
        else:
            _metadata(output)
            _operation_output(operation, latest, output)
            if _relative_path(stage["output_snapshot"]) != f"stages/{index:03d}/output.wav":
                _reject("inconsistent_output_snapshot")
        expected_names = (("error.json", "error_check.json") if status == "error" else
                          ("analysis.json", "check.json"))
        for field, name in zip(("analysis_artifact", "check_artifact"), expected_names):
            if stage[field] is None and status == "error":
                continue
            if _relative_path(stage[field]) != f"stages/{index:03d}/{name}":
                _reject("inconsistent_stage_artifact")
        check = _analysis_check(stage["analysis"], stage["check"], status, latest, output, analysis_engine)
        _configuration(stage["analysis"], operation["kind"] == "gain", operation["kind"] == "resample")
        if status == "analyzed":
            if stage["reason_code"] is not None:
                _reject("inconsistent_stage_reason")
        else:
            _reason(stage["reason_code"])
            if stage["reason_code"] != stage["analysis"]["reason_code"]:
                _reject("inconsistent_stage_reason")
        worst = max(worst, check["exit_code"])
        first_concern = first_concern or _concern("stage", stage, check, status)
        if output is not None:
            latest, latest_snapshot = output, stage["output_snapshot"]
        if status == "error":
            failed_stage = index
    end = result["end_to_end"]
    end_error = False
    if end is None:
        if failed_stage is None:
            _reject("missing_end_to_end_check")
    else:
        end = _fields(end, {"status", "analysis", "check", "analysis_artifact", "check_artifact"},
                      "missing_end_to_end_check")
        if type(end["status"]) is not str or end["status"] not in {"analyzed", "withheld", "error"}:
            _reject("unsupported_end_to_end_status")
        end_names = (("error.json", "error_check.json") if end["status"] == "error" else
                     ("analysis.json", "check.json"))
        for field, name in zip(("analysis_artifact", "check_artifact"), end_names):
            if end[field] is None and end["status"] == "error":
                continue
            if _relative_path(end[field]) != "end_to_end/" + name:
                _reject("inconsistent_end_to_end_artifact")
        check = _analysis_check(end["analysis"], end["check"], end["status"], source, latest, analysis_engine)
        if failed_stage is not None and (end["status"] != "error"
                                         or end["analysis"]["reason_code"] not in {
                                             "source_changed_during_run", "snapshot_changed_during_run",
                                             "snapshot_recheck_failed"}):
            _reject("end_to_end_after_failed_stage")
        _configuration(end["analysis"], any(stage["operation"]["kind"] == "gain" for stage in stages),
                       any(stage["operation"]["kind"] == "resample" for stage in stages))
        worst = max(worst, check["exit_code"])
        first_concern = first_concern or _concern("end_to_end", None, check, end["status"])
        end_error = end["status"] == "error"
    expected_status = "incomplete" if failed_stage is not None or end_error else "completed"
    if result["status"] != expected_status:
        _reject("inconsistent_pipeline_status")
    summary = _fields(result["summary"], _SUMMARY, "invalid_pipeline_summary")
    _integer(summary["exit_code"], "invalid_summary_exit_code", 0, 2)
    _integer(summary["planned_stage_count"], "invalid_summary_count", 1, 8)
    _integer(summary["executed_stage_count"], "invalid_summary_count", 1, 8)
    if summary["failed_stage"] is not None:
        _integer(summary["failed_stage"], "invalid_failed_stage", 1, len(stages))
    if summary["first_concern"] is not None:
        concern = _fields(summary["first_concern"], {"scope", "stage_index", "stage_label", "category"},
                          "invalid_first_concern")
        if concern["stage_label"] is not None:
            _label(concern["stage_label"])
    if (summary["exit_code"] != worst or summary["gate_state"] != _GATES[worst]
            or not _same_json(summary["first_concern"], first_concern) or summary["failed_stage"] != failed_stage
            or summary["planned_stage_count"] != len(stages) or summary["executed_stage_count"] != executed):
        _reject("inconsistent_pipeline_summary")
    return result


def _unique_object(pairs: list[tuple[str, object]]) -> dict:
    value = {}
    for key, item in pairs:
        if key in value:
            _reject("duplicate_json_key")
        value[key] = item
    return value


def _invalid_constant(_: str) -> None:
    _reject("non_finite_metric")


def load_pipeline_result(path: str | Path) -> dict:
    """Read bounded strict UTF-8 JSON without following its referenced files."""
    try:
        with Path(path).open("rb") as stream:
            data = stream.read(MAX_PIPELINE_RESULT_BYTES + 1)
    except (OSError, ValueError, TypeError):
        raise PipelineReportError("result_file_read_error") from None
    if len(data) > MAX_PIPELINE_RESULT_BYTES:
        _reject("result_file_too_large")
    try:
        value = json.loads(data.decode("utf-8"), object_pairs_hook=_unique_object,
                           parse_constant=_invalid_constant)
    except PipelineReportError:
        raise
    except (UnicodeError, ValueError, RecursionError, OverflowError):
        raise PipelineReportError("invalid_result_json") from None
    return validate_pipeline_result(value)


def _e(value: object) -> str:
    return escape(_LOCAL_PATH.sub("[로컬 경로 생략]", str(value)), quote=True)


def _n(value: int | float) -> str:
    return f"{value:,.3f}".rstrip("0").rstrip(".")


_STYLE = """
:root{color-scheme:light;--ink:#182940;--muted:#5d6c80;--line:#dbe4ed;--blue:#27578d;--red:#9d3544;--amber:#8b5b12}
*{box-sizing:border-box}body{margin:0;background:#eff3f7;color:var(--ink);font:15px/1.65 system-ui,-apple-system,"Segoe UI",sans-serif}main{max-width:1120px;margin:38px auto;padding:0 24px}header{margin-bottom:24px}.eyebrow{font-size:12px;letter-spacing:.15em;color:var(--blue);font-weight:800}h1{font-size:32px;line-height:1.3;margin:8px 0 10px}h2{font-size:22px;line-height:1.4;margin:0 0 16px}h3{font-size:18px;margin:0 0 12px}p{margin:8px 0}.muted{color:var(--muted)}.badge{display:inline-block;background:#e4edf6;color:var(--blue);border-radius:20px;font-size:12px;font-weight:700;padding:4px 11px;margin:0 6px 6px 0}.card{background:white;border:1px solid var(--line);border-radius:16px;padding:26px;margin-bottom:20px;box-shadow:0 2px 6px #17243b06}.summary{border-left:6px solid var(--blue)}.summary.review{border-left-color:var(--red)}.summary.blocked{border-left-color:var(--amber)}.state{font-size:13px;font-weight:800;color:var(--blue)}.review .state{color:var(--red)}.blocked .state{color:var(--amber)}.metrics{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:20px 0}.metric{border-radius:10px;padding:12px 16px;background:#f3f6fa}.metric span{display:block;font-size:12px;color:var(--muted)}.metric b{font-size:22px}.notice{padding:16px 20px;background:#fff7e9;border:1px solid #e6cfaa;border-radius:10px}.flow{display:flex;align-items:stretch;gap:10px;overflow-x:auto;padding:3px 0 12px}.node{flex:1;min-width:155px;max-width:230px;border:1px solid var(--line);border-radius:10px;padding:13px;background:#f6f9fc}.node strong{display:block;overflow-wrap:anywhere}.arrow{align-self:center;font-size:22px;color:#7c8da3}.node.review{border-color:#cd92a0}.node.blocked{border-color:#d0af7d}.table-wrap{overflow:auto}table{border-collapse:collapse;width:100%;text-align:left;font-size:13px}th,td{border-bottom:1px solid var(--line);padding:10px 12px;vertical-align:top}th{background:#f5f8fb;color:var(--muted)}code{font:12px/1.6 ui-monospace,Consolas,monospace;overflow-wrap:anywhere}.hash{word-break:break-all}.stage-head{display:flex;align-items:baseline;justify-content:space-between;gap:14px}.index{color:var(--blue);font-size:13px;font-weight:800}.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}dl{display:grid;grid-template-columns:120px 1fr;gap:8px 12px;margin:0}dt{color:var(--muted)}dd{margin:0;overflow-wrap:anywhere}.scope{font-size:13px}.event-table td{min-width:160px}.artifact{font-size:12px;margin-top:16px;border-top:1px solid var(--line);padding-top:12px}.end{border-top:5px solid var(--blue)}footer{font-size:12px;color:var(--muted);padding:5px 0 28px}@media(max-width:720px){main{padding:0 14px;margin:22px auto}h1{font-size:26px}.card{padding:20px}.metrics,.grid{grid-template-columns:1fr}.stage-head{display:block}dl{grid-template-columns:1fr}dd{margin-bottom:7px}}@media print{body{background:white}main{margin:0;max-width:none}.card{box-shadow:none;break-inside:avoid}.flow{flex-wrap:wrap;overflow:visible}.node{min-width:125px}}
"""
_STYLE += """
.comparison-context{margin:16px 0;padding:18px;background:#f3f6fa;border:1px solid var(--line);border-radius:10px}
.comparison-context .grid{gap:14px}.comparison-context p{overflow-wrap:anywhere}
.next-actions{margin:16px 0;padding:18px 20px;border-left:4px solid var(--blue);background:#f4f8fc;border-radius:0 10px 10px 0}
.next-actions ol{margin:0;padding-left:22px}.next-actions li{margin:8px 0;overflow-wrap:anywhere}
@media(max-width:720px){.comparison-context,.next-actions{padding:14px}}
"""
_STATE_LABELS = {0: "지원 범위의 시간적 후보 없음", 1: "시간적 결함 후보 · 검토 필요", 2: "판단 보류 또는 실행 오류"}
_STATUS_LABELS = {"analyzed": "분석 완료", "withheld": "판단 보류", "error": "실행 오류", "not_run": "미실행"}


def _comparison_targets(result: dict, stage: dict | None = None) -> dict:
    """Name the actual compared snapshots, not an assumed original time axis."""
    stages = result["stages"]
    source_snapshot = stages[0]["input_snapshot"]

    def output_name(item: dict) -> str:
        return f'{item["index"]:02d} 단계 · {item["label"]} 출력'

    if stage is None:
        latest = next((item for item in reversed(stages) if item["output_snapshot"]), None)
        return {
            "reference_name": "원본", "reference_snapshot": source_snapshot,
            "processed_name": "최종 출력 · " + output_name(latest) if latest else "출력 미생성",
            "processed_snapshot": latest["output_snapshot"] if latest else None,
        }
    previous = next((item for item in stages[:stage["index"] - 1]
                     if item["output_snapshot"] == stage["input_snapshot"]), None)
    return {
        "reference_name": output_name(previous) if previous else "원본",
        "reference_snapshot": stage["input_snapshot"],
        "processed_name": output_name(stage), "processed_snapshot": stage["output_snapshot"],
    }


def _comparison_context(reference_name: str, processed_name: str,
                        reference_snapshot: str | None, processed_snapshot: str | None) -> str:
    targets = []
    for axis, name, snapshot in (("입력 시간축", reference_name, reference_snapshot),
                                 ("출력 시간축", processed_name, processed_snapshot)):
        targets.append('<div><span class="scope muted">' + _e(axis)
                       + '</span><p><strong>' + _e(name) + '</strong></p><code>'
                       + _e(snapshot or "파일 미생성") + '</code></div>')
    return ('<div class="comparison-context"><h3>시간축과 비교 대상</h3><div class="grid">'
            + ''.join(targets) + '</div><p class="scope">모든 시간은 각 파일의 시작(0초)부터 잰 위치입니다. '
            '단계별 비교 입력은 바로 앞 입력 파일이며, 최초 원본과 항상 같지는 않습니다. '
            '입력과 출력은 서로 다른 시간축이므로 같은 숫자가 같은 내용을 뜻하지 않을 수 있습니다.</p></div>')


def _next_actions(analysis: dict | None, reference_name: str, processed_name: str) -> str:
    """Offer manual checks only; never infer audio, cause, or missing locations."""
    actions = []
    if analysis is None:
        actions.append("이 비교는 수행되지 않았습니다. 앞선 오류 단계의 기록과 입력 파일부터 확인하세요. "
                       "이 단계에는 확인할 결함 위치가 없습니다.")
    elif analysis["status"] == "error":
        actions.append("분석 또는 입력 확인이 끝나지 않았습니다. 표시된 오류 사유와 입력 재확인 기록이 있으면 "
                       "함께 확인하세요. 오류를 해결하기 전에는 통과나 결함으로 판단하지 마세요.")
    elif analysis["status"] == "withheld":
        actions.append("결함 위치를 확정하지 못했습니다. 표시된 보류 사유와 비교 허용 설정을 확인하고, "
                       "두 파일이 같은 원본에서 나온 처리 전후 자료인지 확인하세요. 보류를 통과로 해석하지 마세요.")
    elif not analysis["events"]:
        actions.append("이 비교에서는 지원 범위의 시간적 결함 후보가 없습니다. 보고서 위쪽의 첫 우려 지점과 "
                       "다른 비교 결과도 확인하세요. 이 결과만으로 전체 음질을 승인하지 마세요.")
    else:
        for event in analysis["events"]:
            if event["type"] == "delete":
                start, stop = event["reference_interval_ms"]
                boundary = event["processed_boundary_ms"]
                actions.append(
                    f'입력 「{reference_name}」의 {_n(start / 1000)}–{_n(stop / 1000)}초 구간을 듣고, '
                    f'출력 「{processed_name}」의 {_n(boundary / 1000)}초 전후를 비교하세요. '
                    '출력 위치는 삭제 후보 구간에 대응하는 연결 경계이며, 출력에 같은 길이의 구간이 있다는 뜻은 아닙니다.'
                )
            else:
                start, stop = event["reference_source_interval_ms"]
                added_start, added_stop = event["processed_added_interval_ms"]
                actions.append(
                    f'입력 「{reference_name}」의 {_n(start / 1000)}–{_n(stop / 1000)}초 구간과 '
                    f'출력 「{processed_name}」의 {_n(added_start / 1000)}–{_n(added_stop / 1000)}초 구간을 듣고 '
                    '같은 내용이 인접 반복되는지 확인하세요. 출력 구간은 뒤쪽 인접 복사 기준이며 실제 편집 위치나 원인을 확정하지 않습니다.'
                )
        actions.append("두 파일을 로컬 오디오 도구에서 각각 여세요. 이 보고서는 파일을 열거나 소리를 재생하지 않습니다. "
                       "차이를 확인한 뒤 해당 단계의 처리 설정·로그를 살펴보세요. 관찰된 단계만으로 원인을 단정하지 마세요.")
    return ('<div class="next-actions"><h3>다음 확인</h3><ol>'
            + ''.join('<li>' + _e(action) + '</li>' for action in actions) + '</ol></div>')


def _metadata_view(title: str, metadata: dict | None) -> str:
    if metadata is None:
        return '<div><h3>' + _e(title) + '</h3><p class="muted">출력 스냅샷이 없습니다.</p></div>'
    values = (("샘플률", f'{_n(metadata["sample_rate_hz"])} Hz'),
              ("길이", f'{_n(metadata["duration_ms"])} ms'),
              ("샘플 수", metadata["sample_count"]), ("형식", "mono · PCM16"))
    fields = "".join('<dt>' + _e(name) + '</dt><dd>' + _e(value) + '</dd>' for name, value in values)
    fields += '<dt>SHA-256</dt><dd><code class="hash">' + _e(metadata["sha256"]) + '</code></dd>'
    return '<div><h3>' + _e(title) + '</h3><dl>' + fields + '</dl></div>'


def _events(analysis: dict | None) -> str:
    if analysis is None:
        return '<p class="muted">앞선 실행 오류로 이 검사는 수행되지 않았습니다.</p>'
    if analysis["status"] in {"withheld", "error"}:
        return '<p>판단을 확정하지 않았습니다. 사유: <code>' + _e(analysis["reason_code"]) + '</code></p>'
    if not analysis["events"]:
        return '<p>지원 범위의 시간적 결함 후보 없음</p>'
    rows = []
    for event in analysis["events"]:
        if event["type"] == "delete":
            interval = event["reference_interval_ms"]
            original = f'{_n(interval[0])}–{_n(interval[1])} ms'
            processed = f'대응 경계 {_n(event["processed_boundary_ms"])} ms'
            kind = "삭제 후보"
        else:
            interval = event["reference_source_interval_ms"]
            original = f'{_n(interval[0])}–{_n(interval[1])} ms (복사 출처)'
            interval = event["processed_added_interval_ms"]
            processed = f'{_n(interval[0])}–{_n(interval[1])} ms (뒤쪽 인접 복사)'
            kind = "반복 후보"
        rows.append('<tr><td>' + _e(kind) + '</td><td>' + _e(original) + '</td><td>' + _e(processed) + '</td></tr>')
    return ('<div class="table-wrap"><table class="event-table"><thead><tr><th>후보</th><th>비교 입력 시간축</th>'
            '<th>비교 출력 시간축</th></tr></thead><tbody>' + "".join(rows) + '</tbody></table></div>'
            '<p class="muted scope">각 위치는 해당 비교의 독립된 시간축입니다. 반복은 뒤쪽 인접 복사를 표시하며 실제 편집 위치나 원인을 확정하지 않습니다.</p>')


def _checkpoint(analysis: dict | None, check: dict | None, *, reference_name: str | None = None,
                processed_name: str | None = None, reference_snapshot: str | None = None,
                processed_snapshot: str | None = None) -> str:
    review = render_review_diagnostics(analysis) if analysis is not None else ""
    context = actions = ""
    if reference_name is not None and processed_name is not None:
        context = _comparison_context(reference_name, processed_name, reference_snapshot, processed_snapshot)
        actions = _next_actions(analysis, reference_name, processed_name)
    if check is None:
        return context + _events(analysis) + actions + review
    return (context + '<p><span class="badge">종료 코드 ' + _e(check["exit_code"]) + '</span>'
            + _e(_STATE_LABELS[check["exit_code"]]) + '</p><p class="muted scope">확인 정책: <code>'
            + _e(check["reason_code"]) + '</code></p>' + _events(analysis) + actions + review)


def render_pipeline_html(result: dict) -> str:
    """Render one validated, self-contained report using saved diagnostics only."""
    validate_pipeline_result(result)
    candidate_notice = ""
    if result["engine"] != ENGINE:
        version = result["engine"].rsplit("_", 1)[1]
        description = {"v2": "미세 정렬 취소 재검증 후보",
                       "v3": "제한된 활성 문맥 연결 후보",
                       "v4": "원시 파형 랜드마크·전역 유일성 정합 연구 후보",
                       "v5": "정확한 PCM 정상 리샘플링 증명 연구 후보",
                       "v6": "v5 결과 보존 및 전체 복사·전역 대체 원본 검증 연구 후보",
                       "v7": "v6 결과 보존 및 16→8kHz 음량·리샘플링·지연의 정확한 정상 변환 증명 연구 후보",
                       "v8": "v7 결과 보존 및 16→8kHz 음량·리샘플링·지연에 결합된 단일 삭제·복사의 정확한 전체 출력 증명 연구 후보",
                       "v9": "v8 결과 보존 및 제한된 전역 문맥 정합으로 단일 삭제·복사의 정확한 전체 출력 증명을 재검증하는 연구 후보",
                       "v10": "동일 샘플레이트의 50–200ms 내부 누락·반복에 대한 정확한 전체 출력 증명 후보",
                       "v11": "v10 결과 보존 및 50–2000ms 시작·끝 누락에 대한 한쪽 보존 문맥·정확한 전체 출력 증명 후보"}[version]
        candidate_notice = (f'<section class="card notice"><h2>{_e(version)} · 선택한 실험 후보</h2>'
                            f'<p>실행 결과 버전: <code>{_e(result["engine"])}</code> · '
                            f'분석 엔진: <code>{_e(_ANALYSIS_ENGINES[result["engine"]])}</code>. '
                            f'{description}이며 전체 음질 승인이나 상용 성능 검증이 아닙니다.</p>'
                            '<p class="scope muted">보류 결과에 제한된 추가 검사 요약이 포함되어 있으면 해당 검사 아래에 표시합니다.</p>'
                            '<p class="scope muted">별도 <code>trace.json</code>은 추적 기록의 이름입니다. '
                            '이 보고서는 추적 파일을 읽거나 존재를 확인하지 않으며, 이름은 열리지 않는 텍스트입니다.</p></section>')
    summary = result["summary"]
    state = {0: "clear", 1: "review", 2: "blocked"}[summary["exit_code"]]
    status = "실행 완료" if result["status"] == "completed" else "실행 미완료"
    first = summary["first_concern"]
    if first is None:
        first_view = '<p>관찰된 검토 후보 또는 판단 보류 지점이 없습니다.</p>'
    else:
        position = (f'{first["stage_index"]:02d} 단계 · {first["stage_label"]}' if first["scope"] == "stage"
                    else "원본 → 최종 출력 비교")
        category = {"defect_candidates": "시간적 결함 후보", "withheld": "판단 보류", "execution_error": "실행 오류"}[first["category"]]
        first_view = '<p><strong>' + _e(position) + '</strong>에서 처음 관찰한 항목: ' + _e(category) + '</p>'
    first_view += '<p class="muted scope">처음 관찰된 지점은 원인 확정이 아닙니다. 단계 간 비교는 바로 앞 입력과 출력의 저장된 진단을 보여줍니다.</p>'
    if first is not None:
        item = result["stages"][first["stage_index"] - 1] if first["scope"] == "stage" else result["end_to_end"]
        targets = _comparison_targets(result, item if first["scope"] == "stage" else None)
        first_view += _next_actions(item["analysis"], targets["reference_name"], targets["processed_name"])
    flow = '<div class="node"><span class="index">SOURCE</span><strong>원본 스냅샷</strong><span class="muted">' + _e(_n(result["source"]["duration_ms"])) + ' ms</span></div>'
    sections = []
    for stage in result["stages"]:
        code = stage["check"]["exit_code"] if stage["check"] else 2
        stage_state = {0: "clear", 1: "review", 2: "blocked"}[code]
        flow += ('<span class="arrow" aria-hidden="true">→</span><div class="node ' + stage_state
                 + '"><span class="index">' + _e(f'{stage["index"]:02d}') + '</span><strong>' + _e(stage["label"])
                 + '</strong><span class="muted">' + _e(_STATUS_LABELS[stage["status"]]) + '</span></div>')
        operation = json.dumps(stage["operation"], ensure_ascii=False, sort_keys=True, allow_nan=False)
        artifacts = (("입력", stage["input_snapshot"]), ("출력", stage["output_snapshot"]),
                     ("분석", stage["analysis_artifact"]), ("검사", stage["check_artifact"]))
        artifact_text = ' · '.join(_e(name) + ': <code>' + _e(path or "미생성") + '</code>' for name, path in artifacts)
        sections.append('<section class="card"><div class="stage-head"><h2><span class="index">'
                        + _e(f'{stage["index"]:02d}') + '</span> ' + _e(stage["label"]) + '</h2><span class="badge">'
                        + _e(_STATUS_LABELS[stage["status"]]) + '</span></div><p class="muted scope">처리 사양: <code>'
                        + _e(operation) + '</code> · 실행 시간 ' + _e(_n(stage["runtime_ms"])) + ' ms</p>'
                        + '<div class="grid">' + _metadata_view("바로 앞 입력", stage["input"])
                        + _metadata_view("단계 출력", stage["output"]) + '</div><h3 style="margin-top:22px">단계 간 검사</h3>'
                        + _checkpoint(stage["analysis"], stage["check"], **_comparison_targets(result, stage)) + '<p class="artifact muted">'
                        + artifact_text + '</p></section>')
    end = result["end_to_end"]
    final = ('<p class="muted">단계 실행이 중단되어 원본과 최종 출력 비교를 수행하지 않았습니다.</p>' if end is None else
             _checkpoint(end["analysis"], end["check"], **_comparison_targets(result)) + '<p class="artifact muted">분석: <code>'
             + _e(end["analysis_artifact"] or "미생성") + '</code> · 검사: <code>' + _e(end["check_artifact"] or "미생성") + '</code></p>')
    return ('<!doctype html>\n<html lang="ko"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
            '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\'">'
            '<title>DSP 파이프라인 회귀 검사 보고서</title><style>' + _STYLE + '</style></head><body><main><header>'
            '<div class="eyebrow">AUDIO PIPELINE / STORED RESULT</div><h1>파이프라인 회귀 검사 보고서</h1>'
            '<span class="badge">LOCAL · OFFLINE</span><span class="badge">저장된 결과 · 정적 HTML</span></header>'
            + candidate_notice + '<section class="card summary ' + state + '"><div class="state">' + _e(status) + '</div><h2>'
            + _e(_STATE_LABELS[summary["exit_code"]]) + '</h2><div class="metrics"><div class="metric"><span>좁은 범위의 종료 코드</span><b>'
            + _e(summary["exit_code"]) + '</b></div><div class="metric"><span>실행한 단계 / 계획한 단계</span><b>'
            + _e(summary["executed_stage_count"]) + ' / ' + _e(summary["planned_stage_count"]) + '</b></div>'
            '<div class="metric"><span>비교 범위</span><b>인접 단계 + 원본·최종</b></div></div><p class="scope muted">'
            '코드 0: 지원 범위의 시간적 후보 없음 · 코드 1: 후보 검토 필요 · 코드 2: 판단 보류 또는 실행 오류. 앞선 우려는 뒤 단계의 결과로 지워지지 않습니다.</p></section>'
            '<section class="card"><h2>파이프라인 흐름</h2><div class="flow">' + flow + '</div></section>'
            '<section class="card"><h2>처음 관찰된 우려 지점</h2>' + first_view + '</section>' + "".join(sections)
            + '<section class="card end"><h2>별도 검사 · 원본 → 최종 출력</h2><p class="muted scope">모든 단계를 통과한 출력과 원본을 비교하는 별도의 저장된 검사입니다.</p>'
            + final + '</section><section class="card"><h2>해석 범위</h2><p>내부 삭제·인접 복사 반복의 시간적 후보를 다룹니다. 전체 음질 승인, 상용 성능 검증, 결함 원인 확정 또는 보정된 확률을 뜻하지 않습니다.</p>'
            '<p class="muted scope">보고서 생성은 오디오를 재분석하지 않습니다. 결과 구조와 해시 연결의 일관성을 확인하며 현재 디스크 파일의 무결성을 다시 검증하지 않습니다. 원본 오디오, 절대 입력 경로, 외부 자원과 실행 스크립트를 포함하지 않습니다. 파일 이름은 연결되지 않는 상대 경로 기록입니다.</p></section>'
            '<footer>자체 포함 정적 HTML · 저장된 분석과 검사 결과만 표시</footer></main></body></html>\n')


def write_pipeline_html(result: dict, path: str | Path) -> None:
    """Create a report exclusively, preserving any existing output file."""
    rendered = render_pipeline_html(result)
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(rendered)
