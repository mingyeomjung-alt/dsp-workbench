"""Offline presentation of validated, caller-ordered WAV snapshot audits.

Only saved diagnostics are displayed. This module does not execute transforms,
load audio, reopen snapshot references, or establish a submitted stage order.
"""

from __future__ import annotations

import json
from pathlib import Path

from .pipeline_reporting import (
    _STYLE, _STATUS_LABELS, _STATE_LABELS, _checkpoint, _comparison_context,
    _comparison_targets, _e, _metadata_view, _n, _next_actions,
)
from .saved_pipeline_contract import (
    SavedPipelineContractError, load_saved_pipeline_result,
    validate_saved_pipeline_result,
)


_RECHECK_LABELS = {
    "unchanged": "수집 당시와 동일",
    "changed": "수집 후 입력 변경 감지 · 차단",
    "unavailable": "입력 재확인 불가 · 차단",
}
_STAGE_STATUS_LABELS = {**_STATUS_LABELS, "error": "분석 오류", "not_run": "미분석"}
_AUDIT_STATE_LABELS = {**_STATE_LABELS, 2: "판단 보류 또는 분석·입력 오류"}


def _audio_view(title: str, metadata: dict) -> str:
    """Present snapshot metadata; the hash is not an authenticity claim."""
    return (
        _metadata_view(title, metadata)
        + '<p class="scope muted">RMS: <code>' + _e(_n(metadata["rms"]))
        + '</code> · Peak: <code>' + _e(_n(metadata["peak"])) + '</code></p>'
    )


def _checkpoint_view(analysis: dict | None, check: dict | None, targets: dict) -> str:
    if analysis is None:
        return (_comparison_context(**targets)
                + '<p class="muted">앞선 분석 오류로 이 비교는 수행되지 않았습니다.</p>'
                + _next_actions(None, targets["reference_name"], targets["processed_name"]))
    return _checkpoint(analysis, check, **targets)


def render_saved_pipeline_html(result: dict) -> str:
    """Render a strict saved result without reading any referenced files.

    Declared tolerances and caller labels are escaped inert text, not executable
    processing recipes or evidence that an actual pipeline ran in that order.
    """
    validate_saved_pipeline_result(result)
    candidate_notice = ""
    if result["engine"] in {"audio_saved_pipeline_audit_v2", "audio_saved_pipeline_audit_v3", "audio_saved_pipeline_audit_v4", "audio_saved_pipeline_audit_v5", "audio_saved_pipeline_audit_v6", "audio_saved_pipeline_audit_v7", "audio_saved_pipeline_audit_v8", "audio_saved_pipeline_audit_v9", "audio_saved_pipeline_audit_v10", "audio_saved_pipeline_audit_v11"}:
        version = result["engine"].rsplit("_", 1)[1]
        description = {"v2": "미세 정렬 취소 재검증 후보",
                       "v3": "제한된 활성 문맥 연결 후보",
                       "v4": "원시 파형 랜드마크·전역 유일성 정합 연구 후보",
                       "v5": "정확한 PCM 정상 리샘플링 증명 연구 후보",
                       "v6": "v5 결과 보존 및 전체 복사·전역 대체 원본 검증 연구 후보",
                       "v7": "v6 결과 보존 및 16→8kHz 음량·리샘플링·지연의 정확한 정상 변환 증명 연구 후보",
                       "v8": "v7 결과 보존 및 16→8kHz 음량·리샘플링·지연에 결합된 단일 삭제·복사의 정확한 전체 출력 증명 연구 후보",
                       "v9": "v8 결과 보존 및 제한된 전역 문맥 정합으로 단일 삭제·복사의 정확한 전체 출력 증명을 재검증하는 연구 후보",
                       "v10": "50–200ms 내부 누락·반복의 정확한 전체 출력 증명 후보",
                       "v11": "v10 보존 및 50–2000ms 시작·끝 누락의 한쪽 보존 문맥·정확한 전체 출력 증명 후보"}[version]
        candidate_notice = (f'<section class="card notice"><h2>{_e(version)} · 선택한 실험 후보</h2>'
                            f'<p>감사 결과 버전: <code>{_e(result["engine"])}</code> · '
                            f'분석 엔진: <code>local_content_alignment_{_e(version)}</code>. '
                            f'{description}이며 전체 음질 승인이나 상용 성능 검증이 아닙니다.</p>'
                            '<p class="scope muted">별도 <code>trace.json</code>은 추적 기록의 이름입니다. '
                            '이 보고서는 추적 파일을 읽거나 존재를 확인하지 않으며, 이름은 열리지 않는 텍스트입니다.</p></section>')
    elif result["engine"] == "audio_saved_pipeline_audit_mixed_v1":
        selected = ", ".join(f'{stage["index"]}: {stage["analysis_engine"]}' for stage in result["stages"])
        end = result["end_to_end"]
        end_selection = end["analysis_engine"] if end is not None else "미수행"
        candidate_notice = ('<section class="card notice"><h2>명시적 단계별 후보 비교</h2>'
                            '<p>각 단계와 원본 → 최종 비교는 별도로 지정한 엔진·변환 모델만 사용합니다. '
                            '샘플레이트나 단계 이름으로 FFT 모델을 추정하지 않습니다.</p>'
                            f'<p>단계 선택: <code>{_e(selected)}</code> · 최종 비교: <code>{_e(end_selection)}</code>.</p>'
                            '<p class="scope muted">좌표 연결은 기록된 정렬 범위만 사용합니다. '
                            '정확한 FFT 변환만 확인되고 정렬 구간이 없는 단계는 임의의 대응 구간을 만들지 않습니다. '
                            '전체 음질 승인·실제 처리 이력·상용 성능 검증이 아닙니다.</p></section>')
    summary = result["summary"]
    state = {0: "clear", 1: "review", 2: "blocked"}[summary["exit_code"]]
    status = "검사 완료" if result["status"] == "completed" else "검사 미완료"
    first = summary["first_concern"]
    if first is None:
        first_view = '<p>지원 범위에서 관찰된 검토 후보 또는 판단 보류 지점이 없습니다.</p>'
    else:
        position = (
            f'{first["stage_index"]:02d} 단계 · {first["stage_label"]}'
            if first["scope"] == "stage" else "원본 → 최종 제출 출력 비교"
        )
        category = {
            "defect_candidates": "시간적 결함 후보", "withheld": "판단 보류",
            "execution_error": "분석 또는 입력 재확인 오류",
        }[first["category"]]
        first_view = (
            '<p><strong>' + _e(position) + '</strong>에서 처음 관찰한 항목: '
            + _e(category) + '</p>'
        )
    first_view += (
        '<p class="muted scope">처음 관찰된 지점은 결함 원인 확정이 아닙니다. '
        '제출자가 지정한 파일 순서에 따라 저장된 비교 결과를 표시합니다.</p>'
    )
    if first is not None:
        item = result["stages"][first["stage_index"] - 1] if first["scope"] == "stage" else result["end_to_end"]
        targets = _comparison_targets(result, item if first["scope"] == "stage" else None)
        first_view += _next_actions(item["analysis"], targets["reference_name"], targets["processed_name"])
    flow = (
        '<div class="node"><span class="index">INPUT 000</span>'
        '<strong>제출 원본 스냅샷</strong><span class="muted">'
        + _e(_n(result["source"]["duration_ms"])) + ' ms</span></div>'
    )
    sections = []
    for stage in result["stages"]:
        code = stage["check"]["exit_code"] if stage["check"] else 2
        stage_state = {0: "clear", 1: "review", 2: "blocked"}[code]
        flow += (
            '<span class="arrow" aria-hidden="true">→</span><div class="node '
            + stage_state + '"><span class="index">' + _e(f'{stage["index"]:02d}')
            + '</span><strong>' + _e(stage["label"]) + '</strong><span class="muted">'
            + _e(_STAGE_STATUS_LABELS[stage["status"]]) + '</span></div>'
        )
        declaration = json.dumps(
            stage["declaration"], ensure_ascii=False, sort_keys=True, allow_nan=False,
        )
        artifacts = (
            ("직전 입력 스냅샷", stage["input_snapshot"]),
            ("제출 출력 스냅샷", stage["output_snapshot"]),
            ("분석", stage["analysis_artifact"]), ("검사", stage["check_artifact"]),
        )
        artifact_text = ' · '.join(
            _e(name) + ': <code>' + _e(path or "미생성") + '</code>'
            for name, path in artifacts
        )
        sections.append(
            '<section class="card"><div class="stage-head"><h2><span class="index">'
            + _e(f'{stage["index"]:02d}') + '</span> ' + _e(stage["label"])
            + '</h2><span class="badge">' + _e(_STAGE_STATUS_LABELS[stage["status"]])
            + '</span></div><p class="muted scope">제출자가 선언한 비교 허용 설정: <code>'
            + _e(declaration) + '</code> · 분석 시간 ' + _e(_n(stage["runtime_ms"]))
            + ' ms</p><p class="scope muted">이 설정은 실제 변환 작업이나 순서가 수행됐다는 증거가 아닙니다.</p>'
            + '<div class="grid"><div>' + _audio_view("직전 제출 입력", stage["input"])
            + '</div><div>' + _audio_view("현재 제출 출력", stage["output"])
            + '</div></div><h3 style="margin-top:22px">인접 스냅샷 비교</h3>'
            + _checkpoint_view(stage["analysis"], stage["check"], _comparison_targets(result, stage))
            + '<p class="artifact muted">' + artifact_text + '</p></section>'
        )
    end = result["end_to_end"]
    final = (
        '<p class="muted">앞선 분석 오류로 원본과 최종 제출 출력 비교를 수행하지 않았습니다.</p>'
        if end is None else
        _checkpoint_view(end["analysis"], end["check"], _comparison_targets(result))
        + '<p class="artifact muted">분석: <code>'
        + _e(end["analysis_artifact"] or "미생성") + '</code> · 검사: <code>'
        + _e(end["check_artifact"] or "미생성") + '</code></p>'
    )
    recheck = result["input_recheck"]
    recheck_indices = ', '.join(f'{index:03d}' for index in recheck["file_indices"]) or "없음"
    recheck_view = (
        '<p><strong>' + _e(_RECHECK_LABELS[recheck["status"]]) + '</strong></p>'
        + '<p class="scope muted">변경 또는 재확인 불가 입력 인덱스: <code>'
        + _e(recheck_indices) + '</code>. 모든 입력은 분석 전에 수집한 스냅샷으로 비교합니다. '
        '종료 시 제출 입력의 재확인 결과는 저장된 기록이며, 보고서 생성 시 현재 파일을 다시 읽지 않습니다.</p>'
    )
    return (
        '<!doctype html>\n<html lang="ko"><head><meta charset="utf-8">'
        '<meta name="viewport" content="width=device-width, initial-scale=1">'
        '<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; '
        'style-src \'unsafe-inline\'; base-uri \'none\'; form-action \'none\'">'
        '<title>DSP 저장 단계 비교 보고서</title><style>' + _STYLE
        + '</style></head><body><main><header><div class="eyebrow">'
        'SAVED WAV STAGES / LOCAL AUDIT</div><h1>저장된 DSP 단계 비교 보고서</h1>'
        '<span class="badge">LOCAL · OFFLINE</span><span class="badge">저장된 결과 · 정적 HTML</span>'
        '</header>' + candidate_notice + '<section class="card notice"><h2>실행기가 아닌 제출 파일 검사</h2>'
        '<p>이 검사는 외부 DSP 파이프라인에서 저장했다고 제출한 순서의 WAV 파일을 비교합니다. '
        '리샘플링·음량 조절·분할 조립을 직접 실행하는 기본 파이프라인 실행기와 다릅니다.</p>'
        '<p><strong>제출 순서는 검증되지 않았습니다.</strong> '
        '<code>caller_order_verified: false</code>. 파일 간 차이가 어느 실제 처리에서 생겼는지 확정하지 않습니다.</p>'
        '</section><section class="card summary ' + state + '"><div class="state">'
        + _e(status) + '</div><h2>' + _e(_AUDIT_STATE_LABELS[summary["exit_code"]])
        + '</h2><div class="metrics"><div class="metric"><span>좁은 범위의 종료 코드</span><b>'
        + _e(summary["exit_code"]) + '</b></div><div class="metric"><span>검사 시도 / 계획 단계</span><b>'
        + _e(summary["checked_stage_count"]) + ' / ' + _e(summary["planned_stage_count"])
        + '</b></div><div class="metric"><span>비교 범위</span><b>인접 단계 + 원본·최종</b>'
        '</div></div><p class="scope muted">코드 0: 지원 범위의 시간적 후보 없음 · '
        '코드 1: 후보 검토 필요 · 코드 2: 판단 보류 또는 분석 오류. '
        '앞선 우려는 뒤 단계의 결과로 지워지지 않습니다.</p></section>'
        '<section class="card"><h2>제출된 순서</h2><div class="flow">' + flow
        + '</div></section><section class="card"><h2>처음 관찰된 우려 지점</h2>'
        + first_view + '</section><section class="card"><h2>입력 재확인 기록</h2>'
        + recheck_view + '</section>' + ''.join(sections)
        + '<section class="card end"><h2>별도 검사 · 원본 → 최종 제출 출력</h2>'
        '<p class="muted scope">제출한 첫 입력과 마지막 출력 사이의 별도 저장 비교입니다.</p>'
        + final + '</section><section class="card"><h2>해석 범위</h2>'
        '<p>내부 삭제·인접 복사 반복의 시간적 후보를 다룹니다. 전체 음질 승인, 상용 성능 검증, '
        '결함 원인 확정 또는 보정된 확률을 뜻하지 않습니다. <code>complete_audio_approval: false</code>.</p>'
        '<p class="muted scope">보고서 생성은 오디오 재분석이나 입력·출력 파일 재확인을 하지 않습니다. '
        '저장된 결과 구조와 해시 연결의 일관성만 검증합니다. 원본 오디오와 절대 입력 경로를 포함하지 않으며, '
        '상대 스냅샷·분석 기록의 파일 이름은 클릭하거나 열 수 없는 텍스트입니다. '
        '외부 자원과 실행 스크립트가 없습니다.</p></section><footer>'
        '자체 포함 정적 HTML · 제출 순서는 자체 주장 · 저장된 비교 결과만 표시'
        '</footer></main></body></html>\n'
    )


def write_saved_pipeline_html(result: dict, path: str | Path) -> None:
    """Create a report exclusively; malformed results create no output."""
    rendered = render_saved_pipeline_html(result)
    with Path(path).open("x", encoding="utf-8", newline="\n") as stream:
        stream.write(rendered)
