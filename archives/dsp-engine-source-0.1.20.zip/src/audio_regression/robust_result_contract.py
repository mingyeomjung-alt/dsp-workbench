"""Strict version-2 candidate contract with unchanged raw evidence geometry.

The opt-in engine only revalidates balanced PCM16 microgaps. Its final result
keeps the version-1 metadata, anchor/event geometry, raw correlation, residual,
coverage and approval restrictions. Validate a private copy against those exact
restrictions after replacing only the explicitly checked engine/method names;
return the caller's original version-2 dictionary without mutating it. This is
structural validation, not proof that an engine or sidecar was actually run.
"""

from __future__ import annotations

from copy import deepcopy

from . import result_contract as _base
from .review_contract import with_review_diagnostics


ENGINE = "local_content_alignment_v2"
METHOD = "constrained_edit_alignment_with_pcm16_cancellation_revalidation"


@with_review_diagnostics
def validate_robust_analysis_result(value: object) -> dict:
    """Enforce the candidate's identity and shared strict raw-evidence rules."""
    if type(value) is not dict:
        raise _base.ResultContractError("invalid_result_type")
    # Bound depth and reject cycles/non-JSON values before attempting deepcopy.
    _base._json_tree(value)
    if value.get("engine") != ENGINE:
        raise _base.ResultContractError("unsupported_engine")
    if value.get("status") != "error":
        configuration = value.get("configuration")
        if type(configuration) is not dict or configuration.get("profile") != "basic":
            raise _base.ResultContractError("unsupported_profile")
        analysis = value.get("analysis")
        if type(analysis) is not dict or analysis.get("method") != METHOD:
            raise _base.ResultContractError("invalid_analysis_method")
    shared = deepcopy(value)
    shared["engine"] = _base.ENGINE
    if value.get("status") != "error":
        shared["analysis"]["method"] = "constrained_edit_alignment_with_raw_anchors"
    # The rewritten identifier is v1, so public dispatch cannot recurse here.
    _base.validate_analysis_result(shared)
    return value
