"""Opt-in single-event extension of the exact compound normal proof.

The new rescue is deliberately conditional: one internal grid-aligned source
delete or later adjacent repeat, unknown positive gain, fixed PCM/SRC order,
and exact nonnegative leading zeros. All output samples need one exact witness.
"""

from copy import deepcopy
import math
from pathlib import Path

import numpy as np

from . import compound_engine, instrument_engine as raw
from .analysis_scope import analysis_scope
from .audio import WavAudio, read_wav
from .compound_event_proof import FIR_RADIUS, GRID, _edited_source, prove_event
from .compound_gain import _render, quantization_bound
from .engine import RATE, EngineConfig, EngineConfigError, _corr
from .profiles import prepare_analysis


ENGINE = "local_content_alignment_v8"
METHOD = "exact_quantized_compound_event_forward_proof"
ELIGIBLE_REASONS = frozenset({"raw_landmark_unexplained_local_residual",
                            "raw_landmark_unexplained_local_change",
                            "insertion_not_supported_as_repetition"})


def _retained_summary(x, y, spans, gain):
    """Actual FIR-safe retained measurements; whole-model proof covers edges."""
    floor = quantization_bound() / math.sqrt(1 - .90 ** 2)
    count, squared, denominator, raw_minimum, minimum, quiet = 0, 0.0, 0.0, None, None, 0
    for first, last, offset in spans:
        a, b = gain * x[first:last], y[first + offset:last + offset]
        if len(a) != len(b) or not len(a):
            return None
        count += len(a)
        squared += float(np.dot(b - a, b - a))
        denominator += float(np.dot(a, a))
        width = min(960, len(a))
        starts = sorted(set(range(0, len(a) - width + 1, 480)) | {len(a) - width})
        for start in starts:
            left, right = a[start:start + width], b[start:start + width]
            correlation = _corr(left, right)
            raw_minimum = correlation if raw_minimum is None else min(raw_minimum, correlation)
            if float(np.std(left)) <= floor:
                quiet += 1
                continue
            minimum = correlation if minimum is None else min(minimum, correlation)
            if correlation < .90:
                return None
    nrmse = math.sqrt(squared / max(denominator, 1e-16))
    if minimum is None or nrmse > .08:
        return None
    return {"matched_analysis_samples": count, "matched_normalized_rmse": nrmse,
            "minimum_local_correlation": minimum, "raw_minimum_local_correlation": raw_minimum,
            "low_information_block_count": quiet, "low_information_std_ceiling": floor}


@analysis_scope
def analyze_buffers_with_trace(reference: WavAudio, processed: WavAudio,
                               config: EngineConfig | None = None) -> tuple[dict, dict]:
    settings = config if config is not None else EngineConfig()
    if not isinstance(settings, EngineConfig) or settings.profile != "basic":
        raise EngineConfigError("The compound-event candidate supports basic only.")
    baseline, old_trace = compound_engine.analyze_buffers_with_trace(reference, processed, settings)
    result = deepcopy(baseline)
    result["engine"] = ENGINE
    result["analysis"]["method"] = METHOD
    result["limitations"].append("v7 preserved; new rescue is one internal 1ms-grid source delete or canonical later "
        "adjacent complete source copy, 200-2000ms, declared gain/resampling, PCM16 16-to-8kHz and leading zeros. "
        "All supported context-bracket geometries need exact same-gain output proof within fixed budgets. "
        "Source-NCC is a conservative entry gate, not arbitrary source-history exclusion or edit provenance. "
        "Informative retained correlation excludes FIR boundary bands only from summaries, never from exact proof.")
    trace = {"schema_version": 1, "engine": ENGINE, "analysis_engine": ENGINE, "method": METHOD,
             "reference_sha256": reference.sha256, "processed_sha256": processed.sha256,
             "baseline_status": baseline["status"], "baseline_reason_code": baseline["reason_code"],
             "proof_path": "preserved_v7_result", "compound_event_attempted": False,
             "compound_event_proved": False, "inherited_v7_trace": deepcopy(old_trace),
             "result_status": result["status"], "reason_code": result["reason_code"]}
    if (baseline["status"] != "withheld" or baseline["reason_code"] not in ELIGIBLE_REASONS
            or not settings.allow_gain or not settings.allow_resampling
            or reference.sample_rate_hz != 16000 or processed.sample_rate_hz != RATE
            or len(reference.samples) % 2):
        return result, trace

    trace["compound_event_attempted"] = True
    x, y = prepare_analysis(reference), processed.samples
    points, attempted = raw._landmarks(x, y, math.ceil(settings.max_delay_ms * 8) + 16000, True)
    groups = raw._groups(points)
    trace.update(landmarks_attempted=attempted, landmarks_accepted=len(points),
                 offset_groups=[{"offset_samples": g["offset"], "landmark_count": len(g["points"])} for g in groups[:32]])

    def failure(reason):
        trace["compound_event_failure"] = reason
        return result, trace

    if (len(groups) != 2 or any(len(g["points"]) < 3 for g in groups)
            or any(any(p["offset"] != g["offset"] for p in g["points"]) for g in groups)):
        return failure("compound_event_unique_stable_context_not_supported")
    before, after = groups[0]["offset"], groups[1]["offset"]
    length = abs(after - before)
    kind = "delete" if before > after else "repeat"
    if (before < 0 or before / 8 > settings.max_delay_ms or np.any(y[:before])
            or not 1600 <= length <= 16000 or length % GRID
            or len(y) != before + len(x) + after - before):
        return failure("compound_event_length_or_leading_zero_hypothesis_not_supported")
    # Raw proposals may include ten samples of centered FIR ringing. For a
    # repeat, a unique after-offset window can start inside the source copy
    # and extend into following context, hence the extra copy-length allowance.
    lower = max(p["reference_start"] + p["width"] for p in groups[0]["points"]) - FIR_RADIUS
    upper = min(p["reference_start"] for p in groups[1]["points"]) + FIR_RADIUS
    upper += length if kind == "repeat" else -length
    lower = max(lower, FIR_RADIUS + 480, length if kind == "repeat" else 0)
    upper = min(upper, len(x) - FIR_RADIUS - 480 - (length if kind == "delete" else 0))
    trace["supported_boundary_bracket_samples"] = [lower, upper]
    if upper < lower:
        return failure("compound_event_context_bracket_not_supported")
    proof, proof_trace = prove_event(reference.samples, y[before:], kind, length, lower, upper)
    trace["event_proof_trace"] = proof_trace
    if proof is None:
        return failure(proof_trace["reason_code"])
    if type(proof) is not dict:
        return failure("compound_event_whole_output_exact_proof_failed")
    rendered, gain, point = proof.get("rendered"), proof.get("gain"), proof.get("point")
    if (type(point) is not int or point % GRID or not lower <= point <= upper
            or proof.get("length") != length or proof.get("kind") != kind
            or type(gain) not in (float, int) or not math.isfinite(gain) or gain <= 0
            or not isinstance(rendered, np.ndarray) or rendered.ndim != 1
            or len(rendered) != len(y) - before or not np.array_equal(rendered, y[before:])):
        return failure("compound_event_whole_output_exact_proof_failed")
    reconstructed = _render(_edited_source(reference.samples, point, length, kind), float(gain))
    if reconstructed is None or not np.array_equal(reconstructed, y[before:]):
        return failure("compound_event_whole_output_exact_proof_failed")
    right = point + length if kind == "delete" else point
    spans = [(0, point, before), (right, len(x), after)]
    # Re-prove three real anchors per side outside the FIR transition region.
    correlations, anchor_counts = [], []
    for group, (first, last, offset) in zip(groups, spans, strict=True):
        safe_first = first + (FIR_RADIUS if first else 0)
        safe_last = last - (FIR_RADIUS if last < len(x) else 0)
        accepted = [p for p in group["points"] if p["reference_start"] >= safe_first
                    and p["reference_start"] + p["width"] <= safe_last]
        if len(accepted) < 3:
            return failure("compound_event_insufficient_fir_safe_anchors")
        actual = []
        for p in accepted:
            start, width = p["reference_start"], p["width"]
            a, b = gain * x[start:start + width], y[start + offset:start + offset + width]
            correlation = _corr(a, b)
            if float(np.std(a)) <= quantization_bound() / math.sqrt(1 - .90 ** 2) or correlation < .90:
                return failure("compound_event_final_anchor_reproof_failed")
            actual.append(correlation)
        anchor_counts.append(len(actual))
        correlations.append([actual[0], actual[len(actual) // 2], actual[-1]])
    safe_spans = [(0, point - FIR_RADIUS, before), (right + FIR_RADIUS, len(x), after)]
    summary = _retained_summary(x, y, safe_spans, gain)
    if summary is None:
        return failure("compound_event_informative_retained_proof_failed")
    # Boundary correlations use actual untouched context beyond FIR support.
    left_a = gain * x[point - FIR_RADIUS - 480:point - FIR_RADIUS]
    left_b = y[point + before - FIR_RADIUS - 480:point + before - FIR_RADIUS]
    right_a = gain * x[right + FIR_RADIUS:right + FIR_RADIUS + 480]
    right_b = y[right + after + FIR_RADIUS:right + after + FIR_RADIUS + 480]
    boundary_correlation = (_corr(left_a, left_b) + _corr(right_a, right_b)) / 2
    if boundary_correlation < .90:
        return failure("compound_event_boundary_reproof_failed")
    evidence = {"boundary_correlation": boundary_correlation,
                "offset_before_ms": before / 8, "offset_after_ms": after / 8}
    if kind == "delete":
        event = {"type": "delete", "reference_interval_ms": [point / 8, (point + length) / 8],
                 "processed_boundary_ms": (point + before) / 8, "evidence": evidence}
    else:
        first = point - length
        interior = slice(first + FIR_RADIUS, point - FIR_RADIUS)
        copy_a = y[first + before + FIR_RADIUS:point + before - FIR_RADIUS]
        copy_b = y[point + before + FIR_RADIUS:point + before + length - FIR_RADIUS]
        source_correlation = min(_corr(gain * x[interior], copy_a), _corr(gain * x[interior], copy_b))
        adjacent_correlation = _corr(copy_a, copy_b)
        if (float(np.std(gain * x[interior])) <= quantization_bound() / math.sqrt(1 - .90 ** 2)
                or source_correlation < .90 or adjacent_correlation < .90):
            return failure("compound_event_copy_interior_reproof_failed")
        event = {"type": "repeat", "reference_source_interval_ms": [first / 8, point / 8],
                 "processed_added_interval_ms": [(point + before) / 8, (point + before + length) / 8],
                 "copy_interval_convention": "canonical_later_adjacent_copy_not_edit_provenance",
                 "evidence": {**evidence, "copy_correlation": source_correlation,
                              "adjacent_copy_correlation": adjacent_correlation}}
    nrmse = summary["matched_normalized_rmse"]
    result.update(status="analyzed", reason_code=None, content_preservation_status="defect_candidates",
                  events=[event], diagnostics={"gain_estimate": gain, "applied_gain": gain,
                  "matched_normalized_rmse": nrmse,
                  "matched_analysis_samples": summary["matched_analysis_samples"],
                  "anchor_run_count": 2, "minimum_local_correlation": summary["minimum_local_correlation"],
                  "normalized_path_cost": nrmse}, alignment_segments=[])
    for (first, last, offset), anchors in zip(spans, correlations, strict=True):
        result["alignment_segments"].append({"reference_interval_ms": [first / 8, last / 8],
            "processed_offset_ms": offset / 8, "anchor_correlations": anchors})
    trace.update(proof_path="compound_event_exact_forward", compound_event_proved=True,
                 result_status="analyzed", reason_code=None, event_kind=kind,
                 every_output_sample_exact=True, exact_output_sample_count=len(rendered),
                 leading_zero_sample_count=before, gain_witness=gain,
                 gain_is_unique_or_processing_provenance=False, canonical_anchor_counts=anchor_counts,
                 informative_retained_summary=summary, boundary_correlation=boundary_correlation,
                 exact_proof_includes_fir_boundaries_and_quiet_samples=True)
    return result, trace


def analyze_buffers(reference: WavAudio, processed: WavAudio, config: EngineConfig | None = None) -> dict:
    return analyze_buffers_with_trace(reference, processed, config)[0]


def analyze_wavs_with_trace(reference_path: str | Path, processed_path: str | Path,
                            config: EngineConfig | None = None) -> tuple[dict, dict]:
    return analyze_buffers_with_trace(read_wav(reference_path), read_wav(processed_path), config)
