"""V8 identity with inherited strict result geometry, not full-audio approval.

This inert contract does not open audio or a trace, prove the exact quantized
forward model, or establish general music quality, provenance or performance.
The opt-in engine preserves v7 results and adds a narrow compound event proof.
"""

from copy import deepcopy

from . import result_contract as _base
from .review_contract import with_review_diagnostics
from .compound_result_contract import validate_compound_analysis_result

ENGINE = "local_content_alignment_v8"
METHOD = "exact_quantized_compound_event_forward_proof"


@with_review_diagnostics
def validate_compound_event_analysis_result(value: object) -> dict:
    """Validate separate v8 identity using unchanged shared v7 rules."""
    if type(value) is not dict:
        raise _base.ResultContractError("invalid_result_type")
    _base._json_tree(value)
    if value.get("engine") != ENGINE:
        raise _base.ResultContractError("unsupported_engine")
    if value.get("status") != "error":
        analysis = value.get("analysis")
        if type(analysis) is not dict or analysis.get("method") != METHOD:
            raise _base.ResultContractError("invalid_analysis_method")
    shared = deepcopy(value)
    shared["engine"] = "local_content_alignment_v7"
    if value.get("status") != "error":
        shared["analysis"]["method"] = "interval_gain_quantized_compound_normal_proof"
    validate_compound_analysis_result(shared)
    return value
