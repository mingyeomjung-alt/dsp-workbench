"""Local facade with frozen v1 default and explicit candidate selections."""

from pathlib import Path

from .engine import EngineConfig, EngineConfigError, analyze_wavs
from .endpoint_mapping import map_alignment_endpoints
from .review_diagnostics import build_review_diagnostics
from .result_contract import validate_analysis_result


def _review_result(result: dict, trace: dict | None) -> dict:
    """Attach bounded explanation only; core decision and raw trace stay intact."""
    if result["status"] != "withheld":
        return result
    presented = dict(result)
    presented["review_diagnostics"] = build_review_diagnostics(result, trace)
    return validate_analysis_result(presented)


def analyze_pair(
    reference: str | Path,
    processed: str | Path,
    *,
    profile: str = "basic",
    allow_gain: bool = False,
    allow_resampling: bool = False,
    max_delay_ms: float = 1000.0,
    engine: str = "v1",
    resampling_model: str | None = None,
) -> dict:
    """Analyze a same-content PCM16 mono WAV pair with declared transformations.

    Returns diagnostic candidates after validating their engine-specific contract.
    Input/configuration exceptions propagate; no error is converted into a pass.
    Empty events are not whole-audio approval. v2 through v12 support basic only.
    Neither audio nor result is saved or sent by this function.
    """
    if type(engine) is not str or engine not in {"v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12"}:
        raise EngineConfigError("Use engine v1 through v12.")
    if engine != "v12" and resampling_model is not None:
        raise EngineConfigError("A named resampling model requires engine v12.")
    config = EngineConfig(profile=profile, allow_gain=allow_gain,
                          allow_resampling=allow_resampling, max_delay_ms=max_delay_ms)
    trace = None
    if engine == "v12":
        from .resampler_engine import analyze_wavs_with_trace
        result, trace = analyze_wavs_with_trace(Path(reference), Path(processed), config,
                                               resampling_model=resampling_model)
    elif engine == "v1":
        result = analyze_wavs(Path(reference), Path(processed), config)
    else:
        if profile != "basic":
            raise EngineConfigError("The candidates support the basic profile only.")
        if engine == "v2":
            from .robust_engine import analyze_wavs_with_trace
        elif engine == "v3":
            from .context_engine import analyze_wavs_with_trace
        elif engine == "v4":
            from .instrument_engine import analyze_wavs_with_trace
        elif engine == "v5":
            from .canonical_engine import analyze_wavs_with_trace
        elif engine == "v6":
            from .repeat_engine import analyze_wavs_with_trace
        elif engine == "v7":
            from .compound_engine import analyze_wavs_with_trace
        elif engine == "v8":
            from .compound_event_engine import analyze_wavs_with_trace
        elif engine == "v9":
            from .global_context_engine import analyze_wavs_with_trace
        elif engine == "v10":
            from .short_event_engine import analyze_wavs_with_trace
        else:
            from .edge_event_engine import analyze_wavs_with_trace
        result, trace = analyze_wavs_with_trace(Path(reference), Path(processed), config)
    return _review_result(map_alignment_endpoints(result), trace)


def analyze_pair_with_trace(reference: str | Path, processed: str | Path, *,
                            profile: str = "basic", allow_gain: bool = False,
                            allow_resampling: bool = False, max_delay_ms: float = 1000.0,
                            engine: str = "v1", resampling_model: str | None = None) -> tuple[dict, dict | None]:
    """Return mapped results with review explanation and unchanged raw trace."""
    if type(engine) is not str or engine not in {"v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9", "v10", "v11", "v12"}:
        raise EngineConfigError("Use engine v1 through v12.")
    if engine != "v12" and resampling_model is not None:
        raise EngineConfigError("A named resampling model requires engine v12.")
    config = EngineConfig(profile=profile, allow_gain=allow_gain,
                          allow_resampling=allow_resampling, max_delay_ms=max_delay_ms)
    if engine == "v12":
        from .resampler_engine import analyze_wavs_with_trace
        result, trace = analyze_wavs_with_trace(Path(reference), Path(processed), config,
                                               resampling_model=resampling_model)
        return _review_result(map_alignment_endpoints(result), trace), trace
    if engine == "v1":
        return analyze_pair(reference, processed, profile=profile, allow_gain=allow_gain,
                            allow_resampling=allow_resampling, max_delay_ms=max_delay_ms), None
    if profile != "basic":
        raise EngineConfigError("The candidates support the basic profile only.")
    if engine == "v2":
        from .robust_engine import analyze_wavs_with_trace
    elif engine == "v3":
        from .context_engine import analyze_wavs_with_trace
    elif engine == "v4":
        from .instrument_engine import analyze_wavs_with_trace
    elif engine == "v5":
        from .canonical_engine import analyze_wavs_with_trace
    elif engine == "v6":
        from .repeat_engine import analyze_wavs_with_trace
    elif engine == "v7":
        from .compound_engine import analyze_wavs_with_trace
    elif engine == "v8":
        from .compound_event_engine import analyze_wavs_with_trace
    elif engine == "v9":
        from .global_context_engine import analyze_wavs_with_trace
    elif engine == "v10":
        from .short_event_engine import analyze_wavs_with_trace
    else:
        from .edge_event_engine import analyze_wavs_with_trace
    result, trace = analyze_wavs_with_trace(Path(reference), Path(processed), config)
    return _review_result(map_alignment_endpoints(result), trace), trace
