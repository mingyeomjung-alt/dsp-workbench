"""Independent native-rate measurements, never a temporal or quality gate.

No alignment, gain fitting, resampling, waveform repair or old detector runs.
Same-index comparisons are withheld for rate or length mismatch while each
file's original-rate measurements are still retained. Saved measurement
completion must not be interpreted as audio approval.
"""
from __future__ import annotations

import hashlib
import os
from pathlib import Path
import re

from .audio import AudioInputError
from .fullband_contract import derive_fullband_summary, validate_fullband_result
from .fullband_metrics import BAND_EDGES_HZ, FRAME_DURATION_MS, FullbandMetricError, measure_audio, measure_pair
from .model_check import ModelCheckError, _checked_input_bytes, _input
from .pipeline_runner import PipelineRunError, _absolute_path, _new_bytes, _new_json, _normal_parents
from .result_contract import ResultContractError


_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}\Z")


class FullbandRunError(ValueError):
    """A stable, non-private code; no waveform or local path is exposed."""
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__("Native-rate measurement could not complete: " + code + ".")


def _code(error: Exception) -> str:
    if isinstance(error, (FullbandRunError, FullbandMetricError, ModelCheckError,
                          PipelineRunError, AudioInputError, ResultContractError)):
        code = getattr(error, "code", None)
        if type(code) is str and _CODE.fullmatch(code):
            return {"invalid_model_input_file": "invalid_fullband_input_file",
                    "model_input_changed_during_read": "fullband_input_changed_during_read"}.get(code, code)
    return "fullband_measurement_execution_error"


def run_fullband_measurement(reference: str | Path, processed: str | Path, output_dir: str | Path) -> dict:
    """Measure a bounded pair once, preserving fresh snapshots and failures.

    Returned exit code 0 means measurements were computed, not that either
    file is correct, defect-free, perceptually good, or suitable for approval.
    Observable unsafe paths or changes to named inputs/snapshots are rejected.
    Started evidence remains on failure; no existing file is overwritten.
    """
    started = False
    output = None
    try:
        reference_path, reference_raw, reference_audio = _input(reference)
        processed_path, processed_raw, processed_audio = _input(processed)
        output = _absolute_path(output_dir)
        if os.path.lexists(output):
            raise FullbandRunError("output_directory_exists")
        _normal_parents(output)
        reference_metrics = measure_audio(reference_audio)
        processed_metrics = measure_audio(processed_audio)
        comparison = measure_pair(reference_audio, processed_audio)
        result = {
            "schema_version": 1, "engine": "native_fullband_measurements_v1",
            "status": "measured" if comparison["status"] == "measured" else "comparison_withheld",
            "reason_code": comparison["reason_code"],
            "reference": reference_audio.metadata(), "processed": processed_audio.metadata(),
            "reference_measurements": reference_metrics, "processed_measurements": processed_metrics,
            "comparison": comparison,
            "configuration": {"frame_duration_ms": FRAME_DURATION_MS, "band_edges_hz": list(BAND_EDGES_HZ),
                              "spectrum": "full_record_rectangular_rfft_parseval",
                              "auto_alignment": False, "resampling": False, "gain_compensation": False},
            "summary": derive_fullband_summary(comparison),
            "artifacts": {"reference": "input/reference.wav", "processed": "input/processed.wav"},
            "complete_audio_approval": False, "commercial_performance_validated": False,
            "network_used": False, "fault_provenance_confirmed": False,
        }
        validate_fullband_result(result)
        output.parent.mkdir(parents=True, exist_ok=True)
        _normal_parents(output)
        output.mkdir(exist_ok=False)
        started = True
        _new_json(output / "manifest_started.json", {
            "schema_version": 1, "engine": result["engine"], "status": "started",
            "reference": result["reference"], "processed": result["processed"],
            "configuration": result["configuration"], "quality_verdict": "not_assessed",
            "network_used": False, "fault_provenance_confirmed": False,
        })
        (output / "input").mkdir()
        _new_bytes(output / result["artifacts"]["reference"], reference_raw)
        _new_bytes(output / result["artifacts"]["processed"], processed_raw)
        for path, metadata in ((reference_path, result["reference"]),
                               (processed_path, result["processed"]),
                               (output / result["artifacts"]["reference"], result["reference"]),
                               (output / result["artifacts"]["processed"], result["processed"])):
            if hashlib.sha256(_checked_input_bytes(path)).hexdigest() != metadata["sha256"]:
                raise FullbandRunError("fullband_input_or_snapshot_changed_during_run")
        _new_json(output / "fullband_result.json", result)
        return result
    except Exception as error:
        code = _code(error)
        if started and output is not None:
            try:
                _new_json(output / "run_failed.json", {
                    "schema_version": 1, "status": "error", "reason_code": code,
                    "exit_code": 3, "quality_verdict": "not_assessed", "complete_audio_approval": False,
                })
            except (PipelineRunError, OSError):
                pass
        raise FullbandRunError(code) from None
