# 원래 샘플레이트 전대역 측정

원본과 처리본의 PCM 샘플을 원래 레이트에서 그대로 측정한다. 기존 8 kHz 시간 분석, 선언 모델 검사와 분리된 기능이며 리샘플링·자동 정렬·음량 맞춤·보정은 하지 않는다. 측정 완료는 음질 합격이나 결함 원인 확정이 아니다.

## 측정 항목

각 파일에서 DC 오프셋, 평균 제곱 에너지, RMS·샘플 피크 dBFS, 피크/RMS 크레스트 팩터, PCM 양·음 끝값 점유와 같은 부호 끝값의 최장 연속 길이를 계산한다. 끝값은 +32767과 -32768이며, 점유와 연속 길이는 클리핑 대리 지표이지 실제 클리핑이나 원인 증명이 아니다. 절대 피크 -32767은 양의 끝값과 크기가 같아도 음의 끝값에는 해당하지 않는다. dBFS는 디지털 PCM 기준이며 장비 보정된 음압 dB SPL이나 LUFS가 아니다.

전체 기록에 창·DC 제거·패딩 없이 rFFT를 적용한다. 단측 DFT 에너지에서 DC와 짝수 길이 Nyquist 빈의 가중치는 1, 나머지는 2이며 총합은 시간 영역 평균 제곱 에너지와 대조한다. 대역은 빈의 중심 주파수로 나눈다. 고정 경계는 0·250·500·1000·2000·4000·8000·16000·24000 Hz이고, 입력 Nyquist에서 자른 마지막 유효 대역만 상단을 포함한다. 입력의 Nyquist 밖 대역은 `not_available`와 `null`이며 측정 가능한 무음 에너지 0과 구분한다. 주파수 누설이 있는 전체 기록의 에너지 분해이지 지각적 음질 점수가 아니다.

100 ms 비중첩 프레임의 에너지와 피크를 측정하며 마지막 부분 프레임도 보존한다. 좌표는 시작 샘플 포함·끝 샘플 미포함이다. 원본과 처리본의 레이트·샘플 수가 같을 때만 동일한 원시 인덱스에서 차이를 계산한다. 다른 샘플 수, 첫·마지막 차이 샘플, 최대 절대 PCM 정수 차이, 잔차 평균 제곱·대역 에너지, 변화 프레임, 평균 중심 Pearson 상관을 제공한다. 정렬된 좌표나 자동 결함 분류가 아니다.

`signal_to_residual_db`는 원본 에너지와 두 파일의 차이 에너지 비율이다. 주변 소음과 음성의 SNR이 아니다. 차이 에너지 0·원본 에너지 0·상수 신호의 상관 등 정의되지 않는 계산은 사유와 `null`을 기록하며 Infinity·NaN으로 표시하지 않는다. 진폭 차이를 int32에서 계산해 65535 PCM 정수 차이가 overflow하지 않도록 한다.

## 사용

입력은 PCM16 모노 WAV, 각 2~30초, 8·16·44.1·48 kHz다. 입력 레이트가 달라도 각 파일은 자체 레이트에서 측정한다. 이 경우 또는 길이가 다른 경우 직접 쌍 비교만 보류하며 자동으로 겹치는 구간을 잘라 비교하지 않는다.

```powershell
audio-fullband-check measure --reference original.wav --processed actual.wav --output-dir new_fullband_run
audio-fullband-check report --input new_fullband_run/fullband_result.json --output new_fullband_review.html
```

소스에서는 `python -m audio_regression.fullband_cli`를 사용한다. 새 출력 디렉터리와 HTML은 기존 경로를 덮어쓰지 않는다.

```python
from audio_regression.fullband_runner import run_fullband_measurement

result = run_fullband_measurement("original.wav", "actual.wav", "new_fullband_run")
print(result["comparison"]["residual_bands"])
```

| 종료 코드 | 의미 |
| --- | --- |
| measure 0 | 쌍 측정 계산 완료. 차이가 있어도 0이며 음질 통과 아님 |
| measure 2 | 레이트·샘플 수 불일치로 직접 비교 보류. 개별 파일 측정 보존 |
| measure 3 | 입력·명세·저장·실행 오류 |
| report 0 / 3 | 저장 결과에서 보고서 생성 / 결과·출력 오류 |

원본·처리본 사본과 선언된 측정 설정을 보존하고 종료 전에 입력과 사본의 해시·관측 가능한 경로 상태를 다시 확인한다. 시작 후 실패 기록과 사본은 지우지 않는다. 저장 보고서는 JSON만 읽어 현재 오디오 파일·실행 진위를 다시 확인하지 않는다. 모든 파일 시스템 경쟁을 원자적으로 방지하는 기능은 아니다.

0.1.16은 공통 읽기 검사를 보완해 경로와 열린 파일의 전후 크기·시간·식별 정보를 확인한다. 읽는 도중 같은 파일이 변경되면 `fullband_input_changed_during_read`로 실패하며 측정 완료 결과를 저장하지 않는다. 관측 가능한 링크·하드링크 입력도 오류로 거부한다. 기존의 0은 측정 완료일 뿐 음질 합격이 아니라는 의미는 유지한다.

새 명세는 저장 자료의 구조를 검사하고 Python 계약은 좌표·에너지·측정 사유의 의미적 일관성을 추가 검사한다. 기존 검출·선언 모델·단계별 검사 명세와 판정은 그대로다. 기존 `audio-regression check`에 이 새 측정 결과를 넣으면 검사 계약 오류로 차단되며, 새 측정 완료를 기존 품질 통과로 합산하지 않는다.

실행 예제: `python tools/run_fullband_demo.py --output-dir examples/my_new_fullband_demo`. 자체 생성한 PCM만 사용하며 이전 자연음·봉인 평가나 개인 녹음을 반복하지 않는다.
