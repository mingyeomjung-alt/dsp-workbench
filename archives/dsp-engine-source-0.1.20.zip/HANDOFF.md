# 로컬 오디오 회귀검사 시제품 사용 안내

0.1.20 SDK는 `audio-regression-suite run --manifest my_suite/manifest.json --output-dir suite_run_new`로 최대 20개 원본·기준 출력·새 출력 사례를 검사한다. 기존 분석기·기본 v1·입력 형식은 유지하며 [현재 SDK 안내](README.md)의 새 시험 묶음 규격을 따른다. 현재 새 출력의 판정과 기준 대비 후보 변화를 별도로 보며 보류를 통과로 바꾸지 않는다. 출력에는 로컬 WAV 사본도 있으므로 보고서 공유와 오디오 공유를 구분한다. 기존 0.1.19 Windows 실행판은 보존하며 이 명령줄 전용 추가 기능을 포함한 새 EXE로 소개하지 않는다.

설치 후 `audio-regression-suite --help` 또는 `python -m audio_regression.regression_suite_cli --help`로 확인한다. 아래 이전 버전 변경·설치 기록은 당시의 안내이며 현재 wheel은 별도의 0.1.20 인계 폴더를 사용한다.

0.1.14의 [로컬 검사와 보관본 확인](CHECKS.md)은 검사 결과를 통합하며 기존 음원 판정을 바꾸지 않는다. 설치본의 `audio-artifact-check verify`는 외부 해시 기준의 읽기 전용 파일 확인이고, 소스 도구 `run_local_checks.py`는 선택 시험을 실행한다. 검사 완료와 음질·진위·실행 내력 승인을 구분한다.

0.1.13의 [전대역 측정](FULLBAND.md)은 원래 레이트에서 대역·레벨·PCM 차이를 기록하는 독립 기능이다. 기본 엔진이나 시간·모델 검사의 승인 정책을 바꾸지 않으며 측정 완료 코드 0은 품질 통과가 아니다. 기존 분석 결과와 새 측정 명세를 섞어 검사하지 않는다.

0.1.12의 새 기능은 [선언된 DSP 모델 검사](TRANSFORMS.md)다. 극성 반전·고정 FIR·12비트 양자화를 원본에만 적용해 기대 WAV를 만들고 처리본과 비교한다. `audio-transform-check`는 별도 명령이며 기존 분석과 단계별 검사·자동 보류 기준은 바꾸지 않는다. 새 기대본과 실제 처리본의 좌표를 원본의 결함 발생 원인으로 확정하지 않는다.

0.1.11은 보류 결과의 `review_diagnostics`와 한국어 검토 안내를 추가한다. 최종 사유와 실제 저장된 추가 검사 기록을 구분하고, 미시도·미기록을 실패로 해석하지 않는다. 기본 판정·원시 추적·입력·검색 예산은 유지한다. 기존 JSON을 읽을 수 있으며 새 설명 필드가 있는 결과의 읽기 도구·명세는 0.1.11로 갱신한다. 분석 완료와 최소 오류 응답의 형식은 그대로다.

0.1.10은 정렬 중간 행렬 복사를 없애고 검색 범위 안의 행 상태·역추적만 저장한다. 중첩 엔진의 리샘플링·필터 계산은 한 호출 안에서만 재사용하며 호출 종료·예외 시 캐시와 입력 참조를 해제한다. 특징 내적은 같은 계산 순서를 유지하므로 여전히 전체 행렬이다. 2~30초 입력, 기본 v1, 판정·임계값·검색 예산과 결과 명세는 유지한다. 처리 자원 개선은 정확도 향상이나 전체 음원 승인을 뜻하지 않는다.

0.1.9에서는 직접 배열 입력이 실제 PCM16 값인지 확인하고, 잘못된 형식·잘못된 해시 형식을 거부한다. 원본 파일은 샘플이나 부가 청크의 해시를 바꾸지 않고 읽는다. SHA-256 형식 확인은 파일 진위 인증이 아니다. 실수 배열을 변환하려면 의도적으로 `decode_wav(encode_wav(...))`를 호출해야 한다. 명령줄의 오류 응답은 종료 코드 3이며 예상 밖 처리 예외의 경로·문구는 출력하지 않는다. 기본 엔진과 검출 기준은 그대로다.

같은 내용의 원본과 처리본을 넣어 내부 구간 삭제·인접 중복 후보와 위치를 조사하는 로컬 도구다. 음성인증·음질 승인·자동 복원 도구가 아니다. 기본 프로필은 M3의 제한된 자료에서 목표를 충족했지만 전화 프로필은 목표 미달이다. 전화 결과와 판단 보류는 자동 검사에서 통과시키지 않는다.

처리 단계 자체를 실행하고 중간 결과를 보존하려면 [단계별 파이프라인 안내](PIPELINE.md)를 사용한다. 최신 인계물에는 `audio-pipeline-check` 명령이 추가됐고 기존 `audio-regression` 명령은 그대로 유지한다. 이전 M4 인계물에는 새 명령이 없으므로 두 패키지의 보관 폴더와 해시를 구분한다.

사용자의 처리 코드에서 이미 저장한 중간 WAV는 [저장 단계 검사](SAVED_PIPELINE.md)의 `audit`으로 연결한다. 외부 처리 프로그램은 실행하지 않으며 파일 순서와 실제 실행 내력은 확인되지 않는다.

현재 0.1.1은 홀수 샘플 등 리샘플링 후 마지막 좌표가 원본 길이를 넘는 버그를 공개 API·명령줄·단계별 검사에서 수정한다. 원본 샘플·파일 길이·사건·오프셋·보류 규칙을 유지하고, 확인된 분석 패딩의 마지막 끝점만 실제 원본·처리본 길이에 맞춘다. 과거 0.1.0 인계물에는 이 수정이 없으며 설치 경로와 버전을 구분해야 한다.

0.1.2는 위 끝점 수정과 함께 [선택형 악기·타악기 연구 후보](INSTRUMENT.md)를 포함한다. `--engine v4`를 선택해야 추가 경로를 쓰며 기본 v1은 그대로다. 개발 신호 개선과 독립 자연 음원 검증을 구분한다.

## 설치하고 사용하기

Windows x64와 Python 3.12.14에서 확인했다. 깨끗한 Python 3.12 가상환경을 만들고 이번 버전 제약으로 NumPy 2.5.3·SciPy 1.18.1을 설치한다. 의존성은 자체 wheel에 포함되지 않는다. 아래 예시의 wheel 경로는 생성한 인계 디렉터리의 실제 파일로 바꾼다.

```powershell
python -m venv .dsp-runtime
.\.dsp-runtime\Scripts\python.exe -m pip install -c constraints.txt numpy scipy
.\.dsp-runtime\Scripts\python.exe -m pip install --no-deps path\to\audio_regression_engine-0.1.14-py3-none-any.whl
.\.dsp-runtime\Scripts\audio-regression.exe --help
```

의존성 설치는 네트워크 접근을 수반할 수 있다. 이번 인계 검증은 기존에 설치된 두 의존성만 새 격리 환경으로 복사하고 자체 wheel을 오프라인으로 설치했다. 이 방식은 새 플랫폼에서 의존성 다운로드·설치가 검증됐다는 뜻이 아니다. 플랫폼별 오프라인 배포가 필요하면 별도 승인된 의존성 wheel 저장소와 원문 고지를 준비한다.

## 파일 쌍 분석과 보고서

PCM16 모노 WAV, 파일당 2~30초·최대 10 MB, 8·16·44.1·48 kHz를 입력한다. 동일 내용을 별도로 다시 발화한 두 녹음이 아니라 같은 입력의 처리 전후 파일을 사용한다. 실제로 허용한 고정 이득·리샘플링만 선언한다. 원본은 변경하지 않는다.

```powershell
audio-regression analyze --reference reference.wav --processed processed.wav --output result.json
audio-regression report --input result.json --output review.html
audio-regression check --input result.json
```

`report`는 이미 저장된 결과만 읽어 정적 HTML을 만든다. 음성 분석을 재실행하거나 파일을 업로드하지 않는다. 출력이 존재하면 거절하고 새 파일에만 저장한다. 실제 허용 변환에 이득 또는 리샘플링이 있으면 `analyze`에 `--declare-gain`, `--declare-resampling`을 추가한다. `--profile telephone`은 실험적 분석용이며 자동 검사 통과 대상으로 쓰지 않는다.

설치된 콘솔 명령은 새 사용 명령을 포함한다. 기존 `python -m audio_regression`은 변경하지 않은 분석 명령을 유지하고, 새 기능의 모듈 호출은 `python -m audio_regression.handoff_cli`다.

## Python 라이브러리

```python
from audio_regression.api import analyze_pair
from audio_regression.check_policy import check_result
from audio_regression.reporting import write_html_report

result = analyze_pair("reference.wav", "processed.wav", profile="basic")
gate = check_result(result)
write_html_report(result, "review.html")
raise SystemExit(gate["exit_code"])
```

입력·설정 예외는 호출자에게 전달된다. `result_contract.validate_analysis_result`와 `load_analysis_result`로 저장된 결과도 엄격하게 검증할 수 있다. 크기가 과도하거나 중복 JSON 키·비정상 숫자·알 수 없는 버전·모순된 결과는 자동 통과시키지 않는다.

## 자동 검사 종료 코드

| 명령과 결과 | 코드 | 의미 |
| --- | ---: | --- |
| `check`: 기본 프로필, 분석 완료, 사건 후보 없음 | 0 | 지원 범위의 시간적 검사만 후보 없음 |
| `check`: 기본 프로필, 결함 후보 있음 | 1 | 사람의 구간 검토 필요 |
| `check`: 보류·전화·입력 오류·알 수 없는 결과 | 2 | 해당 검사를 통과시키지 않음 |
| `analyze`: 분석 실행 완료 | 0 | 실행 성공이며 내용 보존 통과가 아님 |
| `analyze`: 보류 | 2 | 판단 불가 |
| `analyze` / `report`: 입력·출력 오류 | 3 | 요청 또는 파일 처리 실패 |

`analyze`의 종료 코드 0을 전체 검수 통과로 사용하면 안 된다. 자동 검사에서는 구조화된 결과를 검증하는 `check`를 별도로 호출한다. 후보 없음도 클리핑·주파수 대역·전사 정확도·모든 결함이 정상이라는 판정이 아니다. 모든 결과에서 전체 음원 승인과 상용 성능 검증 표시는 false를 유지한다.

## 시간축과 결과 명세

패키지의 `audio_regression/schemas/analysis-result-v1.schema.json`에 구조 명세가 있다. 런타임 검증은 명세에 더해 구간 길이·파일 길이·상태 간 일관성을 확인한다. 삭제의 `reference_interval_ms`는 원본에서 없어진 구간이고 `processed_boundary_ms`는 처리본에서 이어진 경계다. 중복의 `reference_source_interval_ms`는 원본 복사 구간, `processed_added_interval_ms`는 처리본의 추가 구간이다. 인접한 동일 복사본 중 나중 복사본을 표시하는 규칙이며 실제 편집 내력을 증명하지 않는다.

`status=withheld`의 사건은 null이며 빈 사건 목록과 다르다. `status=analyzed`의 빈 목록은 지원 범위의 후보 없음이다. 상관과 정합 비용은 관측 수치이지 정확도 확률이 아니다. 기본 사건 범위는 식별 가능한 내부 200~2000 ms 삭제·인접 중복과 최대 2000 ms 누적 편집 이동이다. 명세 검증은 구조·일관성을 확인하는 절차이며 결과에 서명하거나 원음으로부터 실제 생성됐다는 것을 증명하지 않는다. 자동 검사에는 자신의 신뢰할 수 있는 처리 경로에서 생성한 결과를 사용한다.

## 개발 예제와 인계 보관

소스 작업 공간에서는 다음처럼 새 경로에 개발 예제를 만들 수 있다. 저장된 최종 평가 자료를 다시 쓰지 않는다.

```powershell
$env:PYTHONPATH = (Resolve-Path -LiteralPath 'src').Path
python tools/run_handoff_demo.py --output-dir examples/my_new_handoff_demo
```

이 명령은 정상·삭제·중복·무음 보류·실험적 전화 예제를 만들고 JSON·HTML·자동 검사 결과를 저장한다. 예제는 자연음 성능을 입증하는 자료가 아니다. 소스 스냅샷을 빌드한 인계물에는 재현 도구도 포함해야 한다.

wheel·소스 스냅샷·설치 시험은 로컬 사용을 준비한 결과다. 전체 성능 목표 미달, 작은 평가 규모, 실통화·고객 업무 효과 미검증은 남는다. 추가 평가나 새 기능을 무한 반복하지 않고 현재 범위와 한계를 인계한다. 저장소 공개·외부 배포·판매·호스팅은 수행하지 않았다. 의존성과 개인정보 취급은 `THIRD_PARTY_NOTICES.md`를 함께 확인한다.
