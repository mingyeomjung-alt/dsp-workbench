"""Policy tests never rerun a detector or touch the locked M3 evaluation."""

from copy import deepcopy
from pathlib import Path

import pytest

from audio_regression.check_policy import blocked_contract_error, check_result
from audio_regression.result_contract import load_analysis_result


DEVELOPMENT = Path(__file__).resolve().parent / "fixtures" / "results"


def _result(kind="clean", profile="basic"):
    return deepcopy(load_analysis_result(DEVELOPMENT / f"synthetic_{profile}_{kind}.json"))


def _invariants(summary):
    assert summary["complete_audio_approval"] is False
    assert summary["commercial_performance_validated"] is False
    assert summary["probability_claims"] is False
    assert summary["scope"] == "supported_temporal_candidates_only"
    assert "probability" not in summary


def test_basic_empty_events_clear_only_the_supported_temporal_check():
    result = _result()
    before = deepcopy(result)
    summary = check_result(result)
    assert summary["gate_state"] == "clear_supported_temporal_check"
    assert summary["exit_code"] == 0
    assert summary["contract_valid"] is True
    assert summary["event_count"] == 0
    assert summary["source_status"] == "analyzed"
    assert summary["profile"] == "basic"
    assert summary["content_preservation_status"] == "no_supported_defect_candidates"
    assert result == before
    _invariants(summary)


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_basic_defect_candidate_requires_review(kind):
    summary = check_result(_result(kind))
    assert summary["gate_state"] == "review_required"
    assert summary["exit_code"] == 1
    assert summary["event_count"] == 1
    assert summary["contract_valid"] is True
    assert summary["reason_code"] == "supported_temporal_defect_candidates"
    _invariants(summary)


@pytest.mark.parametrize("kind", ["clean", "delete", "repeat"])
def test_experimental_telephone_always_blocks_after_m3_target_miss(kind):
    summary = check_result(_result(kind, "telephone"))
    assert summary["gate_state"] == "blocked"
    assert summary["exit_code"] == 2
    assert summary["reason_code"] == "telephone_profile_experimental_m3_target_miss"
    assert summary["contract_valid"] is True
    _invariants(summary)


def test_withheld_is_blocked_and_has_no_event_count():
    result = _result()
    result.pop("alignment_segments")
    result.update(status="withheld", content_preservation_status="withheld",
                  events=None, reason_code="insufficient_signal_variation", diagnostics={})
    summary = check_result(result)
    assert summary["gate_state"] == "blocked"
    assert summary["exit_code"] == 2
    assert summary["reason_code"] == "analysis_withheld"
    assert summary["contract_valid"] is True
    assert summary["event_count"] is None
    _invariants(summary)


def test_existing_cli_error_is_blocked():
    summary = check_result({"schema_version": 1, "status": "error", "reason_code": "file_read_error"})
    assert summary["gate_state"] == "blocked"
    assert summary["exit_code"] == 2
    assert summary["reason_code"] == "analysis_error"
    assert summary["source_status"] == "error"
    assert summary["contract_valid"] is True
    _invariants(summary)


@pytest.mark.parametrize("result", [None, {}, [], {"schema_version": 2, "status": "analyzed"},
                                     {"schema_version": 1, "status": []}])
def test_malformed_and_unknown_results_fail_closed(result):
    summary = check_result(result)
    assert summary["gate_state"] == "blocked"
    assert summary["exit_code"] == 2
    assert summary["contract_valid"] is False
    assert summary["source_status"] is None
    assert summary["profile"] is None
    assert summary["event_count"] is None
    _invariants(summary)


@pytest.mark.parametrize("field,replacement", [("engine", "global_alignment_baseline_v1"),
                                                ("schema_version", 99), ("complete_audio_approval", True)])
def test_unsupported_engine_schema_or_approval_claim_cannot_clear(field, replacement):
    result = _result()
    result[field] = replacement
    summary = check_result(result)
    assert summary["gate_state"] == "blocked"
    assert summary["exit_code"] == 2
    assert summary["contract_valid"] is False
    _invariants(summary)


def test_unknown_profile_and_nonfinite_metric_cannot_clear():
    for mutate in (lambda result: result["configuration"].update(profile="unknown"),
                   lambda result: result["diagnostics"].update(matched_normalized_rmse=float("nan")),
                   lambda result: result["diagnostics"].update(matched_normalized_rmse=10),
                   lambda result: result["diagnostics"].update(minimum_local_correlation=0.1)):
        result = _result()
        mutate(result)
        summary = check_result(result)
        assert summary["gate_state"] == "blocked"
        assert summary["exit_code"] == 2
        _invariants(summary)


def test_loader_failure_helper_keeps_full_fail_closed_summary():
    summary = blocked_contract_error("duplicate_json_key")
    assert summary["gate_state"] == "blocked"
    assert summary["exit_code"] == 2
    assert summary["reason_code"] == "duplicate_json_key"
    assert summary["contract_valid"] is False
    assert summary["source_status"] is None
    _invariants(summary)


def test_held_result_cannot_approve_through_empty_list():
    result = _result()
    result.update(status="withheld", content_preservation_status="withheld", reason_code="ambiguous_alignment")
    summary = check_result(result)
    assert summary["gate_state"] == "blocked"
    assert summary["exit_code"] == 2
    assert summary["contract_valid"] is False
    _invariants(summary)
