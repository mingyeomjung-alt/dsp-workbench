import copy
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

from audio_regression import regression_suite_cli
from audio_regression.fixtures import generate_case
from audio_regression.regression_suite_contract import (
    SuiteError, build_suite_summary, incomplete_case_delta,
)
from test_regression_suite_reporting import _sample_suite


def _save(tmp_path, value, name="suite.json"):
    path = tmp_path / name
    path.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    return path


def _manifest(tmp_path, kind="clean"):
    case = generate_case(kind, seed=381927)
    declarations = {}
    for role, raw in (("source", case.reference_wav), ("baseline", case.reference_wav), ("candidate", case.processed_wav)):
        (tmp_path / f"{role}.wav").write_bytes(raw)
        declarations[role] = {"path": f"{role}.wav", "sha256": hashlib.sha256(raw).hexdigest()}
    return _save(tmp_path, {
        "schema_version": 1, "suite_id": "cli_test", "baseline_version": "before",
        "candidate_version": "after", "cases": [{"case_id": "case_1", **declarations,
        "configuration": {"engine": "v1", "allow_gain": False, "allow_resampling": False,
                          "max_delay_ms": 1000.0, "resampling_model": None}}],
    }, "manifest.json")


@pytest.mark.parametrize("kind, expected_code", [("clean", 0), ("delete", 1)])
def test_real_run_generates_result_report_and_preserves_inputs(tmp_path, capsys, kind, expected_code):
    manifest = _manifest(tmp_path, kind)
    before = {name: (tmp_path / f"{name}.wav").read_bytes() for name in ("source", "baseline", "candidate")}
    output = tmp_path / "new_output"
    assert regression_suite_cli.main(["run", "--manifest", str(manifest), "--output-dir", str(output)]) == expected_code
    summary = json.loads(capsys.readouterr().out)
    assert summary["summary"]["exit_code"] == expected_code
    assert summary["summary"]["case_count"] == 1
    assert summary["complete_audio_approval"] is False
    assert summary["network_used"] is False
    assert (output / "suite_result.json").is_file()
    assert (output / "suite_report.html").is_file()
    for name, raw in before.items():
        assert (tmp_path / f"{name}.wav").read_bytes() == raw


@pytest.mark.parametrize("value, expected_code", [
    (_sample_suite((("clean", "clean"),)), 0),
    (_sample_suite((("delete", "delete"),)), 1),
    (_sample_suite((("clean", "withheld"),)), 2),
])
def test_run_cli_returns_exact_derived_exit_code_not_delta_only(tmp_path, capsys, monkeypatch, value, expected_code):
    output = tmp_path / "out"
    output.mkdir()
    monkeypatch.setattr(regression_suite_cli, "run_regression_suite", lambda *_args: copy.deepcopy(value))
    assert regression_suite_cli.main(["run", "--manifest", "unused.json", "--output-dir", str(output)]) == expected_code
    emitted = json.loads(capsys.readouterr().out)
    assert emitted["summary"] == value["summary"]
    assert (output / "suite_report.html").is_file()


def test_error_result_run_exit_three_not_success(tmp_path, capsys, monkeypatch):
    value = _sample_suite((("clean", "clean"),))
    value["cases"][0].update(status="error", reason_code="suite_analysis_execution_error",
                              delta=incomplete_case_delta())
    value["summary"] = build_suite_summary(value)
    output = tmp_path / "out"
    output.mkdir()
    monkeypatch.setattr(regression_suite_cli, "run_regression_suite", lambda *_args: value)
    assert regression_suite_cli.main(["run", "--manifest", "unused.json", "--output-dir", str(output)]) == 3
    emitted = json.loads(capsys.readouterr().out)
    assert emitted["summary"]["current_gate_state"] == "blocked"
    assert emitted["summary"]["error_count"] == 1


def test_report_exit_zero_is_only_generation_and_retains_existing_blocked_state(tmp_path, capsys, monkeypatch):
    value = _sample_suite((("clean", "withheld"),))
    saved = _save(tmp_path, value)
    output = tmp_path / "report.html"

    def forbidden(*_args, **_kwargs):
        raise AssertionError("Report must not run detectors.")

    monkeypatch.setattr(regression_suite_cli, "run_regression_suite", forbidden)
    assert regression_suite_cli.main(["report", "--input", str(saved), "--output", str(output)]) == 0
    emitted = json.loads(capsys.readouterr().out)
    assert emitted["generation_only_not_suite_pass"] is True
    assert emitted["original_summary"]["exit_code"] == 2
    assert emitted["original_summary"]["current_gate_state"] == "blocked"
    assert emitted["complete_audio_approval"] is False
    assert output.is_file()


def test_report_output_and_input_never_overwritten(tmp_path, capsys):
    source = _save(tmp_path, _sample_suite())
    before = source.read_bytes()
    for output in (source, tmp_path / "exists.html"):
        if output != source:
            output.write_text("keep", encoding="utf-8")
        preserved = output.read_bytes()
        assert regression_suite_cli.main(["report", "--input", str(source), "--output", str(output)]) == 3
        assert json.loads(capsys.readouterr().out)["reason_code"] == "output_exists"
        assert output.read_bytes() == preserved
    assert source.read_bytes() == before


def test_run_never_replaces_existing_directory(tmp_path, capsys):
    manifest = _manifest(tmp_path)
    output = tmp_path / "existing"
    output.mkdir()
    (output / "sentinel").write_text("keep", encoding="utf-8")
    assert regression_suite_cli.main(["run", "--manifest", str(manifest), "--output-dir", str(output)]) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "suite_output_exists"
    assert (output / "sentinel").read_text(encoding="utf-8") == "keep"


@pytest.mark.parametrize("payload", [
    '{"schema_version":999}',
    '{"schema_version":1,"schema_version":1}',
    '{"schema_version":NaN}',
    '{} trailing',
])
def test_untrusted_json_rejected_without_report_or_private_traceback(tmp_path, capsys, payload):
    source = tmp_path / "untrusted.json"
    source.write_text(payload, encoding="utf-8")
    output = tmp_path / "report.html"
    assert regression_suite_cli.main(["report", "--input", str(source), "--output", str(output)]) == 3
    captured = capsys.readouterr()
    emitted = json.loads(captured.out)
    assert emitted["status"] == "error" and emitted["exit_code"] == 3
    assert "Traceback" not in captured.out and captured.err == ""
    assert not output.exists()


@pytest.mark.parametrize("exception, expected", [
    (SuiteError("invalid_suite_manifest"), "invalid_suite_manifest"),
    (SuiteError("private C:/customer/voice.wav"), "suite_contract_error"),
    (OSError("private C:/customer/voice.wav"), "suite_file_error"),
    (RuntimeError("private C:/customer/voice.wav"), "suite_file_error"),
    (AssertionError("private C:/customer/voice.wav"), "suite_internal_error"),
])
def test_safe_cli_errors_never_echo_exception_payload(tmp_path, capsys, monkeypatch, exception, expected):
    def fail(*_args):
        raise exception
    monkeypatch.setattr(regression_suite_cli, "run_regression_suite", fail)
    assert regression_suite_cli.main(["run", "--manifest", "unused.json", "--output-dir", str(tmp_path / "out")]) == 3
    captured = capsys.readouterr()
    assert json.loads(captured.out)["reason_code"] == expected
    assert "customer" not in captured.out and "voice.wav" not in captured.out
    assert captured.err == ""


def test_report_path_resolution_failure_is_safe(tmp_path, capsys, monkeypatch):
    source = _save(tmp_path, _sample_suite())

    def fail(*_args, **_kwargs):
        raise RuntimeError("private C:/customer/voice.wav")

    monkeypatch.setattr(Path, "resolve", fail)
    assert regression_suite_cli.main(["report", "--input", str(source), "--output", str(tmp_path / "report.html")]) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "suite_file_error"


def test_python_module_command_is_supported(tmp_path):
    source = _save(tmp_path, _sample_suite())
    output = tmp_path / "report.html"
    env = dict(os.environ)
    env["PYTHONPATH"] = str(Path(__file__).parents[1] / "src")
    completed = subprocess.run([sys.executable, "-m", "audio_regression.regression_suite_cli",
                               "report", "--input", str(source), "--output", str(output)],
                              env=env, capture_output=True, text=True, encoding="utf-8", timeout=30)
    assert completed.returncode == 0
    assert json.loads(completed.stdout)["generation_only_not_suite_pass"] is True
    assert completed.stderr == "" and output.is_file()
