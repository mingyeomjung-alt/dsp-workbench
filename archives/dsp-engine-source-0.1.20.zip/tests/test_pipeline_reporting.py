"""Stored-result fixtures only: no detector, locked evaluation, or raw audio."""

import copy
from html.parser import HTMLParser
import json

import pytest

from audio_regression.check_policy import check_result
from audio_regression.pipeline_reporting import (
    MAX_PIPELINE_RESULT_BYTES, PipelineReportError, load_pipeline_result,
    render_pipeline_html, validate_pipeline_result, write_pipeline_html,
)


def metadata(letter="a", duration_ms=6000.0, rate=16000):
    return {"sample_rate_hz": rate, "sample_count": round(duration_ms * rate / 1000),
            "duration_ms": duration_ms, "channels": 1, "encoding": "pcm16",
            "rms": 0.05, "peak": 0.2, "sha256": letter * 64}


def analysis(reference, processed, kind="clean"):
    events = []
    if kind == "delete":
        events = [{"type": "delete", "reference_interval_ms": [2000.0, 2400.0],
                   "processed_boundary_ms": 2000.0,
                   "evidence": {"boundary_correlation": 0.99, "offset_before_ms": 0.0,
                                "offset_after_ms": -400.0}}]
    value = {
        "schema_version": 1, "engine": "local_content_alignment_v1", "status": "analyzed",
        "content_preservation_status": "defect_candidates" if events else "no_supported_defect_candidates",
        "reason_code": None, "events": events, "complete_audio_approval": False,
        "commercial_performance_validated": False,
        "reference": copy.deepcopy(reference), "processed": copy.deepcopy(processed),
        "configuration": {"profile": "basic", "allow_gain": True,
                          "allow_resampling": False, "max_delay_ms": 1000.0},
        "analysis": {"sample_rate_hz": 8000, "hop_ms": 10.0,
                     "method": "constrained_edit_alignment_with_raw_anchors",
                     "minimum_event_duration_ms": 200, "maximum_cumulative_edit_shift_ms": 2000,
                     "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {"normalized_path_cost": 0.01, "gain_estimate": 1.0, "applied_gain": 1.0,
                        "matched_normalized_rmse": 0.001, "matched_analysis_samples": 40000,
                        "anchor_run_count": 1, "minimum_local_correlation": 0.99},
        "limitations": ["시간적 후보 검사 · 전체 음질은 평가 범위 밖"],
        "alignment_segments": [{"reference_interval_ms": [0.0, 2000.0], "processed_offset_ms": 0.0,
                                "anchor_correlations": [0.99, 0.99, 0.99]}],
    }
    if kind == "withheld":
        value.update(status="withheld", content_preservation_status="withheld", events=None,
                     reason_code="insufficient_unambiguous_anchors")
        value.pop("alignment_segments")
    return value


def concern(stage=None, category="withheld"):
    return {"scope": "stage" if stage else "end_to_end", "stage_index": stage["index"] if stage else None,
            "stage_label": stage["label"] if stage else None, "category": category}


def fixture(kind="clean"):
    source = metadata()
    first_output = metadata("b", 5600.0 if kind == "delete" else 6000.0)
    second_output = metadata("c", first_output["duration_ms"])
    stages = []
    previous = source
    for index, output in enumerate((first_output, second_output), 1):
        label = "구간 조립" if kind == "delete" and index == 1 else f"이득 단계 {index}"
        operation = ({"kind": "split_join", "label": label, "segment_ms": 400,
                      "order": [0, 1, 2, 3, 4, 6, 7, 8, 9, 10, 11, 12, 13, 14]}
                     if kind == "delete" and index == 1 else {"kind": "gain", "label": label, "gain_db": 0.0})
        result = analysis(previous, output, kind if index == 1 else "clean")
        if operation["kind"] == "split_join":
            result["configuration"]["allow_gain"] = False
        stages.append({
            "index": index, "label": label, "operation": operation,
            "input": copy.deepcopy(previous), "output": output, "status": result["status"],
            "analysis": result, "check": check_result(result),
            "input_snapshot": "input/source.wav" if index == 1 else "stages/001/output.wav",
            "output_snapshot": f"stages/{index:03d}/output.wav",
            "analysis_artifact": f"stages/{index:03d}/analysis.json",
            "check_artifact": f"stages/{index:03d}/check.json", "reason_code": result["reason_code"],
            "runtime_ms": 12.5,
        })
        previous = output
    end_analysis = analysis(source, second_output, "delete" if kind == "delete" else "clean")
    first = concern(stages[0], "defect_candidates" if kind == "delete" else "withheld") if kind != "clean" else None
    code = {"clean": 0, "delete": 1, "withheld": 2}[kind]
    return {
        "schema_version": 1, "engine": "audio_pipeline_regression_v1", "status": "completed",
        "source": source, "comparison_scope": "adjacent_stage_checks_and_end_to_end", "stages": stages,
        "end_to_end": {"status": end_analysis["status"], "analysis": end_analysis, "check": check_result(end_analysis),
                       "analysis_artifact": "end_to_end/analysis.json", "check_artifact": "end_to_end/check.json"},
        "summary": {"gate_state": {0: "clear_supported_temporal_check", 1: "review_required", 2: "blocked"}[code],
                    "exit_code": code, "first_concern": first, "planned_stage_count": 2,
                    "executed_stage_count": 2, "failed_stage": None},
        "complete_audio_approval": False, "commercial_performance_validated": False,
        "network_used": False, "fault_provenance_confirmed": False,
    }


def failed_fixture(output_exists=False):
    value = fixture()
    first, second = value["stages"]
    error = {"schema_version": 1, "status": "error", "reason_code": "invalid_samples"}
    first.update(status="error", analysis=error, check=check_result(error), reason_code=error["reason_code"],
                 analysis_artifact="stages/001/error.json", check_artifact="stages/001/error_check.json")
    if not output_exists:
        first.update(output=None, output_snapshot=None)
    latest = first["output"] if output_exists else value["source"]
    snapshot = first["output_snapshot"] if output_exists else "input/source.wav"
    second.update(status="not_run", input=copy.deepcopy(latest), input_snapshot=snapshot,
                  output=None, output_snapshot=None, analysis=None, check=None,
                  analysis_artifact=None, check_artifact=None, reason_code="prior_stage_execution_error", runtime_ms=0)
    value.update(status="incomplete", end_to_end=None)
    value["summary"].update(gate_state="blocked", exit_code=2, first_concern=concern(first, "execution_error"),
                             executed_stage_count=1, failed_stage=1)
    return value


class Tags(HTMLParser):
    def __init__(self, source):
        super().__init__()
        self.elements = []
        self.feed(source)

    def handle_starttag(self, tag, attrs):
        self.elements.append((tag, dict(attrs)))


@pytest.mark.parametrize("kind", ["clean", "delete", "withheld"])
def test_coherent_completed_results_validate(kind):
    value = fixture(kind)
    assert validate_pipeline_result(value) is value
    assert value["stages"][1]["check"]["exit_code"] == 0


@pytest.mark.parametrize("output_exists", [False, True])
def test_failed_stage_and_tail_validate(output_exists):
    value = failed_fixture(output_exists)
    assert validate_pipeline_result(value) is value
    html = render_pipeline_html(value)
    assert "실행 미완료" in html and "미실행" in html and "최종 출력 비교를 수행하지 않았습니다" in html


def test_end_to_end_error_is_incomplete_with_no_failed_stage():
    value = fixture()
    error = {"schema_version": 1, "status": "error", "reason_code": "source_changed"}
    value["end_to_end"].update(status="error", analysis=error, check=check_result(error),
                                analysis_artifact="end_to_end/error.json", check_artifact="end_to_end/error_check.json")
    value.update(status="incomplete")
    value["summary"].update(exit_code=2, gate_state="blocked", first_concern=concern(category="execution_error"))
    assert validate_pipeline_result(value) is value


@pytest.mark.parametrize("missing", [("analysis_artifact",), ("check_artifact",),
                                     ("analysis_artifact", "check_artifact")])
def test_error_artifacts_may_be_unavailable_without_clearing(missing):
    value = failed_fixture()
    for name in missing:
        value["stages"][0][name] = None
    validate_pipeline_result(value)
    assert value["summary"]["exit_code"] == 2
    assert "미생성" in render_pipeline_html(value)
    valid = fixture()
    valid["stages"][0][missing[0]] = None
    with pytest.raises(PipelineReportError):
        validate_pipeline_result(valid)


def test_final_source_change_after_stage_failure_remains_blocked():
    value = failed_fixture()
    error = {"schema_version": 1, "status": "error", "reason_code": "source_changed_during_run"}
    value["end_to_end"] = {"status": "error", "analysis": error, "check": check_result(error),
                           "analysis_artifact": None, "check_artifact": None}
    validate_pipeline_result(value)
    assert value["summary"]["first_concern"] == concern(value["stages"][0], "execution_error")
    assert "source_changed_during_run" in render_pipeline_html(value)
    error["reason_code"] = "another_execution_error"
    value["end_to_end"]["check"] = check_result(error)
    with pytest.raises(PipelineReportError) as rejected:
        validate_pipeline_result(value)
    assert rejected.value.code == "end_to_end_after_failed_stage"


def test_more_than_eight_stages_is_rejected():
    value = fixture()
    value["stages"] *= 5
    with pytest.raises(PipelineReportError) as rejected:
        validate_pipeline_result(value)
    assert rejected.value.code == "invalid_pipeline_stages"


@pytest.mark.parametrize("kind", ["delete", "withheld"])
def test_later_clear_cannot_clear_sticky_summary(kind):
    value = fixture(kind)
    value["summary"].update(exit_code=0, gate_state="clear_supported_temporal_check", first_concern=None)
    with pytest.raises(PipelineReportError, match="contract") as rejected:
        validate_pipeline_result(value)
    assert rejected.value.code == "inconsistent_pipeline_summary"


@pytest.mark.parametrize("mutate,code", [
    (lambda r: r.update(schema_version=True), "unsupported_schema_version"),
    (lambda r: r.update(schema_version=2), "unsupported_schema_version"),
    (lambda r: r.update(engine="other"), "unsupported_engine"),
    (lambda r: r.update(status=[]), "unsupported_pipeline_status"),
    (lambda r: r.update(extra="unexpected"), "invalid_pipeline_structure"),
    (lambda r: r.update(complete_audio_approval=True), "invalid_approval_claim"),
    (lambda r: r.update(network_used=0), "invalid_approval_claim"),
    (lambda r: r.update(fault_provenance_confirmed=True), "invalid_approval_claim"),
    (lambda r: r["stages"][0].update(index=2), "inconsistent_stage_index"),
    (lambda r: r["stages"][0].update(runtime_ms=float("nan")), "non_finite_metric"),
    (lambda r: r["stages"][0]["check"].update(exit_code=False), "inconsistent_saved_check"),
    (lambda r: r["stages"][0]["check"].update(reason_code="tampered"), "inconsistent_saved_check"),
    (lambda r: r["stages"][1]["input"].update(sha256="d" * 64), "broken_pipeline_chain"),
    (lambda r: r["stages"][1].update(input_snapshot="input/source.wav"), "broken_snapshot_chain"),
    (lambda r: r["stages"][0]["analysis"]["processed"].update(sha256="d" * 64), "inconsistent_analysis_metadata"),
    (lambda r: r["end_to_end"]["analysis"]["reference"].update(sha256="d" * 64), "inconsistent_analysis_metadata"),
    (lambda r: r["stages"][0]["operation"].update(extra=True), "invalid_stage_operation"),
    (lambda r: r["stages"][0]["operation"].update(gain_db=0), "unnormalized_stage_operation"),
    (lambda r: r["stages"][0]["operation"].update(label="different"), "inconsistent_stage_label"),
    (lambda r: r["stages"][0].update(label="bad\u202elabel"), "invalid_stage_label"),
    (lambda r: r["summary"].update(executed_stage_count=1), "inconsistent_pipeline_summary"),
    (lambda r: r.update(status="incomplete"), "inconsistent_pipeline_status"),
    (lambda r: r.update(end_to_end=None), "missing_end_to_end_check"),
])
def test_contradictions_are_rejected_with_stable_codes(mutate, code):
    value = fixture()
    mutate(value)
    with pytest.raises(PipelineReportError) as rejected:
        validate_pipeline_result(value)
    assert rejected.value.code == code


@pytest.mark.parametrize("path", ["../private.wav", "/tmp/private.wav", "C:/private.wav", "C:\\private.wav",
                                  "stages//001/output.wav", "stages/./001/output.wav", "stages/%2e%2e/x", "file://x"])
def test_unsafe_relative_artifact_paths_are_rejected(path):
    value = fixture()
    value["stages"][0]["analysis_artifact"] = path
    with pytest.raises(PipelineReportError) as rejected:
        validate_pipeline_result(value)
    assert rejected.value.code == "unsafe_artifact_path"


def test_earliest_concern_is_not_replaced_by_later_worse_concern():
    value = fixture("delete")
    stage = value["stages"][1]
    held = analysis(stage["input"], stage["output"], "withheld")
    stage.update(status="withheld", analysis=held, check=check_result(held), reason_code=held["reason_code"])
    value["summary"].update(gate_state="blocked", exit_code=2)
    validate_pipeline_result(value)
    value["summary"]["first_concern"] = concern(stage)
    with pytest.raises(PipelineReportError) as rejected:
        validate_pipeline_result(value)
    assert rejected.value.code == "inconsistent_pipeline_summary"


def test_operation_output_geometry_is_checked():
    value = fixture()
    value["stages"][0]["operation"] = {"kind": "resample", "target_rate_hz": 8000}
    with pytest.raises(PipelineReportError) as rejected:
        validate_pipeline_result(value)
    assert rejected.value.code == "inconsistent_operation_output"


@pytest.mark.parametrize("mutate", [
    lambda r: r.update(status="completed"),
    lambda r: r["stages"][1].update(runtime_ms=1),
    lambda r: r["stages"][1].update(reason_code="other"),
    lambda r: r["summary"].update(failed_stage=2),
    lambda r: r["stages"][0].update(reason_code="different"),
])
def test_failure_contradictions_rejected(mutate):
    value = failed_fixture()
    mutate(value)
    with pytest.raises(PipelineReportError):
        validate_pipeline_result(value)


def test_reports_are_static_escaped_and_deterministic():
    value = fixture("delete")
    payload = '<script>alert("한글 &")</script><svg onload="x">'
    value["stages"][0]["label"] = payload
    value["stages"][0]["operation"]["label"] = payload
    value["summary"]["first_concern"]["stage_label"] = payload
    html = render_pipeline_html(value)
    assert html == render_pipeline_html(value)
    assert "&lt;script&gt;" in html and "한글 &amp;" in html and payload not in html
    assert "처음 관찰된 우려 지점" in html and "처음 관찰된 지점은 원인 확정이 아닙니다" in html
    assert "별도 검사 · 원본 → 최종 출력" in html and "2,000–2,400 ms" in html
    assert "default-src 'none'" in html and 'charset="utf-8"' in html and 'lang="ko"' in html
    assert "전체 음질 승인" in html and "보정된 확률" in html and "PASS" not in html
    tags = Tags(html).elements
    assert not any(tag in {"script", "iframe", "audio", "video", "img", "link", "a"} for tag, _ in tags)
    assert not any(key.startswith("on") for _, attrs in tags for key in attrs)
    assert html.count("<!doctype html>") == 1 and html.count("<html ") == 1
    for item in value["stages"]:
        assert item["input"]["sha256"] in html and item["output"]["sha256"] in html


def test_absolute_paths_in_plain_labels_are_omitted_from_html():
    value = fixture()
    label = r"가나다 C:\private\voice.wav /home/private/speech.wav"
    value["stages"][0]["label"] = label
    value["stages"][0]["operation"]["label"] = label
    html = render_pipeline_html(value)
    assert "C:\\private" not in html and "/home/private" not in html and "[로컬 경로 생략]" in html


def test_exclusive_write_and_invalid_does_not_create(tmp_path):
    path = tmp_path / "report.html"
    write_pipeline_html(fixture(), path)
    before = path.read_bytes()
    with pytest.raises(FileExistsError):
        write_pipeline_html(fixture("delete"), path)
    assert path.read_bytes() == before
    invalid = tmp_path / "invalid.html"
    with pytest.raises(PipelineReportError):
        write_pipeline_html({}, invalid)
    assert not invalid.exists()


@pytest.mark.parametrize("contents,code", [
    (b'{"schema_version":1,"schema_version":1}', "duplicate_json_key"),
    (b'{"runtime_ms":NaN}', "non_finite_metric"),
    (b'{"runtime_ms":Infinity}', "non_finite_metric"),
    (b'\xff', "invalid_result_json"),
    (b'{', "invalid_result_json"),
    (b' ' * (MAX_PIPELINE_RESULT_BYTES + 1), "result_file_too_large"),
], ids=["duplicate-key", "nan", "infinity", "utf8", "syntax", "too-large"])
def test_strict_bounded_loader(tmp_path, contents, code):
    path = tmp_path / "saved.json"
    path.write_bytes(contents)
    with pytest.raises(PipelineReportError) as rejected:
        load_pipeline_result(path)
    assert rejected.value.code == code


def test_loader_valid_and_private_errors(tmp_path):
    path = tmp_path / "saved.json"
    value = fixture()
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    assert load_pipeline_result(path) == value
    private = tmp_path / "private-secret.json"
    with pytest.raises(PipelineReportError) as rejected:
        load_pipeline_result(private)
    assert rejected.value.code == "result_file_read_error" and str(private) not in str(rejected.value)


def test_deep_huge_and_cyclic_structures_are_rejected():
    deep = []
    cursor = deep
    for _ in range(40):
        item = []
        cursor.append(item)
        cursor = item
    for value in (deep, [None] * 100_001, ["x" * 16_385]):
        with pytest.raises(PipelineReportError) as rejected:
            validate_pipeline_result(value)
        assert rejected.value.code == "pipeline_structure_too_large"
    cyclic = []
    cyclic.append(cyclic)
    with pytest.raises(PipelineReportError):
        validate_pipeline_result(cyclic)
