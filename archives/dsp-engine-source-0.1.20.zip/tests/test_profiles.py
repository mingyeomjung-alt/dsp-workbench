import math

import numpy as np
import pytest
from scipy.signal import resample_poly

from audio_regression.audio import AudioInputError, decode_wav, encode_wav
from audio_regression.profiles import (
    ANALYSIS_RATE_HZ, AnalysisProfileError, decode_mulaw_bytes,
    encode_mulaw_pcm16, g711_mulaw_roundtrip, prepare_analysis,
    telephone_transform_samples,
)


def audio(samples, rate=8000):
    # Explicit fixture quantization; the production reader never changes PCM.
    return decode_wav(encode_wav(samples, rate))


def tone(frequency, rate=8000, seconds=3, amplitude=0.2):
    times = np.arange(rate * seconds, dtype=np.float64) / rate
    return amplitude * np.sin(2 * np.pi * frequency * times)


def scalar_mu_encode(pcm):
    # Independently expressed scalar G.711 reference: integer bit length rather
    # than the engine's vectorized segment-boundary search.
    biased = 132 - int(pcm) - 1 if pcm < 0 else 132 + int(pcm)
    segment = (biased | 255).bit_length() - 8
    uncomplemented = 127 if segment >= 8 else (
        (segment << 4) | ((biased >> (segment + 3)) & 15)
    )
    return uncomplemented ^ (127 if pcm < 0 else 255)


def scalar_mu_decode(code):
    bits = int(code) ^ 255
    linear = ((bits % 16) * 8 + 132) * 2 ** ((bits // 16) % 8)
    return 132 - linear if bits >= 128 else linear - 132


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
def test_basic_profile_matches_fixed_rational_resampling(rate):
    source = audio(tone(997, rate), rate)
    original = source.samples.copy()
    observed = prepare_analysis(source)
    divisor = math.gcd(rate, ANALYSIS_RATE_HZ)
    expected = source.samples.copy() if rate == 8000 else resample_poly(
        source.samples, 8000 // divisor, rate // divisor,
    )
    assert observed.dtype == np.float64
    assert len(observed) == 3 * 8000
    np.testing.assert_array_equal(observed, expected)
    np.testing.assert_array_equal(source.samples, original)
    assert not np.shares_memory(observed, source.samples)
    observed[0] = 0.77
    np.testing.assert_array_equal(source.samples, original)


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
def test_telephone_profile_finite_preserves_source_and_time_count(rate):
    source = audio(tone(1000, rate), rate)
    original = source.samples.copy()
    observed = prepare_analysis(source, "telephone")
    assert len(observed) == 3 * 8000
    assert np.all(np.isfinite(observed))
    assert observed.dtype == np.float64
    assert not np.shares_memory(source.samples, observed)
    np.testing.assert_array_equal(source.samples, original)
    # Fixed forward/backward filtering must not add a bulk group delay.
    assert np.corrcoef(observed[1000:-1000], tone(1000)[1000:-1000])[0, 1] > 0.999


@pytest.mark.parametrize("frequency", [100, 3900])
def test_telephone_band_suppresses_out_of_band_energy(frequency):
    values = tone(frequency)
    processed = prepare_analysis(audio(values), "telephone")[1000:-1000]
    ratio = np.sqrt(np.mean(processed**2) / np.mean(values[1000:-1000]**2))
    assert ratio < 0.01


def test_telephone_band_retains_passband_without_gain_normalization():
    # Scaling already quantized low samples preserves the exact 10:1 relation.
    low_audio = audio(tone(1000, amplitude=0.01))
    low = prepare_analysis(low_audio, "telephone")
    high = prepare_analysis(audio(10 * low_audio.samples), "telephone")
    np.testing.assert_allclose(high, 10 * low, atol=1e-12)
    assert np.sqrt(np.mean(high[1000:-1000]**2)) == pytest.approx(
        0.1 / np.sqrt(2), rel=0.01,
    )


@pytest.mark.parametrize("profile", ["", "auto", "G711", None, 42, True, []])
def test_invalid_profile_rejected(profile):
    with pytest.raises(AnalysisProfileError) as caught:
        prepare_analysis(audio(tone(1000)), profile)
    assert caught.value.code == "invalid_configuration"


def test_profile_rejects_non_audio_object():
    with pytest.raises(AudioInputError) as caught:
        prepare_analysis(np.zeros(8000))
    assert caught.value.code == "invalid_audio"


def test_mulaw_known_integer_encode_vectors_including_signed_zero_region():
    pcm = np.array([
        -32768, -32124, -1000, -132, -8, -5, -4, -1,
        0, 1, 3, 4, 8, 132, 1000, 32124, 32767,
    ], dtype=np.int16)
    expected = np.array([
        0x00, 0x00, 0x4E, 0x6F, 0x7E, 0x7E, 0x7F, 0x7F,
        0xFF, 0xFF, 0xFF, 0xFE, 0xFE, 0xEF, 0xCE, 0x80, 0x80,
    ], dtype=np.uint8)
    np.testing.assert_array_equal(encode_mulaw_pcm16(pcm), expected)


def test_mulaw_known_integer_decode_vectors():
    encoded = np.array([0x00, 0x80, 0x7F, 0xFF, 0x7E, 0xFE, 0x6F, 0xEF, 0x4E, 0xCE])
    expected = np.array([-32124, 32124, 0, 0, -8, 8, -132, 132, -988, 988], dtype=np.int16)
    np.testing.assert_array_equal(decode_mulaw_bytes(encoded), expected)


def test_mulaw_encoder_all_pcm16_values_match_scalar_reference():
    pcm = np.arange(-32768, 32768, dtype=np.int32)
    expected = np.fromiter((scalar_mu_encode(v) for v in pcm), dtype=np.uint8)
    np.testing.assert_array_equal(encode_mulaw_pcm16(pcm), expected)


def test_mulaw_decoder_all_code_values_match_scalar_reference():
    codes = np.arange(256, dtype=np.uint8)
    expected = np.fromiter((scalar_mu_decode(v) for v in codes), dtype=np.int16)
    np.testing.assert_array_equal(decode_mulaw_bytes(codes), expected)


def test_mulaw_monotonic_roundtrip_and_codec_error_bounds():
    pcm = np.arange(-32768, 32768, dtype=np.int32)
    decoded = decode_mulaw_bytes(encode_mulaw_pcm16(pcm)).astype(np.int32)
    assert np.all(np.diff(decoded) >= 0)
    assert np.max(np.abs(decoded - pcm)) <= 644


@pytest.mark.parametrize("amplitude", [0.0005, 0.005, 0.05, 0.2, 0.8])
def test_mulaw_roundtrip_has_no_unexpected_level_collapse(amplitude):
    samples = tone(997, amplitude=amplitude)
    before = samples.copy()
    result = g711_mulaw_roundtrip(samples)
    rms_ratio = np.sqrt(np.mean(result**2) / np.mean(samples**2))
    assert 0.9 < rms_ratio < 1.1
    assert np.corrcoef(samples, result)[0, 1] > 0.98
    np.testing.assert_array_equal(samples, before)
    assert not np.shares_memory(samples, result)


@pytest.mark.parametrize("samples", [
    [], [[0.1, 0.2]], [np.nan], [np.inf], [1.001], [-1.001], [1j], [True],
])
def test_mulaw_roundtrip_rejects_invalid_arrays(samples):
    with pytest.raises(AudioInputError) as caught:
        g711_mulaw_roundtrip(np.asarray(samples))
    assert caught.value.code == "invalid_samples"


@pytest.mark.parametrize("values", [[], [[0]], [32768], [-32769], [0.5], [True], [1j]])
def test_pcm_encoder_rejects_invalid_integer_arrays(values):
    with pytest.raises(AudioInputError):
        encode_mulaw_pcm16(np.asarray(values))


@pytest.mark.parametrize("values", [[], [[0]], [256], [-1], [0.5], [True], [1j]])
def test_mulaw_decoder_rejects_invalid_code_arrays(values):
    with pytest.raises(AudioInputError):
        decode_mulaw_bytes(np.asarray(values))


@pytest.mark.parametrize("operation", [encode_mulaw_pcm16, decode_mulaw_bytes])
def test_integer_codec_helpers_reject_ragged_input_consistently(operation):
    with pytest.raises(AudioInputError) as caught:
        operation([[1], [1, 2]])
    assert caught.value.code == "invalid_samples"


def test_endpoints_are_codec_saturated_not_wrapped_and_silence_stays_zero():
    result = g711_mulaw_roundtrip(np.array([-1.0, 0.0, 1.0]))
    np.testing.assert_array_equal(result, np.array([-32124, 0, 32124]) / 32768.0)
    np.testing.assert_array_equal(g711_mulaw_roundtrip(np.zeros(32)), np.zeros(32))


def test_controlled_telephone_transform_is_exact_declared_composition():
    source = audio(tone(997, rate=16000), 16000)
    before = source.samples.copy()
    expected = g711_mulaw_roundtrip(prepare_analysis(source, "telephone"))
    result = telephone_transform_samples(source)
    np.testing.assert_array_equal(result, expected)
    np.testing.assert_array_equal(source.samples, before)
    assert len(result) == 3 * 8000
    assert np.corrcoef(result[1000:-1000], tone(997)[1000:-1000])[0, 1] > 0.999
