"""Truth-free job contracts, one-use and policy tests; no audio evaluation."""

from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import pytest


TOOL = Path(__file__).resolve().parents[1] / "tools/independent_eval_execute.py"
SPEC = importlib.util.spec_from_file_location("independent_eval_execute_test_module", TOOL)
executor = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(executor)


def _write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


def _hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


@pytest.fixture
def suite(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    package = workspace / "dsp_engine/src/audio_regression"
    package.mkdir(parents=True)
    (package / "dummy.py").write_text("# frozen", encoding="utf-8")
    script = workspace / "dsp_engine/tools/independent_eval_execute.py"
    script.parent.mkdir(parents=True)
    script.write_text("# fake-only worker is never executed", encoding="utf-8")
    monkeypatch.setattr(executor, "WORKSPACE", workspace)
    monkeypatch.setattr(executor, "PACKAGE", package)
    monkeypatch.setattr(executor, "__file__", str(script))
    root = workspace / "suite"
    root.mkdir()
    manifest, jobs = [], []
    conditions = [(n, True, "supported", []) for n in ("identity", "gain", "resample", "delay", "combined")]
    for duration in (200, 400, 750):
        conditions += [(f"delete{duration}", False, "supported", [{"type": "delete", "reference_interval_ms": [1000, 1000 + duration], "processed_boundary_ms": 1240}]),
                       (f"repeat{duration}", False, "supported", [{"type": "repeat", "reference_source_interval_ms": [1000, 1000 + duration], "processed_added_interval_ms": [1240 + duration, 1240 + 2 * duration]}])]
    conditions += [(n, False, "stress", []) for n in ("silent", "dropout", "reversal")]
    for category in executor.CATEGORIES:
        for number in range(2):
            group = f"{category}{number}"
            folder = root / group
            folder.mkdir()
            reference = folder / "reference.wav"
            reference.write_bytes(b"frozen-placeholder-not-audio")
            for name, normal, scope, truth in conditions:
                processed = folder / f"{name}.wav"
                processed.write_bytes(b"frozen-placeholder-not-audio")
                config = {"profile": "basic", "allow_gain": False, "allow_resampling": False, "max_delay_ms": 1000.0}
                row = {"trial_id": hashlib.sha256(f"{group}:{name}".encode()).hexdigest()[:24],
                       "source_group": group, "category": category, "condition": name,
                       "scope": scope, "normal_trial": normal, "configuration": config,
                       "expected_events": truth, "input_duration_ms": 12000,
                       "reference_path": reference.relative_to(root).as_posix(),
                       "processed_path": processed.relative_to(root).as_posix(),
                       "reference_sha256": _hash(reference), "processed_sha256": _hash(processed)}
                manifest.append(row)
                jobs.append({"trial_id": row["trial_id"], "reference_path": str(reference),
                             "processed_path": str(processed), "configuration": config})
    _write(root / "protocol.json", {"criteria": executor.CRITERIA})
    _write(root / "manifest.json", manifest)
    _write(root / "worker_jobs.json", jobs)
    def refreeze():
        frozen = {"final_uses": 1,
                  "code_sha256": {p.relative_to(workspace).as_posix(): _hash(p) for p in (script, package / "dummy.py")},
                  "dataset_sha256": {p.relative_to(root).as_posix(): _hash(p) for p in root.rglob("*")
                                     if p.is_file() and p.name not in {"freeze.json", "run_claim.json", "run_completed.json", "report.json"} and "outputs" not in p.parts}}
        _write(root / "freeze.json", frozen)
        return frozen
    freeze = refreeze()
    return SimpleNamespace(root=root, manifest=manifest, jobs=jobs, freeze=freeze, refreeze=refreeze, script=script)


def _result(row, engine, *, held=False, extra=False):
    if row["scope"] == "stress" or held:
        return {"engine": "local_content_alignment_" + engine, "status": "withheld", "events": None}
    events = deepcopy(row["expected_events"])
    if extra:
        events.append({"type": "delete", "reference_interval_ms": [3000, 3400]})
    return {"engine": "local_content_alignment_" + engine, "status": "analyzed", "events": events}


def _outputs(suite, *, baseline_hold=True, candidate_extra=False):
    folder = suite.root / "outputs"
    folder.mkdir(exist_ok=True)
    for engine in executor.ENGINES:
        rows = [{"trial_id": row["trial_id"], "runtime_ms": 50.0, "execution_error": False,
                 "result": _result(row, engine, held=engine == "v1" and baseline_hold and index == 0,
                                   extra=engine == "v3" and candidate_extra and index == 5)}
                for index, row in enumerate(suite.manifest)]
        path = folder / f"{engine}.jsonl"
        path.write_text("\n".join(json.dumps(r) for r in rows) + "\n", encoding="utf-8")


def test_fake_only_inputs_and_truth_free_jobs_are_valid(suite):
    executor.verify_freeze(suite.root)
    protocol, manifest, jobs = executor.validate_inputs(suite.root, suite.freeze)
    assert len(manifest) == len(jobs) == 84
    assert all(set(j) == executor.JOB_KEYS for j in jobs)


@pytest.mark.parametrize("file", ["protocol.json", "manifest.json", "worker_jobs.json", "speech0/reference.wav"])
def test_data_tampering_is_detected_before_claim(suite, file):
    (suite.root / file).write_bytes(b"changed")
    with pytest.raises(ValueError, match="changed"):
        executor.run_suite(suite.root)
    assert not (suite.root / "run_claim.json").exists()


def test_code_tampering_is_detected_before_claim(suite):
    suite.script.write_text("changed", encoding="utf-8")
    with pytest.raises(ValueError, match="changed"):
        executor.run_suite(suite.root)
    assert not (suite.root / "run_claim.json").exists()


@pytest.mark.parametrize("mutation", ["truth", "escape", "criteria", "category", "count", "duplicate"])
def test_invalid_manifest_or_job_contract_is_rejected(suite, mutation):
    if mutation == "truth":
        suite.jobs[0]["expected_events"] = []
    elif mutation == "escape":
        suite.jobs[0]["reference_path"] = str(suite.root.parent / "other.wav")
    elif mutation == "criteria":
        wrong = deepcopy(executor.CRITERIA)
        wrong["event_recall_minimum"] = .5
        _write(suite.root / "protocol.json", {"criteria": wrong})
    elif mutation == "category":
        suite.manifest[0]["category"] = "environment"
    elif mutation == "count":
        suite.manifest.pop()
    else:
        suite.manifest[1]["condition"] = suite.manifest[0]["condition"]
    _write(suite.root / "manifest.json", suite.manifest)
    _write(suite.root / "worker_jobs.json", suite.jobs)
    frozen = suite.refreeze()
    with pytest.raises(ValueError):
        executor.validate_inputs(suite.root, frozen)


def test_paired_improvement_with_all_gates_passed_can_be_adopted(suite):
    _outputs(suite)
    report = executor.score_saved(suite.root, suite.manifest)
    assert report["decision"]["adopt"] is True
    assert report["decision"]["statistically_proven_improvement"] is False
    assert report["paired_source_bootstrap"]["source_group_count"] == 6
    assert all(r["source_group_count"] == 2 for r in report["paired_source_bootstrap_by_category"].values())


def test_tie_retains_default_and_false_positive_event_never_counts_correct(suite):
    _outputs(suite, baseline_hold=False, candidate_extra=True)
    report = executor.score_saved(suite.root, suite.manifest)
    assert report["decision"]["adopt"] is False
    assert report["engines"]["v3"]["supported_outcome_success_count"] == 65


def test_abstention_is_missed_event_and_failed_normal_not_false_success(suite):
    rows = [{**row, "source_kind": row["category"], "profile": "basic", "runtime_ms": 50,
             "execution_error": False, "result": _result(row, "v3", held=True)} for row in suite.manifest]
    summary = executor.summarize(rows)
    assert summary["supported"]["overall"]["normal_coverage"] == 0
    assert summary["supported"]["overall"]["false_negative_events"] == 36
    assert summary["supported_outcome_success_count"] == 0
    assert executor.decide(summary, summary)["adopt"] is False


def test_partial_or_wrong_engine_outputs_cannot_score(suite):
    _outputs(suite)
    path = suite.root / "outputs/v3.jsonl"
    first = json.loads(path.read_text(encoding="utf-8").splitlines()[0])
    first["result"]["engine"] = "local_content_alignment_v1"
    path.write_text(json.dumps(first) + "\n", encoding="utf-8")
    with pytest.raises(ValueError, match="missing"):
        executor.score_saved(suite.root, suite.manifest)


def test_worker_failure_consumes_claim_and_persists_no_adoption(suite, monkeypatch):
    monkeypatch.setattr(executor.subprocess, "run", lambda *a, **k: SimpleNamespace(returncode=9))
    report = executor.run_suite(suite.root)
    assert report["status"] == "incomplete"
    assert report["decision"]["adopt"] is False
    assert report["freeze_unchanged"] is True
    assert (suite.root / "run_claim.json").is_file()
    assert (suite.root / "run_completed.json").is_file()
    with pytest.raises(FileExistsError):
        executor.run_suite(suite.root)


def test_successful_mock_workers_do_not_allow_rerun(suite, monkeypatch):
    def fake_worker(command, **kwargs):
        assert all(kwargs["env"][k] == "1" for k in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"))
        if command[command.index("--worker-engine") + 1] == "v3":
            _outputs(suite)
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(executor.subprocess, "run", fake_worker)
    report = executor.run_suite(suite.root)
    assert report["decision"]["adopt"] is True
    original = (suite.root / "report.json").read_bytes()
    with pytest.raises(FileExistsError):
        executor.run_suite(suite.root)
    assert (suite.root / "report.json").read_bytes() == original


def test_freeze_replacement_during_worker_is_detected(suite, monkeypatch):
    def fake_worker(command, **kwargs):
        if command[command.index("--worker-engine") + 1] == "v3":
            _outputs(suite)
            freeze = json.loads((suite.root / "freeze.json").read_text(encoding="utf-8"))
            freeze["post_result_change"] = True
            _write(suite.root / "freeze.json", freeze)
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(executor.subprocess, "run", fake_worker)
    report = executor.run_suite(suite.root)
    assert report["status"] == "incomplete"
    assert report["decision"]["adopt"] is False
    assert report["freeze_unchanged"] is False
