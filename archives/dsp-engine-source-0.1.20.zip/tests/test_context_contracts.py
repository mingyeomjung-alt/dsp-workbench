"""Stored-JSON v3 contract checks, without rerunning any audio evaluation."""

from copy import deepcopy
import json
from pathlib import Path

import pytest

from audio_regression.check_policy import check_result
from audio_regression.context_result_contract import ENGINE, METHOD, validate_context_analysis_result
from audio_regression.pipeline_reporting import (
    PipelineReportError, load_pipeline_result, render_pipeline_html, validate_pipeline_result,
)
from audio_regression.reporting import render_html
from audio_regression.result_contract import (
    ResultContractError, load_analysis_result, validate_analysis_result,
)
from audio_regression.saved_pipeline_contract import (
    SavedPipelineContractError, load_saved_pipeline_result, validate_saved_pipeline_result,
)
from audio_regression.saved_pipeline_reporting import render_saved_pipeline_html


ROOT = Path(__file__).resolve().parents[1]
DEVELOPMENT = ROOT / "tests" / "fixtures" / "results"
IDENTITIES = {
    "v1": ("local_content_alignment_v1", "constrained_edit_alignment_with_raw_anchors"),
    "v2": ("local_content_alignment_v2", "constrained_edit_alignment_with_pcm16_cancellation_revalidation"),
    "v3": (ENGINE, METHOD),
}


def _pair(version="v3", kind="clean", withheld=False):
    value = load_analysis_result(DEVELOPMENT / f"synthetic_basic_{kind}.json")
    value["engine"], value["analysis"]["method"] = IDENTITIES[version]
    if withheld:
        value.update(status="withheld", content_preservation_status="withheld", events=None,
                     reason_code="insufficient_unambiguous_anchors", diagnostics={})
        value.pop("alignment_segments")
    return value


def _pipeline(saved=False, version="v3", withheld=False):
    pair = _pair(version, withheld=withheld)
    pair["configuration"]["allow_gain"] = True
    source, output = deepcopy(pair["reference"]), deepcopy(pair["processed"])
    check = check_result(pair)
    stage = {"index": 1, "label": "음량 조절", "input": source, "output": output,
             "status": pair["status"], "analysis": pair, "check": check,
             "input_snapshot": "inputs/000.wav" if saved else "input/source.wav",
             "output_snapshot": "inputs/001.wav" if saved else "stages/001/output.wav",
             "analysis_artifact": "stages/001/analysis.json", "check_artifact": "stages/001/check.json",
             "reason_code": pair["reason_code"], "runtime_ms": 1.0}
    if saved:
        stage["declaration"] = deepcopy(pair["configuration"])
    else:
        stage["operation"] = {"kind": "gain", "label": stage["label"], "gain_db": 0.0}
    prefix = "audio_saved_pipeline_audit" if saved else "audio_pipeline_regression"
    count_name = "checked_stage_count" if saved else "executed_stage_count"
    first = ({"scope": "stage", "stage_index": 1, "stage_label": stage["label"],
              "category": "withheld"} if withheld else None)
    result = {"schema_version": 1, "engine": prefix + "_" + version, "status": "completed",
              "source": deepcopy(source), "comparison_scope": "adjacent_stage_checks_and_end_to_end",
              "stages": [stage], "end_to_end": {"status": pair["status"], "analysis": deepcopy(pair),
              "check": deepcopy(check), "analysis_artifact": "end_to_end/analysis.json",
              "check_artifact": "end_to_end/check.json"},
              "summary": {"gate_state": check["gate_state"], "exit_code": check["exit_code"],
              "first_concern": first, "planned_stage_count": 1, count_name: 1, "failed_stage": None},
              "complete_audio_approval": False, "commercial_performance_validated": False,
              "network_used": False, "fault_provenance_confirmed": False}
    if saved:
        result.update(input_recheck={"status": "unchanged", "file_indices": []}, caller_order_verified=False)
    return result


def _validator(saved):
    return validate_saved_pipeline_result if saved else validate_pipeline_result


def _error(saved):
    return SavedPipelineContractError if saved else PipelineReportError


@pytest.mark.parametrize("version", ["v1", "v2", "v3"])
@pytest.mark.parametrize("kind", ["clean", "delete", "repeat"])
def test_three_identities_share_strict_geometry_and_leave_input_unchanged(version, kind):
    value = _pair(version, kind)
    before = deepcopy(value)
    assert validate_analysis_result(value) is value
    assert value == before
    assert check_result(value)["exit_code"] == (0 if kind == "clean" else 1)
    if version == "v3":
        assert validate_context_analysis_result(value) is value


def test_v3_withheld_remains_blocked():
    value = _pair(withheld=True)
    assert validate_context_analysis_result(value) is value
    assert check_result(value)["exit_code"] == 2


@pytest.mark.parametrize("engine", [None, [], "local_content_alignment_v1", "local_content_alignment_v2"])
def test_direct_v3_validator_rejects_other_identities(engine):
    value = _pair()
    value["engine"] = engine
    with pytest.raises(ResultContractError) as caught:
        validate_context_analysis_result(value)
    assert caught.value.code == "unsupported_engine"


@pytest.mark.parametrize("path,replacement,code", [
    (("schema_version",), True, "unsupported_schema_version"),
    (("analysis", "method"), IDENTITIES["v2"][1], "invalid_analysis_method"),
    (("analysis", "method"), None, "invalid_analysis_method"),
    (("analysis", "hop_ms"), 20, "invalid_analysis_method"),
    (("analysis", "minimum_event_duration_ms"), 40, "invalid_analysis_method"),
    (("configuration", "profile"), "telephone", "unsupported_profile"),
    (("configuration", "profile"), [], "unsupported_profile"),
    (("configuration", "allow_gain"), 1, "invalid_configuration"),
    (("complete_audio_approval",), True, "invalid_approval_claim"),
    (("commercial_performance_validated",), True, "invalid_approval_claim"),
    (("status",), "measured", "unsupported_result_status"),
    (("content_preservation_status",), "defect_candidates", "inconsistent_result_status"),
    (("diagnostics", "matched_normalized_rmse"), .081, "inconsistent_analyzed_metrics"),
    (("diagnostics", "minimum_local_correlation"), .89, "inconsistent_analyzed_metrics"),
    (("diagnostics", "matched_analysis_samples"), 100, "inconsistent_matched_sample_count"),
    (("diagnostics", "anchor_run_count"), 2, "inconsistent_anchor_count"),
    (("reference", "duration_ms"), 6100, "inconsistent_audio_duration"),
])
def test_v3_retains_original_raw_evidence_guards(path, replacement, code):
    value = _pair()
    node = value
    for key in path[:-1]:
        node = node[key]
    node[path[-1]] = replacement
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(value)
    assert caught.value.code == code
    assert check_result(value)["exit_code"] == 2


@pytest.mark.parametrize("field", ["trace", "trace_path", "probability", "raw_audio", "reference_path"])
def test_v3_result_cannot_embed_extra_sidecars_or_claim_fields(field):
    value = _pair()
    value[field] = "outside strict result contract"
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(value)
    assert caught.value.code == "unexpected_result_field"


def test_v3_tree_is_bounded_before_copy_and_nonfinite_metrics_rejected():
    value = _pair()
    value["cycle"] = value
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(value)
    assert caught.value.code == "result_structure_too_large"
    value = _pair()
    value["diagnostics"]["matched_normalized_rmse"] = float("nan")
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(value)
    assert caught.value.code == "non_finite_metric"


@pytest.mark.parametrize("version", [None, "v1", "v2", "v3"])
def test_minimal_error_stays_blocked_for_every_supported_identity(version):
    value = {"schema_version": 1, "status": "error", "reason_code": "analysis_execution_error"}
    if version is not None:
        value["engine"] = IDENTITIES[version][0]
    assert validate_analysis_result(value) is value
    assert check_result(value)["exit_code"] == 2


def test_v3_saved_pair_loader_does_not_downgrade_identity(tmp_path):
    path = tmp_path / "result.json"
    value = _pair()
    path.write_text(json.dumps(value), encoding="utf-8")
    assert load_analysis_result(path) == value
    value["analysis"]["method"] = IDENTITIES["v1"][1]
    path.write_text(json.dumps(value), encoding="utf-8")
    with pytest.raises(ResultContractError) as caught:
        load_analysis_result(path)
    assert caught.value.code == "invalid_analysis_method"


@pytest.mark.parametrize("saved", [False, True])
@pytest.mark.parametrize("version", ["v1", "v2", "v3"])
@pytest.mark.parametrize("withheld", [False, True])
def test_matching_pipeline_versions_preserve_sticky_state_without_mutation(saved, version, withheld):
    value = _pipeline(saved, version, withheld)
    before = deepcopy(value)
    assert _validator(saved)(value) is value
    assert value == before
    assert value["summary"]["exit_code"] == (2 if withheld else 0)


@pytest.mark.parametrize("saved", [False, True])
@pytest.mark.parametrize("versions", [("v1", "v2"), ("v1", "v3"), ("v2", "v1"),
                                      ("v2", "v3"), ("v3", "v1"), ("v3", "v2")])
@pytest.mark.parametrize("scope", ["stage", "end_to_end"])
def test_every_mixed_analyzed_pipeline_version_is_rejected(saved, versions, scope):
    top, nested = versions
    value = _pipeline(saved, top)
    item = value["stages"][0] if scope == "stage" else value["end_to_end"]
    item["analysis"]["engine"], item["analysis"]["analysis"]["method"] = IDENTITIES[nested]
    item["check"] = check_result(item["analysis"])
    with pytest.raises(_error(saved)) as caught:
        _validator(saved)(value)
    assert caught.value.code == "inconsistent_analysis_engine"


@pytest.mark.parametrize("saved", [False, True])
@pytest.mark.parametrize("scope", ["stage", "end_to_end"])
def test_v3_rejects_forged_saved_check(saved, scope):
    value = _pipeline(saved)
    item = value["stages"][0] if scope == "stage" else value["end_to_end"]
    item["check"]["complete_audio_approval"] = True
    with pytest.raises(_error(saved)) as caught:
        _validator(saved)(value)
    assert caught.value.code == "inconsistent_saved_check"


@pytest.mark.parametrize("saved", [False, True])
@pytest.mark.parametrize("identified", [False, True])
def test_v3_generic_or_matching_stage_error_is_not_clear(saved, identified):
    value = _pipeline(saved)
    stage = value["stages"][0]
    error = {"schema_version": 1, "status": "error", "reason_code": "analysis_execution_error"}
    if identified:
        error["engine"] = ENGINE
    stage.update(status="error", analysis=error, check=check_result(error),
                 reason_code=error["reason_code"], analysis_artifact="stages/001/error.json",
                 check_artifact="stages/001/error_check.json")
    value.update(status="incomplete", end_to_end=None)
    value["summary"].update(exit_code=2, gate_state="blocked", failed_stage=1,
        first_concern={"scope": "stage", "stage_index": 1, "stage_label": stage["label"],
                       "category": "execution_error"})
    assert _validator(saved)(value) is value


@pytest.mark.parametrize("saved", [False, True])
@pytest.mark.parametrize("versions", [("v1", "v2"), ("v1", "v3"), ("v2", "v1"),
                                      ("v2", "v3"), ("v3", "v1"), ("v3", "v2")])
def test_explicit_wrong_version_error_cannot_hide_mixed_pipeline(saved, versions):
    top, nested = versions
    value = _pipeline(saved, top)
    stage = value["stages"][0]
    error = {"schema_version": 1, "status": "error", "reason_code": "analysis_execution_error",
             "engine": IDENTITIES[nested][0]}
    stage.update(status="error", analysis=error, check=check_result(error),
                 reason_code=error["reason_code"], analysis_artifact="stages/001/error.json",
                 check_artifact="stages/001/error_check.json")
    value.update(status="incomplete", end_to_end=None)
    value["summary"].update(exit_code=2, gate_state="blocked", failed_stage=1,
        first_concern={"scope": "stage", "stage_index": 1, "stage_label": stage["label"],
                       "category": "execution_error"})
    with pytest.raises(_error(saved)) as caught:
        _validator(saved)(value)
    assert caught.value.code == "inconsistent_analysis_engine"


@pytest.mark.parametrize("saved", [False, True])
def test_v3_stored_loader_and_report_need_no_audio_or_trace_files(tmp_path, saved):
    value = _pipeline(saved)
    path = tmp_path / "result.json"
    path.write_text(json.dumps(value), encoding="utf-8")
    loaded = load_saved_pipeline_result(path) if saved else load_pipeline_result(path)
    assert loaded == value
    assert not (tmp_path / "trace.json").exists()
    render = render_saved_pipeline_html if saved else render_pipeline_html
    html = render(loaded)
    assert value["engine"] in html and ENGINE in html
    assert "v3 · 선택한 실험 후보" in html and "제한된 활성 문맥 연결 후보" in html
    assert "존재를 확인하지" in html and "trace.json" in html
    assert '<a ' not in html and '<script' not in html
    assert "전체 음질 승인이나 상용 성능 검증이 아닙니다" in html
    for version in ("v1", "v2"):
        previous = render(_pipeline(saved, version))
        assert "v3 ·" not in previous
        if version == "v1":
            assert "선택한 실험 후보" not in previous and "trace.json" not in previous
        else:
            assert "v2 · 선택한 실험 후보" in previous
            assert "미세 정렬 취소 재검증 후보" in previous


def test_v3_pair_report_is_truthful_version_and_not_validated_accuracy():
    html = render_html(_pair())
    assert ENGINE in html and "v3 · 선택한 개선 후보" in html
    assert "제한된 활성 문맥" in html
    assert "일반 정확도나 상용 성능을 보장하지 않습니다" in html
    assert "존재를 확인하지 않습니다" in html
    assert "v3 ·" not in render_html(_pair("v2"))
    assert "선택한 실험 후보" not in render_html(_pair("v1"))


def test_v3_schema_has_distinct_identity_and_identical_raw_geometry():
    schemas = ROOT / "src" / "audio_regression" / "schemas"
    old = json.loads((schemas / "analysis-result-v1.schema.json").read_text(encoding="utf-8"))
    v2 = json.loads((schemas / "analysis-result-v2.schema.json").read_text(encoding="utf-8"))
    v3 = json.loads((schemas / "analysis-result-v3.schema.json").read_text(encoding="utf-8"))
    assert v3["$id"] == "urn:audio-regression:analysis-result:v3"
    assert v3["$defs"]["analysis"]["properties"]["method"]["const"] == METHOD
    assert v3["$defs"]["configuration"]["properties"]["profile"] == {"type": "string", "const": "basic"}
    for name in ("metadata", "analyzedDiagnostics", "withheldDiagnostics", "deleteEvent",
                 "repeatEvent", "event", "alignmentSegment"):
        assert v3["$defs"][name] == v2["$defs"][name] == old["$defs"][name]
    for name in ("analyzed", "withheld", "cliError"):
        assert v3["$defs"][name]["properties"]["engine"]["const"] == ENGINE
        assert v2["$defs"][name]["properties"]["engine"]["const"] == IDENTITIES["v2"][0]
        assert old["$defs"][name]["properties"]["engine"]["const"] == IDENTITIES["v1"][0]
