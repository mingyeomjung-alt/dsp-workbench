"""Event-score geometry and source-level uncertainty, independent of detector."""

from copy import deepcopy
import json

import numpy as np
import pytest

from audio_regression.evaluation_metrics import (
    aggregate_trials,
    paired_group_bootstrap,
    score_trial,
)


def deletion(start=1000, end=1400, boundary=1000):
    return {"type": "delete", "reference_interval_ms": [start, end],
            "processed_boundary_ms": boundary}


def repeat(start=1400, end=1800, source_start=1000, source_end=1400):
    return {"type": "repeat", "processed_added_interval_ms": [start, end],
            "reference_source_interval_ms": [source_start, source_end]}


def result(events, status="analyzed"):
    return {"status": status, "events": events}


def row(trial_id="trial", *, group="source", truth=None, prediction=None,
        condition="clean", kind="synthetic", profile="basic", held=False):
    return {"trial_id": trial_id, "source_group": group, "source_kind": kind,
            "condition": condition, "profile": profile,
            "expected_events": [] if truth is None else truth,
            "result": result(None, "withheld") if held else result([] if prediction is None else prediction),
            "runtime_ms": 50, "input_duration_ms": 5000}


def test_exact_match_has_zero_endpoint_errors():
    scored = score_trial([deletion()], result([deletion()]))
    assert scored["true_positive_events"] == 1
    assert scored["false_positive_events"] == scored["false_negative_events"] == 0
    assert scored["matches"][0]["iou"] == 1
    assert scored["primary_boundary_errors_ms"] == [0, 0]
    assert scored["deletion_processed_boundary_errors_ms"] == [0]


def test_deletion_uses_reference_axis_not_processed_boundary():
    scored = score_trial([deletion()], result([deletion(2000, 2400, 1000)]))
    assert scored["true_positive_events"] == 0
    assert scored["false_positive_events"] == scored["false_negative_events"] == 1
    assert scored["deletion_processed_boundary_errors_ms"] == []


def test_repeat_uses_added_axis_not_reference_source():
    scored = score_trial([repeat()], result([repeat(2400, 2800)]))
    assert scored["true_positive_events"] == 0
    assert scored["false_positive_events"] == scored["false_negative_events"] == 1


def test_secondary_repeat_source_error_does_not_rescue_or_replace_primary():
    scored = score_trial([repeat()], result([repeat(1410, 1810, 900, 1300)]))
    assert scored["true_positive_events"] == 1
    assert scored["primary_boundary_errors_ms"] == [10, 10]
    assert scored["repeat_reference_source_boundary_errors_ms"] == [100, 100]


def test_different_types_never_match_even_with_equal_intervals():
    scored = score_trial([deletion()], result([repeat(1000, 1400)]))
    assert scored["true_positive_events"] == 0
    assert scored["false_positive_events"] == scored["false_negative_events"] == 1


def test_duplicate_predictions_are_false_positives():
    scored = score_trial([deletion()], result([deletion(), deletion()]))
    assert scored["true_positive_events"] == 1
    assert scored["false_positive_events"] == 1


def test_assignment_maximizes_total_iou_instead_of_greedy_best_edge():
    truth = [deletion(0, 100, 0), deletion(30, 130, 30)]
    predicted = [deletion(0, 100, 0), deletion(0, 80, 0)]
    scored = score_trial(truth, result(predicted))
    assert scored["true_positive_events"] == 2
    assert [(m["expected_index"], m["predicted_index"]) for m in scored["matches"]] == [(0, 1), (1, 0)]


@pytest.mark.parametrize(("end", "expected_tp"), [(200, 1), (201, 0)])
def test_iou_threshold_includes_exact_half(end, expected_tp):
    scored = score_trial([deletion(0, 100, 0)], result([deletion(0, end, 0)]))
    assert scored["true_positive_events"] == expected_tp


@pytest.mark.parametrize("status", ["withheld", "measured", "not_measured"])
def test_null_events_never_become_a_successful_empty_output(status):
    scored = score_trial([deletion(), repeat()], result(None, status))
    assert scored["withheld"] is True
    assert scored["false_negative_events"] == 2
    assert scored["predicted_event_count"] == 0


def test_normal_withheld_is_not_assessed_or_falsely_called_correct():
    scored = score_trial([], result(None, "withheld"))
    assert scored["normal_trial"] is True
    assert scored["normal_assessed"] is False
    assert scored["normal_false_alarm"] is None


def test_any_supported_temporal_event_is_a_normal_false_alarm():
    scored = score_trial([], result([repeat(), deletion()]))
    assert scored["normal_false_alarm"] is True
    assert scored["false_positive_events"] == 2


@pytest.mark.parametrize("interval", [None, "0,100", [0], [0, 1, 2], [True, 100],
                                    ["0", 100], [-1, 100], [1, 1], [2, 1],
                                    [0, float("nan")], [0, float("inf")]])
def test_invalid_truth_intervals_are_rejected(interval):
    event = deletion()
    event["reference_interval_ms"] = interval
    with pytest.raises(ValueError):
        score_trial([event], result([]))


def test_invalid_prediction_and_unsupported_type_are_not_silently_ignored():
    with pytest.raises(ValueError):
        score_trial([], result([{"type": "insert", "processed_added_interval_ms": [0, 100]}]))
    with pytest.raises(ValueError):
        score_trial([], result([repeat(source_end=float("nan"))]))
    with pytest.raises(ValueError):
        score_trial([], result([deletion(boundary=True)]))


def test_withheld_event_output_is_schema_error():
    with pytest.raises(ValueError):
        score_trial([], result([], "withheld"))


def test_numpy_real_boundaries_are_converted_to_json_safe_numbers():
    event = deletion(np.int64(1000), np.int64(1400), np.float32(1000))
    scored = score_trial([event], result([event]))
    json.dumps(scored, allow_nan=False)


def test_aggregate_full_denominators_and_strata():
    rows = [
        row("normal-ok"),
        row("normal-fp", prediction=[deletion()], condition="codec", profile="telephone"),
        row("normal-held", held=True, group="other", kind="public_audio"),
        row("defect-tp", truth=[deletion()], prediction=[deletion(1010, 1410, 1030)]),
        row("defect-held", truth=[repeat()], held=True, condition="codec", profile="telephone"),
    ]
    summary = aggregate_trials(rows)
    all_rows = summary["overall"]
    assert all_rows["event_precision"] == .5
    assert all_rows["event_recall"] == .5
    assert all_rows["normal_false_alarm_rate"] == pytest.approx(1 / 3)
    assert all_rows["normal_assessed_false_alarm_rate"] == .5
    assert all_rows["normal_coverage"] == pytest.approx(2 / 3)
    assert all_rows["withheld_rate"] == .4
    assert all_rows["coverage"] == .6
    assert all_rows["median_primary_boundary_error_ms"] == 10
    assert all_rows["median_deletion_processed_boundary_error_ms"] == 30
    assert all_rows["median_rtf"] == .01
    assert all_rows["source_group_count"] == 2
    assert summary["by_condition"]["codec"]["false_negative_events"] == 1
    assert summary["by_source_kind"]["public_audio"]["normal_coverage"] == 0
    assert summary["by_profile"]["telephone"]["normal_false_alarm_count"] == 1
    json.dumps(summary, allow_nan=False)


def test_zero_denominators_are_null_not_nan():
    summary = aggregate_trials([])["overall"]
    for key in ("event_precision", "event_recall", "normal_false_alarm_rate", "coverage",
                "normal_coverage", "median_primary_boundary_error_ms", "median_rtf"):
        assert summary[key] is None
    json.dumps(summary, allow_nan=False)


@pytest.mark.parametrize(("key", "value"), [("trial_id", ""), ("source_group", 1),
                                            ("runtime_ms", -1), ("runtime_ms", True),
                                            ("runtime_ms", float("nan")), ("input_duration_ms", 0)])
def test_invalid_aggregate_metadata_is_rejected(key, value):
    trial = row()
    trial[key] = value
    with pytest.raises(ValueError):
        aggregate_trials([trial])


def test_duplicate_trial_id_rejected():
    with pytest.raises(ValueError):
        aggregate_trials([row(), row()])


def test_overflowing_real_time_factor_is_rejected():
    trial = row()
    trial.update(runtime_ms=1e308, input_duration_ms=1e-308)
    with pytest.raises(ValueError):
        aggregate_trials([trial])


def _bootstrap_rows(copies=1):
    candidates, baselines = [], []
    for group in ("a", "b"):
        for copy in range(copies):
            candidates.append(row(f"{group}-{copy}", group=group, truth=[deletion()],
                                  prediction=[deletion()] if group == "a" else []))
            baselines.append(row(f"{group}-{copy}", group=group, truth=[deletion()]))
    return candidates, baselines


def test_source_bootstrap_keeps_transformed_trials_dependent():
    short = paired_group_bootstrap(*_bootstrap_rows(1), resamples=200)
    repeated = paired_group_bootstrap(*_bootstrap_rows(80), resamples=200)
    assert short["metrics"] == repeated["metrics"]
    recall = repeated["metrics"]["event_recall"]
    assert recall["difference"] == .5
    assert recall["ci95"] == [0, 1]
    assert repeated["source_group_count"] == 2
    assert repeated["unit"] == "original_source_group"
    assert repeated["descriptive_only"] is True
    assert recall["valid_resamples"] == 200
    assert repeated["metrics"]["normal_false_alarm_rate"]["valid_resamples"] == 0
    assert repeated["metrics"]["normal_false_alarm_rate"]["ci95"] is None
    json.dumps(repeated, allow_nan=False)


def test_bootstrap_is_deterministic_and_order_independent():
    candidates, baselines = _bootstrap_rows(3)
    assert paired_group_bootstrap(candidates, baselines, resamples=200) == paired_group_bootstrap(
        candidates[::-1], baselines[::-1], resamples=200)


@pytest.mark.parametrize("key", ["trial_id", "source_group", "condition", "profile", "source_kind"])
def test_bootstrap_rejects_unpaired_trials(key):
    candidates, baselines = _bootstrap_rows()
    baselines[0][key] = "changed"
    with pytest.raises(ValueError):
        paired_group_bootstrap(candidates, baselines)


def test_bootstrap_rejects_mismatched_ground_truth():
    candidates, baselines = _bootstrap_rows()
    baselines[0]["expected_events"] = [deletion(1100, 1500)]
    with pytest.raises(ValueError):
        paired_group_bootstrap(candidates, baselines)


@pytest.mark.parametrize("comparison_output", [
    {"status": "measured", "events": None,
     "content_preservation_status": "not_assessed_by_comparison_baseline",
     "anomaly_candidate": True, "measurement_available": True},
    {"status": "measured", "events": None,
     "content_preservation_status": "not_assessed_by_global_baseline"},
    {"status": "measured", "events": None, "anomaly_candidate": True},
])
def test_event_bootstrap_rejects_nonlocalizing_baseline(comparison_output):
    candidates, baselines = _bootstrap_rows()
    baselines[0]["result"] = comparison_output
    with pytest.raises(ValueError, match="localization-capable"):
        paired_group_bootstrap(candidates, baselines)


def test_bootstrap_reports_undefined_replicates_instead_of_zero_metrics():
    candidate = [row("normal", group="a"), row("defect", group="b", truth=[deletion()], prediction=[deletion()])]
    baseline = deepcopy(candidate)
    boot = paired_group_bootstrap(candidate, baseline, resamples=200)
    for metric in boot["metrics"].values():
        assert metric["difference"] == 0
        assert metric["ci95"] == [0, 0]
        assert 0 < metric["undefined_resamples"] < 200


def test_empty_bootstrap_is_json_safe_and_explicit():
    boot = paired_group_bootstrap([], [], resamples=20)
    assert boot["source_group_count"] == 0
    assert all(item["difference"] is None and item["undefined_resamples"] == 20
               for item in boot["metrics"].values())
    json.dumps(boot, allow_nan=False)


@pytest.mark.parametrize(("key", "value"), [("resamples", 0), ("resamples", True),
                                            ("resamples", 2.0), ("seed", True), ("seed", -1)])
def test_bootstrap_invalid_settings_rejected(key, value):
    with pytest.raises(ValueError):
        paired_group_bootstrap([], [], **{key: value})
