"""Exact event-observation deltas; no audio accuracy claims."""

from copy import deepcopy

import pytest

from audio_regression.regression_suite_diff import compare_case_results
from audio_regression.resampler_result_contract import MODEL
from test_reporting import sample_result
from test_edge_event_contract import _native, _inherited
from test_resampler_contract import _normal, _short


def configuration(engine="v1"):
    return {"engine": engine, "allow_gain": False, "allow_resampling": engine == "v12",
            "max_delay_ms": 1000, "resampling_model": MODEL if engine == "v12" else None}


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_new_persistent_and_no_longer_observed_are_distinct(kind):
    clean, defect = sample_result(), sample_result(kind)
    assert compare_case_results(clean, defect, configuration(), "a" * 64)["new_candidates"] == [0]
    persistent = compare_case_results(defect, defect, configuration(), "a" * 64)
    assert persistent["persistent_pairs"] == [{"baseline_event_index": 0, "candidate_event_index": 0}]
    assert not persistent["new_candidates"] and not persistent["not_observed_now"]
    gone = compare_case_results(defect, clean, configuration(), "a" * 64)
    assert gone["not_observed_now"] == [0]
    assert gone["coordinate_axis"] == "raw_reference_time_ms"


def test_hold_in_either_direction_never_invents_resolution():
    clean, held = sample_result(), sample_result()
    held.update(status="withheld", events=None, content_preservation_status="withheld",
                reason_code="insufficient_unambiguous_anchors")
    held.pop("alignment_segments")
    for first, second in ((clean, held), (held, clean)):
        delta = compare_case_results(first, second, configuration(), "a" * 64)
        assert delta == {"status": "inconclusive", "reason_code": "analysis_not_comparable",
                         "coordinate_axis": None, "new_candidates": [], "persistent_pairs": [], "not_observed_now": []}


@pytest.mark.parametrize("change", [
    lambda v: v.update(complete_audio_approval=True),
    lambda v: v["reference"].update(sha256="b" * 64),
    lambda v: v["configuration"].update(max_delay_ms=3),
    lambda v: v["configuration"].update(profile="telephone"),
    lambda v: v.update(events=[]),
])
def test_invalid_or_unbound_analysis_is_inconclusive(change):
    before, after = sample_result(), sample_result("delete")
    change(after)
    delta = compare_case_results(before, after, configuration(), "a" * 64)
    assert delta["status"] == "inconclusive"
    assert not delta["new_candidates"] and not delta["not_observed_now"]


def _move(value, position):
    value = deepcopy(value)
    event = value["events"][0]
    if event["type"] == "delete":
        event.update(reference_interval_ms=[position, position + 400], processed_boundary_ms=position)
    else:
        event.update(reference_source_interval_ms=[position, position + 400],
                     processed_added_interval_ms=[position + 400, position + 800])
    return value


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_overlapping_nonidentical_geometry_is_not_fuzzy_matched_or_declared_new(kind):
    before = sample_result(kind)
    after = _move(before, 2000.5)
    delta = compare_case_results(before, after, configuration(), "a" * 64)
    assert delta["reason_code"] == "ambiguous_event_geometry_change"
    assert delta["status"] == "inconclusive"
    assert not any(delta[key] for key in ("new_candidates", "persistent_pairs", "not_observed_now"))


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_disjoint_reference_witnesses_remain_distinct_observations(kind):
    before, after = sample_result(kind), _move(sample_result(kind), 4000)
    delta = compare_case_results(before, after, configuration(), "a" * 64)
    assert delta["status"] == "compared"
    assert delta["new_candidates"] == [0] and delta["not_observed_now"] == [0]
    assert delta["persistent_pairs"] == []


def test_endpoint_location_is_part_of_exact_identity():
    head, tail = _native("head"), _native("tail")
    delta = compare_case_results(head, tail, configuration("v11"), "a" * 64)
    assert delta["status"] == "compared"
    assert delta["new_candidates"] == [0] and delta["not_observed_now"] == [0]
    assert not delta["persistent_pairs"]


def test_effective_scope_difference_needs_exact_byte_identity_absence_witness():
    clean, short = _inherited(False), _inherited(True)
    delta = compare_case_results(clean, short, configuration("v11"), "a" * 64)
    assert delta["status"] == "compared" and delta["new_candidates"] == [0]
    clean["processed"]["sha256"] = "b" * 64
    delta = compare_case_results(clean, short, configuration("v11"), "a" * 64)
    assert delta["reason_code"] == "effective_analysis_scope_mismatch"


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_v12_keeps_canonical_axis_separate_from_raw_48k(kind):
    before, after = _normal(), _short(kind)
    delta = compare_case_results(before, after, configuration("v12"), "a" * 64)
    assert delta["status"] == "compared"
    assert delta["coordinate_axis"] == "canonical_reference_time_ms" and delta["new_candidates"] == [0]
    after["resampling_reference"]["sha256"] = "d" * 64
    delta = compare_case_results(before, after, configuration("v12"), "a" * 64)
    assert delta["reason_code"] == "canonical_reference_mismatch"


def test_bounded_validator_is_read_only_and_minimal_error_is_inconclusive():
    before, after = sample_result(), sample_result("repeat")
    original = deepcopy((before, after))
    compare_case_results(before, after, configuration(), "a" * 64)
    assert (before, after) == original
    error = {"schema_version": 1, "status": "error", "reason_code": "invalid_wav"}
    assert compare_case_results(error, after, configuration(), "a" * 64)["status"] == "inconclusive"


def test_valid_repeat_raw_anchor_tolerance_is_not_silently_promoted_to_exact_source_boundary():
    before, after = sample_result(), sample_result("repeat")
    after["events"][0]["evidence"]["offset_before_ms"] = .5
    after["events"][0]["evidence"]["offset_after_ms"] = 400.5
    delta = compare_case_results(before, after, configuration(), "a" * 64)
    assert delta["reason_code"] == "event_reference_geometry_unresolved"


def test_duplicate_exact_keys_fail_closed_even_if_a_future_child_contract_allows_them(monkeypatch):
    import audio_regression.regression_suite_diff as module
    value = sample_result("delete")
    value["events"].append(deepcopy(value["events"][0]))
    monkeypatch.setattr(module, "validate_analysis_result", lambda result: result)
    monkeypatch.setattr(module, "check_result", lambda _result: {"exit_code": 1})
    assert compare_case_results(value, value, configuration(), "a" * 64)["reason_code"] == "ambiguous_exact_event_matching"
