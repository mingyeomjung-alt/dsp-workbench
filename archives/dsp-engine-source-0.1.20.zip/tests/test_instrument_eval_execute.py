"""Fake-only evaluation contracts; these tests never analyze a natural recording."""

from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import pytest


TOOL = Path(__file__).resolve().parents[1] / "tools/instrument_eval_execute.py"
SPEC = importlib.util.spec_from_file_location("instrument_eval_execute_test_module", TOOL)
executor = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(executor)


def _write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


def _hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


@pytest.fixture
def suite(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    package = workspace / "dsp_engine/src/audio_regression"
    package.mkdir(parents=True)
    (package / "dummy.py").write_text("# frozen", encoding="utf-8")
    schema = package / "schemas/dummy.json"
    _write(schema, {"type": "object"})
    script = workspace / "dsp_engine/tools/instrument_eval_execute.py"
    script.parent.mkdir(parents=True)
    script.write_text("# fake-only worker is never executed", encoding="utf-8")
    monkeypatch.setattr(executor, "WORKSPACE", workspace)
    monkeypatch.setattr(executor, "PACKAGE", package)
    monkeypatch.setattr(executor, "__file__", str(script))
    root = workspace / "suite"
    root.mkdir()
    manifest, jobs, sources = [], [], []
    conditions = [(n, True, "supported", []) for n in sorted(executor.NORMAL_CONDITIONS)]
    for duration in (200, 400, 750):
        conditions += [(f"delete_{duration}", False, "supported", [{"type": "delete", "reference_interval_ms": [1000, 1000 + duration], "processed_boundary_ms": 1240}]),
                       (f"repeat_{duration}", False, "supported", [{"type": "repeat", "reference_source_interval_ms": [1000, 1000 + duration], "processed_added_interval_ms": [1240 + duration, 1240 + 2 * duration]}])]
    conditions += [(n, False, "stress", []) for n in sorted(executor.STRESS_CONDITIONS)]
    for category in executor.CATEGORIES:
        for number in range(2):
            group = f"{category}{number}"
            sources.append({"source_group": group, "category": category})
            folder = root / group
            folder.mkdir()
            reference = folder / "reference.wav"
            reference.write_bytes(b"frozen-placeholder-not-audio")
            for name, normal, scope, truth in conditions:
                processed = folder / f"{name}.wav"
                processed.write_bytes(b"frozen-placeholder-not-audio")
                config = {"profile": "basic", "allow_gain": False, "allow_resampling": False, "max_delay_ms": 1000.0}
                row = {"trial_id": hashlib.sha256(f"{group}:{name}".encode()).hexdigest()[:24],
                       "source_group": group, "category": category, "condition": name,
                       "scope": scope, "normal_trial": normal, "configuration": config,
                       "expected_events": truth, "input_duration_ms": 12000,
                       "reference_path": reference.relative_to(root).as_posix(),
                       "processed_path": processed.relative_to(root).as_posix(),
                       "reference_sha256": _hash(reference), "processed_sha256": _hash(processed)}
                manifest.append(row)
                jobs.append({"trial_id": row["trial_id"], "reference_path": str(reference),
                             "processed_path": str(processed), "configuration": config})
    protocol = {"criteria": executor.CRITERIA, "methods": list(executor.ENGINES), "categories": list(executor.CATEGORIES),
                "source_count": 4, "pair_count": 56, "source_count_by_category": {c: 2 for c in executor.CATEGORIES},
                "profile": "basic", "bootstrap_resamples": 2000, "bootstrap_seed": 20261013,
                "final_uses": 1, "retune_after_results": False, "sources": sources}
    _write(root / "protocol.json", protocol)
    _write(root / "manifest.json", manifest)
    _write(root / "worker_jobs.json", jobs)
    def refreeze():
        frozen = {"final_uses": 1,
                  "code_sha256": {p.relative_to(workspace).as_posix(): _hash(p) for p in (script, package / "dummy.py", schema)},
                  "dataset_sha256": {p.relative_to(root).as_posix(): _hash(p) for p in root.rglob("*")
                                     if p.is_file() and p.name not in {"freeze.json", "run_claim.json", "run_completed.json", "report.json"} and "outputs" not in p.parts}}
        _write(root / "freeze.json", frozen)
        return frozen
    return SimpleNamespace(root=root, manifest=manifest, jobs=jobs, freeze=refreeze(), refreeze=refreeze, script=script, protocol=protocol)


def _result(row, engine, *, held=False, extra=False):
    if row["scope"] == "stress" or held:
        return {"engine": "local_content_alignment_" + engine, "status": "withheld", "events": None}
    events = deepcopy(row["expected_events"])
    if extra:
        events.append({"type": "delete", "reference_interval_ms": [3000, 3400]})
    return {"engine": "local_content_alignment_" + engine, "status": "analyzed", "events": events}


def _outputs(suite, *, baseline_hold=True, candidate_extra=False, secondary_hold=False):
    folder = suite.root / "outputs"
    folder.mkdir(exist_ok=True)
    for engine in executor.ENGINES:
        rows = [{"trial_id": row["trial_id"], "runtime_ms": 50.0, "execution_error": False,
                 "result": _result(row, engine,
                                   held=index == 0 and ((engine == "v1" and baseline_hold) or (engine == "v3" and secondary_hold)),
                                   extra=engine == "v4" and candidate_extra and index == 5)}
                for index, row in enumerate(suite.manifest)]
        path = folder / f"{engine}.jsonl"
        path.write_text("\n".join(json.dumps(r) for r in rows) + "\n", encoding="utf-8")


def test_fake_only_inputs_and_truth_free_jobs_are_valid(suite):
    executor.verify_freeze(suite.root)
    protocol, manifest, jobs = executor.validate_inputs(suite.root, suite.freeze)
    assert len(manifest) == len(jobs) == 56
    assert protocol["methods"] == ["v1", "v3", "v4"]
    assert all(set(j) == executor.JOB_KEYS for j in jobs)


@pytest.mark.parametrize("file", ["protocol.json", "manifest.json", "worker_jobs.json", "music0/reference.wav"])
def test_data_tampering_is_detected_before_claim(suite, file):
    (suite.root / file).write_bytes(b"changed")
    with pytest.raises(ValueError, match="changed"):
        executor.run_suite(suite.root)
    assert not (suite.root / "run_claim.json").exists()


def test_code_tampering_is_detected_before_claim(suite):
    suite.script.write_text("changed", encoding="utf-8")
    with pytest.raises(ValueError, match="changed"):
        executor.run_suite(suite.root)
    assert not (suite.root / "run_claim.json").exists()


def test_schema_omission_is_detected_before_claim(suite):
    frozen = deepcopy(suite.freeze)
    frozen["code_sha256"].pop("dsp_engine/src/audio_regression/schemas/dummy.json")
    _write(suite.root / "freeze.json", frozen)
    with pytest.raises(ValueError, match="schemas"):
        executor.run_suite(suite.root)
    assert not (suite.root / "run_claim.json").exists()


@pytest.mark.parametrize("mutation", ["truth", "escape", "criteria", "category", "count", "duplicate", "condition", "hash", "kind"])
def test_invalid_manifest_or_job_contract_is_rejected(suite, mutation):
    if mutation == "truth":
        suite.jobs[0]["expected_events"] = []
    elif mutation == "escape":
        suite.jobs[0]["reference_path"] = str(suite.root.parent / "other.wav")
    elif mutation == "criteria":
        wrong = deepcopy(executor.CRITERIA)
        wrong["event_recall_minimum"] = .5
        suite.protocol["criteria"] = wrong
    elif mutation == "category":
        suite.manifest[0]["category"] = "environment"
    elif mutation == "count":
        suite.manifest.pop()
    elif mutation == "condition":
        suite.manifest[0]["condition"] = "unregistered"
    elif mutation == "hash":
        suite.manifest[0]["reference_sha256"] = "0" * 64
    elif mutation == "kind":
        suite.manifest[5]["condition"] = "repeat_200"
    else:
        suite.manifest[1]["condition"] = suite.manifest[0]["condition"]
    _write(suite.root / "protocol.json", suite.protocol)
    _write(suite.root / "manifest.json", suite.manifest)
    _write(suite.root / "worker_jobs.json", suite.jobs)
    with pytest.raises(ValueError):
        executor.validate_inputs(suite.root, suite.refreeze())


@pytest.mark.parametrize("key,value", [("methods", ["v4", "v3", "v1"]), ("categories", ["music", "speech"]),
                                      ("source_count", True), ("pair_count", 84), ("bootstrap_seed", 3),
                                      ("bootstrap_resamples", 10), ("retune_after_results", True), ("final_uses", 2)])
def test_scope_and_policy_cannot_change(suite, key, value):
    suite.protocol[key] = value
    _write(suite.root / "protocol.json", suite.protocol)
    with pytest.raises(ValueError, match="scope"):
        executor.validate_inputs(suite.root, suite.refreeze())


def test_source_declaration_cannot_disagree_with_manifest(suite):
    suite.protocol["sources"][0]["source_group"] = "another"
    _write(suite.root / "protocol.json", suite.protocol)
    with pytest.raises(ValueError, match="declared"):
        executor.validate_inputs(suite.root, suite.refreeze())


def test_paired_improvement_with_all_gates_passed_can_be_scoped_adopted(suite):
    _outputs(suite, secondary_hold=True)
    report = executor.score_saved(suite.root, suite.manifest)
    assert report["decision"]["adopt"] is True
    assert report["decision"]["decision"] == "adopt_v4_candidate_for_scoped_offline_use_only"
    assert report["decision"]["statistically_proven_improvement"] is False
    assert report["paired_source_bootstrap"]["source_group_count"] == 4
    assert all(r["source_group_count"] == 2 for r in report["paired_source_bootstrap_by_category"].values())
    secondary = report["secondary_comparison_v4_vs_v3"]
    assert secondary["supported_outcome_success_difference"] == 1
    assert len(secondary["improved_trial_ids"]) == 1
    assert secondary["regressed_trial_ids"] == []


def test_tie_retains_default_and_false_positive_event_never_counts_correct(suite):
    _outputs(suite, baseline_hold=False, candidate_extra=True)
    report = executor.score_saved(suite.root, suite.manifest)
    assert report["decision"]["adopt"] is False
    assert report["engines"]["v4"]["supported_outcome_success_count"] == 43
    assert report["secondary_comparison_v4_vs_v3"]["regressed_trial_ids"]


def test_secondary_regression_blocks_adoption_even_when_primary_improves(suite):
    _outputs(suite)
    path = suite.root / "outputs/v4.jsonl"
    lines = path.read_text(encoding="utf-8").splitlines()
    item = json.loads(lines[1])
    item["result"] = _result(suite.manifest[1], "v4", held=True)
    lines[1] = json.dumps(item)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    report = executor.score_saved(suite.root, suite.manifest)
    assert report["decision"]["adopt"] is False
    assert any(not c["passed"] for c in report["decision"]["criteria_checks"] if "vs_v3" in c["criterion"])


def test_abstention_is_missed_event_and_failed_normal_not_false_success(suite):
    rows = [{**row, "source_kind": row["category"], "profile": "basic", "runtime_ms": 50,
             "execution_error": False, "result": _result(row, "v4", held=True)} for row in suite.manifest]
    summary = executor.summarize(rows)
    assert summary["supported"]["overall"]["normal_coverage"] == 0
    assert summary["supported"]["overall"]["false_negative_events"] == 24
    assert summary["supported_outcome_success_count"] == 0
    assert executor.decide(summary, summary, summary)["adopt"] is False


@pytest.mark.parametrize("mutation", ["partial", "wrong_engine", "duplicate_key", "nonfinite", "bad_runtime", "error_clear"])
def test_invalid_outputs_cannot_score(suite, mutation):
    _outputs(suite)
    path = suite.root / "outputs/v4.jsonl"
    lines = path.read_text(encoding="utf-8").splitlines()
    first = json.loads(lines[0])
    if mutation == "partial":
        lines.pop()
    elif mutation == "wrong_engine":
        first["result"]["engine"] = "local_content_alignment_v1"
        lines[0] = json.dumps(first)
    elif mutation == "duplicate_key":
        lines[0] = lines[0][:-1] + ', "runtime_ms": 10}'
    elif mutation == "nonfinite":
        first["runtime_ms"] = float("nan")
        lines[0] = json.dumps(first)
    elif mutation == "bad_runtime":
        first["runtime_ms"] = True
        lines[0] = json.dumps(first)
    elif mutation == "error_clear":
        first["execution_error"] = True
        lines[0] = json.dumps(first)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    with pytest.raises(ValueError):
        executor.score_saved(suite.root, suite.manifest)


def test_worker_failure_consumes_claim_and_persists_no_adoption(suite, monkeypatch):
    monkeypatch.setattr(executor.subprocess, "run", lambda *a, **k: SimpleNamespace(returncode=9))
    report = executor.run_suite(suite.root)
    assert report["status"] == "incomplete"
    assert report["decision"]["adopt"] is False
    assert report["freeze_unchanged"] is True
    assert (suite.root / "run_claim.json").is_file()
    assert (suite.root / "run_completed.json").is_file()
    with pytest.raises(FileExistsError):
        executor.run_suite(suite.root)


def test_successful_mock_workers_save_all_raw_before_scoring_and_disallow_rerun(suite, monkeypatch):
    order = []
    original_score = executor.score_saved
    def fake_worker(command, **kwargs):
        engine = command[command.index("--worker-engine") + 1]
        order.append(engine)
        assert all(kwargs["env"][k] == "1" for k in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"))
        if engine == "v4":
            _outputs(suite)
        return SimpleNamespace(returncode=0)
    def score(root, manifest):
        assert order == ["v1", "v3", "v4"]
        assert all((root / "outputs" / f"{engine}.jsonl").is_file() for engine in executor.ENGINES)
        return original_score(root, manifest)
    monkeypatch.setattr(executor.subprocess, "run", fake_worker)
    monkeypatch.setattr(executor, "score_saved", score)
    report = executor.run_suite(suite.root)
    assert report["decision"]["adopt"] is True
    original = (suite.root / "report.json").read_bytes()
    with pytest.raises(FileExistsError):
        executor.run_suite(suite.root)
    assert (suite.root / "report.json").read_bytes() == original


def test_freeze_replacement_during_worker_is_detected(suite, monkeypatch):
    def fake_worker(command, **kwargs):
        if command[command.index("--worker-engine") + 1] == "v4":
            _outputs(suite)
            freeze = json.loads((suite.root / "freeze.json").read_text(encoding="utf-8"))
            freeze["post_result_change"] = True
            _write(suite.root / "freeze.json", freeze)
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(executor.subprocess, "run", fake_worker)
    report = executor.run_suite(suite.root)
    assert report["status"] == "incomplete"
    assert report["decision"]["adopt"] is False
    assert report["freeze_unchanged"] is False


def test_fake_worker_records_stable_code_and_not_private_exception_message(suite, monkeypatch):
    from audio_regression import api
    from audio_regression.audio import AudioInputError
    calls = []
    def no_audio(reference, processed, *, engine, **config):
        calls.append(engine)
        raise AudioInputError("unsupported_sample_rate", "private C:/recordings/user.wav")
    monkeypatch.setattr(api, "analyze_pair", no_audio)
    output = suite.root / "fake-worker.jsonl"
    metadata = executor.worker_run(suite.root / "worker_jobs.json", output, "v4")
    assert calls == ["v4"] * 56
    assert metadata["execution_error_count"] == 56
    raw = output.read_text(encoding="utf-8")
    assert "private C:" not in raw
    result = json.loads(raw.splitlines()[0])["result"]
    assert result["exception_type"] == "AudioInputError"
    assert result["exception_reason_code"] == "unsupported_sample_rate"
    assert result["status"] == "withheld" and result["events"] is None


@pytest.mark.parametrize("reason", [None, "C:/private/file.wav", "BOOM", "a" * 129, 5])
def test_arbitrary_exception_details_are_not_machine_codes(reason):
    error = ValueError("private")
    error.code = reason
    assert executor._exception(error) == {"exception_type": "ValueError", "exception_reason_code": None}
