import hashlib
import json

import numpy as np
import pytest

from audio_regression import evaluation_runner as runner
from audio_regression.audio import encode_wav


def _write_json(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


def _prepared(tmp_path, monkeypatch):
    workspace = tmp_path / "workspace"
    package = workspace / "dsp_engine/src/audio_regression"
    package.mkdir(parents=True)
    (package / "engine.py").write_text("# test placeholder, never executed\n", encoding="utf-8")
    data = workspace / ".third_party/mini_librispeech_holdout_20261006/dataset"
    data.mkdir(parents=True)
    values = np.random.default_rng(391).normal(0, .04, 80000)
    payload = encode_wav(values, 16000)
    (data / "example.wav").write_bytes(payload)
    _write_json(data / "provenance.json", {"recordings": {"test": {"enroll": [{
        "file": "example.wav", "duration_ms": 5000, "sha256": hashlib.sha256(payload).hexdigest(),
        "source_member": "synthetic_geometry_fixture_not_public_audio"}]}}})
    _write_json(workspace / "validation/dsp_m2_execution_20261012.json", {
        "examples": {"public_source_sha256": "a" * 64}})
    monkeypatch.setattr(runner, "WORKSPACE", workspace)
    monkeypatch.setattr(runner, "PACKAGE", package)
    monkeypatch.setattr(runner, "PUBLIC_SPEAKERS", ("test",))
    monkeypatch.setattr(runner, "CONFIRMATION_SEEDS", (391391,))
    suite = tmp_path / "suite"
    result = runner.prepare_suite(suite)
    return suite, workspace, result


def test_prepare_freezes_code_data_and_keeps_truth_out_of_jobs(tmp_path, monkeypatch):
    suite, _, result = _prepared(tmp_path, monkeypatch)
    assert result["supported_trials"] == 32
    assert result["source_groups"] == 2
    freeze = runner.verify_freeze(suite)
    assert freeze["status"] == "locked_before_any_final_output"
    jobs = json.loads((suite / "worker_jobs.json").read_text(encoding="utf-8"))
    assert all(set(job) == {"trial_id", "reference_path", "processed_path", "configuration"} for job in jobs)
    assert not (suite / "run_claim.json").exists()
    assert not (suite / "report.json").exists()


def test_dataset_mutation_fails_before_claim(tmp_path, monkeypatch):
    suite, _, _ = _prepared(tmp_path, monkeypatch)
    (suite / "manifest.json").write_text("[]", encoding="utf-8")
    with pytest.raises(ValueError, match="dataset changed"):
        runner.run_suite(suite)
    assert not (suite / "run_claim.json").exists()


def test_engine_mutation_fails_before_claim(tmp_path, monkeypatch):
    suite, workspace, _ = _prepared(tmp_path, monkeypatch)
    (workspace / "dsp_engine/src/audio_regression/engine.py").write_text("changed", encoding="utf-8")
    with pytest.raises(ValueError, match="code changed"):
        runner.run_suite(suite)
    assert not (suite / "run_claim.json").exists()


def test_existing_claim_prevents_any_replay(tmp_path, monkeypatch):
    suite, _, _ = _prepared(tmp_path, monkeypatch)
    claim = suite / "run_claim.json"
    claim.write_text('{"uses":1}', encoding="utf-8")
    before = claim.read_bytes()
    def no_subprocess(*args, **kwargs):
        pytest.fail("A consumed suite must not execute.")
    monkeypatch.setattr(runner.subprocess, "run", no_subprocess)
    with pytest.raises(FileExistsError):
        runner.run_suite(suite)
    assert claim.read_bytes() == before


def test_paths_cannot_escape_suite(tmp_path):
    with pytest.raises(ValueError):
        runner._inside(tmp_path, "../outside.wav")


def test_common_anomaly_task_does_not_fabricate_baseline_events():
    row = {"trial_id": "one", "source_group": "original", "source_kind": "synthetic_confirmation",
           "condition": "delete_400ms", "profile": "basic", "expected_events": [{"type": "delete"}],
           "method": "global_only", "result": {"events": None, "anomaly_candidate": True}}
    result = runner._anomaly_summary([row])
    assert result["anomaly_recall"] == 1
    assert result["withheld_count"] == 0
    row["result"]["anomaly_candidate"] = None
    result = runner._anomaly_summary([row])
    assert result["anomaly_recall"] == 0
    assert result["withheld_count"] == 1


def test_group_bootstrap_rejects_mispaired_grouping():
    row = {"trial_id": "one", "source_group": "a", "source_kind": "public_speech",
           "condition": "normal_clean", "profile": "basic", "expected_events": [],
           "method": "candidate", "result": {"status": "analyzed", "events": []}}
    other = {**row, "source_group": "b", "method": "global_only", "result": {"events": None, "anomaly_candidate": False}}
    with pytest.raises(ValueError, match="grouping"):
        runner._anomaly_bootstrap([row], [other])
