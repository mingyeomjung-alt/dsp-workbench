"""Fresh synthetic v3 facade, runner and persistence safety regressions."""

import json

import numpy as np
import pytest

from audio_regression import api, pipeline_cli
from audio_regression import pipeline_runner as native, saved_pipeline as saved
from audio_regression.engine import EngineConfigError
from audio_regression.fixtures import generate_case
from audio_regression.pipeline_reporting import validate_pipeline_result
from audio_regression.saved_pipeline_contract import validate_saved_pipeline_result


def _source(tmp_path, kind="clean"):
    case = generate_case(kind, seed=133996)
    reference, output = tmp_path / "reference.wav", tmp_path / "output.wav"
    reference.write_bytes(case.reference_wav)
    output.write_bytes(case.processed_wav)
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps({"schema_version": 1, "source": "reference.wav", "stages": [
        {"label": "first", "output": "output.wav", "declaration": {"allow_gain": False, "allow_resampling": False}},
        {"label": "second", "output": "output.wav", "declaration": {"allow_gain": False, "allow_resampling": False}},
    ]}), encoding="utf-8")
    return reference, output, manifest


@pytest.mark.parametrize("kind", ["clean", "delete", "repeat"])
def test_facades_preserve_old_versions_and_identify_v3(tmp_path, kind):
    reference, output, _ = _source(tmp_path, kind)
    old_bytes = reference.read_bytes(), output.read_bytes()
    assert api.analyze_pair(reference, output)["engine"] == "local_content_alignment_v1"
    assert api.analyze_pair(reference, output, engine="v2")["engine"] == "local_content_alignment_v2"
    result, trace = api.analyze_pair_with_trace(reference, output, engine="v3")
    assert result == api.analyze_pair(reference, output, engine="v3")
    assert result["engine"] == trace["analysis_engine"] == "local_content_alignment_v3"
    assert trace["reference_sha256"] == result["reference"]["sha256"]
    assert trace["processed_sha256"] == result["processed"]["sha256"]
    assert old_bytes == (reference.read_bytes(), output.read_bytes())
    assert result["complete_audio_approval"] is False


@pytest.mark.parametrize("profile", ["telephone", "missing", None, True, np.array(["basic", "telephone"])])
def test_bad_candidate_profiles_fail_before_read(tmp_path, profile):
    for facade in (api.analyze_pair, api.analyze_pair_with_trace):
        with pytest.raises(EngineConfigError):
            facade(tmp_path / "missing", tmp_path / "missing2", engine="v3", profile=profile)


@pytest.mark.parametrize("mode", ["native", "saved"])
@pytest.mark.parametrize("scope", ["stage", "end_to_end"])
def test_v3_trace_failure_blocks_and_preserves_files(tmp_path, monkeypatch, mode, scope):
    reference, output, manifest = _source(tmp_path)
    before = reference.read_bytes(), output.read_bytes()
    module = native if mode == "native" else saved
    writer = module._new_json

    def fault(path, value):
        if path.name == "trace.json" and (scope == "stage" or path.parent.name == "end_to_end"):
            raise module.PipelineRunError("output_write_error") if mode == "native" else module.SavedPipelineError("output_write_error")
        return writer(path, value)

    monkeypatch.setattr(module, "_new_json", fault)
    folder = tmp_path / "new"
    result = (native.run_pipeline(reference, [{"kind": "gain", "gain_db": -3}] * 2, folder, engine="v3")
              if mode == "native" else saved.audit_saved_pipeline(manifest, folder, engine="v3"))
    (validate_pipeline_result if mode == "native" else validate_saved_pipeline_result)(result)
    assert result["engine"].endswith("_v3")
    assert result["status"] == "incomplete"
    assert result["summary"]["gate_state"] == "blocked"
    if scope == "stage":
        assert result["stages"][1]["status"] == "not_run"
    else:
        assert all(s["status"] == "analyzed" for s in result["stages"])
        assert (folder / "stages/001/trace.json").is_file()
    assert before == (reference.read_bytes(), output.read_bytes())


@pytest.mark.parametrize("kind,expected", [("clean", 0), ("delete", 1), ("repeat", 1)])
def test_saved_cli_version_and_stored_report(tmp_path, capsys, monkeypatch, kind, expected):
    _, _, manifest = _source(tmp_path, kind)
    folder = tmp_path / "new"
    assert pipeline_cli.main(["audit", "--manifest", str(manifest), "--output-dir", str(folder), "--engine", "v3"]) == expected
    assert json.loads(capsys.readouterr().out)["engine"] == "audio_saved_pipeline_audit_v3"
    result = json.loads((folder / "audit_result.json").read_text(encoding="utf-8"))
    assert all(s["analysis"]["engine"] == "local_content_alignment_v3" for s in result["stages"])
    if kind != "clean":
        assert result["summary"]["first_concern"]["stage_index"] == 1
        assert result["stages"][1]["check"]["exit_code"] == 0

    def forbidden(*args, **kwargs):
        pytest.fail("Rendering stored JSON must not analyze again.")

    monkeypatch.setattr(api, "analyze_pair_with_trace", forbidden)
    report = tmp_path / "stored.html"
    assert pipeline_cli.main(["audit-report", "--input", str(folder / "audit_result.json"), "--output", str(report)]) == 0
    assert "local_content_alignment_v3" in report.read_text(encoding="utf-8")
