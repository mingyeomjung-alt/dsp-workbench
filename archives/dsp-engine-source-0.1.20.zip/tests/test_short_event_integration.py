"""Opt-in short-event facade/CLI checks; no commercial accuracy claim."""

from copy import deepcopy
import hashlib
import json

import numpy as np
import pytest

from audio_regression.api import analyze_pair, analyze_pair_with_trace
from audio_regression.audio import encode_wav
from audio_regression.check_policy import check_result
from audio_regression.engine import EngineConfigError
from audio_regression.fixtures import generate_case
from audio_regression.handoff_cli import main
from audio_regression.reporting import render_html
from audio_regression.result_contract import ResultContractError, validate_analysis_result


def pair(tmp_path, *, damage=False, silence=False):
    if silence:
        samples = np.zeros(48000)
        reference = encode_wav(samples, 16000)
    else:
        from audio_regression.audio import decode_wav
        reference = generate_case(seed=202610157616, duration_seconds=3).reference_wav
        samples = decode_wav(reference).samples
    processed = np.concatenate((samples[:16000], samples[17280:]))
    if damage:
        processed = processed.copy()
        processed[-1] += 1 / 32768
    first, second = tmp_path / "original.wav", tmp_path / "processed.wav"
    first.write_bytes(reference)
    second.write_bytes(encode_wav(processed, 16000))
    return first, second


def test_opt_in_api_short_event_and_input_preservation(tmp_path):
    original, processed = pair(tmp_path)
    hashes = [hashlib.sha256(p.read_bytes()).hexdigest() for p in (original, processed)]
    result, trace = analyze_pair_with_trace(original, processed, engine="v10")
    assert result == analyze_pair(original, processed, engine="v10")
    assert validate_analysis_result(result) is result
    assert result["engine"] == "local_content_alignment_v10"
    assert result["analysis"]["minimum_event_duration_ms"] == 50
    assert result["analysis"]["sample_rate_hz"] == 16000
    assert trace["short_event_proved"] is True
    assert result["events"][0]["reference_interval_ms"] == [1000, 1080]
    assert check_result(result)["gate_state"] == "review_required"
    assert hashes == [hashlib.sha256(p.read_bytes()).hexdigest() for p in (original, processed)]
    assert analyze_pair(original, original)["engine"] == "local_content_alignment_v1"


def test_native_partial_signal_match_cannot_hide_tail_damage(tmp_path):
    original, processed = pair(tmp_path, damage=True)
    result, trace = analyze_pair_with_trace(original, processed, engine="v10")
    assert result["status"] == "withheld" and result["events"] is None
    assert check_result(result)["gate_state"] == "blocked"
    assert trace["short_event_proved"] is False
    review = result["review_diagnostics"]
    assert review["trace_availability"] == "recorded"
    assert review["stages"][-1]["engine"] == "local_content_alignment_v10"
    assert review["fault_provenance_confirmed"] is False


def test_inherited_withheld_trace_is_not_native_proof(tmp_path):
    original, _ = pair(tmp_path, silence=True)
    result, trace = analyze_pair_with_trace(original, original, engine="v10")
    assert result["status"] == "withheld"
    assert result["analysis"]["minimum_event_duration_ms"] == 200
    assert result["analysis"]["sample_rate_hz"] == 8000
    assert trace["short_event_attempted"] is False
    assert check_result(result)["exit_code"] == 2
    assert result["review_diagnostics"]["trace_availability"] == "recorded"


def test_cli_check_report_and_overwrite_rejection(tmp_path, capsys):
    original, processed = pair(tmp_path)
    output, report = tmp_path / "result.json", tmp_path / "report.html"
    assert main(["analyze", "--engine", "v10", "--reference", str(original),
                 "--processed", str(processed), "--output", str(output)]) == 0
    capsys.readouterr()
    assert main(["check", "--input", str(output)]) == 1
    check = json.loads(capsys.readouterr().out)
    assert check["complete_audio_approval"] is False
    assert main(["report", "--input", str(output), "--output", str(report)]) == 0
    capsys.readouterr()
    before = report.read_bytes()
    assert "50~200ms" in report.read_text(encoding="utf-8")
    assert main(["report", "--input", str(output), "--output", str(report)]) == 3
    assert report.read_bytes() == before


@pytest.mark.parametrize("kwargs", [{"profile": "telephone"}, {"engine": "v13"}])
def test_bad_candidate_configuration_is_rejected_before_audio_read(kwargs):
    config = {"engine": "v10", **kwargs}
    with pytest.raises(EngineConfigError):
        analyze_pair("does-not-exist.wav", "also-missing.wav", **config)


def test_native_result_contract_rejects_false_complete_approval(tmp_path):
    original, processed = pair(tmp_path)
    result = analyze_pair(original, processed, engine="v10")
    edited = deepcopy(result)
    edited["complete_audio_approval"] = True
    with pytest.raises(ResultContractError):
        validate_analysis_result(edited)
    assert "운영" not in render_html(result).split("<title>", 1)[-1].split("</title>", 1)[0]
