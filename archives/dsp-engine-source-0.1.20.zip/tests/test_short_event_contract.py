"""Invented v10 result geometry only: not audio or accuracy evaluation."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path

import pytest

from audio_regression.result_contract import ResultContractError, validate_analysis_result
from audio_regression.short_event_result_contract import (
    ENGINE, METHOD, validate_short_event_analysis_result,
)


_ROOT = Path(__file__).resolve().parents[1]
_SCHEMAS = _ROOT / "src" / "audio_regression" / "schemas"


def _inherited(kind="delete"):
    value = json.loads((_ROOT / "tests" / "fixtures" / "results" /
                        f"synthetic_basic_{kind}.json").read_text("utf-8"))
    value["engine"] = ENGINE
    value["analysis"]["method"] = METHOD
    return value


def _native(kind="delete", rate=16000, length=100):
    value = _inherited(kind)
    delta = length if kind == "repeat" else -length
    value["reference"].update(sample_rate_hz=rate, sample_count=6 * rate, duration_ms=6000)
    value["processed"].update(sample_rate_hz=rate, sample_count=round((6000 + delta) * rate / 1000),
                               duration_ms=6000 + delta)
    value["analysis"].update(sample_rate_hz=rate, hop_ms=1000 / rate, minimum_event_duration_ms=50)
    value["diagnostics"].update(normalized_path_cost=0, gain_estimate=1, applied_gain=1,
        matched_normalized_rmse=0, minimum_local_correlation=1, anchor_run_count=2,
        matched_analysis_samples=min(value["reference"]["sample_count"], value["processed"]["sample_count"]))
    event = value["events"][0]
    for key in event["evidence"]:
        event["evidence"][key] = 1 if key.endswith("correlation") else 0
    event["evidence"]["offset_after_ms"] = delta
    if kind == "delete":
        event.update(reference_interval_ms=[2000, 2000 + length], processed_boundary_ms=2000)
        left_end, right_start = 2000, 2000 + length
    else:
        event.update(reference_source_interval_ms=[2000, 2000 + length],
                     processed_added_interval_ms=[2000 + length, 2000 + 2 * length])
        left_end = right_start = 2000 + length
    value["alignment_segments"] = [
        {"reference_interval_ms": [0, left_end], "processed_offset_ms": 0,
         "anchor_correlations": [1, 1, 1]},
        {"reference_interval_ms": [right_start, 6000], "processed_offset_ms": delta,
         "anchor_correlations": [1, 1, 1]},
    ]
    return value


def _withheld(value):
    value.update(status="withheld", content_preservation_status="withheld",
                 reason_code="event_boundary_not_supported", events=None, diagnostics={})
    value.pop("alignment_segments")
    return value


def _reject(value, code):
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(value)
    assert caught.value.code == code


@pytest.mark.parametrize("kind", ["delete", "repeat"])
@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
@pytest.mark.parametrize("length", [50, 100, 200])
def test_native_short_result_preserves_original_and_own_axis_geometry(kind, rate, length):
    value = _native(kind, rate, length)
    before = deepcopy(value)
    assert validate_analysis_result(value) is value
    assert validate_short_event_analysis_result(value) is value
    assert value == before


@pytest.mark.parametrize("kind", ["clean", "delete", "repeat"])
def test_inherited_v9_grid_keeps_200_ms_analysis_contract(kind):
    value = _inherited(kind)
    before = deepcopy(value)
    assert validate_analysis_result(value) is value
    assert value == before
    value["analysis"]["minimum_event_duration_ms"] = 50
    _reject(value, "invalid_analysis_method")


@pytest.mark.parametrize("value", [None, [], "result", 10, True])
def test_native_contract_rejects_non_dictionary(value):
    _reject(value, "invalid_result_type")


@pytest.mark.parametrize("path,replacement,code", [
    (("complete_audio_approval",), True, "invalid_approval_claim"),
    (("commercial_performance_validated",), True, "invalid_approval_claim"),
    (("configuration", "allow_gain"), True, "unsupported_short_event_configuration"),
    (("configuration", "allow_gain"), 0, "unsupported_short_event_configuration"),
    (("configuration", "allow_resampling"), True, "unsupported_short_event_configuration"),
    (("configuration", "profile"), "telephone", "unsupported_profile"),
    (("analysis", "minimum_event_duration_ms"), 200, "invalid_analysis_method"),
    (("analysis", "hop_ms"), 0.1, "invalid_analysis_method"),
    (("analysis", "sample_rate_hz"), 48000, "invalid_analysis_method"),
    (("analysis", "method"), "global_context_quantized_event_forward_proof", "invalid_analysis_method"),
    (("diagnostics", "matched_analysis_samples"), 47200, "inconsistent_matched_sample_count"),
    (("diagnostics", "anchor_run_count"), 1, "inconsistent_anchor_count"),
    (("diagnostics", "minimum_local_correlation"), 0.999, "inconsistent_short_event_exact_metrics"),
    (("diagnostics", "matched_normalized_rmse"), 0.001, "inconsistent_short_event_exact_metrics"),
    (("diagnostics", "normalized_path_cost"), -1e-14, "inconsistent_short_event_exact_metrics"),
    (("alignment_segments", 0, "reference_interval_ms"), [10, 2000], "inconsistent_short_event_full_coverage"),
    (("alignment_segments", 1, "reference_interval_ms"), [2110, 6000], "inconsistent_short_event_full_coverage"),
    (("alignment_segments", 1, "processed_offset_ms"), -90, "inconsistent_short_event_full_coverage"),
    (("alignment_segments", 1, "anchor_correlations"), [1, 1.001, 1], "inconsistent_short_event_exact_evidence"),
    (("events", 0, "evidence", "boundary_correlation"), 0.95, "inconsistent_short_event_exact_evidence"),
    (("events", 0, "evidence", "offset_before_ms"), 1, "inconsistent_short_event_offset"),
    (("events", 0, "evidence", "offset_after_ms"), -90, "inconsistent_short_event_offset"),
    (("events", 0, "processed_boundary_ms"), 2100, "inconsistent_delete_geometry"),
    (("events", 0, "type"), [], "unsupported_event_type"),
])
def test_native_contract_rejects_fabricated_metrics_and_geometry(path, replacement, code):
    value = _native()
    node = value
    for key in path[:-1]:
        node = node[key]
    node[path[-1]] = replacement
    _reject(value, code)


def test_native_grid_cannot_have_zero_or_multiple_events_or_hidden_claims():
    for replacement in ([], None, [_native()["events"][0]] * 2):
        value = _native()
        value["events"] = replacement
        _reject(value, "inconsistent_result_status")
    value = _native()
    value["probability"] = 0.99
    _reject(value, "unexpected_result_field")
    value = _native()
    del value["reference"]
    _reject(value, "missing_result_field")
    value = _native()
    value["diagnostics"]["path"] = "private"
    _reject(value, "unexpected_result_field")


def test_native_grid_does_not_claim_unproven_full_signal_changes_or_off_grid_boundaries():
    value = _native()
    value["processed"]["sample_count"] += 1
    value["processed"]["duration_ms"] += 1000 / 16000
    value["diagnostics"]["matched_analysis_samples"] += 1
    _reject(value, "inconsistent_short_event_length_delta")
    value = _native()
    value["events"][0]["reference_interval_ms"] = [2000.01, 2100.01]
    _reject(value, "short_event_coordinate_not_on_native_grid")
    value = _native()
    value["events"][0]["reference_interval_ms"] = [0, 100]
    _reject(value, "short_event_not_internal")


@pytest.mark.parametrize("native", [False, True])
def test_withheld_and_error_remain_blocked_and_have_no_events(native):
    value = _withheld(_native() if native else _inherited())
    assert validate_analysis_result(value) is value
    error = {"schema_version": 1, "engine": ENGINE, "status": "error", "reason_code": "input_error"}
    assert validate_analysis_result(error) is error
    error["events"] = []
    _reject(error, "unexpected_result_field")


def test_v10_optional_review_trace_is_ordered_bounded_and_not_fault_proof():
    value = _withheld(_native())
    value["review_diagnostics"] = {
        "schema_version": 1, "selected_engine": ENGINE, "result_status": "withheld",
        "primary_reason_code": value["reason_code"], "trace_availability": "recorded",
        "diagnostic_only": True, "fault_provenance_confirmed": False,
        "stages": [{"engine": f"local_content_alignment_v{version}", "outcome": "withheld",
                    "reason_code": "event_boundary_not_supported", "detail_reason_code": None}
                   for version in range(1, 11)],
    }
    before = deepcopy(value)
    assert validate_analysis_result(value) is value
    assert value == before
    value["review_diagnostics"]["stages"].reverse()
    _reject(value, "unordered_review_diagnostics_stages")


def test_native_review_reason_codes_do_not_expand_legacy_stage_contracts():
    value = _withheld(_native())
    reason = "short_event_no_complete_single_edit_explanation"
    value["reason_code"] = reason
    value["review_diagnostics"] = {
        "schema_version": 1, "selected_engine": ENGINE, "result_status": "withheld",
        "primary_reason_code": reason, "trace_availability": "recorded",
        "diagnostic_only": True, "fault_provenance_confirmed": False,
        "stages": [{"engine": ENGINE, "outcome": "withheld",
                    "reason_code": reason, "detail_reason_code": None}],
    }
    assert validate_analysis_result(value) is value
    value["review_diagnostics"]["stages"][0]["engine"] = "local_content_alignment_v9"
    _reject(value, "invalid_review_stage_reason")


def test_new_schema_is_self_contained_and_old_schema_bytes_are_unchanged():
    schema = json.loads((_SCHEMAS / "analysis-result-v10.schema.json").read_text("utf-8"))
    assert schema["$id"].endswith(":v10")
    assert schema["$defs"]["analysis"]["properties"]["method"]["const"] == METHOD
    assert schema["$defs"]["analysis"]["properties"]["minimum_event_duration_ms"]["enum"] == [50, 200]
    assert schema["$defs"]["reviewDiagnostics"]["properties"]["stages"]["maxItems"] == 10
    assert ENGINE in schema["$defs"]["reviewStage"]["properties"]["engine"]["enum"]
    expected = [
        "ef1a43fcf41ecd3db3a6f398b882b6886bc1255d9065343535be71210fb0e1d1",
        "3947a8fbca4bf3165f362d0e12e1284c4db22350c8bb5f09822b6c7356df0727",
        "b80c420e17f189f9afc57bdf6647bd7769b8ddc8ef51cb7e7ca61abaf6fd8bc9",
        "64104df35c380bd6fdb614f6d2dc38498f17f4866ae7db5bc95e6abf21ac6ec1",
        "305377dc4bc46d847233140b8b697fd98535a24ae22f4945cb64309053439c58",
        "aa2a6dd5bcc57646dd6363312b988c8943417842b855e13425922fa829474fc9",
        "d58a7bd6bd256138302c9f6bfc4126ec68a2ee3b7cb2e94b4eff2cb02264c264",
        "19273c5134a3e79adee3c7855068c4f6e1d68b55652f635f36a7752e849609e3",
        "c96cf6949879b9634d571846e79b0352a19ace7c2d12b4b990d3ad1cbdb703a9",
    ]
    for version, digest in enumerate(expected, 1):
        assert hashlib.sha256((_SCHEMAS / f"analysis-result-v{version}.schema.json").read_bytes()).hexdigest() == digest
