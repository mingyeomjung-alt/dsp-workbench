"""Fresh owned fixtures for the bounded endpoint-loss candidate, not field accuracy."""

from copy import deepcopy
import json

import numpy as np
import pytest

from audio_regression import edge_event_engine as candidate
from audio_regression import short_event_engine
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.edge_event_result_contract import validate_edge_event_analysis_result
from audio_regression.engine import EngineConfig, EngineConfigError


def _audio(values, rate=8000):
    return decode_wav(encode_wav(np.asarray(values, dtype=float), rate))


def _signal(rate=8000, seed=202610157411):
    rng = np.random.default_rng(seed)
    return rng.integers(-12000, 12001, size=4 * rate).astype(float) / 32768


def _pair(side, duration_ms=100, rate=8000):
    x = _signal(rate)
    length = round(duration_ms * rate / 1000)
    y = x[length:] if side == "head" else x[:-length]
    return _audio(x, rate), _audio(y, rate), length


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
@pytest.mark.parametrize("duration_ms", [50, 100, 200, 500, 2000])
@pytest.mark.parametrize("side", ["head", "tail"])
def test_exact_single_endpoint_loss_has_native_full_coverage(rate, duration_ms, side):
    reference, processed, length = _pair(side, duration_ms, rate)
    result, trace = candidate.analyze_buffers_with_trace(reference, processed)
    assert result["status"] == "analyzed", result["reason_code"]
    assert validate_edge_event_analysis_result(result) is result
    event = result["events"][0]
    expected_start = 0 if side == "head" else len(processed.samples)
    expected_end = length if side == "head" else len(reference.samples)
    assert event["type"] == "delete"
    assert event["location"] == side
    assert event["reference_interval_ms"] == pytest.approx(
        [expected_start * 1000 / rate, expected_end * 1000 / rate])
    assert event["processed_boundary_ms"] == (0 if side == "head" else processed.metadata()["duration_ms"])
    assert event["evidence"]["retained_offset_ms"] == (-duration_ms if side == "head" else 0)
    assert event["evidence"]["removed_sample_count"] == length
    assert event["evidence"]["retained_native_samples"] == len(processed.samples)
    assert event["evidence"]["all_retained_native_samples_exact"] is True
    assert result["analysis"] == {
        "sample_rate_hz": rate, "hop_ms": 1000 / rate, "method": candidate.METHOD,
        "minimum_event_duration_ms": 50, "maximum_cumulative_edit_shift_ms": 2000,
        "diagnostic_rules_not_calibrated_probabilities": True,
    }
    assert result["diagnostics"]["anchor_run_count"] == 1
    assert result["diagnostics"]["matched_analysis_samples"] == len(processed.samples)
    assert len(result["alignment_segments"]) == 1
    assert trace["proof_path"] == "native_pcm_endpoint_loss"
    assert trace["endpoint_loss_proved"] is True
    assert trace["every_output_sample_exact"] is True
    assert trace["all_retained_native_samples_exact"] is True
    assert trace["complete_endpoints_included"] is True
    assert trace["supported_geometry_count"] == 1
    assert trace["search_complete"] is True
    assert trace["edit_intent_or_cause_established"] is False
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    json.dumps(trace, allow_nan=False)


@pytest.mark.parametrize("side", ["head", "tail"])
@pytest.mark.parametrize("position", [0, 17, 15000, -1])
def test_one_lsb_retained_change_never_escapes_to_legacy_clear(monkeypatch, side, position):
    def forbidden(*args):
        raise AssertionError("unexplained eligible shortening cannot use legacy fallback")
    monkeypatch.setattr(candidate.short_event_engine, "analyze_buffers_with_trace", forbidden)
    reference, processed, _ = _pair(side)
    changed = processed.samples.copy()
    changed[position] += 1 / 32768
    result, trace = candidate.analyze_buffers_with_trace(reference, _audio(changed))
    assert result["status"] == "withheld"
    assert result["events"] is None
    assert result["reason_code"] == "endpoint_loss_no_complete_single_deletion_explanation"
    assert trace["endpoint_loss_proved"] is False
    validate_edge_event_analysis_result(result)


@pytest.mark.parametrize("side", ["head", "tail"])
def test_endpoint_plus_internal_loss_is_not_one_endpoint_event(side):
    x = _signal()
    # 50 ms edge loss and 50 ms independent interior loss, not one 100 ms cut.
    y = np.concatenate((x[400:15000], x[15400:])) if side == "head" else np.concatenate((x[:15000], x[15400:-400]))
    result, trace = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"
    assert trace["supported_geometry_count"] == 0


def test_both_end_losses_are_not_one_edge_event():
    x = _signal()
    result, _ = candidate.analyze_buffers_with_trace(_audio(x), _audio(x[400:-400]))
    assert result["status"] == "withheld"
    assert result["reason_code"] == "endpoint_loss_no_complete_single_deletion_explanation"


@pytest.mark.parametrize("side", ["head", "tail"])
def test_periodic_audio_has_ambiguous_interior_and_edge_explanations(side):
    block = _signal()[:800]
    x = np.tile(block, 40)
    y = x[800:] if side == "head" else x[:-800]
    result, trace = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"
    assert result["reason_code"] == "endpoint_loss_ambiguous_single_deletion_geometry"
    assert trace["supported_geometry_count"] > 1


@pytest.mark.parametrize("side", ["head", "tail"])
def test_even_one_sample_internal_alternative_withholds_exact_endpoint_claim(side):
    x = _signal()
    if side == "head":
        x[0] = x[800]
        y = x[800:]
    else:
        x[-1] = x[-801]
        y = x[:-800]
    result, trace = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"
    assert result["reason_code"] == "endpoint_loss_ambiguous_single_deletion_geometry"
    assert trace["supported_geometry_count"] >= 2


@pytest.mark.parametrize("side", ["head", "tail"])
def test_retained_context_must_be_unique_in_both_complete_files(side):
    x = _signal()
    if side == "head":
        x[12000:12960] = x[800:1760]
        y = x[800:]
    else:
        x[3000:3960] = x[-1760:-800]
        y = x[:-800]
    result, _ = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"
    assert result["reason_code"] == "endpoint_loss_nonunique_retained_context"


@pytest.mark.parametrize("side", ["head", "tail"])
def test_weak_one_sided_context_withholds(side):
    x = _signal()
    if side == "head":
        x[800:1760] = 0
        y = x[800:]
    else:
        x[-1760:-800] = 0
        y = x[:-800]
    result, _ = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"
    assert result["reason_code"] == "endpoint_loss_uninformative_retained_context"


@pytest.mark.parametrize("side", ["head", "tail"])
def test_constant_nonzero_removed_block_is_not_informative_loss(side):
    x = _signal()
    if side == "head":
        x[:800] = .125
        y = x[800:]
    else:
        x[-800:] = .125
        y = x[:-800]
    result, _ = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"
    assert result["reason_code"] == "endpoint_loss_uninformative_removed_content"


@pytest.mark.parametrize("side", ["head", "tail"])
def test_mostly_silent_removed_block_with_nonzero_content_is_not_legacy_normal(side):
    x = _signal()
    if side == "head":
        x[:800] = 0
        x[799] = .25
        y = x[800:]
    else:
        x[-800:] = 0
        x[-800] = .25
        y = x[:-800]
    result, trace = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "analyzed"
    assert result["events"][0]["location"] == side
    assert trace["endpoint_loss_attempted"] is True


def _baseline():
    return {"engine": short_event_engine.ENGINE,
            "analysis": {"method": short_event_engine.METHOD, "sample_rate_hz": 8000,
                         "hop_ms": 10, "minimum_event_duration_ms": 200},
            "status": "analyzed", "reason_code": None, "limitations": [], "events": []}


@pytest.mark.parametrize("side", ["head", "tail"])
@pytest.mark.parametrize("operation", ["pad", "trim"])
@pytest.mark.parametrize("duration_ms", [50, 200, 500, 2000])
def test_exact_zero_only_edge_transform_preserves_original_v10(monkeypatch, side, operation, duration_ms):
    x = _signal()
    count = duration_ms * 8
    # Padding fixture remains within duration limits even for the longest case.
    padded = np.concatenate((np.zeros(count), x)) if side == "head" else np.concatenate((x, np.zeros(count)))
    reference, processed = (x, padded) if operation == "pad" else (padded, x)
    baseline, old_trace = _baseline(), {"actual_native_or_legacy_trace": True}
    original = deepcopy(baseline)
    monkeypatch.setattr(candidate.short_event_engine, "analyze_buffers_with_trace", lambda *args: (baseline, old_trace))
    result, trace = candidate.analyze_buffers_with_trace(_audio(reference), _audio(processed))
    assert baseline == original
    assert result["status"] == "analyzed" and result["events"] == []
    assert result["analysis"] == baseline["analysis"]
    assert trace["proof_path"] == "preserved_v10_result"
    assert trace["endpoint_loss_attempted"] is False
    assert trace["inherited_v10_trace"] == old_trace


@pytest.mark.parametrize("duration_ms", [50, 100, 200])
@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_actual_m1_native_internal_edit_result_is_preserved(duration_ms, kind):
    x = _signal()
    point, count = 14000, duration_ms * 8
    y = (np.concatenate((x[:point], x[point + count:])) if kind == "delete" else
         np.concatenate((x[:point], x[point - count:point], x[point:])))
    reference, processed = _audio(x), _audio(y)
    baseline = short_event_engine.analyze_buffers(reference, processed)
    assert baseline["status"] == "analyzed"
    result, trace = candidate.analyze_buffers_with_trace(reference, processed)
    assert result["events"] == baseline["events"]
    assert result["analysis"] == baseline["analysis"]
    assert result["diagnostics"] == baseline["diagnostics"]
    assert trace["endpoint_loss_attempted"] is False
    validate_edge_event_analysis_result(result)


def test_longer_exact_internal_deletion_preserves_legacy_v10_grid(monkeypatch):
    x = _signal()
    y = np.concatenate((x[:10000], x[14000:]))
    baseline = _baseline()
    monkeypatch.setattr(candidate.short_event_engine, "analyze_buffers_with_trace", lambda *args: (baseline, {}))
    result, trace = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["analysis"]["hop_ms"] == 10
    assert result["analysis"]["minimum_event_duration_ms"] == 200
    assert trace["scope_reason"] == "exact_internal_deletion_geometry"


@pytest.mark.parametrize("configuration", [EngineConfig(allow_gain=True), EngineConfig(allow_resampling=True)])
def test_declared_transforms_are_outside_native_scope(monkeypatch, configuration):
    baseline = _baseline()
    monkeypatch.setattr(candidate.short_event_engine, "analyze_buffers_with_trace", lambda *args: (baseline, {}))
    reference, processed, _ = _pair("head")
    result, trace = candidate.analyze_buffers_with_trace(reference, processed, configuration)
    assert result["analysis"] == baseline["analysis"]
    assert trace["endpoint_loss_attempted"] is False


@pytest.mark.parametrize("configuration", [object(), EngineConfig(profile="telephone")])
def test_invalid_configuration_is_not_silently_changed(configuration):
    reference, processed, _ = _pair("head")
    with pytest.raises(EngineConfigError):
        candidate.analyze_buffers_with_trace(reference, processed, configuration)


def test_fractional_native_duration_bound_is_not_rounded_up():
    x = _signal(44100)
    assert candidate._eligible(_audio(x, 44100), _audio(x[2205:], 44100), EngineConfig())
    assert not candidate._eligible(_audio(x, 44100), _audio(x[2204:], 44100), EngineConfig())
