"""Fresh synthetic development regressions for the declared Fourier model."""

from __future__ import annotations

from copy import deepcopy

import numpy as np
import pytest
from scipy.signal import resample, resample_poly

from audio_regression.audio import decode_wav, encode_wav
from audio_regression.engine import EngineConfig, EngineConfigError
from audio_regression import resampler_engine as engine


SETTINGS = EngineConfig(allow_resampling=True)


def _audio(values, rate):
    pcm = np.rint(np.asarray(values, dtype=np.float64) * 32768.0)
    assert np.all(pcm >= -32768) and np.all(pcm <= 32767)
    return decode_wav(encode_wav(pcm / 32768.0, rate))


def _source(count=192000, seed=202610152871):
    rng = np.random.default_rng(seed)
    times = np.arange(count) / 48000.0
    values = 0.12 * rng.standard_normal(count)
    values += 0.04 * np.sin(2 * np.pi * 731.0 * times)
    return _audio(values, 48000)


def _oracle(source):
    return _audio(resample(source.samples, len(source.samples) // 3), 16000)


def _analyze(source, processed):
    return engine.analyze_buffers_with_trace(
        source, processed, SETTINGS, resampling_model=engine.MODEL)


@pytest.mark.parametrize("count", [96000, 96003, 96006, 192003])
def test_renderer_matches_independent_scipy_resample(count):
    source = _source(count)
    original = source.samples.copy()
    rendered = engine.render_resampling_reference(source)
    oracle = _oracle(source)
    assert rendered.sha256 == oracle.sha256
    np.testing.assert_array_equal(rendered.samples, oracle.samples)
    np.testing.assert_array_equal(source.samples, original)
    assert rendered.sample_rate_hz == 16000
    assert rendered.metadata()["duration_ms"] == source.metadata()["duration_ms"]


@pytest.mark.parametrize("count", [96000, 96003])
@pytest.mark.parametrize("phase", [0.0, 0.31, 1.57])
def test_nyquist_merge_and_odd_bin_match_scipy(count, phase):
    # Exactly the last retained Fourier bin, plus input frequencies which
    # must disappear.  Even output requires merging its conjugate bin pair.
    bin_index = (count // 3) // 2
    indices = np.arange(count)
    source = _audio(
        0.18 * np.cos(2 * np.pi * bin_index * indices / count + phase)
        + 0.06 * np.cos(2 * np.pi * 19001 * indices / count + 0.7), 48000)
    actual = engine.render_resampling_reference(source)
    oracle = _oracle(source)
    np.testing.assert_array_equal(actual.samples, oracle.samples)


def test_normal_proof_keeps_original_and_canonical_metadata_separate():
    source = _source()
    processed = _oracle(source)
    result, trace = _analyze(source, processed)
    assert result["engine"] == engine.ENGINE
    assert result["analysis"]["method"] == engine.METHOD
    assert result["proof_kind"] == "exact_resampling_only"
    assert result["status"] == "analyzed"
    assert result["events"] == []
    assert result["reference"] == source.metadata()
    assert result["processed"] == processed.metadata()
    assert result["resampling_reference"] == processed.metadata()
    assert result["reference"]["sha256"] != result["resampling_reference"]["sha256"]
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    assert trace["proof_proved"] is True
    assert trace["every_output_sample_exact"] is True
    assert trace["reference_sha256"] == source.sha256
    assert result["diagnostics"]["matched_analysis_samples"] == len(processed.samples)
    assert result["diagnostics"]["minimum_local_correlation"] is None


@pytest.mark.parametrize("level", [0.0, 0.125])
def test_exact_uninformative_normal_does_not_invent_correlation(level):
    source = _audio(np.full(96000, level), 48000)
    result, trace = _analyze(source, _oracle(source))
    assert result["proof_kind"] == "exact_resampling_only"
    assert result["status"] == "analyzed"
    assert result["diagnostics"]["minimum_local_correlation"] is None
    assert result["diagnostics"]["anchor_run_count"] == 0
    assert trace["every_output_sample_exact"] is True


@pytest.mark.parametrize("kind", ["delete", "repeat"])
@pytest.mark.parametrize("milliseconds", [50, 100, 200])
def test_short_post_resampling_edit(kind, milliseconds):
    source = _source()
    canonical = _oracle(source)
    point, length = 32000, milliseconds * 16
    values = (np.concatenate((canonical.samples[:point], canonical.samples[point + length:]))
              if kind == "delete" else np.concatenate((canonical.samples[:point],
                  canonical.samples[point - length:point], canonical.samples[point:])))
    result, trace = _analyze(source, _audio(values, 16000))
    assert result["status"] == "analyzed"
    assert result["proof_kind"] == "native_short_event"
    assert result["events"][0]["type"] == kind
    event = result["events"][0]
    if kind == "delete":
        assert event["reference_interval_ms"] == [2000.0, 2000.0 + milliseconds]
    else:
        assert event["processed_added_interval_ms"] == [2000.0, 2000.0 + milliseconds]
    assert trace["proof_proved"] is True
    assert trace["every_output_sample_exact"] is True
    assert result["reference"] == source.metadata()


@pytest.mark.parametrize("side", ["head", "tail"])
@pytest.mark.parametrize("milliseconds", [50, 200, 1000, 2000])
def test_endpoint_post_resampling_loss(side, milliseconds):
    source = _source(count=240000)
    canonical = _oracle(source)
    length = milliseconds * 16
    values = canonical.samples[length:] if side == "head" else canonical.samples[:-length]
    result, trace = _analyze(source, _audio(values, 16000))
    assert result["status"] == "analyzed"
    assert result["proof_kind"] == "native_endpoint_loss"
    assert result["events"][0]["location"] == side
    assert trace["proof_proved"] is True
    assert trace["postedit_trace"]["endpoint_loss_proved"] is True


@pytest.mark.parametrize("mutation", ["polyphase", "one_lsb", "gain", "window"])
def test_wrong_transform_never_inherits_legacy_normal(mutation):
    source = _source()
    canonical = _oracle(source)
    if mutation == "polyphase":
        values = resample_poly(source.samples, 1, 3)
    elif mutation == "window":
        values = resample(source.samples, len(source.samples) // 3, window="hann")
    elif mutation == "gain":
        values = canonical.samples * 0.8
    else:
        values = canonical.samples.copy()
        values[-1] += 1 / 32768
    result, trace = _analyze(source, _audio(values, 16000))
    assert result["status"] == "withheld"
    assert result["proof_kind"] == "unproved"
    assert result["reason_code"] == "resampler_no_exact_supported_postedit_proof"
    assert result["events"] is None
    assert trace["proof_proved"] is False


@pytest.mark.parametrize("kind", ["delete", "repeat", "head", "tail"])
def test_edit_before_fft_is_not_declared_postedit_proof(kind):
    source = _source()
    point, length = 96000, 4800
    x = source.samples
    if kind == "delete":
        edited = np.concatenate((x[:point], x[point + length:]))
    elif kind == "repeat":
        edited = np.concatenate((x[:point], x[point - length:point], x[point:]))
    elif kind == "head":
        edited = x[length:]
    else:
        edited = x[:-length]
    processed = _audio(resample(edited, len(edited) // 3), 16000)
    result, trace = _analyze(source, processed)
    assert result["status"] == "withheld"
    assert result["events"] is None
    assert trace["proof_proved"] is False


@pytest.mark.parametrize("kind", ["delete", "head", "repeat"])
def test_one_lsb_in_retained_content_prevents_edit_proof(kind):
    source = _source()
    canonical = _oracle(source)
    x = canonical.samples
    point, length = 32000, 1600
    if kind == "delete":
        values = np.concatenate((x[:point], x[point + length:]))
    elif kind == "repeat":
        values = np.concatenate((x[:point], x[point - length:point], x[point:]))
    else:
        values = x[length:].copy()
    values[-1] += 1 / 32768
    result, trace = _analyze(source, _audio(values, 16000))
    assert result["status"] == "withheld"
    assert trace["proof_proved"] is False


def test_projection_overflow_rejected_without_clipping():
    source = _audio(np.concatenate((np.full(48000, 32767 / 32768),
                                   np.zeros(48000))), 48000)
    with pytest.raises(engine.ResamplingProjectionError) as caught:
        engine.render_resampling_reference(source)
    assert caught.value.code == "resampler_projection_out_of_range"
    result, trace = _analyze(source, _audio(np.zeros(32000), 16000))
    assert result["status"] == "withheld"
    assert result["resampling_reference"] is None
    assert result["reason_code"] == "resampler_projection_out_of_range"
    assert trace["proof_proved"] is False


@pytest.mark.parametrize("rate,count", [(16000, 32000), (48000, 96001)])
def test_wrong_source_path_is_withheld(rate, count):
    source = _audio(np.zeros(count), rate)
    result, trace = _analyze(source, _audio(np.zeros(32000), 16000))
    assert result["status"] == "withheld"
    assert result["reason_code"] == "resampler_unsupported_input_path"
    assert result["resampling_reference"] is None
    assert trace["proof_attempted"] is False


@pytest.mark.parametrize("config, model", [
    (EngineConfig(), engine.MODEL),
    (EngineConfig(allow_gain=True, allow_resampling=True), engine.MODEL),
    (EngineConfig(profile="telephone", allow_resampling=True), engine.MODEL),
    (SETTINGS, "scipy_fft"),
    (SETTINGS, None),
    (SETTINGS, [engine.MODEL]),
])
def test_invalid_configuration_rejected_before_file_read(monkeypatch, config, model):
    def forbidden(*_args):
        raise AssertionError("Input was opened before configuration validation")
    monkeypatch.setattr(engine, "read_wav", forbidden)
    with pytest.raises(EngineConfigError):
        engine.analyze_wavs_with_trace("missing-source.wav", "missing-output.wav",
                                       config, resampling_model=model)


def test_declaration_does_not_mutate_configuration():
    source = _source()
    expected = deepcopy(SETTINGS)
    _analyze(source, _oracle(source))
    assert SETTINGS == expected
