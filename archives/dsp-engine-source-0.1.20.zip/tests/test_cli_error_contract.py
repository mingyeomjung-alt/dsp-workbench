"""Synthetic/mocked CLI boundary checks, not natural-audio performance claims."""

from copy import deepcopy
import json

import pytest

from audio_regression import cli
from audio_regression.audio import decode_wav
from audio_regression.baseline import compare_buffers
from audio_regression.engine import analyze_buffers
from audio_regression.fixtures import generate_case


def _args(command, tmp_path, *, output=False):
    if command == "generate":
        return [command, "--output-dir", str(tmp_path / "generated")]
    args = [command, "--reference", str(tmp_path / "private_reference.wav"),
            "--processed", str(tmp_path / "private_processed.wav")]
    if output:
        args += ["--output", str(tmp_path / "result.json")]
    return args


def _replace(monkeypatch, command, replacement):
    name = {"generate": "_generate", "analyze": "analyze_pair", "compare": "compare_wavs"}[command]
    monkeypatch.setattr(cli, name, replacement)


def _valid_result(command):
    case = generate_case("clean", seed=427, duration_seconds=3)
    reference, processed = decode_wav(case.reference_wav), decode_wav(case.processed_wav)
    return (analyze_buffers(reference, processed) if command == "analyze"
            else compare_buffers(reference, processed))


@pytest.mark.parametrize("command", ["analyze", "compare"])
def test_engine_error_response_has_error_exit_and_preserves_valid_save(command, tmp_path, monkeypatch, capsys):
    result = {"schema_version": 1, "status": "error", "reason_code": "unsupported_transform"}
    _replace(monkeypatch, command, lambda *args, **kwargs: result)
    assert cli.main(_args(command, tmp_path, output=True)) == 3
    captured = capsys.readouterr()
    assert json.loads(captured.out) == result
    assert not captured.err
    assert json.loads((tmp_path / "result.json").read_text(encoding="utf-8")) == result


@pytest.mark.parametrize("command", ["generate", "analyze", "compare"])
@pytest.mark.parametrize("exception_type", [RuntimeError, KeyError, TypeError, OverflowError])
def test_unexpected_failures_are_private_structured_errors(command, exception_type, tmp_path, monkeypatch, capsys):
    def fail(*args, **kwargs):
        raise exception_type("private C:/recordings/customer-secret.wav")

    _replace(monkeypatch, command, fail)
    assert cli.main(_args(command, tmp_path, output=command != "generate")) == 3
    captured = capsys.readouterr()
    assert json.loads(captured.out) == {
        "schema_version": 1, "status": "error", "reason_code": "internal_processing_error",
    }
    assert not captured.err
    assert "private" not in captured.out and "customer-secret" not in captured.out
    assert not (tmp_path / "result.json").exists()


@pytest.mark.parametrize("command", ["analyze", "compare"])
def test_unexpected_value_error_is_not_generation_error(command, tmp_path, monkeypatch, capsys):
    def fail(*args, **kwargs):
        raise ValueError("private engine failure")

    _replace(monkeypatch, command, fail)
    assert cli.main(_args(command, tmp_path)) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "internal_processing_error"


@pytest.mark.parametrize("command", ["analyze", "compare"])
@pytest.mark.parametrize("response", [None, [], "measured", {}, {"schema_version": True, "status": "measured"},
                                     {"schema_version": 1, "status": "success"}])
def test_malformed_response_never_creates_output(command, response, tmp_path, monkeypatch, capsys):
    _replace(monkeypatch, command, lambda *args, **kwargs: response)
    assert cli.main(_args(command, tmp_path, output=True)) == 3
    assert json.loads(capsys.readouterr().out)["status"] == "error"
    assert not (tmp_path / "result.json").exists()


@pytest.mark.parametrize("command", ["analyze", "compare"])
def test_unknown_engine_response_is_rejected_before_save(command, tmp_path, monkeypatch, capsys):
    result = _valid_result(command)
    result["engine"] = "unknown_engine"
    _replace(monkeypatch, command, lambda *args, **kwargs: result)
    assert cli.main(_args(command, tmp_path, output=True)) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "unsupported_engine"
    assert not (tmp_path / "result.json").exists()


@pytest.mark.parametrize("command", ["analyze", "compare"])
def test_invalid_json_metric_is_rejected_before_save(command, tmp_path, monkeypatch, capsys):
    result = deepcopy(_valid_result(command))
    result["reference"]["rms"] = float("nan")
    _replace(monkeypatch, command, lambda *args, **kwargs: result)
    assert cli.main(_args(command, tmp_path, output=True)) == 3
    assert json.loads(capsys.readouterr().out)["status"] == "error"
    assert not (tmp_path / "result.json").exists()


@pytest.mark.parametrize("command", ["analyze", "compare"])
def test_valid_results_are_unchanged_and_successful(command, tmp_path, monkeypatch, capsys):
    result = _valid_result(command)
    original = deepcopy(result)
    _replace(monkeypatch, command, lambda *args, **kwargs: result)
    assert cli.main(_args(command, tmp_path, output=True)) == 0
    assert json.loads(capsys.readouterr().out) == original
    assert result == original
    assert json.loads((tmp_path / "result.json").read_text(encoding="utf-8")) == original


def test_existing_output_is_not_replaced_even_when_engine_would_error(tmp_path, monkeypatch, capsys):
    output = tmp_path / "result.json"
    output.write_text("preserved", encoding="utf-8")

    def should_not_run(*args, **kwargs):
        raise AssertionError("Output existence must be checked first.")

    _replace(monkeypatch, "analyze", should_not_run)
    assert cli.main(_args("analyze", tmp_path, output=True)) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "output_exists"
    assert output.read_text(encoding="utf-8") == "preserved"


@pytest.mark.parametrize("command", ["analyze", "compare"])
def test_private_reason_in_error_response_is_not_echoed(command, tmp_path, monkeypatch, capsys):
    result = {"schema_version": 1, "status": "error", "reason_code": "C:/private/customer.wav"}
    _replace(monkeypatch, command, lambda *args, **kwargs: result)
    assert cli.main(_args(command, tmp_path, output=True)) == 3
    captured = capsys.readouterr()
    assert json.loads(captured.out)["reason_code"] == "invalid_reason_code"
    assert "private" not in captured.out
    assert not (tmp_path / "result.json").exists()


@pytest.mark.parametrize("command", ["analyze", "compare"])
def test_unknown_error_payload_is_not_echoed_or_saved(command, tmp_path, monkeypatch, capsys):
    result = {"schema_version": 1, "status": "error", "reason_code": "unsupported_transform",
              "message": "C:/private/customer.wav"}
    _replace(monkeypatch, command, lambda *args, **kwargs: result)
    assert cli.main(_args(command, tmp_path, output=True)) == 3
    captured = capsys.readouterr()
    assert json.loads(captured.out)["reason_code"] == "unexpected_result_field"
    assert "private" not in captured.out
    assert not (tmp_path / "result.json").exists()


def test_selected_analyze_engine_cannot_silently_return_other_known_engine(tmp_path, monkeypatch, capsys):
    result = _valid_result("analyze")
    _replace(monkeypatch, "analyze", lambda *args, **kwargs: result)
    assert cli.main([*_args("analyze", tmp_path, output=True), "--engine", "v2"]) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "unsupported_engine"
    assert not (tmp_path / "result.json").exists()


def test_default_engine_dispatch_is_unchanged(tmp_path, monkeypatch, capsys):
    result = _valid_result("analyze")
    calls = []

    def compare(*args, **kwargs):
        calls.append(kwargs)
        return result

    _replace(monkeypatch, "analyze", compare)
    assert cli.main(_args("analyze", tmp_path)) == 0
    assert "engine" not in calls[0]
    assert json.loads(capsys.readouterr().out) == result


@pytest.mark.parametrize("metadata_field", ["reference", "processed"])
def test_comparison_private_metadata_payload_is_not_echoed_or_saved(metadata_field, tmp_path, monkeypatch, capsys):
    result = deepcopy(_valid_result("compare"))
    result[metadata_field] = {"message": "C:/private/customer.wav"}
    _replace(monkeypatch, "compare", lambda *args, **kwargs: result)
    assert cli.main(_args("compare", tmp_path, output=True)) == 3
    captured = capsys.readouterr()
    assert json.loads(captured.out)["reason_code"] == "missing_result_field"
    assert "private" not in captured.out and "customer.wav" not in captured.out
    assert not (tmp_path / "result.json").exists()


@pytest.mark.parametrize("metadata_field", ["reference", "processed"])
@pytest.mark.parametrize("name,value", [("encoding", "float64"), ("sha256", "C:/private/customer.wav"),
                                        ("sample_count", True), ("channels", 2)])
def test_comparison_metadata_uses_strict_existing_contract(metadata_field, name, value, tmp_path,
                                                         monkeypatch, capsys):
    result = deepcopy(_valid_result("compare"))
    result[metadata_field][name] = value
    _replace(monkeypatch, "compare", lambda *args, **kwargs: result)
    assert cli.main(_args("compare", tmp_path, output=True)) == 3
    captured = capsys.readouterr()
    assert json.loads(captured.out)["reason_code"] == "invalid_audio_metadata"
    assert "private" not in captured.out and "customer.wav" not in captured.out
    assert not (tmp_path / "result.json").exists()
