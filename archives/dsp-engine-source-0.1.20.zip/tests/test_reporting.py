import copy
from html.parser import HTMLParser

import pytest

from audio_regression.reporting import render_html, write_html_report
from audio_regression.result_contract import ResultContractError


def sample_result(kind="clean", profile="basic"):
    """Stored-result fixtures only; these tests do not invoke the detector."""
    metadata = {
        "sample_rate_hz": 16000, "sample_count": 96000, "duration_ms": 6000.0,
        "channels": 1, "encoding": "pcm16", "rms": 0.05, "peak": 0.2,
        "sha256": "a" * 64,
    }
    events = []
    if kind == "delete":
        events = [{
            "type": "delete", "reference_interval_ms": [2000.0, 2400.0],
            "processed_boundary_ms": 2000.0,
            "evidence": {"boundary_correlation": 0.99, "offset_before_ms": 0.0,
                         "offset_after_ms": -400.0},
        }]
    if kind == "repeat":
        events = [{
            "type": "repeat", "reference_source_interval_ms": [2000.0, 2400.0],
            "processed_added_interval_ms": [2400.0, 2800.0],
            "copy_interval_convention": "canonical_later_adjacent_copy_not_edit_provenance",
            "evidence": {"boundary_correlation": 0.99, "offset_before_ms": 0.0,
                         "offset_after_ms": 400.0, "copy_correlation": 0.99,
                         "adjacent_copy_correlation": 0.99},
        }]
    processed = copy.deepcopy(metadata)
    processed["sha256"] = "b" * 64
    if kind in {"delete", "repeat"}:
        processed["duration_ms"] += -400.0 if kind == "delete" else 400.0
        processed["sample_count"] = int(processed["duration_ms"] * 16)
    return {
        "schema_version": 1, "engine": "local_content_alignment_v1", "status": "analyzed",
        "content_preservation_status": "defect_candidates" if events else "no_supported_defect_candidates",
        "reason_code": None, "events": events, "complete_audio_approval": False,
        "commercial_performance_validated": False, "reference": metadata, "processed": processed,
        "configuration": {"profile": profile, "allow_gain": False,
                          "allow_resampling": False, "max_delay_ms": 1000.0},
        "analysis": {"sample_rate_hz": 8000, "hop_ms": 10.0,
                     "method": "constrained_edit_alignment_with_raw_anchors",
                     "minimum_event_duration_ms": 200,
                     "maximum_cumulative_edit_shift_ms": 2000,
                     "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {"normalized_path_cost": 0.01, "gain_estimate": 1.0,
                        "applied_gain": 1.0, "matched_normalized_rmse": 0.001,
                        "matched_analysis_samples": 40000, "anchor_run_count": 1,
                        "minimum_local_correlation": 0.99},
        "limitations": ["시간적 결함 후보 · 전체 음질은 평가 범위 밖"],
        "alignment_segments": [{"reference_interval_ms": [0.0, 2000.0],
                                "processed_offset_ms": 0.0, "anchor_correlations": [0.99, 0.99, 0.99]}],
    }


class Tags(HTMLParser):
    def __init__(self, html):
        super().__init__()
        self.elements = []
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        self.elements.append((tag, dict(attrs)))


def test_no_events_is_scoped_and_static_utf8():
    result = sample_result()
    html = render_html(result)
    assert "지원 범위의 시간적 결함 후보 없음" in html
    assert 'lang="ko"' in html and 'charset="utf-8"' in html
    assert "전체 음질" in html and "확률이 아닙니다" in html
    assert "PASS" not in html
    assert "default-src 'none'" in html
    forbidden = {"script", "iframe", "audio", "video", "img", "link"}
    assert not any(tag in forbidden for tag, _ in Tags(html).elements)
    assert render_html(result) == html


def test_dynamic_limitations_are_escaped_including_unicode():
    result = sample_result("repeat")
    payload = '<script>alert("가나다 & 한글")</script><svg onload="x">'
    result["limitations"] = [payload]
    html = render_html(result)
    assert "&lt;script&gt;" in html
    assert "가나다 &amp; 한글" in html
    assert payload not in html
    assert not any(tag == "script" for tag, _ in Tags(html).elements)
    assert not any(any(key.startswith("on") for key in attrs) for _, attrs in Tags(html).elements)


def test_untrusted_diagnostic_text_is_rejected_before_rendering():
    result = sample_result()
    result["diagnostics"]['<script>alert("한글")</script>'] = '<svg onload="x">'
    with pytest.raises(ResultContractError):
        render_html(result)


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_event_axes_use_separate_input_durations(kind):
    result = sample_result(kind)
    html = render_html(result)
    elements = Tags(html).elements
    axes = [attrs for tag, attrs in elements if tag == "svg"]
    assert axes[0]["data-axis"] == "reference"
    assert axes[0]["data-duration-ms"] == "6000.000"
    assert axes[1]["data-axis"] == "processed"
    assert axes[1]["data-duration-ms"] == ("5600.000" if kind == "delete" else "6400.000")
    if kind == "delete":
        assert "원본 삭제 후보 구간" in html and "처리본 대응 경계" in html
        boundary = next(attrs for tag, attrs in elements if tag == "line" and attrs.get("class") == "boundary")
        assert float(boundary["x1"]) == pytest.approx(48 + 840 * 2000 / 5600, abs=0.001)
        assert boundary["data-boundary-ms"] == "2000.000"
    else:
        assert "원본 복사 출처 구간" in html and "처리본 추가 반복 구간" in html
        marks = [attrs for tag, attrs in elements if tag == "rect" and "data-start-ms" in attrs]
        assert float(marks[0]["x"]) == pytest.approx(48 + 840 * 2000 / 6000, abs=0.001)
        assert float(marks[1]["x"]) == pytest.approx(48 + 840 * 2400 / 6400, abs=0.001)
        assert "실제 편집 위치나 원인을 확정하지 않습니다" in html


def test_withheld_and_error_report_never_describe_clear_result():
    result = sample_result()
    result.update(status="withheld", content_preservation_status="withheld",
                  reason_code="insufficient_unambiguous_anchors", events=None)
    result.pop("alignment_segments")
    html = render_html(result)
    assert "판단 보류" in html and "insufficient_unambiguous_anchors" in html
    assert "자동 판단 차단" in html
    assert "지원 범위의 시간적 결함 후보 없음" not in html
    error = {"schema_version": 1, "status": "error", "reason_code": "file_read_error"}
    html = render_html(error)
    assert "분석 오류 · 판단 불가" in html and "자동 판단 차단" in html
    assert "file_read_error" in html and "지원 범위의 시간적 결함 후보 없음" not in html


def test_telephone_warning_is_prominent_even_without_events():
    html = render_html(sample_result(profile="telephone"))
    assert '<aside class="notice">' in html
    assert "실험적 프로필" in html and "M3 고정 평가에서 목표를 충족하지 못했습니다" in html
    assert "telephone_profile_experimental_m3_target_miss" in html
    assert "전화 프로필 · 자동 판단 보류" in html


@pytest.mark.parametrize("mutation", [
    lambda r: r.update(schema_version=2),
    lambda r: r.update(engine="global_alignment_baseline_v1"),
    lambda r: r["events"][0].update(processed_boundary_ms=99999),
    lambda r: r.update(complete_audio_approval=True),
])
def test_unknown_and_invalid_results_are_rejected(mutation):
    result = sample_result("delete")
    mutation(result)
    with pytest.raises(ResultContractError):
        render_html(result)


def test_write_is_exclusive_and_omits_audio_and_absolute_paths(tmp_path):
    result = sample_result()
    result["limitations"].append(r"개인 파일 C:\private\recording.wav 또는 /home/private/voice.wav 또는 /opt/private/file.wav")
    output = tmp_path / "리포트.html"
    write_html_report(result, output)
    data = output.read_bytes()
    html = data.decode("utf-8")
    assert "리포트" not in html  # output paths are never embedded either
    assert "C:\\private" not in html and "/home/private" not in html
    assert "/opt/private" not in html
    assert "[로컬 경로 생략]" in html
    with pytest.raises(FileExistsError):
        write_html_report(sample_result("delete"), output)
    assert output.read_bytes() == data


def test_invalid_result_cannot_leave_a_report_file(tmp_path):
    output = tmp_path / "invalid.html"
    with pytest.raises(ResultContractError):
        write_html_report({"schema_version": 7, "status": "analyzed"}, output)
    assert not output.exists()
