"""Local browser transport tests, not evidence of natural-audio accuracy."""

import base64
from concurrent.futures import ThreadPoolExecutor
from http.client import HTTPConnection
import json
from pathlib import Path
import socket
import struct
import threading

import pytest

from audio_regression import __version__
from audio_regression import workbench as wb
from audio_regression.fixtures import generate_case


@pytest.fixture(scope="module")
def wav_bytes():
    # A fresh, owned synthetic fixture; never old evaluation or user audio.
    return generate_case(seed=202610155879, duration_seconds=3).reference_wav


@pytest.fixture
def server(tmp_path):
    work = tmp_path / "work"
    work.mkdir()
    local = wb.create_server(work_dir=work)
    thread = threading.Thread(target=local.serve_forever, kwargs={"poll_interval": 0.01}, daemon=True)
    thread.start()
    try:
        yield local
    finally:
        local.shutdown()
        thread.join(timeout=5)
        local.server_close()
        assert not list(work.iterdir()), "Uploaded audio must not survive a completed request"


def request(server, method, path, *, body=None, headers=None, send_body=True, half_close=False):
    connection = HTTPConnection("127.0.0.1", server.server_port, timeout=30)
    connection.putrequest(method, path, skip_host=True, skip_accept_encoding=True)
    provided = headers or [("Host", f"127.0.0.1:{server.server_port}")]
    for key, value in provided:
        connection.putheader(key, value)
    connection.endheaders()
    if body is not None and send_body:
        connection.send(body)
    if half_close:
        connection.sock.shutdown(socket.SHUT_WR)
    response = connection.getresponse()
    content = response.read()
    result = (response.status, dict(response.getheaders()), content)
    connection.close()
    return result


def post_headers(server, length, *, origin=None, token=None, content_type="application/json"):
    return [("Host", f"127.0.0.1:{server.server_port}"),
            ("Origin", origin if origin is not None else server.origin),
            ("X-DSP-Token", token if token is not None else server.session_token),
            ("Content-Type", content_type), ("Content-Length", str(length))]


def post(server, value, *, extra_headers=None):
    body = value if isinstance(value, bytes) else json.dumps(value).encode("utf-8")
    return request(server, "POST", "/api/analyze", body=body,
                   headers=post_headers(server, len(body)) + (extra_headers or []))


def payload(wav_bytes, *, engine="v1"):
    encoded = base64.b64encode(wav_bytes).decode("ascii")
    return {"reference": {"name": "원본.wav", "base64": encoded},
            "processed": {"name": "처리본.wav", "base64": encoded},
            "allow_gain": False, "allow_resampling": False, "engine": engine}


def error_body(response, status, code):
    actual_status, headers, body = response
    assert actual_status == status
    result = json.loads(body)
    assert set(result) == {"schema_version", "status", "code", "message"}
    assert result["schema_version"] == 1 and result["status"] == "error"
    assert result["code"] == code
    assert result["message"] and "Access-Control-Allow-Origin" not in headers
    return result


def test_loopback_session_and_security_headers(server):
    assert server.server_address[0] == "127.0.0.1"
    assert 0 < server.server_port <= 65535
    status, headers, body = request(server, "GET", "/api/session")
    session = json.loads(body)
    assert status == 200
    assert session == {"schema_version": 1, "token": server.session_token, "version": __version__,
                       "limits": {"max_file_bytes": 10_000_000, "min_seconds": 2,
                                  "max_seconds": 30, "sample_rates": [8000, 16000, 44100, 48000]},
                       "local_only": True}
    assert len(session["token"]) >= 40
    assert headers["Cache-Control"] == "no-store"
    assert headers["X-Content-Type-Options"] == "nosniff"
    assert headers["Referrer-Policy"] == "no-referrer"
    assert headers["X-Frame-Options"] == "DENY"
    assert "script-src 'self'" in headers["Content-Security-Policy"]
    assert "'unsafe-inline'" not in headers["Content-Security-Policy"]
    assert "sha256-" in headers["Content-Security-Policy"]
    assert "Access-Control-Allow-Origin" not in headers


def test_tokens_are_unique_and_owned_temp_root_cleans_up(tmp_path, monkeypatch):
    monkeypatch.setattr(wb.tempfile, "tempdir", str(tmp_path))
    first, second = wb.create_server(), wb.create_server()
    roots = (first.work_dir, second.work_dir)
    try:
        assert first.session_token != second.session_token
        assert all(path.is_dir() for path in roots)
    finally:
        first.server_close()
        second.server_close()
    assert all(not path.exists() for path in roots)


@pytest.mark.parametrize("port", [-1, 65536, True, "8765", None])
def test_invalid_port_cannot_bind(port):
    with pytest.raises(ValueError):
        wb.create_server(port=port)


def test_work_directory_must_exist_and_be_a_directory(tmp_path):
    with pytest.raises(OSError):
        wb.create_server(work_dir=tmp_path / "missing")
    ordinary_file = tmp_path / "file"
    ordinary_file.write_bytes(b"keep")
    with pytest.raises(ValueError):
        wb.create_server(work_dir=ordinary_file)
    assert ordinary_file.read_bytes() == b"keep"


@pytest.mark.parametrize("host", ["localhost", "evil.example", "127.0.0.1", "0.0.0.0:8765", "127.0.0.1:1"])
def test_wrong_host_denied(server, host):
    error_body(request(server, "GET", "/api/session", headers=[("Host", host)]), 403, "invalid_host")


def test_duplicate_host_denied(server):
    headers = [("Host", f"127.0.0.1:{server.server_port}")] * 2
    error_body(request(server, "GET", "/api/session", headers=headers), 403, "invalid_host")


@pytest.mark.parametrize("path", ["/../api/session", "/%2e%2e/app.js", "/app.js?x=1", "/favicon.ico", "/audio.wav", "/api/session/", "/workbench.py"])
def test_static_allowlist_and_no_audio_endpoints(server, path):
    error_body(request(server, "GET", path), 404, "not_found")


@pytest.mark.parametrize("path,name,content_type", [("/", "index.html", "text/html"),
                                                   ("/app.js", "app.js", "text/javascript"),
                                                   ("/app.css", "app.css", "text/css")])
def test_fixed_static_assets(server, tmp_path, monkeypatch, path, name, content_type):
    asset_dir = tmp_path / "assets" / "workbench_assets"
    asset_dir.mkdir(parents=True)
    (asset_dir / name).write_bytes(b"safe asset")
    monkeypatch.setattr(wb.resources, "files", lambda package: asset_dir.parent)
    status, headers, body = request(server, "GET", path)
    assert status == 200 and body == b"safe asset"
    assert headers["Content-Type"].startswith(content_type)


def test_missing_asset_is_friendly(server, tmp_path, monkeypatch):
    monkeypatch.setattr(wb.resources, "files", lambda package: tmp_path / "missing")
    error_body(request(server, "GET", "/"), 503, "assets_unavailable")


@pytest.mark.parametrize("origin", ["null", "https://evil.example", "http://localhost", "http://127.0.0.1:1", ""])
def test_cross_origin_denied_before_read(server, origin):
    headers = post_headers(server, 10000, origin=origin)
    error_body(request(server, "POST", "/api/analyze", headers=headers), 403, "invalid_origin")


def test_missing_or_duplicate_origin_denied(server):
    headers = [item for item in post_headers(server, 10000) if item[0] != "Origin"]
    error_body(request(server, "POST", "/api/analyze", headers=headers), 403, "invalid_origin")
    headers.append(("Origin", server.origin))
    headers.append(("Origin", server.origin))
    error_body(request(server, "POST", "/api/analyze", headers=headers), 403, "invalid_origin")


@pytest.mark.parametrize("token", ["", "expired", "é"])
def test_session_token_denied_before_read(server, token):
    error_body(request(server, "POST", "/api/analyze", headers=post_headers(server, 10000, token=token)),
               403, "invalid_session")


def test_duplicate_token_is_not_accepted(server):
    headers = post_headers(server, 10000) + [("X-DSP-Token", server.session_token)]
    error_body(request(server, "POST", "/api/analyze", headers=headers), 403, "invalid_session")


def test_cors_preflight_rejected(server):
    error_body(request(server, "OPTIONS", "/api/analyze"), 403, "cross_origin_disabled")


@pytest.mark.parametrize("method", ["HEAD", "PUT", "PATCH", "DELETE", "TRACE"])
def test_other_methods_rejected(server, method):
    status, headers, body = request(server, method, "/api/analyze")
    assert status == 405
    if method == "HEAD":
        assert body == b""
    else:
        assert json.loads(body)["code"] == "method_not_allowed"
    assert "Access-Control-Allow-Origin" not in headers


def test_oversized_body_rejected_without_read(server):
    error_body(request(server, "POST", "/api/analyze", headers=post_headers(server, wb.MAX_REQUEST_BYTES + 1)),
               413, "request_too_large")


@pytest.mark.parametrize("length,status,code", [("-1", 411, "content_length_required"),
                                              ("x", 411, "content_length_required"),
                                              ("0", 400, "invalid_request"),
                                              ("99999999999", 413, "request_too_large")])
def test_invalid_content_length(server, length, status, code):
    error_body(request(server, "POST", "/api/analyze", headers=post_headers(server, length)), status, code)


def test_duplicate_content_length_and_transfer_encoding_denied(server):
    headers = post_headers(server, 100) + [("Content-Length", "100")]
    error_body(request(server, "POST", "/api/analyze", headers=headers), 411, "content_length_required")
    headers = post_headers(server, 100) + [("Transfer-Encoding", "chunked")]
    error_body(request(server, "POST", "/api/analyze", headers=headers), 400, "invalid_request")


def test_missing_content_length_denied(server):
    headers = [item for item in post_headers(server, 10) if item[0] != "Content-Length"]
    error_body(request(server, "POST", "/api/analyze", headers=headers), 411, "content_length_required")


@pytest.mark.parametrize("content_type", ["text/plain", "application/octet-stream", "application/json;charset=latin1"])
def test_non_json_denied_before_read(server, content_type):
    error_body(request(server, "POST", "/api/analyze", headers=post_headers(server, 1000, content_type=content_type)),
               415, "unsupported_media_type")


@pytest.mark.parametrize("raw", [b"{", b"\xff", b'{"x":NaN}', b'{"x":Infinity}', b'{"x":1,"x":2}', b"[" * 1100])
def test_invalid_json_rejected(server, raw):
    error_body(post(server, raw), 400, "invalid_json")


@pytest.mark.parametrize("change", ["extra", "missing", "bool", "engine"])
def test_strict_request_contract(server, wav_bytes, change):
    value = payload(wav_bytes)
    if change == "extra":
        value["threshold"] = 0.1
    elif change == "missing":
        del value["allow_gain"]
    elif change == "bool":
        value["allow_gain"] = 1
    else:
        value["engine"] = "v2"
    error_body(post(server, value), 400, "invalid_engine" if change == "engine" else "invalid_request")


@pytest.mark.parametrize("reference,code", [({}, "invalid_file"),
                                         ({"name": "x.wav", "base64": "!"}, "invalid_file_encoding"),
                                         ({"name": "x.wav", "base64": "é"}, "invalid_file_encoding"),
                                         ({"name": "x.wav", "base64": ""}, "invalid_file"),
                                         ({"name": "x.wav", "base64": "YWJj"}, "invalid_wav"),
                                         ({"name": "", "base64": "YWJj"}, "invalid_file"),
                                         ({"name": "x\u0000.wav", "base64": "YWJj"}, "invalid_file")])
def test_file_payload_rejections(server, wav_bytes, reference, code):
    value = payload(wav_bytes)
    value["reference"] = reference
    error_body(post(server, value), 400, code)


def test_file_bytes_limit(server, wav_bytes):
    value = payload(wav_bytes)
    value["reference"]["base64"] = base64.b64encode(b"x" * (wb.MAX_FILE_BYTES + 1)).decode("ascii")
    error_body(post(server, value), 413, "file_too_large")


@pytest.mark.parametrize("field,offset,value,code", [("channels", 22, 2, "unsupported_channels"),
                                                   ("bits", 34, 24, "unsupported_encoding"),
                                                   ("rate", 24, 22050, "unsupported_sample_rate")])
def test_strict_wav_messages(server, wav_bytes, field, offset, value, code):
    data = bytearray(wav_bytes)
    struct.pack_into("<I" if field == "rate" else "<H", data, offset, value)
    request_value = payload(wav_bytes)
    request_value["processed"]["base64"] = base64.b64encode(data).decode("ascii")
    response = error_body(post(server, request_value), 400, code)
    assert response["message"].startswith("처리본:")


def test_read_timeout_releases_slot(server, monkeypatch):
    monkeypatch.setattr(wb, "READ_TIMEOUT_SECONDS", 0.1)
    error_body(request(server, "POST", "/api/analyze", headers=post_headers(server, 1000)),
               408, "request_timeout")
    assert server.analysis_lock.acquire(blocking=False)
    server.analysis_lock.release()


def test_incomplete_body_rejected(server):
    error_body(request(server, "POST", "/api/analyze", body=b"{}", headers=post_headers(server, 100), half_close=True),
               400, "incomplete_request")


def test_single_concurrent_analysis_denied_before_body(server, wav_bytes, monkeypatch):
    entered, release = threading.Event(), threading.Event()
    def analyzer(*args, **kwargs):
        entered.set()
        assert release.wait(10)
        return {"schema_version": 1, "status": "error", "reason_code": "test_error"}
    monkeypatch.setattr(wb, "analyze_pair", analyzer)
    with ThreadPoolExecutor(max_workers=1) as executor:
        future = executor.submit(post, server, payload(wav_bytes))
        try:
            assert entered.wait(5)
            error_body(request(server, "POST", "/api/analyze", headers=post_headers(server, 100000)),
                       429, "analysis_busy")
        finally:
            release.set()
        status, _, body = future.result(timeout=10)
        assert status == 200 and json.loads(body)["check"]["exit_code"] == 2


def test_fixed_request_paths_options_and_cleanup(server, wav_bytes, monkeypatch, capsys):
    seen = []
    def analyzer(reference, processed, **kwargs):
        assert reference.name == "reference.wav" and processed.name == "processed.wav"
        assert reference.parent == processed.parent and reference.parent.parent == server.work_dir
        assert reference.read_bytes() == processed.read_bytes() == wav_bytes
        assert kwargs == {"allow_gain": True, "allow_resampling": True, "engine": "v9"}
        seen.append(reference.parent)
        return {"schema_version": 1, "status": "error", "reason_code": "test_error"}
    monkeypatch.setattr(wb, "analyze_pair", analyzer)
    value = payload(wav_bytes, engine="v9")
    value["reference"]["name"] = "../../private-name.wav"
    value["processed"]["name"] = "C:\\private\\private-name.wav"
    value["allow_gain"] = value["allow_resampling"] = True
    status, _, body = post(server, value)
    assert status == 200
    result = json.loads(body)
    assert result["status"] == "completed" and result["check"]["exit_code"] == 2
    assert "분석 오류" in result["report_html"]
    assert all(not path.exists() for path in seen)
    assert "private-name" not in body.decode("utf-8")
    assert str(server.work_dir) not in body.decode("utf-8")
    assert capsys.readouterr().out == capsys.readouterr().err == ""


@pytest.mark.parametrize("outcome", ["exception", "bad_result"])
def test_analysis_failure_is_not_pass_and_cleanup_runs(server, wav_bytes, monkeypatch, outcome, capsys):
    paths = []
    def analyzer(reference, processed, **kwargs):
        paths.append(reference.parent)
        if outcome == "exception":
            raise RuntimeError("C:/private/secret.wav highly private audio")
        return {"status": "analyzed", "events": []}
    monkeypatch.setattr(wb, "analyze_pair", analyzer)
    result = error_body(post(server, payload(wav_bytes)), 500, "analysis_failed")
    assert "private" not in json.dumps(result)
    assert all(not path.exists() for path in paths)
    assert server.analysis_lock.acquire(blocking=False)
    server.analysis_lock.release()
    assert capsys.readouterr().out == capsys.readouterr().err == ""


def test_real_existing_engine_on_fresh_owned_pair(server, wav_bytes):
    status, _, body = post(server, payload(wav_bytes))
    result = json.loads(body)
    assert status == 200 and result["status"] == "completed"
    assert result["result"]["engine"] == "local_content_alignment_v1"
    assert result["result"]["status"] == "analyzed"
    assert result["check"]["exit_code"] == 0
    assert result["check"]["complete_audio_approval"] is False
    assert result["check"]["commercial_performance_validated"] is False
    assert "전체 음질" in result["report_html"]


def test_main_failure_is_friendly(monkeypatch, capsys):
    def unavailable(**kwargs):
        raise OSError("C:/private/path")
    monkeypatch.setattr(wb, "create_server", unavailable)
    assert wb.main(["--no-browser"]) == 2
    printed = capsys.readouterr().out
    assert "시작할 수 없습니다" in printed and "private" not in printed


def test_main_no_browser_prints_loopback_and_closes(monkeypatch, capsys):
    state = []
    class FakeServer:
        origin = "http://127.0.0.1:12345"
        def serve_forever(self, **kwargs):
            state.append("served")
            raise KeyboardInterrupt
        def server_close(self):
            state.append("closed")
    monkeypatch.setattr(wb, "create_server", lambda **kwargs: FakeServer())
    monkeypatch.setattr(wb.webbrowser, "open", lambda *args: pytest.fail("must not open browser"))
    assert wb.main(["--no-browser"]) == 0
    assert state == ["served", "closed"]
    assert "http://127.0.0.1:12345/" in capsys.readouterr().out
