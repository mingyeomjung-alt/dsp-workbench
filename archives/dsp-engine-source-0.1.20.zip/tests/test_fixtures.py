from dataclasses import FrozenInstanceError
import hashlib
import io
import json
import math
import wave

import numpy as np
import pytest

from audio_regression.fixtures import generate_case


def pcm(wav_bytes):
    with wave.open(io.BytesIO(wav_bytes), "rb") as stream:
        assert stream.getnchannels() == 1
        assert stream.getsampwidth() == 2
        return np.frombuffer(stream.readframes(stream.getnframes()), dtype="<i2"), stream.getframerate()


def expected_gain(pcm_samples, factor):
    return np.rint(pcm_samples.astype(np.float64) * factor).astype(np.int16)


@pytest.mark.parametrize("kind", ["clean", "delete", "repeat"])
@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
def test_maps_cover_processed_and_reconstruct_exact_pcm(kind, rate):
    case = generate_case(kind, sample_rate_hz=rate, delay_ms=75.25, gain_db=-3.0)
    ref, ref_rate = pcm(case.reference_wav)
    output, output_rate = pcm(case.processed_wav)
    truth = case.ground_truth
    assert ref_rate == output_rate == rate
    assert len(ref) == truth["reference_sample_count"]
    assert len(output) == truth["processed_sample_count"]
    assert truth["source_kind"] == "synthetic_test_signal"
    assert truth["reference_sha256"] == hashlib.sha256(case.reference_wav).hexdigest()
    assert truth["processed_sha256"] == hashlib.sha256(case.processed_wav).hexdigest()
    assert json.loads(json.dumps(truth)) == truth
    covered = np.zeros(len(output), dtype=np.int8)
    source_covered = np.zeros(len(ref), dtype=np.int8)
    for segment in truth["correspondence_segments"]:
        a, b = segment["processed_start_sample"], segment["processed_end_sample"]
        covered[a:b] += 1
        assert segment["processed_start_ms"] == a * 1000 / rate
        assert segment["processed_end_ms"] == b * 1000 / rate
        if segment["kind"] == "generated_silence":
            assert segment["reference_start_sample"] is None
            assert segment["reference_end_sample"] is None
            assert np.all(output[a:b] == 0)
            continue
        c, d = segment["reference_start_sample"], segment["reference_end_sample"]
        assert segment["reference_start_ms"] == c * 1000 / rate
        assert segment["reference_end_ms"] == d * 1000 / rate
        if segment["kind"] == "deleted":
            assert a == b
        else:
            assert b - a == d - c
            np.testing.assert_array_equal(output[a:b], expected_gain(ref[c:d], truth["gain_linear"]))
        if segment["kind"] != "repetition_copy":
            source_covered[c:d] += 1
    assert np.all(covered == 1)
    assert np.all(source_covered == 1)


def test_delete_has_source_gap_and_zero_length_target_boundary():
    truth = generate_case("delete", delay_ms=100).ground_truth
    assert truth["events"] == [{
        "type": "delete",
        "reference_interval_samples": [32000, 38400],
        "reference_interval_ms": [2000.0, 2400.0],
        "processed_boundary_sample": 33600,
        "processed_boundary_ms": 2100.0,
    }]
    assert truth["processed_sample_count"] == 91200


def test_repeat_identifies_added_copy_after_original_source_interval():
    case = generate_case("repeat", delay_ms=100)
    ref, _ = pcm(case.reference_wav)
    output, _ = pcm(case.processed_wav)
    event = case.ground_truth["events"][0]
    assert event["processed_added_interval_samples"] == [40000, 46400]
    assert event["reference_source_interval_samples"] == [32000, 38400]
    np.testing.assert_array_equal(output[33600:40000], ref[32000:38400])
    np.testing.assert_array_equal(output[40000:46400], ref[32000:38400])


def test_clean_pair_bit_identical_and_frozen_container():
    case = generate_case()
    assert case.reference_wav == case.processed_wav
    assert case.ground_truth["events"] == []
    assert case.ground_truth["edit_interval_samples"] is None
    with pytest.raises(FrozenInstanceError):
        case.processed_wav = b"changed"


def test_seed_reproducibility_and_nonperiodic_signal():
    a = generate_case(seed=11)
    b = generate_case(seed=11)
    c = generate_case(seed=12)
    assert a == b
    assert a.reference_wav != c.reference_wav
    samples, rate = pcm(a.reference_wav)
    assert np.count_nonzero(samples) / len(samples) > 0.99
    assert not np.array_equal(samples[:rate], samples[rate:2 * rate])
    assert max(abs(samples.astype(np.int32))) < 32767


def test_rounding_is_sample_exact_not_requested_milliseconds():
    truth = generate_case("repeat", sample_rate_hz=8000,
                          duration_seconds=6.0000625, delay_ms=0.1875,
                          interval_start_ms=2000.1875, interval_duration_ms=400.1875).ground_truth
    assert truth["reference_sample_count"] == round(6.0000625 * 8000)
    assert truth["delay_samples"] == round(0.1875 * 8)
    assert truth["delay_ms"] == truth["delay_samples"] / 8
    start, end = truth["edit_interval_samples"]
    assert start == round(2000.1875 * 8)
    assert end - start == round(400.1875 * 8)
    assert truth["requested"]["delay_ms"] != truth["delay_ms"]


@pytest.mark.parametrize("kwargs", [
    {"kind": "dropout"}, {"kind": None},
    {"seed": True}, {"seed": 1.0}, {"seed": -1}, {"seed": 2**64},
    {"sample_rate_hz": True}, {"sample_rate_hz": 16000.0}, {"sample_rate_hz": 11025},
    {"duration_seconds": 1.99}, {"duration_seconds": 30.01},
    {"duration_seconds": math.nan}, {"duration_seconds": math.inf}, {"duration_seconds": True},
    {"duration_seconds": 10**1000},
    {"delay_ms": -1}, {"delay_ms": math.nan}, {"delay_ms": 28001},
    {"gain_db": math.inf}, {"gain_db": "3"}, {"gain_db": 61},
    {"gain_db": 60},  # valid numeric bound, but would clip this source
    {"interval_start_ms": math.nan}, {"interval_duration_ms": -1},
    {"kind": "delete", "interval_duration_ms": 199},
    {"kind": "delete", "interval_start_ms": 0},
    {"kind": "repeat", "interval_start_ms": 5600},
    {"kind": "delete", "duration_seconds": 2.0, "interval_start_ms": 500},
    {"kind": "repeat", "duration_seconds": 30.0},
    {"duration_seconds": 30.0, "delay_ms": 1},
])
def test_invalid_fields_or_unsupported_geometry_rejected(kwargs):
    with pytest.raises(ValueError):
        generate_case(**kwargs)


@pytest.mark.parametrize("duration", [2.0, 30.0])
def test_clean_duration_boundaries(duration):
    case = generate_case(duration_seconds=duration, sample_rate_hz=8000)
    assert case.ground_truth["reference_sample_count"] == duration * 8000


def test_low_gain_not_silently_normalized():
    normal, _ = pcm(generate_case().processed_wav)
    quiet_case = generate_case(gain_db=-60)
    quiet, _ = pcm(quiet_case.processed_wav)
    np.testing.assert_array_equal(quiet, expected_gain(normal, 0.001))
    assert 0 < np.max(np.abs(quiet)) < 10


def test_clean_validates_but_does_not_use_edit_interval():
    case = generate_case(duration_seconds=2.0, interval_start_ms=30000.0, interval_duration_ms=0)
    assert case.reference_wav == case.processed_wav
    assert case.ground_truth["edit_interval_samples"] is None
