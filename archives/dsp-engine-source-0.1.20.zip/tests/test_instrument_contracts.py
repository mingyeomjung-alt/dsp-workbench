"""V4 stored-result contract regressions using fresh synthetic/fake data only."""

from copy import deepcopy
from functools import lru_cache
import json
from pathlib import Path

import pytest

from audio_regression.audio import decode_wav
from audio_regression.check_policy import check_result
from audio_regression.engine import analyze_buffers
from audio_regression.fixtures import generate_case
from audio_regression.instrument_result_contract import (
    ENGINE, METHOD, validate_instrument_analysis_result,
)
from audio_regression.reporting import render_html
from audio_regression.result_contract import ResultContractError, validate_analysis_result


@lru_cache(maxsize=3)
def _original(kind):
    case = generate_case(kind, seed=313017)
    return analyze_buffers(decode_wav(case.reference_wav), decode_wav(case.processed_wav))


def _pair(kind="clean", withheld=False):
    result = deepcopy(_original(kind))
    assert result["status"] == "analyzed"
    result["engine"], result["analysis"]["method"] = ENGINE, METHOD
    if withheld:
        result.update(status="withheld", content_preservation_status="withheld",
                      reason_code="raw_landmarks_not_unique", events=None, diagnostics={})
        result.pop("alignment_segments")
    return result


@pytest.mark.parametrize("kind", ["clean", "delete", "repeat"])
def test_v4_reuses_strict_geometry_without_mutating_the_original(kind):
    result = _pair(kind)
    before = deepcopy(result)
    assert validate_instrument_analysis_result(result) is result
    assert validate_analysis_result(result) is result
    assert result == before
    assert check_result(result)["exit_code"] == (0 if kind == "clean" else 1)


def test_withheld_and_minimal_error_stay_blocked():
    for result in (_pair(withheld=True),
                   {"schema_version": 1, "engine": ENGINE,
                    "status": "error", "reason_code": "analysis_execution_error"}):
        assert validate_analysis_result(result) is result
        assert check_result(result)["exit_code"] == 2


@pytest.mark.parametrize("path,value,code", [
    (("engine",), "local_content_alignment_v3", "unsupported_engine"),
    (("analysis", "method"), "constrained_edit_alignment_with_raw_anchors", "invalid_analysis_method"),
    (("configuration", "profile"), "telephone", "unsupported_profile"),
    (("complete_audio_approval",), True, "invalid_approval_claim"),
    (("commercial_performance_validated",), True, "invalid_approval_claim"),
    (("diagnostics", "matched_normalized_rmse"), .081, "inconsistent_analyzed_metrics"),
    (("diagnostics", "minimum_local_correlation"), .89, "inconsistent_analyzed_metrics"),
    (("diagnostics", "anchor_run_count"), 2, "inconsistent_anchor_count"),
    (("diagnostics", "matched_analysis_samples"), 100, "inconsistent_matched_sample_count"),
    (("reference", "duration_ms"), 7000, "inconsistent_audio_duration"),
])
def test_v4_does_not_relax_shared_evidence_guards(path, value, code):
    result = _pair()
    target = result
    for key in path[:-1]:
        target = target[key]
    target[path[-1]] = value
    with pytest.raises(ResultContractError) as caught:
        validate_instrument_analysis_result(result)
    assert caught.value.code == code


@pytest.mark.parametrize("field", ["trace", "trace_path", "probability", "raw_audio"])
def test_sidecars_or_new_claims_cannot_enter_the_analysis_result(field):
    result = _pair()
    result[field] = "unsupported extra field"
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(result)
    assert caught.value.code == "unexpected_result_field"
    assert check_result(result)["exit_code"] == 2


def test_tree_is_bounded_before_copy_and_nonfinite_is_rejected():
    result = _pair()
    result["cycle"] = result
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(result)
    assert caught.value.code == "result_structure_too_large"
    result = _pair()
    result["diagnostics"]["matched_normalized_rmse"] = float("nan")
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(result)
    assert caught.value.code == "non_finite_metric"


def test_v4_pair_report_labels_research_and_reads_no_sidecar():
    html = render_html(_pair())
    assert ENGINE in html and "v4 · 선택한 개선 후보" in html
    assert "원시 파형 랜드마크·전역 유일성" in html
    assert "선택형 연구 엔진" in html
    assert "일반 정확도나 상용 성능을 보장하지 않습니다" in html
    assert "존재를 확인하지 않습니다" in html
    assert "<script" not in html and "<a " not in html


def test_v4_schema_has_distinct_identity_and_unchanged_shared_geometry():
    schemas = Path(__file__).resolve().parents[1] / "src" / "audio_regression" / "schemas"
    old = json.loads((schemas / "analysis-result-v1.schema.json").read_text(encoding="utf-8"))
    new = json.loads((schemas / "analysis-result-v4.schema.json").read_text(encoding="utf-8"))
    assert new["$id"] == "urn:audio-regression:analysis-result:v4"
    assert new["$defs"]["analysis"]["properties"]["method"]["const"] == METHOD
    assert new["$defs"]["configuration"]["properties"]["profile"] == {"type": "string", "const": "basic"}
    for name in ("metadata", "analyzedDiagnostics", "withheldDiagnostics", "deleteEvent",
                 "repeatEvent", "event", "alignmentSegment"):
        assert new["$defs"][name] == old["$defs"][name]
    for name in ("analyzed", "withheld", "cliError"):
        assert new["$defs"][name]["properties"]["engine"]["const"] == ENGINE
