"""Invented endpoint certificates; no historical audio or accuracy evaluation."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path

import pytest

from audio_regression.edge_event_result_contract import ENGINE, METHOD, validate_edge_event_analysis_result
from audio_regression.result_contract import ResultContractError, validate_analysis_result
from audio_regression.short_event_result_contract import METHOD as INHERITED_METHOD


_SCHEMAS = Path(__file__).resolve().parents[1] / "src" / "audio_regression" / "schemas"


def _metadata(rate, count, digest):
    return {"sample_rate_hz": rate, "sample_count": count, "duration_ms": count * 1000 / rate,
            "channels": 1, "encoding": "pcm16", "rms": .1, "peak": .5, "sha256": digest * 64}


def _native(location="head", rate=16000, length=100):
    removed = round(length * rate / 1000)
    reference = _metadata(rate, 6 * rate, "a")
    processed = _metadata(rate, 6 * rate - removed, "b")
    length = removed * 1000 / rate
    head = location == "head"
    offset = -length if head else 0
    return {
        "schema_version": 1, "engine": ENGINE, "status": "analyzed",
        "content_preservation_status": "defect_candidates", "reason_code": None,
        "events": [{"type": "delete", "location": location,
                    "reference_interval_ms": [0, length] if head else [processed["duration_ms"], 6000],
                    "processed_boundary_ms": 0 if head else processed["duration_ms"],
                    "evidence": {"retained_offset_ms": offset, "retained_context_correlation": 1,
                                 "removed_sample_count": removed,
                                 "retained_native_samples": processed["sample_count"],
                                 "all_retained_native_samples_exact": True}}],
        "complete_audio_approval": False, "commercial_performance_validated": False,
        "reference": reference, "processed": processed,
        "configuration": {"profile": "basic", "allow_gain": False, "allow_resampling": False,
                          "max_delay_ms": 1000},
        "analysis": {"sample_rate_hz": rate, "hop_ms": 1000 / rate, "method": METHOD,
                     "minimum_event_duration_ms": 50, "maximum_cumulative_edit_shift_ms": 2000,
                     "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {"normalized_path_cost": 0, "gain_estimate": 1, "applied_gain": 1,
                        "matched_normalized_rmse": 0, "minimum_local_correlation": 1,
                        "matched_analysis_samples": processed["sample_count"], "anchor_run_count": 1},
        "limitations": ["Diagnostic retained-side correspondence, not edit intent or complete audio approval."],
        "alignment_segments": [{"reference_interval_ms": [length, 6000] if head else [0, processed["duration_ms"]],
                                "processed_offset_ms": offset, "anchor_correlations": [1, 1, 1]}],
    }


def _inherited(native=True):
    value = _native()
    value["analysis"]["method"] = INHERITED_METHOD
    event = value["events"][0]
    event.pop("location")
    event.update(reference_interval_ms=[2000, 2100], processed_boundary_ms=2000,
                 evidence={"boundary_correlation": 1, "offset_before_ms": 0, "offset_after_ms": -100})
    value["alignment_segments"] = [
        {"reference_interval_ms": [0, 2000], "processed_offset_ms": 0, "anchor_correlations": [1, 1, 1]},
        {"reference_interval_ms": [2100, 6000], "processed_offset_ms": -100, "anchor_correlations": [1, 1, 1]},
    ]
    value["diagnostics"]["anchor_run_count"] = 2
    if not native:
        # An ordinary no-edit result on the original 8 kHz analysis grid.
        value["analysis"].update(sample_rate_hz=8000, hop_ms=10, minimum_event_duration_ms=200)
        value["processed"] = deepcopy(value["reference"])
        value.update(events=[], content_preservation_status="no_supported_defect_candidates")
        value["alignment_segments"] = [{"reference_interval_ms": [0, 6000],
            "processed_offset_ms": 0, "anchor_correlations": [1, 1, 1]}]
        value["diagnostics"].update(anchor_run_count=1, matched_analysis_samples=48000)
    return value


def _withheld(value):
    value.update(status="withheld", content_preservation_status="withheld", events=None,
                 diagnostics={}, reason_code="endpoint_loss_no_complete_single_deletion_explanation")
    value.pop("alignment_segments")
    return value


def _reject(value, code):
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(value)
    assert caught.value.code == code


@pytest.mark.parametrize("location", ["head", "tail"])
@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
@pytest.mark.parametrize("length", [50, 100, 200, 1000, 2000])
def test_one_sided_endpoint_result_is_strict_read_only_and_complete(location, rate, length):
    value = _native(location, rate, length)
    before = deepcopy(value)
    assert validate_analysis_result(value) is value
    assert validate_edge_event_analysis_result(value) is value
    assert value == before
    assert set(value["events"][0]["evidence"]) == {
        "retained_offset_ms", "retained_context_correlation", "removed_sample_count",
        "retained_native_samples", "all_retained_native_samples_exact",
    }


@pytest.mark.parametrize("native", [False, True])
def test_inherited_path_preserves_actual_v10_method_grid_and_event_restrictions(native):
    value = _inherited(native)
    before = deepcopy(value)
    assert validate_analysis_result(value) is value
    assert value == before
    value["analysis"]["method"] = METHOD
    _reject(value, "missing_result_field" if native else "invalid_analysis_method")


@pytest.mark.parametrize("path,replacement,code", [
    (("complete_audio_approval",), True, "invalid_approval_claim"),
    (("commercial_performance_validated",), True, "invalid_approval_claim"),
    (("configuration", "profile"), "telephone", "unsupported_profile"),
    (("configuration", "allow_gain"), True, "unsupported_endpoint_configuration"),
    (("configuration", "allow_resampling"), 0, "unsupported_endpoint_configuration"),
    (("analysis", "method"), "guessed_endpoint", "invalid_analysis_method"),
    (("analysis", "minimum_event_duration_ms"), 200, "invalid_analysis_method"),
    (("analysis", "sample_rate_hz"), 8000, "invalid_analysis_method"),
    (("analysis", "hop_ms"), 10, "invalid_analysis_method"),
    (("events", 0, "location"), "internal", "unsupported_endpoint_location"),
    (("events", 0, "type"), "repeat", "unsupported_event_type"),
    (("events", 0, "reference_interval_ms"), [1, 101], "inconsistent_endpoint_geometry"),
    (("events", 0, "processed_boundary_ms"), 1, "inconsistent_endpoint_geometry"),
    (("events", 0, "evidence", "retained_offset_ms"), 0, "inconsistent_endpoint_offset"),
    (("events", 0, "evidence", "retained_context_correlation"), .99, "inconsistent_endpoint_exact_evidence"),
    (("events", 0, "evidence", "removed_sample_count"), 1599, "inconsistent_endpoint_sample_counts"),
    (("events", 0, "evidence", "retained_native_samples"), 1, "inconsistent_endpoint_sample_counts"),
    (("events", 0, "evidence", "all_retained_native_samples_exact"), 1, "inconsistent_endpoint_sample_counts"),
    (("diagnostics", "anchor_run_count"), 2, "inconsistent_anchor_count"),
    (("diagnostics", "matched_analysis_samples"), 1, "inconsistent_matched_sample_count"),
    (("diagnostics", "matched_normalized_rmse"), .001, "inconsistent_endpoint_exact_metrics"),
    (("alignment_segments", 0, "reference_interval_ms"), [101, 6000], "inconsistent_endpoint_full_coverage"),
    (("alignment_segments", 0, "processed_offset_ms"), 0, "inconsistent_endpoint_full_coverage"),
    (("alignment_segments", 0, "anchor_correlations"), [1, .9, 1], "inconsistent_endpoint_exact_evidence"),
])
def test_endpoint_fabricated_metrics_partial_coverage_and_claims_rejected(path, replacement, code):
    value = _native()
    node = value
    for key in path[:-1]:
        node = node[key]
    node[path[-1]] = replacement
    _reject(value, code)


def test_endpoint_cannot_fabricate_missing_side_evidence_or_hide_multiple_events():
    for extra in ("offset_before_ms", "offset_after_ms", "boundary_correlation", "probability"):
        value = _native()
        value["events"][0]["evidence"][extra] = 0
        _reject(value, "unexpected_result_field")
    value = _native()
    value["events"] *= 2
    _reject(value, "inconsistent_result_status")
    value = _native()
    value["analysis"]["method"] = INHERITED_METHOD
    _reject(value, "inconsistent_anchor_count")


@pytest.mark.parametrize("length", [49, 2001])
def test_native_endpoint_floor_and_ceiling_cannot_be_bypassed(length):
    _reject(_native(length=length), "unsupported_endpoint_configuration")


def test_native_endpoint_requires_native_grid_same_rate_and_duration_delta():
    value = _native()
    value["processed"]["sample_count"] += 1
    value["processed"]["duration_ms"] += 1000 / 16000
    _reject(value, "inconsistent_endpoint_geometry")
    value = _native()
    value["events"][0]["reference_interval_ms"][1] += .01
    _reject(value, "short_event_coordinate_not_on_native_grid")
    value = _native()
    value["processed"].update(sample_rate_hz=8000, sample_count=47200)
    _reject(value, "unsupported_endpoint_configuration")


def test_withheld_and_error_do_not_claim_analyzed_evidence():
    for length in (50, 1000, 2000):
        value = _withheld(_native(length=length))
        assert validate_analysis_result(value) is value
        value["events"] = []
        _reject(value, "inconsistent_result_status")
    error = {"schema_version": 1, "engine": ENGINE, "status": "error", "reason_code": "input_error"}
    assert validate_analysis_result(error) is error
    error["events"] = None
    _reject(error, "unexpected_result_field")


def test_v11_review_stages_are_bounded_and_reasons_do_not_leak_to_older_versions():
    reason = "endpoint_loss_no_complete_single_deletion_explanation"
    value = _withheld(_native())
    value["review_diagnostics"] = {
        "schema_version": 1, "selected_engine": ENGINE, "result_status": "withheld",
        "primary_reason_code": reason, "trace_availability": "recorded",
        "diagnostic_only": True, "fault_provenance_confirmed": False,
        "stages": [{"engine": f"local_content_alignment_v{version}", "outcome": "withheld",
                    "reason_code": "event_boundary_not_supported", "detail_reason_code": None}
                   for version in range(1, 12)],
    }
    value["review_diagnostics"]["stages"][-1]["reason_code"] = reason
    value["review_diagnostics"]["stages"][-2]["reason_code"] = "short_event_no_complete_single_edit_explanation"
    assert validate_analysis_result(value) is value
    value["review_diagnostics"]["stages"][-2]["detail_reason_code"] = reason
    _reject(value, "invalid_review_stage_detail_reason")
    value["review_diagnostics"]["stages"][-2]["detail_reason_code"] = None
    value["review_diagnostics"]["stages"][-1]["reason_code"] = "short_event_no_complete_single_edit_explanation"
    _reject(value, "invalid_review_stage_reason")
    value.pop("review_diagnostics")
    value["engine"] = "local_content_alignment_v10"
    value["analysis"]["method"] = INHERITED_METHOD
    value["review_diagnostics"] = {
        "schema_version": 1, "selected_engine": value["engine"], "result_status": "withheld",
        "primary_reason_code": reason, "trace_availability": "recorded", "diagnostic_only": True,
        "fault_provenance_confirmed": False, "stages": [{"engine": ENGINE, "outcome": "withheld",
            "reason_code": reason, "detail_reason_code": None}],
    }
    _reject(value, "invalid_review_stage_engine")


def test_v11_schema_is_self_contained_and_old_schema_bytes_remain_frozen():
    schema = json.loads((_SCHEMAS / "analysis-result-v11.schema.json").read_text("utf-8"))
    assert schema["$id"].endswith(":v11")
    assert schema["$defs"]["edgeAnalysis"]["properties"]["method"]["const"] == METHOD
    assert schema["$defs"]["inheritedAnalysis"]["properties"]["method"]["const"] == INHERITED_METHOD
    assert schema["$defs"]["reviewDiagnostics"]["properties"]["stages"]["maxItems"] == 11
    assert schema["$defs"]["edgeDeleteEvent"]["additionalProperties"] is False
    for version, digest in enumerate([
        "ef1a43fcf41ecd3db3a6f398b882b6886bc1255d9065343535be71210fb0e1d1",
        "3947a8fbca4bf3165f362d0e12e1284c4db22350c8bb5f09822b6c7356df0727",
        "b80c420e17f189f9afc57bdf6647bd7769b8ddc8ef51cb7e7ca61abaf6fd8bc9",
        "64104df35c380bd6fdb614f6d2dc38498f17f4866ae7db5bc95e6abf21ac6ec1",
        "305377dc4bc46d847233140b8b697fd98535a24ae22f4945cb64309053439c58",
        "aa2a6dd5bcc57646dd6363312b988c8943417842b855e13425922fa829474fc9",
        "d58a7bd6bd256138302c9f6bfc4126ec68a2ee3b7cb2e94b4eff2cb02264c264",
        "19273c5134a3e79adee3c7855068c4f6e1d68b55652f635f36a7752e849609e3",
        "c96cf6949879b9634d571846e79b0352a19ace7c2d12b4b990d3ad1cbdb703a9",
        "f72e2099ecb22edb991fbe85d78ae91439897ab0a40b47fdd23cdcde3b04d755",
    ], 1):
        assert hashlib.sha256((_SCHEMAS / f"analysis-result-v{version}.schema.json").read_bytes()).hexdigest() == digest


def test_schema_references_are_internal_only():
    schema = json.loads((_SCHEMAS / "analysis-result-v11.schema.json").read_text("utf-8"))
    def visit(value):
        if isinstance(value, dict):
            if "$ref" in value:
                assert value["$ref"].startswith("#/$defs/")
                assert value["$ref"].split("/")[-1] in schema["$defs"]
            for item in value.values():
                visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)
    visit(schema)
