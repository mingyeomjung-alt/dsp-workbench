"""The artifact command verifies bytes only; it never grants audio approval."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import pytest

from audio_regression import artifact_cli
from audio_regression.artifact_integrity import ArtifactVerificationError


def _fixture(folder):
    folder.mkdir()
    data = b"opaque bytes, not an audio evaluation\n"
    (folder / "result.bin").write_bytes(data)
    manifest = folder / "manifest.json"
    manifest.write_text(json.dumps({
        "schema_version": 1,
        "files": [{"path": "result.bin", "size_bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}],
        "manifest_excludes_only_itself": True, "network_used": False,
    }), encoding="utf-8")
    digest = hashlib.sha256(manifest.read_bytes()).hexdigest()
    return ["verify", "--root", str(folder), "--manifest", str(manifest), "--manifest-sha256", digest]


def test_verified_is_not_audio_or_authenticity_approval(tmp_path, capsys):
    argv = _fixture(tmp_path / "archive")
    assert artifact_cli.main(argv) == 0
    value = json.loads(capsys.readouterr().out)
    assert value["status"] == "verified"
    assert value["file_count"] == 1
    assert value["exit_code"] == 0
    assert value["quality_verdict"] == "not_assessed"
    for key in ("authenticity_verified", "execution_provenance_verified", "complete_audio_approval",
                "commercial_performance_validated", "network_used"):
        assert value[key] is False


def test_modified_file_never_passes_and_no_write(tmp_path, capsys):
    folder = tmp_path / "archive"
    argv = _fixture(folder)
    (folder / "result.bin").write_bytes(b"tampered")
    before = {path.name: path.read_bytes() for path in folder.iterdir()}
    assert artifact_cli.main(argv) == 2
    value = json.loads(capsys.readouterr().out)
    assert value["status"] == "not_verified"
    assert value["exit_code"] == 2
    assert {path.name: path.read_bytes() for path in folder.iterdir()} == before


@pytest.mark.parametrize("argv", [[], ["verify"], ["snapshot"], ["verify", "--private-token", "sensitive-name"]])
def test_argument_errors_are_stable_and_private(argv, capsys):
    assert artifact_cli.main(argv) == 3
    output = capsys.readouterr()
    assert json.loads(output.out)["reason_code"] == "invalid_cli_arguments"
    assert output.err == ""
    assert "sensitive-name" not in output.out


def test_missing_external_digest_cannot_self_reseal(tmp_path, capsys):
    argv = _fixture(tmp_path / "archive")[:-2]
    assert artifact_cli.main(argv) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "invalid_cli_arguments"


def test_manifest_digest_mismatch_never_passes(tmp_path, capsys):
    argv = _fixture(tmp_path / "archive")
    argv[-1] = "0" * 64
    assert artifact_cli.main(argv) == 2
    assert json.loads(capsys.readouterr().out)["status"] == "not_verified"


@pytest.mark.parametrize("code", ["private/path-secret", "bad error", "X", "", None])
def test_untrusted_exception_codes_never_leak(code, tmp_path, monkeypatch, capsys):
    argv = _fixture(tmp_path / "archive")
    def broken(*args, **kwargs):
        error = ArtifactVerificationError("safe_error")
        error.code = code
        raise error
    monkeypatch.setattr(artifact_cli, "verify_artifact_manifest", broken)
    assert artifact_cli.main(argv) == 2
    output = capsys.readouterr()
    assert json.loads(output.out)["reason_code"] == "artifact_verification_error"
    assert "path-secret" not in output.out
    assert output.err == ""


def test_unexpected_error_does_not_expose_private_text(tmp_path, monkeypatch, capsys):
    argv = _fixture(tmp_path / "archive")
    def broken(*args, **kwargs):
        raise KeyError("C:/private/sensitive-recording.wav")
    monkeypatch.setattr(artifact_cli, "verify_artifact_manifest", broken)
    assert artifact_cli.main(argv) == 3
    output = capsys.readouterr()
    assert json.loads(output.out)["reason_code"] == "artifact_internal_error"
    assert "sensitive-recording" not in output.out


def test_help_documents_verify_only(capsys):
    with pytest.raises(SystemExit) as error:
        artifact_cli.main(["--help"])
    assert error.value.code == 0
    assert "verify" in capsys.readouterr().out
    assert set(artifact_cli._parser()._subparsers._group_actions[0].choices) == {"verify"}


def test_real_python_command_read_only(tmp_path):
    folder = tmp_path / "archive"
    argv = _fixture(folder)
    before = {path.name: path.read_bytes() for path in folder.iterdir()}
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["PYTHONPATH"] = str(Path(__file__).absolute().parents[1] / "src")
    completed = subprocess.run(
        [sys.executable, "-B", "-m", "audio_regression.artifact_cli", *argv],
        capture_output=True, env=environment, timeout=30,
    )
    assert completed.returncode == 0
    assert json.loads(completed.stdout)["status"] == "verified"
    assert completed.stderr == b""
    assert {path.name: path.read_bytes() for path in folder.iterdir()} == before
