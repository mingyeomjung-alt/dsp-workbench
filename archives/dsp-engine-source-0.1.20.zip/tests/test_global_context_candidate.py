"""NEW owned analytic-signal tests for the v9 global geometry certificate.

No recorded, consumed evaluation, older owned fixture, or downloaded sound is
read. Unit injections are labelled as contract guards, not accuracy evidence.
"""

from copy import deepcopy
import json

import numpy as np
import pytest
from scipy.signal import resample_poly

from audio_regression import global_context_engine as candidate
from audio_regression import global_context_proof as proof_module
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.engine import EngineConfig, EngineConfigError


Q = 1 / 32768
GAIN = .6213897
SETTINGS = EngineConfig(allow_gain=True, allow_resampling=True, max_delay_ms=1000)


def _pcm(values):
    return np.minimum(np.rint(values * 32768), 32767) / 32768


def _source(sparse=False):
    t = np.arange(76800, dtype=float) / 16000
    phase = 2 * np.pi * (417 * t + 37 * t ** 2 + .013 * t ** 3 + .17 * np.sin(4.13 * t))
    envelope = .83 + .12 * np.sin(2.17 * t) + .04 * np.cos(5.79 * t)
    values = .12 * envelope * (np.sin(phase) + .29 * np.sin(1.41 * phase + .32)
                              + .17 * np.sin(2.17 * phase - .9))
    if sparse:
        values[t < 2.7] = 0
    return _pcm(values)


def _edit(source, kind, point, length):
    if kind == "delete":
        return np.concatenate((source[:2 * point], source[2 * (point + length):]))
    return np.concatenate((source[:2 * point], source[2 * (point - length):2 * point], source[2 * point:]))


def _observed(source, kind, point, length, gain=GAIN, delay=137):
    changed = _edit(source, kind, point, length)
    return np.concatenate((np.zeros(delay), _pcm(resample_poly(_pcm(changed * gain), 1, 2))))


def _audio(values, rate):
    return decode_wav(encode_wav(values, rate))


@pytest.mark.parametrize("kind", ("delete", "repeat"))
@pytest.mark.parametrize("length", (1600, 3200, 6000, 16000))
def test_exhaustive_quantization_pruner_retains_true_witness(kind, length):
    source = _source()
    point = 19200 if kind == "delete" else 19200 + length
    observed = _observed(source, kind, point, length)
    source_before, observed_before = source.copy(), observed.copy()
    proof, trace = proof_module.prove_event(source, observed, 8000)
    assert proof is not None, trace
    assert (proof["kind"], proof["length"], proof["delay"]) == (kind, length, 137)
    assert abs(proof["point"] - point) <= 160
    assert trace["search_complete"] is True
    assert trace["every_supported_geometry_checked"] is True
    assert trace["interval_excluded_candidate_count"] > 0
    assert trace["gain_solver_calls"] < 10
    assert np.array_equal(proof["rendered"], observed[proof["delay"]:])
    assert np.array_equal(source, source_before) and np.array_equal(observed, observed_before)
    json.dumps(trace, allow_nan=False)


@pytest.mark.parametrize("kind", ("delete", "repeat"))
def test_short_active_prefix_exact_geometry_or_inherited_result_uses_honest_evidence(kind):
    source = _source(sparse=True)
    point = 2840 * 8
    observed = _observed(source, kind, point, 200 * 8)
    reference, processed = _audio(source, 16000), _audio(observed, 8000)
    result, trace = candidate.analyze_buffers_with_trace(reference, processed, SETTINGS)
    assert result["status"] == "analyzed", trace
    assert len(result["events"]) == 1
    if trace["global_context_proved"]:
        assert trace["global_context_attempted"] is True
        assert trace["inherited_v8_trace"]["result_status"] == "withheld"
        assert trace["correspondence_summary_is_unique_landmark_certificate"] is False
    else:
        assert trace["proof_path"] == "preserved_v8_result"
        assert trace["inherited_v8_trace"]["result_status"] == "analyzed"
    proof, proof_trace = proof_module.prove_event(source, observed, 8000)
    assert proof is not None, proof_trace
    assert len(result["alignment_segments"]) == 2
    assert all(len(segment["anchor_correlations"]) == 3 for segment in result["alignment_segments"])
    assert all(0.90 <= value <= 1 for segment in result["alignment_segments"] for value in segment["anchor_correlations"])


@pytest.mark.parametrize("kind,point", (("delete", 0), ("delete", 35200), ("repeat", 38400)))
def test_exact_endpoint_history_is_not_an_internal_event_certificate(kind, point):
    source = _source()
    observed = _observed(source, kind, point, 3200)
    proof, trace = proof_module.prove_event(source, observed, 8000)
    assert proof is None, trace
    assert trace["reason_code"] in {"global_context_endpoint_or_near_edge_alternative", "global_context_ambiguous_geometry"}


def test_unit_prune_helper_intervals_are_necessary_not_approval():
    source = _source()[:8000]
    gain = .537981
    target = _pcm(gain * source)
    lower, upper = proof_module._sample_intervals(source, target)
    assert np.all(lower <= gain) and np.all(upper >= gain)
    assert np.any(upper > lower)


def test_unit_exact_linear_zero_contradiction_is_gain_independent():
    bound = proof_module.quantization_bound()
    reference = np.array([0., 0., 0.])
    target = np.array([0., np.nextafter(bound, 0), np.nextafter(bound, np.inf)])
    lower, upper = proof_module._sample_intervals(reference, target)
    assert lower[0] == lower[1] == 0 and np.isposinf(upper[0]) and np.isposinf(upper[1])
    assert np.isposinf(lower[2]) and np.isneginf(upper[2])


def _predeclared_low_prefix_source(index):
    """Reproduce the root's BEFORE-ANALYSIS locked v4 development equations.

    This is a route regression, not an independent source or new performance
    corpus. No saved audio/result is read and no parameters are retuned here.
    """
    duration, start, point = (8, 3.86, 64000) if index == 0 else (9, 4.06, 67200)
    t = np.arange(duration * 16000) / 16000
    phase = 2 * np.pi * ((437 + 62 * index) * t + (31 + 8 * index) * t * t
                         + .23 * np.sin((1.37 + .31 * index) * t))
    signal = .12 * (np.sin(phase) + .19 * np.sin(1.71 * phase + .37)
                    + .11 * np.sin(2.43 * phase - .59)) * (.71 + .21 * np.sin(.91 * t) ** 2)
    source = _pcm(np.where(t < start, 0, signal))
    source[:point] = _pcm(source[:point] * .0035)
    return source, point // 2


@pytest.mark.parametrize("index", (0, 1))
def test_natural_raw_global_residual_route_requires_and_finds_full_exact_certificate(index):
    source, point = _predeclared_low_prefix_source(index)
    observed = _observed(source, "delete", point, 3200, gain=.8313743, delay=48)
    reference, processed = _audio(source, 16000), _audio(observed, 8000)
    result, trace = candidate.analyze_buffers_with_trace(reference, processed, SETTINGS)
    assert trace["baseline_status"] == "withheld"
    assert trace["baseline_reason_code"] == "raw_landmark_unexplained_signal_change"
    assert trace["global_context_attempted"] is True
    assert trace["global_context_proved"] is True, trace
    assert trace["proof_path"] == "global_context_event_exact_forward"
    assert trace["event_proof_trace"]["search_complete"] is True
    assert trace["event_proof_trace"]["every_supported_geometry_checked"] is True
    assert result["status"] == "analyzed"
    assert result["events"][0]["type"] == "delete"
    assert result["events"][0]["reference_interval_ms"] == [point / 8, (point + 3200) / 8]
    assert trace["every_output_sample_exact"] is True


@pytest.mark.parametrize("index", (0, 1))
@pytest.mark.parametrize("mutation", ("retained_tail_erasure", "retained_one_lsb", "nonuniform_gain"))
def test_raw_global_residual_route_does_not_approve_unexplained_retained_changes(index, mutation):
    source, point = _predeclared_low_prefix_source(index)
    observed = _observed(source, "delete", point, 3200, gain=.8313743, delay=48)
    if mutation == "retained_tail_erasure":
        observed[-1600:] = 0
    elif mutation == "retained_one_lsb":
        observed[-799] += Q
    else:
        observed[-8000:] = _pcm(observed[-8000:] * .81)
    result, trace = candidate.analyze_buffers_with_trace(_audio(source, 16000), _audio(observed, 8000), SETTINGS)
    assert result["status"] == "withheld", trace
    assert trace["global_context_proved"] is False
    assert result["events"] is None


@pytest.mark.parametrize("settings", (EngineConfig(), EngineConfig(allow_gain=True), EngineConfig(allow_resampling=True)))
def test_missing_existing_transform_declaration_never_enters_new_certificate(settings, monkeypatch):
    source = _source(sparse=True)
    observed = _observed(source, "delete", 22720, 1600)
    monkeypatch.setattr(candidate, "prove_event", lambda *args: pytest.fail("Forbidden undeclared proof."))
    _, trace = candidate.analyze_buffers_with_trace(_audio(source, 16000), _audio(observed, 8000), settings)
    assert trace["global_context_attempted"] is False


def test_nonbasic_profile_rejected():
    source = _source()
    observed = _observed(source, "delete", 19200, 3200)
    with pytest.raises(EngineConfigError):
        candidate.analyze_buffers_with_trace(_audio(source, 16000), _audio(observed, 8000),
            EngineConfig(profile="telephone", allow_gain=True, allow_resampling=True))


@pytest.mark.parametrize("failure", ("sample", "point", "delay", "gain", "incomplete", "not_dict"))
def test_unit_outer_engine_independently_rejects_malformed_global_witness(monkeypatch, failure):
    source = _source(sparse=True)
    point, length, delay = 22720, 1600, 137
    observed = _observed(source, "delete", point, length, delay=delay)
    # Unit-only forced eligible withhold isolates the outer witness guard.
    # The real owned pair can already be analyzed by v8; it is not a v9 gain.
    reference, processed = _audio(source, 16000), _audio(observed, 8000)
    baseline, old_trace = candidate.compound_event_engine.analyze_buffers_with_trace(reference, processed, SETTINGS)
    baseline = deepcopy(baseline)
    baseline.update(status="withheld", reason_code="raw_landmark_unexplained_local_change",
                    events=None, content_preservation_status="withheld")
    baseline.pop("alignment_segments", None)
    monkeypatch.setattr(candidate.compound_event_engine, "analyze_buffers_with_trace",
                        lambda *args: (deepcopy(baseline), deepcopy(old_trace)))
    fake = {"point": point, "length": length, "kind": "delete", "delay": delay,
            "gain": GAIN, "rendered": observed[delay:].copy()}
    fake_trace = {"search_complete": True, "every_supported_geometry_checked": True}
    if failure == "sample":
        fake["rendered"][31000] += Q
    elif failure == "point":
        fake["point"] += 1
    elif failure == "delay":
        fake["delay"] -= 1
    elif failure == "gain":
        fake["gain"] = .7311
    elif failure == "incomplete":
        fake_trace["search_complete"] = False
    else:
        fake = [fake]
    monkeypatch.setattr(candidate, "prove_event", lambda *args: (deepcopy(fake), deepcopy(fake_trace)))
    result, trace = candidate.analyze_buffers_with_trace(reference, processed, SETTINGS)
    assert result["status"] == "withheld", trace
    assert trace["global_context_attempted"] is True
    assert trace["global_context_proved"] is False
    assert trace["global_context_failure"] == "global_context_whole_output_exact_proof_failed"
