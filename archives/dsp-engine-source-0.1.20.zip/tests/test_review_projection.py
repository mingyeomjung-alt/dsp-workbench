"""Inert trace projection tests; no audio, consumed evaluations or engine runs."""

from copy import deepcopy
import ast
from pathlib import Path

import pytest
import numpy as np

from audio_regression.review_diagnostics import (
    ENGINE_STAGE_LABELS, KNOWN_REASON_CODES, SUCCESS_REASON_CODES,
    build_review_diagnostics, describe_reason,
)


PRIMARY = "raw_landmark_unexplained_local_residual"
REFERENCE_HASH = "a" * 64
PROCESSED_HASH = "b" * 64


def _result(number, reason=PRIMARY):
    return {"engine": f"local_content_alignment_v{number}", "status": "withheld",
            "reason_code": reason, "reference": {"sha256": REFERENCE_HASH},
            "processed": {"sha256": PROCESSED_HASH}, "events": None}


def _trace(number, reason=PRIMARY):
    engine = f"local_content_alignment_v{number}"
    trace = {"schema_version": 1, "engine": engine, "analysis_engine": engine,
             "reference_sha256": REFERENCE_HASH, "processed_sha256": PROCESSED_HASH,
             "result_status": "withheld", "reason_code": reason}
    if number in (2, 3):
        trace.update(engine={2: "pcm16_cancellation_trace_v1",
                             3: "bounded_active_context_trace_v1"}[number],
                     withheld_branch=reason, trace_truncated=False)
        return trace
    trace.update(baseline_status="withheld", baseline_reason_code=reason)
    flag, proved, path = {
        4: ("fallback_attempted", None, "preserved_v3_result"),
        5: ("canonical_attempted", "canonical_proved", "preserved_v4_result"),
        6: ("repeat_attempted", None, "preserved_v5_result"),
        7: ("compound_attempted", "compound_proved", "preserved_v6_result"),
        8: ("compound_event_attempted", "compound_event_proved", "preserved_v7_result"),
        9: ("global_context_attempted", "global_context_proved", "preserved_v8_result"),
    }[number]
    trace.update({flag: False, "proof_path": path})
    if proved:
        trace[proved] = False
    if number > 4:
        trace[f"inherited_v{number - 1}_trace"] = _trace(number - 1, reason)
    return trace


def _attempt(trace, number, failure=None):
    flag = {4: "fallback_attempted", 5: "canonical_attempted", 6: "repeat_attempted",
            7: "compound_attempted", 8: "compound_event_attempted", 9: "global_context_attempted"}[number]
    trace[flag] = True
    if number == 4:
        trace["proof_path"] = "raw_landmark_fallback"
    if number == 6:
        trace["proof_path"] = "full_copy_feasibility"
    if failure is not None:
        trace[{7: "compound_failure", 8: "compound_event_failure", 9: "global_context_failure"}[number]] = failure


def test_catalog_only_contains_literal_current_production_codes():
    package = Path(__file__).resolve().parents[1] / "src" / "audio_regression"
    files = [package / name for name in (
        "engine.py", "alignment.py", "robust_engine.py", "context_engine.py", "instrument_engine.py",
        "canonical_engine.py", "repeat_engine.py", "compound_engine.py", "compound_event_engine.py",
        "global_context_engine.py", "compound_gain.py", "compound_event_proof.py", "global_context_proof.py")]
    literals = {node.value for path in files for node in ast.walk(ast.parse(path.read_text(encoding="utf-8")))
                if isinstance(node, ast.Constant) and isinstance(node.value, str)}
    assert isinstance(KNOWN_REASON_CODES, frozenset)
    assert isinstance(SUCCESS_REASON_CODES, frozenset)
    assert SUCCESS_REASON_CODES <= KNOWN_REASON_CODES
    assert KNOWN_REASON_CODES <= literals
    assert "compound_gain_search_depth_exceeded" in KNOWN_REASON_CODES
    assert "compound_gain_depth_exceeded" not in KNOWN_REASON_CODES
    assert len(ENGINE_STAGE_LABELS) == 12


@pytest.mark.parametrize("code", sorted(KNOWN_REASON_CODES))
def test_known_catalog_wording_has_exact_fixed_fields(code):
    explanation = describe_reason(code)
    assert set(explanation) == {"label", "explanation", "next_check"}
    assert all(type(value) is str and value for value in explanation.values())
    assert code not in str(explanation)


@pytest.mark.parametrize("code", (None, [], {}, 3, True, "private_api_token_secret", "C:/private.wav", "<script>"))
def test_unknown_reason_has_no_value_echo(code):
    assert describe_reason(code) == describe_reason(None)


def test_v1_missing_trace_is_not_recorded_not_fake_history():
    result = _result(1, "insufficient_signal_variation")
    before = deepcopy(result)
    block = build_review_diagnostics(result)
    assert block == {"schema_version": 1, "selected_engine": result["engine"], "result_status": "withheld",
                     "primary_reason_code": result["reason_code"], "trace_availability": "not_recorded",
                     "diagnostic_only": True, "fault_provenance_confirmed": False, "stages": []}
    assert result == before


@pytest.mark.parametrize("number", range(2, 10))
def test_missing_candidate_trace_is_unavailable(number):
    block = build_review_diagnostics(_result(number))
    assert block["trace_availability"] == "unavailable"
    assert block["stages"] == []


@pytest.mark.parametrize("number", (2, 3))
def test_low_level_withheld_branch_projects_without_raw_revalidations(number):
    result, trace = _result(number), _trace(number)
    trace["revalidations"] = [{"accepted": False, "reason_code": "C:/private.wav", "raw_vector": object()}] * 6001
    block = build_review_diagnostics(result, trace)
    assert block["trace_availability"] == "recorded"
    assert block["stages"] == [{"engine": result["engine"], "outcome": "withheld",
                                "reason_code": PRIMARY, "detail_reason_code": None}]


@pytest.mark.parametrize("number", range(4, 10))
def test_fixed_inherited_chain_is_ascending_and_stops_at_v4(number):
    result, trace = _result(number), _trace(number)
    before = deepcopy((result, trace))
    block = build_review_diagnostics(result, trace)
    assert block["trace_availability"] == "recorded"
    assert [stage["engine"] for stage in block["stages"]] == [f"local_content_alignment_v{n}" for n in range(4, number + 1)]
    assert all(stage["outcome"] == "not_attempted" for stage in block["stages"])
    assert all(stage["reason_code"] is stage["detail_reason_code"] is None for stage in block["stages"])
    assert (result, trace) == before


@pytest.mark.parametrize("number", (5, 6))
def test_attempt_without_explicit_detail_never_reuses_baseline_reason(number):
    trace = _trace(number)
    _attempt(trace, number)
    stage = build_review_diagnostics(_result(number), trace)["stages"][-1]
    assert stage == {"engine": f"local_content_alignment_v{number}", "outcome": "attempted_without_proof_detail",
                     "reason_code": None, "detail_reason_code": None}


@pytest.mark.parametrize("reason", ("repeat_feasibility_ambiguous_geometry", "repeat_feasibility_proof_budget_exceeded"))
def test_repeat_explicit_withholding_is_distinguished_from_baseline(reason):
    trace = _trace(6)
    _attempt(trace, 6)
    trace["reason_code"] = reason
    stage = build_review_diagnostics(_result(6, reason), trace)["stages"][-1]
    assert stage["outcome"] == "withheld"
    assert stage["reason_code"] == reason


@pytest.mark.parametrize("number,reason", (
    (7, "compound_gain_search_budget_exceeded"),
    (8, "compound_event_gain_search_incomplete"),
    (9, "global_context_gain_search_incomplete"),
))
def test_extra_proof_reason_and_deep_gain_detail_preserve_primary(number, reason):
    result, trace = _result(number), _trace(number)
    _attempt(trace, number, reason)
    detail = "compound_gain_search_depth_exceeded"
    if number == 7:
        trace["gain_search_trace"] = {"reason_code": detail, "initial_gain_interval": [1, 2]}
    elif number == 8:
        trace["event_proof_trace"] = {"reason_code": reason, "incomplete_gain_search_reason": detail,
                                     "incomplete_gain_search_boundary_samples": 123}
    else:
        trace["event_proof_trace"] = {"reason_code": reason, "incomplete_gain_search_geometry": {
            "reason_code": detail, "point": 123, "rendered": object()}}
    stage = build_review_diagnostics(result, trace)["stages"][-1]
    assert stage == {"engine": result["engine"], "outcome": "withheld", "reason_code": reason,
                     "detail_reason_code": detail}
    assert result["reason_code"] == PRIMARY


@pytest.mark.parametrize("number", (7, 8, 9))
@pytest.mark.parametrize("unknown", ("C:/private.wav", "private_access_token", "unit_injected_failure", None, {"bad": object()}))
def test_unknown_extra_failure_is_safely_omitted(number, unknown):
    trace = _trace(number)
    _attempt(trace, number)
    trace[{7: "compound_failure", 8: "compound_event_failure", 9: "global_context_failure"}[number]] = unknown
    stage = build_review_diagnostics(_result(number), trace)["stages"][-1]
    assert stage["outcome"] == "attempted_without_proof_detail"
    assert stage["reason_code"] is stage["detail_reason_code"] is None


@pytest.mark.parametrize("key,value", (
    ("schema_version", True), ("schema_version", 2), ("engine", "local_content_alignment_v8"),
    ("analysis_engine", "local_content_alignment_v8"), ("reference_sha256", "c" * 64),
    ("processed_sha256", "a" * 64), ("result_status", "analyzed"), ("reason_code", "different_code"),
    ("baseline_status", "analyzed"), ("proof_path", "global_context_event_exact_forward"),
    ("global_context_attempted", 1), ("global_context_proved", 0),
))
def test_invalid_root_header_fails_closed_without_altering_result(key, value):
    result, trace = _result(9), _trace(9)
    trace[key] = value
    before = deepcopy(result)
    block = build_review_diagnostics(result, trace)
    assert block["trace_availability"] == "unavailable"
    assert block["stages"] == []
    assert result == before


@pytest.mark.parametrize("mode", ("missing", "identity", "hash", "reason", "cycle", "subclass"))
def test_invalid_child_invalidates_whole_projection_not_partial_history(mode):
    trace = _trace(9)
    child = trace["inherited_v8_trace"]
    if mode == "missing":
        del trace["inherited_v8_trace"]
    elif mode == "identity":
        child["analysis_engine"] = "local_content_alignment_v7"
    elif mode == "hash":
        child["reference_sha256"] = "c" * 64
    elif mode == "reason":
        child["reason_code"] = "insufficient_signal_variation"
    elif mode == "cycle":
        trace["inherited_v8_trace"] = trace
    else:
        class NotExactDict(dict):
            pass
        trace["inherited_v8_trace"] = NotExactDict(child)
    block = build_review_diagnostics(_result(9), trace)
    assert block["trace_availability"] == "unavailable"
    assert block["stages"] == []


def test_unknown_big_cyclic_payload_is_not_traversed_or_echoed():
    trace = _trace(9)
    private = {"C:/private.wav": object()}
    private["cycle"] = private
    private["huge"] = [object()] * 100_000
    trace["unknown_payload"] = private
    block = build_review_diagnostics(_result(9), trace)
    assert block["trace_availability"] == "recorded"
    assert "private" not in str(block)
    assert trace["unknown_payload"] is private


@pytest.mark.parametrize("key", ("engine", "analysis_engine", "reference_sha256", "processed_sha256",
                                  "result_status", "reason_code", "baseline_status", "baseline_reason_code",
                                  "proof_path", "global_context_attempted", "global_context_proved"))
def test_untrusted_header_object_is_not_compared_or_stringified(key):
    class PrivateHeader:
        def __eq__(self, other):
            raise AssertionError("An untrusted header must not be compared.")

        def __repr__(self):
            raise AssertionError("An untrusted header must not be rendered.")

    trace = _trace(9)
    trace[key] = PrivateHeader()
    block = build_review_diagnostics(_result(9), trace)
    assert block["trace_availability"] == "unavailable"
    assert block["stages"] == []


@pytest.mark.parametrize("value", (np.array([1, 2]), {}, [], 3.0, None))
@pytest.mark.parametrize("key", ("engine", "analysis_engine", "reference_sha256", "processed_sha256",
                                  "result_status", "reason_code", "baseline_status", "baseline_reason_code",
                                  "proof_path", "global_context_attempted", "global_context_proved"))
def test_non_json_known_header_types_fail_closed(key, value):
    trace = _trace(9)
    trace[key] = value
    block = build_review_diagnostics(_result(9), trace)
    assert block["trace_availability"] == "unavailable"
    assert block["stages"] == []


@pytest.mark.parametrize("value", ("x" * 129, "x" * 1_000_000, "C:/private.wav", "<script>"),
                         ids=("oversize_code", "million_character_code", "private_path", "markup"))
def test_invalid_baseline_code_is_not_followed_into_child(value):
    trace = _trace(9)
    trace["baseline_reason_code"] = value
    block = build_review_diagnostics(_result(9), trace)
    assert block["trace_availability"] == "unavailable"
    assert block["stages"] == []


def test_successful_nested_gain_record_is_not_displayed_as_failure_detail():
    trace = _trace(7)
    _attempt(trace, 7, "global_residual_not_supported")
    trace["gain_search_trace"] = {"reason_code": "compound_gain_exact_witness"}
    stage = build_review_diagnostics(_result(7), trace)["stages"][-1]
    assert stage["reason_code"] == "global_residual_not_supported"
    assert stage["detail_reason_code"] is None


@pytest.mark.parametrize("number", (2, 3))
@pytest.mark.parametrize("code", sorted(SUCCESS_REASON_CODES))
def test_successful_low_level_branch_is_not_displayed_as_failed_stage(number, code):
    trace = _trace(number, code)
    stage = build_review_diagnostics(_result(number, code), trace)["stages"][-1]
    assert stage["outcome"] == "attempted_without_proof_detail"
    assert stage["reason_code"] is stage["detail_reason_code"] is None


@pytest.mark.parametrize("number", (7, 8, 9))
def test_success_code_cannot_masquerade_as_failed_stage_reason(number):
    trace = _trace(number)
    _attempt(trace, number, "compound_gain_exact_witness")
    stage = build_review_diagnostics(_result(number), trace)["stages"][-1]
    assert stage["outcome"] == "attempted_without_proof_detail"
    assert stage["reason_code"] is None


@pytest.mark.parametrize("result", ({}, [], _result(13), {**_result(1), "status": "analyzed"}))
def test_non_withheld_or_unsupported_results_are_not_given_review_blocks(result):
    with pytest.raises(ValueError, match="supported withheld analysis result"):
        build_review_diagnostics(result)
