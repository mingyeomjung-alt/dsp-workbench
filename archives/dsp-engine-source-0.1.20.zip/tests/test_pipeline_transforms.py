"""Native pipeline checks using fresh generated development signals only."""

import hashlib
import json
import math

import numpy as np
import pytest
from scipy.signal import resample_poly

from audio_regression.audio import MAX_FILE_BYTES, WavAudio, decode_wav, encode_wav
from audio_regression.pipeline_transforms import (
    PipelineTransformError,
    execute_stage,
    validate_stage,
)


RATES = [8000, 16000, 44100, 48000]


def _development_audio(rate: int = 8000, count: int | None = None) -> tuple[bytes, WavAudio]:
    count = 3 * rate + 17 if count is None else count
    sample_positions = np.arange(count, dtype=np.float64)
    values = (
        0.11 * np.sin(2 * np.pi * 379 * sample_positions / rate)
        + 0.07 * np.sin(2 * np.pi * 823 * sample_positions / rate + 0.23)
        + 0.025
    )
    data = encode_wav(values, rate)
    return data, decode_wav(data)


def _assert_stage_error(spec, code: str = "invalid_stage") -> None:
    with pytest.raises(PipelineTransformError) as caught:
        validate_stage(spec)
    assert caught.value.code == code


def test_error_has_optional_message_and_machine_readable_code() -> None:
    error = PipelineTransformError("test_code")
    assert error.code == "test_code"
    assert error.message == "test_code"
    assert str(error) == "test_code"
    assert str(PipelineTransformError("test_code", "Safe explanation.")) == "Safe explanation."


@pytest.mark.parametrize("rate", RATES)
def test_validate_supported_resample_rates(rate: int) -> None:
    assert validate_stage({"kind": "resample", "target_rate_hz": rate}) == {
        "kind": "resample", "target_rate_hz": rate,
    }


@pytest.mark.parametrize("gain", [-60, -7.75, 0, 20])
def test_validate_gain_is_normalized_to_finite_float(gain: float) -> None:
    normalized = validate_stage({"kind": "gain", "gain_db": gain})
    assert normalized == {"kind": "gain", "gain_db": float(gain)}
    assert type(normalized["gain_db"]) is float
    json.dumps(normalized, allow_nan=False)


@pytest.mark.parametrize("segment_ms", [200, 701, 30_000])
def test_validate_split_join_duration_boundaries(segment_ms: int) -> None:
    assert validate_stage({"kind": "split_join", "segment_ms": segment_ms}) == {
        "kind": "split_join", "segment_ms": segment_ms,
    }


def test_validate_returns_fresh_order_copy_and_retains_optional_label() -> None:
    order = [2, 0, 1, 1]
    stage = {"kind": "split_join", "segment_ms": 700, "order": order, "label": "development chunks"}
    normalized = validate_stage(stage)
    assert normalized == stage
    assert normalized is not stage
    assert normalized["order"] is not order
    order.append(5)
    assert normalized["order"] == [2, 0, 1, 1]


@pytest.mark.parametrize("label", ["x", "가" * 80, "<script>development</script>", "🎧 DSP"])
def test_labels_accept_inclusive_length_boundaries(label: str) -> None:
    assert validate_stage({"kind": "gain", "gain_db": 0, "label": label})["label"] == label


@pytest.mark.parametrize("spec", [None, [], "gain", 12, {}, {"kind": "unknown"}, {"kind": True}])
def test_rejects_non_objects_and_unknown_kinds(spec) -> None:
    _assert_stage_error(spec)


@pytest.mark.parametrize("spec", [
    {"kind": "gain"},
    {"kind": "resample"},
    {"kind": "split_join"},
    {"kind": "gain", "gain_db": 0, "extra": 1},
    {"kind": "gain", "gain_db": 0, "order": []},
    {"kind": "resample", "target_rate_hz": 8000, "gain_db": 0},
    {"kind": "split_join", "segment_ms": 200, "target_rate_hz": 8000},
])
def test_rejects_missing_parameters_and_unknown_fields(spec: dict) -> None:
    _assert_stage_error(spec)


@pytest.mark.parametrize("label", ["", "x" * 81, None, 3, False, ["stage"]])
def test_rejects_invalid_labels(label) -> None:
    _assert_stage_error({"kind": "gain", "gain_db": 0, "label": label})


@pytest.mark.parametrize("control", [*range(32), 127])
def test_rejects_ascii_control_characters_inside_labels(control: int) -> None:
    _assert_stage_error({"kind": "gain", "gain_db": 0, "label": f"development{chr(control)}stage"})


@pytest.mark.parametrize("character", ["\u0085", "\u009f", "\u200b", "\u202e", "\ud800", "\udfff"])
def test_rejects_unicode_control_format_and_surrogate_characters_in_labels(character: str) -> None:
    _assert_stage_error({"kind": "gain", "gain_db": 0, "label": f"development{character}stage"})


@pytest.mark.parametrize("label", [" ", " " * 80, "\u00a0", "\u3000"])
def test_rejects_all_whitespace_labels(label: str) -> None:
    _assert_stage_error({"kind": "gain", "gain_db": 0, "label": label})


@pytest.mark.parametrize("rate", [True, False, 8000.0, "8000", 22050, 96000, 0, np.nan, np.inf])
def test_rejects_unsupported_or_noninteger_resample_rates(rate) -> None:
    _assert_stage_error({"kind": "resample", "target_rate_hz": rate})


@pytest.mark.parametrize("gain", [True, False, "0", None, np.nan, np.inf, -np.inf, -60.00001, 20.00001, 10**400])
def test_rejects_bool_nonfinite_and_out_of_range_gain(gain) -> None:
    _assert_stage_error({"kind": "gain", "gain_db": gain})


@pytest.mark.parametrize("segment_ms", [True, False, 200.0, "200", None, 199, 30_001, np.nan, np.inf])
def test_rejects_invalid_segment_duration(segment_ms) -> None:
    _assert_stage_error({"kind": "split_join", "segment_ms": segment_ms})


@pytest.mark.parametrize("order", [None, (), "0", [True], [False], [-1], [0.0], [np.nan], [np.inf], ["0"], [0] * 2001])
def test_rejects_invalid_chunk_order_shape_and_types(order) -> None:
    _assert_stage_error({"kind": "split_join", "segment_ms": 200, "order": order})


def test_empty_order_and_maximum_order_length_are_valid_static_specs() -> None:
    assert validate_stage({"kind": "split_join", "segment_ms": 200, "order": []})["order"] == []
    order = list(range(2000))
    assert validate_stage({"kind": "split_join", "segment_ms": 200, "order": order})["order"] == order


@pytest.mark.parametrize("source_rate", RATES)
@pytest.mark.parametrize("target_rate", RATES)
def test_resample_matches_polyphase_geometry_and_quantization(source_rate: int, target_rate: int) -> None:
    _, audio = _development_audio(source_rate)
    original_samples = audio.samples.copy()
    original_hash = audio.sha256
    output, info = execute_stage(audio, {"kind": "resample", "target_rate_hz": target_rate})
    decoded = decode_wav(output)
    divisor = math.gcd(source_rate, target_rate)
    expected = resample_poly(audio.samples, target_rate // divisor, source_rate // divisor)
    assert output == encode_wav(expected, target_rate)
    assert decoded.sample_rate_hz == target_rate
    assert decoded.samples.size == math.ceil(audio.samples.size * target_rate / source_rate)
    assert abs(decoded.samples.size / target_rate - audio.samples.size / source_rate) < 1 / target_rate
    assert len(output) <= MAX_FILE_BYTES
    np.testing.assert_array_equal(audio.samples, original_samples)
    assert audio.sha256 == original_hash
    assert not audio.samples.flags.writeable
    assert info == {
        "kind": "resample",
        "parameters": {"target_rate_hz": target_rate},
        "declared_comparison": {
            "profile": "basic", "allow_gain": False, "allow_resampling": True, "max_delay_ms": 1000.0,
        },
    }


@pytest.mark.parametrize("seconds", [2, 30])
@pytest.mark.parametrize("rate", RATES)
def test_output_duration_boundaries_remain_valid(seconds: int, rate: int) -> None:
    _, audio = _development_audio(rate, seconds * rate)
    for stage in [
        {"kind": "gain", "gain_db": 0},
        {"kind": "resample", "target_rate_hz": 16000},
        {"kind": "split_join", "segment_ms": 701},
    ]:
        output, _ = execute_stage(audio, stage)
        assert decode_wav(output).metadata()["duration_ms"] == seconds * 1000
        assert len(output) <= MAX_FILE_BYTES


@pytest.mark.parametrize("gain_db", [-60, -8.25, 0, 6.0])
def test_gain_matches_db_amplitude_and_preserves_input(gain_db: float) -> None:
    original, audio = _development_audio()
    expected_samples = audio.samples * 10.0 ** (gain_db / 20.0)
    output, info = execute_stage(audio, {"kind": "gain", "gain_db": gain_db, "label": "gain development"})
    assert output == encode_wav(expected_samples, audio.sample_rate_hz)
    assert decode_wav(output).samples.size == audio.samples.size
    assert encode_wav(audio.samples, audio.sample_rate_hz) == original
    assert audio.sha256 == hashlib.sha256(original).hexdigest()
    assert info == {
        "kind": "gain",
        "parameters": {"gain_db": float(gain_db)},
        "declared_comparison": {
            "profile": "basic", "allow_gain": True, "allow_resampling": False, "max_delay_ms": 1000.0,
        },
    }
    if gain_db == 0:
        assert output == original


def test_maximum_gain_applies_exact_amplitude_scale_when_output_fits() -> None:
    values = np.tile(np.array([-0.0625, 0, 0.03125, 0.0625]), 4000)
    audio = decode_wav(encode_wav(values, 8000))
    output, _ = execute_stage(audio, {"kind": "gain", "gain_db": 20})
    np.testing.assert_array_equal(decode_wav(output).samples, audio.samples * 10)


@pytest.mark.parametrize("value", [-1.0, -0.75, 0.75, 32767 / 32768])
def test_gain_rejects_out_of_range_without_clipping(value: float) -> None:
    audio = decode_wav(encode_wav(np.full(16000, value), 8000))
    original_samples = audio.samples.copy()
    with pytest.raises(PipelineTransformError) as caught:
        execute_stage(audio, {"kind": "gain", "gain_db": 6})
    assert caught.value.code == "invalid_samples"
    np.testing.assert_array_equal(audio.samples, original_samples)


def test_resample_rejects_filter_overshoot_without_clipping() -> None:
    values = np.tile(np.array([-1.0, -1.0, 32767 / 32768, 32767 / 32768]), 4000)
    audio = decode_wav(encode_wav(values, 8000))
    expected = resample_poly(audio.samples, 2, 1)
    assert np.max(np.abs(expected)) > 1.0
    with pytest.raises(PipelineTransformError) as caught:
        execute_stage(audio, {"kind": "resample", "target_rate_hz": 16000})
    assert caught.value.code == "invalid_samples"


@pytest.mark.parametrize("rate", RATES)
@pytest.mark.parametrize("segment_ms", [200, 701, 30000])
def test_default_split_join_preserves_all_pcm_bytes_and_last_short_chunk(rate: int, segment_ms: int) -> None:
    original, audio = _development_audio(rate)
    output, info = execute_stage(audio, {"kind": "split_join", "segment_ms": segment_ms})
    assert output == original
    assert hashlib.sha256(output).hexdigest() == audio.sha256
    np.testing.assert_array_equal(decode_wav(output).samples, audio.samples)
    assert info == {
        "kind": "split_join",
        "parameters": {"segment_ms": segment_ms},
        "declared_comparison": {
            "profile": "basic", "allow_gain": False, "allow_resampling": False, "max_delay_ms": 1000.0,
        },
    }


def test_explicit_order_reorders_exact_chunks_including_short_remainder() -> None:
    original, audio = _development_audio(44100, 3 * 44100 + 17)
    segment_ms = 701
    chunk_length = round(44100 * segment_ms / 1000)
    chunks = [audio.samples[start : start + chunk_length] for start in range(0, audio.samples.size, chunk_length)]
    assert chunks[-1].size < chunk_length
    order = list(reversed(range(len(chunks))))
    stage = {"kind": "split_join", "segment_ms": segment_ms, "order": order, "label": "reverse development chunks"}
    output, info = execute_stage(audio, stage)
    assert output == encode_wav(np.concatenate([chunks[index] for index in order]), 44100)
    assert output != original
    assert info["parameters"] == {"segment_ms": segment_ms, "order": order}
    assert not info["declared_comparison"]["allow_gain"]
    assert not info["declared_comparison"]["allow_resampling"]
    assert info["declared_comparison"]["profile"] == "basic"
    order.append(0)
    assert len(info["parameters"]["order"]) == len(chunks)
    assert encode_wav(audio.samples, 44100) == original


@pytest.mark.parametrize("order", [[0, 0, 2], [3, 1, 2]])
def test_explicit_omission_and_repetition_are_exact_assembly_instructions(order: list[int]) -> None:
    _, audio = _development_audio(8000, 4 * 8000)
    chunks = [audio.samples[start : start + 8000] for start in range(0, audio.samples.size, 8000)]
    output, info = execute_stage(audio, {"kind": "split_join", "segment_ms": 1000, "order": order})
    assert output == encode_wav(np.concatenate([chunks[index] for index in order]), 8000)
    assert decode_wav(output).samples.size == 3 * 8000
    assert info["declared_comparison"] == {
        "profile": "basic", "allow_gain": False, "allow_resampling": False, "max_delay_ms": 1000.0,
    }


@pytest.mark.parametrize("order", [[4], [10**100], [0, 4]])
def test_out_of_bounds_order_rejected_based_on_actual_input(order: list[int]) -> None:
    _, audio = _development_audio(8000, 4 * 8000)
    with pytest.raises(PipelineTransformError) as caught:
        execute_stage(audio, {"kind": "split_join", "segment_ms": 1000, "order": order})
    assert caught.value.code == "invalid_order"


@pytest.mark.parametrize("order", [[], [0], [0] * 31, [0] * 2000])
def test_order_cardinality_rejected_without_trimming_or_adaptation(order: list[int]) -> None:
    _, audio = _development_audio(8000, 4 * 8000)
    with pytest.raises(PipelineTransformError) as caught:
        execute_stage(audio, {"kind": "split_join", "segment_ms": 1000, "order": order})
    assert caught.value.code == "invalid_duration"


@pytest.mark.parametrize("copies", [2, 30])
def test_explicit_order_inclusive_output_duration_bounds(copies: int) -> None:
    _, audio = _development_audio(8000, 4 * 8000)
    output, _ = execute_stage(audio, {"kind": "split_join", "segment_ms": 1000, "order": [0] * copies})
    assert decode_wav(output).samples.size == copies * 8000


@pytest.mark.parametrize("audio", [None, np.zeros(16000), b"RIFF", {"samples": []}])
def test_execute_requires_validated_wav_audio(audio) -> None:
    with pytest.raises(PipelineTransformError) as caught:
        execute_stage(audio, {"kind": "gain", "gain_db": 0})
    assert caught.value.code == "invalid_audio"


def test_execute_validates_spec_before_using_audio() -> None:
    _, audio = _development_audio()
    with pytest.raises(PipelineTransformError) as caught:
        execute_stage(audio, {"kind": "gain", "gain_db": True})
    assert caught.value.code == "invalid_stage"
