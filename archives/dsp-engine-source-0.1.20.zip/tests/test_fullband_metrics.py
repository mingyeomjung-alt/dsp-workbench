"""Native-rate metric mathematics against new generated PCM and small DFTs."""

import cmath
import hashlib
import json
import math

import numpy as np
import pytest

from audio_regression.audio import WavAudio
from audio_regression.fullband_metrics import (
    BAND_EDGES_HZ,
    FRAME_DURATION_MS,
    FullbandMetricError,
    _spectral_bands,
    measure_audio,
    measure_pair,
)


RATES = [8000, 16000, 44100, 48000]
AUDIO_KEYS = {
    "dc_offset", "mean_square", "rms_dbfs", "peak_dbfs", "crest_factor",
    "rail_sample_count", "rail_sample_fraction", "longest_same_rail_run_samples",
    "bands", "frame_size_samples", "frames",
}
BAND_KEYS = {
    "lower_hz", "upper_hz", "effective_upper_hz", "upper_inclusive",
    "status", "mean_square", "power_fraction",
}
PAIR_KEYS = {
    "status", "reason_code", "unequal_sample_count", "first_changed_sample",
    "last_changed_sample", "maximum_abs_error_pcm16", "mean_square_error",
    "signal_to_residual_db", "signal_to_residual_status", "correlation",
    "correlation_status", "residual_bands", "changed_frames",
}


def _audio(pcm, rate=8000) -> WavAudio:
    pcm = np.asarray(pcm, dtype=np.int32)
    assert pcm.ndim == 1 and np.all(pcm >= -32768) and np.all(pcm <= 32767)
    return WavAudio(
        samples=pcm.astype(np.float64) / 32768.0,
        sample_rate_hz=rate,
        sha256=hashlib.sha256(pcm.astype("<i2").tobytes()).hexdigest(),
    )


def _pattern(pattern, rate=8000, count=None) -> WavAudio:
    count = 2 * rate if count is None else count
    pcm = np.resize(np.asarray(pattern, dtype=np.int32), count)
    return _audio(pcm, rate)


def _forged(samples=None, rate=8000, digest="a" * 64, readonly=True) -> WavAudio:
    value = object.__new__(WavAudio)
    if samples is None:
        samples = np.zeros(16000, dtype=np.float64)
    if type(samples) is np.ndarray and readonly:
        samples.flags.writeable = False
    object.__setattr__(value, "samples", samples)
    object.__setattr__(value, "sample_rate_hz", rate)
    object.__setattr__(value, "sha256", digest)
    return value


def _assert_invalid(value) -> None:
    for call in (lambda: measure_audio(value), lambda: measure_pair(value, _pattern([0])), lambda: measure_pair(_pattern([0]), value)):
        with pytest.raises(FullbandMetricError) as caught:
            call()
        assert caught.value.code == "invalid_audio"
        assert "private" not in str(caught.value)
        assert "caller-secret" not in str(caught.value)


def _direct_band_oracle(values, rate):
    """Scalar complete-record DFT: independent of NumPy FFT implementation."""
    count = len(values)
    powers = []
    centers = []
    for k in range(count // 2 + 1):
        coefficient = sum(
            value * cmath.exp(-2j * math.pi * k * index / count)
            for index, value in enumerate(values)
        )
        weight = 1 if k == 0 or (count % 2 == 0 and k == count // 2) else 2
        powers.append(weight * abs(coefficient) ** 2 / count ** 2)
        centers.append(k * rate / count)
    totals = []
    for lower, upper in zip(BAND_EDGES_HZ[:-1], BAND_EDGES_HZ[1:]):
        if lower >= rate / 2:
            totals.append(None)
            continue
        effective = min(upper, rate / 2)
        total = sum(
            power for power, center in zip(powers, centers)
            if center >= lower and (center <= effective if effective == rate / 2 else center < effective)
        )
        totals.append(total)
    denominator = sum(total for total in totals if total is not None)
    return totals, denominator


def _assert_bands(bands, rate, direct_mean_square):
    assert len(bands) == 8
    for index, band in enumerate(bands):
        assert set(band) == BAND_KEYS
        lower, upper = BAND_EDGES_HZ[index:index + 2]
        assert band["lower_hz"] == lower and band["upper_hz"] == upper
        if lower >= rate / 2:
            assert band == {
                "lower_hz": lower, "upper_hz": upper,
                "effective_upper_hz": None, "upper_inclusive": False,
                "status": "not_available", "mean_square": None, "power_fraction": None,
            }
        else:
            assert band["status"] == "available"
            assert band["effective_upper_hz"] == min(upper, rate / 2)
            assert band["upper_inclusive"] is (band["effective_upper_hz"] == rate / 2)
            assert band["mean_square"] >= 0
            assert 0 <= band["power_fraction"] <= 1
    available = [band for band in bands if band["status"] == "available"]
    assert sum(band["mean_square"] for band in available) == pytest.approx(direct_mean_square, rel=1e-12, abs=1e-27)
    if direct_mean_square == 0:
        assert all(band["power_fraction"] == 0 for band in available)
    else:
        assert sum(band["power_fraction"] for band in available) == pytest.approx(1, abs=1e-14)


@pytest.mark.parametrize("rate", RATES)
@pytest.mark.parametrize("values", [
    [0] * 8,
    [0.25] * 8,
    [0.25, -0.25] * 4,
    [0, 0.5, 0, -0.5] * 2,
    [0.0, 0.125, -0.5, 0.25, 0.75, -0.125, 0.0],
    [1.5, -1.5, 0.0, 0.25, -0.25, 0.75, -0.5, 0.125, 0.0],
])
def test_even_odd_dft_weighting_matches_independent_scalar_oracle(rate, values):
    values_array = np.asarray(values, dtype=np.float64)
    result = _spectral_bands(values_array, rate)
    oracle, denominator = _direct_band_oracle(values, rate)
    _assert_bands(result, rate, sum(value * value for value in values) / len(values))
    for band, expected in zip(result, oracle):
        if expected is not None:
            assert band["mean_square"] == pytest.approx(expected, rel=1e-12, abs=1e-27)
            assert band["power_fraction"] == pytest.approx(expected / denominator if denominator else 0, abs=1e-13)


@pytest.mark.parametrize("rate", RATES)
@pytest.mark.parametrize("extra", [0, 1, 37])
def test_native_frames_partition_all_samples_and_weighted_energy(rate, extra):
    audio = _pattern([0, 120, -320, 400, -1000, 32767, -32768], rate, 2 * rate + extra)
    result = measure_audio(audio)
    assert set(result) == AUDIO_KEYS
    assert FRAME_DURATION_MS == 100
    assert result["frame_size_samples"] == rate // 10
    frames = result["frames"]
    assert len(frames) == 20 + bool(extra)
    cursor = 0
    weighted_power = 0
    for frame in frames:
        assert set(frame) == {"start_sample", "end_sample", "mean_square", "peak"}
        assert frame["start_sample"] == cursor
        assert 1 <= frame["end_sample"] - cursor <= rate // 10
        segment = audio.samples[cursor:frame["end_sample"]]
        assert frame["mean_square"] == pytest.approx(sum(float(x) ** 2 for x in segment) / len(segment), rel=1e-12)
        assert frame["peak"] == max(abs(float(x)) for x in segment)
        weighted_power += frame["mean_square"] * len(segment)
        cursor = frame["end_sample"]
    assert cursor == len(audio.samples)
    assert weighted_power / cursor == pytest.approx(result["mean_square"], rel=1e-12)
    _assert_bands(result["bands"], rate, result["mean_square"])
    assert json.loads(json.dumps(result, allow_nan=False)) == result


@pytest.mark.parametrize("rate", RATES)
@pytest.mark.parametrize("pcm", [0, 1, -1, 8192, -8192, 32767, -32768])
def test_constant_record_dc_dbfs_crest_and_undefined_silence(rate, pcm):
    audio = _pattern([pcm], rate)
    result = measure_audio(audio)
    linear = pcm / 32768
    assert result["dc_offset"] == linear
    assert result["mean_square"] == linear ** 2
    if pcm:
        assert result["rms_dbfs"] == pytest.approx(20 * math.log10(abs(linear)), abs=1e-12)
        assert result["peak_dbfs"] == pytest.approx(result["rms_dbfs"], abs=1e-12)
        assert result["crest_factor"] == 1
        assert result["bands"][0]["power_fraction"] == pytest.approx(1)
    else:
        assert result["rms_dbfs"] is None and result["peak_dbfs"] is None
        assert result["crest_factor"] is None
    rail = pcm in (-32768, 32767)
    assert result["rail_sample_count"] == (2 * rate if rail else 0)
    assert result["rail_sample_fraction"] == (1 if rail else 0)
    assert result["longest_same_rail_run_samples"] == (2 * rate if rail else 0)
    _assert_bands(result["bands"], rate, linear ** 2)


@pytest.mark.parametrize("rate", RATES)
def test_nyquist_bin_belongs_only_to_preceding_available_band(rate):
    result = measure_audio(_pattern([8192, -8192], rate))
    bands = result["bands"]
    active = next(index for index, band in enumerate(bands) if band["status"] == "available" and band["upper_inclusive"])
    assert bands[active]["mean_square"] == pytest.approx(0.25 ** 2, abs=1e-15)
    assert bands[active]["power_fraction"] == pytest.approx(1, abs=1e-15)
    assert all(band["mean_square"] == pytest.approx(0, abs=1e-27) for index, band in enumerate(bands) if index != active and band["status"] == "available")
    assert sum(band["upper_inclusive"] for band in bands) == 1


@pytest.mark.parametrize("rate,expected_band", [(8000, 4), (16000, 5), (44100, 6), (48000, 6)])
def test_exact_quarter_rate_tone_band_edges_not_double_counted(rate, expected_band):
    result = measure_audio(_pattern([0, 8192, 0, -8192], rate))
    assert result["mean_square"] == 0.03125
    assert result["bands"][expected_band]["mean_square"] == pytest.approx(0.03125, abs=1e-15)
    assert result["bands"][expected_band]["power_fraction"] == pytest.approx(1, abs=1e-15)


@pytest.mark.parametrize("head,tail,longest,rails", [
    ([32767] * 3, [-32768] * 5, 5, 8),
    ([32767, -32768] * 3, [0], 1, 6),
    ([-32768] * 4, [-32768] * 2, 4, 6),
    ([32766, -32767] * 3, [0], 0, 0),
])
def test_endpoint_runs_keep_opposite_signs_and_intervening_nonrail_separate(head, tail, longest, rails):
    pcm = np.zeros(16000, dtype=np.int32)
    pcm[:len(head)] = head
    pcm[-len(tail):] = tail
    result = measure_audio(_audio(pcm))
    assert result["rail_sample_count"] == rails
    assert result["rail_sample_fraction"] == rails / len(pcm)
    assert result["longest_same_rail_run_samples"] == longest


@pytest.mark.parametrize("rate", RATES)
def test_one_lsb_final_partial_frame_and_pair_change_are_not_lost(rate):
    count = 2 * rate + 1
    zero = _pattern([0], rate, count)
    pcm = np.zeros(count, dtype=np.int32)
    pcm[-1] = 1
    one = _audio(pcm, rate)
    result = measure_audio(one)
    assert result["mean_square"] == pytest.approx(1 / (32768 ** 2 * count), rel=1e-12)
    assert result["frames"][-1] == {
        "start_sample": count - 1, "end_sample": count,
        "mean_square": 1 / 32768 ** 2, "peak": 1 / 32768,
    }
    pair = measure_pair(zero, one)
    assert pair["first_changed_sample"] == pair["last_changed_sample"] == count - 1
    assert pair["unequal_sample_count"] == pair["maximum_abs_error_pcm16"] == 1
    assert pair["mean_square_error"] == result["mean_square"]
    assert pair["signal_to_residual_status"] == "zero_reference"
    assert pair["signal_to_residual_db"] is None
    assert pair["changed_frames"] == [{"start_sample": count - 1, "end_sample": count, "unequal_sample_count": 1}]


@pytest.mark.parametrize("pattern", [[0], [1], [-32768], [1, -1, 2, -2], [100, 101, 100, 101]])
def test_identity_zero_residual_and_constant_correlation_semantics(pattern):
    audio = _pattern(pattern)
    pair = measure_pair(audio, audio)
    assert set(pair) == PAIR_KEYS
    assert pair["status"] == "measured" and pair["reason_code"] is None
    assert pair["unequal_sample_count"] == 0
    assert pair["maximum_abs_error_pcm16"] == pair["mean_square_error"] == 0
    assert pair["first_changed_sample"] is None and pair["last_changed_sample"] is None
    assert pair["signal_to_residual_status"] == "zero_residual"
    assert pair["signal_to_residual_db"] is None and pair["changed_frames"] == []
    if len(set(pattern)) == 1:
        assert pair["correlation_status"] == "constant_signal" and pair["correlation"] is None
    else:
        assert pair["correlation_status"] == "defined" and pair["correlation"] == pytest.approx(1, abs=1e-15)
    _assert_bands(pair["residual_bands"], 8000, 0)
    assert json.loads(json.dumps(pair, allow_nan=False)) == pair


@pytest.mark.parametrize("reference,processed,status,expected_db", [
    ([0], [1], "zero_reference", None),
    ([8192], [16384], "finite", 0),
    ([-8192], [8192], "finite", -10 * math.log10(4)),
    ([8192, -8192], [8193, -8191], "finite", 20 * math.log10(8192)),
    ([1, -1], [32767, -32768], "finite", 10 * math.log10(1 / ((32766 ** 2 + 32767 ** 2) / 2))),
])
def test_signal_to_residual_is_file_difference_ratio_not_environment_snr(reference, processed, status, expected_db):
    pair = measure_pair(_pattern(reference), _pattern(processed))
    assert pair["signal_to_residual_status"] == status
    if expected_db is None:
        assert pair["signal_to_residual_db"] is None
    else:
        assert pair["signal_to_residual_db"] == pytest.approx(expected_db, abs=1e-12)
    assert "snr" not in pair and "noise_level" not in pair


@pytest.mark.parametrize("rate", RATES)
def test_int32_residual_cannot_wrap_full_rail_difference(rate):
    left = _pattern([-32768, 32767], rate)
    right = _pattern([32767, -32768], rate)
    pair = measure_pair(left, right)
    assert pair["maximum_abs_error_pcm16"] == 65535
    assert pair["mean_square_error"] == (65535 / 32768) ** 2
    assert pair["unequal_sample_count"] == 2 * rate
    assert pair["first_changed_sample"] == 0 and pair["last_changed_sample"] == 2 * rate - 1
    assert pair["correlation_status"] == "defined" and pair["correlation"] == pytest.approx(-1, abs=1e-15)
    _assert_bands(pair["residual_bands"], rate, pair["mean_square_error"])


@pytest.mark.parametrize("rate", [44100, 48000])
def test_high_frequency_only_difference_is_preserved_on_original_sample_grid(rate):
    count = 2 * rate
    pcm = np.resize(np.asarray([512, 0, -512, 0], dtype=np.int32), count)
    high = np.resize(np.asarray([128, -128], dtype=np.int32), count)
    pair = measure_pair(_audio(pcm, rate), _audio(pcm + high, rate))
    assert pair["unequal_sample_count"] == count
    assert pair["maximum_abs_error_pcm16"] == 128
    assert pair["mean_square_error"] == (128 / 32768) ** 2
    assert pair["residual_bands"][-1]["power_fraction"] == pytest.approx(1, abs=1e-15)
    assert all(band["mean_square"] == pytest.approx(0, abs=1e-27) for band in pair["residual_bands"] if band["upper_hz"] <= 8000)


@pytest.mark.parametrize("multiplier,offset,expected_correlation", [(1, 100, 1), (2, 0, 1), (-1, 0, -1)])
def test_pearson_correlation_does_not_imply_identical_audio(multiplier, offset, expected_correlation):
    pcm = np.resize(np.asarray([1000, -1000, 2000, -2000], dtype=np.int32), 16000)
    pair = measure_pair(_audio(pcm), _audio(pcm * multiplier + offset))
    assert pair["correlation"] == pytest.approx(expected_correlation, abs=1e-15)
    assert pair["correlation_status"] == "defined"
    assert pair["unequal_sample_count"] > 0 and pair["mean_square_error"] > 0
    assert pair["status"] == "measured"
    assert "complete_audio_approval" not in pair


@pytest.mark.parametrize("left,right,reason", [
    (_pattern([0], 8000), _pattern([0], 16000), "sample_rate_mismatch"),
    (_pattern([0], 8000, 32000), _pattern([0], 16000, 32000), "sample_rate_mismatch"),
    (_pattern([0], 8000, 16000), _pattern([0], 8000, 16001), "sample_count_mismatch"),
])
def test_mismatched_geometry_withholds_all_pair_numbers_without_alignment(left, right, reason):
    pair = measure_pair(left, right)
    assert set(pair) == PAIR_KEYS
    assert pair["status"] == "withheld" and pair["reason_code"] == reason
    assert pair["signal_to_residual_status"] == pair["correlation_status"] == "not_comparable"
    for key in PAIR_KEYS - {"status", "reason_code", "signal_to_residual_status", "correlation_status"}:
        assert pair[key] is None
    assert measure_audio(left)["mean_square"] == measure_audio(right)["mean_square"] == 0


@pytest.mark.parametrize("rate", RATES)
def test_sparse_changed_frame_locations_are_native_indices_and_exact_counts(rate):
    count = 2 * rate + 13
    left = _pattern([32, -32], rate, count)
    pcm = (left.samples * 32768).astype(np.int32)
    changes = [0, rate // 10 - 1, rate // 10, 7 * rate // 10 + 5, count - 1]
    pcm[changes] += 1
    pair = measure_pair(left, _audio(pcm, rate))
    assert pair["unequal_sample_count"] == 5
    assert pair["first_changed_sample"] == 0 and pair["last_changed_sample"] == count - 1
    assert pair["changed_frames"] == [
        {"start_sample": 0, "end_sample": rate // 10, "unequal_sample_count": 2},
        {"start_sample": rate // 10, "end_sample": 2 * rate // 10, "unequal_sample_count": 1},
        {"start_sample": 7 * rate // 10, "end_sample": 8 * rate // 10, "unequal_sample_count": 1},
        {"start_sample": 2 * rate, "end_sample": count, "unequal_sample_count": 1},
    ]
    assert sum(frame["unequal_sample_count"] for frame in pair["changed_frames"]) == 5
    assert pair["mean_square_error"] == pytest.approx(5 / (32768 ** 2 * count), rel=1e-12)


@pytest.mark.parametrize("rate", RATES)
def test_complete_measurements_are_deterministic_finite_json_and_leave_sources_immutable(rate):
    rng = np.random.default_rng(202610145 + rate)
    pcm = rng.integers(-32768, 32768, size=2 * rate + 3, dtype=np.int32)
    left = _audio(pcm, rate)
    right = _audio(np.roll(pcm, 1), rate)
    before = (left.samples.tobytes(), right.samples.tobytes(), left.sha256, right.sha256)
    single = measure_audio(left)
    pair = measure_pair(left, right)
    assert measure_audio(left) == single and measure_pair(left, right) == pair
    assert json.loads(json.dumps({"single": single, "pair": pair}, allow_nan=False)) == {"single": single, "pair": pair}
    assert before == (left.samples.tobytes(), right.samples.tobytes(), left.sha256, right.sha256)
    assert left.samples.flags.writeable is False and right.samples.flags.writeable is False


def test_maximum_30_second_48khz_record_has_bounded_frames_and_unpadded_fft(monkeypatch):
    count = 30 * 48000
    audio = _pattern([0, 1, -1, 32767, -32768], 48000, count)
    calls = []
    original = np.fft.rfft

    def observed(values, *args, **kwargs):
        calls.append((values.size, args, kwargs))
        return original(values, *args, **kwargs)

    monkeypatch.setattr(np.fft, "rfft", observed)
    result = measure_audio(audio)
    assert calls == [(count, (), {})]
    assert len(result["frames"]) == 300
    assert result["frames"][-1]["end_sample"] == count
    assert result["frame_size_samples"] == 4800
    _assert_bands(result["bands"], 48000, result["mean_square"])


@pytest.mark.parametrize("value", [None, False, 1, [], {}, "caller-secret/private/path", np.zeros(16000)])
def test_reject_non_audio_objects_without_conversion(value):
    _assert_invalid(value)


@pytest.mark.parametrize("rate", [True, False, 8000.0, np.int64(8000), "8000", 0, 11025, 96000])
def test_recheck_forged_rate_exact_types_and_supported_set(rate):
    _assert_invalid(_forged(rate=rate))


@pytest.mark.parametrize(
    "digest",
    [None, True, 1, "A" * 64, "a" * 63, "a" * 65, "g" * 64, "a" * 64 + "\n", "caller-secret/private/path", "a" * 1000000],
    ids=["none", "bool", "int", "uppercase", "short", "long", "nonhex", "newline", "private", "oversized"],
)
def test_recheck_forged_digest_without_echoing_private_content(digest):
    _assert_invalid(_forged(digest=digest))


@pytest.mark.parametrize("samples", [
    np.zeros(16000, dtype=np.float32),
    np.zeros(16000, dtype=np.int16),
    np.zeros(16000, dtype=np.complex128),
    np.zeros((16000, 1), dtype=np.float64),
    np.zeros(15999, dtype=np.float64),
    np.zeros(240001, dtype=np.float64),
    np.asarray([0.0] * 15999 + [float("nan")]),
    np.asarray([0.0] * 15999 + [float("inf")]),
    np.asarray([0.0] * 15999 + [-float("inf")]),
    np.asarray([0.0] * 15999 + [1.0]),
    np.asarray([0.0] * 15999 + [-1.00001]),
    np.asarray([0.0] * 15999 + [1 / 65536]),
    [], None,
])
def test_recheck_forged_sample_shape_grid_range_and_finiteness(samples):
    if samples is None:
        value = object.__new__(WavAudio)
        object.__setattr__(value, "samples", None)
        object.__setattr__(value, "sample_rate_hz", 8000)
        object.__setattr__(value, "sha256", "a" * 64)
        _assert_invalid(value)
    else:
        _assert_invalid(_forged(samples=samples))


def test_reject_forged_writable_input_without_copy_normalization():
    _assert_invalid(_forged(readonly=False))


def test_reject_missing_fields_and_exact_type_subclasses():
    _assert_invalid(object.__new__(WavAudio))

    class DerivedAudio(WavAudio):
        pass

    _assert_invalid(DerivedAudio(samples=np.zeros(16000), sample_rate_hz=8000, sha256="a" * 64))

    class DangerousObject:
        def __array__(self, *args):
            raise AssertionError("must not coerce")

        def __repr__(self):
            raise AssertionError("must not echo")

    _assert_invalid(DangerousObject())


def test_numerically_inconsistent_fft_is_rejected_not_exported(monkeypatch):
    monkeypatch.setattr(np.fft, "rfft", lambda values: np.zeros(values.size // 2 + 1, dtype=np.complex128))
    with pytest.raises(FullbandMetricError) as caught:
        measure_audio(_pattern([1, -1]))
    assert caught.value.code == "numerical_measurement_error"


def test_error_code_default_and_safe_optional_message():
    error = FullbandMetricError("fixed_code")
    assert error.code == error.message == str(error) == "fixed_code"
    error = FullbandMetricError("fixed_code", "Fixed public explanation.")
    assert error.code == "fixed_code" and str(error) == "Fixed public explanation."
