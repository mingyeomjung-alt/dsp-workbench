"""Static saved-result reporting tests; no detector or evaluation corpus."""

import copy
from html.parser import HTMLParser
import json

import pytest

from audio_regression.check_policy import check_result
from audio_regression.saved_pipeline_reporting import (
    SavedPipelineContractError, load_saved_pipeline_result,
    render_saved_pipeline_html, write_saved_pipeline_html,
)


def metadata(letter="a", duration_ms=6000.0):
    return {"sample_rate_hz": 16000, "sample_count": round(duration_ms * 16),
            "duration_ms": duration_ms, "channels": 1, "encoding": "pcm16",
            "rms": .05, "peak": .2, "sha256": letter * 64}


def analysis(reference, processed, kind="clean"):
    events = []
    if kind == "delete":
        events = [{"type": "delete", "reference_interval_ms": [2000., 2400.],
                   "processed_boundary_ms": 2000.,
                   "evidence": {"boundary_correlation": .99, "offset_before_ms": 0.,
                                "offset_after_ms": -400.}}]
    elif kind == "repeat":
        events = [{"type": "repeat", "reference_source_interval_ms": [2000., 2400.],
                   "processed_added_interval_ms": [2400., 2800.],
                   "copy_interval_convention": "canonical_later_adjacent_copy_not_edit_provenance",
                   "evidence": {"boundary_correlation": .99, "copy_correlation": .99,
                                "adjacent_copy_correlation": .99, "offset_before_ms": 0.,
                                "offset_after_ms": 400.}}]
    value = {
        "schema_version": 1, "engine": "local_content_alignment_v1", "status": "analyzed",
        "content_preservation_status": "defect_candidates" if events else "no_supported_defect_candidates",
        "reason_code": None, "events": events, "complete_audio_approval": False,
        "commercial_performance_validated": False,
        "reference": copy.deepcopy(reference), "processed": copy.deepcopy(processed),
        "configuration": {"profile": "basic", "allow_gain": True,
                          "allow_resampling": False, "max_delay_ms": 1000.},
        "analysis": {"sample_rate_hz": 8000, "hop_ms": 10.,
                     "method": "constrained_edit_alignment_with_raw_anchors",
                     "minimum_event_duration_ms": 200, "maximum_cumulative_edit_shift_ms": 2000,
                     "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {"normalized_path_cost": .01, "gain_estimate": 1., "applied_gain": 1.,
                        "matched_normalized_rmse": .001, "matched_analysis_samples": 40000,
                        "anchor_run_count": 1, "minimum_local_correlation": .99},
        "limitations": ["전체 음질은 평가 범위 밖"],
        "alignment_segments": [{"reference_interval_ms": [0., 2000.], "processed_offset_ms": 0.,
                                "anchor_correlations": [.99, .99, .99]}],
    }
    if kind == "withheld":
        value.update(status="withheld", content_preservation_status="withheld", events=None,
                     reason_code="insufficient_unambiguous_anchors")
        value.pop("alignment_segments")
    return value


def concern(stage=None, category="execution_error"):
    return {"scope": "stage" if stage else "end_to_end",
            "stage_index": stage["index"] if stage else None,
            "stage_label": stage["label"] if stage else None, "category": category}


def fixture(kind="clean"):
    source = metadata()
    duration = {"delete": 5600., "repeat": 6400.}.get(kind, 6000.)
    outputs = [metadata("b", duration), metadata("c", duration)]
    stages = []
    previous = source
    for index, output in enumerate(outputs, 1):
        saved = analysis(previous, output, kind if index == 1 else "clean")
        stages.append({
            "index": index, "label": f"외부 처리 {index}",
            "declaration": {"profile": "basic", "allow_gain": True,
                            "allow_resampling": False, "max_delay_ms": 1000.},
            "input": copy.deepcopy(previous), "output": output,
            "input_snapshot": f"inputs/{index - 1:03d}.wav", "output_snapshot": f"inputs/{index:03d}.wav",
            "status": saved["status"], "analysis": saved, "check": check_result(saved),
            "reason_code": saved["reason_code"], "analysis_artifact": f"stages/{index:03d}/analysis.json",
            "check_artifact": f"stages/{index:03d}/check.json", "runtime_ms": 12.5,
        })
        previous = output
    end = analysis(source, outputs[-1], kind if kind in {"delete", "repeat"} else "clean")
    code = {"clean": 0, "delete": 1, "repeat": 1, "withheld": 2}[kind]
    first = (None if kind == "clean" else concern(
        stages[0], "withheld" if kind == "withheld" else "defect_candidates",
    ))
    return {
        "schema_version": 1, "engine": "audio_saved_pipeline_audit_v1", "status": "completed",
        "comparison_scope": "adjacent_stage_checks_and_end_to_end", "source": source, "stages": stages,
        "end_to_end": {"status": end["status"], "analysis": end, "check": check_result(end),
                       "analysis_artifact": "end_to_end/analysis.json", "check_artifact": "end_to_end/check.json"},
        "input_recheck": {"status": "unchanged", "file_indices": []},
        "summary": {"gate_state": {0: "clear_supported_temporal_check", 1: "review_required", 2: "blocked"}[code],
                    "exit_code": code, "first_concern": first, "planned_stage_count": 2,
                    "checked_stage_count": 2, "failed_stage": None},
        "complete_audio_approval": False, "commercial_performance_validated": False,
        "network_used": False, "fault_provenance_confirmed": False, "caller_order_verified": False,
    }


def failed_fixture():
    value = fixture()
    stage, tail = value["stages"]
    error = {"schema_version": 1, "status": "error", "reason_code": "analysis_failed"}
    stage.update(status="error", analysis=error, check=check_result(error), reason_code=error["reason_code"],
                 analysis_artifact="stages/001/error.json", check_artifact="stages/001/error_check.json")
    tail.update(status="not_run", analysis=None, check=None, analysis_artifact=None, check_artifact=None,
                reason_code="prior_stage_analysis_error", runtime_ms=0.)
    value.update(status="incomplete", end_to_end=None)
    value["summary"].update(gate_state="blocked", exit_code=2, first_concern=concern(stage),
                             checked_stage_count=1, failed_stage=1)
    return value


def recheck_fixture(status, prior="clean"):
    value = fixture(prior)
    reason = {"changed": "input_files_changed", "unavailable": "input_files_recheck_failed"}[status]
    error = {"schema_version": 1, "status": "error", "reason_code": reason}
    value.update(status="incomplete", input_recheck={"status": status, "file_indices": [0, 2]})
    value["end_to_end"].update(status="error", analysis=error, check=check_result(error),
                                analysis_artifact="end_to_end/error.json", check_artifact="end_to_end/error_check.json")
    value["summary"].update(gate_state="blocked", exit_code=2)
    value["summary"]["first_concern"] = value["summary"]["first_concern"] or concern()
    return value


class Tags(HTMLParser):
    def __init__(self, html):
        super().__init__()
        self.elements = []
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        self.elements.append((tag, dict(attrs)))


@pytest.mark.parametrize("kind", ["clean", "delete", "repeat", "withheld"])
def test_supported_saved_results_render_without_losing_scope(kind):
    value = fixture(kind)
    html = render_saved_pipeline_html(value)
    assert html == render_saved_pipeline_html(value)
    assert "저장된 DSP 단계 비교 보고서" in html and "검사 완료" in html
    assert "제출 순서는 검증되지 않았습니다" in html and "caller_order_verified: false" in html
    assert "기본 파이프라인 실행기와 다릅니다" in html
    assert "분석 전에 수집한 스냅샷" in html and "전체 음질 승인" in html
    assert "complete_audio_approval: false" in html and "보정된 확률" in html
    assert "처음 관찰된 지점은 결함 원인 확정이 아닙니다" in html
    assert "별도 검사 · 원본 → 최종 제출 출력" in html
    assert "inputs/000.wav" in html and "inputs/002.wav" in html
    assert value["source"]["sha256"] in html
    for stage in value["stages"]:
        assert stage["input"]["sha256"] in html and stage["output"]["sha256"] in html
    if kind == "delete":
        assert "삭제 후보" in html and "2,000–2,400 ms" in html
    elif kind == "repeat":
        assert "반복 후보" in html and "2,400–2,800 ms" in html
    elif kind == "withheld":
        assert "insufficient_unambiguous_anchors" in html


def test_failure_shows_retained_snapshot_metadata_and_not_run_tail():
    value = failed_fixture()
    html = render_saved_pipeline_html(value)
    assert "검사 미완료" in html and "분석 오류" in html and "미분석" in html
    assert "앞선 분석 오류로 이 비교는 수행되지 않았습니다" in html
    assert "최종 제출 출력 비교를 수행하지 않았습니다" in html
    assert value["stages"][1]["output"]["sha256"] in html
    assert "analysis_failed" in html


@pytest.mark.parametrize("status,label", [
    ("changed", "수집 후 입력 변경 감지 · 차단"),
    ("unavailable", "입력 재확인 불가 · 차단"),
])
def test_input_recheck_failure_is_prominent_and_blocked(status, label):
    value = recheck_fixture(status)
    html = render_saved_pipeline_html(value)
    assert "검사 미완료" in html and label in html
    assert "000, 002" in html and "입력 재확인 기록" in html
    assert value["end_to_end"]["analysis"]["reason_code"] in html
    assert "원본 → 최종 제출 출력 비교" in html


def test_prior_candidate_remains_earliest_when_recheck_blocks_later():
    value = recheck_fixture("changed", "delete")
    html = render_saved_pipeline_html(value)
    assert "외부 처리 1" in html and "시간적 결함 후보" in html
    assert value["summary"]["first_concern"]["stage_index"] == 1
    assert "input_files_changed" in html


def test_later_clear_does_not_erase_earliest_reported_candidate():
    value = fixture("delete")
    assert value["stages"][1]["check"]["exit_code"] == 0
    html = render_saved_pipeline_html(value)
    assert '<strong>01 단계 · 외부 처리 1</strong>' in html
    assert "앞선 우려는 뒤 단계의 결과로 지워지지 않습니다" in html


def test_static_html_escapes_labels_and_has_no_active_or_remote_content():
    value = fixture("delete")
    payload = '<script>alert("한글 &")</script><svg onload="x">'
    value["stages"][0]["label"] = payload
    value["summary"]["first_concern"]["stage_label"] = payload
    html = render_saved_pipeline_html(value)
    assert payload not in html and "&lt;script&gt;" in html and "한글 &amp;" in html
    assert "default-src 'none'" in html and "base-uri 'none'" in html and "form-action 'none'" in html
    assert 'charset="utf-8"' in html and 'lang="ko"' in html
    tags = Tags(html).elements
    assert not any(tag in {"a", "script", "iframe", "audio", "video", "img", "link", "object", "embed", "form"}
                   for tag, _ in tags)
    assert not any(key.startswith("on") or key in {"href", "src"} for _, attrs in tags for key in attrs)
    assert html.count("<!doctype html>") == 1 and html.count("<html ") == 1
    assert "PASS" not in html


def test_absolute_paths_inside_labels_are_suppressed():
    value = fixture()
    value["stages"][0]["label"] = r"단계 C:\private\secret.wav /home/private/voice.wav"
    html = render_saved_pipeline_html(value)
    assert "C:\\private" not in html and "/home/private" not in html
    assert "[로컬 경로 생략]" in html and "단계" in html


@pytest.mark.parametrize("mutate", [
    lambda r: r.update(schema_version=2),
    lambda r: r.update(caller_order_verified=True),
    lambda r: r.update(complete_audio_approval=True),
    lambda r: r["summary"].update(first_concern=None, exit_code=0, gate_state="clear_supported_temporal_check"),
    lambda r: r["stages"][0]["check"].update(exit_code=0),
    lambda r: r["stages"][0].update(output_snapshot="C:/private/source.wav"),
    lambda r: r["stages"][0].update(analysis_artifact="../private.json"),
])
def test_invalid_saved_result_is_rejected_before_output(tmp_path, mutate):
    value = fixture("delete")
    mutate(value)
    with pytest.raises(SavedPipelineContractError):
        render_saved_pipeline_html(value)
    path = tmp_path / "invalid.html"
    with pytest.raises(SavedPipelineContractError):
        write_saved_pipeline_html(value, path)
    assert not path.exists()


def test_exclusive_write_preserves_existing_file(tmp_path):
    path = tmp_path / "report.html"
    value = fixture()
    write_saved_pipeline_html(value, path)
    before = path.read_bytes()
    assert before == render_saved_pipeline_html(value).encode("utf-8")
    with pytest.raises(FileExistsError):
        write_saved_pipeline_html(fixture("delete"), path)
    assert path.read_bytes() == before


def test_reporting_and_loader_do_not_analyze_audio_or_follow_artifacts(tmp_path, monkeypatch):
    from audio_regression import api, audio, engine

    def forbidden(*args, **kwargs):
        pytest.fail("Saved report attempted audio loading or analysis.")

    monkeypatch.setattr(api, "analyze_pair", forbidden)
    monkeypatch.setattr(audio, "read_wav", forbidden)
    monkeypatch.setattr(audio, "decode_wav", forbidden)
    monkeypatch.setattr(engine, "analyze_buffers", forbidden)
    monkeypatch.setattr(engine, "analyze_wavs", forbidden)
    value = fixture("repeat")
    path = tmp_path / "saved.json"
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    assert not (tmp_path / "inputs").exists()
    loaded = load_saved_pipeline_result(path)
    assert loaded == value
    rendered = render_saved_pipeline_html(loaded)
    assert "반복 후보" in rendered
    assert not (tmp_path / "inputs").exists()


@pytest.mark.parametrize("data", [b'{"schema_version":1,"schema_version":1}', b'{"x":NaN}', b'\xff', b'{'])
def test_imported_strict_loader_rejects_malformed_json(tmp_path, data):
    path = tmp_path / "invalid.json"
    path.write_bytes(data)
    with pytest.raises(SavedPipelineContractError):
        load_saved_pipeline_result(path)


def test_missing_error_artifacts_are_reported_not_read():
    value = failed_fixture()
    value["stages"][0].update(analysis_artifact=None, check_artifact=None)
    html = render_saved_pipeline_html(value)
    assert "미생성" in html and "판단 보류 또는 분석·입력 오류" in html
