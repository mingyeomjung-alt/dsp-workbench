"""Opt-in v6 public routes on owned analytic fixtures, not sealed recordings."""

from copy import deepcopy
import json
from pathlib import Path

import numpy as np
import pytest

from audio_regression import api, cli, handoff_cli, pipeline_cli
from audio_regression import pipeline_runner as native, saved_pipeline as saved
from audio_regression.engine import EngineConfigError
from audio_regression.fixtures import generate_case
from audio_regression.pipeline_reporting import (
    PipelineReportError, render_pipeline_html, validate_pipeline_result,
)
from audio_regression.reporting import render_html
from audio_regression.repeat_result_contract import ENGINE, METHOD
from audio_regression.result_contract import ResultContractError, validate_analysis_result
from audio_regression.saved_pipeline_contract import (
    SavedPipelineContractError, validate_saved_pipeline_result,
)
from audio_regression.saved_pipeline_reporting import render_saved_pipeline_html


def _source(tmp_path, kind="clean"):
    case = generate_case(kind, seed=202610136)
    reference, output = tmp_path / "reference.wav", tmp_path / "output.wav"
    reference.write_bytes(case.reference_wav)
    output.write_bytes(case.processed_wav)
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps({"schema_version": 1, "source": "reference.wav", "stages": [
        {"label": "first", "output": "output.wav", "declaration": {
            "allow_gain": False, "allow_resampling": False}},
        {"label": "second", "output": "output.wav", "declaration": {
            "allow_gain": False, "allow_resampling": False}},
    ]}), encoding="utf-8")
    return reference, output, manifest


@pytest.mark.parametrize("kind", ["clean", "delete", "repeat"])
def test_v6_public_facade_is_explicit_and_keeps_input_unchanged(tmp_path, kind):
    reference, output, _ = _source(tmp_path, kind)
    before = reference.read_bytes(), output.read_bytes()
    assert api.analyze_pair(reference, output)["engine"] == "local_content_alignment_v1"
    result, trace = api.analyze_pair_with_trace(reference, output, engine="v6")
    assert result == api.analyze_pair(reference, output, engine="v6")
    assert result["engine"] == trace["analysis_engine"] == ENGINE
    assert result["analysis"]["method"] == METHOD
    assert trace["reference_sha256"] == result["reference"]["sha256"]
    assert trace["processed_sha256"] == result["processed"]["sha256"]
    assert validate_analysis_result(result) is result
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    assert before == (reference.read_bytes(), output.read_bytes())


@pytest.mark.parametrize("profile", ["telephone", "missing", None, True, np.array(["basic", "telephone"])])
def test_v6_profile_failure_happens_before_audio_read(tmp_path, profile):
    for facade in (api.analyze_pair, api.analyze_pair_with_trace):
        with pytest.raises(EngineConfigError):
            facade(tmp_path / "missing", tmp_path / "missing2", engine="v6", profile=profile)


@pytest.mark.parametrize("engine", [None, 6, True, "v13", ["v6"], np.array(["v6"])])
def test_invalid_engine_failure_happens_before_audio_read(tmp_path, engine):
    for facade in (api.analyze_pair, api.analyze_pair_with_trace):
        with pytest.raises(EngineConfigError):
            facade(tmp_path / "missing", tmp_path / "missing2", engine=engine)


@pytest.mark.parametrize("kind,code", [("clean", 0), ("delete", 1), ("repeat", 1)])
def test_v6_console_analysis_check_report_and_no_overwrite(tmp_path, capsys, kind, code):
    reference, output, _ = _source(tmp_path, kind)
    path = tmp_path / "analysis.json"
    args = ["analyze", "--reference", str(reference), "--processed", str(output),
            "--engine", "v6", "--output", str(path)]
    assert handoff_cli.main(args) == 0
    assert json.loads(capsys.readouterr().out)["engine"] == ENGINE
    assert handoff_cli.main(["check", "--input", str(path)]) == code
    assert json.loads(capsys.readouterr().out)["complete_audio_approval"] is False
    html = tmp_path / "report.html"
    assert handoff_cli.main(["report", "--input", str(path), "--output", str(html)]) == 0
    capsys.readouterr()
    document = html.read_text(encoding="utf-8")
    assert "v6 · 선택한 개선 후보" in document and "전체 복사와 전역 대체 원본" in document
    before = path.read_bytes()
    assert handoff_cli.main(args) == 3
    capsys.readouterr()
    assert path.read_bytes() == before


@pytest.mark.parametrize("mode", ["native", "saved"])
def test_v6_pipeline_preserves_review_after_later_clear_and_stored_report(tmp_path, monkeypatch, mode):
    reference, _, manifest = _source(tmp_path, "repeat")
    if mode == "native":
        order = list(range(10)) + [8, 9] + list(range(10, 30))
        result = native.run_pipeline(reference, [
            {"kind": "split_join", "segment_ms": 200, "order": order},
            {"kind": "gain", "gain_db": 0},
        ], tmp_path / "new", engine="v6")
        validator, render = validate_pipeline_result, render_pipeline_html
    else:
        result = saved.audit_saved_pipeline(manifest, tmp_path / "new", engine="v6")
        validator, render = validate_saved_pipeline_result, render_saved_pipeline_html
    validator(result)
    assert result["engine"].endswith("_v6")
    assert result["summary"]["exit_code"] == 1
    assert result["summary"]["first_concern"]["stage_index"] == 1
    assert result["stages"][1]["check"]["exit_code"] == 0
    assert all(stage["analysis"]["engine"] == ENGINE for stage in result["stages"])
    assert result["complete_audio_approval"] is False

    def forbidden(*args, **kwargs):
        pytest.fail("Stored HTML must not analyze audio or load a trace.")

    monkeypatch.setattr(api, "analyze_pair_with_trace", forbidden)
    html = render(result)
    assert "v6 · 선택한 실험 후보" in html
    assert "전체 복사·전역 대체 원본" in html
    assert "전체 음질 승인이나 상용 성능 검증이 아닙니다" in html
    assert "<script" not in html and "<a " not in html


@pytest.mark.parametrize("mode", ["native", "saved"])
@pytest.mark.parametrize("scope", ["stage", "end_to_end"])
def test_v6_trace_write_failure_stays_blocked_and_preserves_audio(tmp_path, monkeypatch, mode, scope):
    reference, output, manifest = _source(tmp_path)
    before = reference.read_bytes(), output.read_bytes()
    module = native if mode == "native" else saved
    writer = module._new_json

    def fault(path, value):
        if path.name == "trace.json" and (scope == "stage" or path.parent.name == "end_to_end"):
            error = native.PipelineRunError if mode == "native" else saved.SavedPipelineError
            raise error("output_write_error")
        return writer(path, value)

    monkeypatch.setattr(module, "_new_json", fault)
    folder = tmp_path / "new"
    result = (native.run_pipeline(reference, [{"kind": "gain", "gain_db": -3}] * 2, folder, engine="v6")
              if mode == "native" else saved.audit_saved_pipeline(manifest, folder, engine="v6"))
    (validate_pipeline_result if mode == "native" else validate_saved_pipeline_result)(result)
    assert result["status"] == "incomplete" and result["summary"]["gate_state"] == "blocked"
    if scope == "stage":
        assert result["stages"][1]["status"] == "not_run"
    else:
        assert all(stage["status"] == "analyzed" for stage in result["stages"])
        assert (folder / "stages/001/trace.json").is_file()
    assert before == (reference.read_bytes(), output.read_bytes())


@pytest.mark.parametrize("mode", ["native", "saved"])
def test_v6_pipeline_rejects_mixed_nested_engine(tmp_path, mode):
    reference, _, manifest = _source(tmp_path)
    result = (native.run_pipeline(reference, [{"kind": "gain", "gain_db": -3}], tmp_path / "new", engine="v6")
              if mode == "native" else saved.audit_saved_pipeline(manifest, tmp_path / "new", engine="v6"))
    value = deepcopy(result)
    value["stages"][0]["analysis"]["engine"] = "local_content_alignment_v5"
    value["stages"][0]["analysis"]["analysis"]["method"] = "exact_canonical_pcm_resampling_with_unique_context"
    validator = validate_pipeline_result if mode == "native" else validate_saved_pipeline_result
    error = PipelineReportError if mode == "native" else SavedPipelineContractError
    with pytest.raises(error) as caught:
        validator(value)
    assert caught.value.code == "inconsistent_analysis_engine"


@pytest.mark.parametrize("mutation", ["method", "approval", "profile", "position", "anchors", "coverage", "anchor_count"])
def test_v6_contract_rejects_fabricated_identity_and_evidence(tmp_path, mutation):
    reference, output, _ = _source(tmp_path)
    result = api.analyze_pair(reference, output, engine="v6")
    value = deepcopy(result)
    if mutation == "method":
        value["analysis"]["method"] = "made_up"
    elif mutation == "approval":
        value["complete_audio_approval"] = True
    elif mutation == "profile":
        value["configuration"]["profile"] = "telephone"
    elif mutation == "position":
        value["alignment_segments"][0]["reference_interval_ms"][1] = 99999
    elif mutation == "anchors":
        value["alignment_segments"][0]["anchor_correlations"] = [.99, .99]
    elif mutation == "coverage":
        value["diagnostics"]["matched_analysis_samples"] = 1599
    else:
        value["diagnostics"]["anchor_run_count"] += 1
    with pytest.raises(ResultContractError):
        validate_analysis_result(value)


def test_v6_schema_identity_and_cli_defaults_are_explicit():
    root = Path(__file__).parents[1] / "src/audio_regression/schemas"
    schema = json.loads((root / "analysis-result-v6.schema.json").read_text(encoding="utf-8"))
    assert schema["$id"].endswith(":v6")
    assert ENGINE in json.dumps(schema) and METHOD in json.dumps(schema)
    assert cli._parser().parse_args(["analyze", "--reference", "a", "--processed", "b"]).engine == "v1"
    for command, args in [
        ("run", ["--source", "a", "--plan", "p", "--output-dir", "out"]),
        ("audit", ["--manifest", "m", "--output-dir", "out"]),
    ]:
        assert pipeline_cli._parser().parse_args([command, *args]).engine == "v1"
        assert pipeline_cli._parser().parse_args([command, *args, "--engine", "v6"]).engine == "v6"


def test_v6_stored_error_remains_blocked_and_has_no_probability():
    from audio_regression.check_policy import check_result

    error = {"schema_version": 1, "engine": ENGINE, "status": "error", "reason_code": "input_error"}
    assert validate_analysis_result(error) is error
    check = check_result(error)
    assert check["exit_code"] == 2 and check["probability_claims"] is False
    html = render_html(error)
    assert "v6 · 선택한 개선 후보" in html and "자동 판단 차단" in html
