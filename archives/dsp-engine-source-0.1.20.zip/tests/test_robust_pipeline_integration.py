import json

import numpy as np
import pytest

from audio_regression import api, pipeline_cli
from audio_regression import pipeline_runner as native_runner, saved_pipeline as saved_runner
from audio_regression.engine import EngineConfigError
from audio_regression.fixtures import generate_case
from audio_regression.pipeline_reporting import validate_pipeline_result
from audio_regression.pipeline_runner import PipelineRunError, run_pipeline
from audio_regression.saved_pipeline import SavedPipelineError, audit_saved_pipeline
from audio_regression.saved_pipeline_contract import validate_saved_pipeline_result


def _files(tmp_path, kind="clean"):
    case = generate_case(kind, seed=66321)
    ref, out = tmp_path / "reference.wav", tmp_path / "output.wav"
    ref.write_bytes(case.reference_wav)
    out.write_bytes(case.processed_wav)
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps({"schema_version": 1, "source": "reference.wav", "stages": [
        {"label": "저장 출력", "output": "output.wav", "declaration": {"allow_gain": False, "allow_resampling": False}}
    ]}), encoding="utf-8")
    return ref, out, manifest


@pytest.mark.parametrize("kind", ["clean", "delete", "repeat"])
def test_explicit_engine_is_versioned_and_default_stays_v1(tmp_path, kind):
    ref, out, manifest = _files(tmp_path, kind)
    baseline = api.analyze_pair(ref, out)
    candidate, trace = api.analyze_pair_with_trace(ref, out, engine="v2")
    assert baseline["engine"] == "local_content_alignment_v1"
    assert candidate["engine"] == "local_content_alignment_v2"
    assert candidate["complete_audio_approval"] is False
    assert trace["analysis_engine"] == candidate["engine"]
    assert trace["reference_sha256"] == candidate["reference"]["sha256"]
    assert trace["processed_sha256"] == candidate["processed"]["sha256"]
    assert api.analyze_pair_with_trace(ref, out)[1] is None
    assert ref.read_bytes() == generate_case(kind, seed=66321).reference_wav


@pytest.mark.parametrize("engine", [None, True, 2, "unknown", "local_content_alignment_v2"])
def test_invalid_engine_is_rejected_before_inputs_or_output(tmp_path, engine):
    with pytest.raises(EngineConfigError):
        api.analyze_pair(tmp_path / "missing", tmp_path / "missing2", engine=engine)
    with pytest.raises(EngineConfigError):
        api.analyze_pair_with_trace(tmp_path / "missing", tmp_path / "missing2", engine=engine)
    with pytest.raises(PipelineRunError, match="invalid_engine"):
        run_pipeline(tmp_path / "missing", [], tmp_path / "native", engine=engine)
    with pytest.raises(SavedPipelineError, match="invalid_engine"):
        audit_saved_pipeline(tmp_path / "missing", tmp_path / "saved", engine=engine)
    assert not (tmp_path / "native").exists()
    assert not (tmp_path / "saved").exists()


def test_array_engine_is_rejected_without_ambiguous_comparison(tmp_path):
    for facade in (api.analyze_pair, api.analyze_pair_with_trace):
        with pytest.raises(EngineConfigError):
            facade(tmp_path / "missing", tmp_path / "missing2", engine=np.array(["v1", "v2"]))


def test_candidate_nonbasic_profile_rejected_before_read(tmp_path):
    with pytest.raises(EngineConfigError):
        api.analyze_pair(tmp_path / "missing", tmp_path / "missing2", engine="v2", profile="telephone")


def test_saved_cli_records_candidate_and_trace_files(tmp_path, capsys):
    ref, _, manifest = _files(tmp_path, "delete")
    output = tmp_path / "saved_v2"
    assert pipeline_cli.main(["audit", "--manifest", str(manifest), "--output-dir", str(output), "--engine", "v2"]) == 1
    summary = json.loads(capsys.readouterr().out)
    assert summary["engine"] == "audio_saved_pipeline_audit_v2"
    assert summary["first_concern"]["stage_index"] == 1
    result = json.loads((output / "audit_result.json").read_text(encoding="utf-8"))
    assert all(stage["analysis"]["engine"] == "local_content_alignment_v2" for stage in result["stages"])
    assert (output / "stages/001/trace.json").is_file()
    assert (output / "end_to_end/trace.json").is_file()
    assert "v2" in (output / "audit_report.html").read_text(encoding="utf-8")


def test_native_cli_records_candidate_and_keeps_review_sticky(tmp_path, capsys):
    ref, _, _ = _files(tmp_path)
    plan = tmp_path / "plan.json"
    order = [index for index in range(15) if index != 5]
    plan.write_text(json.dumps({"schema_version": 1, "stages": [
        {"kind": "split_join", "segment_ms": 400, "order": order},
        {"kind": "gain", "gain_db": -6},
    ]}), encoding="utf-8")
    output = tmp_path / "native_v2"
    assert pipeline_cli.main(["run", "--source", str(ref), "--plan", str(plan), "--output-dir", str(output), "--engine", "v2"]) == 1
    summary = json.loads(capsys.readouterr().out)
    assert summary["engine"] == "audio_pipeline_regression_v2"
    assert summary["first_concern"]["stage_index"] == 1
    result = json.loads((output / "run_result.json").read_text(encoding="utf-8"))
    assert result["stages"][1]["check"]["exit_code"] == 0
    assert result["summary"]["exit_code"] == 1
    assert (output / "stages/002/trace.json").is_file()


def test_stored_candidate_report_never_runs_detector_again(tmp_path, capsys, monkeypatch):
    _, _, manifest = _files(tmp_path)
    output = tmp_path / "saved_v2"
    assert pipeline_cli.main(["audit", "--manifest", str(manifest), "--output-dir", str(output), "--engine", "v2"]) == 0
    capsys.readouterr()

    def forbidden(*args, **kwargs):
        pytest.fail("Stored v2 report must not execute the engine.")

    monkeypatch.setattr(api, "analyze_pair_with_trace", forbidden)
    report = tmp_path / "new.html"
    assert pipeline_cli.main(["audit-report", "--input", str(output / "audit_result.json"), "--output", str(report)]) == 0
    assert json.loads(capsys.readouterr().out)["status"] == "generated_saved_pipeline_html"


@pytest.mark.parametrize("mode", ["native", "saved"])
@pytest.mark.parametrize("scope", ["stage", "end_to_end"])
def test_trace_persistence_failure_blocks_without_losing_inputs(tmp_path, monkeypatch, mode, scope):
    reference, output_file, manifest_path = _files(tmp_path)
    original = reference.read_bytes(), output_file.read_bytes()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["stages"].append({**manifest["stages"][0], "label": "second"})
    manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
    module = native_runner if mode == "native" else saved_runner
    writer = module._new_json
    exception = PipelineRunError if mode == "native" else SavedPipelineError

    def fault(path, value):
        relative = path.as_posix()
        if path.name == "trace.json" and (scope == "stage" or "/end_to_end/" in relative):
            raise exception("output_write_error")
        return writer(path, value)

    monkeypatch.setattr(module, "_new_json", fault)
    directory = tmp_path / (mode + "_fault")
    if mode == "native":
        result = run_pipeline(reference, [{"kind": "gain", "gain_db": -3},
                                          {"kind": "gain", "gain_db": -3}], directory, engine="v2")
        validate_pipeline_result(result)
    else:
        result = audit_saved_pipeline(manifest_path, directory, engine="v2")
        validate_saved_pipeline_result(result)
        assert result["input_recheck"]["status"] == "unchanged"
    assert result["status"] == "incomplete"
    assert result["summary"]["gate_state"] == "blocked"
    assert result["summary"]["exit_code"] == 2
    if scope == "stage":
        assert result["stages"][0]["status"] == "error"
        assert result["stages"][0]["analysis"]["reason_code"] == "output_write_error"
        assert result["stages"][1]["status"] == "not_run"
        assert result["summary"]["first_concern"]["stage_index"] == 1
    else:
        assert all(stage["status"] == "analyzed" for stage in result["stages"])
        assert result["end_to_end"]["status"] == "error"
        assert result["end_to_end"]["analysis"]["reason_code"] == "output_write_error"
        assert result["summary"]["first_concern"]["scope"] == "end_to_end"
        assert (directory / "stages/001/trace.json").is_file()
    assert reference.read_bytes() == original[0]
    assert output_file.read_bytes() == original[1]
    assert (directory / "manifest_started.json").is_file()


@pytest.mark.parametrize("command", ["run", "audit"])
def test_candidate_cli_preflight_error_identifies_selected_engine(tmp_path, capsys, command):
    if command == "run":
        args = ["run", "--source", str(tmp_path / "missing.wav"), "--plan", str(tmp_path / "missing.json")]
    else:
        args = ["audit", "--manifest", str(tmp_path / "missing.json")]
    assert pipeline_cli.main(args + ["--output-dir", str(tmp_path / "none"), "--engine", "v2"]) == 3
    result = json.loads(capsys.readouterr().out)
    assert result["engine"].endswith("_v2")
    assert result["gate_state"] == "blocked"
    assert not (tmp_path / "none").exists()
