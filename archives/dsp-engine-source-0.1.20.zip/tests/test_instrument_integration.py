"""V4 opt-in facade and fail-closed persistence checks on new synthetic audio."""

import json

import numpy as np
import pytest

from audio_regression import api, cli, handoff_cli, pipeline_cli
from audio_regression import pipeline_runner as native, saved_pipeline as saved
from audio_regression.engine import EngineConfigError
from audio_regression.fixtures import generate_case
from audio_regression.pipeline_reporting import (
    PipelineReportError, render_pipeline_html, validate_pipeline_result,
)
from audio_regression.saved_pipeline_contract import (
    SavedPipelineContractError, validate_saved_pipeline_result,
)
from audio_regression.saved_pipeline_reporting import render_saved_pipeline_html


def _source(tmp_path, kind="clean"):
    case = generate_case(kind, seed=415137)
    reference, output = tmp_path / "reference.wav", tmp_path / "output.wav"
    reference.write_bytes(case.reference_wav)
    output.write_bytes(case.processed_wav)
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps({"schema_version": 1, "source": "reference.wav", "stages": [
        {"label": "first", "output": "output.wav", "declaration": {"allow_gain": False, "allow_resampling": False}},
        {"label": "second", "output": "output.wav", "declaration": {"allow_gain": False, "allow_resampling": False}},
    ]}), encoding="utf-8")
    return reference, output, manifest


@pytest.mark.parametrize("kind", ["clean", "delete", "repeat"])
def test_v4_is_explicit_and_default_remains_v1(tmp_path, kind):
    reference, output, _ = _source(tmp_path, kind)
    before = reference.read_bytes(), output.read_bytes()
    assert api.analyze_pair(reference, output)["engine"] == "local_content_alignment_v1"
    result, trace = api.analyze_pair_with_trace(reference, output, engine="v4")
    assert result == api.analyze_pair(reference, output, engine="v4")
    assert result["engine"] == trace["analysis_engine"] == "local_content_alignment_v4"
    assert trace["reference_sha256"] == result["reference"]["sha256"]
    assert trace["processed_sha256"] == result["processed"]["sha256"]
    assert result["complete_audio_approval"] is False
    assert before == (reference.read_bytes(), output.read_bytes())


@pytest.mark.parametrize("profile", ["telephone", "missing", None, True, np.array(["basic", "telephone"])])
def test_v4_profile_failure_happens_before_read(tmp_path, profile):
    for facade in (api.analyze_pair, api.analyze_pair_with_trace):
        with pytest.raises(EngineConfigError):
            facade(tmp_path / "missing", tmp_path / "missing2", engine="v4", profile=profile)


def test_v4_analyze_command_and_handoff_reports(tmp_path, capsys):
    reference, output, _ = _source(tmp_path)
    path = tmp_path / "analysis.json"
    assert handoff_cli.main(["analyze", "--reference", str(reference), "--processed", str(output),
                             "--engine", "v4", "--output", str(path)]) == 0
    assert json.loads(capsys.readouterr().out)["engine"] == "local_content_alignment_v4"
    assert json.loads(path.read_text(encoding="utf-8"))["engine"] == "local_content_alignment_v4"
    html = tmp_path / "report.html"
    assert handoff_cli.main(["report", "--input", str(path), "--output", str(html)]) == 0
    capsys.readouterr()
    assert "선택형 연구 엔진" in html.read_text(encoding="utf-8")
    assert cli._parser().parse_args(["analyze", "--reference", "a", "--processed", "b"]).engine == "v1"


@pytest.mark.parametrize("mode", ["native", "saved"])
@pytest.mark.parametrize("scope", ["stage", "end_to_end"])
def test_v4_trace_write_failure_is_blocked_and_preserves_input(tmp_path, monkeypatch, mode, scope):
    reference, output, manifest = _source(tmp_path)
    before = reference.read_bytes(), output.read_bytes()
    module = native if mode == "native" else saved
    writer = module._new_json

    def fault(path, value):
        if path.name == "trace.json" and (scope == "stage" or path.parent.name == "end_to_end"):
            raise module.PipelineRunError("output_write_error") if mode == "native" else module.SavedPipelineError("output_write_error")
        return writer(path, value)

    monkeypatch.setattr(module, "_new_json", fault)
    folder = tmp_path / "new"
    result = (native.run_pipeline(reference, [{"kind": "gain", "gain_db": -3}] * 2, folder, engine="v4")
              if mode == "native" else saved.audit_saved_pipeline(manifest, folder, engine="v4"))
    (validate_pipeline_result if mode == "native" else validate_saved_pipeline_result)(result)
    assert result["engine"].endswith("_v4")
    assert result["status"] == "incomplete"
    assert result["summary"]["gate_state"] == "blocked"
    if scope == "stage":
        assert result["stages"][1]["status"] == "not_run"
    else:
        assert all(stage["status"] == "analyzed" for stage in result["stages"])
        assert (folder / "stages/001/trace.json").is_file()
    assert before == (reference.read_bytes(), output.read_bytes())


@pytest.mark.parametrize("kind,expected", [("clean", 0), ("delete", 1), ("repeat", 1)])
def test_v4_saved_cli_sticky_state_and_no_reanalysis_report(tmp_path, capsys, monkeypatch, kind, expected):
    _, _, manifest = _source(tmp_path, kind)
    folder = tmp_path / "new"
    assert pipeline_cli.main(["audit", "--manifest", str(manifest), "--output-dir", str(folder), "--engine", "v4"]) == expected
    assert json.loads(capsys.readouterr().out)["engine"] == "audio_saved_pipeline_audit_v4"
    result = json.loads((folder / "audit_result.json").read_text(encoding="utf-8"))
    assert all(stage["analysis"]["engine"] == "local_content_alignment_v4" for stage in result["stages"])
    if kind != "clean":
        assert result["summary"]["first_concern"]["stage_index"] == 1
        assert result["stages"][1]["check"]["exit_code"] == 0

    def forbidden(*args, **kwargs):
        pytest.fail("A stored report must not reanalyze audio.")

    monkeypatch.setattr(api, "analyze_pair_with_trace", forbidden)
    report = tmp_path / "stored.html"
    assert pipeline_cli.main(["audit-report", "--input", str(folder / "audit_result.json"), "--output", str(report)]) == 0
    capsys.readouterr()
    html = report.read_text(encoding="utf-8")
    assert "v4 · 선택한 실험 후보" in html
    assert "원시 파형 랜드마크·전역 유일성" in html
    assert "전체 음질 승인이나 상용 성능 검증이 아닙니다" in html
    assert "<script" not in html and "<a " not in html


@pytest.mark.parametrize("saved_mode", [False, True])
def test_v4_pipeline_rejects_mixed_nested_v3_result(tmp_path, saved_mode):
    reference, _, manifest = _source(tmp_path)
    result = (saved.audit_saved_pipeline(manifest, tmp_path / "new", engine="v4") if saved_mode
              else native.run_pipeline(reference, [{"kind": "gain", "gain_db": -3}], tmp_path / "new", engine="v4"))
    render = render_saved_pipeline_html if saved_mode else render_pipeline_html
    assert "v4 · 선택한 실험 후보" in render(result)
    nested = result["stages"][0]["analysis"]
    nested["engine"] = "local_content_alignment_v3"
    nested["analysis"]["method"] = "constrained_edit_alignment_with_bounded_active_context_bridge"
    validator = validate_saved_pipeline_result if saved_mode else validate_pipeline_result
    error = SavedPipelineContractError if saved_mode else PipelineReportError
    with pytest.raises(error) as caught:
        validator(result)
    assert caught.value.code == "inconsistent_analysis_engine"
