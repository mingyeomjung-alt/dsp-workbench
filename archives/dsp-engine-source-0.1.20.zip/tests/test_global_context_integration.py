"""Opt-in v9 public routes on new owned equations, never sealed recordings.

These are implementation and stored-contract checks, not independent music
accuracy, provenance, customer utility or commercial performance evidence.
"""

from copy import deepcopy
import json
from pathlib import Path

import numpy as np
import pytest
from scipy.signal import resample_poly

from audio_regression import api, cli, handoff_cli, pipeline_cli
from audio_regression import pipeline_runner as native, saved_pipeline as saved
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.check_policy import check_result
from audio_regression.global_context_result_contract import ENGINE, METHOD
from audio_regression.engine import EngineConfigError
from audio_regression.fixtures import generate_case
from audio_regression.pipeline_reporting import (
    PipelineReportError, render_pipeline_html, validate_pipeline_result,
)
from audio_regression.reporting import render_html
from audio_regression.result_contract import ResultContractError, validate_analysis_result
from audio_regression.saved_pipeline_contract import (
    SavedPipelineContractError, validate_saved_pipeline_result,
)
from audio_regression.saved_pipeline_reporting import render_saved_pipeline_html


def _source(tmp_path, kind="clean"):
    case = generate_case(kind, seed=202610149)
    reference, output = tmp_path / "reference.wav", tmp_path / "output.wav"
    reference.write_bytes(case.reference_wav)
    output.write_bytes(case.processed_wav)
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps({"schema_version": 1, "source": "reference.wav", "stages": [
        {"label": "first", "output": "output.wav", "declaration": {
            "allow_gain": False, "allow_resampling": False}},
        {"label": "second", "output": "output.wav", "declaration": {
            "allow_gain": False, "allow_resampling": False}},
    ]}), encoding="utf-8")
    return reference, output, manifest


def _compound_source(tmp_path, kind, delay=1920):
    """A newly specified nonperiodic equation, including a nonzero quiet tail."""
    rate = 16000
    time = np.arange(9 * rate, dtype=float) / rate
    phase = 2 * np.pi * (347 * time + 23 * time * time + .19 * np.sin(2.3 * time))
    loud = .16 * (np.sin(phase) + .24 * np.sin(1.57 * phase + .41)
                  + .17 * np.sin(2.37 * phase - .31)) * (.68 + .27 * np.sin(.97 * time) ** 2)
    quiet = .55 / 32768 * np.sin(2 * np.pi * (2630 * time + 13 * time * time))
    raw = encode_wav(np.where(time < 7, loud, quiet), rate)
    source = decode_wav(raw)
    first, last = 48000, 57600
    if kind == "delete":
        edited = np.concatenate((source.samples[:first], source.samples[last:]))
    elif kind == "repeat":
        edited = np.concatenate((source.samples[:last], source.samples[first:last], source.samples[last:]))
    else:
        edited = source.samples
    gained = decode_wav(encode_wav(edited * 10 ** (-6 / 20), rate))
    downsampled = decode_wav(encode_wav(resample_poly(gained.samples, 1, 2), 8000))
    output = encode_wav(np.concatenate((np.zeros(delay), downsampled.samples)), 8000)
    reference, processed = tmp_path / "compound_reference.wav", tmp_path / "compound_output.wav"
    reference.write_bytes(raw)
    processed.write_bytes(output)
    return reference, processed


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_v9_compound_event_reaches_public_api_with_trace_and_unchanged_inputs(tmp_path, kind):
    reference, processed = _compound_source(tmp_path, kind)
    before = reference.read_bytes(), processed.read_bytes()
    flags = {"allow_gain": True, "allow_resampling": True}
    baseline = api.analyze_pair(reference, processed, engine="v8", **flags)
    assert baseline["status"] == "analyzed"
    result, trace = api.analyze_pair_with_trace(reference, processed, engine="v9", **flags)
    assert result == api.analyze_pair(reference, processed, engine="v9", **flags)
    assert result["engine"] == ENGINE and result["analysis"]["method"] == METHOD
    assert result["status"] == "analyzed" and len(result["events"]) == 1
    assert result["events"][0]["type"] == kind
    assert len(result["alignment_segments"]) == 2
    assert trace["proof_path"] == "preserved_v8_result"
    assert trace["inherited_v8_trace"]["compound_event_proved"] is True
    assert trace["reference_sha256"] == result["reference"]["sha256"]
    assert trace["processed_sha256"] == result["processed"]["sha256"]
    assert validate_analysis_result(result) is result
    assert check_result(result)["exit_code"] == 1
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    assert set(result["configuration"]) == {"profile", "allow_gain", "allow_resampling", "max_delay_ms"}
    event = result["events"][0]
    if kind == "delete":
        assert event["reference_interval_ms"] == [3000, 3600]
        assert event["processed_boundary_ms"] == 3240
    else:
        assert event["reference_source_interval_ms"] == [3000, 3600]
        assert event["processed_added_interval_ms"] == [3840, 4440]
    assert before == (reference.read_bytes(), processed.read_bytes())


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_v9_compound_event_console_check_requires_review_and_report_is_inert(tmp_path, capsys, kind):
    reference, processed = _compound_source(tmp_path, kind)
    output = tmp_path / "compound.json"
    args = ["analyze", "--reference", str(reference), "--processed", str(processed),
            "--engine", "v9", "--declare-gain", "--declare-resampling", "--output", str(output)]
    assert handoff_cli.main(args) == 0
    capsys.readouterr()
    result = json.loads(output.read_text(encoding="utf-8"))
    assert result["status"] == "analyzed" and len(result["events"]) == 1
    assert handoff_cli.main(["check", "--input", str(output)]) == 1
    assert json.loads(capsys.readouterr().out)["complete_audio_approval"] is False
    html = tmp_path / "compound.html"
    assert handoff_cli.main(["report", "--input", str(output), "--output", str(html)]) == 0
    capsys.readouterr()
    document = html.read_text(encoding="utf-8")
    assert "전역 문맥 정합" in document
    assert "사건 후보는 검토 필요이며 정상 통과가 아닙니다" in document
    assert "<script" not in document and "<a " not in document
    before = output.read_bytes()
    assert handoff_cli.main(args) == 3
    capsys.readouterr()
    assert output.read_bytes() == before


@pytest.mark.parametrize("kind", ["delete", "repeat"])
@pytest.mark.parametrize("mode", ["native", "saved"])
def test_v9_compound_event_reaches_end_to_end_pipeline_with_two_segments(tmp_path, mode, kind):
    reference, processed = _compound_source(tmp_path, kind)
    folder = tmp_path / "new_pipeline"
    if mode == "native":
        order = list(range(15))
        if kind == "delete":
            del order[5]
        else:
            order.insert(6, 5)
        result = native.run_pipeline(reference, [
            {"kind": "split_join", "segment_ms": 600, "order": order},
            {"kind": "gain", "gain_db": -6},
            {"kind": "resample", "target_rate_hz": 8000},
            {"kind": "gain", "gain_db": 0},
        ], folder, engine="v9")
        validator = validate_pipeline_result
    else:
        manifest = tmp_path / "compound_manifest.json"
        manifest.write_text(json.dumps({"schema_version": 1, "source": reference.name, "stages": [
            {"label": "compound", "output": processed.name, "declaration": {
                "allow_gain": True, "allow_resampling": True}},
            {"label": "unchanged", "output": processed.name, "declaration": {
                "allow_gain": False, "allow_resampling": False}},
        ]}), encoding="utf-8")
        result = saved.audit_saved_pipeline(manifest, folder, engine="v9")
        validator = validate_saved_pipeline_result
    validator(result)
    assert result["status"] == "completed"
    end = result["end_to_end"]["analysis"]
    assert end["engine"] == ENGINE and end["status"] == "analyzed"
    assert len(end["events"]) == 1 and end["events"][0]["type"] == kind
    assert len(end["alignment_segments"]) == 2
    assert result["end_to_end"]["check"]["exit_code"] == 1
    assert result["summary"]["exit_code"] == 1
    assert result["summary"]["first_concern"] is not None
    assert result["stages"][-1]["check"]["exit_code"] == 0
    trace = json.loads((folder / "end_to_end/trace.json").read_text(encoding="utf-8"))
    assert trace["inherited_v8_trace"]["compound_event_proved"] is True
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False


@pytest.mark.parametrize("kind", ["clean", "delete", "repeat"])
def test_v9_preserves_v8_results_and_default_engine(tmp_path, kind):
    reference, output, _ = _source(tmp_path, kind)
    before = reference.read_bytes(), output.read_bytes()
    assert api.analyze_pair(reference, output)["engine"] == "local_content_alignment_v1"
    baseline = api.analyze_pair(reference, output, engine="v8")
    result, trace = api.analyze_pair_with_trace(reference, output, engine="v9")
    assert result["engine"] == trace["analysis_engine"] == ENGINE
    assert result["analysis"]["method"] == METHOD
    assert result["status"] == baseline["status"]
    assert result["events"] == baseline["events"]
    assert result["reason_code"] == baseline["reason_code"]
    assert trace["proof_path"] == "preserved_v8_result"
    assert validate_analysis_result(result) is result
    assert before == (reference.read_bytes(), output.read_bytes())


@pytest.mark.parametrize("profile", ["telephone", "missing", None, True, np.array(["basic", "telephone"])])
def test_v9_profile_failure_happens_before_audio_read(tmp_path, profile):
    for facade in (api.analyze_pair, api.analyze_pair_with_trace):
        with pytest.raises(EngineConfigError):
            facade(tmp_path / "missing", tmp_path / "missing2", engine="v9", profile=profile)


@pytest.mark.parametrize("engine", [None, 8, True, "v13", ["v9"], np.array(["v9"])])
def test_v9_invalid_selection_happens_before_audio_read(tmp_path, engine):
    for facade in (api.analyze_pair, api.analyze_pair_with_trace):
        with pytest.raises(EngineConfigError):
            facade(tmp_path / "missing", tmp_path / "missing2", engine=engine)


@pytest.mark.parametrize("mode", ["native", "saved"])
def test_v9_pipeline_keeps_earlier_review_when_later_stage_is_clear(tmp_path, monkeypatch, mode):
    reference, _, manifest = _source(tmp_path, "repeat")
    if mode == "native":
        order = list(range(10)) + [8, 9] + list(range(10, 30))
        result = native.run_pipeline(reference, [
            {"kind": "split_join", "segment_ms": 200, "order": order},
            {"kind": "gain", "gain_db": 0},
        ], tmp_path / "new", engine="v9")
        validator, render = validate_pipeline_result, render_pipeline_html
    else:
        result = saved.audit_saved_pipeline(manifest, tmp_path / "new", engine="v9")
        validator, render = validate_saved_pipeline_result, render_saved_pipeline_html
    validator(result)
    assert result["summary"]["exit_code"] == 1
    assert result["summary"]["first_concern"]["stage_index"] == 1
    assert result["stages"][1]["check"]["exit_code"] == 0
    assert all(stage["analysis"]["engine"] == ENGINE for stage in result["stages"])

    def forbidden(*args, **kwargs):
        pytest.fail("Stored HTML must not analyze audio or load a trace.")

    monkeypatch.setattr(api, "analyze_pair_with_trace", forbidden)
    html = render(result)
    assert "v9 · 선택한 실험 후보" in html and "전역 문맥 정합" in html
    assert "전체 음질 승인이나 상용 성능 검증이 아닙니다" in html
    assert "<script" not in html and "<a " not in html


@pytest.mark.parametrize("mode", ["native", "saved"])
@pytest.mark.parametrize("scope", ["stage", "end_to_end"])
def test_v9_trace_write_failure_is_blocked_not_cleared(tmp_path, monkeypatch, mode, scope):
    reference, output, manifest = _source(tmp_path)
    before = reference.read_bytes(), output.read_bytes()
    module = native if mode == "native" else saved
    writer = module._new_json

    def fault(path, value):
        if path.name == "trace.json" and (scope == "stage" or path.parent.name == "end_to_end"):
            error = native.PipelineRunError if mode == "native" else saved.SavedPipelineError
            raise error("output_write_error")
        return writer(path, value)

    monkeypatch.setattr(module, "_new_json", fault)
    folder = tmp_path / "new"
    result = (native.run_pipeline(reference, [{"kind": "gain", "gain_db": -3}] * 2, folder, engine="v9")
              if mode == "native" else saved.audit_saved_pipeline(manifest, folder, engine="v9"))
    (validate_pipeline_result if mode == "native" else validate_saved_pipeline_result)(result)
    assert result["status"] == "incomplete" and result["summary"]["gate_state"] == "blocked"
    if scope == "stage":
        assert result["stages"][1]["status"] == "not_run"
    else:
        assert all(stage["status"] == "analyzed" for stage in result["stages"])
        assert (folder / "stages/001/trace.json").is_file()
    assert before == (reference.read_bytes(), output.read_bytes())


@pytest.mark.parametrize("mode", ["native", "saved"])
def test_v9_pipeline_rejects_mixed_nested_identity(tmp_path, mode):
    reference, _, manifest = _source(tmp_path)
    result = (native.run_pipeline(reference, [{"kind": "gain", "gain_db": -3}], tmp_path / "new", engine="v9")
              if mode == "native" else saved.audit_saved_pipeline(manifest, tmp_path / "new", engine="v9"))
    value = deepcopy(result)
    value["stages"][0]["analysis"]["engine"] = "local_content_alignment_v8"
    value["stages"][0]["analysis"]["analysis"]["method"] = "exact_quantized_compound_event_forward_proof"
    validator = validate_pipeline_result if mode == "native" else validate_saved_pipeline_result
    error = PipelineReportError if mode == "native" else SavedPipelineContractError
    with pytest.raises(error) as caught:
        validator(value)
    assert caught.value.code == "inconsistent_analysis_engine"


@pytest.mark.parametrize("mutation", ["method", "approval", "commercial", "profile", "position", "anchors", "coverage", "anchor_count"])
def test_v9_contract_rejects_fabricated_identity_or_evidence(tmp_path, mutation):
    reference, output, _ = _source(tmp_path)
    value = deepcopy(api.analyze_pair(reference, output, engine="v9"))
    if mutation == "method":
        value["analysis"]["method"] = "made_up"
    elif mutation == "approval":
        value["complete_audio_approval"] = True
    elif mutation == "commercial":
        value["commercial_performance_validated"] = True
    elif mutation == "profile":
        value["configuration"]["profile"] = "telephone"
    elif mutation == "position":
        value["alignment_segments"][0]["reference_interval_ms"][1] = 99999
    elif mutation == "anchors":
        value["alignment_segments"][0]["anchor_correlations"] = [.99, .99]
    elif mutation == "coverage":
        value["diagnostics"]["matched_analysis_samples"] = 1599
    else:
        value["diagnostics"]["anchor_run_count"] += 1
    with pytest.raises(ResultContractError):
        validate_analysis_result(value)


def test_v9_schema_identity_and_cli_defaults_are_explicit():
    root = Path(__file__).parents[1] / "src/audio_regression/schemas"
    schema = json.loads((root / "analysis-result-v9.schema.json").read_text(encoding="utf-8"))
    assert schema["$id"].endswith(":v9")
    assert ENGINE in json.dumps(schema) and METHOD in json.dumps(schema)
    assert "single-event" in schema["title"] and "Events require review" in schema["description"]
    assert cli._parser().parse_args(["analyze", "--reference", "a", "--processed", "b"]).engine == "v1"
    assert cli._parser().parse_args(["analyze", "--reference", "a", "--processed", "b", "--engine", "v9"]).engine == "v9"
    for command, args in [("run", ["--source", "a", "--plan", "p", "--output-dir", "out"]),
                          ("audit", ["--manifest", "m", "--output-dir", "out"])]:
        assert pipeline_cli._parser().parse_args([command, *args]).engine == "v1"
        assert pipeline_cli._parser().parse_args([command, *args, "--engine", "v9"]).engine == "v9"


def test_v9_stored_error_is_blocked_without_probability_claim():
    error = {"schema_version": 1, "engine": ENGINE, "status": "error", "reason_code": "input_error"}
    assert validate_analysis_result(error) is error
    check = check_result(error)
    assert check["exit_code"] == 2 and check["probability_claims"] is False
    html = render_html(error)
    assert "v9 · 선택한 개선 후보" in html and "자동 판단 차단" in html
