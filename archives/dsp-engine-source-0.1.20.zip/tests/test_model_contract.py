"""Invented bounded result records only; no audio, sealed data, or DSP execution."""

from copy import deepcopy
import json
from pathlib import Path

import pytest

from audio_regression.check_policy import check_result
from audio_regression.model_contract import (
    ENGINE, MAX_MODEL_RESULT_BYTES, derive_model_summary, load_model_result,
    validate_model_result,
)
from audio_regression.result_contract import ResultContractError, validate_analysis_result


METHODS = [
    "constrained_edit_alignment_with_raw_anchors",
    "constrained_edit_alignment_with_pcm16_cancellation_revalidation",
    "constrained_edit_alignment_with_bounded_active_context_bridge",
    "raw_landmark_piecewise_alignment_with_global_uniqueness",
    "exact_canonical_pcm_resampling_with_unique_context",
    "full_copy_feasibility_with_global_source_exclusion",
    "interval_gain_quantized_compound_normal_proof",
    "exact_quantized_compound_event_forward_proof",
    "global_context_quantized_event_forward_proof",
]
MODEL_KINDS = ["polarity_invert", "fir_binomial_3", "pcm_quantize_12"]
SCHEMA = Path(__file__).resolve().parents[1] / "src" / "audio_regression" / "schemas" / "declared-transform-result-v1.schema.json"


def _metadata(rate=8000, duration=3000, digest="a"):
    return {"sample_rate_hz": rate, "sample_count": int(rate * duration / 1000),
            "duration_ms": duration, "channels": 1, "encoding": "pcm16",
            "rms": .1, "peak": .2, "sha256": digest * 64}


def _child(version=1, kind="clean", rate=8000):
    reference = _metadata(rate)
    processed = deepcopy(reference)
    child = {
        "schema_version": 1, "engine": f"local_content_alignment_v{version}",
        "status": "analyzed", "content_preservation_status": "no_supported_defect_candidates",
        "reason_code": None, "events": [], "complete_audio_approval": False,
        "commercial_performance_validated": False, "reference": reference,
        "processed": processed,
        "configuration": {"profile": "basic", "allow_gain": False,
                          "allow_resampling": False, "max_delay_ms": 1000},
        "analysis": {"sample_rate_hz": 8000, "hop_ms": 10, "method": METHODS[version - 1],
                     "minimum_event_duration_ms": 200, "maximum_cumulative_edit_shift_ms": 2000,
                     "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {"normalized_path_cost": 0, "gain_estimate": 1, "applied_gain": 1,
                        "matched_normalized_rmse": 0, "matched_analysis_samples": 24000,
                        "anchor_run_count": 1, "minimum_local_correlation": 1},
        "limitations": ["Invented contract fixture, not observed audio or model execution."],
        "alignment_segments": [{"reference_interval_ms": [0, 3000], "processed_offset_ms": 0,
                                "anchor_correlations": [1, 1, 1]}],
    }
    if kind == "delete":
        child["processed"] = _metadata(rate, 2600, "b")
        child["content_preservation_status"] = "defect_candidates"
        child["events"] = [{"type": "delete", "reference_interval_ms": [800, 1200],
                            "processed_boundary_ms": 800,
                            "evidence": {"boundary_correlation": 1, "offset_before_ms": 0,
                                         "offset_after_ms": -400}}]
        child["alignment_segments"] = [
            {"reference_interval_ms": [0, 800], "processed_offset_ms": 0, "anchor_correlations": [1, 1, 1]},
            {"reference_interval_ms": [1200, 3000], "processed_offset_ms": -400, "anchor_correlations": [1, 1, 1]},
        ]
        child["diagnostics"].update(anchor_run_count=2, matched_analysis_samples=20800)
    elif kind == "withheld":
        child.update(status="withheld", content_preservation_status="withheld",
                     reason_code="insufficient_signal_variation", events=None, diagnostics={})
        child.pop("alignment_segments")
    elif kind == "different_length_clean":
        child["processed"] = _metadata(rate, 3100, "b")
        child["alignment_segments"][0]["processed_offset_ms"] = 100
    assert validate_analysis_result(child) is child
    return child


def _result(version=1, kind="clean", exact=True, rate=8000):
    child = _child(version, kind, rate)
    if not exact:
        child["processed"]["sha256"] = "b" * 64
    different_length = child["reference"]["sample_count"] != child["processed"]["sample_count"]
    comparison = {"exact_pcm16_match": False if different_length else exact,
                  "unequal_sample_count": None if different_length else (0 if exact else 1),
                  "maximum_abs_error_pcm16": None if different_length else (0 if exact else 1)}
    temporal = check_result(child)
    return {
        "schema_version": 1, "engine": ENGINE, "status": "completed",
        "model_plan": {"schema_version": 1, "models": [{"kind": "polarity_invert"}]},
        "source": deepcopy(child["reference"]), "expected": deepcopy(child["reference"]),
        "processed": deepcopy(child["processed"]), "comparison": comparison,
        "analysis": child, "temporal_check": temporal,
        "summary": derive_model_summary(comparison, temporal),
        "artifacts": {"source": "input/source.wav", "processed": "input/processed.wav",
                      "expected": "expected/output.wav", "analysis": "analysis.json",
                      "temporal_check": "temporal_check.json",
                      "trace": None if version == 1 else "trace.json"},
        "complete_audio_approval": False, "commercial_performance_validated": False,
        "network_used": False, "fault_provenance_confirmed": False,
    }


def _set(result, path, value):
    current = result
    for part in path[:-1]:
        current = current[part]
    current[path[-1]] = value


def _reject(result, code):
    with pytest.raises(ResultContractError) as caught:
        validate_model_result(result)
    assert caught.value.code == code
    assert "private" not in str(caught.value)


@pytest.mark.parametrize("version", range(1, 10))
@pytest.mark.parametrize("kind,exact,gate", [
    ("clean", True, "clear_declared_model_check"),
    ("clean", False, "blocked"),
    ("withheld", True, "blocked"),
    ("withheld", False, "blocked"),
    ("delete", False, "review_required"),
    ("different_length_clean", False, "blocked"),
])
def test_all_original_child_versions_and_narrow_gate_branches(version, kind, exact, gate):
    result = _result(version, kind, exact)
    before = deepcopy(result)
    assert validate_model_result(result) is result
    assert result == before
    assert result["summary"]["gate_state"] == gate
    assert result["temporal_check"] == check_result(result["analysis"])


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
def test_supported_metadata_rates_keep_existing_analysis_band(rate):
    assert validate_model_result(_result(rate=rate))["source"]["sample_rate_hz"] == rate


@pytest.mark.parametrize("kind", MODEL_KINDS)
@pytest.mark.parametrize("count", [1, 2, 3, 4])
def test_explicit_plan_fixed_models_repeat_and_order_are_preserved(kind, count):
    result = _result()
    result["model_plan"]["models"] = [{"kind": kind}] * count
    before = deepcopy(result)
    assert validate_model_result(result) is result
    assert result == before


def test_order_is_declared_not_inferred_or_authenticated():
    first = _result()
    first["model_plan"]["models"] = [{"kind": kind} for kind in MODEL_KINDS]
    second = deepcopy(first)
    second["model_plan"]["models"].reverse()
    assert validate_model_result(first) is first
    assert validate_model_result(second) is second
    assert first["model_plan"] != second["model_plan"]
    assert not first["fault_provenance_confirmed"] and not second["fault_provenance_confirmed"]


@pytest.mark.parametrize("version", range(1, 10))
def test_existing_optional_review_child_is_preserved_and_still_blocks(version):
    result = _result(version, "withheld")
    result["analysis"]["review_diagnostics"] = {
        "schema_version": 1, "selected_engine": f"local_content_alignment_v{version}",
        "result_status": "withheld", "primary_reason_code": "insufficient_signal_variation",
        "trace_availability": "unavailable", "diagnostic_only": True,
        "fault_provenance_confirmed": False, "stages": [],
    }
    assert validate_model_result(result) is result
    assert result["summary"] == {"gate_state": "blocked", "exit_code": 2,
                                  "reason_code": "temporal_comparison_withheld"}


@pytest.mark.parametrize("value", [None, [], "{}", True, 1, 1.0])
def test_result_must_be_exact_dictionary(value):
    _reject(value, "invalid_model_result_type")


@pytest.mark.parametrize("field", list(_result()))
def test_all_top_fields_required(field):
    result = _result()
    result.pop(field)
    _reject(result, "missing_result_field")


@pytest.mark.parametrize("scope", [(), ("model_plan",), ("model_plan", "models", 0),
                                   ("comparison",), ("summary",), ("artifacts",),
                                   ("source",), ("expected",), ("processed",),
                                   ("analysis",), ("temporal_check",)])
def test_unknown_payloads_rejected_at_every_owned_boundary(scope):
    result = _result()
    current = result
    for part in scope:
        current = current[part]
    current["private_payload"] = "C:/private/person.wav"
    expected = ("invalid_model_plan" if scope == ("model_plan",) else
                "invalid_models" if scope == ("model_plan", "models", 0) else
                "inconsistent_model_temporal_check" if scope == ("temporal_check",) else
                "unexpected_result_field")
    _reject(result, expected)


@pytest.mark.parametrize("path,value,code", [
    (("schema_version",), True, "unsupported_schema_version"),
    (("schema_version",), 1.0, "unsupported_schema_version"),
    (("schema_version",), 2, "unsupported_schema_version"),
    (("engine",), [], "unsupported_model_engine"),
    (("engine",), "local_content_alignment_v1", "unsupported_model_engine"),
    (("status",), "incomplete", "unsupported_model_result_status"),
    (("status",), {}, "unsupported_model_result_status"),
    (("comparison", "exact_pcm16_match"), 1, "invalid_model_comparison"),
    (("comparison", "unequal_sample_count"), True, "invalid_unequal_sample_count"),
    (("comparison", "unequal_sample_count"), 0.0, "invalid_unequal_sample_count"),
    (("comparison", "unequal_sample_count"), -1, "invalid_unequal_sample_count"),
    (("comparison", "unequal_sample_count"), 24001, "invalid_unequal_sample_count"),
    (("comparison", "maximum_abs_error_pcm16"), False, "invalid_maximum_pcm16_error"),
    (("comparison", "maximum_abs_error_pcm16"), 0.0, "invalid_maximum_pcm16_error"),
    (("comparison", "maximum_abs_error_pcm16"), -1, "invalid_maximum_pcm16_error"),
    (("comparison", "maximum_abs_error_pcm16"), 65536, "invalid_maximum_pcm16_error"),
    (("comparison", "unequal_sample_count"), 1, "inconsistent_model_comparison"),
    (("comparison", "maximum_abs_error_pcm16"), 1, "inconsistent_model_comparison"),
    (("comparison", "exact_pcm16_match"), False, "inconsistent_model_comparison"),
    (("comparison", "unequal_sample_count"), None, "invalid_unequal_sample_count"),
    (("comparison", "maximum_abs_error_pcm16"), None, "invalid_maximum_pcm16_error"),
    (("summary", "exit_code"), False, "invalid_model_summary_exit_code"),
    (("summary", "exit_code"), 0.0, "invalid_model_summary_exit_code"),
    (("summary", "exit_code"), 3, "invalid_model_summary_exit_code"),
    (("summary", "gate_state"), "clear_supported_temporal_check", "inconsistent_model_summary"),
    (("summary", "reason_code"), "passed", "inconsistent_model_summary"),
    (("summary", "reason_code"), {}, "inconsistent_model_summary"),
    (("source", "duration_ms"), 3001, "inconsistent_audio_duration"),
    (("expected", "sha256"), "private", "invalid_audio_metadata"),
    (("processed", "rms"), .3, "invalid_audio_metadata"),
    (("source", "sample_count"), True, "invalid_audio_metadata"),
    (("expected", "channels"), True, "invalid_audio_metadata"),
    (("processed", "encoding"), "float32", "invalid_audio_metadata"),
    (("source", "peak"), 1.01, "invalid_audio_metadata"),
    (("analysis", "configuration", "profile"), "telephone", "invalid_model_analysis_configuration"),
    (("analysis", "configuration", "allow_gain"), True, "invalid_model_analysis_configuration"),
    (("analysis", "configuration", "allow_resampling"), True, "invalid_model_analysis_configuration"),
    (("analysis", "configuration", "max_delay_ms"), 999, "invalid_model_analysis_configuration"),
    (("analysis", "diagnostics", "matched_normalized_rmse"), .5, "inconsistent_analyzed_metrics"),
    (("analysis", "alignment_segments", 0, "anchor_correlations"), [1, .1, 1], "invalid_anchor_correlations"),
    (("analysis", "commercial_performance_validated"), True, "invalid_approval_claim"),
])
def test_strict_type_numeric_child_and_summary_mutations(path, value, code):
    result = _result()
    _set(result, path, value)
    _reject(result, code)


@pytest.mark.parametrize("field", ["complete_audio_approval", "commercial_performance_validated",
                                   "network_used", "fault_provenance_confirmed"])
@pytest.mark.parametrize("value", [True, 0, None, "false"])
def test_false_claim_flags_cannot_be_weakened(field, value):
    result = _result()
    result[field] = value
    _reject(result, "invalid_approval_claim")


@pytest.mark.parametrize("plan,code", [
    (None, "invalid_model_plan"), ({}, "invalid_model_plan"),
    ({"schema_version": True, "models": [{"kind": "polarity_invert"}]}, "invalid_model_plan"),
    ({"schema_version": 2, "models": [{"kind": "polarity_invert"}]}, "invalid_model_plan"),
    ({"schema_version": 1, "models": []}, "invalid_models"),
    ({"schema_version": 1, "models": [{"kind": "polarity_invert"}] * 5}, "invalid_models"),
    ({"schema_version": 1, "models": ({"kind": "polarity_invert"},)}, "invalid_json_value"),
    ({"schema_version": 1, "models": [{"kind": "automatic"}]}, "invalid_models"),
    ({"schema_version": 1, "models": [{"kind": "gain", "value": 2}]}, "invalid_models"),
    ({"schema_version": 1, "models": [{"kind": []}]}, "invalid_models"),
    ({"schema_version": 1, "models": [None]}, "invalid_models"),
    ({"schema_version": 1, "models": "polarity_invert"}, "invalid_models"),
])
def test_plan_is_bounded_fixed_and_never_auto_inferred(plan, code):
    result = _result()
    result["model_plan"] = plan
    _reject(result, code)


@pytest.mark.parametrize("field", ["source", "expected", "processed"])
def test_rates_must_match_even_when_each_metadata_record_is_valid(field):
    result = _result()
    result[field] = _metadata(16000)
    _reject(result, "inconsistent_model_sample_rate")


@pytest.mark.parametrize("field", ["source", "expected"])
def test_expected_model_preserves_original_count(field):
    result = _result()
    result[field] = _metadata(duration=3100)
    _reject(result, "inconsistent_model_expected_length")


@pytest.mark.parametrize("field", ["expected", "processed"])
def test_child_metadata_must_bind_to_top_records(field):
    result = _result()
    result[field]["sha256"] = "b" * 64
    _reject(result, "inconsistent_model_analysis_metadata")


def test_container_hashes_are_not_mistaken_for_pcm_content_equality():
    result = _result()
    result["source"]["sha256"] = "c" * 64
    result["processed"]["sha256"] = "d" * 64
    result["analysis"]["processed"]["sha256"] = "d" * 64
    assert validate_model_result(result) is result
    assert result["comparison"]["exact_pcm16_match"] is True


@pytest.mark.parametrize("field,value", [("rms", .11), ("peak", .21)])
def test_exact_pcm_requires_same_signal_measurements_even_with_different_container_hashes(field, value):
    result = _result()
    result["processed"]["sha256"] = "b" * 64
    result["analysis"]["processed"]["sha256"] = "b" * 64
    result["processed"][field] = value
    result["analysis"]["processed"][field] = value
    _reject(result, "inconsistent_model_exact_metadata")


def test_same_byte_hash_cannot_claim_different_pcm_samples():
    result = _result(exact=False)
    result["processed"]["sha256"] = result["expected"]["sha256"]
    result["analysis"]["processed"]["sha256"] = result["expected"]["sha256"]
    _reject(result, "inconsistent_model_hash_comparison")


def test_same_byte_hash_cannot_claim_different_metadata():
    result = _result(kind="different_length_clean", exact=False)
    result["processed"]["sha256"] = result["expected"]["sha256"]
    result["analysis"]["processed"]["sha256"] = result["expected"]["sha256"]
    _reject(result, "inconsistent_model_hash_comparison")


def test_private_summary_payload_is_not_copied_or_serialized(monkeypatch):
    result = _result()
    result["summary"]["reason_code"] = "private" * 150_000

    def never_serialize(*args, **kwargs):
        raise AssertionError("Validation must not serialize unknown caller payloads.")

    monkeypatch.setattr(json, "dumps", never_serialize)
    _reject(result, "inconsistent_model_summary")


@pytest.mark.parametrize("field,value", [("unequal_sample_count", 0), ("maximum_abs_error_pcm16", 0),
                                        ("exact_pcm16_match", True)])
def test_length_mismatch_requires_null_unaligned_sample_metrics(field, value):
    result = _result(kind="delete", exact=False)
    result["comparison"][field] = value
    _reject(result, "inconsistent_model_comparison")


def test_positive_sample_mismatch_limits_accept_only_coherent_pair():
    result = _result(exact=False)
    result["comparison"].update(unequal_sample_count=24000, maximum_abs_error_pcm16=65535)
    assert validate_model_result(result) is result


@pytest.mark.parametrize("field,value", [("exit_code", False), ("schema_version", True),
                                        ("event_count", False), ("reason_code", "analysis_withheld"),
                                        ("contract_valid", False), ("probability_claims", True)])
def test_stored_temporal_check_is_recomputed_type_sensitively(field, value):
    result = _result()
    result["temporal_check"][field] = value
    _reject(result, "inconsistent_model_temporal_check")


def test_child_error_envelope_cannot_be_a_completed_model_check():
    result = _result()
    result["analysis"] = {"schema_version": 1, "status": "error", "reason_code": "input_error"}
    _reject(result, "model_child_analysis_error")


@pytest.mark.parametrize("version", range(1, 10))
def test_mutated_existing_child_review_is_not_trusted(version):
    result = _result(version, "withheld")
    result["analysis"]["review_diagnostics"] = {"fault_provenance_confirmed": True}
    _reject(result, "invalid_review_diagnostics_structure")


def test_temporal_candidates_cannot_coexist_with_claimed_exact_pcm_match():
    result = _result()
    child = result["analysis"]
    child["events"] = [{"type": "repeat", "reference_source_interval_ms": [800, 1200],
                        "processed_added_interval_ms": [1200, 1600],
                        "copy_interval_convention": "canonical_later_adjacent_copy_not_edit_provenance",
                        "evidence": {"boundary_correlation": 1, "copy_correlation": 1,
                                     "adjacent_copy_correlation": 1, "offset_before_ms": 0,
                                     "offset_after_ms": 400}}]
    child["content_preservation_status"] = "defect_candidates"
    assert validate_analysis_result(child) is child
    result["temporal_check"] = check_result(child)
    _reject(result, "inconsistent_exact_temporal_candidates")


@pytest.mark.parametrize("field", ["source", "processed", "expected", "analysis", "temporal_check", "trace"])
@pytest.mark.parametrize("path", ["../private.wav", "C:/private/person.wav", "/private/person.wav",
                                  "https://example.invalid/private.wav", "input\\source.wav", None])
def test_artifact_references_are_fixed_inert_names(field, path):
    result = _result(version=9)
    result["artifacts"][field] = path
    _reject(result, "invalid_model_artifact_path")


def test_trace_name_follows_selected_child_engine():
    result = _result()
    result["artifacts"]["trace"] = "trace.json"
    _reject(result, "invalid_model_artifact_path")


@pytest.mark.parametrize("path", [
    ("source", "rms"), ("expected", "duration_ms"),
    ("comparison", "maximum_abs_error_pcm16"), ("summary", "exit_code"),
    ("analysis", "diagnostics", "normalized_path_cost"),
    ("temporal_check", "event_count"),
])
@pytest.mark.parametrize("value", [float("nan"), float("inf"), float("-inf")])
def test_hidden_nonfinite_numbers_are_rejected_before_semantic_dispatch(path, value):
    result = _result()
    _set(result, path, value)
    _reject(result, "non_finite_metric")


def test_huge_integer_and_hidden_nonjson_payload_are_fail_closed():
    result = _result()
    result["summary"]["exit_code"] = 10 ** 1000
    _reject(result, "non_finite_metric")
    for payload in (object(), {1: "private"}, (1, 2), {1, 2}):
        result = _result()
        result["private_payload"] = payload
        _reject(result, "invalid_json_value")


def test_cycles_deep_trees_and_excess_nodes_are_bounded():
    result = _result()
    result["private_payload"] = result
    _reject(result, "result_structure_too_large")
    result = _result()
    branch = result
    for _ in range(25):
        branch["private_payload"] = {}
        branch = branch["private_payload"]
    _reject(result, "result_structure_too_large")
    result = _result()
    result["private_payload"] = [0] * 20_001
    _reject(result, "result_structure_too_large")


@pytest.mark.parametrize("comparison,temporal", [
    (None, {"exit_code": 0}), ({"exact_pcm16_match": 1}, {"exit_code": 0}),
    ({"exact_pcm16_match": True}, None), ({"exact_pcm16_match": True}, {"exit_code": False}),
    ({"exact_pcm16_match": True}, {"exit_code": 0.0}), ({"exact_pcm16_match": False}, {"exit_code": 3}),
])
def test_summary_helper_control_types_are_fail_closed(comparison, temporal):
    with pytest.raises(ResultContractError) as caught:
        derive_model_summary(comparison, temporal)
    assert caught.value.code == "invalid_model_summary_inputs"


def test_summary_helper_does_not_clear_exact_withheld_or_accept_exact_candidate():
    assert derive_model_summary({"exact_pcm16_match": True}, {"exit_code": 2}) == {
        "gate_state": "blocked", "exit_code": 2, "reason_code": "temporal_comparison_withheld"}
    with pytest.raises(ResultContractError) as caught:
        derive_model_summary({"exact_pcm16_match": True}, {"exit_code": 1})
    assert caught.value.code == "inconsistent_exact_temporal_candidates"


@pytest.mark.parametrize("version", range(1, 10))
def test_bounded_loader_returns_original_stored_record_without_artifact_reads(tmp_path, monkeypatch, version):
    result = _result(version, "withheld")
    path = tmp_path / "result.json"
    data = json.dumps(result, allow_nan=False).encode("utf-8")
    path.write_bytes(data)
    actual_open = Path.open
    opened = []

    def only_result_open(target, *args, **kwargs):
        assert target == path
        opened.append(target)
        return actual_open(target, *args, **kwargs)

    with monkeypatch.context() as patch:
        patch.setattr(Path, "open", only_result_open)
        assert load_model_result(path) == result
    assert opened == [path]
    assert path.read_bytes() == data


@pytest.mark.parametrize("data,code", [
    (b'{"schema_version":1,"schema_version":1}', "duplicate_json_key"),
    (b'{"private":NaN}', "non_finite_metric"),
    (b'{"private":Infinity}', "non_finite_metric"),
    (b'{"private":-Infinity}', "non_finite_metric"),
    (b'{"private":1e9999}', "non_finite_metric"),
    (b'\xff', "invalid_result_json"),
    (b'\xef\xbb\xbf{}', "invalid_result_json"),
    (b'{} garbage', "invalid_result_json"),
    (b'[]', "invalid_model_result_type"),
    (b' ' * (MAX_MODEL_RESULT_BYTES + 1), "result_file_too_large"),
], ids=["duplicate", "nan", "infinity", "negative-infinity", "overflow",
        "invalid-utf8", "bom", "trailing-text", "array", "over-one-mib"])
def test_loader_rejects_duplicate_keys_nonfinite_utf8_and_oversized_json(tmp_path, data, code):
    path = tmp_path / "private.json"
    path.write_bytes(data)
    with pytest.raises(ResultContractError) as caught:
        load_model_result(path)
    assert caught.value.code == code
    assert "private" not in str(caught.value)


def test_loader_also_rejects_duplicate_keys_inside_a_valid_record(tmp_path):
    data = json.dumps(_result())
    data = data.replace('"kind": "polarity_invert"', '"kind": "polarity_invert", "kind": "pcm_quantize_12"')
    path = tmp_path / "record.json"
    path.write_text(data, encoding="utf-8")
    with pytest.raises(ResultContractError) as caught:
        load_model_result(path)
    assert caught.value.code == "duplicate_json_key"


@pytest.mark.parametrize("path", [None, 1, "bad\0private.json"])
def test_loader_safe_file_failure_does_not_echo_path(path):
    with pytest.raises(ResultContractError) as caught:
        load_model_result(path)
    assert caught.value.code == "result_file_read_error"
    assert "private" not in str(caught.value)


def test_loader_missing_path_is_stable(tmp_path):
    with pytest.raises(ResultContractError) as caught:
        load_model_result(tmp_path / "private_missing.json")
    assert caught.value.code == "result_file_read_error"


def test_schema_is_self_contained_bounded_and_explicit_about_semantic_limits():
    schema = json.loads(SCHEMA.read_text("utf-8"))
    result = _result()
    assert schema["$schema"].endswith("2020-12/schema")
    assert schema["additionalProperties"] is False
    assert set(schema["required"]) == set(result)
    assert schema["properties"]["engine"]["const"] == ENGINE
    assert "Python model_contract additionally" in schema["description"]
    assert "does not establish all" in schema["description"]
    model_items = schema["$defs"]["modelPlan"]["properties"]["models"]
    assert model_items["minItems"] == 1 and model_items["maxItems"] == 4
    assert set(model_items["items"]["properties"]["kind"]["enum"]) == set(MODEL_KINDS)
    assert model_items["items"]["additionalProperties"] is False
    assert set(schema["$defs"]["summary"]["required"]) == set(result["summary"])
    assert set(schema["$defs"]["comparison"]["required"]) == set(result["comparison"])
    assert set(schema["$defs"]["artifacts"]["required"]) == set(result["artifacts"])
    assert schema["$defs"]["comparison"]["properties"]["maximum_abs_error_pcm16"]["maximum"] == 65535
    assert schema["$defs"]["childAnalysis"]["properties"]["status"]["enum"] == ["analyzed", "withheld"]
    assert schema["$defs"]["configuration"]["properties"]["allow_gain"]["const"] is False
    assert schema["$defs"]["configuration"]["properties"]["allow_resampling"]["const"] is False
    assert schema["$defs"]["configuration"]["properties"]["max_delay_ms"]["const"] == 1000

    def visit(value):
        if isinstance(value, dict):
            if "$ref" in value:
                reference = value["$ref"]
                assert reference.startswith("#/$defs/")
                assert reference[len("#/$defs/"):] in schema["$defs"]
            for item in value.values():
                visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)

    visit(schema)
