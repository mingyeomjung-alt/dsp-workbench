"""Saved-record contract fixtures only; no audio or locked evaluation replay."""

import copy
import json
from pathlib import Path

import pytest

from audio_regression.check_policy import check_result
from audio_regression.saved_pipeline_contract import (
    MAX_SAVED_PIPELINE_RESULT_BYTES, SavedPipelineContractError,
    load_saved_pipeline_result, validate_saved_pipeline_result,
)


def metadata(letter="a", duration_ms=6000.0, rate=16000):
    return {"sample_rate_hz": rate, "sample_count": round(duration_ms * rate / 1000),
            "duration_ms": duration_ms, "channels": 1, "encoding": "pcm16",
            "rms": 0.05, "peak": 0.2, "sha256": letter * 64}


def analysis(reference, processed, kind="clean"):
    events = []
    if kind == "delete":
        events = [{"type": "delete", "reference_interval_ms": [2000.0, 2400.0],
                   "processed_boundary_ms": 2000.0,
                   "evidence": {"boundary_correlation": 0.99, "offset_before_ms": 0.0,
                                "offset_after_ms": -400.0}}]
    result = {
        "schema_version": 1, "engine": "local_content_alignment_v1", "status": "analyzed",
        "content_preservation_status": "defect_candidates" if events else "no_supported_defect_candidates",
        "reason_code": None, "events": events, "complete_audio_approval": False,
        "commercial_performance_validated": False,
        "reference": copy.deepcopy(reference), "processed": copy.deepcopy(processed),
        "configuration": {"profile": "basic", "allow_gain": True,
                          "allow_resampling": False, "max_delay_ms": 1000.0},
        "analysis": {"sample_rate_hz": 8000, "hop_ms": 10.0,
                     "method": "constrained_edit_alignment_with_raw_anchors",
                     "minimum_event_duration_ms": 200, "maximum_cumulative_edit_shift_ms": 2000,
                     "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {"normalized_path_cost": 0.01, "gain_estimate": 1.0, "applied_gain": 1.0,
                        "matched_normalized_rmse": 0.001, "matched_analysis_samples": 40000,
                        "anchor_run_count": 1, "minimum_local_correlation": 0.99},
        "limitations": ["지원 시간적 후보만 검사 · 전체 음질 승인 아님"],
        "alignment_segments": [{"reference_interval_ms": [0.0, 2000.0], "processed_offset_ms": 0.0,
                                "anchor_correlations": [0.99, 0.99, 0.99]}],
    }
    if kind == "withheld":
        result.update(status="withheld", content_preservation_status="withheld", events=None,
                      reason_code="insufficient_unambiguous_anchors")
        result.pop("alignment_segments")
    return result


def concern(stage=None, category="execution_error"):
    return {"scope": "stage" if stage else "end_to_end",
            "stage_index": stage["index"] if stage else None,
            "stage_label": stage["label"] if stage else None, "category": category}


def saved_fixture(kind="clean"):
    source = metadata()
    outputs = [metadata("b", 5600.0 if kind == "delete" else 6000.0),
               metadata("c", 5600.0 if kind == "delete" else 6000.0)]
    previous = source
    stages = []
    for index, output in enumerate(outputs, 1):
        result = analysis(previous, output, kind if index == 1 else "clean")
        stages.append({"index": index, "label": f"저장 처리 {index}",
                       "declaration": copy.deepcopy(result["configuration"]),
                       "input": copy.deepcopy(previous), "output": copy.deepcopy(output),
                       "input_snapshot": f"inputs/{index - 1:03d}.wav",
                       "output_snapshot": f"inputs/{index:03d}.wav",
                       "status": result["status"], "analysis": result, "check": check_result(result),
                       "reason_code": result["reason_code"],
                       "analysis_artifact": f"stages/{index:03d}/analysis.json",
                       "check_artifact": f"stages/{index:03d}/check.json", "runtime_ms": 12.5})
        previous = output
    end_analysis = analysis(source, outputs[-1], "delete" if kind == "delete" else "clean")
    code = {"clean": 0, "delete": 1, "withheld": 2}[kind]
    first = concern(stages[0], "defect_candidates" if kind == "delete" else "withheld") if code else None
    return {"schema_version": 1, "engine": "audio_saved_pipeline_audit_v1", "status": "completed",
            "comparison_scope": "adjacent_stage_checks_and_end_to_end", "source": source, "stages": stages,
            "end_to_end": {"status": end_analysis["status"], "analysis": end_analysis,
                           "check": check_result(end_analysis),
                           "analysis_artifact": "end_to_end/analysis.json",
                           "check_artifact": "end_to_end/check.json"},
            "input_recheck": {"status": "unchanged", "file_indices": []},
            "summary": {"gate_state": {0: "clear_supported_temporal_check", 1: "review_required", 2: "blocked"}[code],
                        "exit_code": code, "first_concern": first, "planned_stage_count": 2,
                        "checked_stage_count": 2, "failed_stage": None},
            "complete_audio_approval": False, "commercial_performance_validated": False,
            "network_used": False, "fault_provenance_confirmed": False, "caller_order_verified": False}


def end_error(value, reason="analysis_execution_error"):
    error = {"schema_version": 1, "status": "error", "reason_code": reason}
    value.update(status="incomplete", end_to_end={"status": "error", "analysis": error,
                 "check": check_result(error), "analysis_artifact": "end_to_end/error.json",
                 "check_artifact": "end_to_end/error_check.json"})
    value["summary"].update(exit_code=2, gate_state="blocked")
    if value["summary"]["first_concern"] is None:
        value["summary"]["first_concern"] = concern()
    return value


def failed_fixture():
    value = saved_fixture()
    first, second = value["stages"]
    error = {"schema_version": 1, "status": "error", "reason_code": "analysis_execution_error"}
    first.update(status="error", analysis=error, check=check_result(error), reason_code=error["reason_code"],
                 analysis_artifact="stages/001/error.json", check_artifact="stages/001/error_check.json")
    second.update(status="not_run", analysis=None, check=None, reason_code="prior_stage_analysis_error",
                  analysis_artifact=None, check_artifact=None, runtime_ms=0.0)
    value.update(status="incomplete", end_to_end=None)
    value["summary"].update(gate_state="blocked", exit_code=2, checked_stage_count=1,
                            failed_stage=1, first_concern=concern(first))
    return value


@pytest.mark.parametrize("kind", ["clean", "delete", "withheld"])
def test_coherent_results_and_sticky_concern_validate(kind):
    value = saved_fixture(kind)
    assert validate_saved_pipeline_result(value) is value
    assert value["stages"][1]["check"]["exit_code"] == 0


def test_failed_stage_preserves_supplied_tail_metadata():
    value = failed_fixture()
    assert validate_saved_pipeline_result(value) is value
    assert value["stages"][1]["output"]["sha256"] == "c" * 64


@pytest.mark.parametrize("status,reason", [("changed", "input_files_changed"),
                                          ("unavailable", "input_files_recheck_failed")])
@pytest.mark.parametrize("prior", ["clean", "delete", "failed"])
def test_recheck_failures_block_without_erasing_prior_concern(status, reason, prior):
    value = failed_fixture() if prior == "failed" else saved_fixture(prior)
    first = copy.deepcopy(value["summary"]["first_concern"])
    end_error(value, reason)
    value["input_recheck"] = {"status": status, "file_indices": [0, 2]}
    assert validate_saved_pipeline_result(value) is value
    assert value["summary"]["first_concern"] == (first or concern())


@pytest.mark.parametrize("first", ["clean", "delete", "withheld"])
def test_end_only_analysis_error_is_incomplete_and_sticky(first):
    assert validate_saved_pipeline_result(end_error(saved_fixture(first)))["status"] == "incomplete"


@pytest.mark.parametrize("target", ["stage", "end"])
@pytest.mark.parametrize("missing", [("analysis_artifact",), ("check_artifact",),
                                     ("analysis_artifact", "check_artifact")])
def test_error_artifacts_may_be_missing_but_cannot_clear(target, missing):
    value = failed_fixture() if target == "stage" else end_error(saved_fixture())
    item = value["stages"][0] if target == "stage" else value["end_to_end"]
    for field in missing:
        item[field] = None
    assert validate_saved_pipeline_result(value)["summary"]["exit_code"] == 2


@pytest.mark.parametrize("field", ["complete_audio_approval", "commercial_performance_validated",
                                   "network_used", "fault_provenance_confirmed", "caller_order_verified"])
@pytest.mark.parametrize("claim", [True, 0, None, "false"])
def test_all_approval_or_provenance_claims_are_rejected(field, claim):
    value = saved_fixture()
    value[field] = claim
    with pytest.raises(SavedPipelineContractError, match="contract") as caught:
        validate_saved_pipeline_result(value)
    assert caught.value.code == "invalid_approval_claim"


@pytest.mark.parametrize("scope", ["top", "stage", "declaration", "summary", "end", "recheck"])
def test_unknown_fields_never_silently_validate(scope):
    value = saved_fixture()
    target = {"top": value, "stage": value["stages"][0], "declaration": value["stages"][0]["declaration"],
              "summary": value["summary"], "end": value["end_to_end"], "recheck": value["input_recheck"]}[scope]
    target["extra"] = False
    with pytest.raises(SavedPipelineContractError):
        validate_saved_pipeline_result(value)


@pytest.mark.parametrize("field,bad", [("profile", "telephone"), ("profile", None), ("allow_gain", 1),
                                       ("allow_resampling", 0), ("max_delay_ms", True),
                                       ("max_delay_ms", 999.0), ("max_delay_ms", float("inf"))])
def test_stage_declaration_is_narrow_and_strict(field, bad):
    value = saved_fixture()
    value["stages"][0]["declaration"][field] = bad
    with pytest.raises(SavedPipelineContractError):
        validate_saved_pipeline_result(value)


@pytest.mark.parametrize("field", ["analysis", "check"])
def test_forged_stage_check_or_analysis_does_not_pass(field):
    value = saved_fixture("delete")
    if field == "check":
        value["stages"][0]["check"]["exit_code"] = 0
    else:
        value["stages"][0]["analysis"]["configuration"]["allow_gain"] = False
    with pytest.raises(SavedPipelineContractError):
        validate_saved_pipeline_result(value)


@pytest.mark.parametrize("location", ["input", "output", "source", "analysis"])
def test_chain_and_analysis_metadata_are_consistent(location):
    value = saved_fixture()
    target = {"input": value["stages"][1]["input"], "output": value["stages"][1]["output"],
              "source": value["source"], "analysis": value["stages"][0]["analysis"]["processed"]}[location]
    target["sha256"] = "f" * 64
    with pytest.raises(SavedPipelineContractError):
        validate_saved_pipeline_result(value)


@pytest.mark.parametrize("field", ["input_snapshot", "output_snapshot", "analysis_artifact", "check_artifact"])
@pytest.mark.parametrize("bad", ["../secret.wav", "C:/secret.wav", "https://example.org/a", "inputs/999.wav",
                                 "inputs\\001.wav", "inputs/001.wav?x"])
def test_snapshot_and_artifact_paths_are_canonical_and_inert(field, bad):
    value = saved_fixture()
    value["stages"][0][field] = bad
    with pytest.raises(SavedPipelineContractError):
        validate_saved_pipeline_result(value)


@pytest.mark.parametrize("bad", ["", "   ", "a\n", "a\u202e", "a\ud800", "x" * 81, True])
def test_stage_labels_reject_unbounded_and_invisible_control_content(bad):
    value = saved_fixture()
    value["stages"][0]["label"] = bad
    with pytest.raises(SavedPipelineContractError):
        validate_saved_pipeline_result(value)


@pytest.mark.parametrize("bad", [True, -1, float("nan"), float("inf"), "1"])
def test_runtime_must_be_finite_nonnegative_number(bad):
    value = saved_fixture()
    value["stages"][0]["runtime_ms"] = bad
    with pytest.raises(SavedPipelineContractError):
        validate_saved_pipeline_result(value)


@pytest.mark.parametrize("field,bad", [("gate_state", "clear_supported_temporal_check"), ("exit_code", 0),
                                       ("first_concern", None), ("checked_stage_count", 1),
                                       ("planned_stage_count", 1), ("failed_stage", 1),
                                       ("checked_stage_count", True)])
def test_review_summary_cannot_be_forged(field, bad):
    value = saved_fixture("delete")
    value["summary"][field] = bad
    with pytest.raises(SavedPipelineContractError):
        validate_saved_pipeline_result(value)


@pytest.mark.parametrize("change", ["no_prior_error", "analysis_present", "runtime_nonzero", "wrong_reason",
                                    "missing_output", "metadata_changed"])
def test_not_run_requires_prior_error_and_present_saved_snapshots(change):
    value = failed_fixture()
    stage = value["stages"][1]
    if change == "no_prior_error":
        value["stages"][0] = saved_fixture()["stages"][0]
    elif change == "analysis_present":
        stage["analysis"] = saved_fixture()["stages"][1]["analysis"]
    elif change == "runtime_nonzero":
        stage["runtime_ms"] = 1
    elif change == "wrong_reason":
        stage["reason_code"] = "prior_stage_execution_error"
    elif change == "missing_output":
        stage["output"] = None
    else:
        stage["input"]["sha256"] = "e" * 64
    with pytest.raises(SavedPipelineContractError):
        validate_saved_pipeline_result(value)


def test_analysis_cannot_continue_after_stage_error():
    value = failed_fixture()
    value["stages"][1] = saved_fixture()["stages"][1]
    with pytest.raises(SavedPipelineContractError) as caught:
        validate_saved_pipeline_result(value)
    assert caught.value.code == "analysis_after_failed_stage"


def test_arbitrary_end_error_is_not_allowed_after_failed_stage():
    value = end_error(failed_fixture())
    with pytest.raises(SavedPipelineContractError) as caught:
        validate_saved_pipeline_result(value)
    assert caught.value.code == "end_to_end_after_failed_stage"


@pytest.mark.parametrize("status,indices", [("unchanged", [0]), ("changed", []), ("unavailable", []),
                                           ("changed", [1, 0]), ("changed", [0, 0]),
                                           ("changed", [-1]), ("changed", [3]),
                                           ("changed", [True]), ("changed", [0.0]),
                                           ("unknown", []), ("changed", None)])
def test_recheck_index_contract(status, indices):
    value = end_error(saved_fixture(), "input_files_changed")
    value["input_recheck"] = {"status": status, "file_indices": indices}
    with pytest.raises(SavedPipelineContractError):
        validate_saved_pipeline_result(value)


@pytest.mark.parametrize("status,reason", [("unchanged", "input_files_changed"),
                                          ("unchanged", "input_files_recheck_failed"),
                                          ("changed", "input_files_recheck_failed"),
                                          ("unavailable", "input_files_changed")])
def test_recheck_status_and_error_reason_must_agree(status, reason):
    value = end_error(saved_fixture(), reason)
    value["input_recheck"] = {"status": status, "file_indices": [] if status == "unchanged" else [1]}
    with pytest.raises(SavedPipelineContractError) as caught:
        validate_saved_pipeline_result(value)
    assert caught.value.code == "inconsistent_input_recheck_error"


def test_end_declaration_is_union_of_adjacent_declarations():
    value = saved_fixture()
    value["stages"][1]["declaration"]["allow_resampling"] = True
    value["stages"][1]["analysis"]["configuration"]["allow_resampling"] = True
    with pytest.raises(SavedPipelineContractError) as caught:
        validate_saved_pipeline_result(value)
    assert caught.value.code == "inconsistent_analysis_configuration"
    value["end_to_end"]["analysis"]["configuration"]["allow_resampling"] = True
    assert validate_saved_pipeline_result(value) is value


def test_validation_does_not_open_files_or_execute_analysis(monkeypatch):
    def denied(*args, **kwargs):
        raise AssertionError("Saved validation must not open audio or artifacts.")
    monkeypatch.setattr(Path, "open", denied)
    assert validate_saved_pipeline_result(saved_fixture())["summary"]["exit_code"] == 0


def test_loader_reads_only_result_json(tmp_path):
    path = tmp_path / "result.json"
    value = saved_fixture()
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    assert load_saved_pipeline_result(path) == value
    assert not (tmp_path / "inputs").exists()


@pytest.mark.parametrize("raw,code", [(b'{"x":1,"x":2}', "duplicate_json_key"),
                                     (b'{"x":NaN}', "non_finite_metric"),
                                     (b'{"x":Infinity}', "non_finite_metric"),
                                     (b'\xff', "invalid_result_json"),
                                     (b'{', "invalid_result_json")])
def test_loader_strict_json_errors(tmp_path, raw, code):
    path = tmp_path / "result.json"
    path.write_bytes(raw)
    with pytest.raises(SavedPipelineContractError) as caught:
        load_saved_pipeline_result(path)
    assert caught.value.code == code


def test_loader_rejects_oversize_before_parse(tmp_path):
    path = tmp_path / "oversize.json"
    path.write_bytes(b" " * (MAX_SAVED_PIPELINE_RESULT_BYTES + 1))
    with pytest.raises(SavedPipelineContractError) as caught:
        load_saved_pipeline_result(path)
    assert caught.value.code == "result_file_too_large"


def test_loader_missing_file_has_nonprivate_code(tmp_path):
    with pytest.raises(SavedPipelineContractError) as caught:
        load_saved_pipeline_result(tmp_path / "private_name.json")
    assert caught.value.code == "result_file_read_error"
    assert "private_name" not in str(caught.value)
