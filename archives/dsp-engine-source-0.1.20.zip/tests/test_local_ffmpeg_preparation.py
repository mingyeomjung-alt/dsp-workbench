"""No-network tests of hash-pinned internal tool preparation guards."""

import hashlib
import importlib.util
import io
import json
from pathlib import Path
from urllib.request import Request
import zipfile

import pytest


@pytest.fixture
def tool():
    path = Path(__file__).resolve().parents[1] / "tools/prepare_local_ffmpeg_trial.py"
    spec = importlib.util.spec_from_file_location("local_ffmpeg_preparation", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def _archive(entries):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w") as archive:
        for name, value in entries:
            # ZipInfo normalizes native Windows separators at construction;
            # explicitly restore the raw fixture name to exercise hostile ZIPs.
            info = zipfile.ZipInfo(name)
            info.filename = name
            archive.writestr(info, value)
    return buffer.getvalue()


def _fake_download(tool, monkeypatch, data, length=None):
    class Response(io.BytesIO):
        headers = {"Content-Length": str(len(data) if length is None else length)}
        def geturl(self):
            return tool.URL
    class Opener:
        def open(self, request, **kwargs):
            assert request.full_url == tool.URL
            assert kwargs["timeout"] == 30
            return Response(data)
    monkeypatch.setattr(tool, "build_opener", lambda *a: Opener())


def test_selected_files_only_and_hash_before_extract(tool, tmp_path, monkeypatch):
    data = _archive([( "build/bin/ffmpeg.exe", b"exe"), ("build/LICENSE", b"GPL notice"),
                     ("build/README.txt", b"readme"), ("build/bin/ffprobe.exe", b"excluded")])
    monkeypatch.setattr(tool, "EXPECTED_SHA256", hashlib.sha256(data).hexdigest())
    _fake_download(tool, monkeypatch, data)
    target = tmp_path / "new_tool"
    result = tool.run(target)
    assert result["status"] == "completed"
    assert result["archive_hash_verified_before_extraction"] is True
    assert result["installed"] is False
    assert result["redistribution_performed"] is False
    assert {r["local_file"] for r in result["extracted"]} == {"ffmpeg.exe", "LICENSE", "README.txt"}
    assert (target / "ffmpeg.exe").read_bytes() == b"exe"
    assert not (target / "ffprobe.exe").exists()


def test_hash_mismatch_never_extracts_executable(tool, tmp_path, monkeypatch):
    data = _archive([("build/bin/ffmpeg.exe", b"exe"), ("build/LICENSE", b"GPL")])
    _fake_download(tool, monkeypatch, data)
    target = tmp_path / "bad_hash"
    with pytest.raises(ValueError, match="SHA-256"):
        tool.run(target)
    assert not (target / "ffmpeg.exe").exists()
    assert json.loads((target / "preparation_result.json").read_text("utf-8"))["status"] == "incomplete"


@pytest.mark.parametrize("name", ["../escape.exe", "build/../escape.exe", "build\\escape.exe", "/outside.exe"])
def test_unsafe_member_aborts_before_selected_extraction(tool, tmp_path, monkeypatch, name):
    data = _archive([("build/bin/ffmpeg.exe", b"exe"), ("build/LICENSE", b"GPL"), (name, b"x")])
    monkeypatch.setattr(tool, "EXPECTED_SHA256", hashlib.sha256(data).hexdigest())
    _fake_download(tool, monkeypatch, data)
    target = tmp_path / "unsafe"
    with pytest.raises(ValueError, match="unsafe member"):
        tool.run(target)
    assert not (target / "ffmpeg.exe").exists()


def test_missing_license_aborts_before_extraction(tool, tmp_path, monkeypatch):
    data = _archive([("build/bin/ffmpeg.exe", b"exe")])
    monkeypatch.setattr(tool, "EXPECTED_SHA256", hashlib.sha256(data).hexdigest())
    _fake_download(tool, monkeypatch, data)
    with pytest.raises(ValueError, match="license notice"):
        tool.run(tmp_path / "no_license")


def test_content_length_limit_stops_before_archive(tool, tmp_path, monkeypatch):
    _fake_download(tool, monkeypatch, b"small", length=tool.MAX_ARCHIVE_BYTES + 1)
    target = tmp_path / "oversized"
    with pytest.raises(ValueError, match="size limit"):
        tool.run(target)
    assert not (target / "ffmpeg-9.0.2-essentials_build.zip").exists()


@pytest.mark.parametrize("url", ["http://www.gyan.dev/file", "https://evil.example/file", "https://www.gyan.dev.evil.example/file"])
def test_redirect_cannot_leave_primary_https_host(tool, url):
    with pytest.raises(ValueError, match="primary HTTPS host"):
        tool._SamePrimaryHost().redirect_request(Request(tool.URL), None, 302, "", {}, url)


def test_preparation_destination_must_be_new(tool, tmp_path):
    with pytest.raises(FileExistsError):
        tool.run(tmp_path)
