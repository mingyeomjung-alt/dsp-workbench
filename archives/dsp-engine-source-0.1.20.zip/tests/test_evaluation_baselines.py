"""Contract/regression checks, not a final defect-detection evaluation."""

import json

import numpy as np
import pytest
from scipy.signal import chirp, resample_poly

from audio_regression.audio import AudioInputError, decode_wav, encode_wav
from audio_regression.engine import EngineConfig, EngineConfigError
from audio_regression.evaluation_baselines import BASELINE_METHODS, evaluate_baseline
from audio_regression.profiles import telephone_transform_samples


METHODS = sorted(BASELINE_METHODS)


def _signal(seed=98271, seconds=5.0):
    rate = 16000
    rng = np.random.default_rng(seed)
    time = np.arange(round(seconds * rate)) / rate
    noise = np.convolve(rng.normal(size=len(time)), [.1, .2, .4, .2, .1], mode="same")
    envelope = np.interp(time, np.linspace(0, seconds, 61), rng.uniform(.25, 1, 61))
    values = envelope * (noise + .18 * chirp(time, f0=250, f1=2800, t1=seconds))
    return values * (.20 / np.max(np.abs(values)))


def _audio(samples, rate=16000):
    return decode_wav(encode_wav(samples, rate))


def _evaluate(reference, processed, method, config=None):
    return evaluate_baseline(reference, processed, config or EngineConfig(), method=method)


def _assert_contract(result):
    assert result["status"] in {"analyzed", "withheld"}
    assert result["events"] is None
    assert result["content_preservation_status"] == "not_assessed_by_comparison_baseline"
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    if result["status"] == "analyzed":
        assert result["reason_code"] is None
        assert type(result["anomaly_candidate"]) is bool
        assert result["measurement_available"] is True
    else:
        assert result["anomaly_candidate"] is None
        assert result["reason_code"] is not None
    json.dumps(result, allow_nan=False)


@pytest.mark.parametrize("method", METHODS)
def test_unchanged_signal_is_measured_without_a_content_approval(method):
    audio = _audio(_signal())
    result = _evaluate(audio, audio, method)
    _assert_contract(result)
    assert result["status"] == "analyzed"
    assert result["anomaly_candidate"] is False
    assert result["metrics"]["normalized_rmse"] == 0


def test_global_offset_removes_delay_residual_but_raw_difference_does_not():
    signal = _signal()
    reference = _audio(signal)
    processed = _audio(np.concatenate([np.zeros(240 * 16), signal]))
    direct = _evaluate(reference, processed, "direct_difference")
    global_only = _evaluate(reference, processed, "global_only")
    _assert_contract(direct)
    _assert_contract(global_only)
    assert direct["anomaly_candidate"] is True
    assert global_only["anomaly_candidate"] is False
    assert direct["metrics"]["normalized_rmse"] > .5
    assert global_only["metrics"]["normalized_rmse"] < .01
    assert global_only["metrics"]["estimated_delay_ms"] == pytest.approx(240, abs=1)
    assert global_only["diagnostics"]["unaligned_edge_audit"]["all_unaligned_edges_demonstrably_silent"] is True


@pytest.mark.parametrize("method", ["global_only", "no_local_alignment"])
def test_longer_file_due_to_proven_silent_padding_is_not_anomalous(method):
    signal = _signal()
    result = _evaluate(_audio(signal), _audio(np.concatenate([np.zeros(240 * 16), signal])), method)
    _assert_contract(result)
    assert result["status"] == "analyzed"
    assert result["metrics"]["normalized_rmse"] < .01
    assert result["metrics"]["duration_difference_ms"] == pytest.approx(240)
    assert result["anomaly_candidate"] is False
    assert result["diagnostics"]["anomaly_reasons"] == []


@pytest.mark.parametrize("method", ["global_only", "no_local_alignment"])
def test_equal_length_cropped_non_silent_tail_is_not_hidden_by_perfect_overlap(method):
    signal = _signal()
    reference = _audio(signal)
    processed = _audio(np.concatenate([np.zeros(240 * 16), signal[:-240 * 16]]))
    result = _evaluate(reference, processed, method)
    _assert_contract(result)
    assert result["status"] == "analyzed"
    assert result["metrics"]["normalized_rmse"] < .01
    assert result["metrics"]["duration_difference_ms"] == 0
    assert result["anomaly_candidate"] is True
    assert result["diagnostics"]["unaligned_edge_audit"]["unexplained_non_silent_edge"] is True
    assert "unaligned_non_silent_file_edge" in result["diagnostics"]["anomaly_reasons"]


@pytest.mark.parametrize("method", ["global_only", "no_local_alignment"])
def test_non_silent_added_prefix_is_anomalous_even_if_rest_is_identical(method):
    signal = _signal()
    added = _signal(seed=19)[:240 * 16]
    result = _evaluate(_audio(signal), _audio(np.concatenate([added, signal])), method)
    _assert_contract(result)
    assert result["status"] == "analyzed"
    assert result["metrics"]["normalized_rmse"] < .01
    assert result["anomaly_candidate"] is True
    assert "unexplained_duration_difference_exceeds_fixed_rule" in result["diagnostics"]["anomaly_reasons"]


@pytest.mark.parametrize("method", METHODS)
def test_declared_gain_is_a_global_fit_without_changing_sources(method):
    signal = _signal()
    reference, processed = _audio(signal), _audio(.55 * signal)
    reference_before, processed_before = reference.samples.copy(), processed.samples.copy()
    undeclared = _evaluate(reference, processed, method)
    declared = _evaluate(reference, processed, method, EngineConfig(allow_gain=True))
    _assert_contract(declared)
    assert undeclared["anomaly_candidate"] is True
    assert declared["anomaly_candidate"] is False
    assert declared["metrics"]["comparison"]["gain_estimate"] == pytest.approx(.55, abs=.01)
    assert declared["metrics"]["raw"] == undeclared["metrics"]["raw"]
    np.testing.assert_array_equal(reference.samples, reference_before)
    np.testing.assert_array_equal(processed.samples, processed_before)
    assert declared["reference"] == reference.metadata()
    assert declared["processed"] == processed.metadata()


@pytest.mark.parametrize("method", METHODS)
def test_resampling_must_be_declared_and_is_not_an_anomaly(method):
    signal = _signal()
    reference, processed = _audio(signal), _audio(resample_poly(signal, 1, 2), 8000)
    withheld = _evaluate(reference, processed, method)
    _assert_contract(withheld)
    assert withheld["reason_code"] == "resampling_not_declared"
    assert withheld["measurement_available"] is False
    declared = _evaluate(reference, processed, method, EngineConfig(allow_resampling=True))
    _assert_contract(declared)
    assert declared["status"] == "analyzed"
    assert declared["anomaly_candidate"] is False


@pytest.mark.parametrize("method", METHODS)
def test_telephone_profile_is_shared_with_the_candidate(method):
    reference = _audio(_signal())
    processed = _audio(telephone_transform_samples(reference), 8000)
    result = _evaluate(reference, processed, method, EngineConfig(profile="telephone", allow_resampling=True))
    _assert_contract(result)
    assert result["status"] == "analyzed", result
    assert result["analysis"]["fixed_normalized_rmse_threshold"] == .25
    assert result["anomaly_candidate"] is False


@pytest.mark.parametrize("method", METHODS)
@pytest.mark.parametrize("level", [0.0, .2])
def test_silence_and_constant_dc_are_withheld(method, level):
    audio = _audio(np.full(80000, level))
    result = _evaluate(audio, audio, method)
    _assert_contract(result)
    assert result["reason_code"] == "insufficient_signal_variation"
    assert result["measurement_available"] is False


@pytest.mark.parametrize("method", METHODS)
def test_periodic_signal_has_no_comparison_decision(method):
    time = np.arange(80000) / 16000
    audio = _audio(.15 * np.sin(2 * np.pi * 440 * time))
    result = _evaluate(audio, audio, method)
    _assert_contract(result)
    assert result["reason_code"] == "ambiguous_alignment"
    assert result["measurement_available"] is True


@pytest.mark.parametrize("method", METHODS)
@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_controls_do_not_return_typed_defect_events(method, kind):
    signal = _signal()
    first, last = 2000 * 16, 2400 * 16
    edited = (
        np.concatenate([signal[:first], signal[last:]]) if kind == "delete"
        else np.concatenate([signal[:last], signal[first:last], signal[last:]])
    )
    result = _evaluate(_audio(signal), _audio(edited), method)
    _assert_contract(result)
    assert result["events"] is None
    assert result["anomaly_candidate"] is True or result["status"] == "withheld"


def test_no_local_alignment_is_an_ablation_without_calling_edit_alignment(monkeypatch):
    def fail(*args, **kwargs):
        raise AssertionError("A constant-offset ablation must not run local alignment.")
    monkeypatch.setattr("audio_regression.engine.edit_align", fail)
    audio = _audio(_signal())
    result = _evaluate(audio, audio, "no_local_alignment")
    _assert_contract(result)
    assert result["analysis"]["ablation_diagnostic"] is True
    assert result["analysis"]["local_alignment_enabled"] is False
    checks = result["diagnostics"]["constant_offset_checks"]
    assert checks["constant_offset_active_feature_frame_count"] > 0
    assert checks["mean_constant_offset_feature_cost"] < 1e-12
    assert checks["minimum_local_correlation"] > .999


def test_constant_offset_ablation_refuses_local_replacement():
    signal = _signal()
    replaced = signal.copy()
    replaced[2000 * 16:2400 * 16] = _signal(seed=47)[2000 * 16:2400 * 16]
    result = _evaluate(_audio(signal), _audio(replaced), "no_local_alignment")
    _assert_contract(result)
    assert result["status"] == "withheld"
    assert result["reason_code"] in {"unexplained_local_signal_change", "insufficient_unambiguous_anchors"}


@pytest.mark.parametrize("method", [None, 1, "local", "", [], {}])
def test_invalid_method_is_a_configuration_error(method):
    audio = _audio(_signal())
    with pytest.raises(EngineConfigError):
        evaluate_baseline(audio, audio, EngineConfig(), method=method)


def test_invalid_config_and_audio_use_stable_errors():
    audio = _audio(_signal())
    with pytest.raises(EngineConfigError):
        evaluate_baseline(audio, audio, None, method="global_only")
    with pytest.raises(AudioInputError):
        evaluate_baseline(None, audio, EngineConfig(), method="global_only")


def test_zero_delay_budget_is_supported_and_boundary_delay_is_withheld():
    signal = _signal()
    audio = _audio(signal)
    no_delay = _evaluate(audio, audio, "global_only", EngineConfig(max_delay_ms=0))
    assert no_delay["status"] == "analyzed"
    delayed = _audio(np.concatenate([np.zeros(240 * 16), signal]))
    bounded = _evaluate(audio, delayed, "global_only", EngineConfig(max_delay_ms=240))
    _assert_contract(bounded)
    assert bounded["reason_code"] == "delay_at_search_boundary"
