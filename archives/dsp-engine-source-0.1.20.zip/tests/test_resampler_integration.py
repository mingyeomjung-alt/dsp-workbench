"""M3 opt-in facade/report checks, not natural-audio performance evidence."""
from copy import deepcopy
import hashlib
import json

import numpy as np
import pytest
from scipy.signal import resample, resample_poly

from audio_regression.api import analyze_pair, analyze_pair_with_trace
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.check_policy import check_result
from audio_regression.engine import EngineConfigError
from audio_regression.fixtures import generate_case
from audio_regression.handoff_cli import main
from audio_regression.reporting import render_html
from audio_regression.result_contract import validate_analysis_result
from audio_regression.review_diagnostics import build_review_diagnostics

MODEL = "scipy_fft_periodic_48k_16k_pcm16_postedit_v1"
OPTIONS = {"engine": "v12", "allow_resampling": True, "resampling_model": MODEL}


def pair(tmp_path, kind="normal"):
    raw = generate_case(seed=202610158481, duration_seconds=4,
                        sample_rate_hz=48000).reference_wav
    x = decode_wav(raw).samples
    # Producer intentionally uses SciPy's public full-record implementation,
    # not the candidate's renderer or edit helper.
    canonical = np.rint(resample(x, len(x) // 3) * 32768) / 32768
    if kind == "delete":
        y = np.concatenate((canonical[:24000], canonical[25600:]))
    elif kind == "repeat":
        y = np.concatenate((canonical[:25600], canonical[24000:25600], canonical[25600:]))
    elif kind == "head":
        y = canonical[1600:]
    elif kind == "tail":
        y = canonical[:-1600]
    elif kind == "wrong_filter":
        y = np.rint(resample_poly(x, 1, 3) * 32768) / 32768
    else:
        y = canonical.copy()
        if kind == "damage":
            y[12345] += 1 / 32768
    original, processed = tmp_path / "reference.wav", tmp_path / "processed.wav"
    original.write_bytes(raw)
    processed.write_bytes(encode_wav(y, 16000))
    return original, processed


@pytest.mark.parametrize("kind", ["normal", "delete", "repeat", "head", "tail"])
def test_named_model_keeps_real_input_and_derived_reference_distinct(tmp_path, kind):
    original, processed = pair(tmp_path, kind)
    hashes = [hashlib.sha256(p.read_bytes()).hexdigest() for p in (original, processed)]
    result, trace = analyze_pair_with_trace(original, processed, **OPTIONS)
    assert result == analyze_pair(original, processed, **OPTIONS)
    assert validate_analysis_result(result) is result
    assert result["status"] == "analyzed"
    assert result["reference"]["sample_rate_hz"] == 48000
    assert result["resampling_reference"]["sample_rate_hz"] == 16000
    assert result["reference"]["sample_count"] == 3 * result["resampling_reference"]["sample_count"]
    assert result["reference"]["sha256"] == hashes[0]
    assert result["processed"]["sha256"] == hashes[1]
    assert result["resampling_reference"]["sha256"] != hashes[0]
    assert result["analysis"]["sample_rate_hz"] == 16000
    assert check_result(result)["exit_code"] == (0 if kind == "normal" else 1)
    assert result["complete_audio_approval"] is False
    assert hashes == [hashlib.sha256(p.read_bytes()).hexdigest() for p in (original, processed)]
    if kind in {"head", "tail"}:
        assert result["events"][0]["location"] == kind
    report = render_html(result)
    assert "실제 48kHz 파일" in report and "비교용 WAV SHA-256" in report
    assert MODEL in report and "실제 처리 순서" in report


@pytest.mark.parametrize("kind", ["wrong_filter", "damage"])
def test_model_mismatch_cannot_escape_through_old_clear(tmp_path, kind):
    original, processed = pair(tmp_path, kind)
    result, trace = analyze_pair_with_trace(original, processed, **OPTIONS)
    assert result["status"] == "withheld" and result["events"] is None
    assert check_result(result)["gate_state"] == "blocked"
    block = result["review_diagnostics"]
    assert block["trace_availability"] == "recorded"
    assert len(block["stages"]) == 1
    assert block["stages"][0]["engine"] == "local_content_alignment_v12"
    broken = deepcopy(trace)
    broken["reference_sha256"] = "0" * 64
    assert build_review_diagnostics(result, broken)["trace_availability"] == "unavailable"
    report = render_html(result)
    assert "판단 보류" in report


@pytest.mark.parametrize("overrides", [
    {"resampling_model": None}, {"resampling_model": "unknown"},
    {"allow_gain": True}, {"allow_resampling": False}, {"profile": "telephone"},
    {"engine": "v11"}, {"engine": "v1"}, {"engine": "v13"},
])
def test_bad_model_configuration_rejected_before_read(overrides):
    with pytest.raises(EngineConfigError):
        analyze_pair("missing.wav", "also-missing.wav", **{**OPTIONS, **overrides})
    with pytest.raises(EngineConfigError):
        analyze_pair_with_trace("missing.wav", "also-missing.wav", **{**OPTIONS, **overrides})


def test_cli_named_model_check_report_and_no_overwrite(tmp_path, capsys):
    original, processed = pair(tmp_path, "head")
    output, report = tmp_path / "result.json", tmp_path / "report.html"
    assert main(["analyze", "--engine", "v12", "--declare-resampling",
                 "--resampling-model", MODEL, "--reference", str(original),
                 "--processed", str(processed), "--output", str(output)]) == 0
    capsys.readouterr()
    assert main(["check", "--input", str(output)]) == 1
    assert json.loads(capsys.readouterr().out)["complete_audio_approval"] is False
    assert main(["report", "--input", str(output), "--output", str(report)]) == 0
    capsys.readouterr()
    saved = report.read_bytes()
    assert "시작부분 누락 후보" in saved.decode("utf-8")
    assert main(["report", "--input", str(output), "--output", str(report)]) == 3
    assert report.read_bytes() == saved
