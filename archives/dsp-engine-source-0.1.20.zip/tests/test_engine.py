"""Independent black-box checks of the M2 local-content contract.

The detector receives only decoded audio and normal-transformation declarations.
These synthetic development checks are not a commercial accuracy evaluation and
do not use the fixture generator or a defect answer key in detector inputs.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np
import pytest
from scipy.signal import chirp, resample_poly

from audio_regression.audio import decode_wav, encode_wav
from audio_regression.engine import (
    EngineConfig,
    EngineConfigError,
    analyze_buffers,
    analyze_wavs,
)


def _signal(*, sample_rate_hz: int = 16000, seconds: float = 6.0, seed: int = 5821) -> np.ndarray:
    """Nonperiodic colored noise plus chirps with independently varying level."""
    rng = np.random.default_rng(seed)
    count = round(sample_rate_hz * seconds)
    time = np.arange(count) / sample_rate_hz
    colored = np.convolve(
        rng.standard_normal(count), np.array([0.1, 0.2, 0.4, 0.2, 0.1]), mode="same"
    )
    knots = rng.uniform(0.3, 1.0, 53)
    envelope = np.interp(np.linspace(0, 52, count), np.arange(53), knots)
    changing_tone = chirp(time, f0=260.0, f1=2600.0, t1=seconds, method="quadratic")
    values = envelope * (colored + 0.2 * changing_tone)
    return values * (0.24 / np.max(np.abs(values)))


def _audio(samples: np.ndarray, sample_rate_hz: int = 16000):
    return decode_wav(encode_wav(samples, sample_rate_hz))


def _analyze(reference, processed, *, sample_rate_hz=16000, config=None):
    return analyze_buffers(
        _audio(reference, sample_rate_hz), _audio(processed, sample_rate_hz), config=config
    )


def _assert_contract(result: dict) -> None:
    assert result["schema_version"] == 1
    assert result["engine"] == "local_content_alignment_v1"
    assert result["status"] in {"analyzed", "withheld"}
    json.dumps(result, allow_nan=False)
    if result["status"] == "withheld":
        assert result["content_preservation_status"] == "withheld"
        assert isinstance(result["reason_code"], str) and result["reason_code"]
        assert result["events"] is None
    else:
        assert result["reason_code"] is None
        assert isinstance(result["events"], list)
        assert result["content_preservation_status"] == (
            "defect_candidates" if result["events"] else "no_supported_defect_candidates"
        )
        for event in result["events"]:
            assert event["type"] in {"delete", "repeat"}
            if event["type"] == "delete":
                _assert_interval(event["reference_interval_ms"])
                assert np.isfinite(event["processed_boundary_ms"])
                assert event["processed_boundary_ms"] >= 0
            else:
                _assert_interval(event["reference_source_interval_ms"])
                _assert_interval(event["processed_added_interval_ms"])


def _assert_interval(interval) -> None:
    assert isinstance(interval, list) and len(interval) == 2
    assert all(np.isfinite(value) for value in interval)
    assert 0 <= interval[0] < interval[1]


def _assert_empty(result: dict) -> None:
    _assert_contract(result)
    assert result["status"] == "analyzed"
    assert result["events"] == []


def _assert_event(result: dict, event_type: str) -> dict:
    _assert_contract(result)
    assert result["status"] == "analyzed"
    events = [event for event in result["events"] if event["type"] == event_type]
    assert len(events) == 1
    return events[0]


def _assert_near_interval(actual, expected) -> None:
    assert actual == pytest.approx(expected, abs=100.0)


@pytest.mark.parametrize("sample_rate_hz", [8000, 16000, 44100, 48000])
def test_identical_nonperiodic_audio_has_no_supported_defect_candidates(sample_rate_hz):
    signal = _signal(sample_rate_hz=sample_rate_hz)
    _assert_empty(_analyze(signal, signal, sample_rate_hz=sample_rate_hz))


@pytest.mark.parametrize("delay_ms", [80.0, 240.0, 650.0])
def test_silent_leading_latency_is_not_a_content_insertion(delay_ms):
    signal = _signal()
    delayed = np.concatenate([np.zeros(round(delay_ms * 16)), signal])
    _assert_empty(_analyze(signal, delayed))


def test_reference_leading_latency_is_not_a_deletion():
    signal = _signal()
    delayed_reference = np.concatenate([np.zeros(240 * 16), signal])
    _assert_empty(_analyze(delayed_reference, signal))


def test_declared_global_delay_and_gain_have_no_defect_candidates():
    signal = _signal()
    delayed_and_quieter = np.concatenate([np.zeros(320 * 16), signal * 0.45])
    _assert_empty(_analyze(signal, delayed_and_quieter, config=EngineConfig(allow_gain=True)))


def test_differing_rates_require_declaration_and_normal_resampling_is_allowed():
    signal = _signal()
    reference = _audio(signal, 16000)
    processed = _audio(resample_poly(signal, 1, 2), 8000)
    withheld = analyze_buffers(reference, processed)
    _assert_contract(withheld)
    assert withheld["status"] == "withheld"
    _assert_empty(analyze_buffers(reference, processed, config=EngineConfig(allow_resampling=True)))


@pytest.mark.parametrize("duration_ms", [200.0, 400.0, 750.0])
@pytest.mark.parametrize("sample_rate_hz", [8000, 16000, 48000])
def test_internal_deletion_is_located_on_the_reference_axis(duration_ms, sample_rate_hz):
    signal = _signal(sample_rate_hz=sample_rate_hz)
    start_ms = 1700.0
    end_ms = start_ms + duration_ms
    first = round(start_ms * sample_rate_hz / 1000)
    last = round(end_ms * sample_rate_hz / 1000)
    processed = np.concatenate([signal[:first], signal[last:]])
    result = _analyze(signal, processed, sample_rate_hz=sample_rate_hz)
    event = _assert_event(result, "delete")
    assert len(result["events"]) == 1
    _assert_near_interval(event["reference_interval_ms"], [start_ms, end_ms])
    assert event["processed_boundary_ms"] == pytest.approx(start_ms, abs=100.0)


@pytest.mark.parametrize("duration_ms", [200.0, 400.0, 750.0])
def test_internal_repeat_identifies_the_inserted_copy_and_its_reference_source(duration_ms):
    signal = _signal()
    start_ms = 1800.0
    stop_ms = start_ms + duration_ms
    first, last = round(start_ms * 16), round(stop_ms * 16)
    processed = np.concatenate([signal[:last], signal[first:last], signal[last:]])
    result = _analyze(signal, processed)
    event = _assert_event(result, "repeat")
    assert len(result["events"]) == 1
    _assert_near_interval(event["reference_source_interval_ms"], [start_ms, stop_ms])
    _assert_near_interval(event["processed_added_interval_ms"], [stop_ms, stop_ms + duration_ms])


def test_deletion_with_declared_latency_and_gain_retains_correct_file_time_axes():
    signal = _signal()
    first, last = 1500 * 16, 1950 * 16
    deleted = np.concatenate([signal[:first], signal[last:]])
    processed = np.concatenate([np.zeros(240 * 16), deleted * 0.5])
    result = _analyze(signal, processed, config=EngineConfig(allow_gain=True))
    event = _assert_event(result, "delete")
    assert len(result["events"]) == 1
    _assert_near_interval(event["reference_interval_ms"], [1500.0, 1950.0])
    assert event["processed_boundary_ms"] == pytest.approx(1740.0, abs=100.0)


def test_equal_duration_deletion_and_repeat_are_not_guessed_from_total_length():
    signal = _signal()
    # Remove 1.2..1.5 seconds, then add a copy of original 3.6..3.9 seconds.
    processed = np.concatenate([
        signal[:1200 * 16], signal[1500 * 16:3900 * 16],
        signal[3600 * 16:3900 * 16], signal[3900 * 16:],
    ])
    assert processed.size == signal.size
    result = _analyze(signal, processed)
    deletion = _assert_event(result, "delete")
    repetition = _assert_event(result, "repeat")
    assert len(result["events"]) == 2
    _assert_near_interval(deletion["reference_interval_ms"], [1200.0, 1500.0])
    assert deletion["processed_boundary_ms"] == pytest.approx(1200.0, abs=100.0)
    _assert_near_interval(repetition["reference_source_interval_ms"], [3600.0, 3900.0])
    _assert_near_interval(repetition["processed_added_interval_ms"], [3600.0, 3900.0])


def test_inserted_unrelated_content_is_not_reported_as_a_repeat():
    signal = _signal()
    new_content = _signal(seed=1057)[32000:38400]
    processed = np.concatenate([signal[:32000], new_content, signal[32000:]])
    result = _analyze(signal, processed)
    _assert_contract(result)
    assert result["status"] == "withheld"


def test_duration_preserving_zero_dropout_is_not_a_deletion():
    signal = _signal()
    processed = signal.copy()
    processed[1800 * 16:2200 * 16] = 0
    result = _analyze(signal, processed)
    _assert_contract(result)
    # Dropout is a different defect, outside M2's supported deletion contract.
    assert result["status"] == "withheld"


@pytest.mark.parametrize("end_ms, other_seed", [(2000.0, 13), (2200.0, 11)])
def test_duration_preserving_unrelated_replacement_is_not_hidden_by_fragmented_matches(end_ms, other_seed):
    signal = _signal()
    unrelated = _signal(seed=other_seed)
    processed = signal.copy()
    first, last = 1800 * 16, round(end_ms * 16)
    processed[first:last] = unrelated[first:last]
    result = _analyze(signal, processed)
    _assert_contract(result)
    # A delete followed by an unrelated insertion is not a supported repeat.
    # Short spurious correspondence fragments must not produce a false clean
    # report or erase the unexplained replacement between reliable anchors.
    assert result["status"] == "withheld"


def test_off_grid_leading_delay_is_a_normal_change():
    signal = _signal()
    processed = np.concatenate([np.zeros(round(243.25 * 16)), signal])
    _assert_empty(_analyze(signal, processed))


@pytest.mark.parametrize("event_type", ["delete", "repeat"])
def test_off_grid_defect_with_delay_and_gain_uses_observed_boundaries(event_type):
    signal = _signal()
    start_ms, length_ms, delay_ms = 1703.5, 317.75, 243.25
    end_ms = start_ms + length_ms
    first, last = round(start_ms * 16), round(end_ms * 16)
    if event_type == "delete":
        edited = np.concatenate([signal[:first], signal[last:]])
    else:
        edited = np.concatenate([signal[:last], signal[first:last], signal[last:]])
    processed = np.concatenate([np.zeros(round(delay_ms * 16)), edited * 0.55])
    result = _analyze(signal, processed, config=EngineConfig(allow_gain=True))
    event = _assert_event(result, event_type)
    assert len(result["events"]) == 1
    if event_type == "delete":
        _assert_near_interval(event["reference_interval_ms"], [start_ms, end_ms])
        assert event["processed_boundary_ms"] == pytest.approx(start_ms + delay_ms, abs=100.0)
    else:
        _assert_near_interval(event["reference_source_interval_ms"], [start_ms, end_ms])
        _assert_near_interval(
            event["processed_added_interval_ms"],
            [end_ms + delay_ms, end_ms + delay_ms + length_ms],
        )


@pytest.mark.parametrize("side", ["start", "end"])
def test_content_cropped_at_file_edges_is_not_hidden_by_global_alignment(side):
    signal = _signal()
    cropped = signal[4800:] if side == "start" else signal[:-4800]
    result = _analyze(signal, cropped)
    _assert_contract(result)
    assert result["status"] == "withheld"


@pytest.mark.parametrize("value", [0.0, 0.125, -0.25])
def test_silence_and_dc_offset_are_withheld(value):
    signal = np.full(6 * 16000, value)
    result = _analyze(signal, signal)
    _assert_contract(result)
    assert result["status"] == "withheld"


def test_periodic_tone_is_withheld_due_to_ambiguous_content_alignment():
    time = np.arange(6 * 16000) / 16000
    periodic = 0.2 * np.sin(2 * np.pi * 440 * time)
    result = _analyze(periodic, periodic)
    _assert_contract(result)
    assert result["status"] == "withheld"


def test_unrelated_audio_is_withheld_without_fabricated_events():
    result = _analyze(_signal(seed=217), _signal(seed=315))
    _assert_contract(result)
    assert result["status"] == "withheld"


@pytest.mark.parametrize(
    "kwargs",
    [
        {"profile": "unknown"}, {"profile": None}, {"profile": 1}, {"profile": []},
        {"allow_gain": 1}, {"allow_gain": "false"}, {"allow_gain": None},
        {"allow_resampling": 0}, {"allow_resampling": "true"}, {"allow_resampling": None},
        {"max_delay_ms": -1}, {"max_delay_ms": 5000.1},
        {"max_delay_ms": float("nan")}, {"max_delay_ms": float("inf")},
        {"max_delay_ms": True}, {"max_delay_ms": "1000"}, {"max_delay_ms": 10**1000},
    ],
)
def test_invalid_engine_configuration_has_stable_error_code(kwargs):
    with pytest.raises(EngineConfigError) as caught:
        config = EngineConfig(**kwargs)
        _analyze(_signal(), _signal(), config=config)
    assert caught.value.code == "invalid_configuration"


@pytest.mark.parametrize("maximum", [0, np.float32(1000.0), np.int64(1000)])
def test_valid_numeric_delay_config_is_json_safe(maximum):
    result = _analyze(_signal(), _signal(), config=EngineConfig(max_delay_ms=maximum))
    _assert_empty(result)


def test_buffer_analysis_does_not_modify_or_contaminate_raw_samples():
    reference = _audio(_signal())
    processed = _audio(_signal() * 0.5)
    reference_copy, processed_copy = reference.samples.copy(), processed.samples.copy()
    before = analyze_buffers(reference, processed)
    analyze_buffers(reference, processed, config=EngineConfig(allow_gain=True))
    after = analyze_buffers(reference, processed)
    assert before == after
    np.testing.assert_array_equal(reference.samples, reference_copy)
    np.testing.assert_array_equal(processed.samples, processed_copy)


def test_path_analysis_keeps_source_files_and_their_exact_hashes(tmp_path: Path):
    reference_bytes = encode_wav(_signal(), 16000)
    processed_bytes = encode_wav(_signal() * 0.5, 16000)
    reference_path, processed_path = tmp_path / "reference.wav", tmp_path / "processed.wav"
    reference_path.write_bytes(reference_bytes)
    processed_path.write_bytes(processed_bytes)
    result = analyze_wavs(reference_path, processed_path, config=EngineConfig(allow_gain=True))
    _assert_empty(result)
    assert result["reference"]["sha256"] == hashlib.sha256(reference_bytes).hexdigest()
    assert result["processed"]["sha256"] == hashlib.sha256(processed_bytes).hexdigest()
    assert reference_path.read_bytes() == reference_bytes
    assert processed_path.read_bytes() == processed_bytes


def test_engine_import_has_no_voiceguard_or_model_runtime_dependency():
    script = (
        "import sys; import audio_regression.engine; "
        "forbidden = ('voiceguard', 'torch', 'onnxruntime', 'sherpa_onnx'); "
        "assert not any(name == prefix or name.startswith(prefix + '.') "
        "for name in sys.modules for prefix in forbidden)"
    )
    environment = dict(os.environ)
    source_path = str(Path(__file__).resolve().parents[1] / "src")
    old_path = environment.get("PYTHONPATH")
    environment["PYTHONPATH"] = source_path + (os.pathsep + old_path if old_path else "")
    completed = subprocess.run(
        [sys.executable, "-c", script], capture_output=True, text=True,
        check=False, env=environment,
    )
    assert completed.returncode == 0, completed.stderr
