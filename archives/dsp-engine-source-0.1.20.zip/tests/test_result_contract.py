"""Contract tests use saved development JSON and invented result geometry only."""

from copy import deepcopy
import json
from pathlib import Path

import pytest

from audio_regression.result_contract import (
    MAX_RESULT_BYTES, ResultContractError, load_analysis_result, validate_analysis_result,
)


DEVELOPMENT = Path(__file__).resolve().parent / "fixtures" / "results"
DEVELOPMENT_RESULTS = [DEVELOPMENT / f"synthetic_{profile}_{kind}.json"
                       for profile in ("basic", "telephone")
                       for kind in ("clean", "delete", "repeat")]
# Historical public development artifacts are checked only in workspaces that
# retain them. They are not a source-archive dependency or an evaluation re-run.
OPTIONAL_PUBLIC_DEVELOPMENT = Path(__file__).resolve().parents[1] / "examples" / "m2_20261012"
OPTIONAL_PUBLIC_RESULTS = sorted(OPTIONAL_PUBLIC_DEVELOPMENT.glob("public_*/result.json"))


def _result(kind="clean", profile="basic"):
    return deepcopy(load_analysis_result(DEVELOPMENT / f"synthetic_{profile}_{kind}.json"))


def _withheld():
    value = _result()
    value.update(status="withheld", content_preservation_status="withheld",
                 reason_code="insufficient_signal_variation", events=None, diagnostics={})
    value.pop("alignment_segments")
    return value


def _set(value, path, replacement):
    container = value
    for key in path[:-1]:
        container = container[key]
    container[path[-1]] = replacement


def _assert_rejected(value, code):
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(value)
    assert caught.value.code == code


@pytest.mark.parametrize("path", DEVELOPMENT_RESULTS, ids=lambda path: path.stem)
def test_saved_development_results_validate_read_only(path):
    before = path.read_bytes()
    result = load_analysis_result(path)
    assert result["engine"] == "local_content_alignment_v1"
    assert path.read_bytes() == before


@pytest.mark.parametrize("path", OPTIONAL_PUBLIC_RESULTS or [None],
                         ids=lambda path: path.parent.name if path is not None else "not-in-source-archive")
def test_optional_saved_public_results_validate_read_only(path):
    if path is None:
        pytest.skip("Optional public development artifacts are not distributed in the source archive.")
    before = path.read_bytes()
    result = load_analysis_result(path)
    assert result["engine"] == "local_content_alignment_v1"
    assert path.read_bytes() == before


def test_validation_returns_original_without_modification():
    result = _result()
    before = deepcopy(result)
    assert validate_analysis_result(result) is result
    assert result == before


@pytest.mark.parametrize("value", [None, [], "{}", True, 1])
def test_result_must_be_a_dictionary(value):
    _assert_rejected(value, "invalid_result_type")


@pytest.mark.parametrize("path,replacement,code", [
    (("schema_version",), 2, "unsupported_schema_version"),
    (("schema_version",), True, "unsupported_schema_version"),
    (("engine",), "global_alignment_baseline_v1", "unsupported_engine"),
    (("status",), "measured", "unsupported_result_status"),
    (("status",), [], "unsupported_result_status"),
    (("configuration", "profile"), "future", "unsupported_profile"),
    (("configuration", "profile"), {}, "unsupported_profile"),
    (("configuration", "allow_gain"), 0, "invalid_configuration"),
    (("configuration", "max_delay_ms"), 5001, "invalid_configuration"),
    (("complete_audio_approval",), True, "invalid_approval_claim"),
    (("complete_audio_approval",), 0, "invalid_approval_claim"),
    (("commercial_performance_validated",), True, "invalid_approval_claim"),
    (("analysis", "diagnostic_rules_not_calibrated_probabilities"), False, "invalid_analysis_method"),
    (("analysis", "method"), "global_alignment", "invalid_analysis_method"),
    (("reason_code",), "silent", "inconsistent_result_status"),
    (("events",), None, "inconsistent_result_status"),
    (("content_preservation_status",), "defect_candidates", "inconsistent_result_status"),
    (("reference", "duration_ms"), 6100, "inconsistent_audio_duration"),
    (("reference", "sample_count"), True, "invalid_audio_metadata"),
    (("reference", "sha256"), "not_a_hash", "invalid_audio_metadata"),
    (("reference", "rms"), 1.1, "invalid_audio_metadata"),
    (("reference", "peak"), 0.001, "invalid_audio_metadata"),
    (("diagnostics", "matched_analysis_samples"), 1_000_000, "inconsistent_matched_sample_count"),
    (("diagnostics", "matched_analysis_samples"), 100, "inconsistent_matched_sample_count"),
    (("diagnostics", "matched_normalized_rmse"), 10, "inconsistent_analyzed_metrics"),
    (("diagnostics", "minimum_local_correlation"), 0.2, "inconsistent_analyzed_metrics"),
    (("diagnostics", "anchor_run_count"), 2, "inconsistent_anchor_count"),
    (("diagnostics", "applied_gain"), 2, "inconsistent_applied_gain"),
    (("alignment_segments", 0, "processed_offset_ms"), -1, "invalid_alignment_processed_interval"),
    (("alignment_segments", 0, "anchor_correlations"), [1, 1.1, 1], "invalid_anchor_correlations"),
    (("alignment_segments", 0, "anchor_correlations"), [1, 0.1, 1], "invalid_anchor_correlations"),
])
def test_strict_structure_status_and_metadata(path, replacement, code):
    result = _result()
    _set(result, path, replacement)
    _assert_rejected(result, code)


@pytest.mark.parametrize("path", [
    ("configuration", "max_delay_ms"), ("reference", "rms"),
    ("processed", "peak"), ("diagnostics", "gain_estimate"),
    ("analysis", "hop_ms"), ("alignment_segments", 0, "processed_offset_ms"),
    ("alignment_segments", 0, "anchor_correlations", 1),
])
@pytest.mark.parametrize("metric", [float("nan"), float("inf"), float("-inf")])
def test_all_numeric_locations_reject_nonfinite_values(path, metric):
    result = _result()
    _set(result, path, metric)
    _assert_rejected(result, "non_finite_metric")


def test_non_json_values_and_cyclic_objects_are_rejected():
    result = _result()
    result["diagnostics"]["normalized_path_cost"] = object()
    _assert_rejected(result, "invalid_json_value")
    result = _result()
    result["cycle"] = result
    _assert_rejected(result, "result_structure_too_large")


def test_unknown_fields_and_probability_claims_are_rejected():
    for field in ("probability", "raw_audio", "reference_path"):
        result = _result()
        result[field] = "unspecified"
        _assert_rejected(result, "unexpected_result_field")
    result = _result()
    result["diagnostics"]["confidence_probability"] = 0.99
    _assert_rejected(result, "unexpected_result_field")


def test_analyzed_result_cannot_hide_events_or_unavailable_anchors():
    result = _result("delete")
    result["content_preservation_status"] = "no_supported_defect_candidates"
    _assert_rejected(result, "inconsistent_result_status")
    result = _result()
    result.pop("alignment_segments")
    _assert_rejected(result, "missing_result_field")


@pytest.mark.parametrize("path,replacement,code", [
    (("reference_interval_ms",), [5900, 6300], "invalid_reference_interval"),
    (("reference_interval_ms",), [2400, 2000], "invalid_reference_interval"),
    (("reference_interval_ms",), [2000, True], "invalid_reference_interval"),
    (("processed_boundary_ms",), 5700, "invalid_processed_boundary"),
    (("processed_boundary_ms",), 1999, "inconsistent_delete_geometry"),
    (("evidence", "offset_after_ms"), -350, "inconsistent_delete_geometry"),
    (("evidence", "boundary_correlation"), float("nan"), "non_finite_metric"),
    (("evidence", "boundary_correlation"), 0.3, "invalid_event_evidence"),
    (("type",), "insert", "unsupported_event_type"),
    (("type",), [], "unsupported_event_type"),
])
def test_delete_uses_reference_interval_and_processed_boundary(path, replacement, code):
    result = _result("delete")
    _set(result["events"][0], path, replacement)
    _assert_rejected(result, code)


@pytest.mark.parametrize("path,replacement,code", [
    (("reference_source_interval_ms",), [6100, 6500], "invalid_reference_interval"),
    (("processed_added_interval_ms",), [6200, 6600], "invalid_processed_interval"),
    (("processed_added_interval_ms",), [2400, 2850], "inconsistent_repeat_geometry"),
    (("processed_added_interval_ms",), [0, 400], "inconsistent_repeat_geometry"),
    (("evidence", "offset_after_ms"), -400, "inconsistent_event_offset"),
    (("reference_source_interval_ms",), [1000, 1400], "inconsistent_repeat_mapping"),
    (("copy_interval_convention",), "actual_edit_provenance", "unsupported_copy_interval_convention"),
])
def test_repeat_uses_reference_source_and_processed_added_axes(path, replacement, code):
    result = _result("repeat")
    _set(result["events"][0], path, replacement)
    _assert_rejected(result, code)


def test_overlapping_added_intervals_are_rejected():
    result = _result("repeat")
    result["events"].append(deepcopy(result["events"][0]))
    _assert_rejected(result, "unordered_or_overlapping_events")


def test_alignment_cannot_run_backwards_on_processed_axis():
    result = _result()
    first = result["alignment_segments"][0]
    second = deepcopy(first)
    first["reference_interval_ms"] = [0, 3000]
    second.update(reference_interval_ms=[3000, 6000], processed_offset_ms=-100)
    result["alignment_segments"].append(second)
    result["diagnostics"]["anchor_run_count"] = 2
    _assert_rejected(result, "unordered_or_overlapping_alignment")


def test_empty_events_cannot_hide_supported_offset_change_or_large_internal_gap():
    result = _result()
    first = result["alignment_segments"][0]
    second = deepcopy(first)
    first["reference_interval_ms"] = [0, 3000]
    second.update(reference_interval_ms=[3000, 5500], processed_offset_ms=400)
    result["alignment_segments"].append(second)
    result["diagnostics"]["anchor_run_count"] = 2
    _assert_rejected(result, "unexplained_empty_event_offset_change")
    first["reference_interval_ms"] = [0, 2000]
    second.update(reference_interval_ms=[2500, 6000], processed_offset_ms=0)
    _assert_rejected(result, "unexplained_empty_event_alignment_gap")


def test_frozen_engine_ignored_window_leakage_is_still_a_narrow_valid_result():
    result = _result()
    first = result["alignment_segments"][0]
    second = deepcopy(first)
    first["reference_interval_ms"] = [0, 3000]
    second.update(reference_interval_ms=[3000, 5960], processed_offset_ms=40)
    result["alignment_segments"].append(second)
    result["diagnostics"]["anchor_run_count"] = 2
    assert validate_analysis_result(result)["complete_audio_approval"] is False


def test_unsupported_short_event_geometry_is_rejected():
    result = _result("delete")
    result["events"][0]["reference_interval_ms"][1] = 2100
    result["events"][0]["evidence"]["offset_after_ms"] = -100
    _assert_rejected(result, "unsupported_event_duration")


def test_withheld_and_existing_cli_error_envelope_validate():
    assert validate_analysis_result(_withheld())["events"] is None
    withheld = _withheld()
    withheld["diagnostics"].update(anchor_run_count=0, matched_analysis_samples=0)
    assert validate_analysis_result(withheld)["status"] == "withheld"
    for reason in ("file_read_error", "invalid_configuration", "output_exists"):
        error = {"schema_version": 1, "status": "error", "reason_code": reason}
        assert validate_analysis_result(error) is error


def test_withheld_and_error_never_smuggle_analyzed_evidence():
    result = _withheld()
    result["events"] = []
    _assert_rejected(result, "inconsistent_result_status")
    result = _withheld()
    result["reason_code"] = None
    _assert_rejected(result, "invalid_reason_code")
    result = {"schema_version": 1, "status": "error", "reason_code": "file_read_error", "events": []}
    _assert_rejected(result, "unexpected_result_field")


def test_global_baseline_is_not_an_analysis_result():
    path = DEVELOPMENT / "synthetic_global_baseline.json"
    with pytest.raises(ResultContractError) as caught:
        load_analysis_result(path)
    assert caught.value.code in {"unsupported_result_status", "unsupported_engine"}


@pytest.mark.parametrize("payload,code", [
    (b'{"schema_version":1,"schema_version":1,"status":"error","reason_code":"file_read_error"}', "duplicate_json_key"),
    (b'{"schema_version":1,"status":"error","reason_code":"file_read_error","x":{"a":0,"a":1}}', "duplicate_json_key"),
    (b'{"schema_version":NaN}', "non_finite_metric"),
    (b'{"schema_version":Infinity}', "non_finite_metric"),
    (b'{"schema_version":1e999}', "non_finite_metric"),
    (b'{', "invalid_result_json"),
    (b'\xff', "invalid_result_json"),
    (b'RIFFfake-WAV-data', "invalid_result_json"),
    (b' ' * (MAX_RESULT_BYTES + 1), "result_file_too_large"),
], ids=["duplicate-top-level", "duplicate-nested", "nan", "infinity", "float-overflow",
        "malformed-json", "invalid-utf8", "audio-is-not-json", "oversized-json"])
def test_loader_bounds_and_strict_json(tmp_path, payload, code):
    source = tmp_path / "invalid.json"
    with source.open("xb") as stream:
        stream.write(payload)
    with pytest.raises(ResultContractError) as caught:
        load_analysis_result(source)
    assert caught.value.code == code
    assert source.read_bytes() == payload


def test_file_failure_message_omits_private_path(tmp_path):
    private = tmp_path / "private-name.json"
    with pytest.raises(ResultContractError) as caught:
        load_analysis_result(private)
    assert caught.value.code == "result_file_read_error"
    assert str(private) not in str(caught.value)


def test_packaged_json_schema_has_separate_error_and_analysis_branches():
    schema_path = Path(__file__).resolve().parents[1] / "src" / "audio_regression" / "schemas" / "analysis-result-v1.schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    assert schema["$schema"] == "https://json-schema.org/draft/2020-12/schema"
    assert len(schema["oneOf"]) == 3
    assert schema["$defs"]["cliError"]["required"] == ["schema_version", "status", "reason_code"]
    for branch in ("analyzed", "withheld"):
        assert schema["$defs"][branch]["properties"]["engine"]["const"] == "local_content_alignment_v1"
        assert schema["$defs"][branch]["properties"]["complete_audio_approval"]["const"] is False
        assert schema["$defs"][branch]["additionalProperties"] is False
