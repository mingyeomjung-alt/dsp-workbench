"""Fresh synthetic endpoint checks through native and saved-stage pipelines.

Only newly generated PCM16 WAV files are used. These are contract/integration
regressions, not a replay of locked trials or evidence of natural-audio accuracy.
"""

from __future__ import annotations

from functools import lru_cache
import json

import numpy as np
import pytest
from scipy.signal import chirp

from audio_regression.audio import decode_wav, encode_wav, read_wav
from audio_regression.pipeline_reporting import validate_pipeline_result
from audio_regression.pipeline_runner import run_pipeline
from audio_regression.pipeline_transforms import execute_stage
from audio_regression.result_contract import validate_analysis_result
from audio_regression.saved_pipeline import audit_saved_pipeline
from audio_regression.saved_pipeline_contract import validate_saved_pipeline_result


ENGINES = ("v1", "v2", "v3")


@lru_cache(maxsize=1)
def _new_odd_pcm16() -> bytes:
    rate, count = 16000, 6 * 16000 + 1
    rng = np.random.default_rng(130817)
    time = np.arange(count, dtype=np.float64) / rate
    noise = np.convolve(rng.standard_normal(count), [0.1, 0.2, 0.4, 0.2, 0.1], mode="same")
    envelope = np.interp(np.linspace(0, 60, count), np.arange(61), rng.uniform(0.3, 1, 61))
    samples = envelope * (noise + 0.2 * chirp(time, 310, 6, 2170, method="quadratic"))
    samples *= 0.22 / np.max(np.abs(samples))
    return encode_wav(samples, rate)


def _run(tmp_path, mode: str, engine: str, stages: list[dict]) -> tuple[dict, bytes]:
    original = _new_odd_pcm16()
    source = tmp_path / "source.wav"
    source.write_bytes(original)
    output = tmp_path / "result"
    if mode == "native":
        result = run_pipeline(source, stages, output, engine=engine)
        assert validate_pipeline_result(result) is result
        assert (output / "input/source.wav").read_bytes() == original
    else:
        audio = decode_wav(original)
        saved_stages = []
        originals = [(source, original)]
        for index, spec in enumerate(stages, 1):
            wav, operation = execute_stage(audio, spec)
            path = tmp_path / f"stage-{index}.wav"
            path.write_bytes(wav)
            originals.append((path, wav))
            declaration = operation["declared_comparison"]
            saved_stages.append({"label": f"Stage {index}", "output": path.name,
                                 "declaration": {key: declaration[key] for key in
                                                 ("allow_gain", "allow_resampling")}})
            audio = decode_wav(wav)
        manifest = tmp_path / "manifest.json"
        manifest.write_text(json.dumps({"schema_version": 1, "source": source.name,
                                        "stages": saved_stages}), encoding="utf-8")
        result = audit_saved_pipeline(manifest, output, engine=engine)
        assert validate_saved_pipeline_result(result) is result
        assert result["input_recheck"] == {"status": "unchanged", "file_indices": []}
        for index, (path, wav) in enumerate(originals):
            assert path.read_bytes() == wav
            assert (output / f"inputs/{index:03d}.wav").read_bytes() == wav
    assert source.read_bytes() == original
    assert read_wav(source).metadata()["sample_count"] == 96001
    assert result["status"] == "completed"
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    assert result["network_used"] is False
    for record in [*result["stages"], result["end_to_end"]]:
        analysis = record["analysis"]
        assert validate_analysis_result(analysis) is analysis
        assert analysis["engine"] == f"local_content_alignment_{engine}"
        if analysis["status"] == "analyzed":
            for segment in analysis["alignment_segments"]:
                first, last = segment["reference_interval_ms"]
                offset = segment["processed_offset_ms"]
                assert 0 <= first < last <= analysis["reference"]["duration_ms"]
                assert 0 <= first + offset < last + offset <= analysis["processed"]["duration_ms"]
    return result, original


@pytest.mark.parametrize("engine", ENGINES)
@pytest.mark.parametrize("mode", ["native", "saved"])
def test_odd_source_all_native_operations_keep_source_time_endpoints(tmp_path, mode, engine):
    result, _ = _run(tmp_path, mode, engine, [
        {"kind": "gain", "gain_db": -3},
        {"kind": "split_join", "segment_ms": 400},
        {"kind": "resample", "target_rate_hz": 8000},
    ])
    assert result["summary"]["exit_code"] == 0
    assert result["summary"]["first_concern"] is None
    for record in [*result["stages"], result["end_to_end"]]:
        analysis = record["analysis"]
        assert record["check"]["exit_code"] == 0
        assert analysis["status"] == "analyzed"
        assert analysis["events"] == []
        assert analysis["alignment_segments"][-1]["reference_interval_ms"][1] == 6000.0625
    assert result["stages"][-1]["analysis"]["processed"]["duration_ms"] == 6000.125


@pytest.mark.parametrize("engine", ENGINES)
@pytest.mark.parametrize("mode", ["native", "saved"])
def test_odd_source_deletion_review_survives_later_clear_stage(tmp_path, mode, engine):
    order = [index for index in range(16) if index != 5]
    result, _ = _run(tmp_path, mode, engine, [
        {"kind": "split_join", "segment_ms": 400, "order": order},
        {"kind": "gain", "gain_db": 0},
    ])
    first, later = result["stages"]
    assert first["check"]["gate_state"] == "review_required"
    assert first["analysis"]["events"][0]["type"] == "delete"
    assert later["check"]["gate_state"] == "clear_supported_temporal_check"
    assert later["analysis"]["alignment_segments"][-1]["reference_interval_ms"][1] == 5600.0625
    assert result["summary"]["gate_state"] == "review_required"
    assert result["summary"]["exit_code"] == 1
    assert result["summary"]["first_concern"]["stage_index"] == 1
    assert result["summary"]["first_concern"]["category"] == "defect_candidates"


@pytest.mark.parametrize("engine", ENGINES)
@pytest.mark.parametrize("mode", ["native", "saved"])
def test_odd_source_unsupported_reordering_withheld_survives_later_clear(tmp_path, mode, engine):
    order = list(range(16))
    order[5], order[6] = order[6], order[5]
    result, _ = _run(tmp_path, mode, engine, [
        {"kind": "split_join", "segment_ms": 400, "order": order},
        {"kind": "gain", "gain_db": 0},
    ])
    first, later = result["stages"]
    assert first["analysis"]["status"] == "withheld"
    assert first["analysis"]["events"] is None
    assert first["check"]["gate_state"] == "blocked"
    assert later["check"]["gate_state"] == "clear_supported_temporal_check"
    assert later["analysis"]["alignment_segments"][-1]["reference_interval_ms"][1] == 6000.0625
    assert result["summary"]["gate_state"] == "blocked"
    assert result["summary"]["exit_code"] == 2
    assert result["summary"]["first_concern"]["stage_index"] == 1
    assert result["summary"]["first_concern"]["category"] == "withheld"
