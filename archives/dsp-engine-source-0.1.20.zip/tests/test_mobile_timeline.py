"""Stored-result regressions for readable, non-scaling timeline end labels.

These tests exercise report presentation only. They do not load audio or
invoke an analysis engine, and the render must not alter the saved decision.
"""

import copy
from html.parser import HTMLParser
import re

import pytest

from audio_regression.check_policy import check_result
from audio_regression.reporting import render_html
from test_reporting import sample_result


class TimelineMarkup(HTMLParser):
    """Collect timeline labels with their parent context, not string offsets."""

    def __init__(self, html):
        super().__init__()
        self.elements = []
        self.axes = []
        self.ticks = []
        self.svg_texts = []
        self._svg_depth = 0
        self._div_depth = 0
        self._tick_depth = None
        self._tick = None
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        self.elements.append((tag, attrs))
        if tag == "svg":
            self._svg_depth += 1
            self.axes.append(attrs)
        elif tag == "text" and self._svg_depth:
            self.svg_texts.append(attrs)
        if tag == "div":
            self._div_depth += 1
            if "timeline-ticks" in attrs.get("class", "").split():
                self._tick_depth = self._div_depth
                self._tick = {"attrs": attrs, "parts": [], "inside_svg": bool(self._svg_depth)}
                self.ticks.append(self._tick)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)

    def handle_endtag(self, tag):
        if tag == "svg":
            self._svg_depth -= 1
        elif tag == "div":
            if self._tick_depth == self._div_depth:
                self._tick_depth = None
                self._tick = None
            self._div_depth -= 1

    def handle_data(self, data):
        if self._tick is not None and data.strip():
            self._tick["parts"].append(data.strip())


def _style_rule(html, class_name):
    match = re.search(r"\." + re.escape(class_name) + r"\s*\{([^}]*)\}", html)
    assert match is not None, f"Missing report style for {class_name}"
    return {
        key.strip(): value.strip()
        for declaration in match.group(1).split(";")
        if ":" in declaration
        for key, value in [declaration.split(":", 1)]
    }


def _with_reference_duration(kind, duration_ms):
    """Make a valid stored fixture; the event itself is kept unchanged."""
    result = sample_result(kind)
    result["reference"]["duration_ms"] = duration_ms
    result["reference"]["sample_count"] = round(duration_ms * 16)
    processed_ms = duration_ms + (-400 if kind == "delete" else 400)
    result["processed"]["duration_ms"] = processed_ms
    result["processed"]["sample_count"] = round(processed_ms * 16)
    result["diagnostics"]["matched_analysis_samples"] = int(min(duration_ms, processed_ms) * 4)
    return result


@pytest.mark.parametrize("kind,processed_duration", [("delete", 5600), ("repeat", 6400)])
def test_axis_end_labels_are_html_outside_the_scaling_svg(kind, processed_duration):
    markup = TimelineMarkup(render_html(sample_result(kind)))
    assert len(markup.axes) == len(markup.ticks) == 2
    assert markup.svg_texts == []
    for axis, ticks, name, duration in zip(
        markup.axes, markup.ticks, ("reference", "processed"), (6000, processed_duration)
    ):
        assert axis["data-axis"] == ticks["attrs"]["data-axis"] == name
        assert axis["data-duration-ms"] == ticks["attrs"]["data-duration-ms"] == f"{duration:.3f}"
        assert axis["viewbox"] == "0 0 940 42"
        assert "timeline-plot" in axis["class"].split()
        assert ticks["parts"] == ["0 ms", f"{duration:,} ms"]
        assert not ticks["inside_svg"]


def test_endpoint_text_keeps_css_pixel_size_and_plot_has_a_minimum_height():
    html = render_html(sample_result("delete"))
    ticks = _style_rule(html, "timeline-ticks")
    plot = _style_rule(html, "timeline-plot")
    assert ticks["font-size"] == "12px"
    assert ticks["display"] == "flex"
    assert ticks["justify-content"] == "space-between"
    assert plot["min-height"] == "28px"


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_mobile_label_change_preserves_event_coordinates(kind):
    html = render_html(sample_result(kind))
    elements = TimelineMarkup(html).elements
    tracks = [attrs for tag, attrs in elements if tag == "rect" and attrs.get("class") == "track"]
    assert len(tracks) == 2
    assert all(float(track["x"]) == 48 and float(track["width"]) == 840 for track in tracks)
    marks = [attrs for tag, attrs in elements if tag == "rect" and "data-start-ms" in attrs]
    assert float(marks[0]["x"]) == pytest.approx(48 + 840 * 2000 / 6000, abs=0.001)
    assert float(marks[0]["width"]) == pytest.approx(840 * 400 / 6000, abs=0.001)
    if kind == "delete":
        boundary = next(attrs for tag, attrs in elements if tag == "line" and attrs.get("class") == "boundary")
        expected = 48 + 840 * 2000 / 5600
        assert float(boundary["x1"]) == pytest.approx(expected, abs=0.001)
        assert float(boundary["x2"]) == pytest.approx(expected, abs=0.001)
        assert boundary["data-boundary-ms"] == "2000.000"
        assert boundary.get("vector-effect", _style_rule(html, "boundary").get("vector-effect")) == "non-scaling-stroke"
    else:
        assert float(marks[1]["x"]) == pytest.approx(48 + 840 * 2400 / 6400, abs=0.001)
        assert float(marks[1]["width"]) == pytest.approx(840 * 400 / 6400, abs=0.001)
        assert marks[1]["data-start-ms"] == "2400.000"
        assert marks[1]["data-end-ms"] == "2800.000"


@pytest.mark.parametrize("kind,reference_ms,reference_label,processed_label", [
    ("delete", 30000, "30,000 ms", "29,600 ms"),
    ("repeat", 29600, "29,600 ms", "30,000 ms"),
    ("delete", 6000.0625, "6,000.062 ms", "5,600.062 ms"),
    ("repeat", 6000.0625, "6,000.062 ms", "6,400.062 ms"),
    ("delete", 6000.125, "6,000.125 ms", "5,600.125 ms"),
    ("repeat", 6000.125, "6,000.125 ms", "6,400.125 ms"),
])
def test_each_axis_formats_its_own_whole_or_submillisecond_end(
    kind, reference_ms, reference_label, processed_label
):
    result = _with_reference_duration(kind, reference_ms)
    markup = TimelineMarkup(render_html(result))
    assert [tick["parts"] for tick in markup.ticks] == [
        ["0 ms", reference_label], ["0 ms", processed_label]
    ]
    assert markup.axes[0]["data-duration-ms"] == f"{result['reference']['duration_ms']:.3f}"
    assert markup.axes[1]["data-duration-ms"] == f"{result['processed']['duration_ms']:.3f}"


@pytest.mark.parametrize("kind", ["clean", "delete", "repeat", "withheld", "error"])
def test_report_presentation_does_not_mutate_saved_result_or_check_policy(kind):
    result = sample_result(kind if kind in {"clean", "delete", "repeat"} else "clean")
    if kind == "withheld":
        result.update(status="withheld", content_preservation_status="withheld",
                      reason_code="insufficient_unambiguous_anchors", events=None)
        result.pop("alignment_segments")
    elif kind == "error":
        result = {"schema_version": 1, "status": "error", "reason_code": "file_read_error"}
    original = copy.deepcopy(result)
    decision = copy.deepcopy(check_result(result))
    html = render_html(result)
    assert result == original
    assert check_result(result) == decision
    assert render_html(result) == html


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_non_scaling_labels_do_not_introduce_scripts_or_external_resources(kind):
    result = sample_result(kind)
    result["limitations"].append('<script>alert("x")</script><img src="https://example.invalid/image">')
    html = render_html(result)
    markup = TimelineMarkup(html)
    forbidden = {"script", "iframe", "audio", "video", "img", "link", "object", "embed"}
    assert not any(tag in forbidden for tag, _ in markup.elements)
    assert not any(key.lower().startswith("on") for _, attrs in markup.elements for key in attrs)
    assert not any(key in {"href", "src", "xlink:href"} for _, attrs in markup.elements for key in attrs)
    csp = next(attrs["content"] for tag, attrs in markup.elements
               if tag == "meta" and attrs.get("http-equiv") == "Content-Security-Policy")
    assert "default-src 'none'" in csp
    assert "base-uri 'none'" in csp
    assert "form-action 'none'" in csp
    assert '<script>alert("x")</script>' not in html


@pytest.mark.parametrize("kind", ["withheld", "error", "clean"])
def test_no_confirmed_event_produces_no_timeline_or_end_labels(kind):
    result = sample_result()
    if kind == "withheld":
        result.update(status="withheld", content_preservation_status="withheld",
                      reason_code="insufficient_unambiguous_anchors", events=None)
        result.pop("alignment_segments")
    elif kind == "error":
        result = {"schema_version": 1, "status": "error", "reason_code": "file_read_error"}
    markup = TimelineMarkup(render_html(result))
    assert markup.axes == []
    assert markup.ticks == []
