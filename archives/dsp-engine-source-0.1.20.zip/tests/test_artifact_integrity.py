"""Inert artifact verification using newly authored private byte fixtures."""

from copy import deepcopy
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import stat
from types import SimpleNamespace

import pytest

from audio_regression import artifact_integrity as verifier


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _write_manifest(root, value, *, raw=None, name="artifact_manifest.json"):
    path = root / name
    payload = raw if raw is not None else json.dumps(value, ensure_ascii=False).encode("utf-8")
    path.write_bytes(payload)
    return path, _sha(payload)


def _value(entries):
    return {"schema_version": 1, "files": entries,
            "manifest_excludes_only_itself": True, "network_used": False}


def _entry(path, raw):
    return {"path": path, "size_bytes": len(raw), "sha256": _sha(raw)}


@pytest.fixture
def artifacts(tmp_path):
    root = tmp_path / "preserved-private-tree"
    root.mkdir()
    raw = {"bytes.wav": b"Not a WAV; must never be decoded.",
           "nested/deeper/inert.html": b"<script>must-not-run()</script>",
           "nested/empty.bin": b""}
    for relative, data in raw.items():
        path = root.joinpath(*relative.split("/"))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)
    value = _value([_entry(path, raw[path]) for path in sorted(raw)])
    manifest, digest = _write_manifest(root, value)
    return root, manifest, digest, value, raw


def _reject(artifacts, code=None, *, expected=None):
    root, manifest, digest, *_ = artifacts
    with pytest.raises(verifier.ArtifactVerificationError) as exc:
        verifier.verify_artifact_manifest(root, manifest,
            expected_manifest_sha256=digest if expected is None else expected)
    if code is not None:
        assert exc.value.code == code
    assert str(root) not in str(exc.value)
    assert str(manifest) not in str(exc.value)
    assert "private" not in str(exc.value)
    return exc.value.code


def test_exact_tree_verified_without_audio_quality_or_provenance_claim(artifacts):
    root, manifest, digest, _, raw = artifacts
    before = {p: p.read_bytes() for p in root.rglob("*") if p.is_file()}
    result = verifier.verify_artifact_manifest(root, manifest, expected_manifest_sha256=digest)
    assert result == {"schema_version": 1, "engine": "preserved_artifact_integrity_v1",
        "status": "verified", "manifest_sha256": digest, "file_count": 3,
        "total_bytes": sum(map(len, raw.values())), "quality_verdict": "not_assessed",
        "authenticity_verified": False, "execution_provenance_verified": False,
        "complete_audio_approval": False, "commercial_performance_validated": False,
        "network_used": False}
    assert before == {p: p.read_bytes() for p in root.rglob("*") if p.is_file()}


def test_empty_manifest_verifies_only_manifest_alone(tmp_path):
    manifest, digest = _write_manifest(tmp_path, _value([]))
    result = verifier.verify_artifact_manifest(tmp_path, manifest, expected_manifest_sha256=digest)
    assert result["file_count"] == result["total_bytes"] == 0
    (tmp_path / "unlisted-empty-directory").mkdir()
    with pytest.raises(verifier.ArtifactVerificationError, match="artifact_coverage_mismatch"):
        verifier.verify_artifact_manifest(tmp_path, manifest, expected_manifest_sha256=digest)


@pytest.mark.parametrize("expected", [None, True, 1, b"a" * 64, "a" * 63,
    "a" * 65, "A" * 64, "g" * 64, "a" * 64 + "\n", ""])
def test_external_digest_required_before_any_path_read(artifacts, expected, monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("path read before external anchor check")
    monkeypatch.setattr(verifier, "_absolute", forbidden)
    root, manifest, *_ = artifacts
    with pytest.raises(verifier.ArtifactVerificationError) as exc:
        verifier.verify_artifact_manifest(root, manifest, expected_manifest_sha256=expected)
    assert exc.value.code == "invalid_expected_manifest_sha256"


def test_wrong_external_digest_fails_before_json_parse(artifacts, monkeypatch):
    monkeypatch.setattr(verifier, "_manifest", lambda *_: pytest.fail("parsed unanchored data"))
    _reject(artifacts, "manifest_digest_mismatch", expected="0" * 64)


@pytest.mark.parametrize("raw,code", [
    (b'{"schema_version":1,"schema_version":1}', "duplicate_json_key"),
    (b'{"nested":{"x":1,"x":2}}', "duplicate_json_key"),
    (b'{"x":NaN}', "non_finite_manifest_value"),
    (b'{"x":Infinity}', "non_finite_manifest_value"),
    (b'{"x":-Infinity}', "non_finite_manifest_value"),
    (b"\xef\xbb\xbf{}", "invalid_artifact_manifest_json"),
    (b"\xff", "invalid_artifact_manifest_json"),
    (b"{} garbage", "invalid_artifact_manifest_json"),
], ids=["duplicate_top", "duplicate_nested", "nan", "positive_infinity", "negative_infinity",
        "bom", "invalid_utf8", "trailing_payload"])
def test_strict_inert_json(artifacts, raw, code):
    root, _, _, *rest = artifacts
    manifest, digest = _write_manifest(root, None, raw=raw)
    _reject((root, manifest, digest, *rest), code)


def test_deep_non_manifest_json_is_rejected_safely(artifacts):
    root, _, _, *rest = artifacts
    manifest, digest = _write_manifest(root, None, raw=b"[" * 1500 + b"]" * 1500)
    assert _reject((root, manifest, digest, *rest)) in {
        "invalid_artifact_manifest", "invalid_artifact_manifest_json"}


@pytest.mark.parametrize("field,value", [("schema_version", True), ("schema_version", 1.0),
    ("schema_version", 2), ("files", {}), ("files", None),
    ("manifest_excludes_only_itself", 1), ("manifest_excludes_only_itself", False),
    ("network_used", 0), ("network_used", True), ("extra_hidden_payload", {"run": "processor"})])
def test_exact_manifest_shape(artifacts, field, value):
    root, _, _, original, raw = artifacts
    changed = deepcopy(original)
    changed[field] = value
    manifest, digest = _write_manifest(root, changed)
    _reject((root, manifest, digest, changed, raw), "invalid_artifact_manifest")


@pytest.mark.parametrize("removed", ["schema_version", "files", "network_used", "manifest_excludes_only_itself"])
def test_missing_manifest_fields(artifacts, removed):
    root, _, _, value, raw = artifacts
    del value[removed]
    manifest, digest = _write_manifest(root, value)
    _reject((root, manifest, digest, value, raw), "invalid_artifact_manifest")


@pytest.mark.parametrize("item", [None, [], True, {"path": "bytes.wav"},
    {"path": "bytes.wav", "size_bytes": 1, "sha256": "0" * 64, "run": "never"}])
def test_exact_entry_shape(artifacts, item):
    root, _, _, value, raw = artifacts
    value["files"][0] = item
    manifest, digest = _write_manifest(root, value)
    _reject((root, manifest, digest, value, raw), "invalid_artifact_entry")


@pytest.mark.parametrize("path", ["", "/a", "a/", "a//b", "a/../b", "./a", "..",
    "C:/a", "a\\b", "a:b", "a?b", "a*b", "a<b", "a>b", "a|b", 'a"b',
    "a\nb", "a\x00b", "a\u200bb", "a\ud800b", "a.", "a ", " a", "a/ b",
    "a/CON", "a/aux.txt", "NUL", "COM1.wav", "lpt9", "COM¹.wav", "LPT²",
    "e\u0301.wav", "x" * 256, "/".join(["a"] * 65), True, 9, None])
def test_unsafe_portable_manifest_paths(artifacts, path):
    root, _, _, value, raw = artifacts
    value["files"][0]["path"] = path
    # Surrogate cannot be UTF-8 encoded; JSON escape keeps test payload inert.
    payload = json.dumps(value, ensure_ascii=True).encode("utf-8")
    manifest, digest = _write_manifest(root, value, raw=payload)
    _reject((root, manifest, digest, value, raw), "invalid_artifact_relative_path")


@pytest.mark.parametrize("size", [True, False, 1.0, -1, "1", None, verifier.MAX_FILE_BYTES + 1])
def test_size_must_be_bounded_integer(artifacts, size):
    root, _, _, value, raw = artifacts
    value["files"][0]["size_bytes"] = size
    manifest, digest = _write_manifest(root, value)
    _reject((root, manifest, digest, value, raw), "invalid_artifact_size")


@pytest.mark.parametrize("digest_value", [None, True, 7, "A" * 64, "g" * 64, "a" * 63, "a" * 65, "a" * 64 + "\n"])
def test_each_digest_must_be_lowercase_sha256(artifacts, digest_value):
    root, _, _, value, raw = artifacts
    value["files"][0]["sha256"] = digest_value
    manifest, digest = _write_manifest(root, value)
    _reject((root, manifest, digest, value, raw), "invalid_artifact_digest")


@pytest.mark.parametrize("paths,code", [
    (["b", "a"], "invalid_artifact_path_order"),
    (["a", "a"], "invalid_artifact_path_order"),
    (["A", "a"], "artifact_path_collision"),
    (["Dir/a", "dir/b"], "artifact_path_collision"),
    (["a", "a/b"], "artifact_path_collision"),
    (["artifact_manifest.json"], "artifact_manifest_self_entry"),
    (["ARTIFACT_MANIFEST.JSON"], "artifact_manifest_self_entry"),
])
def test_order_collisions_and_self_entry(artifacts, paths, code):
    root, _, _, value, raw = artifacts
    value["files"] = [_entry(path, b"") for path in paths]
    manifest, digest = _write_manifest(root, value)
    _reject((root, manifest, digest, value, raw), code)


def test_file_count_limit_before_tree_reads(artifacts, monkeypatch):
    root, _, _, value, raw = artifacts
    value["files"] = [_entry(f"{i:05}.bin", b"") for i in range(verifier.MAX_FILES + 1)]
    manifest, digest = _write_manifest(root, value)
    monkeypatch.setattr(verifier, "_tree", lambda *_: pytest.fail("scanned oversized manifest"))
    _reject((root, manifest, digest, value, raw), "invalid_artifact_manifest")


def test_total_claim_limit_before_any_artifact_reads(artifacts, monkeypatch):
    root, _, _, value, raw = artifacts
    value["files"] = [{"path": f"{i:05}.bin", "size_bytes": verifier.MAX_FILE_BYTES,
                       "sha256": "0" * 64} for i in range(33)]
    manifest, digest = _write_manifest(root, value)
    monkeypatch.setattr(verifier, "_tree", lambda *_: pytest.fail("scanned oversized total"))
    _reject((root, manifest, digest, value, raw), "artifact_total_size_exceeded")


def test_manifest_read_size_is_bounded(artifacts):
    root, _, _, value, raw = artifacts
    manifest, digest = _write_manifest(root, value, raw=b" " * (verifier.MAX_MANIFEST_BYTES + 1))
    _reject((root, manifest, digest, value, raw), "artifact_file_too_large")


@pytest.mark.parametrize("change", ["extra-file", "extra-directory", "missing-file", "missing-subtree"])
def test_exact_tree_coverage(artifacts, change):
    root, *_ = artifacts
    if change == "extra-file":
        (root / "unexpected.bin").write_bytes(b"unlisted")
    elif change == "extra-directory":
        (root / "empty-dir").mkdir()
    elif change == "missing-file":
        (root / "bytes.wav").unlink()
    else:
        (root / "nested/deeper/inert.html").unlink()
        (root / "nested/deeper").rmdir()
    _reject(artifacts, "artifact_coverage_mismatch")


def test_same_size_artifact_tamper_rejected(artifacts):
    root, _, _, _, raw = artifacts
    data = raw["bytes.wav"]
    (root / "bytes.wav").write_bytes(b"X" + data[1:])
    _reject(artifacts, "artifact_digest_mismatch")


def test_changed_artifact_length_rejected(artifacts):
    root, *_ = artifacts
    with (root / "bytes.wav").open("ab") as stream:
        stream.write(b"x")
    _reject(artifacts, "artifact_size_mismatch")


def test_changed_manifest_requires_external_digest_not_reseal(artifacts):
    root, manifest, *_ = artifacts
    with manifest.open("ab") as stream:
        stream.write(b" ")
    _reject(artifacts, "manifest_digest_mismatch")


@pytest.mark.parametrize("name", ["nested/manifest.json", "manifest.JSON", "manifest.txt"])
def test_manifest_must_be_direct_lowercase_json(artifacts, name):
    root, _, _, value, raw = artifacts
    manifest, digest = _write_manifest(root, value, name=name)
    _reject((root, manifest, digest, value, raw), "invalid_artifact_manifest_location")


def test_manifest_outside_root_rejected(artifacts, tmp_path):
    root, _, _, value, raw = artifacts
    manifest, digest = _write_manifest(tmp_path, value, name="other.json")
    _reject((root, manifest, digest, value, raw), "invalid_artifact_manifest_location")


@pytest.mark.parametrize("kind", ["listed-leaf", "manifest", "unlisted-leaf"])
def test_regular_hardlinks_rejected(artifacts, tmp_path, kind):
    root, manifest, *_ = artifacts
    source = manifest if kind == "manifest" else root / "bytes.wav"
    target = root / "unlisted-alias.bin" if kind == "unlisted-leaf" else tmp_path / "outside-alias.bin"
    try:
        os.link(source, target)
    except OSError:
        pytest.skip("hardlink unsupported by this filesystem")
    _reject(artifacts, "unsafe_artifact_path")


@pytest.mark.parametrize("kind", ["listed-leaf", "directory", "manifest", "unlisted-leaf", "root"])
def test_symlinks_rejected_when_supported(artifacts, tmp_path, kind):
    root, manifest, digest, value, raw = artifacts
    source = tmp_path / "outside-source.bin"
    source.write_bytes(raw["bytes.wav"])
    try:
        if kind == "root":
            alias = tmp_path / "alias-root"
            alias.symlink_to(root, target_is_directory=True)
            _reject((alias, alias / manifest.name, digest, value, raw), "unsafe_artifact_path")
            return
        target = root / {"listed-leaf": "bytes.wav", "directory": "outside-dir",
                         "manifest": manifest.name, "unlisted-leaf": "outside-leaf"}[kind]
        if target.exists():
            target.unlink()
        target.symlink_to(root if kind == "directory" else source,
                          target_is_directory=kind == "directory")
    except OSError:
        pytest.skip("symlink creation unavailable")
    _reject((root, manifest, digest, value, raw), "unsafe_artifact_path")


def test_reparse_attribute_and_nonregular_are_rejected_without_following(artifacts, monkeypatch):
    original = Path.lstat
    root, *_ = artifacts
    def reparse(path, *args, **kwargs):
        info = original(path, *args, **kwargs)
        if path == root / "bytes.wav":
            attributes = {key: getattr(info, key) for key in (
                "st_mode", "st_nlink", "st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")}
            return SimpleNamespace(**attributes, st_file_attributes=0x400)
        return info
    monkeypatch.setattr(Path, "lstat", reparse)
    _reject(artifacts, "unsafe_artifact_path")


@pytest.mark.parametrize("target,mutation", [("parent", "reparse"), ("leaf", "hardlink"),
    ("leaf", "device"), ("root", "file")])
def test_unsafe_stat_forms_rejected_without_platform_link_privileges(artifacts, monkeypatch, target, mutation):
    original = Path.lstat
    root, *_ = artifacts
    selected = root.parent if target == "parent" else root if target == "root" else root / "bytes.wav"
    def altered(path, *args, **kwargs):
        info = original(path, *args, **kwargs)
        if path != selected:
            return info
        values = {key: getattr(info, key) for key in (
            "st_mode", "st_nlink", "st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")}
        values["st_file_attributes"] = 0x400 if mutation == "reparse" else 0
        if mutation == "hardlink":
            values["st_nlink"] = 2
        elif mutation == "device":
            values["st_mode"] = stat.S_IFCHR | 0o600
        elif mutation == "file":
            values["st_mode"] = stat.S_IFREG | 0o600
        return SimpleNamespace(**values)
    monkeypatch.setattr(Path, "lstat", altered)
    _reject(artifacts, "unsafe_artifact_path")


def test_actual_file_size_limit_matches_bound_exactly(tmp_path):
    raw = b"x" * verifier.MAX_FILE_BYTES
    (tmp_path / "bounded.bin").write_bytes(raw)
    manifest, digest = _write_manifest(tmp_path, _value([_entry("bounded.bin", raw)]))
    result = verifier.verify_artifact_manifest(tmp_path, manifest, expected_manifest_sha256=digest)
    assert result["total_bytes"] == verifier.MAX_FILE_BYTES


def test_streaming_extra_byte_rejected_before_digest_or_json(artifacts, monkeypatch):
    original = verifier.os.fdopen
    class GrowingStream:
        def __init__(self, stream):
            self.stream, self.extra = stream, False
        def __enter__(self):
            return self
        def __exit__(self, *args):
            self.stream.close()
        def fileno(self):
            return self.stream.fileno()
        def read(self, size):
            data = self.stream.read(size)
            if not data and not self.extra:
                self.extra = True
                return b"x"
            return data
    root, *_ = artifacts
    # Direct bounded-reader check: a source reporting its original size but
    # streaming one extra byte must stop at limit+1, not retain extra payload.
    path = root / "bytes.wav"
    monkeypatch.setattr(verifier.os, "fdopen", lambda *args, **kwargs: GrowingStream(original(*args, **kwargs)))
    with pytest.raises(verifier.ArtifactVerificationError, match="artifact_file_too_large"):
        verifier._read_regular(path, path.stat().st_size)


def test_tree_entry_limit_is_enforced(artifacts, monkeypatch):
    monkeypatch.setattr(verifier, "MAX_TREE_ENTRIES", 3)
    _reject(artifacts, "artifact_tree_limit_exceeded")


def test_changed_file_during_open_rejected(artifacts, monkeypatch):
    root, *_ = artifacts
    original = verifier.os.open
    changed = False
    def mutate(path, flags, *args, **kwargs):
        nonlocal changed
        if Path(path) == root / "bytes.wav" and not changed:
            changed = True
            Path(path).write_bytes(b"same-ish length but different bytes")
        return original(path, flags, *args, **kwargs)
    monkeypatch.setattr(verifier.os, "open", mutate)
    _reject(artifacts, "artifact_changed_during_verification")


def test_named_descriptor_ctime_origins_are_not_cross_compared(artifacts, monkeypatch):
    original = verifier.os.fstat
    def differing_descriptor_ctime(fd):
        info = original(fd)
        values = {key: getattr(info, key) for key in (
            "st_mode", "st_nlink", "st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")}
        values["st_ctime_ns"] += 100
        values["st_birthtime_ns"] = getattr(info, "st_birthtime_ns", info.st_ctime_ns)
        values["st_file_attributes"] = getattr(info, "st_file_attributes", 0)
        return SimpleNamespace(**values)
    if os.name != "nt":
        # The cross-origin exception is available only where native birth time
        # is exposed by BOTH stat origins; POSIX ctime should still be compared.
        pytest.skip("Windows creation/change-time origin test")
    monkeypatch.setattr(verifier.os, "fstat", differing_descriptor_ctime)
    root, manifest, digest, *_ = artifacts
    assert verifier.verify_artifact_manifest(root, manifest,
        expected_manifest_sha256=digest)["status"] == "verified"


def test_descriptor_mutation_ctime_still_checked_within_same_origin(artifacts, monkeypatch):
    original = verifier.os.fstat
    reads = {}
    def changed_descriptor_ctime(fd):
        info = original(fd)
        key = (fd, info.st_ino)
        reads[key] = reads.get(key, 0) + 1
        values = {field: getattr(info, field) for field in (
            "st_mode", "st_nlink", "st_dev", "st_ino", "st_size", "st_mtime_ns", "st_ctime_ns")}
        if reads[key] >= 2:
            values["st_ctime_ns"] += 100
        if hasattr(info, "st_birthtime_ns"):
            values["st_birthtime_ns"] = info.st_birthtime_ns
        values["st_file_attributes"] = getattr(info, "st_file_attributes", 0)
        return SimpleNamespace(**values)
    monkeypatch.setattr(verifier.os, "fstat", changed_descriptor_ctime)
    _reject(artifacts, "artifact_changed_during_verification")


def test_same_bytes_leaf_replacement_during_read_is_not_digest_only(artifacts, monkeypatch):
    root, *_ = artifacts
    original = verifier.os.open
    changed = False
    def replace(path, flags, *args, **kwargs):
        nonlocal changed
        if Path(path) == root / "bytes.wav" and not changed:
            changed = True
            raw = Path(path).read_bytes()
            replacement = root / "temporary-replacement.bin"
            replacement.write_bytes(raw)
            os.replace(replacement, path)
        return original(path, flags, *args, **kwargs)
    monkeypatch.setattr(verifier.os, "open", replace)
    _reject(artifacts, "artifact_changed_during_verification")


def test_added_file_after_reads_rejected(artifacts, monkeypatch):
    root, manifest, *_ = artifacts
    original = verifier._read_regular
    manifest_reads = 0
    def mutate(path, *args, **kwargs):
        nonlocal manifest_reads
        result = original(path, *args, **kwargs)
        if path == manifest:
            manifest_reads += 1
            if manifest_reads == 2:
                (root / "late-added.bin").write_bytes(b"unexpected")
        return result
    monkeypatch.setattr(verifier, "_read_regular", mutate)
    _reject(artifacts, "artifact_changed_during_verification")


def test_manifest_change_during_artifact_reads_rejected(artifacts, monkeypatch):
    root, manifest, *_ = artifacts
    original = verifier._read_regular
    def mutate(path, *args, **kwargs):
        result = original(path, *args, **kwargs)
        if path == root / "bytes.wav":
            with manifest.open("ab") as stream:
                stream.write(b" ")
        return result
    monkeypatch.setattr(verifier, "_read_regular", mutate)
    _reject(artifacts, "artifact_changed_during_verification")


def test_file_reads_are_chunk_bounded_and_never_use_read_bytes(artifacts, monkeypatch):
    root, manifest, _, value, raw = artifacts
    data = b"x" * (verifier.READ_CHUNK_BYTES * 3 + 17)
    (root / "bytes.wav").write_bytes(data)
    value["files"][0] = _entry("bytes.wav", data)
    manifest, digest = _write_manifest(root, value)
    original = verifier.os.fdopen
    calls = []
    class GuardedStream:
        def __init__(self, stream):
            self.stream = stream
        def __enter__(self):
            return self
        def __exit__(self, *args):
            self.stream.close()
        def fileno(self):
            return self.stream.fileno()
        def read(self, size=-1):
            calls.append(size)
            assert 0 < size <= verifier.READ_CHUNK_BYTES
            return self.stream.read(size)
    monkeypatch.setattr(verifier.os, "fdopen", lambda *args, **kwargs: GuardedStream(original(*args, **kwargs)))
    monkeypatch.setattr(Path, "read_bytes", lambda *_: pytest.fail("unbounded read_bytes used"))
    result = verifier.verify_artifact_manifest(root, manifest, expected_manifest_sha256=digest)
    assert result["status"] == "verified"
    assert len(calls) >= 8


@pytest.mark.parametrize("error", [OSError("private-location"), ValueError("private-location"),
    TypeError("private-location"), KeyError("private-location")])
def test_unexpected_errors_expose_only_safe_codes(artifacts, monkeypatch, error):
    def fail(*args, **kwargs):
        raise error
    monkeypatch.setattr(verifier, "_tree", fail)
    code = _reject(artifacts)
    assert code in {"artifact_read_error", "artifact_verification_internal_error"}


def test_module_loads_standalone_without_dsp_dependencies(monkeypatch):
    source = Path(verifier.__file__)
    spec = importlib.util.spec_from_file_location("standalone_artifact_only", source)
    module = importlib.util.module_from_spec(spec)
    original = __import__
    def forbid(name, *args, **kwargs):
        if name.startswith(("audio_regression", "numpy", "scipy")):
            pytest.fail("DSP dependency imported by inert verifier")
        return original(name, *args, **kwargs)
    monkeypatch.setattr("builtins.__import__", forbid)
    spec.loader.exec_module(module)
    assert module.ENGINE == "preserved_artifact_integrity_v1"


def test_arbitrary_manifest_name_and_unicode_portable_artifact(tmp_path):
    data = b"inert binary bytes"
    (tmp_path / "일반-파일.bin").write_bytes(data)
    value = _value([_entry("일반-파일.bin", data)])
    manifest, digest = _write_manifest(tmp_path, value, name="saved_anchor.json")
    result = verifier.verify_artifact_manifest(tmp_path, manifest, expected_manifest_sha256=digest)
    assert result["file_count"] == 1


def test_no_native_audio_import_execution_or_network_names_in_source():
    source = Path(verifier.__file__).read_text(encoding="utf-8")
    for prohibited in ("from .", "import numpy", "import scipy", "import subprocess",
                       "import socket", "import urllib", "decode_wav(", "exec(", "eval("):
        assert prohibited not in source
