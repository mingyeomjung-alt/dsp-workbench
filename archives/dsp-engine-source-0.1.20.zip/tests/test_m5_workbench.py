"""Explicit local GUI choices and inert lineage transport, not accuracy proof."""

import base64
from copy import deepcopy
from importlib import resources
import json
from pathlib import Path

import numpy as np
import pytest
from scipy.signal import resample

from audio_regression import workbench as wb
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.event_lineage import build_event_lineage
from audio_regression.fixtures import generate_case
from audio_regression.pipeline_reporting import _STYLE as PIPELINE_STYLE
from audio_regression.resampler_engine import MODEL
from test_event_lineage import chain
from test_workbench import error_body, payload, post, post_headers, request, server, wav_bytes


def fft_payload():
    raw = generate_case(seed=202610152133, duration_seconds=3,
                        sample_rate_hz=48000).reference_wav
    source = decode_wav(raw)
    output = encode_wav(resample(source.samples, len(source.samples) // 3), 16000)
    value = payload(raw, engine="v12")
    value["processed"]["base64"] = base64.b64encode(output).decode("ascii")
    value["allow_resampling"] = True
    value["resampling_model"] = MODEL
    return value


def lineage_post(server, value, *, headers=None):
    raw = value if isinstance(value, bytes) else json.dumps(value, ensure_ascii=False).encode("utf-8")
    return request(server, "POST", "/api/lineage", body=raw,
                   headers=headers or post_headers(server, len(raw)))


@pytest.mark.parametrize("engine", ["v1", "v9", "v10", "v11"])
def test_existing_five_field_request_and_explicit_native_choices(wav_bytes, engine):
    value = payload(wav_bytes, engine=engine)
    assert wb._read_request_json(json.dumps(value).encode()) == value
    assert set(value) == wb._REQUEST_FIELDS


def test_fft_transport_requires_exact_named_model():
    value = fft_payload()
    assert wb._read_request_json(json.dumps(value).encode()) == value
    assert value["resampling_model"] == MODEL


@pytest.mark.parametrize("mutation", ["missing", "null", "wrong", "bool", "gain", "undeclared"])
def test_fft_bad_options_rejected_before_audio_or_temporary_directory(server, monkeypatch, mutation):
    value = fft_payload()
    if mutation == "missing":
        del value["resampling_model"]
    elif mutation == "null":
        value["resampling_model"] = None
    elif mutation == "wrong":
        value["resampling_model"] = "guess_any_filter"
    elif mutation == "bool":
        value["resampling_model"] = True
    elif mutation == "gain":
        value["allow_gain"] = True
    else:
        value["allow_resampling"] = False
    monkeypatch.setattr(wb, "_audio_bytes", lambda *_: pytest.fail("bad options must precede audio decoding"))
    monkeypatch.setattr(wb.tempfile, "TemporaryDirectory", lambda **_: pytest.fail("bad options must not write files"))
    error_body(post(server, value), 400, "invalid_resampling_configuration")


@pytest.mark.parametrize("engine", ["v1", "v9", "v10", "v11"])
def test_other_engines_cannot_consume_fft_model_key(wav_bytes, engine):
    value = payload(wav_bytes, engine=engine)
    value["resampling_model"] = MODEL
    with pytest.raises(wb._RequestError) as caught:
        wb._read_request_json(json.dumps(value).encode())
    assert caught.value.code == "invalid_resampling_configuration"


@pytest.mark.parametrize("bad_input", ["source_rate", "target_rate", "nondivisible"])
def test_fft_input_grid_rejected_before_temporary_writes(server, monkeypatch, bad_input):
    value = fft_payload()
    if bad_input == "source_rate":
        value["reference"] = deepcopy(value["processed"])
    elif bad_input == "target_rate":
        value["processed"] = deepcopy(value["reference"])
    else:
        source = decode_wav(base64.b64decode(value["reference"]["base64"]))
        raw = encode_wav(np.r_[source.samples, 0.0], 48000)
        value["reference"]["base64"] = base64.b64encode(raw).decode("ascii")
    monkeypatch.setattr(wb.tempfile, "TemporaryDirectory", lambda **_: pytest.fail("incompatible input must not write files"))
    monkeypatch.setattr(wb, "analyze_pair", lambda *_a, **_k: pytest.fail("no fallback analysis"))
    error_body(post(server, value), 400, "unsupported_resampling_input")


@pytest.mark.parametrize("engine", ["v10", "v11", "v12"])
def test_explicit_options_forwarded_and_audio_cleaned(server, wav_bytes, monkeypatch, engine):
    value = fft_payload() if engine == "v12" else payload(wav_bytes, engine=engine)
    calls = []
    def analyzer(reference, processed, **options):
        assert reference.is_file() and processed.is_file()
        assert set(options) == ({"engine", "allow_gain", "allow_resampling", "resampling_model"}
                                if engine == "v12" else {"engine", "allow_gain", "allow_resampling"})
        assert options["engine"] == engine
        if engine == "v12":
            assert options["resampling_model"] == MODEL and options["allow_resampling"] is True
        calls.append(reference.parent)
        return {"schema_version": 1, "status": "error", "reason_code": "test_error"}
    monkeypatch.setattr(wb, "analyze_pair", analyzer)
    status, _, body = post(server, value)
    assert status == 200 and json.loads(body)["check"]["exit_code"] == 2
    assert calls and all(not path.exists() for path in calls)


def test_real_declared_fft_path_uses_v12_without_default_switch(server):
    status, _, body = post(server, fft_payload())
    result = json.loads(body)
    assert status == 200 and result["check"]["exit_code"] == 0
    assert result["result"]["engine"] == "local_content_alignment_v12"
    assert result["result"]["reference"]["sample_rate_hz"] == 48000
    assert result["result"]["processed"]["sample_rate_hz"] == 16000
    assert result["check"]["complete_audio_approval"] is False


def test_lineage_rebuild_is_inert_and_preserves_original_gate(server, monkeypatch):
    source = chain("delete", "clean")
    expected = build_event_lineage(source)
    monkeypatch.setattr(wb.tempfile, "TemporaryDirectory", lambda **_: pytest.fail("lineage must not create audio files"))
    monkeypatch.setattr(Path, "open", lambda *_a, **_k: pytest.fail("saved artifact paths must stay inert"))
    status, _, body = lineage_post(server, {"source_result": source})
    result = json.loads(body)
    assert status == 200 and result["status"] == "completed"
    assert result["lineage_result"] == expected
    assert result["lineage_result"]["projection"]["original_summary"] == source["summary"]
    assert result["lineage_result"]["complete_audio_approval"] is False
    assert "기존 검사 판정 유지" in result["report_html"]


@pytest.mark.parametrize("raw,code", [
    (b'{"source_result":{},"source_result":{}}', "invalid_json"),
    (b'{"source_result":{"nested":NaN}}', "invalid_json"),
    (b'{"source_result":{"nested":1,"nested":2}}', "invalid_json"),
    (b'{"source_result":{}}', "invalid_lineage_source"),
    (b'{"source_result":[]}', "invalid_lineage_request"),
    (b'{"source_result":{},"path":"C:/private.wav"}', "invalid_lineage_request"),
    (b'{"source_result":{"audio":{"base64":"YWJj"}}}', "invalid_lineage_source"),
    (b"\xff", "invalid_json"),
    (b"[" * 1100, "invalid_json"),
])
def test_lineage_strict_bounded_json(server, raw, code):
    error_body(lineage_post(server, raw), 400, code)


def test_lineage_request_size_rejected_before_body_and_slot_available(server):
    error_body(request(server, "POST", "/api/lineage",
                       headers=post_headers(server, wb.MAX_LINEAGE_REQUEST_BYTES + 1)),
               413, "request_too_large")
    assert server.analysis_lock.acquire(blocking=False)
    server.analysis_lock.release()


@pytest.mark.parametrize("guard", ["host", "origin", "token"])
def test_lineage_uses_same_loopback_authentication(server, guard):
    headers = post_headers(server, 100)
    position = {"host": 0, "origin": 1, "token": 2}[guard]
    headers[position] = (headers[position][0], "untrusted")
    error_body(request(server, "POST", "/api/lineage", headers=headers),
               403, {"host": "invalid_host", "origin": "invalid_origin", "token": "invalid_session"}[guard])


def test_lineage_and_pair_share_single_bounded_worker(server):
    assert server.analysis_lock.acquire(blocking=False)
    try:
        error_body(request(server, "POST", "/api/lineage", headers=post_headers(server, 100)),
                   429, "analysis_busy")
    finally:
        server.analysis_lock.release()


def test_lineage_renderer_exception_is_sanitized_and_slot_released(server, monkeypatch):
    def failed(_value):
        raise RuntimeError("C:/private/name.wav secret")
    monkeypatch.setattr(wb, "render_event_lineage_html", failed)
    result = error_body(lineage_post(server, {"source_result": chain("delete")}),
                        500, "analysis_failed")
    assert "private" not in json.dumps(result) and "secret" not in json.dumps(result)
    assert server.analysis_lock.acquire(blocking=False)
    server.analysis_lock.release()


def test_two_report_style_hashes_are_allowed_without_unsafe_inline(server):
    status, headers, _ = request(server, "GET", "/")
    assert status == 200 and "'unsafe-inline'" not in headers["Content-Security-Policy"]
    import hashlib
    expected = base64.b64encode(hashlib.sha256(PIPELINE_STYLE.encode()).digest()).decode()
    assert f"'sha256-{expected}'" in headers["Content-Security-Policy"]
    assert wb._REPORT_STYLE_HASH != expected


def test_gui_opt_in_choices_and_lineage_are_present_with_no_auto_declaration():
    assets = resources.files("audio_regression").joinpath("workbench_assets")
    html = assets.joinpath("index.html").read_text(encoding="utf-8")
    js = assets.joinpath("app.js").read_text(encoding="utf-8")
    assert '<option value="v1">' in html and 'selected' not in html
    for engine in ("v9", "v10", "v11", "v12"):
        assert f'<option value="{engine}">' in html
    assert 'id="lineage-file"' in html and 'id="lineage-frame"' in html
    assert '/api/lineage' in js and "sourceText + '}'" in js
    assert 'new TextDecoder("utf-8", { fatal: true })' in js
    assert MODEL in js
    assert '$("allow-resampling").checked = true' not in js
    assert 'request.resampling_model = FFT_RESAMPLING_MODEL' in js
    assert '.innerHTML' not in js and 'eval(' not in js
