"""Explicit model mathematics, with new generated PCM only and scalar oracles."""

from fractions import Fraction
import hashlib
import json
import struct

import numpy as np
import pytest

import audio_regression.transform_models as model_module
from audio_regression.audio import WavAudio, decode_wav, encode_wav
from audio_regression.transform_models import (
    MAX_MODELS,
    MODEL_KINDS,
    ModelTransformError,
    render_models,
    validate_model_plan,
    validate_models,
)


RATES = [8000, 16000, 44100, 48000]
KINDS = ["polarity_invert", "fir_binomial_3", "pcm_quantize_12"]


def _audio(pcm: list[int] | np.ndarray, rate: int = 8000) -> tuple[bytes, WavAudio]:
    values = np.asarray(pcm, dtype=np.float64) / 32768.0
    data = encode_wav(values, rate)
    return data, decode_wav(data)


def _pcm(data: bytes) -> list[int]:
    # Independent container payload reading, not the renderer's decode logic.
    assert data[:4] == b"RIFF" and data[8:12] == b"WAVE"
    assert len(data) - 8 == struct.unpack_from("<I", data, 4)[0]
    assert data[36:40] == b"data"
    return list(struct.unpack(f"<{(len(data) - 44) // 2}h", data[44:]))


def _scalar_step(pcm: list[int], kind: str) -> list[int]:
    if kind == "polarity_invert":
        result = [-value for value in pcm]
    elif kind == "fir_binomial_3":
        result = [
            round(Fraction(value + 2 * (pcm[i - 1] if i >= 1 else 0) + (pcm[i - 2] if i >= 2 else 0), 4))
            for i, value in enumerate(pcm)
        ]
    else:
        result = [16 * round(Fraction(value, 16)) for value in pcm]
    if any(value < -32768 or value > 32767 for value in result):
        raise OverflowError
    return result


def _scalar_models(pcm: list[int], kinds: list[str]) -> list[int]:
    for kind in kinds:
        pcm = _scalar_step(pcm, kind)
    return pcm


def _models(kinds: list[str]) -> list[dict]:
    return [{"kind": kind} for kind in kinds]


def _assert_error(call, code: str) -> None:
    with pytest.raises(ModelTransformError) as caught:
        call()
    assert caught.value.code == code
    assert "/private/path" not in str(caught.value)
    assert "caller-secret" not in str(caught.value)


def test_error_code_and_optional_safe_message() -> None:
    error = ModelTransformError("safe_code")
    assert error.code == error.message == str(error) == "safe_code"
    error = ModelTransformError("safe_code", "Fixed explanation.")
    assert error.code == "safe_code" and str(error) == "Fixed explanation."


@pytest.mark.parametrize("kind", KINDS)
@pytest.mark.parametrize("count", [1, MAX_MODELS])
def test_model_specs_are_fresh_fixed_parameter_free_json(kind: str, count: int) -> None:
    models = [{"kind": kind}] * count
    result = validate_models(models)
    assert result == models and result is not models
    assert all(left is not right for left, right in zip(models, result))
    assert len({id(item) for item in result}) == count
    assert json.loads(json.dumps(result, allow_nan=False)) == result
    assert MODEL_KINDS == frozenset(KINDS)
    models[0]["kind"] = "caller-secret"
    assert result == [{"kind": kind}] * count


def test_plan_validation_makes_all_containers_fresh() -> None:
    plan = {"schema_version": 1, "models": _models(KINDS)}
    result = validate_model_plan(plan)
    assert result == plan and result is not plan
    assert result["models"] is not plan["models"]
    assert all(a is not b for a, b in zip(result["models"], plan["models"]))
    plan["models"][0]["kind"] = "caller-secret"
    assert result["models"][0] == {"kind": "polarity_invert"}
    json.dumps(result, allow_nan=False)


@pytest.mark.parametrize("value", [None, False, True, 1, 1.5, float("nan"), float("inf"), "caller-secret", (), {}, [], [None], [True], [1], [1.5], [{"kind": "polarity_invert"}] * 5])
def test_reject_non_list_wrong_item_and_cardinality(value) -> None:
    _assert_error(lambda: validate_models(value), "invalid_models")


@pytest.mark.parametrize("spec", [
    {}, {"kind": None}, {"kind": True}, {"kind": 12}, {"kind": 12.0},
    {"kind": float("nan")}, {"kind": float("inf")}, {"kind": -float("inf")},
    {"kind": np.int64(1)}, {"kind": np.str_("polarity_invert")},
    {"kind": "caller-secret/private/path"}, {"kind": "gain"}, {"kind": "fir"},
    {"kind": "polarity_invert", "parameters": {}}, {"kind": "pcm_quantize_12", "bits": 12},
    {"kind": "fir_binomial_3", "taps": [0.25, 0.5, 0.25]}, {"kind": "polarity_invert", "label": "x"},
    {"not_kind": "polarity_invert"}, {False: "polarity_invert"},
])
def test_reject_extra_fields_unknown_kinds_and_non_exact_types(spec) -> None:
    _assert_error(lambda: validate_models([spec]), "invalid_models")


@pytest.mark.parametrize("plan", [
    None, [], True, {}, {"models": _models(KINDS)}, {"schema_version": 1},
    {"schema_version": 1, "models": _models(KINDS), "extra": 1},
    {"schema_version": True, "models": _models(KINDS)},
    {"schema_version": 1.0, "models": _models(KINDS)},
    {"schema_version": np.int64(1), "models": _models(KINDS)},
    {"schema_version": "1", "models": _models(KINDS)},
    {"schema_version": 2, "models": _models(KINDS)},
    {"schema_version": float("nan"), "models": _models(KINDS)},
    {False: 1, "models": _models(KINDS)},
])
def test_reject_plan_envelopes_without_coercion(plan) -> None:
    _assert_error(lambda: validate_model_plan(plan), "invalid_model_plan")


@pytest.mark.parametrize("models", [None, [], [None], [{"kind": "polarity_invert", "extra": 1}]])
def test_plan_nested_model_failure_remains_specific(models) -> None:
    _assert_error(lambda: validate_model_plan({"schema_version": 1, "models": models}), "invalid_models")


def test_cycles_and_huge_unknown_payloads_are_rejected_without_traversal() -> None:
    cyclic_list = []
    cyclic_list.append(cyclic_list)
    cyclic_dict = {"kind": None}
    cyclic_dict["kind"] = cyclic_dict
    for models in [cyclic_list, [cyclic_dict], [{"kind": "x" * 1_000_000}], [None] * 1_000_000]:
        _assert_error(lambda: validate_models(models), "invalid_models")
    plan = {"schema_version": 1, "models": None}
    plan["models"] = plan
    _assert_error(lambda: validate_model_plan(plan), "invalid_models")


def test_builtin_subclasses_and_hostile_keys_are_not_coerced_or_formatted() -> None:
    class Hostile:
        def __hash__(self):
            return 327

        def __eq__(self, other):
            raise AssertionError("must not compare unknown objects")

        def __repr__(self):
            raise AssertionError("must not format unknown objects")

    class SubList(list):
        pass

    class SubDict(dict):
        pass

    class SubStr(str):
        pass

    for models in [SubList(_models(KINDS)), [SubDict(kind="polarity_invert")], [{"kind": SubStr("polarity_invert")}], [{Hostile(): "polarity_invert"}], [{"kind": Hostile()}]]:
        _assert_error(lambda: validate_models(models), "invalid_models")
    _assert_error(lambda: validate_model_plan(SubDict(schema_version=1, models=_models(KINDS))), "invalid_model_plan")
    _assert_error(lambda: validate_model_plan({Hostile(): 1, "models": _models(KINDS)}), "invalid_model_plan")


@pytest.mark.parametrize("rate", RATES)
@pytest.mark.parametrize("kind", KINDS)
def test_each_model_matches_independent_scalar_reference_at_four_rates(rate: int, kind: str) -> None:
    rng = np.random.default_rng(202610140417 + rate)
    pcm = rng.integers(-29000, 29001, 2 * rate + 17, dtype=np.int32).tolist()
    source, audio = _audio(pcm, rate)
    original_samples = audio.samples.copy()
    models = _models([kind])
    output = render_models(audio, models)
    assert _pcm(output) == _scalar_step(pcm, kind)
    decoded = decode_wav(output)
    assert decoded.sample_rate_hz == rate and decoded.samples.size == len(pcm)
    assert models == _models([kind])
    np.testing.assert_array_equal(audio.samples, original_samples)
    assert audio.sha256 == hashlib.sha256(source).hexdigest()
    assert not audio.samples.flags.writeable


@pytest.mark.parametrize("rate", RATES)
@pytest.mark.parametrize("kinds", [
    ["polarity_invert", "polarity_invert"],
    ["fir_binomial_3", "pcm_quantize_12"],
    ["pcm_quantize_12", "fir_binomial_3"],
    ["fir_binomial_3", "fir_binomial_3"],
    ["polarity_invert", "fir_binomial_3", "pcm_quantize_12", "fir_binomial_3"],
])
def test_order_and_per_step_quantization_match_scalar_reference(rate: int, kinds: list[str]) -> None:
    pcm = np.resize(np.array([1, 7, 8, 9, 15, 16, 17, 24, 31, -1, -7, -8, -9, -15, -16, -17, -24, -31]), 2 * rate + 19).tolist()
    _, audio = _audio(pcm, rate)
    result = render_models(audio, _models(kinds))
    assert _pcm(result) == _scalar_models(pcm, kinds)


def test_models_are_not_commutative_and_repeated_fir_does_not_fuse_rounding() -> None:
    pcm = np.resize([1, 7, 8, 9, 15, 16, 17, 24, 31, -1, -7, -8, -9], 16000).tolist()
    _, audio = _audio(pcm)
    fq = render_models(audio, _models(["fir_binomial_3", "pcm_quantize_12"]))
    qf = render_models(audio, _models(["pcm_quantize_12", "fir_binomial_3"]))
    assert fq != qf
    two_fir = _pcm(render_models(audio, _models(["fir_binomial_3", "fir_binomial_3"])))
    first_unrounded = [Fraction(value + 2 * (pcm[i - 1] if i >= 1 else 0) + (pcm[i - 2] if i >= 2 else 0), 4) for i, value in enumerate(pcm)]
    fused = [round((value + 2 * (first_unrounded[i - 1] if i >= 1 else 0) + (first_unrounded[i - 2] if i >= 2 else 0)) / 4) for i, value in enumerate(first_unrounded)]
    assert two_fir != fused
    assert two_fir == _scalar_models(pcm, ["fir_binomial_3", "fir_binomial_3"])


@pytest.mark.parametrize("position", [0, 1, 15998, 15999])
@pytest.mark.parametrize("amplitude", [4, 2, -2, 32767, -32768])
def test_causal_fir_impulses_include_zero_state_ties_and_discarded_tail(position: int, amplitude: int) -> None:
    pcm = [0] * 16000
    pcm[position] = amplitude
    _, audio = _audio(pcm)
    output = render_models(audio, _models(["fir_binomial_3"]))
    assert _pcm(output) == _scalar_step(pcm, "fir_binomial_3")
    assert len(_pcm(output)) == len(pcm)
    assert all(value == 0 for value in _pcm(output)[:position])


def test_fir_constant_startup_is_not_padding_or_noncausal_filtering() -> None:
    _, audio = _audio([100] * 16000)
    values = _pcm(render_models(audio, _models(["fir_binomial_3"])))
    assert values[:4] == [25, 75, 100, 100]
    assert values[-1] == 100


@pytest.mark.parametrize("endpoint", [-32768, 32767])
def test_fir_handles_pcm_endpoints_without_clipping(endpoint: int) -> None:
    pcm = [endpoint] * 16000
    _, audio = _audio(pcm)
    output = _pcm(render_models(audio, _models(["fir_binomial_3"])))
    assert output == _scalar_step(pcm, "fir_binomial_3")
    assert output[-1] == endpoint


def test_quantizer_covers_every_nonoverflow_pcm_integer_with_scalar_ties_even() -> None:
    pcm = list(range(-32768, 32760))
    _, audio = _audio(pcm)
    output = _pcm(render_models(audio, _models(["pcm_quantize_12"])))
    assert output == _scalar_step(pcm, "pcm_quantize_12")
    assert all(value % 16 == 0 for value in output)
    assert output[0] == -32768 and output[-1] == 32752


@pytest.mark.parametrize("value", [32760, 32761, 32762, 32763, 32764, 32765, 32766, 32767])
def test_quantizer_positive_overflow_is_rejected_without_saturation(value: int) -> None:
    _, audio = _audio([value] * 16000)
    before = audio.samples.copy()
    _assert_error(lambda: render_models(audio, _models(["pcm_quantize_12"])), "model_output_out_of_range")
    np.testing.assert_array_equal(audio.samples, before)


def test_polarity_negative_endpoint_overflow_is_rejected_without_limiting() -> None:
    _, audio = _audio([-32768] + [0] * 15999)
    _assert_error(lambda: render_models(audio, _models(["polarity_invert"])), "model_output_out_of_range")
    assert audio.samples[0] == -1.0


def test_pcm_steps_cannot_bypass_an_intermediate_overflow() -> None:
    _, audio = _audio([-32768] + [0] * 15999)
    _assert_error(lambda: render_models(audio, _models(["polarity_invert", "polarity_invert"])), "model_output_out_of_range")
    _, audio = _audio([32767] + [0] * 15999)
    _assert_error(lambda: render_models(audio, _models(["pcm_quantize_12", "fir_binomial_3"])), "model_output_out_of_range")
    assert _pcm(render_models(audio, _models(["fir_binomial_3", "pcm_quantize_12"])))[0] == 8192


@pytest.mark.parametrize("rate", RATES)
@pytest.mark.parametrize("seconds", [2, 30])
@pytest.mark.parametrize("kind", KINDS)
def test_inclusive_geometry_bounds_preserved(rate: int, seconds: int, kind: str) -> None:
    _, audio = _audio(np.zeros(rate * seconds, dtype=np.int16), rate)
    result = decode_wav(render_models(audio, _models([kind])))
    assert result.sample_rate_hz == rate and result.samples.size == rate * seconds
    assert result.metadata()["duration_ms"] == seconds * 1000


@pytest.mark.parametrize("invalid", [None, b"RIFF", np.zeros(16000), {"samples": []}, True])
def test_render_rejects_non_audio_objects(invalid) -> None:
    _assert_error(lambda: render_models(invalid, _models(["polarity_invert"])), "invalid_audio")


def test_uninitialized_audio_has_a_private_free_structured_rejection() -> None:
    incomplete = object.__new__(WavAudio)
    _assert_error(lambda: render_models(incomplete, _models(["polarity_invert"])), "invalid_audio")


@pytest.mark.parametrize("field,value", [
    ("samples", np.zeros(15999)), ("samples", np.zeros(240001)),
    ("samples", np.full(16000, np.nan)), ("samples", np.full(16000, np.inf)),
    ("samples", np.full(16000, 0.00001)), ("samples", np.full(16000, 1.0)),
    ("samples", np.full(16000, -1.0001)), ("samples", np.zeros((16000, 1))),
    ("samples", np.zeros(16000, dtype=np.int16)), ("samples", [0] * 16000),
    ("sample_rate_hz", True), ("sample_rate_hz", 8000.0), ("sample_rate_hz", 22050),
    ("sha256", "caller-secret/private/path"),
])
def test_forged_audio_cannot_skip_pcm_duration_type_and_finite_validation(field: str, value) -> None:
    _, valid = _audio(np.zeros(16000))
    forged = object.__new__(WavAudio)
    for name in ["samples", "sample_rate_hz", "sha256"]:
        object.__setattr__(forged, name, value if field == name else getattr(valid, name))
    _assert_error(lambda: render_models(forged, _models(["polarity_invert"])), "invalid_audio")


def test_invalid_spec_is_checked_before_audio_and_leaves_inputs_unchanged() -> None:
    models = [{"kind": "polarity_invert", "extra": "caller-secret"}]
    _assert_error(lambda: render_models(None, models), "invalid_models")
    assert models == [{"kind": "polarity_invert", "extra": "caller-secret"}]


def test_repeated_render_is_byte_deterministic_and_same_pcm_polarity_twice_is_identity() -> None:
    pcm = np.resize([-32767, -1, 0, 1, 32767], 16000)
    source, audio = _audio(pcm)
    models = _models(["polarity_invert", "polarity_invert"])
    assert render_models(audio, models) == render_models(audio, models) == source


@pytest.mark.parametrize("kind", KINDS)
@pytest.mark.parametrize("count", [1, 2, 3, 4])
def test_each_model_decodes_its_output_exactly_once_without_changing_input(monkeypatch, kind: str, count: int) -> None:
    # Fresh synthetic PCM; no caller file or previously evaluated audio.
    pcm = np.resize(np.array([-28001, -31, -9, -1, 0, 1, 9, 31, 28001]), 16017)
    source, audio = _audio(pcm)
    before = audio.samples.copy()
    observed: list[tuple[bytes, WavAudio]] = []

    def observed_decode(data: bytes) -> WavAudio:
        decoded = decode_wav(data)
        observed.append((data, decoded))
        return decoded

    monkeypatch.setattr(model_module, "decode_wav", observed_decode)
    output = render_models(audio, _models([kind] * count))

    assert type(output) is bytes
    assert len(observed) == count
    assert observed[-1][0] is output
    assert all(not decoded.samples.flags.writeable for _, decoded in observed)
    assert _pcm(output) == _scalar_models(pcm.tolist(), [kind] * count)
    np.testing.assert_array_equal(audio.samples, before)
    assert not audio.samples.flags.writeable
    assert audio.sha256 == hashlib.sha256(source).hexdigest()


def test_reused_step_decode_still_rejects_invalid_encoded_output(monkeypatch) -> None:
    _, audio = _audio(np.zeros(16000, dtype=np.int16))
    calls = []

    def observed_decode(data: bytes) -> WavAudio:
        calls.append(data)
        return decode_wav(data)

    monkeypatch.setattr(model_module, "encode_wav", lambda *args: b"invalid-new-synthetic-output")
    monkeypatch.setattr(model_module, "decode_wav", observed_decode)
    _assert_error(lambda: render_models(audio, _models(["fir_binomial_3"])), "invalid_model_output")
    assert calls == [b"invalid-new-synthetic-output"]


@pytest.mark.parametrize("different_geometry", ["rate", "count"])
def test_reused_step_decode_still_rejects_changed_geometry(monkeypatch, different_geometry: str) -> None:
    _, audio = _audio(np.zeros(16000, dtype=np.int16))
    _, wrong = _audio(
        np.zeros(32000 if different_geometry == "rate" else 16001, dtype=np.int16),
        16000 if different_geometry == "rate" else 8000,
    )
    calls = []

    def wrong_geometry(data: bytes) -> WavAudio:
        calls.append(data)
        return wrong

    monkeypatch.setattr(model_module, "decode_wav", wrong_geometry)
    _assert_error(lambda: render_models(audio, _models(["fir_binomial_3"])), "invalid_model_output")
    assert len(calls) == 1


@pytest.mark.parametrize("kind,value", [("polarity_invert", -32768), ("pcm_quantize_12", 32767)])
def test_overflow_is_rejected_before_any_step_decode(monkeypatch, kind: str, value: int) -> None:
    _, audio = _audio(np.resize(np.array([value, 0], dtype=np.int32), 16000))

    def unexpected_decode(data: bytes) -> WavAudio:
        raise AssertionError("out-of-range output must not be encoded or decoded")

    monkeypatch.setattr(model_module, "decode_wav", unexpected_decode)
    _assert_error(lambda: render_models(audio, _models([kind])), "model_output_out_of_range")
