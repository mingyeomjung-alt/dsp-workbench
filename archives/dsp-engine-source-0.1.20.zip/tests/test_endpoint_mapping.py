"""Fresh synthetic regressions for source-time endpoints after analysis resampling.

No fixture corpus, saved evaluation output, natural recording, or locked trial is
read here. These are implementation/contract checks, not accuracy evidence.
"""

from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import json
import math

import numpy as np
import pytest
from scipy.signal import chirp, resample_poly

from audio_regression import api, cli, context_engine, robust_engine
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.engine import EngineConfig, analyze_buffers
from audio_regression.endpoint_mapping import map_alignment_endpoints
from audio_regression.result_contract import ResultContractError, validate_analysis_result


ENGINES = ("v1", "v2", "v3")
RATES = (8000, 16000, 44100, 48000)
ANALYZERS = {
    "v1": analyze_buffers,
    "v2": robust_engine.analyze_buffers,
    "v3": context_engine.analyze_buffers,
}


@lru_cache(maxsize=None)
def _signal(rate: int, extra_samples: int = 1) -> np.ndarray:
    """Independently generated nonperiodic audio, with an exact requested tail."""
    count = 5 * rate + extra_samples
    rng = np.random.default_rng(913731 + rate)
    time = np.arange(count, dtype=np.float64) / rate
    noise = np.convolve(rng.standard_normal(count), [0.1, 0.2, 0.4, 0.2, 0.1], mode="same")
    envelope = np.interp(
        np.linspace(0, 48, count), np.arange(49), rng.uniform(0.3, 1.0, 49)
    )
    values = envelope * (noise + 0.25 * chirp(time, 290, 5, 2380, method="quadratic"))
    return values * (0.24 / np.max(np.abs(values)))


def _audio(samples: np.ndarray, rate: int):
    return decode_wav(encode_wav(samples, rate))


def _resample(samples: np.ndarray, source_rate: int, target_rate: int) -> np.ndarray:
    divisor = math.gcd(source_rate, target_rate)
    return resample_poly(samples, target_rate // divisor, source_rate // divisor)


def _analyze(engine: str, reference, processed, **configuration) -> dict:
    raw = ANALYZERS[engine](reference, processed, EngineConfig(**configuration))
    before = deepcopy(raw)
    result = map_alignment_endpoints(raw)
    assert raw == before
    restored = deepcopy(result)
    for source, mapped in zip(raw.get("alignment_segments", []), restored.get("alignment_segments", []), strict=True):
        assert mapped["reference_interval_ms"][0] == source["reference_interval_ms"][0]
        assert mapped["reference_interval_ms"][1] <= source["reference_interval_ms"][1]
        mapped["reference_interval_ms"][1] = source["reference_interval_ms"][1]
    assert restored == raw  # Events, offsets, status and all diagnostics unchanged.
    assert validate_analysis_result(result) is result
    assert result["engine"] == f"local_content_alignment_{engine}"
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    if result["status"] == "analyzed":
        for segment in result["alignment_segments"]:
            start, end = segment["reference_interval_ms"]
            offset = segment["processed_offset_ms"]
            assert 0 <= start < end <= reference.metadata()["duration_ms"]
            assert 0 <= start + offset < end + offset <= processed.metadata()["duration_ms"]
    return result


@pytest.mark.parametrize("engine", ENGINES)
@pytest.mark.parametrize("rate", [16000, 44100, 48000])
def test_raw_core_reproduces_old_ceil_endpoint_bug_and_mapping_does_not_mutate_it(engine, rate):
    audio = _audio(_signal(rate), rate)
    raw = ANALYZERS[engine](audio, audio)
    assert raw["status"] == "analyzed"
    end = raw["alignment_segments"][-1]["reference_interval_ms"][1]
    assert 0 < end - raw["reference"]["duration_ms"] < 0.125
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(raw)
    assert caught.value.code == "invalid_alignment_reference_interval"
    before = deepcopy(raw)
    mapped = map_alignment_endpoints(raw)
    assert validate_analysis_result(mapped) is mapped
    assert mapped["alignment_segments"][-1]["reference_interval_ms"][1] == raw["reference"]["duration_ms"]
    assert raw == before


@pytest.mark.parametrize("engine", ENGINES)
@pytest.mark.parametrize("rate", RATES)
@pytest.mark.parametrize("operation", ["identity", "gain", "processed_delay", "reference_delay", "resample"])
def test_valid_odd_length_normal_changes_have_bounded_source_time_axes(engine, rate, operation):
    original = _audio(_signal(rate), rate)
    reference, processed = original, original
    configuration = {}
    if operation == "gain":
        processed = _audio(original.samples * 0.5, rate)
        configuration["allow_gain"] = True
    elif operation == "processed_delay":
        processed = _audio(np.concatenate([np.zeros(round(0.24 * rate)), original.samples]), rate)
    elif operation == "reference_delay":
        reference = _audio(np.concatenate([np.zeros(round(0.24 * rate)), original.samples]), rate)
    elif operation == "resample":
        target = 16000 if rate == 8000 else 8000
        processed = _audio(_resample(original.samples, rate, target), target)
        configuration["allow_resampling"] = True
    reference_copy, processed_copy = reference.samples.copy(), processed.samples.copy()
    result = _analyze(engine, reference, processed, **configuration)
    assert result["status"] == "analyzed", result["reason_code"]
    assert result["events"] == []
    np.testing.assert_array_equal(reference.samples, reference_copy)
    np.testing.assert_array_equal(processed.samples, processed_copy)
    assert result["reference"]["sample_count"] == reference.samples.size
    assert result["processed"]["sample_count"] == processed.samples.size


@pytest.mark.parametrize("engine", ENGINES)
@pytest.mark.parametrize("rate", RATES)
@pytest.mark.parametrize("event_type", ["delete", "repeat"])
def test_real_internal_edit_and_delay_keep_event_time_and_offset_geometry(engine, rate, event_type):
    reference = _audio(_signal(rate), rate)
    first, last = round(1.7 * rate), round(2.1 * rate)
    samples = reference.samples
    edited = (np.concatenate([samples[:first], samples[last:]]) if event_type == "delete" else
              np.concatenate([samples[:last], samples[first:last], samples[last:]]))
    processed = _audio(np.concatenate([np.zeros(round(0.24 * rate)), 0.5 * edited]), rate)
    result = _analyze(engine, reference, processed, allow_gain=True)
    assert result["status"] == "analyzed", result["reason_code"]
    assert len(result["events"]) == 1
    event = result["events"][0]
    assert event["type"] == event_type
    evidence = event["evidence"]
    assert evidence["offset_before_ms"] == pytest.approx(240.0, abs=0.125)
    assert evidence["offset_after_ms"] == pytest.approx(-160.0 if event_type == "delete" else 640.0, abs=0.125)
    if event_type == "delete":
        assert event["reference_interval_ms"] == pytest.approx([1700.0, 2100.0], abs=100.0)
        assert event["processed_boundary_ms"] == pytest.approx(1940.0, abs=100.0)
        start, end = event["reference_interval_ms"]
        assert event["processed_boundary_ms"] == pytest.approx(start + evidence["offset_before_ms"], abs=1e-9)
        assert event["processed_boundary_ms"] == pytest.approx(end + evidence["offset_after_ms"], abs=1e-9)
    else:
        assert event["reference_source_interval_ms"] == pytest.approx([1700.0, 2100.0], abs=100.0)
        assert event["processed_added_interval_ms"] == pytest.approx([2340.0, 2740.0], abs=100.0)
        assert event["processed_added_interval_ms"][1] <= processed.metadata()["duration_ms"]
        assert event["reference_source_interval_ms"][1] <= reference.metadata()["duration_ms"]


@pytest.mark.parametrize("engine", ENGINES)
@pytest.mark.parametrize("rate", RATES)
@pytest.mark.parametrize("extra_samples", [0, 1, 2, 3])
def test_file_api_accepts_even_and_odd_tail_counts_without_modifying_inputs(tmp_path, engine, rate, extra_samples):
    data = encode_wav(_signal(rate, extra_samples), rate)
    reference_path, processed_path = tmp_path / "reference.wav", tmp_path / "processed.wav"
    reference_path.write_bytes(data)
    processed_path.write_bytes(data)
    result = api.analyze_pair(reference_path, processed_path, engine=engine)
    assert result["status"] == "analyzed", result["reason_code"]
    assert result["events"] == []
    assert result["reference"]["sample_count"] == 5 * rate + extra_samples
    assert result["reference"]["duration_ms"] == (5 * rate + extra_samples) * 1000 / rate
    assert result["alignment_segments"][-1]["reference_interval_ms"][1] <= result["reference"]["duration_ms"]
    assert reference_path.read_bytes() == processed_path.read_bytes() == data


@pytest.mark.parametrize("engine", ENGINES)
@pytest.mark.parametrize("rate", RATES)
def test_processed_axis_is_limited_independently_and_real_8k_overrun_is_not_hidden(engine, rate):
    reference = _audio(_signal(rate, 2), rate)
    processed = _audio(reference.samples[:-1], rate)
    raw = ANALYZERS[engine](reference, processed)
    assert raw["status"] == "analyzed"
    before = deepcopy(raw)
    if rate == 8000:
        # No analysis-resampling ceil padding exists at 8k. An actual one-sample
        # mismatch must remain invalid rather than receiving a blanket clamp.
        with pytest.raises(ResultContractError) as caught:
            validate_analysis_result(map_alignment_endpoints(raw))
        assert caught.value.code == "invalid_alignment_processed_interval"
    else:
        mapped = map_alignment_endpoints(raw)
        assert validate_analysis_result(mapped) is mapped
        assert mapped["alignment_segments"][-1]["reference_interval_ms"][1] == processed.metadata()["duration_ms"]
        assert mapped["events"] == raw["events"] == []
        assert mapped["status"] == raw["status"]
    assert raw == before


@pytest.mark.parametrize("engine", ENGINES)
@pytest.mark.parametrize("change", ["source_overrun", "processed_overrun"])
def test_result_contract_still_rejects_subsample_out_of_bounds_geometry(engine, change):
    audio = _audio(_signal(16000), 16000)
    valid = _analyze(engine, audio, audio)
    assert valid["status"] == "analyzed"
    forged = deepcopy(valid)
    last = forged["alignment_segments"][-1]
    if change == "source_overrun":
        last["reference_interval_ms"][1] = forged["reference"]["duration_ms"] + 0.001
        expected = "invalid_alignment_reference_interval"
    else:
        last["processed_offset_ms"] = (
            forged["processed"]["duration_ms"] - last["reference_interval_ms"][1] + 0.001
        )
        expected = "invalid_alignment_processed_interval"
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(forged)
    assert caught.value.code == expected
    # This small overrun is NOT the analysis ceil endpoint. Mapping must not
    # sanitize arbitrary almost-in-range geometry or a modified anchor offset.
    with pytest.raises(ResultContractError) as mapped_caught:
        validate_analysis_result(map_alignment_endpoints(forged))
    assert mapped_caught.value.code == expected


@pytest.mark.parametrize("engine", ENGINES)
@pytest.mark.parametrize("change", ["large_overrun", "negative_start", "changed_offset", "eight_k_no_padding"])
def test_mapper_does_not_repair_larger_or_unrelated_contract_failures(engine, change):
    rate = 8000 if change == "eight_k_no_padding" else 16000
    audio = _audio(_signal(rate), rate)
    valid = _analyze(engine, audio, audio)
    forged = deepcopy(valid)
    last = forged["alignment_segments"][-1]
    if change == "large_overrun":
        last["reference_interval_ms"][1] = forged["reference"]["duration_ms"] + 1.0
        expected = "invalid_alignment_reference_interval"
    elif change == "negative_start":
        last["reference_interval_ms"][0] = -0.001
        expected = "invalid_alignment_reference_interval"
    elif change == "changed_offset":
        last["processed_offset_ms"] = 1.0
        expected = "invalid_alignment_processed_interval"
    else:
        last["reference_interval_ms"][1] += 0.125
        expected = "invalid_alignment_reference_interval"
    before = deepcopy(forged)
    with pytest.raises(ResultContractError) as caught:
        map_alignment_endpoints(forged)
    assert caught.value.code == expected
    assert forged == before


@pytest.mark.parametrize("engine", ENGINES)
@pytest.mark.parametrize("operation", ["zero_dropout", "unrelated_replacement", "non_silent_tail_crop", "undeclared_resampling", "silence"])
def test_odd_length_unsupported_changes_remain_withheld(engine, operation):
    rate = 16000
    reference = _audio(_signal(rate), rate)
    processed_samples = reference.samples.copy()
    processed_rate = rate
    if operation == "zero_dropout":
        processed_samples[28000:34400] = 0
    elif operation == "unrelated_replacement":
        rng = np.random.default_rng(619073)
        processed_samples[28000:34400] = rng.uniform(-0.15, 0.15, 6400)
    elif operation == "non_silent_tail_crop":
        processed_samples = processed_samples[:-4800]
    elif operation == "undeclared_resampling":
        processed_samples = _resample(processed_samples, rate, 8000)
        processed_rate = 8000
    else:
        reference = _audio(np.zeros(5 * rate + 1), rate)
        processed_samples = reference.samples
    processed = _audio(processed_samples, processed_rate)
    result = _analyze(engine, reference, processed)
    assert result["status"] == "withheld"
    assert result["events"] is None
    assert "alignment_segments" not in result


@pytest.mark.parametrize("engine", ENGINES)
def test_trace_facade_uses_endpoint_mapping_without_changing_sidecar(tmp_path, engine):
    original = _signal(16000)
    reference_path, processed_path = tmp_path / "reference.wav", tmp_path / "processed.wav"
    reference_path.write_bytes(encode_wav(original, 16000))
    processed_path.write_bytes(encode_wav(np.concatenate([np.zeros(3840), original * 0.5]), 16000))
    reference, processed = _audio(original, 16000), _audio(np.concatenate([np.zeros(3840), original * 0.5]), 16000)
    if engine == "v1":
        raw_trace = None
    else:
        module = robust_engine if engine == "v2" else context_engine
        _, raw_trace = module.analyze_buffers_with_trace(reference, processed, EngineConfig(allow_gain=True))
    result, trace = api.analyze_pair_with_trace(reference_path, processed_path, engine=engine, allow_gain=True)
    assert validate_analysis_result(result) is result
    assert result["status"] == "analyzed"
    assert result["events"] == []
    assert trace == raw_trace
    assert result == api.analyze_pair(reference_path, processed_path, engine=engine, allow_gain=True)


@pytest.mark.parametrize("operation,expected_exit", [("identity", 0), ("delete", 0), ("dropout", 2)])
def test_general_analyze_cli_stores_only_contract_valid_endpoint_mapped_results(tmp_path, capsys, operation, expected_exit):
    original = _signal(16000)
    processed = original.copy()
    if operation == "delete":
        processed = np.concatenate([processed[:27200], processed[33600:]])
    elif operation == "dropout":
        processed[27200:33600] = 0
    reference_path, processed_path = tmp_path / "reference.wav", tmp_path / "processed.wav"
    reference_path.write_bytes(encode_wav(original, 16000))
    processed_path.write_bytes(encode_wav(processed, 16000))
    output = tmp_path / "result.json"
    assert cli.main(["analyze", "--reference", str(reference_path), "--processed", str(processed_path),
                     "--output", str(output)]) == expected_exit
    result = json.loads(capsys.readouterr().out)
    assert validate_analysis_result(result) is result
    assert result == json.loads(output.read_text(encoding="utf-8"))
    assert result["status"] == ("withheld" if operation == "dropout" else "analyzed")

