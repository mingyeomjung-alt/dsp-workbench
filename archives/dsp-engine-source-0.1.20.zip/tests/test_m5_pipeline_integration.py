"""Explicit candidate-chain integration; owned fixtures, not field accuracy."""

from copy import deepcopy
import json
from pathlib import Path

import numpy as np
import pytest
from scipy.signal import resample, resample_poly

from audio_regression.audio import decode_wav, encode_wav
from audio_regression.event_lineage import build_event_lineage, _mapped_query
from audio_regression.event_lineage_contract import validate_lineage_result
from audio_regression.fixtures import generate_case
from audio_regression.pipeline_cli import main
from audio_regression.pipeline_runner import PipelineRunError, run_pipeline
from audio_regression.pipeline_reporting import validate_pipeline_result, render_pipeline_html
from audio_regression.saved_pipeline import SavedPipelineError, audit_saved_pipeline, load_saved_manifest
from audio_regression import saved_pipeline as saved_runner
from audio_regression.saved_pipeline_contract import SavedPipelineContractError, validate_saved_pipeline_result
from audio_regression.saved_pipeline_reporting import render_saved_pipeline_html

MODEL = "scipy_fft_periodic_48k_16k_pcm16_postedit_v1"


def _manifest(root, stages, end, *, schema=2):
    value = {"schema_version": schema, "source": "source.wav", "stages": stages}
    if schema == 2:
        value["end_to_end"] = end
    path = root / "manifest.json"
    path.write_text(json.dumps(value), encoding="utf-8")
    return path


def _selection(engine="v11", resampling=False):
    value = {"engine": engine,
             "declaration": {"allow_gain": False, "allow_resampling": resampling}}
    if engine == "v12":
        value["declaration"]["resampling_model"] = MODEL
    return value


def _source(root, rate=16000):
    raw = generate_case(seed=202610159731, duration_seconds=5,
                        sample_rate_hz=rate).reference_wav
    (root / "source.wav").write_bytes(raw)
    return decode_wav(raw).samples


@pytest.mark.parametrize("engine", ["v10", "v11"])
def test_native_candidates_are_explicit_and_keep_sticky_review(tmp_path, engine):
    _source(tmp_path)
    result = run_pipeline(tmp_path / "source.wav", [
        {"kind": "split_join", "segment_ms": 200,
         "order": [i for i in range(25) if i != 10]},
        {"kind": "split_join", "segment_ms": 200}], tmp_path / "run", engine=engine)
    assert validate_pipeline_result(result) is result
    assert result["stages"][0]["analysis"]["events"][0]["type"] == "delete"
    assert result["stages"][1]["check"]["exit_code"] == 0
    assert result["summary"]["exit_code"] == 1
    assert result["summary"]["first_concern"]["stage_index"] == 1
    assert validate_lineage_result(build_event_lineage(result))["projection"]["summary"]["observed_event_count"] == 1
    assert "삭제" in render_pipeline_html(result)


def test_native_polyphase_runner_never_accepts_fft_v12_selection(tmp_path):
    with pytest.raises(PipelineRunError, match="invalid_engine"):
        run_pipeline(tmp_path / "missing.wav", [{"kind": "resample", "target_rate_hz": 16000}],
                     tmp_path / "run", engine="v12")
    assert not (tmp_path / "run").exists()


@pytest.mark.parametrize("engine", ["v10", "v11"])
def test_schema1_audit_supports_candidate_without_loosening_old_structure(tmp_path, engine):
    x = _source(tmp_path)
    (tmp_path / "out.wav").write_bytes(encode_wav(np.concatenate((x[:24000], x[25600:])), 16000))
    path = _manifest(tmp_path, [{"label": "native", "output": "out.wav",
        "declaration": {"allow_gain": False, "allow_resampling": False}}], None, schema=1)
    result = audit_saved_pipeline(path, tmp_path / "audit", engine=engine)
    assert validate_saved_pipeline_result(result) is result
    assert result["summary"]["exit_code"] == 1
    assert result["schema_version"] == 1 and "analysis_engine" not in result["stages"][0]
    assert validate_lineage_result(build_event_lineage(result))["projection"]["summary"]["observed_event_count"] == 1


def _mixed_chain(root, *, wrong_filter=False):
    x = _source(root, 48000)
    y = (resample_poly(x, 1, 3) if wrong_filter else resample(x, len(x) // 3))
    y = np.rint(y * 32768) / 32768
    (root / "resampled.wav").write_bytes(encode_wav(y, 16000))
    z = y[1600:]
    (root / "head.wav").write_bytes(encode_wav(z, 16000))
    stages = [{"label": "explicit periodic FFT", "output": "resampled.wav", **_selection("v12", True)},
              {"label": "head loss", "output": "head.wav", **_selection("v11")}]
    return _manifest(root, stages, _selection("v12", True))


def test_mixed_audit_has_explicit_stage_and_end_models_and_no_fake_anchor(tmp_path):
    result = audit_saved_pipeline(_mixed_chain(tmp_path), tmp_path / "audit")
    assert validate_saved_pipeline_result(result) is result
    assert result["schema_version"] == 2
    assert result["engine"] == "audio_saved_pipeline_audit_mixed_v1"
    assert [s["analysis_engine"] for s in result["stages"]] == ["v12", "v11"]
    assert result["stages"][0]["check"]["exit_code"] == 0
    assert result["stages"][0]["analysis"]["alignment_segments"] == []
    assert result["stages"][1]["analysis"]["events"][0]["location"] == "head"
    assert result["end_to_end"]["analysis_engine"] == "v12"
    assert result["end_to_end"]["analysis"]["proof_kind"] == "native_endpoint_loss"
    assert result["summary"]["exit_code"] == 1
    lineage = validate_lineage_result(build_event_lineage(result))
    event = lineage["projection"]["events"][0]
    assert event["source_projection"]["status"] == "unresolved"
    assert event["source_projection"]["reason_code"] == "unmapped_alignment_gap"
    assert event["final_projection"]["status"] == "mapped"
    assert MODEL in render_saved_pipeline_html(result)
    assert result["complete_audio_approval"] is False


def test_mixed_wrong_filter_stays_blocked_despite_later_exact_native_event(tmp_path):
    result = audit_saved_pipeline(_mixed_chain(tmp_path, wrong_filter=True), tmp_path / "audit")
    assert result["stages"][0]["status"] == "withheld"
    assert result["stages"][1]["status"] == "analyzed"
    assert result["end_to_end"]["status"] == "withheld"
    assert result["summary"]["exit_code"] == 2
    assert result["summary"]["first_concern"]["stage_index"] == 1
    validate_saved_pipeline_result(result)


@pytest.mark.parametrize("mutation", ["missing_model", "wrong_model", "extra_model_old_engine", "no_end", "global_engine"])
def test_mixed_manifest_bad_declarations_fail_without_output(tmp_path, mutation):
    path = _mixed_chain(tmp_path)
    value = json.loads(path.read_text(encoding="utf-8"))
    if mutation == "missing_model":
        value["stages"][0]["declaration"].pop("resampling_model")
    elif mutation == "wrong_model":
        value["stages"][0]["declaration"]["resampling_model"] = "guess_from_rate"
    elif mutation == "extra_model_old_engine":
        value["stages"][1]["declaration"]["resampling_model"] = MODEL
    elif mutation == "no_end":
        value.pop("end_to_end")
    path.write_text(json.dumps(value), encoding="utf-8")
    with pytest.raises(SavedPipelineError):
        audit_saved_pipeline(path, tmp_path / "audit", **({"engine": "v11"} if mutation == "global_engine" else {}))
    assert not (tmp_path / "audit").exists()


@pytest.mark.parametrize("mutation", ["stage_engine", "end_engine", "stage_model", "end_model", "drop_end_declaration", "summary"])
def test_mixed_saved_contract_rejects_relabeling_or_laundering(tmp_path, mutation):
    result = audit_saved_pipeline(_mixed_chain(tmp_path), tmp_path / "audit")
    broken = deepcopy(result)
    if mutation == "stage_engine":
        broken["stages"][0]["analysis_engine"] = "v11"
    elif mutation == "end_engine":
        broken["end_to_end"]["analysis_engine"] = "v11"
    elif mutation == "stage_model":
        broken["stages"][0]["declaration"]["resampling_model"] = "wrong"
    elif mutation == "end_model":
        broken["end_to_end"]["declaration"]["resampling_model"] = "wrong"
    elif mutation == "drop_end_declaration":
        broken["end_to_end"].pop("declaration")
    else:
        broken["summary"].update(exit_code=0, gate_state="clear_supported_temporal_check", first_concern=None)
    with pytest.raises(SavedPipelineContractError):
        validate_saved_pipeline_result(broken)


def test_endpoint_one_sided_evidence_projects_retained_region_without_keyerror(tmp_path):
    x = _source(tmp_path)
    (tmp_path / "head.wav").write_bytes(encode_wav(x[1600:], 16000))
    path = _manifest(tmp_path, [{"label": "head", "output": "head.wav", **_selection("v11")}], _selection("v11"))
    result = audit_saved_pipeline(path, tmp_path / "audit")
    analysis = result["stages"][0]["analysis"]
    query, reason = _mapped_query({"kind": "interval", "interval_ms": [200, 300]}, analysis, "forward")
    assert reason is None and query == {"kind": "interval", "interval_ms": [100, 200]}
    query, reason = _mapped_query({"kind": "interval", "interval_ms": [0, 50]}, analysis, "forward")
    assert query is None and reason == "unmapped_alignment_gap"


def test_cli_mixed_audit_and_inert_lineage_roundtrip(tmp_path, capsys):
    path = _mixed_chain(tmp_path)
    assert main(["audit", "--manifest", str(path), "--output-dir", str(tmp_path / "audit")]) == 1
    assert json.loads(capsys.readouterr().out)["engine"] == "audio_saved_pipeline_audit_mixed_v1"
    assert main(["lineage", "--input", str(tmp_path / "audit/audit_result.json"),
                 "--output", str(tmp_path / "lineage.json")]) == 0
    assert json.loads(capsys.readouterr().out)["generation_only_not_pipeline_pass"] is True
    assert main(["lineage-report", "--input", str(tmp_path / "lineage.json"),
                 "--output", str(tmp_path / "lineage.html")]) == 0
    capsys.readouterr()
    assert (tmp_path / "lineage.html").is_file()


def test_mixed_end_comparison_never_inherits_stage_resampling_permission(tmp_path):
    path = _mixed_chain(tmp_path)
    value = json.loads(path.read_text(encoding="utf-8"))
    value["end_to_end"] = _selection("v1", False)
    path.write_text(json.dumps(value), encoding="utf-8")
    result = audit_saved_pipeline(path, tmp_path / "audit")
    assert result["stages"][0]["status"] == "analyzed"
    assert result["end_to_end"]["analysis_engine"] == "v1"
    assert result["end_to_end"]["analysis"]["configuration"]["allow_resampling"] is False
    assert result["end_to_end"]["status"] == "withheld"
    assert result["summary"]["exit_code"] == 2
    validate_saved_pipeline_result(result)


def test_mixed_analysis_failure_preserves_not_run_stage_selection(tmp_path, monkeypatch):
    path = _mixed_chain(tmp_path)
    def fail(*args, **kwargs):
        raise RuntimeError("private path must not escape")
    monkeypatch.setattr(saved_runner, "_analysis", fail)
    result = audit_saved_pipeline(path, tmp_path / "audit")
    assert result["status"] == "incomplete" and result["summary"]["exit_code"] == 2
    assert result["stages"][0]["status"] == "error"
    assert result["stages"][1]["status"] == "not_run"
    assert result["stages"][1]["analysis_engine"] == "v11"
    assert result["end_to_end"] is None
    assert "private path" not in json.dumps(result)
    validate_saved_pipeline_result(result)


def test_mixed_snapshot_recheck_failure_keeps_explicit_end_selection(tmp_path, monkeypatch):
    path = _mixed_chain(tmp_path)
    monkeypatch.setattr(saved_runner, "_recheck", lambda *args, **kwargs:
                        {"status": "changed", "file_indices": [1]})
    result = audit_saved_pipeline(path, tmp_path / "audit")
    assert result["status"] == "incomplete" and result["summary"]["exit_code"] == 2
    assert result["end_to_end"]["analysis_engine"] == "v12"
    assert result["end_to_end"]["declaration"]["resampling_model"] == MODEL
    assert result["end_to_end"]["analysis"]["reason_code"] == "input_files_changed"
    validate_saved_pipeline_result(result)


def test_mixed_recheck_after_analysis_failure_records_selected_end(tmp_path, monkeypatch):
    path = _mixed_chain(tmp_path)
    monkeypatch.setattr(saved_runner, "_analysis", lambda *args, **kwargs: (_ for _ in ()).throw(RuntimeError()))
    monkeypatch.setattr(saved_runner, "_recheck", lambda *args, **kwargs:
                        {"status": "unavailable", "file_indices": [0]})
    result = audit_saved_pipeline(path, tmp_path / "audit")
    assert result["end_to_end"]["analysis_engine"] == "v12"
    assert result["end_to_end"]["analysis"]["reason_code"] == "input_files_recheck_failed"
    assert result["summary"]["exit_code"] == 2
    validate_saved_pipeline_result(result)


def test_new_schema_is_separate_from_frozen_M4_and_native_never_claims_v12():
    folder = Path(__file__).resolve().parents[1] / "src/audio_regression/schemas"
    old = json.loads((folder / "pipeline-event-lineage-v1.schema.json").read_text(encoding="utf-8"))
    new = json.loads((folder / "pipeline-event-lineage-integrated-v1.schema.json").read_text(encoding="utf-8"))
    assert old["$id"] != new["$id"]
    old_enum = old["$defs"]["projection"]["properties"]["input_pipeline_engine"]["enum"]
    new_enum = new["$defs"]["projection"]["properties"]["input_pipeline_engine"]["enum"]
    assert "audio_pipeline_regression_v10" not in old_enum
    assert {"audio_pipeline_regression_v10", "audio_pipeline_regression_v11",
            "audio_saved_pipeline_audit_mixed_v1"} <= set(new_enum)
    assert "audio_pipeline_regression_v12" not in new_enum
    assert new["$defs"]["mixedSource"]["properties"]["schema_version"] == {"const": 2}
    assert new["$defs"]["fftDeclaration"]["properties"]["resampling_model"] == {"const": MODEL}


def test_integrated_structural_schema_references_resolve_only_local_definitions():
    folder = Path(__file__).resolve().parents[1] / "src/audio_regression/schemas"
    def visit(node, origin):
        if isinstance(node, dict):
            if "$ref" in node:
                filename, fragment = node["$ref"].split("#", 1)
                target = json.loads((folder / filename).read_text(encoding="utf-8")) if filename else origin
                for component in fragment.lstrip("/").split("/"):
                    target = target[component]
            for child in node.values():
                visit(child, origin)
        elif isinstance(node, list):
            for child in node:
                visit(child, origin)
    for name in ("pipeline-event-lineage-integrated-v1.schema.json", "pipeline-result-candidates-v1.schema.json",
                 "saved-pipeline-result-integrated-v1.schema.json", "saved-pipeline-manifest-v2.schema.json"):
        schema = json.loads((folder / name).read_text(encoding="utf-8"))
        visit(schema, schema)
