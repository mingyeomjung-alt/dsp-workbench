"""Stored-diagnostic presentation/CLI checks, never detector accuracy."""
from copy import deepcopy
from html.parser import HTMLParser
import json

import pytest

from audio_regression.event_lineage import LineageError, build_event_lineage
from audio_regression.event_lineage_contract import load_lineage_result, validate_lineage_result
from audio_regression.event_lineage_reporting import render_event_lineage_html, write_event_lineage_html
from audio_regression.pipeline_cli import main
from test_pipeline_reporting import fixture as native_fixture
from test_saved_pipeline_reporting import fixture as saved_fixture, recheck_fixture


@pytest.mark.parametrize("factory,kind", [
    (native_fixture, "clean"), (native_fixture, "delete"), (native_fixture, "withheld"),
    (saved_fixture, "clean"), (saved_fixture, "delete"), (saved_fixture, "repeat"),
    (saved_fixture, "withheld"),
])
def test_report_preserves_gate_and_does_not_reanalyze(factory, kind, monkeypatch):
    from audio_regression import api, audio
    def forbidden(*args, **kwargs):
        raise AssertionError("A stored-result projection must not read or analyze WAV")
    monkeypatch.setattr(audio, "read_wav", forbidden)
    monkeypatch.setattr(api, "analyze_pair", forbidden)
    monkeypatch.setattr(api, "analyze_pair_with_trace", forbidden)
    source = factory(kind)
    before = deepcopy(source)
    value = build_event_lineage(source)
    assert source == before
    assert value["source_result"] == before
    html = render_event_lineage_html(value)
    assert html == render_event_lineage_html(value)
    assert "사건별 단계 좌표 추적" in html and "실제 원인 확정이 아닙니다" in html
    assert "진위 증명이 아닙니다" in html and "다시 분석하지 않습니다" in html
    assert value["projection"]["original_summary"] == source["summary"]
    if kind == "delete":
        assert "삭제된 입력 구간" in html and "출력의 대응 경계" in html
    elif kind == "repeat":
        assert "출력의 나중 추가 사본 구간" in html and "추적 미확정" in html


@pytest.mark.parametrize("status", ["changed", "unavailable"])
def test_failed_input_preservation_never_gets_mapped_report(status):
    source = recheck_fixture(status, "delete")
    value = build_event_lineage(source)
    assert value["projection"]["original_summary"]["gate_state"] == "blocked"
    event = value["projection"]["events"][0]
    assert event["source_projection"]["status"] == event["final_projection"]["status"] == "unresolved"
    html = render_event_lineage_html(value)
    assert "입력 보존 실패" in html and "추적 미확정" in html


def test_cli_creates_sidecar_then_report_without_changing_input(tmp_path, capsys):
    source = saved_fixture("delete")
    original, output, report = (tmp_path / name for name in ("audit.json", "lineage.json", "lineage.html"))
    original.write_text(json.dumps(source, ensure_ascii=False), encoding="utf-8")
    before = original.read_bytes()
    assert main(["lineage", "--input", str(original), "--output", str(output)]) == 0
    printed = json.loads(capsys.readouterr().out)
    assert printed["generation_only_not_pipeline_pass"] is True
    assert printed["original_exit_code"] == 1 and printed["original_gate_state"] == "review_required"
    value = load_lineage_result(output)
    assert validate_lineage_result(value) is value
    assert main(["lineage-report", "--input", str(output), "--output", str(report)]) == 0
    capsys.readouterr()
    saved = report.read_bytes()
    assert main(["lineage-report", "--input", str(output), "--output", str(report)]) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "output_exists"
    assert report.read_bytes() == saved and original.read_bytes() == before
    assert main(["lineage", "--input", str(original), "--output", str(output)]) == 3
    capsys.readouterr()
    assert main(["lineage", "--input", str(original), "--output", str(original)]) == 3
    assert original.read_bytes() == before


def test_cli_generated_report_does_not_clear_blocked_source(tmp_path, capsys):
    source = recheck_fixture("changed", "delete")
    original, output = tmp_path / "audit.json", tmp_path / "lineage.json"
    original.write_text(json.dumps(source), encoding="utf-8")
    assert main(["lineage", "--input", str(original), "--output", str(output)]) == 0
    printed = json.loads(capsys.readouterr().out)
    assert printed["original_gate_state"] == "blocked" and printed["original_exit_code"] == 2
    assert printed["complete_audio_approval"] is False


@pytest.mark.parametrize("command", ["lineage", "lineage-report"])
def test_invalid_cli_input_has_no_private_echo_or_created_output(tmp_path, capsys, command):
    original, output = tmp_path / "source.json", tmp_path / "out.json"
    original.write_text('{"private":"DO-NOT-ECHO-THIS"}', encoding="utf-8")
    assert main([command, "--input", str(original), "--output", str(output)]) == 3
    printed = capsys.readouterr().out
    assert "DO-NOT-ECHO-THIS" not in printed and str(tmp_path) not in printed
    assert not output.exists()


def test_report_is_inert_escaped_and_never_overwrites(tmp_path):
    source = saved_fixture("delete")
    source["stages"][0]["label"] = '<img src=x onerror="private">'
    source["summary"]["first_concern"]["stage_label"] = source["stages"][0]["label"]
    value = build_event_lineage(source)
    html = render_event_lineage_html(value)
    class Tags(HTMLParser):
        def __init__(self):
            super().__init__()
            self.tags = []
        def handle_starttag(self, tag, attrs):
            self.tags.append((tag, dict(attrs)))
    parsed = Tags()
    parsed.feed(html)
    assert not any(tag in {"script", "iframe", "audio", "video", "img", "link"} for tag, _ in parsed.tags)
    assert not any(any(name.startswith("on") for name in attrs) for _, attrs in parsed.tags)
    assert "&lt;img" in html and "Content-Security-Policy" in html
    report = tmp_path / "report.html"
    write_event_lineage_html(value, report)
    with pytest.raises(FileExistsError):
        write_event_lineage_html(value, report)
    assert report.read_text(encoding="utf-8") == html
