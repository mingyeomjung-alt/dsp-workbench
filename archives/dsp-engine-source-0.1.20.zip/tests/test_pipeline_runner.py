"""Fresh development pipelines; no locked evaluation corpus or detector edits."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import struct
from types import SimpleNamespace

import pytest

from audio_regression import pipeline_runner as runner
from audio_regression.audio import read_wav
from audio_regression.check_policy import check_result
from audio_regression.fixtures import generate_case
from audio_regression.pipeline_transforms import PipelineTransformError
from audio_regression.result_contract import load_analysis_result


@pytest.fixture
def source(tmp_path):
    path = tmp_path / "private-source-name.wav"
    path.write_bytes(generate_case("clean", seed=720120).reference_wav)
    return path


def _clear(reference, processed, **configuration):
    # This development artifact supplies the frozen contract, not new evidence.
    result = deepcopy(load_analysis_result(
        Path(__file__).resolve().parents[1]
        / "tests/fixtures/results/synthetic_basic_clean.json"))
    result.update(reference=read_wav(reference).metadata(),
                  processed=read_wav(processed).metadata(), configuration=configuration)
    return result


def _withheld(reference, processed, **configuration):
    result = _clear(reference, processed, **configuration)
    result.pop("alignment_segments")
    result.update(status="withheld", events=None, diagnostics={},
                  content_preservation_status="withheld", reason_code="ambiguous_alignment")
    return result


def _assert_claims(result):
    from audio_regression.pipeline_reporting import validate_pipeline_result

    for field in ("complete_audio_approval", "commercial_performance_validated",
                  "network_used", "fault_provenance_confirmed"):
        assert result[field] is False
    assert result["schema_version"] == 1
    assert result["engine"] == "audio_pipeline_regression_v1"
    assert result["comparison_scope"] == "adjacent_stage_checks_and_end_to_end"
    assert result["summary"]["exit_code"] == {
        "clear_supported_temporal_check": 0, "review_required": 1, "blocked": 2
    }[result["summary"]["gate_state"]]
    assert validate_pipeline_result(result) is result


def test_actual_fresh_dsp_pipeline_preserves_original_and_saved_chain(source, tmp_path):
    original = source.read_bytes()
    stages = [{"kind": "gain", "gain_db": -3, "label": "local gain"},
              {"kind": "split_join", "segment_ms": 400},
              {"kind": "resample", "target_rate_hz": 8000}]
    before = deepcopy(stages)
    output = tmp_path / "new" / "run"
    result = runner.run_pipeline(source, stages, output)
    assert result["status"] == "completed"
    assert result["summary"] == {
        "gate_state": "clear_supported_temporal_check", "exit_code": 0,
        "first_concern": None, "planned_stage_count": 3,
        "executed_stage_count": 3, "failed_stage": None}
    assert source.read_bytes() == original == (output / "input/source.wav").read_bytes()
    assert result["source"]["sha256"] == hashlib.sha256(original).hexdigest()
    assert stages == before
    previous = result["source"]
    for index, stage in enumerate(result["stages"], 1):
        assert stage["index"] == index
        assert stage["input"] == previous == stage["analysis"]["reference"]
        assert stage["output"] == stage["analysis"]["processed"]
        assert stage["output"] == read_wav(output / stage["output_snapshot"]).metadata()
        assert stage["check"] == check_result(stage["analysis"])
        assert stage["reason_code"] is None
        assert stage["runtime_ms"] >= 0
        for field in ("analysis_artifact", "check_artifact"):
            assert (output / stage[field]).is_file()
        previous = stage["output"]
    assert result["end_to_end"]["analysis"]["configuration"] == {
        "profile": "basic", "allow_gain": True,
        "allow_resampling": True, "max_delay_ms": 1000.0}
    assert json.loads((output / "run_result.json").read_text("utf-8")) == result
    assert source.name not in (output / "run_result.json").read_text("utf-8")
    assert str(source) not in (output / "manifest_started.json").read_text("utf-8")
    _assert_claims(result)


def test_actual_missing_chunk_candidate_stays_after_later_normal_stage(source, tmp_path):
    order = [index for index in range(15) if index != 5]
    result = runner.run_pipeline(source, [
        {"kind": "split_join", "segment_ms": 400, "order": order, "label": "assembly"},
        {"kind": "gain", "gain_db": 0, "label": "later normal"}], tmp_path / "candidate")
    assert result["stages"][0]["check"]["gate_state"] == "review_required"
    assert result["stages"][1]["check"]["gate_state"] == "clear_supported_temporal_check"
    assert result["status"] == "completed"
    assert result["summary"]["gate_state"] == "review_required"
    assert result["summary"]["first_concern"] == {
        "scope": "stage", "stage_index": 1, "stage_label": "assembly",
        "category": "defect_candidates"}
    _assert_claims(result)


def test_withheld_is_sticky_and_does_not_stop_following_stage(source, tmp_path, monkeypatch):
    calls = []

    def compare(reference, processed, **configuration):
        calls.append(configuration)
        return (_withheld if len(calls) == 1 else _clear)(reference, processed, **configuration)

    monkeypatch.setattr(runner.api, "analyze_pair", compare)
    result = runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0},
                                          {"kind": "split_join", "segment_ms": 400}], tmp_path / "held")
    assert len(calls) == 3
    assert [stage["status"] for stage in result["stages"]] == ["withheld", "analyzed"]
    assert result["status"] == "completed"
    assert result["summary"]["gate_state"] == "blocked"
    assert result["summary"]["first_concern"]["category"] == "withheld"
    assert result["summary"]["failed_stage"] is None
    _assert_claims(result)


def test_end_to_end_only_execution_failure_never_assigns_a_stage(source, tmp_path, monkeypatch):
    count = 0

    def compare(reference, processed, **configuration):
        nonlocal count
        count += 1
        if count == 3:
            raise RuntimeError("Private C:/sensitive/path.wav")
        return _clear(reference, processed, **configuration)

    monkeypatch.setattr(runner.api, "analyze_pair", compare)
    output = tmp_path / "end_failure"
    result = runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0},
                                          {"kind": "split_join", "segment_ms": 400}], output)
    assert result["status"] == "incomplete"
    assert all(stage["status"] == "analyzed" for stage in result["stages"])
    assert result["summary"]["gate_state"] == "blocked"
    assert result["summary"]["failed_stage"] is None
    assert result["summary"]["first_concern"] == {
        "scope": "end_to_end", "stage_index": None, "stage_label": None,
        "category": "execution_error"}
    assert result["end_to_end"]["analysis"] == {
        "schema_version": 1, "status": "error", "reason_code": "analysis_execution_error"}
    assert "sensitive" not in (output / "run_result.json").read_text("utf-8")
    _assert_claims(result)


def test_end_to_end_only_withheld_completes_but_blocks(source, tmp_path, monkeypatch):
    count = 0

    def compare(reference, processed, **configuration):
        nonlocal count
        count += 1
        return (_withheld if count == 2 else _clear)(reference, processed, **configuration)

    monkeypatch.setattr(runner.api, "analyze_pair", compare)
    result = runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], tmp_path / "end_held")
    assert result["status"] == "completed"
    assert result["summary"]["exit_code"] == 2
    assert result["summary"]["first_concern"] == {
        "scope": "end_to_end", "stage_index": None, "stage_label": None, "category": "withheld"}
    _assert_claims(result)


def test_input_dependent_transform_failure_keeps_partial_results_and_not_run(source, tmp_path, monkeypatch):
    monkeypatch.setattr(runner.api, "analyze_pair", _clear)
    output = tmp_path / "partial"
    result = runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0},
        {"kind": "split_join", "segment_ms": 400, "order": [100], "label": "failed assembly"},
        {"kind": "gain", "gain_db": -3}], output)
    first, failed, later = result["stages"]
    assert [stage["status"] for stage in result["stages"]] == ["analyzed", "error", "not_run"]
    assert failed["reason_code"] == "invalid_order"
    assert failed["output"] is failed["output_snapshot"] is None
    assert failed["analysis"] == {"schema_version": 1, "status": "error", "reason_code": "invalid_order"}
    assert failed["check"] == check_result(failed["analysis"])
    assert (output / failed["analysis_artifact"]).is_file()
    assert later["input"] == first["output"]
    assert later["input_snapshot"] == first["output_snapshot"]
    assert later["analysis"] is later["check"] is later["output"] is None
    assert later["runtime_ms"] == 0
    assert not (output / "stages/003").exists()
    assert result["end_to_end"] is None
    assert result["summary"]["executed_stage_count"] == 2
    assert result["summary"]["failed_stage"] == 2
    assert result["summary"]["first_concern"]["stage_index"] == 2
    _assert_claims(result)


@pytest.mark.parametrize("failure", [RuntimeError("private-path-name"),
                                     PipelineTransformError("invalid_duration"),
                                     PipelineTransformError("C:/private/file.wav")])
def test_transform_exceptions_are_stable_private_free_errors(source, tmp_path, monkeypatch, failure):
    def fail(*args):
        raise failure

    monkeypatch.setattr(runner.pipeline_transforms, "execute_stage", fail)
    result = runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], tmp_path / "error")
    expected = "invalid_duration" if getattr(failure, "code", None) == "invalid_duration" else "transform_execution_error"
    assert result["stages"][0]["reason_code"] == expected
    assert result["summary"]["exit_code"] == 2
    assert result["status"] == "incomplete"


@pytest.mark.parametrize("analysis_failure", ["raise", "invalid", "error"])
def test_analyzer_failure_stops_chain_and_keeps_transformed_output(source, tmp_path, monkeypatch, analysis_failure):
    def compare(*args, **kwargs):
        if analysis_failure == "raise":
            raise RuntimeError("Sensitive exception and path")
        if analysis_failure == "invalid":
            return {"schema_version": 1, "status": "analyzed"}
        return {"schema_version": 1, "status": "error", "reason_code": "analysis_execution_error"}

    monkeypatch.setattr(runner.api, "analyze_pair", compare)
    output = tmp_path / "analyzer_error"
    result = runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0},
                                          {"kind": "split_join", "segment_ms": 400}], output)
    failed, unrun = result["stages"]
    assert failed["status"] == "error"
    assert failed["output"] is not None
    assert (output / failed["output_snapshot"]).is_file()
    assert unrun["status"] == "not_run"
    assert unrun["input"] == failed["output"]
    assert result["summary"]["first_concern"]["category"] == "execution_error"
    assert result["status"] == "incomplete"
    assert result["end_to_end"] is None


def test_analyzer_receives_only_declarations_not_labels_or_assembly_order(source, tmp_path, monkeypatch):
    seen = []

    def compare(reference, processed, **configuration):
        seen.append((Path(reference).relative_to(output).as_posix(),
                     Path(processed).relative_to(output).as_posix(), configuration))
        return _clear(reference, processed, **configuration)

    monkeypatch.setattr(runner.api, "analyze_pair", compare)
    output = tmp_path / "only-declarations"
    runner.run_pipeline(source, [
        {"kind": "gain", "gain_db": 0, "label": "<script>private label</script>"},
        {"kind": "split_join", "segment_ms": 400, "order": list(range(15))}], output)
    assert [item[:2] for item in seen] == [
        ("input/source.wav", "stages/001/output.wav"),
        ("stages/001/output.wav", "stages/002/output.wav"),
        ("input/source.wav", "stages/002/output.wav")]
    assert all(set(item[2]) == {"profile", "allow_gain", "allow_resampling", "max_delay_ms"} for item in seen)
    assert seen[0][2]["allow_gain"] is True
    assert seen[1][2]["allow_gain"] is False
    assert seen[2][2]["allow_gain"] is True
    assert (output / "stages/001/output.wav").exists()
    assert not any("script" in path.name for path in output.rglob("*"))


def test_exact_riff_container_snapshot_keeps_unknown_chunk(source, tmp_path, monkeypatch):
    raw = source.read_bytes() + b"JUNK" + struct.pack("<I", 3) + b"abc\0"
    raw = raw[:4] + struct.pack("<I", len(raw) - 8) + raw[8:]
    source.write_bytes(raw)
    monkeypatch.setattr(runner.api, "analyze_pair", _clear)
    output = tmp_path / "container"
    result = runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], output)
    assert source.read_bytes() == raw == (output / "input/source.wav").read_bytes()
    assert result["source"]["sha256"] == hashlib.sha256(raw).hexdigest()
    assert result["stages"][0]["output"]["sha256"] != result["source"]["sha256"]


def test_source_change_at_finish_is_blocked_without_restoration(source, tmp_path, monkeypatch):
    raw = source.read_bytes()
    count = 0

    def compare(reference, processed, **configuration):
        nonlocal count
        count += 1
        result = _clear(reference, processed, **configuration)
        if count == 2:
            source.write_bytes(b"changed by external process")
        return result

    monkeypatch.setattr(runner.api, "analyze_pair", compare)
    output = tmp_path / "changed"
    result = runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], output)
    assert source.read_bytes() == b"changed by external process"
    assert (output / "input/source.wav").read_bytes() == raw
    assert result["status"] == "incomplete"
    assert result["summary"]["exit_code"] == 2
    assert result["summary"]["first_concern"]["scope"] == "end_to_end"
    assert result["summary"]["first_concern"]["stage_index"] is None
    assert result["end_to_end"]["analysis"]["reason_code"] == "source_changed_during_run"
    assert result["end_to_end"]["analysis_artifact"] == "end_to_end/error.json"
    assert (output / "end_to_end/analysis.json").is_file()
    _assert_claims(result)


@pytest.mark.parametrize("stages", [[], [{}] * 9, [{"kind": "command", "command": "anything"}],
                                     [{"kind": "gain", "gain_db": True}],
                                     [{"kind": "gain", "gain_db": 0}, {"kind": "unknown"}]])
def test_all_stage_preflight_rejections_create_no_outputs(source, tmp_path, stages):
    output = tmp_path / "absent" / "invalid"
    with pytest.raises(runner.PipelineRunError):
        runner.run_pipeline(source, stages, output)
    assert not output.parent.exists()


@pytest.mark.parametrize("kind", ["missing", "malformed", "oversized"])
def test_source_preflight_rejections_create_no_outputs(tmp_path, kind):
    source = tmp_path / "bad.wav"
    if kind == "malformed":
        source.write_bytes(b"not wav")
    elif kind == "oversized":
        source.write_bytes(b"\0" * 10_000_001)
    output = tmp_path / "absent" / "run"
    with pytest.raises(runner.PipelineRunError):
        runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], output)
    assert not output.parent.exists()


def test_existing_output_and_input_alias_are_never_overwritten(source, tmp_path):
    output = tmp_path / "existing"
    output.mkdir()
    marker = output / "evidence.txt"
    marker.write_text("preserve", encoding="utf-8")
    raw = source.read_bytes()
    with pytest.raises(runner.PipelineRunError, match="output_directory_exists"):
        runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], output)
    with pytest.raises(runner.PipelineRunError, match="input_output_alias"):
        runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], source)
    assert marker.read_text("utf-8") == "preserve"
    assert source.read_bytes() == raw


@pytest.mark.parametrize("dangling", [False, True])
def test_output_symlink_and_dangling_symlink_are_rejected(source, tmp_path, dangling):
    target = tmp_path / "target"
    if not dangling:
        target.mkdir()
    output = tmp_path / "linked"
    try:
        output.symlink_to(target, target_is_directory=True)
    except OSError:
        pytest.skip("This Windows account cannot create directory symlinks")
    with pytest.raises(runner.PipelineRunError, match="output_directory_exists"):
        runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], output)
    assert output.is_symlink()


def test_linked_output_parent_is_rejected(source, tmp_path):
    target = tmp_path / "target"
    target.mkdir()
    parent = tmp_path / "linked-parent"
    try:
        parent.symlink_to(target, target_is_directory=True)
    except OSError:
        pytest.skip("This Windows account cannot create directory symlinks")
    with pytest.raises(runner.PipelineRunError, match="unsafe_output_parent"):
        runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], parent / "output")
    assert list(target.iterdir()) == []


def test_stage_write_failure_preserves_started_manifest_and_journal(source, tmp_path, monkeypatch):
    original_writer = runner._new_bytes

    def writer(path, raw):
        if path.name == "output.wav":
            raise runner.PipelineRunError("output_write_error")
        return original_writer(path, raw)

    monkeypatch.setattr(runner, "_new_bytes", writer)
    output = tmp_path / "disk-failure"
    result = runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0},
                                          {"kind": "split_join", "segment_ms": 400}], output)
    assert result["status"] == "incomplete"
    assert result["summary"]["exit_code"] == 2
    assert [stage["status"] for stage in result["stages"]] == ["error", "not_run"]
    assert (output / "manifest_started.json").is_file()
    events = [json.loads(line) for line in (output / "execution.jsonl").read_text("utf-8").splitlines()]
    assert events[-1]["gate_state"] == "blocked"
    assert result["stages"][0]["reason_code"] == "output_write_error"
    _assert_claims(result)


def test_result_file_write_failure_raises_and_retains_partial_evidence(source, tmp_path, monkeypatch):
    monkeypatch.setattr(runner.api, "analyze_pair", _clear)
    original_writer = runner._new_json

    def writer(path, value):
        if path.name == "run_result.json":
            raise runner.PipelineRunError("output_write_error")
        return original_writer(path, value)

    monkeypatch.setattr(runner, "_new_json", writer)
    output = tmp_path / "result-disk-failure"
    with pytest.raises(runner.PipelineRunError, match="output_write_error"):
        runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], output)
    assert (output / "manifest_started.json").is_file()
    assert (output / "execution.jsonl").is_file()
    assert (output / "stages/001/output.wav").is_file()
    assert not (output / "run_result.json").exists()
    last_event = json.loads((output / "execution.jsonl").read_text("utf-8").splitlines()[-1])
    assert last_event["event"] == "run_failed"
    assert last_event["gate_state"] == "blocked"


def test_nonclear_analysis_then_artifact_failure_has_a_coherent_error_result(source, tmp_path, monkeypatch):
    from audio_regression.pipeline_reporting import validate_pipeline_result

    monkeypatch.setattr(runner.api, "analyze_pair", _withheld)
    original_writer = runner._new_json

    def writer(path, value):
        if path.name == "analysis.json":
            raise runner.PipelineRunError("output_write_error")
        return original_writer(path, value)

    monkeypatch.setattr(runner, "_new_json", writer)
    result = runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], tmp_path / "artifact-error")
    assert result["summary"]["first_concern"]["category"] == "execution_error"
    assert result["stages"][0]["reason_code"] == "output_write_error"
    assert validate_pipeline_result(result) is result


def test_missing_error_artifacts_are_null_and_still_fail_closed(source, tmp_path, monkeypatch):
    from audio_regression.pipeline_reporting import validate_pipeline_result

    original_writer = runner._new_json

    def writer(path, value):
        if path.name in {"error.json", "error_check.json"}:
            raise runner.PipelineRunError("output_write_error")
        return original_writer(path, value)

    monkeypatch.setattr(runner, "_new_json", writer)
    result = runner.run_pipeline(source, [{"kind": "split_join", "segment_ms": 400,
                                          "order": [100]}], tmp_path / "missing-error-artifacts")
    assert result["stages"][0]["analysis_artifact"] is None
    assert result["stages"][0]["check_artifact"] is None
    assert result["summary"]["exit_code"] == 2
    assert validate_pipeline_result(result) is result


def test_source_change_after_stage_failure_keeps_earliest_stage_concern(source, tmp_path, monkeypatch):
    from audio_regression.pipeline_reporting import validate_pipeline_result

    original = source.read_bytes()

    def fail(*args):
        source.write_bytes(b"external change")
        raise PipelineTransformError("invalid_samples")

    monkeypatch.setattr(runner.pipeline_transforms, "execute_stage", fail)
    output = tmp_path / "failed-and-changed"
    result = runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0},
                                          {"kind": "split_join", "segment_ms": 400}], output)
    assert result["summary"]["first_concern"]["stage_index"] == 1
    assert result["summary"]["failed_stage"] == 1
    assert result["end_to_end"]["analysis"]["reason_code"] == "source_changed_during_run"
    assert source.read_bytes() == b"external change"
    assert (output / "input/source.wav").read_bytes() == original
    assert validate_pipeline_result(result) is result


def test_source_change_between_preflight_reads_creates_no_outputs(source, tmp_path, monkeypatch):
    original_reader = runner._bounded_bytes

    def reader(path):
        source.write_bytes(b"external change")
        return original_reader(path)

    monkeypatch.setattr(runner, "_bounded_bytes", reader)
    output = tmp_path / "preflight-change"
    with pytest.raises(runner.PipelineRunError, match="source_changed_during_preflight"):
        runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], output)
    assert not output.exists()


def test_simulated_windows_reparse_parent_is_rejected(source, tmp_path, monkeypatch):
    parent = tmp_path / "junction-parent"
    parent.mkdir()
    original_lstat = Path.lstat

    def lstat(path, *args, **kwargs):
        info = original_lstat(path, *args, **kwargs)
        if path == parent:
            return SimpleNamespace(st_mode=info.st_mode, st_file_attributes=0x400)
        return info

    monkeypatch.setattr(Path, "lstat", lstat)
    with pytest.raises(runner.PipelineRunError, match="unsafe_output_parent"):
        runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], parent / "run")
    assert list(parent.iterdir()) == []


def test_invalid_declaration_cannot_smuggle_options_to_analyzer(source, tmp_path, monkeypatch):
    original_execute = runner.pipeline_transforms.execute_stage

    def execute(audio, spec):
        wav, info = original_execute(audio, spec)
        info["declared_comparison"]["expected_events"] = []
        return wav, info

    def must_not_analyze(*args, **kwargs):
        pytest.fail("Invalid declaration reached analyzer")

    monkeypatch.setattr(runner.pipeline_transforms, "execute_stage", execute)
    monkeypatch.setattr(runner.api, "analyze_pair", must_not_analyze)
    result = runner.run_pipeline(source, [{"kind": "gain", "gain_db": 0}], tmp_path / "bad-declaration")
    assert result["stages"][0]["reason_code"] == "invalid_transform_result"
    assert result["summary"]["exit_code"] == 2


@pytest.mark.parametrize("raw,code", [
    (b'{"schema_version":1,"schema_version":1,"stages":[]}', "duplicate_json_key"),
    (b'{"schema_version":1,"stages":[{"kind":"gain","gain_db":0,"gain_db":1}]}', "duplicate_json_key"),
    (b'{"schema_version":1,"stages":[{"kind":"gain","gain_db":NaN}]}', "non_finite_metric"),
    (b'{"schema_version":1,"stages":[{"kind":"gain","gain_db":Infinity}]}', "non_finite_metric"),
    (b'{"schema_version":true,"stages":[]}', "invalid_pipeline_plan"),
    (b'{"schema_version":1,"stages":[],"command":"anything"}', "invalid_pipeline_plan"),
    (b'\xff', "invalid_plan_json"),
    (b'\xef\xbb\xbf{}', "invalid_plan_json"),
    (b'{}', "invalid_pipeline_plan"),
    (b' ' * (runner.MAX_PLAN_BYTES + 1), "plan_file_too_large"),
], ids=["duplicate-top-key", "duplicate-stage-key", "nan", "infinity", "boolean-version",
        "extra-command", "invalid-utf8", "bom", "missing-fields", "oversized"])
def test_strict_bounded_plan_loading(tmp_path, raw, code):
    path = tmp_path / "plan.json"
    path.write_bytes(raw)
    with pytest.raises(runner.PipelineRunError) as failure:
        runner.load_pipeline_plan(path)
    assert failure.value.code == code
    assert str(path) not in str(failure.value)


def test_plan_loading_normalizes_safe_specs_without_output(tmp_path):
    path = tmp_path / "plan.json"
    path.write_text(json.dumps({"schema_version": 1, "stages": [
        {"kind": "gain", "gain_db": -3, "label": "gain"},
        {"kind": "split_join", "segment_ms": 400, "order": [0, 1, 2]}]}), encoding="utf-8")
    result = runner.load_pipeline_plan(path)
    assert result["schema_version"] == 1
    assert type(result["stages"][0]["gain_db"]) is float
    assert result["stages"][1]["order"] == [0, 1, 2]
    assert list(tmp_path.iterdir()) == [path]


def test_missing_plan_has_stable_code(tmp_path):
    with pytest.raises(runner.PipelineRunError) as failure:
        runner.load_pipeline_plan(tmp_path / "private-plan.json")
    assert failure.value.code == "plan_file_read_error"
