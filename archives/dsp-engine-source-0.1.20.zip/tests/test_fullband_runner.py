"""Fresh native-rate file measurements; no old audio or approval policy changes."""
import json
from pathlib import Path
from types import SimpleNamespace
import stat

import numpy as np
import pytest

from audio_regression import api
from audio_regression.audio import encode_wav
from audio_regression.check_policy import check_result
from audio_regression.fullband_contract import validate_fullband_result
from audio_regression.fullband_runner import FullbandRunError, run_fullband_measurement


def _pair(tmp_path, rate=8000, change=None):
    rng = np.random.default_rng(2026101459417)
    pcm = rng.integers(-3000, 3001, rate * 2 + 17)
    altered = pcm.copy()
    if change == "one_sample":
        altered[-1] += 1
    elif change == "length":
        altered = altered[:-1]
    left, right = tmp_path / "reference.wav", tmp_path / "processed.wav"
    left.write_bytes(encode_wav(pcm / 32768, rate))
    right.write_bytes(encode_wav(altered / 32768, rate))
    return left, right


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
def test_native_measurements_retain_original_geometry_and_last_partial(tmp_path, rate):
    left, right = _pair(tmp_path, rate)
    before = (left.read_bytes(), right.read_bytes())
    folder = tmp_path / "new_measurement"
    result = run_fullband_measurement(left, right, folder)
    assert validate_fullband_result(result) is result
    assert result["summary"]["exit_code"] == 0
    assert result["summary"]["quality_verdict"] == "not_assessed"
    assert result["reference"]["sample_rate_hz"] == rate
    assert result["reference_measurements"]["frames"][-1]["end_sample"] == rate * 2 + 17
    assert result["comparison"]["unequal_sample_count"] == 0
    assert before == (left.read_bytes(), right.read_bytes())
    assert json.loads((folder / "fullband_result.json").read_text(encoding="utf-8")) == result
    assert (folder / "input/reference.wav").read_bytes() == before[0]


def test_one_lsb_change_is_measured_not_approved_or_given_a_defect_gate(tmp_path):
    left, right = _pair(tmp_path, change="one_sample")
    result = run_fullband_measurement(left, right, tmp_path / "run")
    assert result["comparison"]["unequal_sample_count"] == 1
    assert result["comparison"]["maximum_abs_error_pcm16"] == 1
    assert result["comparison"]["first_changed_sample"] == result["reference"]["sample_count"] - 1
    assert result["comparison"]["changed_frames"][-1]["unequal_sample_count"] == 1
    assert result["summary"] == {"exit_code": 0, "meaning": "measurement_completed_no_quality_verdict",
                                  "quality_verdict": "not_assessed"}
    assert result["complete_audio_approval"] is False
    # The old diagnostic gate rejects this new measurement envelope, never
    # treating a measurement exit code as a temporal approval.
    assert check_result(result)["exit_code"] == 2


@pytest.mark.parametrize("kind", ["length", "rate"])
def test_incomparable_pair_still_measures_both_files(tmp_path, kind):
    left, right = _pair(tmp_path, change="length" if kind == "length" else None)
    if kind == "rate":
        right.write_bytes(encode_wav(np.zeros(32000), 16000))
    result = run_fullband_measurement(left, right, tmp_path / "run")
    assert result["status"] == "comparison_withheld"
    assert result["reason_code"] == ("sample_rate_mismatch" if kind == "rate" else "sample_count_mismatch")
    assert result["summary"]["exit_code"] == 2
    assert result["reference_measurements"]["frames"]
    assert result["processed_measurements"]["frames"]
    assert result["comparison"]["residual_bands"] is None
    assert result["comparison"]["changed_frames"] is None


def test_no_old_analysis_or_model_engine_is_called(tmp_path, monkeypatch):
    from audio_regression import transform_models
    def forbidden(*args, **kwargs):
        pytest.fail("Original-rate measurements must not call old detector/model rendering")
    monkeypatch.setattr(api, "analyze_pair", forbidden)
    monkeypatch.setattr(api, "analyze_pair_with_trace", forbidden)
    monkeypatch.setattr(transform_models, "render_models", forbidden)
    left, right = _pair(tmp_path)
    result = run_fullband_measurement(left, right, tmp_path / "run")
    assert result["summary"]["exit_code"] == 0


def test_invalid_audio_and_occupied_destinations_preserved(tmp_path):
    left, right = _pair(tmp_path)
    before = left.read_bytes()
    with pytest.raises(FullbandRunError, match="output_directory_exists"):
        run_fullband_measurement(left, right, left)
    assert left.read_bytes() == before
    occupied = tmp_path / "occupied"
    occupied.mkdir()
    sentinel = occupied / "sentinel"
    sentinel.write_bytes(b"preserve")
    with pytest.raises(FullbandRunError):
        run_fullband_measurement(left, right, occupied)
    assert sentinel.read_bytes() == b"preserve"
    right.write_bytes(b"invalid")
    with pytest.raises(FullbandRunError) as caught:
        run_fullband_measurement(left, right, tmp_path / "new")
    assert str(right) not in str(caught.value)
    assert not (tmp_path / "new").exists()


@pytest.mark.parametrize("target", ["reference", "processed"])
def test_named_input_change_during_measurement_never_returns_completion(tmp_path, monkeypatch, target):
    from audio_regression import fullband_runner
    left, right = _pair(tmp_path)
    real = fullband_runner.measure_pair
    def mutate(*args):
        result = real(*args)
        (left if target == "reference" else right).write_bytes(b"changed")
        return result
    monkeypatch.setattr(fullband_runner, "measure_pair", mutate)
    folder = tmp_path / "run"
    with pytest.raises(FullbandRunError, match="fullband_input_or_snapshot_changed_during_run"):
        run_fullband_measurement(left, right, folder)
    assert not (folder / "fullband_result.json").exists()
    assert (folder / "manifest_started.json").exists()
    assert json.loads((folder / "run_failed.json").read_text())["quality_verdict"] == "not_assessed"


@pytest.mark.parametrize("target", ["reference", "processed", "reference_snapshot", "processed_snapshot"])
def test_same_bytes_reparse_changes_after_snapshot_are_rejected(tmp_path, monkeypatch, target):
    from audio_regression import fullband_runner
    left, right = _pair(tmp_path)
    folder = tmp_path / "run"
    real_write, real_lstat = fullband_runner._new_bytes, Path.lstat
    changed = {"path": None}
    def mark(path, raw):
        real_write(path, raw)
        if path == folder / "input/processed.wav":
            changed["path"] = {"reference": left, "processed": right,
                               "reference_snapshot": folder / "input/reference.wav",
                               "processed_snapshot": folder / "input/processed.wav"}[target]
    def fake_lstat(path):
        if path == changed["path"]:
            return SimpleNamespace(st_mode=stat.S_IFREG, st_file_attributes=0x400)
        return real_lstat(path)
    monkeypatch.setattr(fullband_runner, "_new_bytes", mark)
    monkeypatch.setattr(Path, "lstat", fake_lstat)
    with pytest.raises(FullbandRunError, match="invalid_fullband_input_file"):
        run_fullband_measurement(left, right, folder)
    assert not (folder / "fullband_result.json").exists()


def test_maximum_length_native_high_rate_json_is_bounded(tmp_path):
    data = np.tile(np.array([1000, -1000, 2000, -2000]) / 32768, 48000 * 30 // 4)
    left, right = tmp_path / "max_ref.wav", tmp_path / "max_out.wav"
    left.write_bytes(encode_wav(data, 48000))
    right.write_bytes(left.read_bytes())
    result = run_fullband_measurement(left, right, tmp_path / "run")
    assert len(result["reference_measurements"]["frames"]) == 300
    assert len(json.dumps(result, allow_nan=False).encode("utf-8")) < 1048576
    assert result["comparison"]["unequal_sample_count"] == 0


def test_cli_unexpected_exception_does_not_reveal_internal_details(tmp_path, monkeypatch, capsys):
    from audio_regression import fullband_cli
    def broken(*args):
        raise KeyError("C:/private-source/example-sensitive-path")
    monkeypatch.setattr(fullband_cli, "run_fullband_measurement", broken)
    code = fullband_cli.main(["measure", "--reference", str(tmp_path / "a.wav"),
                             "--processed", str(tmp_path / "b.wav"),
                             "--output-dir", str(tmp_path / "new")])
    text = capsys.readouterr().out
    result = json.loads(text)
    assert code == 3 and result["reason_code"] == "fullband_internal_error"
    assert "private-source" not in text and "Traceback" not in text
    assert result["quality_verdict"] == "not_assessed"
