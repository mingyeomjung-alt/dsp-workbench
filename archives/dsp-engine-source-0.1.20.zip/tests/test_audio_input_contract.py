"""Direct PCM16 contract regressions using new in-memory signals only."""

import hashlib
import struct

import numpy as np
import pytest

from audio_regression.audio import AudioInputError, WavAudio, decode_wav, encode_wav


@pytest.mark.parametrize("sample", [0.123456, 1.0, 1 / 65536, -1 / 65536])
def test_non_pcm16_direct_values_are_rejected_without_mutation(sample):
    values = np.zeros(16000)
    values[19] = sample
    original = values.copy()
    with pytest.raises(AudioInputError) as caught:
        WavAudio(values, 8000, "0" * 64)
    assert caught.value.code == "non_pcm16_samples"
    np.testing.assert_array_equal(values, original)


@pytest.mark.parametrize("values", [
    np.full(16000, True), np.full(16000, "0"),
    np.full(16000, 0, dtype=object), np.full(16000, 0j),
])
def test_non_numeric_or_non_real_dtype_is_not_treated_as_pcm16(values):
    with pytest.raises(AudioInputError) as caught:
        WavAudio(values, 8000, "0" * 64)
    assert caught.value.code == "invalid_samples"


@pytest.mark.parametrize("digest", [
    None, 0, b"0" * 64, "", "not_a_sha256", "A" * 64,
    "f" * 63, "f" * 65, "g" * 64, "0" * 64 + "\n",
])
def test_direct_digest_format_is_checked_without_echoing_private_value(digest):
    with pytest.raises(AudioInputError) as caught:
        WavAudio(np.zeros(16000), 8000, digest)
    assert caught.value.code == "invalid_audio_hash"
    assert "not_a_sha256" not in str(caught.value)


@pytest.mark.parametrize("dtype", [np.float32, np.float64])
def test_valid_direct_pcm16_grid_keeps_every_value_and_owns_copy(dtype):
    integers = np.tile(np.array([-32768, -123, 0, 1, 123, 32767]), 2667)[:16000]
    values = (integers / 32768.0).astype(dtype)
    original = values.copy()
    audio = WavAudio(values, 8000, "a" * 64)
    np.testing.assert_array_equal(audio.samples, original)
    values[:] = 0
    np.testing.assert_array_equal(audio.samples, original)
    assert not audio.samples.flags.writeable
    assert audio.metadata()["encoding"] == "pcm16"
    # Supplied digest format is checked, not source authenticity established.
    assert audio.sha256 == "a" * 64


def test_explicit_encoding_quantizes_but_does_not_modify_callers_float_input():
    values = np.full(16000, 0.123456)
    values[1] = 1.0
    original = values.copy()
    raw = encode_wav(values, 8000)
    audio = decode_wav(raw)
    np.testing.assert_array_equal(values, original)
    assert audio.samples[1] == 32767 / 32768
    assert np.all(audio.samples * 32768 == np.rint(audio.samples * 32768))
    assert audio.sha256 == hashlib.sha256(raw).hexdigest()


def test_container_metadata_changes_keep_distinct_original_hashes():
    raw = encode_wav(np.zeros(16000), 8000)
    extra = b"JUNK" + struct.pack("<I", 4) + b"unit"
    decorated = raw[:12] + extra + raw[12:]
    decorated = decorated[:4] + struct.pack("<I", len(decorated) - 8) + decorated[8:]
    first, second = decode_wav(raw), decode_wav(decorated)
    np.testing.assert_array_equal(first.samples, second.samples)
    assert first.sha256 == hashlib.sha256(raw).hexdigest()
    assert second.sha256 == hashlib.sha256(decorated).hexdigest()
    assert first.sha256 != second.sha256
