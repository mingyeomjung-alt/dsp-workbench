"""Input-contract tests using generated signals only, not private audio."""

from dataclasses import FrozenInstanceError
import hashlib
import json
import struct

import numpy as np
import pytest

from audio_regression.audio import AudioInputError, WavAudio, decode_wav, encode_wav, read_wav


def _wav(rate: int = 8000, seconds: float = 2.0) -> bytes:
    time = np.arange(round(rate * seconds), dtype=np.float64) / rate
    return encode_wav(0.25 * np.sin(2 * np.pi * 313 * time), rate)


def _replace(data: bytes, offset: int, packed: bytes) -> bytes:
    return data[:offset] + packed + data[offset + len(packed) :]


def _assert_error(data: bytes, code: str) -> None:
    with pytest.raises(AudioInputError) as error:
        decode_wav(data)
    assert error.value.code == code


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
@pytest.mark.parametrize("seconds", [2, 30])
def test_duration_boundaries_and_supported_rates(rate: int, seconds: int) -> None:
    data = _wav(rate, seconds)
    audio = decode_wav(data)
    assert isinstance(audio, WavAudio)
    assert audio.sample_rate_hz == rate
    assert audio.samples.size == rate * seconds
    assert audio.samples.dtype == np.float64
    assert audio.metadata()["duration_ms"] == seconds * 1000
    assert audio.sha256 == hashlib.sha256(data).hexdigest()
    json.dumps(audio.metadata(), allow_nan=False)


def test_decode_retains_silence_fullscale_dc_and_every_sample() -> None:
    integers = np.tile(np.array([-32768, -30000, 0, 30000, 32767, 0, 0, 128], dtype="<i2"), 2000)
    original = _wav()
    data = original[:44] + integers.tobytes()
    audio = decode_wav(data)
    np.testing.assert_array_equal(audio.samples, integers.astype(np.float64) / 32768)
    assert encode_wav(audio.samples, 8000) == data
    assert audio.metadata()["peak"] == 1.0
    assert audio.metadata()["channels"] == 1
    assert audio.metadata()["encoding"] == "pcm16"


def test_immutable_array_and_frozen_record() -> None:
    audio = decode_wav(_wav())
    assert not audio.samples.flags.writeable
    with pytest.raises(ValueError):
        audio.samples[0] = 0.5
    with pytest.raises(ValueError):
        audio.samples.setflags(write=True)
    with pytest.raises(FrozenInstanceError):
        audio.sample_rate_hz = 16000


def test_direct_record_construction_owns_immutable_copy() -> None:
    caller_samples = np.zeros(16000)
    audio = WavAudio(caller_samples, np.int64(8000), "0" * 64)
    caller_samples[0] = 0.5
    assert audio.samples[0] == 0
    assert isinstance(audio.sample_rate_hz, int)
    assert not audio.samples.flags.writeable
    json.dumps(audio.metadata(), allow_nan=False)


def test_read_wav_roundtrip_and_non_private_filesystem_error(tmp_path) -> None:
    data = _wav()
    path = tmp_path / "generated.wav"
    path.write_bytes(data)
    assert read_wav(path).sha256 == hashlib.sha256(data).hexdigest()
    with pytest.raises(AudioInputError) as error:
        read_wav(tmp_path / "private_name_not_to_disclose.wav")
    assert error.value.code == "file_read_error"
    assert "private_name" not in str(error.value)


@pytest.mark.parametrize("data", [b"", b"RIFF", b"X" * 44, b"RIFF\x00\x00\x00\x00WAVE"])
def test_invalid_headers(data: bytes) -> None:
    _assert_error(data, "invalid_wav")


@pytest.mark.parametrize("cut", [1, 2, 7, 100])
def test_truncated_wav_rejected_even_when_riff_length_is_repaired(cut: int) -> None:
    data = _wav()[:-cut]
    _assert_error(data, "invalid_wav")
    repaired = _replace(data, 4, struct.pack("<I", len(data) - 8))
    _assert_error(repaired, "invalid_wav")


def test_trailing_bytes_and_missing_chunks() -> None:
    data = _wav()
    _assert_error(data + b"trailing", "invalid_wav")
    _assert_error(b"RIFF\x04\x00\x00\x00WAVE", "invalid_wav")
    fmt_only = data[:36]
    _assert_error(_replace(fmt_only, 4, struct.pack("<I", len(fmt_only) - 8)), "invalid_wav")


@pytest.mark.parametrize("channels", [0, 2, 6])
def test_multichannel_and_invalid_channels_rejected(channels: int) -> None:
    _assert_error(_replace(_wav(), 22, struct.pack("<H", channels)), "unsupported_channels")


@pytest.mark.parametrize("format_code,bits", [(3, 32), (6, 8), (7, 8), (65534, 16), (1, 8), (1, 24)])
def test_only_pcm16_supported(format_code: int, bits: int) -> None:
    data = _replace(_wav(), 20, struct.pack("<H", format_code))
    data = _replace(data, 34, struct.pack("<H", bits))
    _assert_error(data, "unsupported_encoding")


@pytest.mark.parametrize("rate", [0, 7999, 22050, 96000])
def test_unsupported_decoding_rates(rate: int) -> None:
    _assert_error(_replace(_wav(), 24, struct.pack("<I", rate)), "unsupported_sample_rate")


@pytest.mark.parametrize("offset,value,pack_format", [(28, 123, "<I"), (32, 1, "<H")])
def test_inconsistent_pcm_header(offset: int, value: int, pack_format: str) -> None:
    _assert_error(_replace(_wav(), offset, struct.pack(pack_format, value)), "invalid_wav")


def test_odd_pcm_payload_rejected() -> None:
    data = _wav()
    odd = _replace(data, 40, struct.pack("<I", len(data) - 45))
    _assert_error(odd, "invalid_wav")


def test_metadata_chunks_padding_and_empty_pcm_extension() -> None:
    data = _wav()
    metadata = b"JUNK" + struct.pack("<I", 3) + b"abc\x00"
    extended_fmt = data[12:16] + struct.pack("<I", 18) + data[20:36] + b"\x00\x00"
    rebuilt = data[:12] + metadata + extended_fmt + data[36:]
    rebuilt = _replace(rebuilt, 4, struct.pack("<I", len(rebuilt) - 8))
    decoded = decode_wav(rebuilt)
    np.testing.assert_array_equal(decoded.samples, decode_wav(data).samples)
    assert decoded.sha256 != decode_wav(data).sha256


def test_duplicate_chunks_rejected() -> None:
    data = _wav()
    for chunk in [data[12:36], data[36:]]:
        duplicate = data + chunk
        duplicate = _replace(duplicate, 4, struct.pack("<I", len(duplicate) - 8))
        _assert_error(duplicate, "invalid_wav")


def test_size_limit_checked_before_parsing() -> None:
    _assert_error(b"x" * 10_000_001, "file_too_large")


@pytest.mark.parametrize("sample_count", [15999, 240001])
def test_decoding_duration_outside_inclusive_contract(sample_count: int) -> None:
    pcm = b"\x00\x00" * sample_count
    data = _wav()[:44] + pcm
    data = _replace(data, 4, struct.pack("<I", len(data) - 8))
    data = _replace(data, 40, struct.pack("<I", len(pcm)))
    _assert_error(data, "invalid_duration")


@pytest.mark.parametrize("rate", [True, 8000.0, 22050, 0])
def test_invalid_encoding_rate(rate) -> None:
    with pytest.raises(AudioInputError) as error:
        encode_wav(np.zeros(16000), rate)
    assert error.value.code == "unsupported_sample_rate"


@pytest.mark.parametrize("bad", [np.nan, np.inf, -np.inf, -1.00001, 1.00001])
def test_encoding_rejects_non_finite_or_out_of_range_without_clipping(bad: float) -> None:
    samples = np.zeros(16000)
    samples[1] = bad
    with pytest.raises(AudioInputError) as error:
        encode_wav(samples, 8000)
    assert error.value.code == "invalid_samples"


@pytest.mark.parametrize("bad", [np.zeros((16000, 1)), np.zeros((2, 16000)), [complex(0, 1)] * 16000, "not_audio"])
def test_encoding_rejects_non_mono_or_non_numeric_arrays(bad) -> None:
    with pytest.raises(AudioInputError) as error:
        encode_wav(bad, 8000)
    assert error.value.code == "invalid_samples"


@pytest.mark.parametrize("count", [0, 15999, 240001])
def test_encoding_duration_rejected(count: int) -> None:
    with pytest.raises(AudioInputError) as error:
        encode_wav(np.zeros(count), 8000)
    assert error.value.code == "invalid_duration"


def test_encoding_fullscale_endpoints_do_not_wrap_or_change_gain() -> None:
    samples = np.zeros(16000)
    samples[:5] = [-1.0, -0.5, 0.5, 32767 / 32768, 1.0]
    audio = decode_wav(encode_wav(samples, 8000))
    np.testing.assert_array_equal(audio.samples[:5], [-1, -0.5, 0.5, 32767 / 32768, 32767 / 32768])


def test_decoder_rejects_non_bytes_without_low_level_exception() -> None:
    with pytest.raises(AudioInputError) as error:
        decode_wav(None)
    assert error.value.code == "invalid_wav"
