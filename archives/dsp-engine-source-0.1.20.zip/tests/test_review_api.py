"""Fresh synthetic public review projection; no consumed audio is replayed."""
from copy import deepcopy
import importlib
import json

import numpy as np
import pytest

from audio_regression import api, cli
from audio_regression.audio import encode_wav, read_wav
from audio_regression.check_policy import check_result
from audio_regression.engine import EngineConfig, analyze_buffers
from audio_regression.endpoint_mapping import map_alignment_endpoints
from audio_regression.result_contract import validate_analysis_result


MODULES = {"v2": "robust_engine", "v3": "context_engine", "v4": "instrument_engine",
           "v5": "canonical_engine", "v6": "repeat_engine", "v7": "compound_engine",
           "v8": "compound_event_engine", "v9": "global_context_engine"}


def _pair(tmp_path, kind="silence"):
    samples = np.zeros(24000)
    if kind != "silence":
        rng = np.random.default_rng(202610141927)
        samples = .06 * np.convolve(rng.uniform(-1, 1, 24000), [.2, .6, .2], "same")
    data = encode_wav(samples, 8000)
    reference, processed = tmp_path / "reference.wav", tmp_path / "processed.wav"
    reference.write_bytes(data)
    processed.write_bytes(data)
    return reference, processed, data


def _raw(engine, reference, processed):
    left, right = read_wav(reference), read_wav(processed)
    config = EngineConfig(allow_gain=True, allow_resampling=True)
    if engine == "v1":
        return analyze_buffers(left, right, config), None
    module = importlib.import_module("audio_regression." + MODULES[engine])
    return module.analyze_buffers_with_trace(left, right, config)


@pytest.mark.parametrize("engine", ["v" + str(i) for i in range(1, 10)])
def test_both_public_entries_add_review_without_changing_core_or_trace(tmp_path, engine):
    reference, processed, data = _pair(tmp_path)
    raw, raw_trace = _raw(engine, reference, processed)
    raw_copy, trace_copy = deepcopy(raw), deepcopy(raw_trace)
    result, trace = api.analyze_pair_with_trace(reference, processed, engine=engine,
                                               allow_gain=True, allow_resampling=True)
    plain = api.analyze_pair(reference, processed, engine=engine,
                            allow_gain=True, allow_resampling=True)
    assert result == plain
    assert trace == raw_trace == trace_copy
    assert raw == raw_copy
    assert {key: value for key, value in result.items() if key != "review_diagnostics"} == map_alignment_endpoints(raw)
    assert result["status"] == "withheld" and result["events"] is None
    assert check_result(result)["exit_code"] == 2
    assert validate_analysis_result(result) is result
    block = result["review_diagnostics"]
    assert block["primary_reason_code"] == result["reason_code"]
    assert block["selected_engine"] == result["engine"]
    assert block["diagnostic_only"] is True and block["fault_provenance_confirmed"] is False
    assert block["trace_availability"] == ("not_recorded" if engine == "v1" else "recorded")
    assert reference.read_bytes() == processed.read_bytes() == data


@pytest.mark.parametrize("engine", ["v1", "v3", "v9"])
def test_analyzed_result_has_no_withholding_projection(tmp_path, engine):
    reference, processed, data = _pair(tmp_path, "clean")
    raw, raw_trace = _raw(engine, reference, processed)
    result, trace = api.analyze_pair_with_trace(reference, processed, engine=engine,
                                               allow_gain=True, allow_resampling=True)
    assert result["status"] == "analyzed"
    assert "review_diagnostics" not in result
    assert result == map_alignment_endpoints(raw)
    assert trace == raw_trace
    assert reference.read_bytes() == processed.read_bytes() == data


@pytest.mark.parametrize("engine", ["v1", "v9"])
def test_cli_saves_withheld_projection_and_still_exits_two(tmp_path, engine, capsys):
    reference, processed, data = _pair(tmp_path)
    output = tmp_path / "result.json"
    code = cli.main(["analyze", "--reference", str(reference), "--processed", str(processed),
                     "--engine", engine, "--declare-gain", "--declare-resampling", "--output", str(output)])
    stdout = json.loads(capsys.readouterr().out)
    saved = json.loads(output.read_text(encoding="utf-8"))
    assert code == 2 and saved == stdout
    assert saved["review_diagnostics"]["primary_reason_code"] == saved["reason_code"]
    assert check_result(saved)["exit_code"] == 2
    assert saved["complete_audio_approval"] is False
    assert saved["commercial_performance_validated"] is False
    assert reference.read_bytes() == processed.read_bytes() == data


def test_missing_candidate_trace_cannot_invent_stage_history(tmp_path, monkeypatch):
    reference, processed, _ = _pair(tmp_path)
    raw, _ = _raw("v9", reference, processed)
    module = importlib.import_module("audio_regression.global_context_engine")
    monkeypatch.setattr(module, "analyze_wavs_with_trace", lambda *args: (deepcopy(raw), None))
    result = api.analyze_pair(reference, processed, engine="v9", allow_gain=True, allow_resampling=True)
    assert result["review_diagnostics"]["trace_availability"] == "unavailable"
    assert result["review_diagnostics"]["stages"] == []
    assert result["reason_code"] == raw["reason_code"]
    assert check_result(result)["exit_code"] == 2
