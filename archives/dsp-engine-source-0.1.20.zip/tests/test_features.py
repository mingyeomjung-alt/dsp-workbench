"""Feature geometry and numerical checks, independent of scenario ground truth."""

from __future__ import annotations

from dataclasses import FrozenInstanceError

import numpy as np
import pytest

from audio_regression.features import BAND_COUNT, FeatureInputError, FeatureTrack, extract_features


def _signal(samples: int = 32000) -> np.ndarray:
    rng = np.random.default_rng(661)
    time = np.arange(samples) / 8000
    # Changing tones plus seeded noise yield nonperiodic local band shapes.
    return 0.12 * np.sin(2 * np.pi * (420 * time + 75 * time * time)) + rng.normal(0, 0.02, samples)


@pytest.mark.parametrize("length", [1, 79, 80, 81, 801, 32000, 240000])
def test_centers_shape_dtype_and_finite_values(length: int) -> None:
    track = extract_features(_signal(length))
    expected = np.arange(0, length, 80, dtype=np.int64)
    np.testing.assert_array_equal(track.centers_samples, expected)
    assert track.features.shape == (expected.size, BAND_COUNT)
    assert track.features.dtype == np.float64
    assert track.frame_rms.dtype == np.float64
    assert track.centers_samples.dtype == np.int64
    assert track.sample_rate_hz == 8000
    assert track.hop_samples == 80
    assert track.window_samples == 320
    assert np.all(np.isfinite(track.features))
    assert np.all(np.isfinite(track.frame_rms))
    norms = np.linalg.norm(track.features, axis=1)
    assert np.all((norms < 1e-12) | np.isclose(norms, 1.0))


@pytest.mark.parametrize("gain", [0.001, 0.125, 2.0, -0.5, 1e-100, 1e100])
def test_constant_gain_preserves_shape_and_scales_rms(gain: float) -> None:
    signal = _signal()
    original = extract_features(signal)
    changed = extract_features(signal * gain)
    np.testing.assert_allclose(changed.features, original.features, atol=1e-12, rtol=1e-10)
    np.testing.assert_allclose(changed.frame_rms, original.frame_rms * abs(gain), atol=0, rtol=1e-12)


@pytest.mark.parametrize("value", [0.0, 0.25, -0.75, 1e300])
def test_constant_and_silent_frames_have_no_band_shape(value: float) -> None:
    track = extract_features(np.full(811, value))
    np.testing.assert_array_equal(track.features, np.zeros_like(track.features))
    np.testing.assert_allclose(track.frame_rms, abs(value), rtol=1e-14, atol=0)


def test_rms_uses_present_samples_not_zero_padding() -> None:
    signal = _signal(1701)
    track = extract_features(signal)
    for index, center in enumerate(track.centers_samples):
        frame = signal[max(0, center - 160):min(signal.size, center + 160)]
        expected = np.sqrt(np.mean(frame * frame))
        assert track.frame_rms[index] == pytest.approx(expected, abs=1e-14)


def test_local_frequency_change_has_different_band_shape() -> None:
    time = np.arange(8000) / 8000
    low = extract_features(0.2 * np.sin(2 * np.pi * 500 * time))
    high = extract_features(0.2 * np.sin(2 * np.pi * 2700 * time))
    similarities = np.sum(low.features[5:-5] * high.features[5:-5], axis=1)
    assert float(np.median(similarities)) < 0.8


def test_input_preserved_and_feature_buffers_truly_readonly() -> None:
    signal = _signal()
    original = signal.copy()
    track = extract_features(signal)
    np.testing.assert_array_equal(signal, original)
    for buffer in (track.features, track.centers_samples, track.frame_rms):
        assert not buffer.flags.writeable
        with pytest.raises(ValueError):
            buffer.setflags(write=True)
        with pytest.raises(ValueError):
            buffer.flat[0] = 0
    with pytest.raises(FrozenInstanceError):
        track.hop_samples = 100


@pytest.mark.parametrize("value", [16000, 44100, 48000, 8000.0, True, np.bool_(True), "8000", None])
def test_unsupported_or_noninteger_rate_rejected(value) -> None:
    with pytest.raises(FeatureInputError) as caught:
        extract_features(_signal(), sample_rate_hz=value)
    assert caught.value.code == "unsupported_sample_rate"


def test_numpy_integer_rate_and_frame_configuration_supported() -> None:
    track = extract_features(_signal(), np.int64(8000), hop_ms=np.float32(5), window_ms=np.int64(20))
    assert type(track.sample_rate_hz) is int
    assert track.hop_samples == 40
    assert track.window_samples == 160


@pytest.mark.parametrize(
    "kwargs",
    [
        {"hop_ms": True}, {"hop_ms": "10"}, {"hop_ms": float("nan")},
        {"hop_ms": float("inf")}, {"hop_ms": 0}, {"hop_ms": 20.1},
        {"hop_ms": 10.01}, {"hop_ms": 10**1000}, {"window_ms": 19.9},
        {"window_ms": 80.1}, {"window_ms": 40.125},
        {"window_ms": 20, "hop_ms": 20},
    ],
)
def test_unsupported_geometry_has_stable_error(kwargs: dict) -> None:
    with pytest.raises(FeatureInputError) as caught:
        extract_features(_signal(), **kwargs)
    assert caught.value.code == "invalid_configuration"


@pytest.mark.parametrize(
    "samples",
    [
        [], [[0.1, 0.2]], [float("nan")], [float("inf")],
        np.array([1 + 2j]), ["0.1"], [True, False], None,
    ],
)
def test_invalid_sample_arrays_rejected(samples) -> None:
    with pytest.raises(FeatureInputError) as caught:
        extract_features(samples)
    assert caught.value.code == "invalid_samples"


def test_integer_and_noncontiguous_input_supported() -> None:
    input_values = np.arange(1600, dtype=np.int16)[::2]
    track = extract_features(input_values)
    assert track.features.shape == (10, BAND_COUNT)
    assert np.all(np.isfinite(track.features))


def test_track_copies_constructor_arrays() -> None:
    features = np.ones((2, BAND_COUNT))
    centers = np.array([0, 80], dtype=np.int64)
    rms = np.ones(2)
    track = FeatureTrack(features, centers, rms, 8000, 80, 320)
    features[:] = 0
    centers[:] = 0
    rms[:] = 0
    np.testing.assert_array_equal(track.features, np.ones((2, BAND_COUNT)))
    np.testing.assert_array_equal(track.centers_samples, [0, 80])
    np.testing.assert_array_equal(track.frame_rms, [1, 1])


@pytest.mark.parametrize(
    "features, centers, rms",
    [
        (np.zeros((0, BAND_COUNT)), np.array([], dtype=np.int64), np.zeros(0)),
        (np.zeros((2, 3)), np.array([0, 80]), np.ones(2)),
        (np.zeros((2, BAND_COUNT)), np.array([1, 81]), np.ones(2)),
        (np.zeros((2, BAND_COUNT)), np.array([0.0, 80.0]), np.ones(2)),
        (np.zeros((2, BAND_COUNT)), np.array([0, 80]), np.array([1, -1])),
        (np.full((2, BAND_COUNT), np.nan), np.array([0, 80]), np.ones(2)),
    ],
)
def test_malformed_track_rejected(features, centers, rms) -> None:
    with pytest.raises(FeatureInputError) as caught:
        FeatureTrack(features, centers, rms, 8000, 80, 320)
    assert caught.value.code == "invalid_features"
