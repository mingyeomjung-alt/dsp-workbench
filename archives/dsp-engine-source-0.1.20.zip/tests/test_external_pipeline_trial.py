"""Tool-only checks with owned signals; no sealed data or external downloads."""

import importlib.util
import hashlib
import json
from pathlib import Path
import subprocess
from types import SimpleNamespace

import numpy as np
import pytest

from audio_regression.audio import decode_wav, encode_wav


@pytest.fixture
def tool():
    path = Path(__file__).resolve().parents[1] / "tools/run_external_pipeline_trial.py"
    spec = importlib.util.spec_from_file_location("external_pipeline_trial", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_missing_binary_is_explicit_block_without_analyzer_or_audio(tool, tmp_path, monkeypatch):
    monkeypatch.setattr(tool.shutil, "which", lambda _: None)
    monkeypatch.setattr(tool, "audit_saved_pipeline", lambda *a, **k: pytest.fail("Analyzer must not run."))
    output = tmp_path / "new_trial"
    result = tool.run(output)
    assert result["status"] == "blocked"
    assert result["reason_code"] == "local_ffmpeg_unavailable"
    assert result["case_count"] == 0
    assert result["external_pipeline_executed"] is False
    assert not list(output.rglob("*.wav"))
    assert json.loads((output / "trial_plan.json").read_text("utf-8"))["engine"] == "v4"
    assert json.loads((output / "trial_summary.json").read_text("utf-8")) == result


def test_output_is_never_reused_or_overwritten(tool, tmp_path):
    with pytest.raises(tool.ExternalTrialError, match="output_directory_exists"):
        tool.run(tmp_path)


def test_invalid_explicit_binary_does_not_fall_back_to_path(tool, tmp_path, monkeypatch):
    monkeypatch.setattr(tool.shutil, "which", lambda _: pytest.fail("Explicit path must not fall back."))
    with pytest.raises(tool.ExternalTrialError, match="invalid_local_ffmpeg"):
        tool.run(tmp_path / "trial", tmp_path / "missing.exe")
    summary = json.loads((tmp_path / "trial/trial_summary.json").read_text("utf-8"))
    assert summary["status"] == "incomplete"


@pytest.mark.parametrize("case", ["normal", "delete_400ms", "repeat_400ms"])
@pytest.mark.parametrize("stage", [1, 2, 3, 4, 5])
def test_processor_command_is_bounded_and_non_destructive(tool, tmp_path, case, stage):
    source = tmp_path / "source.wav"
    dest = tmp_path / "new output.wav"
    command = tool._ffmpeg_command(tmp_path / "ffmpeg.exe", source, dest, stage, case)
    assert command[1:3] == ["-nostdin", "-n"]
    assert "-y" not in command
    assert command[-1] == str(dest)
    assert command[command.index("-i") + 1] == str(source)
    assert command[command.index("-c:a") + 1] == "pcm_s16le"
    assert command[command.index("-ac") + 1] == "1"
    assert command.count("-i") == 1


def test_subprocess_uses_arg_vector_no_shell_hidden_and_finite_timeout(tool, monkeypatch):
    captured = {}
    def fake(command, **kwargs):
        captured.update(kwargs)
        assert command == ["ffmpeg.exe", "-version"]
        return SimpleNamespace(returncode=0, stdout=b"", stderr=b"")
    monkeypatch.setattr(tool.subprocess, "run", fake)
    tool._subprocess(["ffmpeg.exe", "-version"], timeout=10)
    assert captured["shell"] is False
    assert captured["stdin"] == subprocess.DEVNULL
    assert captured["timeout"] == 10
    assert captured["check"] is False


def test_timeout_is_stable_and_not_retried(tool, monkeypatch):
    calls = []
    def fake(command, **kwargs):
        calls.append(command)
        raise subprocess.TimeoutExpired(command, kwargs["timeout"])
    monkeypatch.setattr(tool.subprocess, "run", fake)
    with pytest.raises(tool.ExternalTrialError, match="external_processor_timeout"):
        tool._subprocess(["ffmpeg.exe"], timeout=30)
    assert len(calls) == 1


def test_unrecognized_program_is_rejected_before_transform(tool, tmp_path, monkeypatch):
    binary = tmp_path / "binary.exe"
    binary.write_bytes(b"not actually executable")
    monkeypatch.setattr(tool, "_subprocess", lambda *a, **k:
                        SimpleNamespace(returncode=0, stdout=b"different program", stderr=b""))
    with pytest.raises(tool.ExternalTrialError, match="unrecognized_ffmpeg_version"):
        tool._version(binary)


@pytest.mark.parametrize("case,size", [("normal", 65920), ("delete_400ms", 62720), ("repeat_400ms", 69120)])
def test_native_control_has_exact_delay_and_edit_lengths(tool, case, size):
    source = encode_wav(tool._owned_signal(), tool.RATE)
    raw = source
    for stage in range(1, 6):
        raw = tool._native_stage(raw, stage, case)
    result = decode_wav(raw)
    assert result.sample_rate_hz == 8000
    assert result.samples.size == size
    assert np.all(result.samples[:1920] == 0)
    assert decode_wav(source).samples.size == 128000


def test_manifest_has_only_allowed_basic_declarations_and_not_truth(tool):
    value = tool._manifest()
    assert value["schema_version"] == 1
    assert len(value["stages"]) == 5
    assert "expected" not in json.dumps(value)
    assert [s["declaration"] for s in value["stages"]] == [
        {"allow_gain": gain, "allow_resampling": rate} for gain, rate in tool.DECLARATIONS]


def test_wave_difference_separates_container_identity_from_signal(tool):
    raw = encode_wav(tool._owned_signal(), tool.RATE)
    assert tool._wave_difference(raw, raw)["byte_identical"] is True
    other = encode_wav(tool._owned_signal() * .5, tool.RATE)
    diff = tool._wave_difference(raw, other)
    assert diff["same_rate_and_sample_count"]
    assert diff["rms_difference"] > 0
    assert diff["byte_identical"] is False


def test_preexisting_external_file_is_never_passed_to_processor(tool, tmp_path, monkeypatch):
    target = tmp_path / "already.wav"
    target.write_bytes(b"preserve")
    monkeypatch.setattr(tool, "_subprocess", lambda *a, **k: pytest.fail("Must not execute."))
    with pytest.raises(tool.ExternalTrialError, match="external_output_exists"):
        tool._transform(tmp_path / "ffmpeg.exe", tmp_path / "missing.wav", target, 1, "normal", None)
    assert target.read_bytes() == b"preserve"


@pytest.mark.parametrize("case,event", [
    ("delete_400ms", {"type": "delete", "reference_interval_ms": [2640.0, 3040.0],
                      "processed_boundary_ms": 2640.0}),
    ("repeat_400ms", {"type": "repeat", "reference_source_interval_ms": [2640.0, 3040.0],
                      "processed_added_interval_ms": [3040.0, 3440.0]}),
])
def test_event_observation_checks_exact_owned_coordinates(tool, case, event):
    assert tool._event_matches({"status": "analyzed", "events": [event]}, case)
    assert not tool._event_matches({"status": "withheld", "events": None}, case)
    assert not tool._event_matches({"status": "analyzed", "events": []}, case)
    wrong = dict(event)
    field = "reference_interval_ms" if case == "delete_400ms" else "reference_source_interval_ms"
    wrong[field] = [2500.0, 2900.0]
    assert not tool._event_matches({"status": "analyzed", "events": [wrong]}, case)


def test_normal_observation_never_accepts_withheld_or_candidates(tool):
    assert tool._event_matches({"status": "analyzed", "events": []}, "normal")
    assert not tool._event_matches({"status": "withheld", "events": None}, "normal")
    assert not tool._event_matches({"status": "analyzed", "events": [{}]}, "normal")


def test_saved_verification_never_runs_processor_or_analyzer_and_preserves_summary(tool, tmp_path, monkeypatch):
    raw = encode_wav(tool._owned_signal(), tool.RATE)
    meta = decode_wav(raw).metadata()
    summary_path = tmp_path / "trial_summary.json"
    summary_raw = json.dumps({"source_sha256": hashlib.sha256(raw).hexdigest()}).encode()
    summary_path.write_bytes(summary_raw)
    for case in tool.CASES:
        for kind in ("external", "native"):
            root = tmp_path / case / kind
            (root / "supplied").mkdir(parents=True)
            (root / "audit").mkdir()
            (root / "audit/audit_result.json").write_bytes(b"mock-result")
            for name in tool.FILES:
                (root / "supplied" / name).write_bytes(raw)
    monkeypatch.setattr(tool, "load_saved_pipeline_result", lambda *a: {
        "source": meta, "stages": [{"output": meta} for _ in range(5)]})
    monkeypatch.setattr(tool, "_observation", lambda *a: {"expected_behavior_met": True})
    monkeypatch.setattr(tool, "_subprocess", lambda *a, **k: pytest.fail("No external replay."))
    monkeypatch.setattr(tool, "audit_saved_pipeline", lambda *a, **k: pytest.fail("No analysis replay."))
    result = tool.verify_saved_trial(tmp_path)
    assert result["analysis_replayed"] is False
    assert result["external_processing_replayed"] is False
    assert result["total_audits"] == 6
    assert result["expected_behavior_count"] == 6
    assert summary_path.read_bytes() == summary_raw
    assert (tmp_path / "trial_verification.json").is_file()
    with pytest.raises(FileExistsError):
        tool.verify_saved_trial(tmp_path)
