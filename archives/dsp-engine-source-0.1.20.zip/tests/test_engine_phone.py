"""Telephone-profile development integration, not real-call validation.

Signals and edits are made independently of the fixture generator. The engine
receives only the two decoded files and declared transformations, never edit
locations, source seeds, labels, or a ground-truth time map.
"""

from __future__ import annotations

import hashlib
import json

import numpy as np
import pytest
from scipy.signal import chirp, lfilter

from audio_regression.audio import decode_wav, encode_wav
from audio_regression.engine import EngineConfig, analyze_buffers, analyze_wavs
from audio_regression.profiles import telephone_transform_samples


SOURCE_RATE_HZ = 16000
PHONE_RATE_HZ = 8000


def _nonperiodic_signal(seed=7729, seconds=6.0):
    rng = np.random.default_rng(seed)
    count = round(SOURCE_RATE_HZ * seconds)
    time = np.arange(count) / SOURCE_RATE_HZ
    colored = lfilter([0.3, 0.4, 0.3], [1.0, -0.42], rng.standard_normal(count))
    envelope = np.interp(
        time, np.linspace(0, seconds, 61), rng.uniform(0.25, 1.0, 61),
    )
    varying = chirp(time, f0=420, f1=2450, t1=seconds, method="quadratic")
    values = envelope * (colored + 0.17 * varying)
    return values * (0.18 / np.max(np.abs(values)))


def _decoded(samples, rate=SOURCE_RATE_HZ):
    return decode_wav(encode_wav(samples, rate))


def _telephone_audio(source):
    return _decoded(telephone_transform_samples(source), PHONE_RATE_HZ)


def _config(*, allow_gain=False, allow_resampling=True):
    return EngineConfig(
        profile="telephone", allow_gain=allow_gain, allow_resampling=allow_resampling,
    )


def _analyze_preserving_sources(reference, processed, config=None):
    ref_before = reference.samples.copy()
    proc_before = processed.samples.copy()
    result = analyze_buffers(reference, processed, config or _config())
    np.testing.assert_array_equal(reference.samples, ref_before)
    np.testing.assert_array_equal(processed.samples, proc_before)
    assert result["reference"] == reference.metadata()
    assert result["processed"] == processed.metadata()
    assert result["configuration"]["profile"] == "telephone"
    assert result["analysis"]["sample_rate_hz"] == PHONE_RATE_HZ
    json.dumps(result, allow_nan=False)
    return result


def _assert_analyzed(result):
    assert result["status"] == "analyzed", result
    assert result["reason_code"] is None
    assert isinstance(result["events"], list)


@pytest.mark.parametrize("seed", [7729, 8311])
def test_declared_bandlimit_mulaw_and_rate_change_have_no_defect_candidates(seed):
    reference = _decoded(_nonperiodic_signal(seed))
    processed = _telephone_audio(reference)
    result = _analyze_preserving_sources(reference, processed)
    _assert_analyzed(result)
    assert result["content_preservation_status"] == "no_supported_defect_candidates"
    assert result["events"] == []


@pytest.mark.parametrize("duration_ms", [200.0, 400.0])
@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_declared_telephone_transform_preserves_local_defect_location(kind, duration_ms):
    values = _nonperiodic_signal()
    start_ms = 1700.0
    stop_ms = start_ms + duration_ms
    first, last = round(start_ms * 16), round(stop_ms * 16)
    if kind == "delete":
        edited = np.concatenate([values[:first], values[last:]])
    else:
        edited = np.concatenate([values[:last], values[first:last], values[last:]])
    reference = _decoded(values)
    processed = _telephone_audio(_decoded(edited))
    result = _analyze_preserving_sources(reference, processed)
    _assert_analyzed(result)
    assert result["content_preservation_status"] == "defect_candidates"
    assert len(result["events"]) == 1
    event = result["events"][0]
    assert event["type"] == kind
    if kind == "delete":
        assert event["reference_interval_ms"] == pytest.approx(
            [start_ms, stop_ms], abs=100.0,
        )
        assert event["processed_boundary_ms"] == pytest.approx(start_ms, abs=100.0)
    else:
        assert event["reference_source_interval_ms"] == pytest.approx(
            [start_ms, stop_ms], abs=100.0,
        )
        assert event["processed_added_interval_ms"] == pytest.approx(
            [stop_ms, stop_ms + duration_ms], abs=100.0,
        )
        assert event["copy_interval_convention"] == (
            "canonical_later_adjacent_copy_not_edit_provenance"
        )


def test_declared_telephone_delay_and_gain_are_normal_changes():
    reference = _decoded(_nonperiodic_signal())
    transformed = telephone_transform_samples(reference)
    processed = _decoded(
        np.concatenate([np.zeros(240 * 8), transformed * 0.55]), PHONE_RATE_HZ,
    )
    result = _analyze_preserving_sources(reference, processed, _config(allow_gain=True))
    _assert_analyzed(result)
    assert result["content_preservation_status"] == "no_supported_defect_candidates"
    assert result["events"] == []
    assert result["diagnostics"]["gain_estimate"] == pytest.approx(0.55, abs=0.03)
    assert all(
        segment["processed_offset_ms"] == pytest.approx(240.0, abs=3.0)
        for segment in result["alignment_segments"]
    )


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_telephone_defect_with_delay_and_gain_uses_correct_time_axes(kind):
    values = _nonperiodic_signal(seed=8311)
    start_ms, length_ms, delay_ms = 1800.0, 400.0, 240.0
    stop_ms = start_ms + length_ms
    first, last = round(start_ms * 16), round(stop_ms * 16)
    edited = (
        np.concatenate([values[:first], values[last:]]) if kind == "delete"
        else np.concatenate([values[:last], values[first:last], values[last:]])
    )
    reference = _decoded(values)
    transformed = telephone_transform_samples(_decoded(edited))
    processed = _decoded(
        np.concatenate([np.zeros(round(delay_ms * 8)), transformed * 0.55]), PHONE_RATE_HZ,
    )
    result = _analyze_preserving_sources(reference, processed, _config(allow_gain=True))
    _assert_analyzed(result)
    assert len(result["events"]) == 1
    event = result["events"][0]
    assert event["type"] == kind
    if kind == "delete":
        assert event["reference_interval_ms"] == pytest.approx([start_ms, stop_ms], abs=100.0)
        assert event["processed_boundary_ms"] == pytest.approx(start_ms + delay_ms, abs=100.0)
    else:
        assert event["reference_source_interval_ms"] == pytest.approx([start_ms, stop_ms], abs=100.0)
        assert event["processed_added_interval_ms"] == pytest.approx(
            [stop_ms + delay_ms, stop_ms + delay_ms + length_ms], abs=100.0,
        )


def test_telephone_profile_does_not_implicitly_allow_undeclared_rate_change():
    reference = _decoded(_nonperiodic_signal())
    processed = _telephone_audio(reference)
    result = _analyze_preserving_sources(reference, processed, _config(allow_resampling=False))
    assert result["status"] == "withheld"
    assert result["content_preservation_status"] == "withheld"
    assert result["reason_code"] == "resampling_not_declared"
    assert result["events"] is None


def test_file_api_telephone_analysis_preserves_bytes_and_matches_buffer_results(tmp_path):
    reference_bytes = encode_wav(_nonperiodic_signal(), SOURCE_RATE_HZ)
    reference = decode_wav(reference_bytes)
    processed_bytes = encode_wav(telephone_transform_samples(reference), PHONE_RATE_HZ)
    reference_path, processed_path = tmp_path / "source.wav", tmp_path / "telephone.wav"
    reference_path.write_bytes(reference_bytes)
    processed_path.write_bytes(processed_bytes)
    result = analyze_wavs(reference_path, processed_path, _config())
    expected = analyze_buffers(reference, decode_wav(processed_bytes), _config())
    assert result == expected
    _assert_analyzed(result)
    assert result["content_preservation_status"] == "no_supported_defect_candidates"
    assert result["reference"]["sha256"] == hashlib.sha256(reference_bytes).hexdigest()
    assert result["processed"]["sha256"] == hashlib.sha256(processed_bytes).hexdigest()
    assert reference_path.read_bytes() == reference_bytes
    assert processed_path.read_bytes() == processed_bytes
