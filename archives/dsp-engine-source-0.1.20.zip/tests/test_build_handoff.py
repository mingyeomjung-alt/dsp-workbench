"""Safety checks for the narrow offline DSP handoff, without audio fixtures."""

import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import zipfile

import pytest


TOOL = Path(__file__).absolute().parents[1] / "tools" / "build_handoff.py"
SPEC = importlib.util.spec_from_file_location("dsp_build_handoff", TOOL)
handoff = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(handoff)


def project(tmp_path):
    root = tmp_path / "dsp"
    package = root / "src" / "audio_regression"
    package.mkdir(parents=True)
    (package / "__init__.py").write_text('__version__ = "0.1.0"\n', encoding="utf-8")
    (package / "cli.py").write_text("def main():\n    return 0\n", encoding="utf-8")
    (package / "schemas").mkdir()
    (package / "schemas" / "analysis-result-v1.schema.json").write_text('{"type": "object"}\n', encoding="utf-8")
    (root / "README.md").write_text("DSP fixture\n", encoding="utf-8")
    (root / "pyproject.toml").write_text('''[build-system]
requires = ["setuptools>=75"]
build-backend = "setuptools.build_meta"
[project]
name = "audio-regression-engine"
version = "0.1.0"
requires-python = ">=3.12"
[project.scripts]
audio-regression = "audio_regression.cli:main"
[tool.setuptools.packages.find]
where = ["src"]
[tool.setuptools.package-data]
audio_regression = ["schemas/*.json"]
''', encoding="utf-8")
    return root


def test_windows_deployment_only_tests_are_not_selected_for_sdk(tmp_path):
    source = project(tmp_path)
    tests = source / "tests"
    tests.mkdir()
    for name in ("test_windows_portable.py", "test_windows_entry.py", "test_event_lineage.py"):
        (tests / name).write_text("# owned selection fixture\n", encoding="utf-8")
    selected = {path.relative_to(source).as_posix() for path in handoff._selected_sources(source)}
    assert "tests/test_event_lineage.py" in selected
    assert "tests/test_windows_portable.py" not in selected
    assert "tests/test_windows_entry.py" not in selected


def fake_wheel(stage, dist, *, extra=None, missing_schema=False):
    target = dist / "audio_regression_engine-0.1.0-py3-none-any.whl"
    with zipfile.ZipFile(target, "x") as archive:
        for path in (stage / "src" / "audio_regression").rglob("*"):
            if path.is_file() and not (missing_schema and path.suffix == ".json"):
                archive.write(path, path.relative_to(stage / "src").as_posix())
        prefix = "audio_regression_engine-0.1.0.dist-info/"
        for name, data in {"METADATA": "Name: audio-regression-engine\nVersion: 0.1.0\n", "WHEEL": "Wheel-Version: 1.0\n", "RECORD": "", "top_level.txt": "audio_regression\n"}.items():
            archive.writestr(prefix + name, data)
        if extra:
            archive.writestr(extra, "private")
    return target


def test_staging_excludes_workspace_audio_keys_builds_and_test_files(tmp_path):
    source = project(tmp_path)
    for relative in (".venv/secret.py", "build/lib/voiceguard/identity.py", "evaluations/pairs/private.wav",
                     "src/voiceguard/key.py", "src/audio_regression/model_keys/secret.py",
                     "src/audio_regression/.personalwav/secret.py", "src/audio_regression/__pycache__/cache.py",
                     "src/audio_regression/wave.wav", "tests/.temp/private.py", ".git/config"):
        path = source / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"DO NOT COPY")
    (source / "HANDOFF.md").write_text("local only\n", encoding="utf-8")
    (source / "constraints-build.txt").write_text("setuptools==84.0.0\n", encoding="utf-8")
    (source / "tests" / "test_api.py").write_text("assert True\n", encoding="utf-8")
    (source / "tools").mkdir()
    (source / "tools" / "build_handoff.py").write_text("# reproduction tool\n", encoding="utf-8")
    (source / "tools" / "unapproved.py").write_text("DO NOT COPY", encoding="utf-8")
    stage = tmp_path / "stage"
    stage.mkdir()
    inventory = handoff.stage_source(source, stage)
    assert {item["path"] for item in inventory} == {
        "pyproject.toml", "README.md", "HANDOFF.md", "constraints-build.txt",
        "src/audio_regression/__init__.py", "src/audio_regression/cli.py",
        "src/audio_regression/schemas/analysis-result-v1.schema.json",
        "tests/test_api.py", "tools/build_handoff.py",
    }
    assert all(b"DO NOT COPY" not in path.read_bytes() for path in stage.rglob("*") if path.is_file())


def test_workbench_assets_use_a_fixed_allowlist_without_becoming_a_python_package(tmp_path):
    source = project(tmp_path)
    assets = source / "src" / "audio_regression" / "workbench_assets"
    assets.mkdir()
    for name in ("index.html", "app.css", "app.js"):
        (assets / name).write_text("owned static asset " + name, encoding="utf-8")
    for name in ("private.wav", "token.json", "extra.js", "app.js.map"):
        (assets / name).write_bytes(b"DO NOT COPY")
    nested = assets / "nested"
    nested.mkdir()
    (nested / "app.js").write_bytes(b"DO NOT COPY")
    (source / "Start-DSP.cmd").write_text("@echo off\n", encoding="utf-8")
    stage = tmp_path / "stage"
    stage.mkdir()
    inventory = handoff.stage_source(source, stage)
    names = {item["path"] for item in inventory}
    assert {"src/audio_regression/workbench_assets/" + name
            for name in ("index.html", "app.css", "app.js")} <= names
    assert "Start-DSP.cmd" in names
    assert not any(name.endswith((".wav", ".map", "token.json", "extra.js")) for name in names)
    handoff.verify_stage(stage, inventory)


def test_wheel_must_include_allowlisted_workbench_assets_exactly(tmp_path):
    source = project(tmp_path)
    assets = source / "src" / "audio_regression" / "workbench_assets"
    assets.mkdir()
    for name in ("index.html", "app.css", "app.js"):
        (assets / name).write_text(name, encoding="utf-8")
    stage, dist = tmp_path / "stage", tmp_path / "dist"
    stage.mkdir()
    dist.mkdir()
    inventory = handoff.stage_source(source, stage)
    wheel = fake_wheel(stage, dist)
    entries = handoff.inspect_wheel(wheel, stage, inventory, "0.1.0")
    assert {"audio_regression/workbench_assets/" + name
            for name in ("index.html", "app.css", "app.js")} <= {entry["path"] for entry in entries}


def test_new_directory_required_and_existing_contents_preserved(tmp_path):
    source = project(tmp_path)
    output = tmp_path / "existing"
    output.mkdir()
    sentinel = output / "keep.txt"
    sentinel.write_text("untouched", encoding="utf-8")
    with pytest.raises(handoff.HandoffError, match="already exists"):
        handoff.build_handoff(source, output, tmp_path)
    assert sentinel.read_text(encoding="utf-8") == "untouched"
    assert sorted(path.name for path in output.iterdir()) == ["keep.txt"]


@pytest.mark.parametrize("relative", ["../outside", "dsp/src/audio_regression/nested-output", "dsp/arbitrary-output"])
def test_destination_cannot_escape_or_overlap_source(tmp_path, relative):
    source = project(tmp_path)
    output = tmp_path / relative
    with pytest.raises(handoff.HandoffError):
        handoff.build_handoff(source, output, tmp_path)
    assert not output.exists()


def test_explicit_deliverables_child_is_allowed_without_recursion(tmp_path):
    source = project(tmp_path)
    destination = source / "deliverables"
    destination.mkdir()
    (destination / "old-build.py").write_text("DO NOT COPY", encoding="utf-8")
    output = destination / "new"
    assert handoff._destination(output, destination, source) == output
    assert all("deliverables" not in path.parts for path in handoff._selected_sources(source))


def test_symlinked_source_and_destination_are_rejected(tmp_path):
    source = project(tmp_path)
    secret = tmp_path / "private.py"
    secret.write_text("PRIVATE", encoding="utf-8")
    selected = source / "src" / "audio_regression" / "stolen.py"
    try:
        selected.symlink_to(secret)
    except OSError:
        pytest.skip("This Windows account cannot create symbolic links.")
    with pytest.raises(handoff.HandoffError, match="Links or reparse"):
        handoff.build_handoff(source, tmp_path / "out", tmp_path)
    assert not (tmp_path / "out").exists()
    stage = tmp_path / "linked-destination"
    stage.symlink_to(tmp_path, target_is_directory=True)
    with pytest.raises(handoff.HandoffError, match="Links or reparse"):
        handoff._destination(stage / "other", stage, source)


def test_hardlinked_source_is_rejected_without_output(tmp_path):
    source = project(tmp_path)
    private = tmp_path / "private.py"
    private.write_text("PRIVATE", encoding="utf-8")
    try:
        os.link(private, source / "src" / "audio_regression" / "stolen.py")
    except OSError:
        pytest.skip("Hard links are unavailable on this filesystem.")
    with pytest.raises(handoff.HandoffError, match="one link"):
        handoff.build_handoff(source, tmp_path / "out", tmp_path)
    assert not (tmp_path / "out").exists()
    assert private.read_text(encoding="utf-8") == "PRIVATE"


@pytest.mark.skipif(os.name != "nt", reason="Windows junction check")
def test_windows_junction_source_and_destination_are_rejected(tmp_path):
    import _winapi
    source = project(tmp_path)
    external = tmp_path / "private-package"
    external.mkdir()
    (external / "__init__.py").write_text("PRIVATE", encoding="utf-8")
    source_link = source / "src" / "audio_regression" / "linked_package"
    try:
        _winapi.CreateJunction(str(external), str(source_link))
    except OSError:
        pytest.skip("Windows junction creation is unavailable in this sandbox.")
    with pytest.raises(handoff.HandoffError, match="Links or reparse"):
        handoff.build_handoff(source, tmp_path / "out", tmp_path)
    assert not (tmp_path / "out").exists()
    destination_link = tmp_path / "linked-destination"
    _winapi.CreateJunction(str(external), str(destination_link))
    with pytest.raises(handoff.HandoffError, match="Links or reparse"):
        handoff._destination(destination_link / "new", destination_link, source)


def test_wheel_symlink_and_duplicate_entries_are_rejected(tmp_path):
    source = project(tmp_path)
    stage, dist = tmp_path / "stage", tmp_path / "dist"
    stage.mkdir()
    dist.mkdir()
    inventory = handoff.stage_source(source, stage)
    link_wheel = dist / "linked.whl"
    member = zipfile.ZipInfo("audio_regression/__init__.py")
    member.create_system = 3
    member.external_attr = 0o120777 << 16
    with zipfile.ZipFile(link_wheel, "x") as archive:
        archive.writestr(member, "../../private.py")
    with pytest.raises(handoff.HandoffError, match="duplicate, link"):
        handoff.inspect_wheel(link_wheel, stage, inventory, "0.1.0")
    duplicate_wheel = dist / "duplicate.whl"
    with zipfile.ZipFile(duplicate_wheel, "x") as archive:
        archive.writestr("audio_regression/__init__.py", (stage / "src" / "audio_regression" / "__init__.py").read_bytes())
        with pytest.warns(UserWarning, match="Duplicate name"):
            archive.writestr("audio_regression/__init__.py", "private")
    with pytest.raises(handoff.HandoffError, match="duplicate, link"):
        handoff.inspect_wheel(duplicate_wheel, stage, inventory, "0.1.0")


def test_staged_source_tamper_is_rejected(tmp_path):
    source = project(tmp_path)
    stage = tmp_path / "stage"
    stage.mkdir()
    inventory = handoff.stage_source(source, stage)
    (stage / "src" / "audio_regression" / "cli.py").write_text("tampered", encoding="utf-8")
    with pytest.raises(handoff.HandoffError, match="bytes changed"):
        handoff.verify_stage(stage, inventory)


def test_staged_nonallowlisted_file_is_rejected(tmp_path):
    source = project(tmp_path)
    stage = tmp_path / "stage"
    stage.mkdir()
    inventory = handoff.stage_source(source, stage)
    (stage / "src" / "audio_regression" / "private.wav").write_bytes(b"private audio")
    with pytest.raises(handoff.HandoffError, match="Unexpected file"):
        handoff.verify_stage(stage, inventory)


@pytest.mark.parametrize("extra", ["voiceguard/identity.py", "../personal.wav", "audio_regression/private.wav",
                                    "C:/model.key", "audio_regression\\secret.py"])
def test_wheel_private_payload_and_path_traversal_are_rejected(tmp_path, extra):
    source = project(tmp_path)
    stage, dist = tmp_path / "stage", tmp_path / "dist"
    stage.mkdir()
    dist.mkdir()
    inventory = handoff.stage_source(source, stage)
    wheel = fake_wheel(stage, dist, extra=extra)
    with pytest.raises(handoff.HandoffError):
        handoff.inspect_wheel(wheel, stage, inventory, "0.1.0")


def test_schema_must_be_present_in_the_wheel(tmp_path):
    source = project(tmp_path)
    stage, dist = tmp_path / "stage", tmp_path / "dist"
    stage.mkdir()
    dist.mkdir()
    inventory = handoff.stage_source(source, stage)
    wheel = fake_wheel(stage, dist, missing_schema=True)
    with pytest.raises(handoff.HandoffError, match="missing staged DSP code or schemas"):
        handoff.inspect_wheel(wheel, stage, inventory, "0.1.0")


def test_offline_build_flags_snapshot_and_sha_inventory(tmp_path, monkeypatch):
    source = project(tmp_path)
    calls = []
    def build(command, **kwargs):
        calls.append((command, kwargs))
        fake_wheel(Path(command[-1]), Path(command[command.index("--wheel-dir") + 1]))
        return subprocess.CompletedProcess(command, 0, "offline build", "")
    monkeypatch.setattr(handoff.subprocess, "run", build)
    output = tmp_path / "handoff"
    report = handoff.build_handoff(source, output, tmp_path, source_snapshot=True)
    command, kwargs = calls[0]
    assert {"--no-deps", "--no-build-isolation", "--no-index", "--no-cache-dir"}.issubset(command)
    assert kwargs["env"]["PIP_NO_INDEX"] == "1"
    assert "PYTHONPATH" not in kwargs["env"]
    assert hashlib.sha256((output / report["wheel"]["path"]).read_bytes()).hexdigest() == report["wheel"]["sha256"]
    assert json.loads((output / "inventory.json").read_text(encoding="utf-8")) == report
    with zipfile.ZipFile(output / "dsp-source.zip") as archive:
        assert set(archive.namelist()) == {entry["path"] for entry in report["source_inventory"]}
    assert "offline build" in (output / "build.log").read_text(encoding="utf-8")


def test_backend_cannot_execute_workspace_code(tmp_path):
    source = project(tmp_path)
    configuration = source / "pyproject.toml"
    configuration.write_text(configuration.read_text(encoding="utf-8").replace("setuptools.build_meta", "private_backend"), encoding="utf-8")
    with pytest.raises(handoff.HandoffError, match="setuptools.build_meta"):
        handoff.build_handoff(source, tmp_path / "out", tmp_path)
    assert not (tmp_path / "out").exists()


def test_failed_build_retains_only_new_output_and_log(tmp_path, monkeypatch):
    source = project(tmp_path)
    monkeypatch.setattr(handoff.subprocess, "run", lambda command, **kwargs: subprocess.CompletedProcess(command, 1, "", "offline failure"))
    output = tmp_path / "failed"
    with pytest.raises(handoff.HandoffError, match="retained"):
        handoff.build_handoff(source, output, tmp_path)
    assert (output / "build.log").read_text(encoding="utf-8") == "offline failure"
    assert not (output / "inventory.json").exists()
    assert (source / "README.md").read_text(encoding="utf-8") == "DSP fixture\n"


def test_original_source_edit_during_build_never_produces_success_inventory(tmp_path, monkeypatch):
    source = project(tmp_path)
    def build(command, **kwargs):
        fake_wheel(Path(command[-1]), Path(command[command.index("--wheel-dir") + 1]))
        (source / "src" / "audio_regression" / "cli.py").write_text("new source revision", encoding="utf-8")
        return subprocess.CompletedProcess(command, 0, "offline build", "")
    monkeypatch.setattr(handoff.subprocess, "run", build)
    output = tmp_path / "changed"
    with pytest.raises(handoff.HandoffError, match="Original DSP source bytes changed"):
        handoff.build_handoff(source, output, tmp_path, source_snapshot=True)
    assert not (output / "inventory.json").exists()
    assert not (output / "SHA256SUMS.txt").exists()
    assert (output / "build.log").exists()
