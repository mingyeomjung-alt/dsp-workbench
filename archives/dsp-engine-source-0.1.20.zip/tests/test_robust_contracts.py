"""Candidate contract/report tests use saved development JSON, never a detector."""

from copy import deepcopy
import json
from pathlib import Path

import pytest

from audio_regression.check_policy import check_result
from audio_regression.pipeline_reporting import (
    PipelineReportError, load_pipeline_result, render_pipeline_html,
    validate_pipeline_result,
)
from audio_regression.reporting import render_html
from audio_regression.result_contract import (
    ResultContractError, load_analysis_result, validate_analysis_result,
)
from audio_regression.robust_result_contract import ENGINE, METHOD, validate_robust_analysis_result
from audio_regression.saved_pipeline_contract import (
    SavedPipelineContractError, load_saved_pipeline_result, validate_saved_pipeline_result,
)
from audio_regression.saved_pipeline_reporting import render_saved_pipeline_html


ROOT = Path(__file__).resolve().parents[1]
DEVELOPMENT = ROOT / "tests" / "fixtures" / "results"


def _pair(kind="clean", candidate=True):
    value = load_analysis_result(DEVELOPMENT / f"synthetic_basic_{kind}.json")
    if candidate:
        value["engine"] = ENGINE
        value["analysis"]["method"] = METHOD
    return value


def _withheld(candidate=True):
    value = _pair(candidate=candidate)
    value.update(status="withheld", content_preservation_status="withheld", events=None,
                 reason_code="insufficient_unambiguous_anchors", diagnostics={})
    value.pop("alignment_segments")
    return value


def _pipeline(saved=False, candidate=True, withheld=False):
    pair = _withheld(candidate) if withheld else _pair(candidate=candidate)
    pair["configuration"]["allow_gain"] = True
    source, output = deepcopy(pair["reference"]), deepcopy(pair["processed"])
    check = check_result(pair)
    stage = {"index": 1, "label": "음량 조절", "input": source, "output": output,
             "status": pair["status"], "analysis": pair, "check": check,
             "input_snapshot": "inputs/000.wav" if saved else "input/source.wav",
             "output_snapshot": "inputs/001.wav" if saved else "stages/001/output.wav",
             "analysis_artifact": "stages/001/analysis.json",
             "check_artifact": "stages/001/check.json", "reason_code": pair["reason_code"],
             "runtime_ms": 12.0}
    if saved:
        stage["declaration"] = deepcopy(pair["configuration"])
    else:
        stage["operation"] = {"kind": "gain", "label": stage["label"], "gain_db": 0.0}
    prefix = "audio_saved_pipeline_audit" if saved else "audio_pipeline_regression"
    count_name = "checked_stage_count" if saved else "executed_stage_count"
    concern = ({"scope": "stage", "stage_index": 1, "stage_label": stage["label"],
                "category": "withheld"} if withheld else None)
    result = {"schema_version": 1, "engine": prefix + ("_v2" if candidate else "_v1"),
              "status": "completed", "source": deepcopy(source),
              "comparison_scope": "adjacent_stage_checks_and_end_to_end", "stages": [stage],
              "end_to_end": {"status": pair["status"], "analysis": deepcopy(pair),
                             "check": deepcopy(check), "analysis_artifact": "end_to_end/analysis.json",
                             "check_artifact": "end_to_end/check.json"},
              "summary": {"gate_state": check["gate_state"], "exit_code": check["exit_code"],
                          "first_concern": concern, "planned_stage_count": 1,
                          count_name: 1, "failed_stage": None},
              "complete_audio_approval": False, "commercial_performance_validated": False,
              "network_used": False, "fault_provenance_confirmed": False}
    if saved:
        result.update(input_recheck={"status": "unchanged", "file_indices": []}, caller_order_verified=False)
    return result


def _validate_pipeline(value, saved):
    return validate_saved_pipeline_result(value) if saved else validate_pipeline_result(value)


def _pipeline_error(saved):
    return SavedPipelineContractError if saved else PipelineReportError


@pytest.mark.parametrize("kind", ["clean", "delete", "repeat"])
def test_candidate_uses_same_strict_raw_evidence_geometry_without_mutating(kind):
    value = _pair(kind)
    before = deepcopy(value)
    assert validate_analysis_result(value) is value
    assert validate_robust_analysis_result(value) is value
    assert value == before
    assert check_result(value)["exit_code"] == (0 if kind == "clean" else 1)


def test_candidate_withheld_is_valid_but_cannot_clear():
    value = _withheld()
    assert validate_analysis_result(value) is value
    assert check_result(value)["exit_code"] == 2


@pytest.mark.parametrize("engine", [None, "local_content_alignment_v1", "local_content_alignment_v3", []])
def test_direct_candidate_validator_rejects_other_identities(engine):
    value = _pair()
    value["engine"] = engine
    with pytest.raises(ResultContractError) as caught:
        validate_robust_analysis_result(value)
    assert caught.value.code == "unsupported_engine"


@pytest.mark.parametrize("path,replacement,code", [
    (("schema_version",), 2, "unsupported_schema_version"),
    (("analysis", "method"), "constrained_edit_alignment_with_raw_anchors", "invalid_analysis_method"),
    (("analysis", "method"), None, "invalid_analysis_method"),
    (("analysis", "hop_ms"), 20, "invalid_analysis_method"),
    (("configuration", "profile"), "telephone", "unsupported_profile"),
    (("configuration", "profile"), [], "unsupported_profile"),
    (("complete_audio_approval",), True, "invalid_approval_claim"),
    (("commercial_performance_validated",), True, "invalid_approval_claim"),
    (("status",), "measured", "unsupported_result_status"),
    (("content_preservation_status",), "defect_candidates", "inconsistent_result_status"),
    (("diagnostics", "matched_normalized_rmse"), .081, "inconsistent_analyzed_metrics"),
    (("diagnostics", "minimum_local_correlation"), .89, "inconsistent_analyzed_metrics"),
    (("diagnostics", "matched_analysis_samples"), 100, "inconsistent_matched_sample_count"),
    (("diagnostics", "anchor_run_count"), 2, "inconsistent_anchor_count"),
    (("reference", "duration_ms"), 6100, "inconsistent_audio_duration"),
])
def test_candidate_does_not_relax_v1_raw_rules(path, replacement, code):
    value = _pair()
    node = value
    for key in path[:-1]:
        node = node[key]
    node[path[-1]] = replacement
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(value)
    assert caught.value.code == code
    assert check_result(value)["exit_code"] == 2


@pytest.mark.parametrize("field", ["trace", "probability", "raw_audio", "reference_path"])
def test_candidate_diagnostic_result_rejects_sidecars_or_extra_claim_fields(field):
    value = _pair()
    value[field] = "not part of the result contract"
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(value)
    assert caught.value.code == "unexpected_result_field"


def test_candidate_tree_is_bounded_before_copy_and_rejects_nonfinite():
    value = _pair()
    value["cycle"] = value
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(value)
    assert caught.value.code == "result_structure_too_large"
    value = _pair()
    value["diagnostics"]["matched_normalized_rmse"] = float("nan")
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(value)
    assert caught.value.code == "non_finite_metric"


@pytest.mark.parametrize("engine", [None, ENGINE])
def test_generic_or_candidate_minimal_error_is_always_blocked(engine):
    value = {"schema_version": 1, "status": "error", "reason_code": "analysis_execution_error"}
    if engine is not None:
        value["engine"] = engine
    assert validate_analysis_result(value) is value
    assert check_result(value)["exit_code"] == 2


def test_candidate_saved_pair_loader_keeps_identity_and_rejects_unknown_method(tmp_path):
    path = tmp_path / "result.json"
    value = _pair()
    path.write_text(json.dumps(value), encoding="utf-8")
    assert load_analysis_result(path) == value
    value["analysis"]["method"] = "unrecognized"
    path.write_text(json.dumps(value), encoding="utf-8")
    with pytest.raises(ResultContractError) as caught:
        load_analysis_result(path)
    assert caught.value.code == "invalid_analysis_method"


@pytest.mark.parametrize("saved", [False, True])
@pytest.mark.parametrize("candidate", [False, True])
@pytest.mark.parametrize("withheld", [False, True])
def test_old_and_candidate_pipelines_validate_read_only_with_sticky_state(saved, candidate, withheld):
    value = _pipeline(saved, candidate, withheld)
    before = deepcopy(value)
    assert _validate_pipeline(value, saved) is value
    assert value == before
    assert value["summary"]["exit_code"] == (2 if withheld else 0)


@pytest.mark.parametrize("saved", [False, True])
@pytest.mark.parametrize("top_candidate", [False, True])
@pytest.mark.parametrize("scope", ["stage", "end_to_end"])
def test_pipeline_cannot_mix_candidate_and_old_engine_versions(saved, top_candidate, scope):
    value = _pipeline(saved, top_candidate)
    item = value["stages"][0] if scope == "stage" else value["end_to_end"]
    item["analysis"]["engine"] = "local_content_alignment_v1" if top_candidate else ENGINE
    item["analysis"]["analysis"]["method"] = (
        "constrained_edit_alignment_with_raw_anchors" if top_candidate else METHOD)
    item["check"] = check_result(item["analysis"])
    with pytest.raises(_pipeline_error(saved)) as caught:
        _validate_pipeline(value, saved)
    assert caught.value.code == "inconsistent_analysis_engine"


@pytest.mark.parametrize("saved", [False, True])
@pytest.mark.parametrize("scope", ["stage", "end_to_end"])
def test_candidate_pipeline_rejects_forged_canonical_check(saved, scope):
    value = _pipeline(saved)
    item = value["stages"][0] if scope == "stage" else value["end_to_end"]
    item["check"]["complete_audio_approval"] = True
    with pytest.raises(_pipeline_error(saved)) as caught:
        _validate_pipeline(value, saved)
    assert caught.value.code == "inconsistent_saved_check"


@pytest.mark.parametrize("saved", [False, True])
def test_candidate_pipeline_generic_stage_error_never_becomes_clear(saved):
    value = _pipeline(saved)
    stage = value["stages"][0]
    error = {"schema_version": 1, "status": "error", "reason_code": "analysis_execution_error"}
    stage.update(status="error", analysis=error, check=check_result(error),
                 reason_code=error["reason_code"], analysis_artifact="stages/001/error.json",
                 check_artifact="stages/001/error_check.json")
    value.update(status="incomplete", end_to_end=None)
    value["summary"].update(exit_code=2, gate_state="blocked", failed_stage=1,
        first_concern={"scope": "stage", "stage_index": 1, "stage_label": stage["label"],
                       "category": "execution_error"})
    assert _validate_pipeline(value, saved) is value


@pytest.mark.parametrize("saved", [False, True])
def test_candidate_pipeline_loads_stored_json_without_trace_or_audio_files(tmp_path, saved):
    value = _pipeline(saved)
    path = tmp_path / "result.json"
    path.write_text(json.dumps(value), encoding="utf-8")
    loaded = load_saved_pipeline_result(path) if saved else load_pipeline_result(path)
    assert loaded == value
    assert not (tmp_path / "trace.json").exists()


@pytest.mark.parametrize("saved", [False, True])
def test_candidate_pipeline_report_names_actual_engine_and_inert_trace_note(saved):
    candidate = _pipeline(saved)
    render = render_saved_pipeline_html if saved else render_pipeline_html
    html = render(candidate)
    assert candidate["engine"] in html
    assert ENGINE in html
    assert "선택한 실험 후보" in html
    assert "trace.json" in html
    assert "존재를 확인하지" in html
    assert '<a ' not in html and '<script' not in html
    legacy_html = render(_pipeline(saved, candidate=False))
    assert "선택한 실험 후보" not in legacy_html
    assert "trace.json" not in legacy_html


def test_pair_report_does_not_present_candidate_as_verified_performance():
    html = render_html(_pair())
    assert ENGINE in html and "선택한 실험 후보" in html
    assert "일반 정확도나 상용 성능을 보장하지 않습니다" in html
    assert "선택한 실험 후보" not in render_html(_pair(candidate=False))


def test_new_schema_retains_old_schema_identity_and_raw_geometry():
    schemas = ROOT / "src" / "audio_regression" / "schemas"
    old = json.loads((schemas / "analysis-result-v1.schema.json").read_text(encoding="utf-8"))
    candidate = json.loads((schemas / "analysis-result-v2.schema.json").read_text(encoding="utf-8"))
    assert old["$id"] == "urn:audio-regression:analysis-result:v1"
    assert candidate["$id"] == "urn:audio-regression:analysis-result:v2"
    assert old["$defs"]["analysis"]["properties"]["method"]["const"] == "constrained_edit_alignment_with_raw_anchors"
    assert candidate["$defs"]["analysis"]["properties"]["method"]["const"] == METHOD
    assert candidate["$defs"]["configuration"]["properties"]["profile"] == {"type": "string", "const": "basic"}
    for name in ("metadata", "analyzedDiagnostics", "withheldDiagnostics", "deleteEvent",
                 "repeatEvent", "event", "alignmentSegment"):
        assert candidate["$defs"][name] == old["$defs"][name]
    for name in ("analyzed", "withheld", "cliError"):
        assert candidate["$defs"][name]["properties"]["engine"]["const"] == ENGINE
        assert old["$defs"][name]["properties"]["engine"]["const"] == "local_content_alignment_v1"
