"""V5 opt-in public routes on owned analytic audio, never sealed recordings."""

import copy
import json
from pathlib import Path
import pytest
from audio_regression import api, handoff_cli, pipeline_cli
from audio_regression.audio import encode_wav
from audio_regression.result_contract import validate_analysis_result, ResultContractError
from audio_regression.reporting import render_html
from audio_regression.pipeline_runner import run_pipeline
from audio_regression.pipeline_reporting import validate_pipeline_result, render_pipeline_html
from audio_regression.saved_pipeline import audit_saved_pipeline
from audio_regression.saved_pipeline_contract import validate_saved_pipeline_result
from audio_regression.saved_pipeline_reporting import render_saved_pipeline_html
from test_canonical_resampling import _owned_pair


@pytest.fixture
def files(tmp_path):
    a, b = _owned_pair()
    reference, processed = tmp_path / "a.wav", tmp_path / "b.wav"
    reference.write_bytes(encode_wav(a.samples, a.sample_rate_hz))
    processed.write_bytes(encode_wav(b.samples, b.sample_rate_hz))
    return reference, processed


def test_public_facade_and_report_identify_exact_proof_without_probability(files):
    a, b = files
    result, trace = api.analyze_pair_with_trace(a, b, engine="v5", allow_resampling=True)
    validate_analysis_result(result)
    assert result["events"] == [] and trace["canonical_proved"]
    assert trace["low_information_block_count"] > 0
    assert result == api.analyze_pair(a, b, engine="v5", allow_resampling=True)
    html = render_html(result)
    assert "v5 · 선택한 개선 후보" in html and "정확한 PCM 정상 리샘플링" in html
    assert result["complete_audio_approval"] is False
    assert api.analyze_pair(a, b, allow_resampling=True)["engine"] == "local_content_alignment_v1"


def test_console_analysis_check_report_and_duplicate_output(files, tmp_path, capsys):
    a, b = files
    output = tmp_path / "result.json"
    args = ["analyze", "--engine", "v5", "--reference", str(a), "--processed", str(b),
            "--declare-resampling", "--output", str(output)]
    assert handoff_cli.main(args) == 0
    capsys.readouterr()
    assert handoff_cli.main(["check", "--input", str(output)]) == 0
    capsys.readouterr()
    html = tmp_path / "report.html"
    assert handoff_cli.main(["report", "--input", str(output), "--output", str(html)]) == 0
    capsys.readouterr()
    assert "local_content_alignment_v5" in html.read_text(encoding="utf-8")
    before = output.read_bytes()
    assert handoff_cli.main(args) == 3
    capsys.readouterr()
    assert output.read_bytes() == before


@pytest.mark.parametrize("mode", ["native", "saved"])
def test_pipeline_routes_and_not_reanalyzing_report(files, tmp_path, monkeypatch, mode):
    a, b = files
    if mode == "native":
        result = run_pipeline(a, [{"kind": "resample", "target_rate_hz": 8000}],
                              tmp_path / "native", engine="v5")
        validate_pipeline_result(result)
        render = render_pipeline_html
    else:
        manifest = tmp_path / "manifest.json"
        manifest.write_text(json.dumps({"schema_version": 1, "source": "a.wav", "stages": [
            {"output": "b.wav", "label": "resample", "declaration": {
                "allow_gain": False, "allow_resampling": True}}]}), encoding="utf-8")
        result = audit_saved_pipeline(manifest, tmp_path / "saved", engine="v5")
        validate_saved_pipeline_result(result)
        render = render_saved_pipeline_html
    assert result["summary"]["exit_code"] == 0
    assert all(stage["analysis"]["engine"] == "local_content_alignment_v5" for stage in result["stages"])
    monkeypatch.setattr(api, "analyze_pair_with_trace", lambda *a, **k: pytest.fail("stored report reanalysis"))
    html = render(result)
    assert "v5 · 선택한 실험 후보" in html and "전체 음질 승인" in html


@pytest.mark.parametrize("mutation", ["method", "approval", "profile", "position"])
def test_v5_contract_rejects_fabricated_results(files, mutation):
    result = api.analyze_pair(*files, engine="v5", allow_resampling=True)
    value = copy.deepcopy(result)
    if mutation == "method":
        value["analysis"]["method"] = "made_up"
    elif mutation == "approval":
        value["complete_audio_approval"] = True
    elif mutation == "profile":
        value["configuration"]["profile"] = "telephone"
    else:
        value["alignment_segments"][0]["reference_interval_ms"][1] = 99999
    with pytest.raises(ResultContractError):
        validate_analysis_result(value)


def test_schema_identity_and_default_pipeline_choice():
    root = Path(__file__).parents[1] / "src/audio_regression/schemas"
    schema = json.loads((root / "analysis-result-v5.schema.json").read_text(encoding="utf-8"))
    assert schema["$id"].endswith(":v5")
    assert "local_content_alignment_v5" in json.dumps(schema)
    args = pipeline_cli._parser().parse_args(["run", "--source", "a.wav", "--plan", "p.json", "--output-dir", "new"])
    assert args.engine == "v1"
