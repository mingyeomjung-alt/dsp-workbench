"""Strict saved-measurement contract tests using only fresh owned PCM signals."""

from copy import deepcopy
from functools import lru_cache
import json
from pathlib import Path

import numpy as np
import pytest

from audio_regression.audio import decode_wav, encode_wav
from audio_regression.fullband_contract import (
    BAND_EDGES_HZ, CONFIGURATION, ENGINE, MAX_FULLBAND_RESULT_BYTES,
    derive_fullband_summary, load_fullband_result, validate_fullband_result,
)
from audio_regression.fullband_metrics import measure_audio, measure_pair
from audio_regression.result_contract import ResultContractError, _json_tree


SCHEMA = Path(__file__).resolve().parents[1] / "src" / "audio_regression" / "schemas" / "fullband-measurement-v1.schema.json"


def _pcm(rate=8000, count=None, kind="tone"):
    count = count or 2 * rate + 17
    if kind == "zero":
        integers = np.zeros(count, dtype=np.int16)
    elif kind == "constant":
        integers = np.full(count, 8192, dtype=np.int16)
    elif kind == "rails":
        integers = np.where(np.arange(count) % 2, 32767, -32768).astype(np.int16)
    else:
        integers = np.rint(6000 * np.sin(np.arange(count) * 2 * np.pi * 613 / rate)).astype(np.int16)
    return decode_wav(encode_wav(integers.astype(np.float64) / 32768, rate))


@lru_cache(maxsize=32)
def _cached_result(rate=8000, kind="changed"):
    reference = _pcm(rate, kind=kind if kind in {"zero", "constant", "rails"} else "tone")
    if kind in {"identical", "zero", "constant", "rails"}:
        processed = reference
    elif kind == "rate_mismatch":
        processed = _pcm(16000 if rate != 16000 else 8000)
    elif kind == "count_mismatch":
        processed = _pcm(rate, count=2 * rate + 18)
    elif kind == "zero_reference":
        processed = reference
        reference = _pcm(rate, kind="zero")
    else:
        integers = np.rint(reference.samples * 32768).astype(np.int16)
        integers[-1] = np.int16(int(integers[-1]) + 1)
        processed = decode_wav(encode_wav(integers.astype(np.float64) / 32768, rate))
    comparison = measure_pair(reference, processed)
    return {
        "schema_version": 1, "engine": ENGINE,
        "status": "measured" if comparison["status"] == "measured" else "comparison_withheld",
        "reason_code": comparison["reason_code"], "reference": reference.metadata(),
        "processed": processed.metadata(), "reference_measurements": measure_audio(reference),
        "processed_measurements": measure_audio(processed), "comparison": comparison,
        "configuration": deepcopy(CONFIGURATION), "summary": derive_fullband_summary(comparison),
        "artifacts": {"reference": "input/reference.wav", "processed": "input/processed.wav"},
        "complete_audio_approval": False, "commercial_performance_validated": False,
        "network_used": False, "fault_provenance_confirmed": False,
    }


def _result(rate=8000, kind="changed"):
    return deepcopy(_cached_result(rate, kind))


def _set(record, path, value):
    target = record
    for key in path[:-1]:
        target = target[key]
    target[path[-1]] = value


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
@pytest.mark.parametrize("kind", ["changed", "identical", "zero", "constant", "rails", "zero_reference", "rate_mismatch", "count_mismatch"])
def test_fresh_owned_measurements_are_valid_and_unchanged(rate, kind):
    record = _result(rate, kind)
    before = deepcopy(record)
    assert validate_fullband_result(record) is record
    assert record == before
    assert record["summary"]["quality_verdict"] == "not_assessed"


BAD_VALUES = [
    (("schema_version",), True), (("schema_version",), 2), (("engine",), "local_content_alignment_v1"),
    (("status",), "approved"), (("reason_code",), "private_reason"),
    (("complete_audio_approval",), True), (("commercial_performance_validated",), True),
    (("network_used",), 0), (("fault_provenance_confirmed",), True),
    (("reference", "sample_rate_hz"), True), (("reference", "sample_count"), True),
    (("reference", "rms"), True), (("reference", "peak"), -1),
    (("reference", "encoding"), "float32"), (("reference", "sha256"), "private/path"),
    (("reference_measurements", "dc_offset"), 1), (("reference_measurements", "mean_square"), 0),
    (("reference_measurements", "rms_dbfs"), None), (("reference_measurements", "peak_dbfs"), None),
    (("reference_measurements", "crest_factor"), 0), (("reference_measurements", "rail_sample_count"), 1),
    (("reference_measurements", "rail_sample_fraction"), 1),
    (("reference_measurements", "longest_same_rail_run_samples"), True),
    (("reference_measurements", "frame_size_samples"), 50),
    (("reference_measurements", "bands", 0, "lower_hz"), True),
    (("reference_measurements", "bands", 0, "upper_hz"), 251),
    (("reference_measurements", "bands", 0, "effective_upper_hz"), None),
    (("reference_measurements", "bands", 0, "upper_inclusive"), True),
    (("reference_measurements", "bands", 0, "mean_square"), .25),
    (("reference_measurements", "bands", 0, "power_fraction"), .5),
    (("reference_measurements", "bands", 5, "status"), "available"),
    (("reference_measurements", "bands", 5, "mean_square"), 0),
    (("reference_measurements", "bands", 5, "effective_upper_hz"), 8000),
    (("reference_measurements", "frames", 0, "start_sample"), 1),
    (("reference_measurements", "frames", 0, "end_sample"), 799),
    (("reference_measurements", "frames", 0, "mean_square"), .5),
    (("reference_measurements", "frames", 0, "peak"), 0),
    (("comparison", "status"), "withheld"), (("comparison", "reason_code"), "sample_count_mismatch"),
    (("comparison", "unequal_sample_count"), True), (("comparison", "unequal_sample_count"), 16018),
    (("comparison", "first_changed_sample"), None), (("comparison", "first_changed_sample"), -1),
    (("comparison", "last_changed_sample"), 16017),
    (("comparison", "maximum_abs_error_pcm16"), 65536),
    (("comparison", "maximum_abs_error_pcm16"), 0),
    (("comparison", "mean_square_error"), 0), (("comparison", "mean_square_error"), 4),
    (("comparison", "signal_to_residual_db"), None),
    (("comparison", "signal_to_residual_status"), "zero_reference"),
    (("comparison", "correlation"), 2), (("comparison", "correlation"), True),
    (("comparison", "correlation_status"), "constant_signal"),
    (("comparison", "residual_bands"), None),
    (("comparison", "changed_frames", 0, "start_sample"), 1),
    (("comparison", "changed_frames", 0, "end_sample"), 16000),
    (("comparison", "changed_frames", 0, "unequal_sample_count"), 0),
    (("comparison", "changed_frames", 0, "unequal_sample_count"), 2),
    (("configuration", "frame_duration_ms"), True),
    (("configuration", "band_edges_hz"), [0, 250]),
    (("configuration", "auto_alignment"), True), (("configuration", "resampling"), True),
    (("configuration", "gain_compensation"), True),
    (("summary", "exit_code"), False), (("summary", "exit_code"), 1),
    (("summary", "meaning"), "audio_quality_approved"),
    (("summary", "quality_verdict"), "passed"),
    (("artifacts", "reference"), "../../private.wav"),
    (("artifacts", "processed"), "https://private.invalid/file.wav"),
]


@pytest.mark.parametrize("path,value", BAD_VALUES, ids=["-".join(map(str, path)) + "-" + str(index) for index, (path, _) in enumerate(BAD_VALUES)])
def test_rejects_inconsistent_numeric_structural_and_approval_claims(path, value):
    record = _result()
    _set(record, path, value)
    with pytest.raises(ResultContractError):
        validate_fullband_result(record)


@pytest.mark.parametrize("path", [(), ("reference",), ("reference_measurements",),
                                  ("reference_measurements", "bands", 0),
                                  ("reference_measurements", "frames", 0),
                                  ("comparison",), ("comparison", "changed_frames", 0),
                                  ("configuration",), ("summary",), ("artifacts",)])
@pytest.mark.parametrize("action", ["extra", "missing"])
def test_closed_structures_reject_added_and_removed_fields(path, action):
    record = _result()
    target = record
    for key in path:
        target = target[key]
    if action == "extra":
        target["private_payload"] = None
    else:
        target.pop(next(iter(target)))
    with pytest.raises(ResultContractError):
        validate_fullband_result(record)


@pytest.mark.parametrize("kind", ["zero", "constant"])
@pytest.mark.parametrize("field,value", [("signal_to_residual_db", 0), ("signal_to_residual_status", "finite"),
                                        ("correlation", 1), ("correlation_status", "defined")])
def test_undefined_metrics_remain_null_with_exact_status(kind, field, value):
    record = _result(kind=kind)
    record["comparison"][field] = value
    with pytest.raises(ResultContractError):
        validate_fullband_result(record)


@pytest.mark.parametrize("field", ["rms_dbfs", "peak_dbfs", "crest_factor", "dc_offset"])
def test_zero_audio_does_not_claim_finite_log_or_crest(field):
    record = _result(kind="zero")
    record["reference_measurements"][field] = 1
    with pytest.raises(ResultContractError):
        validate_fullband_result(record)


@pytest.mark.parametrize("kind", ["rate_mismatch", "count_mismatch"])
@pytest.mark.parametrize("field", ["unequal_sample_count", "first_changed_sample", "last_changed_sample",
                                  "maximum_abs_error_pcm16", "mean_square_error", "signal_to_residual_db",
                                  "correlation", "residual_bands", "changed_frames"])
def test_mismatched_native_geometry_keeps_pair_metrics_unavailable(kind, field):
    record = _result(kind=kind)
    record["comparison"][field] = [] if field.endswith("bands") or field.endswith("frames") else 0
    with pytest.raises(ResultContractError):
        validate_fullband_result(record)


def test_rate_mismatch_has_priority_and_cannot_be_swapped_for_count_reason():
    record = _result(kind="rate_mismatch")
    assert record["reference"]["sample_count"] != record["processed"]["sample_count"]
    record["reason_code"] = record["comparison"]["reason_code"] = "sample_count_mismatch"
    with pytest.raises(ResultContractError):
        validate_fullband_result(record)


@pytest.mark.parametrize("kind", ["changed", "rate_mismatch", "count_mismatch"])
def test_identical_container_hash_cannot_bind_changed_metadata_or_pcm(kind):
    record = _result(kind=kind)
    record["processed"]["sha256"] = record["reference"]["sha256"]
    with pytest.raises(ResultContractError):
        validate_fullband_result(record)


def test_final_partial_frame_and_single_pcm_unit_change_are_retained():
    record = _result()
    assert record["reference_measurements"]["frames"][-1]["end_sample"] == 16017
    pair = record["comparison"]
    assert pair["changed_frames"] == [{"start_sample": 16000, "end_sample": 16017, "unequal_sample_count": 1}]
    assert pair["mean_square_error"] == pytest.approx(1 / (32768 ** 2 * 16017))
    assert pair["first_changed_sample"] == pair["last_changed_sample"] == 16016
    assert validate_fullband_result(record) is record
    record["reference_measurements"]["frames"].pop()
    with pytest.raises(ResultContractError):
        validate_fullband_result(record)


def test_changed_frames_are_unique_ordered_and_bound_to_first_last_indices():
    record = _result()
    record["comparison"]["changed_frames"].append(deepcopy(record["comparison"]["changed_frames"][0]))
    with pytest.raises(ResultContractError):
        validate_fullband_result(record)
    record = _result()
    record["comparison"]["first_changed_sample"] = 0
    with pytest.raises(ResultContractError):
        validate_fullband_result(record)


def test_identical_nonconstant_pcm_cannot_claim_different_measurements_or_correlation():
    record = _result(kind="identical")
    record["comparison"]["correlation"] = .5
    with pytest.raises(ResultContractError):
        validate_fullband_result(record)
    record = _result(kind="identical")
    record["processed_measurements"]["dc_offset"] += 1e-8
    with pytest.raises(ResultContractError):
        validate_fullband_result(record)


def test_zero_energy_cannot_claim_nonzero_peak_even_if_frame_and_log_are_changed():
    record = _result(kind="zero")
    for name in ("reference", "processed"):
        record[name]["peak"] = 1 / 32768
    for name in ("reference_measurements", "processed_measurements"):
        record[name]["peak_dbfs"] = float(20 * np.log10(1 / 32768))
        record[name]["frames"][0]["peak"] = 1 / 32768
    with pytest.raises(ResultContractError) as caught:
        validate_fullband_result(record)
    assert caught.value.code == "inconsistent_fullband_audio_moments"


def test_full_negative_peak_requires_at_least_one_rail_sample():
    record = _result(kind="rails")
    for name in ("reference_measurements", "processed_measurements"):
        record[name].update(rail_sample_count=0, rail_sample_fraction=0, longest_same_rail_run_samples=0)
    with pytest.raises(ResultContractError) as caught:
        validate_fullband_result(record)
    assert caught.value.code == "inconsistent_fullband_rail_energy"


def test_negative_32767_peak_is_not_a_signed_rail_hit():
    samples = np.full(16000, -32767 / 32768, dtype=np.float64)
    audio = decode_wav(encode_wav(samples, 8000))
    measurements = measure_audio(audio)
    comparison = measure_pair(audio, audio)
    record = _result(kind="constant")
    record.update(reference=audio.metadata(), processed=audio.metadata(),
                  reference_measurements=measurements, processed_measurements=deepcopy(measurements),
                  comparison=comparison, summary=derive_fullband_summary(comparison))
    assert audio.metadata()["peak"] == 32767 / 32768
    assert measurements["rail_sample_count"] == 0
    assert measurements["longest_same_rail_run_samples"] == 0
    assert comparison["correlation_status"] == "constant_signal"
    assert comparison["correlation"] is None
    assert validate_fullband_result(record) is record


def test_one_changed_sample_must_have_identical_first_last_indices():
    record = _result()
    record["comparison"]["first_changed_sample"] = 16015
    with pytest.raises(ResultContractError) as caught:
        validate_fullband_result(record)
    assert caught.value.code == "inconsistent_fullband_changed_interval"


def test_different_container_hashes_are_not_automatically_a_pcm_difference():
    record = _result(kind="identical")
    record["processed"]["sha256"] = "b" * 64
    assert validate_fullband_result(record) is record


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
def test_near_constant_low_variance_pcm_is_not_labeled_constant(rate):
    integers = np.full(2 * rate + 1, 32767, dtype=np.int16)
    integers[-1] = 32766
    audio = decode_wav(encode_wav(integers.astype(np.float64) / 32768, rate))
    comparison = measure_pair(audio, audio)
    record = _result(rate, "identical")
    metrics = measure_audio(audio)
    record.update(reference=audio.metadata(), processed=audio.metadata(),
                  reference_measurements=metrics, processed_measurements=deepcopy(metrics),
                  comparison=comparison, summary=derive_fullband_summary(comparison))
    assert comparison["correlation_status"] == "defined"
    assert validate_fullband_result(record) is record


@pytest.mark.parametrize("value", [None, [], True, 1, "private", {"status": True}, {"status": "approved"}])
def test_summary_helper_rejects_nonmeasurement_status(value):
    with pytest.raises(ResultContractError):
        derive_fullband_summary(value)


def test_summary_is_not_a_quality_gate_and_measured_difference_still_exit_zero():
    changed = _result()
    assert changed["comparison"]["unequal_sample_count"] == 1
    assert derive_fullband_summary(changed["comparison"]) == {
        "exit_code": 0, "meaning": "measurement_completed_no_quality_verdict", "quality_verdict": "not_assessed",
    }
    assert derive_fullband_summary(_result(kind="count_mismatch")["comparison"])["exit_code"] == 2


@pytest.mark.parametrize("value", [None, True, [], "private", 1, 1.0])
def test_result_rejects_wrong_root_type_without_echo(value):
    with pytest.raises(ResultContractError) as caught:
        validate_fullband_result(value)
    assert "private" not in str(caught.value)


@pytest.mark.parametrize("value", [float("nan"), float("inf"), float("-inf"), 10 ** 1000])
def test_nonfinite_or_overflow_is_rejected_even_hidden_in_extra_field(value):
    record = _result()
    record["private"] = value
    with pytest.raises(ResultContractError) as caught:
        validate_fullband_result(record)
    assert caught.value.code == "non_finite_metric"


def test_cycle_depth_and_tree_budget_fail_closed():
    record = _result()
    record["private"] = record
    with pytest.raises(ResultContractError) as caught:
        validate_fullband_result(record)
    assert caught.value.code == "result_structure_too_large"
    record = _result()
    record["private"] = [None] * 20000
    with pytest.raises(ResultContractError) as caught:
        validate_fullband_result(record)
    assert caught.value.code == "result_structure_too_large"


def test_maximum_native_record_all_changed_frames_fits_contract_and_loader_budget(tmp_path):
    reference = _pcm(48000, 30 * 48000)
    processed = decode_wav(encode_wav(-reference.samples, 48000))
    comparison = measure_pair(reference, processed)
    record = _result(48000)
    record.update(reference=reference.metadata(), processed=processed.metadata(),
                  reference_measurements=measure_audio(reference), processed_measurements=measure_audio(processed),
                  comparison=comparison, summary=derive_fullband_summary(comparison))
    assert len(comparison["changed_frames"]) == 300
    remaining = [20000]
    _json_tree(record, budget=remaining)
    assert remaining[0] > 0
    assert validate_fullband_result(record) is record
    data = json.dumps(record, allow_nan=False).encode("utf-8")
    assert len(data) < MAX_FULLBAND_RESULT_BYTES
    path = tmp_path / "maximum.json"
    path.write_bytes(data)
    assert load_fullband_result(path) == record


@pytest.mark.parametrize("data,code", [
    (b'{"schema_version":1,"schema_version":1}', "duplicate_json_key"),
    (b'{"private":NaN}', "non_finite_metric"), (b'{"private":Infinity}', "non_finite_metric"),
    (b'{"private":-Infinity}', "non_finite_metric"), (b'{"private":1e9999}', "non_finite_metric"),
    (b'\xff', "invalid_result_json"), (b'\xef\xbb\xbf{}', "invalid_result_json"),
    (b'{} extra', "invalid_result_json"), (b'[]', "invalid_fullband_result_type"),
    (b' ' * (MAX_FULLBAND_RESULT_BYTES + 1), "result_file_too_large"),
], ids=["duplicate", "nan", "infinity", "negative-infinity", "overflow", "utf8", "bom", "extra", "array", "size"])
def test_loader_rejects_nonfinite_duplicate_and_oversized_json(tmp_path, data, code):
    path = tmp_path / "private.json"
    path.write_bytes(data)
    with pytest.raises(ResultContractError) as caught:
        load_fullband_result(path)
    assert caught.value.code == code
    assert "private" not in str(caught.value)


@pytest.mark.parametrize("path", [None, 1, "private\0.json"])
def test_loader_read_errors_are_stable_and_nonprivate(path):
    with pytest.raises(ResultContractError) as caught:
        load_fullband_result(path)
    assert caught.value.code == "result_file_read_error"
    assert "private" not in str(caught.value)


def test_saved_loader_opens_only_result_not_artifacts(tmp_path, monkeypatch):
    record = _result()
    target = tmp_path / "result.json"
    target.write_text(json.dumps(record), encoding="utf-8")
    original = Path.open
    opened = []

    def guarded_open(path, *args, **kwargs):
        opened.append(path)
        assert path == target
        return original(path, *args, **kwargs)

    monkeypatch.setattr(Path, "open", guarded_open)
    assert load_fullband_result(target) == record
    assert opened == [target]


def test_schema_is_self_contained_bounded_and_explicit_about_semantic_limits():
    schema = json.loads(SCHEMA.read_text("utf-8"))
    record = _result()
    assert schema["$schema"].endswith("2020-12/schema")
    assert schema["additionalProperties"] is False
    assert set(schema["required"]) == set(record)
    assert schema["properties"]["engine"]["const"] == ENGINE
    assert "Python validation additionally" in schema["description"]
    assert "does not claim complete semantic parity" in schema["description"]
    assert schema["$defs"]["audioMeasurements"]["properties"]["frames"]["maxItems"] == 300
    assert schema["$defs"]["audioMeasurements"]["properties"]["bands"]["maxItems"] == 8
    assert schema["$defs"]["configuration"]["properties"]["band_edges_hz"]["const"] == list(BAND_EDGES_HZ)
    assert schema["$defs"]["configuration"]["properties"]["resampling"]["const"] is False
    assert schema["$defs"]["configuration"]["properties"]["auto_alignment"]["const"] is False

    def visit(value):
        if isinstance(value, dict):
            if "$ref" in value:
                assert value["$ref"].startswith("#/$defs/")
                assert value["$ref"][len("#/$defs/"):] in schema["$defs"]
            for item in value.values():
                visit(item)
        elif isinstance(value, list):
            for item in value:
                visit(item)

    visit(schema)
