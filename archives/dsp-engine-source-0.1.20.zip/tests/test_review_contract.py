"""Invented explanatory metadata over saved synthetic result contracts only."""

from copy import deepcopy
import importlib
import json
from pathlib import Path

import pytest

from audio_regression.check_policy import check_result
from audio_regression.result_contract import ResultContractError, validate_analysis_result


_ROOT = Path(__file__).resolve().parents[1]
_IDENTITIES = {
    1: ("result_contract", "validate_analysis_result",
        "constrained_edit_alignment_with_raw_anchors"),
    2: ("robust_result_contract", "validate_robust_analysis_result",
        "constrained_edit_alignment_with_pcm16_cancellation_revalidation"),
    3: ("context_result_contract", "validate_context_analysis_result",
        "constrained_edit_alignment_with_bounded_active_context_bridge"),
    4: ("instrument_result_contract", "validate_instrument_analysis_result",
        "raw_landmark_piecewise_alignment_with_global_uniqueness"),
    5: ("canonical_result_contract", "validate_canonical_analysis_result",
        "exact_canonical_pcm_resampling_with_unique_context"),
    6: ("repeat_result_contract", "validate_repeat_analysis_result",
        "full_copy_feasibility_with_global_source_exclusion"),
    7: ("compound_result_contract", "validate_compound_analysis_result",
        "interval_gain_quantized_compound_normal_proof"),
    8: ("compound_event_result_contract", "validate_compound_event_analysis_result",
        "exact_quantized_compound_event_forward_proof"),
    9: ("global_context_result_contract", "validate_global_context_analysis_result",
        "global_context_quantized_event_forward_proof"),
}


def _validator(version):
    module, function, _ = _IDENTITIES[version]
    return getattr(importlib.import_module("audio_regression." + module), function)


def _result(version=1, status="withheld", reason="insufficient_signal_variation"):
    value = json.loads((_ROOT / "tests" / "fixtures" / "results" /
                        "synthetic_basic_clean.json").read_text("utf-8"))
    value["engine"] = f"local_content_alignment_v{version}"
    value["analysis"]["method"] = _IDENTITIES[version][2]
    if status == "withheld":
        value.update(status=status, content_preservation_status=status,
                     reason_code=reason, events=None, diagnostics={})
        value.pop("alignment_segments")
    elif status == "error":
        value = {"schema_version": 1, "engine": value["engine"],
                 "status": "error", "reason_code": "file_read_error"}
    return value


def _stage(version, outcome="withheld", reason="insufficient_signal_variation", detail=None):
    return {"engine": f"local_content_alignment_v{version}", "outcome": outcome,
            "reason_code": reason, "detail_reason_code": detail}


def _review(value, availability="recorded", stages=None):
    value["review_diagnostics"] = {
        "schema_version": 1, "selected_engine": value["engine"],
        "result_status": "withheld", "primary_reason_code": value["reason_code"],
        "trace_availability": availability, "diagnostic_only": True,
        "fault_provenance_confirmed": False,
        "stages": stages if stages is not None else [_stage(int(value["engine"].rsplit("v", 1)[1]))],
    }
    return value


def _reject(value, expected):
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(value)
    assert caught.value.code == expected


@pytest.mark.parametrize("version", range(1, 10))
@pytest.mark.parametrize("status", ["analyzed", "withheld", "error"])
def test_legacy_result_is_unchanged_and_needs_no_review(version, status):
    value = _result(version, status)
    before = deepcopy(value)
    assert validate_analysis_result(value) is value
    assert _validator(version)(value) is value
    assert value == before


@pytest.mark.parametrize("version", range(1, 10))
def test_optional_review_validates_in_dispatch_and_direct_candidate_without_mutation(version):
    value = _review(_result(version), stages=[_stage(index) for index in range(1, version + 1)])
    before = deepcopy(value)
    assert validate_analysis_result(value) is value
    assert _validator(version)(value) is value
    assert value == before
    assert check_result(value) == check_result(_result(version))
    assert check_result(value)["exit_code"] == 2


@pytest.mark.parametrize("version", range(1, 10))
@pytest.mark.parametrize("availability", ["not_recorded", "unavailable"])
def test_missing_trace_never_invents_stages(version, availability):
    value = _review(_result(version), availability, [])
    assert validate_analysis_result(value) is value
    assert _validator(version)(value) is value


@pytest.mark.parametrize("version", range(1, 10))
@pytest.mark.parametrize("status", ["analyzed", "error"])
def test_explanation_is_forbidden_on_other_statuses(version, status):
    value = _review(_result(version, status))
    _reject(value, "review_diagnostics_not_supported_for_status")
    with pytest.raises(ResultContractError) as caught:
        _validator(version)(value)
    assert caught.value.code == "review_diagnostics_not_supported_for_status"


@pytest.mark.parametrize("availability", ["not_recorded", "unavailable"])
def test_nonrecorded_availability_rejects_fabricated_stage(availability):
    _reject(_review(_result(), availability), "inconsistent_review_trace_availability")


@pytest.mark.parametrize("field,value,code", [
    ("schema_version", True, "unsupported_review_diagnostics_version"),
    ("schema_version", 2, "unsupported_review_diagnostics_version"),
    ("selected_engine", "local_content_alignment_v2", "inconsistent_review_diagnostics_engine"),
    ("selected_engine", None, "inconsistent_review_diagnostics_engine"),
    ("result_status", "analyzed", "inconsistent_review_diagnostics_status"),
    ("primary_reason_code", "unexplained_local_signal_change", "inconsistent_review_diagnostics_reason"),
    ("primary_reason_code", "C:/private/trace.json", "invalid_reason_code"),
    ("primary_reason_code", "<script>", "invalid_reason_code"),
    ("trace_availability", "complete", "invalid_review_trace_availability"),
    ("trace_availability", None, "invalid_review_trace_availability"),
    ("diagnostic_only", False, "invalid_review_diagnostics_claim"),
    ("diagnostic_only", 1, "invalid_review_diagnostics_claim"),
    ("fault_provenance_confirmed", True, "invalid_review_diagnostics_claim"),
    ("fault_provenance_confirmed", 0, "invalid_review_diagnostics_claim"),
    ("stages", {}, "invalid_review_diagnostics_stages"),
    ("stages", [_stage(1)] * 10, "invalid_review_diagnostics_stages"),
])
def test_block_rejects_malformed_and_misleading_fields(field, value, code):
    result = _review(_result())
    result["review_diagnostics"][field] = value
    _reject(result, code)


@pytest.mark.parametrize("missing", [True, False])
def test_block_fields_are_exact(missing):
    result = _review(_result())
    if missing:
        result["review_diagnostics"].pop("diagnostic_only")
    else:
        result["review_diagnostics"]["trace_path"] = "private.wav"
    _reject(result, "invalid_review_diagnostics_structure")


@pytest.mark.parametrize("block", [None, [], "private content", True, 1])
def test_block_must_be_a_dictionary(block):
    result = _result()
    result["review_diagnostics"] = block
    _reject(result, "invalid_review_diagnostics_structure")


@pytest.mark.parametrize("reason", ["new_safe_future_reason", "a", "a" + "0" * 127])
def test_unknown_safe_primary_reason_preserves_legacy_core_compatibility(reason):
    result = _review(_result(reason=reason), "not_recorded", [])
    assert validate_analysis_result(result) is result


@pytest.mark.parametrize("outcome", ["not_attempted", "attempted_without_proof_detail"])
def test_unattempted_or_unrecorded_failure_details_must_be_null(outcome):
    result = _review(_result(9), stages=[_stage(9, outcome, None)])
    assert validate_analysis_result(result) is result
    result["review_diagnostics"]["stages"][0]["reason_code"] = "insufficient_signal_variation"
    _reject(result, "inconsistent_review_stage_reason")
    result["review_diagnostics"]["stages"][0]["reason_code"] = None
    result["review_diagnostics"]["stages"][0]["detail_reason_code"] = "insufficient_signal_variation"
    _reject(result, "inconsistent_review_stage_reason")


@pytest.mark.parametrize("field,value,code", [
    ("engine", "local_content_alignment_v10", "invalid_review_stage_engine"),
    ("engine", None, "invalid_review_stage_engine"),
    ("outcome", "passed", "invalid_review_stage_outcome"),
    ("outcome", None, "invalid_review_stage_outcome"),
    ("reason_code", None, "invalid_review_stage_reason"),
    ("reason_code", "unknown_safe_code", "invalid_review_stage_reason"),
    ("reason_code", "C:/private.wav", "invalid_review_stage_reason"),
    ("reason_code", ["insufficient_signal_variation"], "invalid_review_stage_reason"),
    ("detail_reason_code", "unknown_safe_code", "invalid_review_stage_detail_reason"),
    ("detail_reason_code", "<script>", "invalid_review_stage_detail_reason"),
    ("detail_reason_code", 1, "invalid_review_stage_detail_reason"),
])
def test_stage_fields_are_strict_allowlists(field, value, code):
    result = _review(_result(9))
    result["review_diagnostics"]["stages"][0][field] = value
    _reject(result, code)


@pytest.mark.parametrize("stages", [
    [_stage(2)], [_stage(1), _stage(1)], [_stage(2), _stage(1)],
])
def test_stage_order_uniqueness_and_selected_engine_bound(stages):
    result = _review(_result(1 if len(stages) == 1 else 9), stages=stages)
    _reject(result, "unordered_review_diagnostics_stages")


@pytest.mark.parametrize("missing", [True, False])
def test_stage_fields_are_exact(missing):
    result = _review(_result())
    if missing:
        result["review_diagnostics"]["stages"][0].pop("detail_reason_code")
    else:
        result["review_diagnostics"]["stages"][0]["probability"] = 1
    _reject(result, "invalid_review_stage_structure")


@pytest.mark.parametrize("stage", [None, [], "private content", True, 1])
def test_stage_must_be_a_dictionary(stage):
    _reject(_review(_result(), stages=[stage]), "invalid_review_stage_structure")


def test_core_restrictions_are_not_relaxed_by_an_explanation():
    result = _review(_result())
    result["complete_audio_approval"] = True
    _reject(result, "invalid_approval_claim")
    result["complete_audio_approval"] = False
    result["diagnostics"] = {"matched_normalized_rmse": float("nan")}
    _reject(result, "non_finite_metric")


def test_bounded_json_is_checked_before_copying_new_explanations():
    result = _review(_result())
    result["review_diagnostics"]["stages"] = result
    _reject(result, "result_structure_too_large")


def test_known_catalog_accepts_only_safe_bounded_codes():
    from audio_regression.result_contract import _reason
    from audio_regression.review_diagnostics import KNOWN_REASON_CODES
    assert KNOWN_REASON_CODES
    for code in KNOWN_REASON_CODES:
        _reason(code)


@pytest.mark.parametrize("field", ["reason_code", "detail_reason_code"])
@pytest.mark.parametrize("code", [
    "pcm16_cancellation_revalidated", "active_context_independently_revalidated",
    "whole_bracket_pcm16_residual_revalidated", "bounded_active_context_bridge_revalidated",
    "compound_gain_exact_witness", "supported_source_ncc_gate",
    "compound_event_exact_supported_witness", "global_context_exact_supported_witness",
])
def test_recorded_success_codes_cannot_claim_a_withheld_stage(field, code):
    result = _review(_result(9))
    result["review_diagnostics"]["stages"][0][field] = code
    expected = "invalid_review_stage_reason" if field == "reason_code" else "invalid_review_stage_detail_reason"
    _reject(result, expected)
    with pytest.raises(ResultContractError) as caught:
        _validator(9)(result)
    assert caught.value.code == expected


@pytest.mark.parametrize("code", [
    "pcm16_cancellation_revalidated", "active_context_independently_revalidated",
    "whole_bracket_pcm16_residual_revalidated", "bounded_active_context_bridge_revalidated",
    "compound_gain_exact_witness", "supported_source_ncc_gate",
    "compound_event_exact_supported_witness", "global_context_exact_supported_witness",
])
def test_existing_safe_primary_codes_remain_compatible_even_if_catalog_marks_success(code):
    result = _review(_result(reason=code), "not_recorded", [])
    assert validate_analysis_result(result) is result
    assert check_result(result)["exit_code"] == 2


@pytest.mark.parametrize("version", range(1, 10))
def test_stored_result_loader_accepts_new_optional_block_read_only(tmp_path, version):
    from audio_regression.result_contract import load_analysis_result
    result = _review(_result(version))
    path = tmp_path / "result.json"
    raw = json.dumps(result, ensure_ascii=False, allow_nan=False).encode("utf-8")
    path.write_bytes(raw)
    assert load_analysis_result(path) == result
    assert path.read_bytes() == raw


def test_analyze_cli_keeps_withheld_exit_and_serializes_review_without_reanalysis(tmp_path, monkeypatch, capsys):
    from audio_regression import cli
    result = _review(_result(9))
    monkeypatch.setattr(cli, "analyze_pair", lambda *a, **k: result)
    output = tmp_path / "result.json"
    assert cli.main(["analyze", "--engine", "v9", "--reference", "not-read.wav",
                     "--processed", "also-not-read.wav", "--output", str(output)]) == 2
    assert json.loads(capsys.readouterr().out) == result
    assert json.loads(output.read_text("utf-8")) == result


def test_malformed_review_never_clears_check_or_creates_cli_output(tmp_path, monkeypatch, capsys):
    from audio_regression import cli
    result = _review(_result(9))
    result["review_diagnostics"]["fault_provenance_confirmed"] = True
    summary = check_result(result)
    assert summary["exit_code"] == 2 and summary["contract_valid"] is False
    monkeypatch.setattr(cli, "analyze_pair", lambda *a, **k: result)
    output = tmp_path / "result.json"
    assert cli.main(["analyze", "--engine", "v9", "--reference", "not-read.wav",
                     "--processed", "also-not-read.wav", "--output", str(output)]) == 3
    error = json.loads(capsys.readouterr().out)
    assert error == {"schema_version": 1, "status": "error",
                     "reason_code": "invalid_review_diagnostics_claim"}
    assert not output.exists()


@pytest.mark.parametrize("version", range(1, 10))
def test_schema_explanation_fields_and_allowlists_match_runtime(version):
    from audio_regression.review_diagnostics import KNOWN_REASON_CODES
    schema = json.loads((_ROOT / "src" / "audio_regression" / "schemas" /
                         f"analysis-result-v{version}.schema.json").read_text("utf-8"))
    definitions = schema["$defs"]
    assert "review_diagnostics" in definitions["withheld"]["properties"]
    assert "review_diagnostics" not in definitions["withheld"]["required"]
    assert "review_diagnostics" not in definitions["analyzed"]["properties"]
    assert "review_diagnostics" not in definitions["cliError"]["properties"]
    block = definitions["reviewDiagnostics"]
    stage = definitions["reviewStage"]
    assert set(block["required"]) == set(_review(_result())["review_diagnostics"])
    assert set(stage["required"]) == set(_stage(1))
    assert block["additionalProperties"] is False and stage["additionalProperties"] is False
    assert block["properties"]["selected_engine"]["const"] == f"local_content_alignment_v{version}"
    assert block["properties"]["stages"]["maxItems"] == 9
    assert set(stage["properties"]["engine"]["enum"]) == {
        f"local_content_alignment_v{index}" for index in range(1, version + 1)}
    for field in ("reason_code", "detail_reason_code"):
        assert stage["properties"][field] == {
            "anyOf": [{"type": "null"}, {"$ref": "#/$defs/reviewReasonCode"}]}
    assert set(definitions["reviewReasonCode"]["enum"]) == set(KNOWN_REASON_CODES)


@pytest.mark.parametrize("version", range(1, 10))
def test_schema_conditions_cover_review_outcomes_and_missing_trace(version):
    from audio_regression.review_diagnostics import SUCCESS_REASON_CODES
    schema = json.loads((_ROOT / "src" / "audio_regression" / "schemas" /
                         f"analysis-result-v{version}.schema.json").read_text("utf-8"))
    block, stage = schema["$defs"]["reviewDiagnostics"], schema["$defs"]["reviewStage"]
    assert block["allOf"][0]["then"]["properties"]["stages"]["maxItems"] == 0
    condition = stage["allOf"][0]
    assert condition["if"]["properties"]["outcome"]["const"] == "withheld"
    reason_conditions = condition["then"]["properties"]["reason_code"]["allOf"]
    assert reason_conditions[0] == {"$ref": "#/$defs/reviewReasonCode"}
    assert set(reason_conditions[1]["not"]["enum"]) == set(SUCCESS_REASON_CODES)
    assert set(condition["then"]["properties"]["detail_reason_code"]["not"]["enum"]) == set(SUCCESS_REASON_CODES)
    for field in ("reason_code", "detail_reason_code"):
        assert condition["else"]["properties"][field] == {"type": "null"}
