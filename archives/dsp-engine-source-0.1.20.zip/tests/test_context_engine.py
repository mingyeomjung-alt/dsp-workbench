"""Owned synthetic development regressions for the opt-in context candidate."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pytest
from scipy.signal import chirp, resample_poly

import audio_regression.context_engine as candidate
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.engine import EngineConfig, EngineConfigError
from audio_regression.robust_engine import _revalidate_compound, analyze_buffers as analyze_v2


def _audio(values, rate=8000):
    return decode_wav(encode_wav(values, rate))


def _signal(rate=8000, seconds=6.0, seed=703281):
    rng = np.random.default_rng(seed)
    t = np.arange(round(rate * seconds)) / rate
    noise = np.convolve(rng.normal(size=len(t)), [.1, .2, .4, .2, .1], "same")
    envelope = np.interp(np.linspace(0, 60, len(t)), np.arange(61), rng.uniform(.2, 1., 61))
    wave = envelope * (noise + .2 * chirp(t, 207, seconds, 2930, method="quadratic"))
    return wave * (.23 / np.max(np.abs(wave)))


def _run(kind, first, last, offset=0):
    return {"kind": kind, "reference_start_frame": first, "reference_end_frame": last,
            "processed_start_frame": first + offset, "processed_end_frame": last + offset}


def _quiet_case(two=False, gain=.5):
    x = _audio(_signal()).samples.copy()
    rng = np.random.default_rng(916477)
    first, last = 160 * candidate.HOP, (282 if two else 241) * candidate.HOP
    x[first:last] = rng.integers(-3, 4, last - first) * candidate.PCM16_STEP
    y = _audio(x * gain).samples.copy()
    if two:
        runs = [_run("match", 0, 200), _run("compound", 200, 201),
                _run("match", 201, 240), _run("compound", 240, 241),
                _run("match", 241, 600)]
    else:
        runs = [_run("match", 0, 200), _run("compound", 200, 201), _run("match", 201, 600)]
    anchors = {index: {**run, "offset_samples": 0} for index, run in enumerate(runs) if run["kind"] == "match"}
    ordinary = {index: _revalidate_compound(index, runs, anchors, x, y, gain)
                for index, run in enumerate(runs) if run["kind"] == "compound"}
    return x, y, runs, anchors, ordinary


def _bridge(two=False, gain=.5):
    x, y, runs, anchors, ordinary = _quiet_case(two, gain)
    first, last = candidate._bounded_clusters(runs)[0]
    record = candidate._bridge_cluster(first, last, runs, anchors, ordinary, x, y, gain)
    return record, x, y, runs, anchors, ordinary


def _raw_path(runs):
    """Represent controlled cancellations as the original DP gap sequence."""
    raw = []
    for run in runs:
        if run["kind"] != "compound":
            raw.append(dict(run))
            continue
        first, last = run["reference_start_frame"], run["reference_end_frame"]
        pfirst, plast = run["processed_start_frame"], run["processed_end_frame"]
        raw.extend(({"kind": "delete", "reference_start_frame": first, "reference_end_frame": last,
                     "processed_start_frame": pfirst, "processed_end_frame": pfirst},
                    {"kind": "insert", "reference_start_frame": last, "reference_end_frame": last,
                     "processed_start_frame": pfirst, "processed_end_frame": plast}))
    return raw


def test_physical_policy_is_fixed_and_does_not_lower_activity_floor():
    assert candidate.MINIMUM_ACTIVITY == 8 / 32768
    assert candidate.MAXIMUM_BRIDGE_SAMPLES == 9600
    assert candidate.BRIDGE_POLICY["maximum_compound_duration_ms"] == 40
    assert candidate.BRIDGE_POLICY["context_duration_ms"] == 240
    assert candidate.BRIDGE_POLICY["first_active_window_only"] is True
    assert candidate.BRIDGE_POLICY["fixed_bracket_final_gain_reproof_required"] is True
    assert candidate.BRIDGE_POLICY["measured_rival_peak_evidence_required"] is True


@pytest.mark.parametrize("two", [False, True])
@pytest.mark.parametrize("gain", [.5, 1.0, 2.0])
def test_quiet_context_uses_bounded_independent_active_brackets(two, gain):
    record, x, y, runs, anchors, ordinary = _bridge(two, gain)
    assert any(prior["reason_code"] == "raw_context_below_quantization_activity_floor" for prior in ordinary.values())
    assert record["accepted"], record
    assert record["reason_code"] == "bounded_active_context_bridge_revalidated"
    assert len(record["scans"]) == 2
    assert all(scan["scanned_window_count"] > 1 for scan in record["scans"])
    for scan in record["scans"]:
        window = scan["selected"]
        assert window["located_processed_start_sample"] == window["processed_interval_samples"][0]
        assert min(window["processed_rms"], window["reference_rms_at_applied_gain"]) >= candidate.MINIMUM_ACTIVITY
        assert window["rival_peak_margin"] is not None and window["rival_peak_margin"] >= .03
    first, last = record["whole_bracket"]["reference_interval_samples"]
    assert first < runs[1]["reference_start_frame"] * candidate.HOP
    assert last > runs[record["last_run_index"]]["reference_end_frame"] * candidate.HOP
    assert record["whole_bracket"]["sample_count"] == last - first


@pytest.mark.parametrize("kind", ["delete", "insert", "large_compound", "offset_change"])
def test_clusters_never_cross_real_edits_or_unequal_axis_offsets(kind):
    runs = [_run("match", 0, 100), _run("compound", 100, 101),
            _run("match", 101, 130), _run("compound", 130, 131), _run("match", 131, 300)]
    if kind == "large_compound":
        runs[2]["kind"] = "compound"
    elif kind == "offset_change":
        runs[2]["processed_start_frame"] += 1
        runs[2]["processed_end_frame"] += 1
    else:
        runs[2]["kind"] = kind
    assert candidate._bounded_clusters(runs) == [(1, 1), (3, 3)]


def test_cluster_duration_budget_is_maximal_earliest_first_without_splitting_compounds():
    runs = [_run("match", 0, 100), _run("compound", 100, 101),
            _run("match", 101, 217), _run("compound", 217, 220),
            _run("match", 220, 221), _run("compound", 221, 222), _run("match", 222, 500)]
    assert candidate._bounded_clusters(runs) == [(1, 3), (5, 5)]
    runs[1]["reference_end_frame"] = runs[1]["processed_end_frame"] = 105
    assert candidate._bounded_clusters(runs)[0] == (3, 5)


@pytest.mark.parametrize("change", ["missing_anchor", "different_anchor", "wrong_coordinates", "noncontiguous"])
def test_bridge_proof_requires_original_exact_same_offset_contiguous_outer_anchors(change):
    x, y, runs, anchors, ordinary = _quiet_case()
    if change == "missing_anchor":
        anchors.pop(2)
    elif change == "different_anchor":
        anchors[2]["offset_samples"] = 1
    elif change == "wrong_coordinates":
        runs[2]["processed_start_frame"] += 1
        runs[2]["processed_end_frame"] += 1
    else:
        runs[2]["reference_start_frame"] += 1
        runs[2]["processed_start_frame"] += 1
    assert not candidate._bridge_cluster(1, 1, runs, anchors, ordinary, x, y, .5)["accepted"]


@pytest.mark.parametrize("edge", ["start", "end"])
def test_bridge_does_not_add_file_edge_repair(edge):
    x, y, runs, anchors, ordinary = _quiet_case()
    if edge == "start":
        runs = runs[1:]
        anchors, ordinary = {1: {**runs[1], "offset_samples": 0}}, {0: ordinary[1]}
        index = 0
    else:
        runs = runs[:-1]
        anchors, ordinary = {0: {**runs[0], "offset_samples": 0}}, {1: ordinary[1]}
        index = 1
    record = candidate._bridge_cluster(index, index, runs, anchors, ordinary, x, y, .5)
    assert record["reason_code"] == "bridge_is_not_internal_and_both_sided"


@pytest.mark.parametrize("reason", ["suspicious_samples_exceed_pcm16_error_budget", "raw_context_correlation_not_supported",
                                     "independent_anchor_offsets_not_equal", "not_short_balanced_cancellation"])
def test_only_ordinary_low_activity_failure_can_enter_fallback(reason):
    x, y, runs, anchors, ordinary = _quiet_case()
    ordinary[1]["reason_code"] = reason
    assert candidate._bridge_cluster(1, 1, runs, anchors, ordinary, x, y, .5)["reason_code"] == "ordinary_failure_is_not_only_low_context_activity"


def test_active_context_window_is_first_not_best_correlation():
    x = _audio(_signal()).samples.copy()
    y = x.copy()
    first = 200 * candidate.HOP
    y[first - candidate.CONTEXT_SAMPLES:first] *= -1
    selected, scan = candidate._select_bracket("before", first, first + candidate.HOP,
                                               _run("match", 0, 200), 0, x, y, 1.)
    assert selected is not None and not selected["accepted"]
    assert scan["scanned_window_count"] == 1
    assert scan["reason_code"] == "first_active_context_correlation_not_supported"
    # Earlier windows would match, but the algorithm must not cherry-pick one.
    assert candidate._corr(x[:candidate.CONTEXT_SAMPLES], y[:candidate.CONTEXT_SAMPLES]) > .99


def test_periodic_active_window_is_not_unique_context_evidence():
    t = np.arange(48000) / 8000
    x = .1 * np.sin(2 * np.pi * 400 * t)
    first = 200 * candidate.HOP
    selected, scan = candidate._select_bracket("before", first, first + candidate.HOP,
                                               _run("match", 0, 200), 0, x, x, 1.)
    assert selected is not None and not selected["accepted"]
    assert scan["scanned_window_count"] == 1
    assert scan["reason_code"] == "first_active_context_not_unique_at_proven_offset"


def test_exact_240ms_outer_match_cannot_supply_measured_rival_evidence():
    x = _audio(_signal()).samples.copy()
    first, last = 176 * candidate.HOP, 200 * candidate.HOP
    window = {"side": "before", "reference_interval_samples": [first, last]}
    record = candidate._check_selected_window(window, _run("match", 176, 200), 0, x, x, 1.)
    assert record["correlation"] > .99
    assert record["located_processed_start_sample"] == first
    assert record["rival_peak_margin"] is None
    assert not record["accepted"]
    assert record["reason_code"] == "first_active_context_not_unique_at_proven_offset"


def test_no_active_bracket_outside_1200ms_search_extent():
    x, y, runs, anchors, ordinary = _quiet_case()
    first = runs[1]["reference_start_frame"] * candidate.HOP
    x[first - candidate.MAXIMUM_BRIDGE_SAMPLES:first] = candidate.PCM16_STEP
    y = _audio(x * .5).samples.copy()
    record = candidate._bridge_cluster(1, 1, runs, anchors, ordinary, x, y, .5)
    assert record["reason_code"] == "no_active_context_within_bounded_original_match"
    assert record["scans"][0]["selected"] is None


@pytest.mark.parametrize("change", ["substitution", "dropout", "impulse", "drift"])
def test_every_intermediate_match_sample_in_a_cluster_is_checked(change):
    x, y, runs, anchors, ordinary = _quiet_case(two=True)
    point = 224 * candidate.HOP
    if change == "substitution":
        y[point:point + 200] = .01
    elif change == "dropout":
        # Drop a quiet but identifiable patch at greater than the physical
        # PCM16 residual allowance. It is not permitted merely for being quiet.
        x[point:point + 200] = 20 * candidate.PCM16_STEP
        y[point:point + 200] = 0
    elif change == "impulse":
        y[point] += 20 * candidate.PCM16_STEP
    else:
        y[point:point + 200] = np.roll(x[point:point + 200], 2) * .5 + 10 * candidate.PCM16_STEP
    record = candidate._bridge_cluster(1, 3, runs, anchors, ordinary, x, y, .5)
    assert not record["accepted"]
    assert record["reason_code"] == "whole_bracket_samples_exceed_pcm16_error_budget"


def test_raw_bracket_boundary_discontinuity_remains_blocked():
    record, x, y, _, _, _ = _bridge()
    assert record["accepted"]
    first, last = record["whole_bracket"]["reference_interval_samples"]
    y[first - 1] += 20 * candidate.PCM16_STEP
    proof = candidate._whole_bracket_proof(first, last, 0, x, y, .5)
    assert proof["reason_code"] == "whole_bracket_boundary_continuity_not_supported"


@pytest.mark.parametrize("change", ["gain", "offset", "missing_anchor"])
def test_final_gain_and_merged_anchor_must_reprove_same_fixed_brackets(change):
    record, x, y, runs, _, _ = _bridge()
    assert record["accepted"]
    final_anchors = {0: {**_run("match", 0, 600), "offset_samples": 0}}
    gain = .5
    if change == "gain":
        gain = .52
    elif change == "offset":
        final_anchors[0]["offset_samples"] = 1
    else:
        final_anchors.clear()
    old_coordinates = [scan["selected"]["reference_interval_samples"][:] for scan in record["scans"]]
    proof = candidate._final_bridge_proof(record, runs, final_anchors, x, y, gain)
    assert not proof["accepted"]
    assert [scan["selected"]["reference_interval_samples"] for scan in record["scans"]] == old_coordinates


@pytest.mark.parametrize("two", [False, True])
def test_complete_analysis_rechecks_final_gain_and_new_anchors_without_mutating_old_engines(monkeypatch, two):
    x, y, runs, _, _ = _quiet_case(two)
    monkeypatch.setattr(candidate, "edit_align", lambda *args: {"status": "aligned", "runs": _raw_path(runs),
                                                               "normalized_path_cost": .01})
    reference, processed = _audio(x), _audio(y)
    before = reference.samples.copy(), processed.samples.copy()
    result, trace = candidate.analyze_buffers_with_trace(reference, processed, EngineConfig(allow_gain=True))
    assert result["status"] == "analyzed", (result, trace)
    assert result["engine"] == candidate.ENGINE
    assert result["analysis"]["method"] == candidate.METHOD
    assert result["events"] == []
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    assert len(trace["bridge_attempts"]) == 1
    assert trace["bridge_attempts"][0]["final_gain_reproof"]["accepted"] is True
    assert trace["reference_sha256"] == reference.sha256
    assert trace["processed_sha256"] == processed.sha256
    np.testing.assert_array_equal(reference.samples, before[0])
    np.testing.assert_array_equal(processed.samples, before[1])
    json.dumps(result, allow_nan=False)
    json.dumps(trace, allow_nan=False)


def test_fresh_merged_anchor_with_changed_offset_is_withheld_in_full_flow(monkeypatch):
    x, y, runs, _, _ = _quiet_case()
    monkeypatch.setattr(candidate, "edit_align", lambda *args: {"status": "aligned", "runs": _raw_path(runs),
                                                               "normalized_path_cost": .01})
    trusted = candidate._trusted_matches
    calls = []
    def changed_anchor(*args):
        anchors, gain, reason = trusted(*args)
        calls.append(1)
        if len(calls) == 2:
            next(iter(anchors.values()))["offset_samples"] += 1
        return anchors, gain, reason
    monkeypatch.setattr(candidate, "_trusted_matches", changed_anchor)
    result, trace = candidate.analyze_buffers_with_trace(_audio(x), _audio(y), EngineConfig(allow_gain=True))
    assert result["status"] == "withheld"
    assert result["reason_code"] == "active_context_bridge_final_gain_reproof_failed"
    assert trace["bridge_attempts"][0]["final_gain_reproof"]["reason_code"] == "fresh_merged_anchor_does_not_have_exact_proven_offset"


@pytest.mark.parametrize("kind", ["delete", "repeat"])
@pytest.mark.parametrize("length_ms", [200, 400, 750])
def test_real_supported_edits_preserve_v2_event_geometry(kind, length_ms):
    x = _audio(_signal()).samples
    first, last = 1700 * 8, (1700 + length_ms) * 8
    edited = np.concatenate((x[:first], x[last:])) if kind == "delete" else np.concatenate((x[:last], x[first:last], x[last:]))
    reference, processed = _audio(x), _audio(edited)
    old, new = analyze_v2(reference, processed), candidate.analyze_buffers(reference, processed)
    assert old["status"] == new["status"] == "analyzed"
    assert old["events"] == new["events"]
    assert len(new["events"]) == 1
    assert new["events"][0]["type"] == kind


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
@pytest.mark.parametrize("gain", [.5, 1.0])
def test_owned_signal_declared_gain_and_resampling_keep_normal_flow(rate, gain):
    reference = _audio(_signal(rate), rate)
    divisor = np.gcd(rate, 8000)
    processed = _audio(resample_poly(reference.samples, 8000 // divisor, rate // divisor) * gain)
    result = candidate.analyze_buffers(reference, processed, EngineConfig(allow_gain=True, allow_resampling=True))
    assert result["status"] == "analyzed"
    assert result["events"] == []


@pytest.mark.parametrize("change", ["substitution", "dropout", "unrelated_insert", "drift", "periodic"])
def test_unsupported_signal_changes_and_ambiguity_do_not_become_clear(change):
    x = _audio(_signal()).samples.copy()
    y = x.copy()
    first, last = 1700 * 8, 2100 * 8
    if change == "substitution":
        y[first:last] = _signal(seed=887220)[first:last]
    elif change == "dropout":
        y[first:last] = 0
    elif change == "unrelated_insert":
        y = np.concatenate((x[:first], _signal(seed=814092)[first:last], x[first:]))
    elif change == "drift":
        y = resample_poly(x, 101, 100)
    else:
        t = np.arange(len(x)) / 8000
        x = y = .2 * np.sin(2 * np.pi * 440 * t)
    result, trace = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"
    assert result["events"] is None
    assert trace["withheld_branch"] == result["reason_code"]


@pytest.mark.parametrize("config", [1, {}, False, "basic", EngineConfig(profile="telephone")])
def test_unsupported_configuration_is_rejected_before_signal_analysis(config):
    with pytest.raises(EngineConfigError):
        candidate.analyze_buffers(_audio(_signal()), _audio(_signal()), config)


def test_gain_or_resampling_requires_declaration():
    original = _audio(_signal())
    gain_result = candidate.analyze_buffers(original, _audio(original.samples * .5))
    assert gain_result["status"] == "withheld"
    transformed = _audio(resample_poly(original.samples, 2, 1), 16000)
    result = candidate.analyze_buffers(original, transformed)
    assert result["reason_code"] == "resampling_not_declared"


def test_file_hashes_stay_exact_and_trace_contains_no_private_payload(tmp_path: Path):
    reference, processed = encode_wav(_signal(), 8000), encode_wav(_signal() * .5, 8000)
    first, second = tmp_path / "reference.wav", tmp_path / "processed.wav"
    first.write_bytes(reference)
    second.write_bytes(processed)
    result, trace = candidate.analyze_wavs_with_trace(first, second, EngineConfig(allow_gain=True))
    assert result["status"] == "analyzed"
    assert first.read_bytes() == reference and second.read_bytes() == processed
    assert trace["reference_sha256"] == hashlib.sha256(reference).hexdigest()
    assert trace["processed_sha256"] == hashlib.sha256(processed).hexdigest()
    assert trace["engine"] == "bounded_active_context_trace_v1"
    assert all(len(trace[key]) <= 6001 for key in ("raw_runs", "coalesced_runs", "revalidated_runs", "revalidations", "bridge_attempts"))
    assert all(key not in trace for key in ("samples", "reference_path", "processed_path", "ground_truth", "scenario"))
