"""Owned-signal tests for the bounded feasible-copy candidate.

No audio from a sealed evaluation or an external processor trial is read here.
The harmonic formula is regenerated from its published development recipe.
The primary end-to-end cases use real raw waveform comparisons, not injected
similarity scores. The explicitly labelled policy tests inject only a baseline
withholding decision to prove that a forbidden rescue is not attempted.
"""

from __future__ import annotations

from copy import deepcopy
import json

import numpy as np
import pytest
from scipy.signal import resample_poly

from audio_regression import canonical_engine
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.engine import EngineConfig, EngineConfigError, _corr
import audio_regression.repeat_engine as candidate


RATE = 8000
SOURCE_START = 2640 * 8
COPY_LENGTH = 400 * 8


def _audio(values: np.ndarray, rate: int = RATE):
    return decode_wav(encode_wav(values, rate))


def _owned_harmonic() -> np.ndarray:
    """Regenerate a development recipe; do not open its saved trial files."""
    rate = 16000
    time = np.arange(rate * 8, dtype=float) / rate
    frequency = 311 + 17 * time + 2.3 * np.sin(2 * np.pi * .61 * time)
    phase = 2 * np.pi * np.cumsum(frequency) / rate
    envelope = (.57 + .13 * np.sin(2 * np.pi * .29 * time)
                + .09 * np.sin(2 * np.pi * .11 * time + .8))
    values = envelope * (np.sin(phase) + .27 * np.sin(2 * phase + .3)
                         + .13 * np.sin(3 * phase + .9))
    raw = _audio(values * (.28 / np.max(np.abs(values))), rate)
    gained = _audio(raw.samples * .5, rate)
    downsampled = _audio(resample_poly(gained.samples, 1, 2))
    return _audio(np.concatenate((np.zeros(1920), downsampled.samples))).samples


def _owned_unique_context() -> np.ndarray:
    """Noise is only an adversarial-test fixture, not a performance corpus."""
    return _audio(.10 * np.random.default_rng(630124).normal(size=8 * RATE)).samples.copy()


def _insert(reference: np.ndarray, payload: np.ndarray, source_start: int = SOURCE_START):
    boundary = source_start + len(payload)
    return _audio(np.concatenate((reference[:boundary], payload, reference[boundary:])))


def _checked(reference, processed, settings: EngineConfig | None = None):
    original_left, original_right = reference.samples.copy(), processed.samples.copy()
    result, trace = candidate.analyze_buffers_with_trace(reference, processed, settings)
    assert result["engine"] == "local_content_alignment_v6"
    assert result["analysis"]["method"] == "full_copy_feasibility_with_global_source_exclusion"
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    np.testing.assert_array_equal(reference.samples, original_left)
    np.testing.assert_array_equal(processed.samples, original_right)
    json.dumps(result, allow_nan=False)
    json.dumps(trace, allow_nan=False)
    return result, trace


def _assert_repeat(result: dict, start: int, length: int):
    assert result["status"] == "analyzed", result
    assert result["reason_code"] is None
    assert len(result["events"]) == 1
    event = result["events"][0]
    assert event["type"] == "repeat"
    assert event["reference_source_interval_ms"] == pytest.approx(
        [start / 8, (start + length) / 8], abs=20)
    assert event["processed_added_interval_ms"] == pytest.approx(
        [(start + length) / 8, (start + 2 * length) / 8], abs=20)
    assert event["copy_interval_convention"] == "canonical_later_adjacent_copy_not_edit_provenance"


def test_complete_owned_harmonic_copy_is_rescued_by_a_unique_feasible_geometry():
    reference = _audio(_owned_harmonic())
    payload = reference.samples[SOURCE_START:SOURCE_START + COPY_LENGTH].copy()
    processed = _insert(reference.samples, payload)
    baseline, _ = canonical_engine.analyze_buffers_with_trace(reference, processed)
    assert baseline["status"] == "withheld", baseline
    assert baseline["reason_code"] == "insertion_not_supported_as_repetition", baseline
    result, trace = _checked(reference, processed)
    _assert_repeat(result, SOURCE_START, COPY_LENGTH)
    assert trace["repeat_attempted"] is True
    assert trace["feasible_candidate_count"] == 1
    assert 1 <= trace["candidate_proofs_attempted"] <= 1000
    assert trace["proof_path"] != "preserved_v5_result"


@pytest.mark.parametrize("kind", (
    "unrelated", "tail_counterfeit", "head_and_tail_counterfeit", "reversed", "silent",
))
def test_unproved_added_payload_cannot_be_reported_as_a_copy(kind):
    reference = _audio(_owned_harmonic())
    original = reference.samples[SOURCE_START:SOURCE_START + COPY_LENGTH].copy()
    if kind == "unrelated":
        payload = .1 * np.random.default_rng(74126).normal(size=COPY_LENGTH)
    elif kind == "tail_counterfeit":
        payload = original.copy()
        amplitude = .8 * np.sqrt(np.mean(original ** 2))
        payload[-160:] = amplitude * np.random.default_rng(28546).normal(size=160)
        # The high average NCC cannot excuse twenty ms of unrelated tail.
        assert .90 < _corr(original, payload) < .99
    elif kind == "head_and_tail_counterfeit":
        payload = original.copy()
        amplitude = .8 * np.sqrt(np.mean(original ** 2))
        counterfeit = amplitude * np.random.default_rng(93624).normal(size=160)
        payload[:80], payload[-80:] = counterfeit[:80], counterfeit[-80:]
        assert .90 < _corr(original, payload) < .99
    elif kind == "reversed":
        payload = original[::-1].copy()
    else:
        payload = np.zeros(COPY_LENGTH)
    result, trace = _checked(reference, _insert(reference.samples, payload))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None
    assert result["reason_code"] is not None
    assert trace["candidate_proofs_attempted"] <= 1000


@pytest.mark.parametrize("other_gain", (.5, 1.0))
def test_inherited_v5_repeat_does_not_claim_new_global_source_exclusion(other_gain):
    # Compatibility limitation: the old spectral path already reports this
    # real adjacent copy from its retained context, despite another occurrence
    # elsewhere. v6 preserves it; its NEW global source exclusion never ran.
    # The direct new-proof tests below separately require both rivals to fail.
    values = _owned_unique_context()
    start = 2 * RATE
    payload = values[start:start + COPY_LENGTH].copy()
    values[5 * RATE:5 * RATE + COPY_LENGTH] = payload * other_gain
    reference = _audio(values)
    processed = _insert(reference.samples, payload, start)
    settings = EngineConfig(allow_gain=True)
    baseline, _ = canonical_engine.analyze_buffers_with_trace(reference, processed, settings)
    assert baseline["status"] == "analyzed", baseline
    result, trace = _checked(reference, processed, settings)
    for field in ("status", "events", "alignment_segments", "diagnostics", "reason_code"):
        assert result[field] == baseline[field]
    assert trace["proof_path"] == "preserved_v5_result"
    assert trace["repeat_attempted"] is False
    assert trace["candidate_proofs_attempted"] == 0
    assert trace["feasible_candidate_count"] == 0


def test_identical_periodic_copy_with_unique_surrounding_context_stays_ambiguous():
    values = _owned_unique_context()
    time = np.arange(RATE * 2) / RATE
    values[3 * RATE:5 * RATE] = .18 * np.sin(2 * np.pi * 400 * time)
    reference = _audio(values)
    start = 4 * RATE
    payload = reference.samples[start:start + COPY_LENGTH]
    result, trace = _checked(reference, _insert(reference.samples, payload, start))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None


@pytest.mark.parametrize("kind", ("normal", "delete", "repeat"))
def test_successful_v5_results_are_preserved_instead_of_reproved(kind):
    reference = _audio(_owned_unique_context())
    if kind == "normal":
        processed = _audio(reference.samples)
    elif kind == "delete":
        processed = _audio(np.concatenate((reference.samples[:SOURCE_START],
                                          reference.samples[SOURCE_START + COPY_LENGTH:])))
    else:
        processed = _insert(reference.samples,
                            reference.samples[SOURCE_START:SOURCE_START + COPY_LENGTH])
    baseline, _ = canonical_engine.analyze_buffers_with_trace(reference, processed)
    assert baseline["status"] == "analyzed", baseline
    result, trace = _checked(reference, processed)
    for field in ("status", "events", "alignment_segments", "diagnostics", "reason_code",
                  "content_preservation_status"):
        assert result[field] == baseline[field]
    assert trace["proof_path"] == "preserved_v5_result"
    assert trace["repeat_attempted"] is False
    assert trace["candidate_proofs_attempted"] == 0


@pytest.mark.parametrize("reason", (
    "resampling_not_declared", "non_silent_file_edge_change",
    "event_outside_supported_duration", "initial_delay_outside_declared_search",
    "cumulative_edit_shift_outside_budget", "insufficient_signal_variation",
    "raw_landmark_unexplained_local_residual",
))
def test_unit_policy_withholding_is_not_rescued(monkeypatch, reason):
    # Unit-only injected baseline decision. No raw similarity is replaced.
    reference = _audio(_owned_unique_context())
    baseline, old_trace = canonical_engine.analyze_buffers_with_trace(reference, reference)
    forced = deepcopy(baseline)
    forced.update(status="withheld", content_preservation_status="withheld",
                  reason_code=reason, events=None)
    forced.pop("alignment_segments", None)
    monkeypatch.setattr(candidate.canonical_engine, "analyze_buffers_with_trace",
                        lambda *args: (deepcopy(forced), deepcopy(old_trace)))
    result, trace = _checked(reference, reference)
    assert result["status"] == "withheld"
    assert result["reason_code"] == reason
    assert trace["repeat_attempted"] is False
    assert trace["candidate_proofs_attempted"] == 0
    assert trace["feasible_candidate_count"] == 0


def test_nonbasic_profile_remains_rejected_before_candidate_analysis():
    reference = _audio(_owned_unique_context())
    with pytest.raises(EngineConfigError):
        candidate.analyze_buffers_with_trace(reference, reference, EngineConfig(profile="telephone"))


def test_undeclared_rate_conversion_remains_a_policy_hold_without_repeat_search():
    reference = _audio(_owned_harmonic())
    processed = _audio(resample_poly(reference.samples, 2, 1), 16000)
    result, trace = _checked(reference, processed)
    assert result["status"] == "withheld", (result, trace)
    assert result["reason_code"] == "resampling_not_declared"
    assert trace["repeat_attempted"] is False
    assert trace["candidate_proofs_attempted"] == 0


def test_candidate_positions_cover_the_old_two_neighborhoods_gap_and_stay_bounded():
    approximate, length, total = 3040 * 8, 12000, 8 * RATE
    positions = list(candidate._candidate_positions(approximate, length, total))
    expected = list(range(max(0, approximate - length - 960),
                          min(total - 2 * length, approximate + 960) + 1, 8))
    assert positions == expected
    # This midpoint was outside both former 120 ms neighborhoods.
    midpoint = approximate - length // 2
    assert midpoint in positions
    assert all(0 <= first and first + 2 * length <= total for first in positions)


@pytest.mark.parametrize("other_gain", (.5, 1.0))
def test_global_source_exclusion_checks_off_grid_gain_equivalent_rivals(other_gain):
    values = _owned_unique_context()
    start, other = 2 * RATE, 5 * RATE + 3  # A distant non-8-sample-grid rival.
    payload = values[start:start + COPY_LENGTH].copy()
    values[other:other + COPY_LENGTH] = payload * other_gain
    budget = candidate._ProofBudget()
    assert candidate._source_unique(values, payload, start, True, budget) is False
    assert 1 <= budget.used <= candidate.MAX_PROOFS


def test_global_source_exclusion_removes_dc_before_rolling_variance_arithmetic():
    # Unit-level double arrays deliberately stress cancellation, not PCM audio.
    values = .9 + 1e-5 * np.random.default_rng(76031).normal(size=6 * RATE)
    start = 2 * RATE
    payload = values[start:start + COPY_LENGTH].copy()
    assert candidate._copy_fit(values[start:start + COPY_LENGTH], payload, False) is not None
    budget = candidate._ProofBudget()
    assert candidate._source_unique(values, payload, start, False, budget) is True


def test_ill_conditioned_source_windows_cannot_certify_global_exclusion():
    values = _owned_unique_context()
    values[:COPY_LENGTH + 160] = .35
    start = 4 * RATE
    payload = values[start:start + COPY_LENGTH].copy()
    budget = candidate._ProofBudget()
    assert candidate._source_unique(values, payload, start, False, budget) is False


def test_full_copy_residual_not_average_ncc_rejects_counterfeit_tail():
    values = _owned_unique_context()
    payload = values[SOURCE_START:SOURCE_START + COPY_LENGTH].copy()
    changed = payload.copy()
    changed[-160:] = .08 * np.random.default_rng(94871).normal(size=160)
    assert _corr(payload, changed) > .90
    assert candidate._copy_fit(payload, changed, False) is None


def test_proof_budget_never_exceeds_one_thousand_checks():
    assert candidate.MAX_PROOFS == 1000
    budget = candidate._ProofBudget()
    for _ in range(1000):
        budget.take()
    assert budget.used == 1000
    with pytest.raises(candidate._BudgetExceeded):
        budget.take()
    assert budget.used == 1000


def _real_eligible_pair():
    reference = _audio(_owned_harmonic())
    payload = reference.samples[SOURCE_START:SOURCE_START + COPY_LENGTH]
    return reference, _insert(reference.samples, payload)


def test_unit_two_distinct_feasible_geometries_are_not_resolved_by_ranking(monkeypatch):
    # Unit injection of proof outcomes only: exercise the final uniqueness gate.
    # The real E2E test above proves the raw signal path without this injection.
    reference, processed = _real_eligible_pair()
    points = (SOURCE_START, SOURCE_START + candidate.POSITION_TOLERANCE + 8)
    monkeypatch.setattr(candidate, "_candidate_positions", lambda *args: points)
    def two_proved_geometries(x, y, first, length, before, after, groups, settings, budget):
        budget.take()
        return {"source": first}
    monkeypatch.setattr(candidate, "_prove_copy_candidate", two_proved_geometries)
    result, trace = _checked(reference, processed)
    assert result["status"] == "withheld"
    assert result["reason_code"] == "repeat_feasibility_ambiguous_geometry"
    assert result["events"] is None
    assert trace["repeat_attempted"] is True
    assert trace["feasible_candidate_count"] == 2
    assert trace["candidate_proofs_attempted"] == 2


@pytest.mark.parametrize("early_feasible", (False, True))
def test_unit_budget_exhaustion_stays_withheld_even_after_one_feasible_proof(monkeypatch, early_feasible):
    # Unit injection of proof outcomes: exhaustive exclusion must finish before
    # a single early result can become an analyzed event.
    reference, processed = _real_eligible_pair()
    monkeypatch.setattr(candidate, "_candidate_positions", lambda *args: range(1001))
    def consume_budget(x, y, first, length, before, after, groups, settings, budget):
        budget.take()
        return {"source": SOURCE_START} if early_feasible and first == 0 else None
    monkeypatch.setattr(candidate, "_prove_copy_candidate", consume_budget)
    result, trace = _checked(reference, processed)
    assert result["status"] == "withheld"
    assert result["reason_code"] == "repeat_feasibility_proof_budget_exceeded"
    assert result["events"] is None
    assert trace["repeat_attempted"] is True
    assert trace["candidate_proofs_attempted"] == 1000
    assert trace["feasible_candidate_count"] == int(early_feasible)

