"""Fresh saved-output development audits; no final evaluation re-scoring."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import struct
from types import SimpleNamespace

import pytest

from audio_regression import saved_pipeline as runner
from audio_regression.audio import decode_wav, read_wav
from audio_regression.check_policy import check_result
from audio_regression.fixtures import generate_case
from audio_regression.pipeline_transforms import execute_stage
from audio_regression.result_contract import load_analysis_result


@pytest.fixture
def files(tmp_path):
    raw = generate_case("clean", seed=655144).reference_wav
    for name in ("private-source.wav", "private-first.wav", "private-second.wav", "private-third.wav"):
        (tmp_path / name).write_bytes(raw)
    return tmp_path, raw


def _manifest(root, count=2, *, labels=None, declaration=None):
    declaration = declaration or {"allow_gain": False, "allow_resampling": False}
    names = ["private-first.wav", "private-second.wav", "private-third.wav"]
    value = {"schema_version": 1, "source": "private-source.wav", "stages": [
        {"label": labels[i] if labels else f"Stage {i + 1}", "output": names[i],
         "declaration": dict(declaration)} for i in range(count)]}
    path = root / "manifest.json"
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    return path, value


def _clear(reference, processed, **configuration):
    result = deepcopy(load_analysis_result(Path(__file__).resolve().parents[1]
        / "tests/fixtures/results/synthetic_basic_clean.json"))
    result.update(reference=read_wav(reference).metadata(), processed=read_wav(processed).metadata(),
                  configuration=configuration)
    return result


def _withheld(reference, processed, **configuration):
    result = _clear(reference, processed, **configuration)
    result.pop("alignment_segments")
    result.update(status="withheld", events=None, diagnostics={},
                  content_preservation_status="withheld", reason_code="ambiguous_alignment")
    return result


def _contract(result):
    from audio_regression.saved_pipeline_contract import validate_saved_pipeline_result
    assert validate_saved_pipeline_result(result) is result
    for field in ("complete_audio_approval", "commercial_performance_validated", "network_used",
                  "fault_provenance_confirmed", "caller_order_verified"):
        assert result[field] is False


def test_actual_saved_outputs_are_compared_and_copied_without_processing(files):
    root, raw = files
    audio = decode_wav(raw)
    gain_raw, _ = execute_stage(audio, {"kind": "gain", "gain_db": -3})
    (root / "private-first.wav").write_bytes(gain_raw)
    (root / "private-second.wav").write_bytes(gain_raw)
    manifest, value = _manifest(root)
    value["stages"][0]["declaration"]["allow_gain"] = True
    manifest.write_text(json.dumps(value), encoding="utf-8")
    output = root / "new" / "audit"
    result = runner.audit_saved_pipeline(manifest, output)
    assert result["status"] == "completed"
    assert result["summary"] == {"gate_state": "clear_supported_temporal_check", "exit_code": 0,
        "first_concern": None, "planned_stage_count": 2, "checked_stage_count": 2, "failed_stage": None}
    assert result["input_recheck"] == {"status": "unchanged", "file_indices": []}
    assert (output / "inputs/000.wav").read_bytes() == raw
    assert (output / "inputs/001.wav").read_bytes() == gain_raw
    assert (output / "inputs/002.wav").read_bytes() == gain_raw
    assert (root / "private-source.wav").read_bytes() == raw
    assert result["source"]["sha256"] == hashlib.sha256(raw).hexdigest()
    assert result["end_to_end"]["analysis"]["configuration"] == {
        "profile": "basic", "allow_gain": True, "allow_resampling": False, "max_delay_ms": 1000.0}
    saved = (output / "audit_result.json").read_text("utf-8")
    assert json.loads(saved) == result
    assert "private-source" not in saved and str(root) not in saved
    _contract(result)


def test_actual_deletion_is_first_observed_at_assembly_and_stays_after_later_clear(files):
    root, raw = files
    changed, _ = execute_stage(decode_wav(raw), {"kind": "split_join", "segment_ms": 400,
        "order": [i for i in range(15) if i != 5]})
    (root / "private-first.wav").write_bytes(changed)
    (root / "private-second.wav").write_bytes(changed)
    manifest, _ = _manifest(root, labels=["assembly", "later normal"])
    result = runner.audit_saved_pipeline(manifest, root / "candidate")
    assert result["stages"][0]["check"]["gate_state"] == "review_required"
    assert result["stages"][1]["check"]["gate_state"] == "clear_supported_temporal_check"
    assert result["summary"]["first_concern"] == {"scope": "stage", "stage_index": 1,
        "stage_label": "assembly", "category": "defect_candidates"}
    assert result["summary"]["exit_code"] == 1
    _contract(result)


def test_all_inputs_are_snapshotted_before_analyzer_sees_only_four_settings(files, monkeypatch):
    root, raw = files
    manifest, value = _manifest(root, labels=["<script>private label</script>", "ignored order"])
    value["stages"][1]["declaration"]["allow_resampling"] = True
    manifest.write_text(json.dumps(value), encoding="utf-8")
    output, seen = root / "only-copies", []

    def compare(reference, processed, **configuration):
        assert all((output / f"inputs/{i:03d}.wav").read_bytes() == raw for i in range(3))
        seen.append((Path(reference).relative_to(output).as_posix(),
                     Path(processed).relative_to(output).as_posix(), configuration))
        return _clear(reference, processed, **configuration)

    monkeypatch.setattr(runner.api, "analyze_pair", compare)
    result = runner.audit_saved_pipeline(manifest, output)
    assert [s[:2] for s in seen] == [("inputs/000.wav", "inputs/001.wav"),
        ("inputs/001.wav", "inputs/002.wav"), ("inputs/000.wav", "inputs/002.wav")]
    assert all(set(s[2]) == {"profile", "allow_gain", "allow_resampling", "max_delay_ms"} for s in seen)
    assert seen[-1][2]["allow_resampling"] is True
    assert str(root) not in (output / "manifest_started.json").read_text("utf-8")
    _contract(result)


def test_withheld_is_sticky_but_does_not_stop_following_checks(files, monkeypatch):
    root, _ = files
    manifest, _ = _manifest(root)
    count = 0

    def compare(reference, processed, **configuration):
        nonlocal count
        count += 1
        return (_withheld if count == 1 else _clear)(reference, processed, **configuration)

    monkeypatch.setattr(runner.api, "analyze_pair", compare)
    result = runner.audit_saved_pipeline(manifest, root / "held")
    assert count == 3
    assert [stage["status"] for stage in result["stages"]] == ["withheld", "analyzed"]
    assert result["status"] == "completed"
    assert result["summary"]["exit_code"] == 2
    assert result["summary"]["first_concern"]["category"] == "withheld"
    _contract(result)


@pytest.mark.parametrize("failure", ["raise", "invalid", "error", "mismatch"])
def test_stage_error_stops_checks_but_retains_every_saved_input(files, monkeypatch, failure):
    root, raw = files
    manifest, _ = _manifest(root, count=3)
    calls = 0

    def compare(reference, processed, **configuration):
        nonlocal calls
        calls += 1
        if failure == "raise":
            raise RuntimeError("Sensitive C:/private/path.wav")
        if failure == "invalid":
            return {"schema_version": 1, "status": "analyzed"}
        if failure == "error":
            return {"schema_version": 1, "status": "error", "reason_code": "analysis_execution_error"}
        result = _clear(reference, processed, **configuration)
        result["configuration"]["allow_gain"] = True
        return result

    monkeypatch.setattr(runner.api, "analyze_pair", compare)
    output = root / "failed"
    result = runner.audit_saved_pipeline(manifest, output)
    assert calls == 1
    assert result["status"] == "incomplete"
    assert [s["status"] for s in result["stages"]] == ["error", "not_run", "not_run"]
    assert result["summary"]["checked_stage_count"] == 1
    assert result["summary"]["failed_stage"] == 1
    assert result["end_to_end"] is None
    for i in range(4):
        assert (output / f"inputs/{i:03d}.wav").read_bytes() == raw
    for stage in result["stages"][1:]:
        assert stage["input"] == stage["output"] == read_wav(root / "private-source.wav").metadata()
        assert stage["reason_code"] == "prior_stage_analysis_error"
        assert stage["analysis"] is stage["check"] is stage["analysis_artifact"] is None
    assert "Sensitive" not in json.dumps(result)
    _contract(result)


def test_end_only_error_has_no_assigned_stage(files, monkeypatch):
    root, _ = files
    manifest, _ = _manifest(root, count=1)
    count = 0

    def compare(reference, processed, **configuration):
        nonlocal count
        count += 1
        if count == 2:
            raise RuntimeError("private exception")
        return _clear(reference, processed, **configuration)

    monkeypatch.setattr(runner.api, "analyze_pair", compare)
    result = runner.audit_saved_pipeline(manifest, root / "end-error")
    assert result["summary"]["failed_stage"] is None
    assert result["summary"]["first_concern"] == {"scope": "end_to_end", "stage_index": None,
        "stage_label": None, "category": "execution_error"}
    assert result["status"] == "incomplete"
    _contract(result)


@pytest.mark.parametrize("position", [0, 1, 2])
def test_changed_original_named_inputs_block_and_preserve_copies(files, monkeypatch, position):
    root, raw = files
    manifest, _ = _manifest(root)
    paths = [root / n for n in ("private-source.wav", "private-first.wav", "private-second.wav")]
    count = 0

    def compare(reference, processed, **configuration):
        nonlocal count
        count += 1
        result = _clear(reference, processed, **configuration)
        if count == 3:
            paths[position].write_bytes(b"external mutation")
        return result

    monkeypatch.setattr(runner.api, "analyze_pair", compare)
    output = root / "changed"
    result = runner.audit_saved_pipeline(manifest, output)
    assert result["input_recheck"] == {"status": "changed", "file_indices": [position]}
    assert result["end_to_end"]["analysis"]["reason_code"] == "input_files_changed"
    assert result["status"] == "incomplete" and result["summary"]["exit_code"] == 2
    assert (output / f"inputs/{position:03d}.wav").read_bytes() == raw
    assert paths[position].read_bytes() == b"external mutation"
    _contract(result)


def test_unavailable_and_changed_recheck_indices_are_sorted_without_private_paths(files, monkeypatch):
    root, _ = files
    manifest, _ = _manifest(root)
    original_read = runner._guarded_bytes
    unavailable = root / "private-first.wav"
    calls = 0

    def reader(path, limit):
        if calls >= 3 and path == unavailable:
            raise runner.SavedPipelineError("input_file_read_error")
        return original_read(path, limit)

    def compare(reference, processed, **configuration):
        nonlocal calls
        calls += 1
        result = _clear(reference, processed, **configuration)
        if calls == 3:
            (root / "private-second.wav").write_bytes(b"external change")
        return result

    monkeypatch.setattr(runner, "_guarded_bytes", reader)
    monkeypatch.setattr(runner.api, "analyze_pair", compare)
    result = runner.audit_saved_pipeline(manifest, root / "unavailable")
    assert result["input_recheck"] == {"status": "unavailable", "file_indices": [1, 2]}
    assert result["end_to_end"]["analysis"]["reason_code"] == "input_files_recheck_failed"
    _contract(result)


def test_change_after_stage_failure_still_rechecks_every_input_and_keeps_earliest(files, monkeypatch):
    root, raw = files
    manifest, _ = _manifest(root)

    def fail(*args, **kwargs):
        (root / "private-second.wav").write_bytes(b"external change")
        raise RuntimeError("private exception")

    monkeypatch.setattr(runner.api, "analyze_pair", fail)
    output = root / "failed-changed"
    result = runner.audit_saved_pipeline(manifest, output)
    assert result["input_recheck"] == {"status": "changed", "file_indices": [2]}
    assert result["summary"]["first_concern"]["stage_index"] == 1
    assert result["end_to_end"]["analysis"]["reason_code"] == "input_files_changed"
    assert (output / "inputs/002.wav").read_bytes() == raw
    _contract(result)


def test_artifact_write_failure_replaces_prior_withheld_before_summary_derivation(files, monkeypatch):
    root, _ = files
    manifest, _ = _manifest(root)
    monkeypatch.setattr(runner.api, "analyze_pair", _withheld)
    writer = runner._new_json

    def failing(path, value):
        if path.name == "analysis.json":
            raise runner.SavedPipelineError("output_write_error")
        return writer(path, value)

    monkeypatch.setattr(runner, "_new_json", failing)
    result = runner.audit_saved_pipeline(manifest, root / "write-failure")
    assert result["summary"]["first_concern"]["category"] == "execution_error"
    assert result["stages"][0]["reason_code"] == "output_write_error"
    _contract(result)


def test_error_artifacts_unwritable_are_null_not_invented(files, monkeypatch):
    root, _ = files
    manifest, _ = _manifest(root)
    writer = runner._new_json

    def failing(path, value):
        if path.name in {"error.json", "error_check.json"}:
            raise runner.SavedPipelineError("output_write_error")
        return writer(path, value)

    def fail(*args, **kwargs):
        raise RuntimeError("private exception")

    monkeypatch.setattr(runner, "_new_json", failing)
    monkeypatch.setattr(runner.api, "analyze_pair", fail)
    result = runner.audit_saved_pipeline(manifest, root / "no-error-artifacts")
    assert result["stages"][0]["analysis_artifact"] is result["stages"][0]["check_artifact"] is None
    assert result["summary"]["exit_code"] == 2
    _contract(result)


def test_final_write_failure_never_returns_success_and_retains_partial_evidence(files, monkeypatch):
    root, raw = files
    manifest, _ = _manifest(root)
    monkeypatch.setattr(runner.api, "analyze_pair", _clear)
    writer = runner._new_json

    def failing(path, value):
        if path.name == "audit_result.json":
            raise runner.SavedPipelineError("output_write_error")
        return writer(path, value)

    monkeypatch.setattr(runner, "_new_json", failing)
    output = root / "final-write"
    with pytest.raises(runner.SavedPipelineError, match="output_write_error"):
        runner.audit_saved_pipeline(manifest, output)
    assert not (output / "audit_result.json").exists()
    assert (output / "inputs/000.wav").read_bytes() == raw
    assert (output / "manifest_started.json").is_file()
    events = [json.loads(line) for line in (output / "execution.jsonl").read_text("utf-8").splitlines()]
    assert events[-1]["event"] == "audit_failed" and events[-1]["gate_state"] == "blocked"


@pytest.mark.parametrize("file_name,content", [("private-source.wav", b"not wav"),
    ("private-second.wav", b"not wav"), ("private-second.wav", b"\0" * 10_000_001)],
    ids=["malformed-source", "malformed-later-output", "oversized-later-output"])
def test_all_wav_preflight_failures_create_no_output(files, file_name, content):
    root, _ = files
    manifest, _ = _manifest(root)
    (root / file_name).write_bytes(content)
    output = root / "absent" / "audit"
    with pytest.raises(runner.SavedPipelineError):
        runner.audit_saved_pipeline(manifest, output)
    assert not output.parent.exists()


def test_missing_later_wav_preflight_creates_no_output(files):
    root, _ = files
    manifest, value = _manifest(root)
    value["stages"][1]["output"] = "missing.wav"
    manifest.write_text(json.dumps(value), encoding="utf-8")
    output = root / "absent" / "audit"
    with pytest.raises(runner.SavedPipelineError, match="input_file_read_error"):
        runner.audit_saved_pipeline(manifest, output)
    assert not output.parent.exists()


def test_existing_output_and_input_alias_are_not_overwritten(files):
    root, raw = files
    manifest, _ = _manifest(root)
    output = root / "existing"
    output.mkdir()
    marker = output / "preserve.txt"
    marker.write_text("original", encoding="utf-8")
    with pytest.raises(runner.SavedPipelineError, match="output_directory_exists"):
        runner.audit_saved_pipeline(manifest, output)
    with pytest.raises(runner.SavedPipelineError, match="input_output_alias"):
        runner.audit_saved_pipeline(manifest, root / "private-source.wav")
    assert marker.read_text("utf-8") == "original"
    assert (root / "private-source.wav").read_bytes() == raw


def test_raw_riff_container_unknown_chunk_is_preserved(files, monkeypatch):
    root, raw = files
    chunked = raw + b"JUNK" + struct.pack("<I", 3) + b"abc\0"
    chunked = chunked[:4] + struct.pack("<I", len(chunked) - 8) + chunked[8:]
    (root / "private-source.wav").write_bytes(chunked)
    manifest, _ = _manifest(root)
    monkeypatch.setattr(runner.api, "analyze_pair", _clear)
    output = root / "chunks"
    result = runner.audit_saved_pipeline(manifest, output)
    assert (output / "inputs/000.wav").read_bytes() == chunked
    assert result["source"]["sha256"] == hashlib.sha256(chunked).hexdigest()
    _contract(result)


@pytest.mark.parametrize("relative", ["../outside.wav", "nested/../file.wav", "./file.wav", "/file.wav",
    "//host/file.wav", "C:/file.wav", "C:file.wav", "nested\\file.wav", "file.wav:stream.wav",
    "nested//file.wav", "file.wav/", "file.mp3", "file.wav\x00", "hidden\u202efile.wav", "con.wav",
    "folder./file.wav", "folder /file.wav", "", True, None])
def test_manifest_paths_reject_traversal_absolute_aliases_and_controls(files, relative):
    root, _ = files
    manifest, value = _manifest(root)
    value["source"] = relative
    manifest.write_text(json.dumps(value), encoding="utf-8")
    with pytest.raises(runner.SavedPipelineError, match="invalid_manifest_path"):
        runner.load_saved_manifest(manifest)


@pytest.mark.parametrize("label", ["", "  ", "a" * 81, "x\ny", "x\x7fy", "x\u200by", "x\ud800y", True])
def test_labels_are_bounded_without_control_format_or_surrogate_characters(files, label):
    root, _ = files
    manifest, value = _manifest(root)
    value["stages"][0]["label"] = label
    manifest.write_text(json.dumps(value), encoding="utf-8")
    with pytest.raises(runner.SavedPipelineError, match="invalid_saved_stage"):
        runner.load_saved_manifest(manifest)


@pytest.mark.parametrize("raw,code", [
    (b'{"schema_version":1,"schema_version":1}', "duplicate_json_key"),
    (b'{"schema_version":1,"source":"x.wav","stages":[{"label":"x","output":"y.wav","declaration":{"allow_gain":false,"allow_gain":true,"allow_resampling":false}}]}', "duplicate_json_key"),
    (b'{"value":NaN}', "non_finite_metric"), (b'{"value":Infinity}', "non_finite_metric"),
    (b'\xff', "invalid_manifest_json"), (b'\xef\xbb\xbf{}', "invalid_manifest_json"),
    (b'{}', "invalid_saved_manifest"), (b' ' * 262_145, "manifest_file_too_large"),
], ids=["duplicate-top", "duplicate-declaration", "nan", "infinity", "invalid-utf8",
        "bom", "missing-fields", "oversized"])
def test_strict_bounded_json_loading(tmp_path, raw, code):
    path = tmp_path / "private-manifest.json"
    path.write_bytes(raw)
    with pytest.raises(runner.SavedPipelineError) as exc:
        runner.load_saved_manifest(path)
    assert exc.value.code == code
    assert str(path) not in str(exc.value)


@pytest.mark.parametrize("mutation", ["version_bool", "empty", "nine", "extra_top", "extra_stage",
    "extra_declaration", "missing_declaration", "gain_int", "resample_string", "stage_list"])
def test_exact_manifest_fields_and_types_are_enforced(files, mutation):
    root, _ = files
    manifest, value = _manifest(root)
    if mutation == "version_bool":
        value["schema_version"] = True
    elif mutation == "empty":
        value["stages"] = []
    elif mutation == "nine":
        value["stages"] *= 5
    elif mutation == "extra_top":
        value["command"] = "run anything"
    elif mutation == "extra_stage":
        value["stages"][0]["operation"] = "anything"
    elif mutation == "extra_declaration":
        value["stages"][0]["declaration"]["expected_events"] = []
    elif mutation == "missing_declaration":
        value["stages"][0].pop("declaration")
    elif mutation == "gain_int":
        value["stages"][0]["declaration"]["allow_gain"] = 1
    elif mutation == "resample_string":
        value["stages"][0]["declaration"]["allow_resampling"] = "true"
    else:
        value["stages"][0] = []
    manifest.write_text(json.dumps(value), encoding="utf-8")
    with pytest.raises(runner.SavedPipelineError):
        runner.load_saved_manifest(manifest)


def test_nested_unicode_paths_load_and_return_fresh_normalized_manifest(files):
    root, raw = files
    folder = root / "보존"
    folder.mkdir()
    (folder / "원음.wav").write_bytes(raw)
    manifest, value = _manifest(root)
    value["source"] = "보존/원음.wav"
    manifest.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    assert runner.load_saved_manifest(manifest) == value


def test_missing_manifest_error_is_stable(tmp_path):
    with pytest.raises(runner.SavedPipelineError) as exc:
        runner.load_saved_manifest(tmp_path / "private-manifest.json")
    assert exc.value.code == "manifest_file_read_error"


@pytest.mark.parametrize("target_kind", ["file", "parent", "manifest"])
def test_observable_input_reparse_points_are_rejected_before_outputs(files, monkeypatch, target_kind):
    root, raw = files
    manifest, value = _manifest(root)
    if target_kind == "parent":
        nested = root / "nested"
        nested.mkdir()
        (nested / "source.wav").write_bytes(raw)
        value["source"] = "nested/source.wav"
        manifest.write_text(json.dumps(value), encoding="utf-8")
        guarded = nested
    else:
        guarded = manifest if target_kind == "manifest" else root / "private-source.wav"
    original = Path.lstat

    def lstat(path, *args, **kwargs):
        info = original(path, *args, **kwargs)
        if path == guarded:
            return SimpleNamespace(st_mode=info.st_mode, st_file_attributes=0x400)
        return info

    monkeypatch.setattr(Path, "lstat", lstat)
    output = root / "absent" / "audit"
    with pytest.raises(runner.SavedPipelineError, match="unsafe_input_path"):
        runner.audit_saved_pipeline(manifest, output)
    assert not output.parent.exists()


def test_observable_output_reparse_parent_is_rejected(files, monkeypatch):
    root, _ = files
    manifest, _ = _manifest(root)
    parent = root / "junction"
    parent.mkdir()
    original = Path.lstat

    def lstat(path, *args, **kwargs):
        info = original(path, *args, **kwargs)
        if path == parent:
            return SimpleNamespace(st_mode=info.st_mode, st_file_attributes=0x400)
        return info

    monkeypatch.setattr(Path, "lstat", lstat)
    with pytest.raises(runner.SavedPipelineError, match="unsafe_output_parent"):
        runner.audit_saved_pipeline(manifest, parent / "audit")
    assert list(parent.iterdir()) == []


@pytest.mark.parametrize("linked", ["source", "manifest"])
def test_actual_input_symlinks_rejected_when_windows_permits_creation(files, linked):
    root, _ = files
    manifest, value = _manifest(root)
    target = root / ("private-source.wav" if linked == "source" else "manifest.json")
    link = root / ("linked.wav" if linked == "source" else "linked.json")
    try:
        link.symlink_to(target)
    except OSError:
        pytest.skip("This Windows account cannot create file symlinks")
    if linked == "source":
        value["source"] = "linked.wav"
        manifest.write_text(json.dumps(value), encoding="utf-8")
    else:
        manifest = link
    with pytest.raises(runner.SavedPipelineError, match="unsafe_input_path"):
        runner.audit_saved_pipeline(manifest, root / "audit")
    assert not (root / "audit").exists()
