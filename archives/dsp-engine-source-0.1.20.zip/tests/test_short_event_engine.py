"""Owned synthetic native-PCM fixtures, not a new field-performance claim."""

from copy import deepcopy
import json

import numpy as np
import pytest

from audio_regression.audio import decode_wav, encode_wav
from audio_regression.engine import EngineConfig, EngineConfigError
from audio_regression import short_event_engine as candidate


def _audio(values, rate=8000):
    return decode_wav(encode_wav(np.asarray(values, dtype=float), rate))


def _signal(rate=8000, seed=731921):
    rng = np.random.default_rng(seed)
    return rng.integers(-11000, 11001, size=3 * rate).astype(float) / 32768


def _pair(kind, duration_ms=100, rate=8000, point_ms=1300):
    x = _signal(rate)
    point, length = round(point_ms * rate / 1000), round(duration_ms * rate / 1000)
    if kind == "delete":
        y = np.concatenate((x[:point], x[point + length:]))
    else:
        y = np.concatenate((x[:point], x[point - length:point], x[point:]))
    return _audio(x, rate), _audio(y, rate), point, length


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
@pytest.mark.parametrize("duration_ms", [50, 75, 100, 150, 200])
@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_native_single_edit_uses_all_samples_at_each_rate(rate, duration_ms, kind):
    x, y, point, length = _pair(kind, duration_ms, rate)
    result, trace = candidate.analyze_buffers_with_trace(x, y)
    assert result["status"] == "analyzed", result["reason_code"]
    assert result["events"][0]["type"] == kind
    event = result["events"][0]
    interval = event["reference_interval_ms"] if kind == "delete" else event["processed_added_interval_ms"]
    assert abs(interval[0] - point * 1000 / rate) <= 1
    assert interval[1] - interval[0] == pytest.approx(length * 1000 / rate)
    assert result["analysis"]["sample_rate_hz"] == rate
    assert result["analysis"]["minimum_event_duration_ms"] == 50
    assert result["analysis"]["hop_ms"] == 1000 / rate
    assert trace["every_output_sample_exact"] is True
    assert trace["complete_endpoints_included"] is True
    assert trace["search_complete"] is True
    assert trace["every_supported_geometry_checked"] is True
    assert trace["exact_output_sample_count"] == len(y.samples)
    assert result["diagnostics"]["matched_analysis_samples"] == min(len(x.samples), len(y.samples))
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    assert all(abs(c - 1) < 1e-12 for segment in result["alignment_segments"]
               for c in segment["anchor_correlations"])
    # Trace contains measurements/coordinates only, never PCM arrays or paths.
    json.dumps(trace, allow_nan=False)


@pytest.mark.parametrize("kind", ["delete", "repeat"])
@pytest.mark.parametrize("position", [0, 10, 7300, -1])
def test_hidden_one_lsb_change_anywhere_in_retained_output_is_not_cleared(kind, position):
    x, y, _, _ = _pair(kind)
    changed = y.samples.copy()
    changed[position] += 1 / 32768
    result, trace = candidate.analyze_buffers_with_trace(x, _audio(changed))
    assert result["status"] == "withheld"
    assert result["events"] is None
    assert trace["short_event_proved"] is False


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_substitution_in_the_middle_of_an_exact_retained_run_is_not_hidden(kind):
    x, y, _, _ = _pair(kind)
    changed = y.samples.copy()
    changed[5000:5200] = -changed[5000:5200]
    result, _ = candidate.analyze_buffers_with_trace(x, _audio(changed))
    assert result["status"] == "withheld"


def test_insertion_of_unrelated_content_is_not_called_a_repeat():
    x = _signal()
    extra = _signal(seed=872)[:800]
    y = np.concatenate((x[:10400], extra, x[10400:]))
    result, trace = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"
    assert result["reason_code"] == "short_event_insertion_not_adjacent_copy"
    assert trace["supported_geometry_count"] == 0


def test_two_deletions_cannot_be_explained_by_net_duration_only():
    x = _signal()
    y = np.concatenate((x[:5000], x[5400:15000], x[15400:]))
    result, _ = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"
    assert result["reason_code"] == "short_event_no_complete_single_edit_explanation"


@pytest.mark.parametrize("side", ["start", "end"])
def test_nonzero_endpoint_loss_is_not_an_internal_event(side):
    x = _signal()
    y = x[800:] if side == "start" else x[:-800]
    result, trace = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"
    assert result["reason_code"] == "short_event_insufficient_internal_context"
    assert trace["short_event_attempted"] is True


def test_repeated_and_periodic_original_makes_boundaries_ambiguous():
    block = _signal()[:800]
    x = np.tile(block, 30)
    y = np.concatenate((x[:10400], x[11200:]))
    result, trace = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"
    assert result["reason_code"] == "short_event_ambiguous_single_edit_geometry"
    assert trace["supported_boundary_span_samples"] > 8


def test_silent_deleted_interval_is_not_identifiable():
    x = _signal()
    x[10000:12000] = 0
    y = np.concatenate((x[:10400], x[11200:]))
    result, _ = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"
    assert result["reason_code"] == "short_event_ambiguous_single_edit_geometry"


@pytest.mark.parametrize("level", [0.0, .125])
def test_quiet_silence_is_not_a_native_proof(level):
    result, _ = candidate.analyze_buffers_with_trace(_audio(np.full(24000, level)), _audio(np.full(23200, level)))
    assert result["status"] == "withheld"
    assert result["reason_code"] in {"short_event_insufficient_signal_variation", "insufficient_signal_variation"}


def test_adjacent_repeat_is_the_canonical_later_copy_not_claimed_edit_provenance():
    x, y, point, length = _pair("repeat", 75, 44100)
    result, trace = candidate.analyze_buffers_with_trace(x, y)
    assert result["status"] == "analyzed"
    event = result["events"][0]
    assert event["copy_interval_convention"] == "canonical_later_adjacent_copy_not_edit_provenance"
    assert event["reference_source_interval_ms"] == pytest.approx([(point-length)*1000/44100, point*1000/44100])
    assert trace["canonical_copy_is_edit_provenance"] is False


def test_nonadjacent_copy_is_not_a_supported_repeat():
    x = _signal()
    y = np.concatenate((x[:10400], x[2000:2800], x[10400:]))
    result, _ = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"


def test_copy_of_constant_block_is_not_identifiable():
    x = _signal()
    x[9600:10400] = .125
    y = np.concatenate((x[:10400], x[9600:10400], x[10400:]))
    result, _ = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"


def test_whole_native_signal_failure_never_uses_legacy_fallback(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("eligible native proof must not fall back to a legacy clear")
    monkeypatch.setattr(candidate.global_context_engine, "analyze_buffers_with_trace", forbidden)
    x, y, _, _ = _pair("delete")
    changed = y.samples.copy()
    changed[-1] += 1 / 32768
    result, _ = candidate.analyze_buffers_with_trace(x, _audio(changed))
    assert result["status"] == "withheld"


@pytest.mark.parametrize("duration_samples", [399, 1601])
def test_outside_native_duration_scope_preserves_v9_result(monkeypatch, duration_samples):
    x = _signal()
    y = np.concatenate((x[:10400], x[10400+duration_samples:]))
    baseline = {"engine": "local_content_alignment_v9", "analysis": {"method": "old",
                "sample_rate_hz": 8000, "hop_ms": 10, "minimum_event_duration_ms": 200},
                "status": "withheld", "reason_code": "legacy_reason", "limitations": []}
    old_trace = {"legacy": True}
    monkeypatch.setattr(candidate.global_context_engine, "analyze_buffers_with_trace",
                        lambda *args: (baseline, old_trace))
    before = deepcopy(baseline)
    result, trace = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert baseline == before
    assert result["analysis"]["minimum_event_duration_ms"] == 200
    assert trace["proof_path"] == "preserved_v9_result"
    assert trace["inherited_v9_trace"] == old_trace
    assert trace["baseline_reason_code"] == "legacy_reason"


@pytest.mark.parametrize("duration_ms", [50, 100, 200])
@pytest.mark.parametrize("side", ["start", "end"])
@pytest.mark.parametrize("operation", ["pad", "trim"])
def test_exact_silent_edge_transform_is_passed_to_v9(monkeypatch, duration_ms, side, operation):
    x = _signal()
    count = duration_ms * 8
    padded = np.concatenate((np.zeros(count), x)) if side == "start" else np.concatenate((x, np.zeros(count)))
    reference, processed = (x, padded) if operation == "pad" else (padded, x)
    baseline = {"engine": "local_content_alignment_v9", "analysis": {"method": "old",
                "sample_rate_hz": 8000, "hop_ms": 10, "minimum_event_duration_ms": 200},
                "status": "analyzed", "reason_code": None, "limitations": [], "events": []}
    monkeypatch.setattr(candidate.global_context_engine, "analyze_buffers_with_trace",
                        lambda *args: (baseline, {}))
    result, trace = candidate.analyze_buffers_with_trace(_audio(reference), _audio(processed))
    assert result["status"] == "analyzed"
    assert result["events"] == []
    assert trace["short_event_attempted"] is False


def test_silent_padding_with_one_lsb_change_does_not_escape_to_v9(monkeypatch):
    def forbidden(*args, **kwargs):
        raise AssertionError("not an exact silent-edge transform")
    monkeypatch.setattr(candidate.global_context_engine, "analyze_buffers_with_trace", forbidden)
    x = _signal()
    y = np.concatenate((np.zeros(800), x))
    y[-1] += 1 / 32768
    result, _ = candidate.analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"


def test_float_44k1_duration_bounds_are_not_rounded_down():
    x, y, _, _ = _pair("delete", 50, 44100)
    assert candidate._eligible(x, y, EngineConfig()) is True
    x_values = x.samples
    under = np.concatenate((x_values[:40000], x_values[42204:]))  # 2204, not 2205 samples.
    assert candidate._eligible(x, _audio(under, 44100), EngineConfig()) is False


def test_gain_or_resampling_declaration_stays_with_legacy(monkeypatch):
    baseline = {"engine": "local_content_alignment_v9", "analysis": {"method": "old",
                "sample_rate_hz": 8000, "hop_ms": 10, "minimum_event_duration_ms": 200},
                "status": "withheld", "reason_code": "legacy_reason", "limitations": []}
    monkeypatch.setattr(candidate.global_context_engine, "analyze_buffers_with_trace",
                        lambda *args: (baseline, {}))
    x, y, _, _ = _pair("delete")
    for config in (EngineConfig(allow_gain=True), EngineConfig(allow_resampling=True)):
        _, trace = candidate.analyze_buffers_with_trace(x, y, config)
        assert trace["short_event_attempted"] is False


@pytest.mark.parametrize("configuration", [object(), EngineConfig(profile="telephone")])
def test_invalid_candidate_configuration_is_not_silently_changed(configuration):
    x, y, _, _ = _pair("delete")
    with pytest.raises(EngineConfigError):
        candidate.analyze_buffers_with_trace(x, y, configuration)
