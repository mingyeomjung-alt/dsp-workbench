"""Independent owned-signal checks for the opt-in compound edit proof.

The formula and seed in this file are new development fixtures. They read no
recorded audio, sealed evaluation, external processor output, or older owned
example. Policy and witness injections are labelled unit tests, not evidence
of real-audio performance. Every end-to-end positive uses edit-before-gain
PCM quantization and the actual public resampling implementation.
"""

from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import importlib
import json

import numpy as np
import pytest
from scipy.signal import resample_poly

from audio_regression import compound_engine
from audio_regression.api import analyze_pair_with_trace
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.check_policy import check_result
from audio_regression.engine import EngineConfig, EngineConfigError
from audio_regression.result_contract import validate_analysis_result


Q = 1 / 32768
SOURCE_RATE = 16000
TARGET_RATE = 8000
SOURCE_START_MS = 2320
GAIN = .637281
LEAD_MS = 180
SETTINGS = EngineConfig(allow_gain=True, allow_resampling=True)
ENGINE = "local_content_alignment_v8"


def _audio(values, rate=SOURCE_RATE):
    return decode_wav(encode_wav(values, rate))


def _owned_values(*, quiet_tail=True):
    """Distinct chirps and incommensurate partials provide unique raw context."""
    time = np.arange(8 * SOURCE_RATE, dtype=float) / SOURCE_RATE
    phase = 2 * np.pi * (193 * time + 23 * time ** 2 + .003 * time ** 3
                        + .23 * np.sin(3.7 * time))
    envelope = .78 + .13 * np.sin(2.8 * time) + .08 * np.sin(6.3 * time + .2)
    loud = .14 * envelope * (np.sin(phase) + .27 * np.sin(1.37 * phase + .8)
                            + .13 * np.cos(2.63 * phase - 1.2))
    quiet = .70 * Q * np.sin(2 * np.pi * (2370 * time + 9 * time ** 2))
    return np.where(time < 6.5, loud, quiet) if quiet_tail else loud


@lru_cache(maxsize=None)
def _reference(quiet_tail=True):
    return _audio(_owned_values(quiet_tail=quiet_tail))


def _edited(source, kind, start_ms=SOURCE_START_MS, length_ms=400):
    start = round(start_ms * 16)
    length = round(length_ms * 16)
    end = start + length
    if kind == "delete":
        return np.concatenate((source[:start], source[end:]))
    if kind == "repeat":
        return np.concatenate((source[:end], source[start:end], source[end:]))
    if kind == "normal":
        return source.copy()
    raise ValueError(kind)


def _transform(values, gain=GAIN, lead_ms=LEAD_MS):
    gained = _audio(values * gain)
    down = _audio(resample_poly(gained.samples, 1, 2), TARGET_RATE)
    return _audio(np.concatenate((np.zeros(round(lead_ms * 8)), down.samples)), TARGET_RATE)


@lru_cache(maxsize=None)
def _pair(kind="delete", length_ms=400, gain=GAIN, lead_ms=LEAD_MS):
    reference = _reference()
    changed = _edited(reference.samples, kind, length_ms=length_ms)
    return reference, _transform(changed, gain, lead_ms)


@pytest.fixture
def candidate():
    # Deferred until the new module is present; no import of a half-written
    # module is necessary for fixture-only baseline checks.
    return importlib.import_module("audio_regression.compound_event_engine")


def _checked(candidate, reference, processed, settings=SETTINGS, *, strict_result=True):
    originals = reference.samples.copy(), processed.samples.copy()
    result, trace = candidate.analyze_buffers_with_trace(reference, processed, settings)
    assert result["engine"] == ENGINE
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    np.testing.assert_array_equal(reference.samples, originals[0])
    np.testing.assert_array_equal(processed.samples, originals[1])
    json.dumps(result, allow_nan=False)
    json.dumps(trace, allow_nan=False)
    if strict_result:
        validate_analysis_result(result)
    return result, trace


def _preserved(result, baseline):
    for key in ("status", "reason_code", "events", "diagnostics", "alignment_segments",
                "configuration", "content_preservation_status"):
        if key in baseline:
            assert result[key] == baseline[key]
        else:
            assert key not in result


@pytest.mark.parametrize("length_ms", (400, 1200, 2000))
def test_fresh_owned_repeat_before_compound_transform_reproduces_v7_withholding(length_ms):
    # Initial fixture inventory showed that v7 already handles all delete
    # cases and two repeat durations. Keep those inheritance checks below;
    # these three are the genuinely withheld cases, not invented misses.
    kind = "repeat"
    reference, processed = _pair(kind, length_ms)
    result, trace = compound_engine.analyze_buffers_with_trace(reference, processed, SETTINGS)
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None
    assert trace["compound_proved"] is False


@pytest.mark.parametrize("kind,length_ms", (
    ("delete", 200), ("repeat", 200), ("delete", 400), ("repeat", 400),
    ("delete", 800), ("repeat", 800), ("delete", 1200), ("repeat", 1200),
    ("delete", 2000),
))
def test_exact_compound_event_has_one_localized_candidate_and_review_exit(candidate, kind, length_ms):
    reference, processed = _pair(kind, length_ms)
    baseline, _ = compound_engine.analyze_buffers_with_trace(reference, processed, SETTINGS)
    result, trace = _checked(candidate, reference, processed)
    assert result["status"] == "analyzed", (result, trace)
    assert result["reason_code"] is None
    assert result["content_preservation_status"] == "defect_candidates"
    assert len(result["events"]) == 1
    event = result["events"][0]
    assert event["type"] == kind
    if kind == "delete":
        assert event["reference_interval_ms"] == pytest.approx(
            [SOURCE_START_MS, SOURCE_START_MS + length_ms], abs=20)
        assert event["processed_boundary_ms"] == pytest.approx(
            LEAD_MS + SOURCE_START_MS, abs=20)
    else:
        assert event["reference_source_interval_ms"] == pytest.approx(
            [SOURCE_START_MS, SOURCE_START_MS + length_ms], abs=20)
        assert event["processed_added_interval_ms"] == pytest.approx(
            [LEAD_MS + SOURCE_START_MS + length_ms,
             LEAD_MS + SOURCE_START_MS + 2 * length_ms], abs=20)
        assert event["copy_interval_convention"] == "canonical_later_adjacent_copy_not_edit_provenance"
    assert check_result(result)["exit_code"] == 1
    assert len(result["alignment_segments"]) == 2
    if baseline["status"] == "analyzed":
        _preserved(result, baseline)
        assert trace["compound_event_proved"] is False
    else:
        assert trace["compound_event_attempted"] is True
        assert trace["compound_event_proved"] is True
        assert trace["every_output_sample_exact"] is True


def test_large_repeat_with_unsupported_legacy_bracket_remains_explicitly_withheld(candidate):
    # This owned 2000 ms fixture has a 2963-geometry bracket, exceeding the
    # unchanged 2401-candidate cap. It is not an eligible rescue and is kept
    # as a negative scope check rather than raising the cap to pass a test.
    reference, processed = _pair("repeat", 2000)
    baseline, _ = compound_engine.analyze_buffers_with_trace(reference, processed, SETTINGS)
    assert baseline["reason_code"] == "raw_landmark_event_bracket_not_supported"
    result, trace = _checked(candidate, reference, processed)
    _preserved(result, baseline)
    assert result["status"] == "withheld"
    assert trace["compound_event_attempted"] is False
    assert trace["compound_event_proved"] is False
    assert check_result(result)["exit_code"] == 2


def test_normal_compound_result_is_preserved_and_not_relabelled_as_new_event_proof(candidate):
    reference, processed = _pair("normal")
    baseline, _ = compound_engine.analyze_buffers_with_trace(reference, processed, SETTINGS)
    result, trace = _checked(candidate, reference, processed)
    _preserved(result, baseline)
    assert trace["compound_event_proved"] is False
    assert check_result(result)["exit_code"] == check_result(baseline)["exit_code"]
    if baseline["status"] == "analyzed":
        assert trace["compound_event_attempted"] is False
        assert result["events"] == []


@pytest.mark.parametrize("mutation", ("one_quiet_lsb", "erase_quiet_tail", "dropout", "noise", "sign_flip"))
def test_mutation_outside_candidate_interval_cannot_hide_in_the_event_forward_proof(candidate, mutation):
    reference, processed = _pair("repeat", 400)
    values = processed.samples.copy()
    quiet_start = (LEAD_MS + 7100) * 8
    if mutation == "one_quiet_lsb":
        values[quiet_start + 113] += Q
    elif mutation == "erase_quiet_tail":
        assert np.count_nonzero(values[quiet_start:]) > 0
        values[quiet_start:] = 0
    elif mutation == "dropout":
        values[7000:7160] = 0
    elif mutation == "noise":
        values += .002 * np.random.default_rng(831047).uniform(-1, 1, len(values))
    else:
        values[9000:9200] *= -1
    assert not np.array_equal(values, processed.samples)
    result, trace = _checked(candidate, reference, _audio(values, TARGET_RATE))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None
    assert trace["compound_event_proved"] is False
    assert check_result(result)["exit_code"] == 2


@pytest.mark.parametrize("payload_kind", ("unrelated", "reversed", "silent", "counterfeit_tail", "different_gain"))
def test_unproved_inserted_payload_is_not_claimed_as_complete_adjacent_copy(candidate, payload_kind):
    reference = _reference()
    source = reference.samples
    start, length = SOURCE_START_MS * 16, 400 * 16
    end = start + length
    payload = source[start:end].copy()
    if payload_kind == "unrelated":
        payload = .07 * np.random.default_rng(940311).normal(size=length)
    elif payload_kind == "reversed":
        payload = payload[::-1]
    elif payload_kind == "silent":
        payload[:] = 0
    elif payload_kind == "counterfeit_tail":
        payload[-400:] = .06 * np.random.default_rng(220931).normal(size=400)
    else:
        payload *= .7
    changed = np.concatenate((source[:end], payload, source[end:]))
    result, trace = _checked(candidate, reference, _transform(changed))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None
    assert trace["compound_event_proved"] is False


@pytest.mark.parametrize("settings", (EngineConfig(), EngineConfig(allow_gain=True),
                                     EngineConfig(allow_resampling=True)))
def test_missing_existing_gain_or_resampling_declaration_cannot_enable_event_rescue(candidate, settings):
    reference, processed = _pair("repeat", 400)
    baseline, _ = compound_engine.analyze_buffers_with_trace(reference, processed, settings)
    result, trace = _checked(candidate, reference, processed, settings)
    _preserved(result, baseline)
    assert trace["compound_event_attempted"] is False
    assert trace["compound_event_proved"] is False


def test_nonbasic_profile_is_not_silently_reinterpreted_as_compound_edit(candidate):
    reference, processed = _pair("repeat", 400)
    with pytest.raises(EngineConfigError):
        candidate.analyze_buffers_with_trace(reference, processed, EngineConfig(
            profile="telephone", allow_gain=True, allow_resampling=True))


@pytest.mark.parametrize("rate", (8000, 44100, 48000))
def test_non16k_reference_cannot_earn_new_fixed16_to8_event_proof(candidate, rate):
    original, processed = _pair("repeat", 400)
    reference = _audio(resample_poly(original.samples, rate, SOURCE_RATE), rate)
    baseline, _ = compound_engine.analyze_buffers_with_trace(reference, processed, SETTINGS)
    result, trace = _checked(candidate, reference, processed)
    _preserved(result, baseline)
    assert trace["compound_event_attempted"] is False
    assert trace["compound_event_proved"] is False


@pytest.mark.parametrize("kind", ("delete", "repeat"))
@pytest.mark.parametrize("start_ms", (0, 7600))
def test_file_edge_edit_cannot_earn_new_two_context_event_proof(candidate, kind, start_ms):
    reference = _reference()
    changed = _edited(reference.samples, kind, start_ms=start_ms, length_ms=400)
    processed = _transform(changed)
    result, trace = _checked(candidate, reference, processed)
    assert trace["compound_event_proved"] is False
    assert not (result["status"] == "analyzed" and result["events"] == [])


@pytest.mark.parametrize("kind", ("delete", "repeat"))
def test_multiple_separated_events_are_not_collapsed_into_one_exact_event(candidate, kind):
    reference = _reference()
    changed = _edited(reference.samples, kind, start_ms=4000, length_ms=400)
    changed = _edited(changed, kind, start_ms=2320, length_ms=400)
    result, trace = _checked(candidate, reference, _transform(changed))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None
    assert trace["compound_event_proved"] is False


@pytest.mark.parametrize("mode", ("gain_after_src", "different_fir", "post_src_edit"))
def test_different_transform_order_is_not_claimed_as_new_edit_before_compound_proof(candidate, mode):
    reference = _reference()
    changed = _edited(reference.samples, "repeat", length_ms=400)
    if mode == "gain_after_src":
        down = _audio(resample_poly(changed, 1, 2), TARGET_RATE)
        values = _audio(down.samples * GAIN, TARGET_RATE).samples
    elif mode == "different_fir":
        gained = _audio(changed * GAIN)
        values = _audio(resample_poly(gained.samples, 1, 2, window=("kaiser", 8.2)), TARGET_RATE).samples
    else:
        gained = _audio(reference.samples * GAIN)
        values = _audio(resample_poly(gained.samples, 1, 2), TARGET_RATE).samples
        start, end = SOURCE_START_MS * 8, (SOURCE_START_MS + 400) * 8
        values = np.concatenate((values[:end], values[start:end], values[end:]))
    processed = _audio(np.concatenate((np.zeros(LEAD_MS * 8), values)), TARGET_RATE)
    assert not np.array_equal(processed.samples, _pair("repeat", 400)[1].samples)
    baseline, _ = compound_engine.analyze_buffers_with_trace(reference, processed, SETTINGS)
    result, trace = _checked(candidate, reference, processed)
    # An inherited raw engine may legitimately diagnose its own transform;
    # the new exact edit-before-SRC path must not misstate that provenance.
    _preserved(result, baseline)
    assert trace["compound_event_proved"] is False


@pytest.mark.parametrize("lead_change", ("nonzero_prefix", "negative_lead", "too_long"))
def test_leading_zero_delay_hypothesis_is_not_fitted_around_unexplained_content(candidate, lead_change):
    reference, processed = _pair("repeat", 400)
    values = processed.samples.copy()
    settings = SETTINGS
    if lead_change == "nonzero_prefix":
        values[40] = .03
    elif lead_change == "negative_lead":
        values = values[LEAD_MS * 8 + 400:]
    else:
        values = np.concatenate((np.zeros(2200 * 8), values))
    modified = _audio(values, TARGET_RATE)
    result, trace = _checked(candidate, reference, modified, settings)
    assert trace["compound_event_proved"] is False
    assert not (result["status"] == "analyzed" and result["events"] == [])


@pytest.mark.parametrize("gain", (0., -.5))
def test_nonpositive_gain_does_not_become_an_event_witness(candidate, gain):
    reference, processed = _pair("repeat", 400, gain)
    result, trace = _checked(candidate, reference, processed)
    assert trace["compound_event_proved"] is False
    assert result["status"] == "withheld", (result, trace)


@pytest.mark.parametrize("kind", ("delete", "repeat"))
def test_periodic_signal_cannot_claim_unique_local_event_context(candidate, kind):
    time = np.arange(8 * SOURCE_RATE, dtype=float) / SOURCE_RATE
    reference = _audio(.15 * np.sin(2 * np.pi * 500 * time))
    changed = _edited(reference.samples, kind, length_ms=400)
    result, trace = _checked(candidate, reference, _transform(changed))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None
    assert trace["compound_event_proved"] is False


@pytest.mark.parametrize("kind", ("delete", "repeat"))
def test_silent_event_content_cannot_claim_identifiable_geometry(candidate, kind):
    values = _owned_values()
    # The whole wider interval is silent, so even exact sample equivalence
    # cannot identify an interior boundary to the reported tolerance.
    values[2100 * 16:3200 * 16] = 0
    reference = _audio(values)
    changed = _edited(reference.samples, kind, start_ms=2320, length_ms=400)
    result, trace = _checked(candidate, reference, _transform(changed))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None
    assert trace["compound_event_proved"] is False


def test_distant_identical_copy_source_is_not_unique_even_when_retained_context_is_unique(candidate):
    values = _owned_values()
    start, length = SOURCE_START_MS * 16, 400 * 16
    values[4700 * 16:5100 * 16] = values[start:start + length]
    reference = _audio(values)
    changed = _edited(reference.samples, "repeat", length_ms=400)
    result, trace = _checked(candidate, reference, _transform(changed))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None
    assert trace["compound_event_proved"] is False


@pytest.mark.parametrize("budget", ("MAX_CANDIDATES", "MAX_GAIN_NODES"))
def test_exhausted_fixed_event_budget_cannot_rescue_a_real_v7_withhold(candidate, monkeypatch, budget):
    proof_module = importlib.import_module("audio_regression.compound_event_proof")
    monkeypatch.setattr(proof_module, budget, 0)
    reference, processed = _pair("repeat", 400)
    result, trace = _checked(candidate, reference, processed)
    assert result["status"] == "withheld", (result, trace)
    assert trace["compound_event_proved"] is False
    assert trace["event_proof_trace"]["search_complete"] is False
    assert trace["event_proof_trace"]["reason_code"] == "compound_event_proof_budget_exceeded"
    assert check_result(result)["exit_code"] == 2


@pytest.mark.parametrize("failure", ("wrong_sample", "wrong_length", "wrong_gain", "wrong_point", "not_dict"))
def test_unit_outer_engine_independently_rejects_malformed_complete_render(candidate, monkeypatch, failure):
    # Unit contract injection only: no fabricated waveform evidence is used
    # as a positive case. The outer analyzer must reject a malformed witness.
    reference, processed = _pair("repeat", 400)
    wrong = processed.samples[LEAD_MS * 8:].copy()
    if failure == "wrong_sample":
        wrong[57000] += Q
    elif failure == "wrong_length":
        wrong = wrong[:-1]
    proof = {"point": (SOURCE_START_MS + 400) * 8, "length": 400 * 8,
             "kind": "repeat", "gain": GAIN, "rendered": wrong,
             "gain_search_trace": {"search_complete": True}}
    if failure == "wrong_gain":
        proof["gain"] = .73
    elif failure == "wrong_point":
        proof["point"] += 1
    elif failure == "not_dict":
        proof = [proof]
    monkeypatch.setattr(candidate, "prove_event", lambda *args: (
        deepcopy(proof), {"search_complete": True, "reason_code": "unit_fake_witness"}))
    result, trace = _checked(candidate, reference, processed)
    assert result["status"] == "withheld", (result, trace)
    assert trace["compound_event_proved"] is False
    assert trace["compound_event_failure"] == "compound_event_whole_output_exact_proof_failed"


@pytest.mark.parametrize("failure", ("wrong_sample", "wrong_length", "not_array", "nan_gain", "wrong_gain"))
def test_unit_event_search_rejects_malformed_gain_witness(monkeypatch, failure):
    proof_module = importlib.import_module("audio_regression.compound_event_proof")
    reference, processed = _pair("delete", 400)
    target = processed.samples[LEAD_MS * 8:]
    rendered = target.copy()
    gain = GAIN
    if failure == "wrong_sample":
        rendered[15000] += Q
    elif failure == "wrong_length":
        rendered = rendered[:-1]
    elif failure == "not_array":
        rendered = rendered.tolist()
    elif failure == "nan_gain":
        gain = float("nan")
    else:
        gain = .73
    monkeypatch.setattr(proof_module, "solve_gain", lambda *args: (
        {"gain": gain, "rendered": rendered}, {"nodes_visited": 1, "search_complete": True}))
    point = SOURCE_START_MS * 8
    proof, trace = proof_module.prove_event(reference.samples, target, "delete", 400 * 8, point, point)
    assert proof is None
    assert trace["search_complete"] is False
    assert trace["reason_code"] == "compound_event_invalid_exact_witness"
    json.dumps(trace, allow_nan=False)


def test_unit_a_witness_from_incomplete_gain_search_cannot_establish_geometry_uniqueness(monkeypatch):
    proof_module = importlib.import_module("audio_regression.compound_event_proof")
    reference, processed = _pair("delete", 400)
    target = processed.samples[LEAD_MS * 8:]
    monkeypatch.setattr(proof_module, "solve_gain", lambda *args: (
        {"gain": GAIN, "rendered": target.copy()},
        {"nodes_visited": 128, "search_complete": False, "reason_code": "unit_exhaustion"}))
    point = SOURCE_START_MS * 8
    proof, trace = proof_module.prove_event(reference.samples, target, "delete", 400 * 8, point, point)
    assert proof is None
    assert trace["search_complete"] is False
    assert trace["reason_code"] == "compound_event_gain_search_incomplete"


def test_unit_already_found_witness_does_not_hide_later_incomplete_geometry_search(monkeypatch):
    proof_module = importlib.import_module("audio_regression.compound_event_proof")
    reference, processed = _pair("delete", 400)
    target = processed.samples[LEAD_MS * 8:]
    count = 0

    def fake_solver(*args):
        nonlocal count
        count += 1
        return ({"gain": GAIN, "rendered": target.copy()}, {
            "nodes_visited": 1, "search_complete": count == 1,
            "reason_code": "unit_first_witness_then_exhaustion"})

    monkeypatch.setattr(proof_module, "solve_gain", fake_solver)
    point = SOURCE_START_MS * 8
    proof, trace = proof_module.prove_event(reference.samples, target, "delete", 400 * 8, point, point + 8)
    assert count == 2
    assert proof is None
    assert trace["feasible_candidate_count"] == 1
    assert trace["search_complete"] is False
    assert trace["every_supported_boundary_checked"] is False
    assert trace["reason_code"] == "compound_event_gain_search_incomplete"


@pytest.mark.parametrize("kind", ("delete", "repeat"))
def test_odd16k_sample_count_is_not_silently_truncated_into_supported_event_class(candidate, kind):
    reference = _audio(np.concatenate((_reference().samples, [0.])))
    processed = _transform(_edited(reference.samples, kind, length_ms=400))
    baseline, _ = compound_engine.analyze_buffers_with_trace(reference, processed, SETTINGS)
    # Raw buffers preserve historical ceil-analysis coordinates. The public
    # facade maps only a proved sub-sample terminal padding before strict
    # validation; a separate public-API test below enforces that contract.
    result, trace = _checked(candidate, reference, processed, strict_result=False)
    _preserved(result, baseline)
    assert trace["compound_event_attempted"] is False
    assert trace["compound_event_proved"] is False


@pytest.mark.parametrize("kind", ("delete", "repeat"))
def test_public_api_odd_source_result_is_strict_after_existing_terminal_endpoint_mapping(tmp_path, kind):
    reference = _audio(np.concatenate((_reference().samples, [0.])))
    processed = _transform(_edited(reference.samples, kind, length_ms=400))
    reference_path, processed_path = tmp_path / "owned-reference.wav", tmp_path / "owned-processed.wav"
    reference_bytes = encode_wav(reference.samples, SOURCE_RATE)
    processed_bytes = encode_wav(processed.samples, TARGET_RATE)
    reference_path.write_bytes(reference_bytes)
    processed_path.write_bytes(processed_bytes)
    baseline, _ = analyze_pair_with_trace(reference_path, processed_path, engine="v7",
        allow_gain=True, allow_resampling=True)
    result, trace = analyze_pair_with_trace(reference_path, processed_path, engine="v8",
        allow_gain=True, allow_resampling=True)
    validate_analysis_result(result)
    _preserved(result, baseline)
    assert trace["compound_event_attempted"] is False
    assert trace["compound_event_proved"] is False
    assert check_result(result)["exit_code"] == check_result(baseline)["exit_code"]
    assert reference_path.read_bytes() == reference_bytes
    assert processed_path.read_bytes() == processed_bytes


@pytest.mark.parametrize("reason", ("resampling_not_declared", "gain_change_not_declared",
                                   "non_silent_file_edge_change", "initial_delay_outside_declared_search",
                                   "raw_landmark_insufficient_unique_anchors",
                                   "raw_landmark_ambiguous_event_boundary"))
def test_unit_policy_or_ambiguity_withhold_cannot_enter_event_search(candidate, monkeypatch, reason):
    reference, processed = _pair("repeat", 400)
    baseline, old_trace = compound_engine.analyze_buffers_with_trace(reference, processed, SETTINGS)
    baseline = deepcopy(baseline)
    baseline.update(status="withheld", reason_code=reason, events=None,
                    content_preservation_status="withheld")
    baseline.pop("alignment_segments", None)
    monkeypatch.setattr(candidate.compound_engine, "analyze_buffers_with_trace", lambda *args: (
        deepcopy(baseline), deepcopy(old_trace)))
    monkeypatch.setattr(candidate, "prove_event", lambda *args: pytest.fail("Forbidden rescue was attempted."))
    result, trace = _checked(candidate, reference, processed)
    _preserved(result, baseline)
    assert trace["compound_event_attempted"] is False
    assert trace["compound_event_proved"] is False


