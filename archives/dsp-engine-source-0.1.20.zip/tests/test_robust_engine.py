"""New development regressions; never frozen final-evaluation inputs."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import numpy as np
import pytest
from scipy.signal import chirp, resample_poly

from audio_regression.audio import decode_wav, encode_wav
from audio_regression.engine import EngineConfig, EngineConfigError, analyze_buffers as analyze_v1
from audio_regression.robust_engine import (
    CONTEXT_SAMPLES, ENGINE, HOP, METHOD, PCM16_STEP, REVALIDATION_POLICY,
    _merge_revalidated_matches, _revalidate_compound, analyze_buffers,
    analyze_buffers_with_trace, analyze_wavs_with_trace,
)


def _signal(rate=8000, seconds=6.0, seed=890041):
    rng = np.random.default_rng(seed)
    t = np.arange(round(rate * seconds)) / rate
    values = np.convolve(rng.normal(size=len(t)), [.1, .2, .4, .2, .1], "same")
    envelope = np.interp(np.linspace(0, 60, len(t)), np.arange(61), rng.uniform(.2, 1.0, 61))
    values = envelope * (values + .2 * chirp(t, 213, seconds, 2970, method="quadratic"))
    return values * (.23 / np.max(np.abs(values)))


def _audio(values, rate=8000):
    return decode_wav(encode_wav(values, rate))


def _run(kind, i0, i1, j0=None, j1=None):
    return {"kind": kind, "reference_start_frame": i0, "reference_end_frame": i1,
            "processed_start_frame": i0 if j0 is None else j0,
            "processed_end_frame": i1 if j1 is None else j1}


def _balanced_case(side="internal", length=1):
    x = _audio(_signal()).samples
    total = len(x) // HOP
    if side == "start":
        runs = [_run("compound", 0, length), _run("match", length, total)]
        anchored = {1: {**runs[1], "offset_samples": 0}}
        index = 0
    elif side == "end":
        runs = [_run("match", 0, total - length), _run("compound", total - length, total)]
        anchored = {0: {**runs[0], "offset_samples": 0}}
        index = 1
    else:
        runs = [_run("match", 0, 200), _run("compound", 200, 200 + length),
                _run("match", 200 + length, total)]
        anchored = {0: {**runs[0], "offset_samples": 0}, 2: {**runs[2], "offset_samples": 0}}
        index = 1
    return x, runs, anchored, index


@pytest.mark.parametrize("side", ["internal", "start", "end"])
@pytest.mark.parametrize("length", [1, 2, 4])
@pytest.mark.parametrize("gain", [.5, 1.0, 2.0])
def test_physically_bounded_balanced_cancellation_requires_raw_revalidation(side, length, gain):
    x, runs, anchored, index = _balanced_case(side, length)
    y = np.rint(gain * x * 32768) / 32768
    record = _revalidate_compound(index, runs, anchored, x, y, gain)
    assert record["accepted"] is True
    assert record["reason_code"] == "pcm16_cancellation_revalidated"
    assert record["maximum_absolute_residual"] <= record["maximum_absolute_residual_bound"]
    assert record["rms_residual"] <= record["rms_residual_bound"]
    assert len(record["context"]) == (2 if side == "internal" else 1)


@pytest.mark.parametrize("change", ["substitution", "dropout", "reversal", "impulse"])
@pytest.mark.parametrize("side", ["internal", "start", "end"])
def test_actual_balanced_raw_edits_are_never_repaired(change, side):
    x, runs, anchored, index = _balanced_case(side, 2)
    y = x.copy()
    first, last = runs[index]["reference_start_frame"] * HOP, runs[index]["reference_end_frame"] * HOP
    if change == "substitution":
        y[first:last] = _signal(seed=991607)[first:last]
    elif change == "dropout":
        y[first:last] = 0
    elif change == "reversal":
        y[first:last] = y[first:last][::-1]
    else:
        y[first + HOP // 2] += 20 * PCM16_STEP
    record = _revalidate_compound(index, runs, anchored, x, y, 1.0)
    assert record["accepted"] is False
    assert record["reason_code"] == "suspicious_samples_exceed_pcm16_error_budget"


def test_no_thresholds_are_selected_from_input_results():
    assert REVALIDATION_POLICY["pcm16_step"] == 1 / 32768
    assert REVALIDATION_POLICY["maximum_balanced_span_ms"] == 40
    assert REVALIDATION_POLICY["context_duration_ms"] == 240
    assert REVALIDATION_POLICY["minimum_context_correlation"] == .90
    assert REVALIDATION_POLICY["minimum_context_rms_pcm16_steps"] == 8
    assert CONTEXT_SAMPLES == 1920


@pytest.mark.parametrize("length", [5, 20, 100])
def test_compound_over_existing_40ms_budget_is_never_repaired(length):
    x, runs, anchored, index = _balanced_case(length=length)
    record = _revalidate_compound(index, runs, anchored, x, x, 1.0)
    assert not record["accepted"]
    assert record["reason_code"] == "not_short_balanced_cancellation"


def test_net_offset_change_and_unanchored_cancellation_are_never_repaired():
    x, runs, anchored, index = _balanced_case()
    anchored[2]["offset_samples"] = HOP
    assert _revalidate_compound(index, runs, anchored, x, x, 1.0)["reason_code"] == "independent_anchor_offsets_not_equal"
    anchored.pop(2)
    assert _revalidate_compound(index, runs, anchored, x, x, 1.0)["reason_code"] == "independent_anchor_offsets_not_equal"


def test_equal_span_coordinates_must_follow_exact_anchor_offset():
    x, runs, anchored, index = _balanced_case()
    runs[index]["processed_start_frame"] += 1
    runs[index]["processed_end_frame"] += 1
    assert _revalidate_compound(index, runs, anchored, x, x, 1.0)["reason_code"] == "compound_coordinates_not_at_anchor_offset"


@pytest.mark.parametrize("gain", [0, -1, float("inf"), float("nan")])
def test_positive_finite_gain_is_mandatory(gain):
    x, runs, anchored, index = _balanced_case()
    assert _revalidate_compound(index, runs, anchored, x, x, gain)["accepted"] is False


@pytest.mark.parametrize("side", ["start", "end"])
def test_exact_file_edge_and_zero_offset_are_mandatory(side):
    x, runs, anchored, index = _balanced_case(side)
    next(iter(anchored.values()))["offset_samples"] = 1
    assert _revalidate_compound(index, runs, anchored, x, x, 1.0)["reason_code"] == "file_edge_not_exactly_anchored"


def test_quantization_ambiguous_context_is_not_repaired():
    x, runs, anchored, index = _balanced_case()
    quiet = x * .0001
    record = _revalidate_compound(index, runs, anchored, quiet, quiet, 1.0)
    assert not record["accepted"]
    assert record["reason_code"] == "raw_context_below_quantization_activity_floor"


def test_suspicious_context_blocks_otherwise_identical_compound():
    x, runs, anchored, index = _balanced_case()
    y = x.copy()
    start = runs[index]["reference_end_frame"] * HOP
    y[start:start + CONTEXT_SAMPLES] *= -1
    assert _revalidate_compound(index, runs, anchored, x, y, 1.0)["reason_code"] == "raw_context_correlation_not_supported"


def test_context_boundary_discontinuity_blocks_a_bounded_compound():
    x, runs, anchored, index = _balanced_case()
    y = x.copy()
    first = runs[index]["reference_start_frame"] * HOP
    y[first - 1] += 20 * PCM16_STEP
    assert _revalidate_compound(index, runs, anchored, x, y, 1.0)["reason_code"] == "raw_boundary_continuity_not_supported"


def test_merge_only_contiguous_equal_offset_matches():
    runs = [_run("match", 0, 100), _run("compound", 100, 101), _run("match", 101, 200)]
    assert _merge_revalidated_matches(runs, {1}) == [_run("match", 0, 200)]
    assert runs[1]["kind"] == "compound"
    runs[2]["processed_start_frame"] += 1
    runs[2]["processed_end_frame"] += 1
    merged = _merge_revalidated_matches(runs, {1})
    assert len(merged) == 2
    assert merged[0] == _run("match", 0, 101)


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
@pytest.mark.parametrize("gain", [.5, 1.0])
def test_declared_normal_resampling_and_quantized_gain_are_supported(rate, gain):
    original = _audio(_signal(rate=rate), rate)
    factor = np.gcd(rate, 8000)
    transformed = resample_poly(original.samples, 8000 // factor, rate // factor)
    processed = _audio(transformed * gain)
    result, trace = analyze_buffers_with_trace(original, processed, EngineConfig(allow_gain=True, allow_resampling=True))
    assert result["engine"] == ENGINE
    assert result["analysis"]["method"] == METHOD
    assert result["status"] == "analyzed"
    assert result["events"] == []
    assert trace["result_status"] == "analyzed"
    assert trace["withheld_branch"] is None
    assert trace["reference_sha256"] == original.sha256
    assert trace["processed_sha256"] == processed.sha256
    json.dumps(result, allow_nan=False)
    json.dumps(trace, allow_nan=False)


@pytest.mark.parametrize("kind", ["delete", "repeat"])
@pytest.mark.parametrize("length_ms", [200, 400, 750])
def test_raw_anchored_supported_defects_preserve_v1_event_geometry(kind, length_ms):
    x = _audio(_signal()).samples
    first, last = 1700 * 8, (1700 + length_ms) * 8
    edited = np.concatenate((x[:first], x[last:])) if kind == "delete" else np.concatenate((x[:last], x[first:last], x[last:]))
    reference, processed = _audio(x), _audio(edited)
    old, new = analyze_v1(reference, processed), analyze_buffers(reference, processed)
    assert new["status"] == old["status"] == "analyzed"
    assert new["events"] == old["events"]
    assert len(new["events"]) == 1
    assert new["events"][0]["type"] == kind


@pytest.mark.parametrize("kind", ["dropout", "substitution", "unrelated_insert", "balanced_mixed", "drift", "periodic"])
def test_unexplained_changes_and_periodic_ambiguity_stay_withheld(kind):
    x = _audio(_signal()).samples
    y = x.copy()
    first, last = 1700 * 8, 2100 * 8
    if kind == "dropout":
        y[first:last] = 0
    elif kind == "substitution":
        y[first:last] = _signal(seed=106400)[first:last]
    elif kind == "unrelated_insert":
        y = np.concatenate((x[:first], _signal(seed=920313)[first:last], x[first:]))
    elif kind == "balanced_mixed":
        # Close unrelated insertion and deletion keep duration but are not a
        # physically bounded quantization cancellation.
        y[first:last] = _signal(seed=319800)[first:last]
    elif kind == "drift":
        y = resample_poly(x, 101, 100)
    else:
        t = np.arange(len(x)) / 8000
        x = y = .2 * np.sin(2 * np.pi * 440 * t)
    result, trace = analyze_buffers_with_trace(_audio(x), _audio(y))
    assert result["status"] == "withheld"
    assert result["events"] is None
    assert trace["withheld_branch"] == result["reason_code"]


@pytest.mark.parametrize("side", ["start", "end"])
def test_non_silent_file_crop_is_not_repaired(side):
    x = _signal()
    y = x[2400:] if side == "start" else x[:-2400]
    assert analyze_buffers(_audio(x), _audio(y))["status"] == "withheld"


def test_optional_codec_profile_is_explicitly_not_supported():
    with pytest.raises(EngineConfigError):
        analyze_buffers(_audio(_signal()), _audio(_signal()), EngineConfig(profile="telephone"))


@pytest.mark.parametrize("config", [1, {}, "basic", False])
def test_invalid_candidate_config_does_not_enter_detector(config):
    with pytest.raises(EngineConfigError):
        analyze_buffers(_audio(_signal()), _audio(_signal()), config)


def test_buffer_inputs_stay_immutable_and_trace_contains_no_path_or_audio():
    reference, processed = _audio(_signal()), _audio(_signal() * .5)
    before = reference.samples.copy(), processed.samples.copy()
    result, trace = analyze_buffers_with_trace(reference, processed, EngineConfig(allow_gain=True))
    np.testing.assert_array_equal(reference.samples, before[0])
    np.testing.assert_array_equal(processed.samples, before[1])
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    assert all(name not in trace for name in ("reference_path", "processed_path", "samples", "ground_truth"))


def test_actual_path_inputs_keep_exact_hashes_and_contents(tmp_path: Path):
    first, second = encode_wav(_signal(), 8000), encode_wav(_signal() * .5, 8000)
    ref, proc = tmp_path / "reference.wav", tmp_path / "processed.wav"
    ref.write_bytes(first)
    proc.write_bytes(second)
    result, trace = analyze_wavs_with_trace(ref, proc, EngineConfig(allow_gain=True))
    assert result["status"] == "analyzed"
    assert trace["reference_sha256"] == hashlib.sha256(first).hexdigest()
    assert trace["processed_sha256"] == hashlib.sha256(second).hexdigest()
    assert ref.read_bytes() == first and proc.read_bytes() == second
