import json
from pathlib import Path

import pytest

from audio_regression import pipeline_cli
from audio_regression.fixtures import generate_case


def _source_and_plan(tmp_path, stages=None):
    source = tmp_path / "source.wav"
    source.write_bytes(generate_case("clean", seed=59331).reference_wav)
    plan = tmp_path / "plan.json"
    plan.write_text(json.dumps({"schema_version": 1, "stages": stages or [
        {"kind": "gain", "gain_db": -6},
        {"kind": "split_join", "segment_ms": 400},
    ]}), encoding="utf-8")
    return source, plan


def test_run_cli_writes_bounded_artifacts_and_narrow_clear(tmp_path, capsys):
    source, plan = _source_and_plan(tmp_path)
    before = source.read_bytes()
    output = tmp_path / "new_output"
    assert pipeline_cli.main(["run", "--source", str(source), "--plan", str(plan), "--output-dir", str(output)]) == 0
    summary = json.loads(capsys.readouterr().out)
    assert summary["gate_state"] == "clear_supported_temporal_check"
    assert summary["first_concern"] is None
    assert summary["complete_audio_approval"] is False
    assert (output / "run_result.json").is_file()
    assert (output / "run_report.html").is_file()
    assert source.read_bytes() == before


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_cli_concern_is_not_hidden_by_a_later_clear_stage(tmp_path, capsys, kind):
    order = list(range(15))
    altered = [index for index in order if index != 5] if kind == "delete" else order[:6] + [5] + order[6:]
    source, plan = _source_and_plan(tmp_path, [
        {"kind": "split_join", "segment_ms": 400, "order": altered},
        {"kind": "gain", "gain_db": -6},
    ])
    assert pipeline_cli.main(["run", "--source", str(source), "--plan", str(plan), "--output-dir", str(tmp_path / "out")]) == 1
    summary = json.loads(capsys.readouterr().out)
    assert summary["first_concern"]["stage_index"] == 1
    assert summary["gate_state"] == "review_required"


def test_runtime_stage_failure_cannot_exit_clear(tmp_path, capsys):
    source, plan = _source_and_plan(tmp_path, [
        {"kind": "split_join", "segment_ms": 400, "order": [999]},
        {"kind": "gain", "gain_db": -6},
    ])
    output = tmp_path / "out"
    assert pipeline_cli.main(["run", "--source", str(source), "--plan", str(plan), "--output-dir", str(output)]) == 2
    summary = json.loads(capsys.readouterr().out)
    assert summary["status"] == "incomplete"
    assert summary["gate_state"] == "blocked"
    assert summary["first_concern"]["category"] == "execution_error"


@pytest.mark.parametrize("payload", [
    '{"schema_version":2,"stages":[]}',
    '{"schema_version":1,"schema_version":1,"stages":[]}',
    '{"schema_version":1,"stages":[{"kind":"shell","command":"unsafe"}]}',
])
def test_invalid_plan_has_no_output_or_pass(tmp_path, capsys, payload):
    source, plan = _source_and_plan(tmp_path)
    plan.write_text(payload, encoding="utf-8")
    output = tmp_path / "out"
    assert pipeline_cli.main(["run", "--source", str(source), "--plan", str(plan), "--output-dir", str(output)]) == 3
    summary = json.loads(capsys.readouterr().out)
    assert summary["gate_state"] == "blocked"
    assert not output.exists()


def test_cli_preserves_existing_directory_and_report(tmp_path, capsys):
    source, plan = _source_and_plan(tmp_path)
    output = tmp_path / "out"
    output.mkdir()
    sentinel = output / "sentinel.txt"
    sentinel.write_text("keep", encoding="utf-8")
    assert pipeline_cli.main(["run", "--source", str(source), "--plan", str(plan), "--output-dir", str(output)]) == 3
    assert sentinel.read_text(encoding="utf-8") == "keep"
    capsys.readouterr()
    new_output = tmp_path / "new"
    assert pipeline_cli.main(["run", "--source", str(source), "--plan", str(plan), "--output-dir", str(new_output)]) == 0
    capsys.readouterr()
    report = tmp_path / "report.html"
    assert pipeline_cli.main(["report", "--input", str(new_output / "run_result.json"), "--output", str(report)]) == 0
    capsys.readouterr()
    before = report.read_bytes()
    assert pipeline_cli.main(["report", "--input", str(new_output / "run_result.json"), "--output", str(report)]) == 3
    summary = json.loads(capsys.readouterr().out)
    assert summary["reason_code"] == "output_exists"
    assert report.read_bytes() == before


def test_untrusted_result_is_not_rendered(tmp_path, capsys):
    payload = tmp_path / "unknown.json"
    payload.write_text('{"schema_version":999,"engine":"unknown"}', encoding="utf-8")
    report = tmp_path / "report.html"
    assert pipeline_cli.main(["report", "--input", str(payload), "--output", str(report)]) == 3
    assert json.loads(capsys.readouterr().out)["gate_state"] == "blocked"
    assert not report.exists()


def test_report_path_resolution_failure_is_blocked_without_traceback(tmp_path, capsys, monkeypatch):
    payload = tmp_path / "unknown.json"
    payload.write_text('{"schema_version":999,"engine":"unknown"}', encoding="utf-8")
    report = tmp_path / "report.html"

    def unavailable_resolution(*args, **kwargs):
        raise RuntimeError("Private path detail must not be exposed.")

    monkeypatch.setattr(Path, "resolve", unavailable_resolution)
    assert pipeline_cli.main(["report", "--input", str(payload), "--output", str(report)]) == 3
    summary = json.loads(capsys.readouterr().out)
    assert summary["reason_code"] == "pipeline_file_error"
    assert summary["gate_state"] == "blocked"
    assert not report.exists()
