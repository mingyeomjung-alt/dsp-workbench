"""Black-box checks for the M1 global-alignment baseline.

Inputs are generated here rather than by the engine's scenario generator. These
checks establish the baseline contract, not local-defect detection performance.
"""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

import numpy as np
import pytest
from scipy.signal import resample_poly

from audio_regression.audio import decode_wav, encode_wav
from audio_regression.baseline import (
    BaselineConfig,
    BaselineConfigError,
    _lag_scores,
    compare_buffers,
    compare_wavs,
)


def _signal(*, sample_rate_hz: int = 16000, seconds: float = 4.0, seed: int = 913) -> np.ndarray:
    """A reproducible nonperiodic, bounded input with a changing envelope."""
    rng = np.random.default_rng(seed)
    count = round(sample_rate_hz * seconds)
    noise = rng.standard_normal(count)
    # Finite smoothing and a nonperiodic envelope make alignment identifiable
    # without relying on a model, a personal recording, or the fixture engine.
    filtered = np.convolve(noise, np.array([0.12, 0.24, 0.28, 0.24, 0.12]), mode="same")
    knots = rng.uniform(0.18, 1.0, 37)
    envelope = np.interp(np.linspace(0, 36, count), np.arange(37), knots)
    signal = filtered * envelope
    return signal / np.max(np.abs(signal)) * 0.22


def _audio(samples: np.ndarray, sample_rate_hz: int = 16000):
    return decode_wav(encode_wav(samples, sample_rate_hz))


def _compare(reference: np.ndarray, processed: np.ndarray, config: BaselineConfig | None = None):
    return compare_buffers(_audio(reference), _audio(processed), config=config or BaselineConfig())


def _assert_safe_contract(result: dict) -> None:
    assert result["schema_version"] == 1
    assert result["engine"] == "global_alignment_baseline_v1"
    assert result["status"] in {"measured", "withheld"}
    assert result["content_preservation_status"] == "not_assessed_by_global_baseline"
    assert result["events"] is None
    if result["status"] == "measured":
        assert result["reason_code"] is None
    else:
        assert result["reason_code"] is not None
    # JSON serialization must reject infinities and NaNs instead of quietly
    # generating a nonstandard report that another language cannot decode.
    json.dumps(result, allow_nan=False)
    if result["status"] == "withheld":
        assert result["metrics"]["aligned"] is None
        for key in ("estimated_delay_ms", "gain_estimate", "applied_gain", "overlap_ms"):
            assert result["alignment"][key] is None


def test_unchanged_signal_has_zero_delay_and_error() -> None:
    signal = _signal()
    result = _compare(signal, signal)
    _assert_safe_contract(result)
    assert result["status"] == "measured"
    assert result["alignment"]["estimated_delay_ms"] == pytest.approx(0.0, abs=1.0)
    assert result["alignment"]["correlation"] > 0.999
    assert result["alignment"]["ambiguous"] is False
    assert result["alignment"]["gain_estimate"] == pytest.approx(1.0, abs=0.001)
    assert result["metrics"]["raw"]["normalized_rmse"] < 1e-6
    assert result["metrics"]["aligned"]["normalized_rmse"] < 1e-6


@pytest.mark.parametrize("delay_ms", [75.0, 240.0, 650.0])
def test_processed_later_has_positive_delay(delay_ms: float) -> None:
    signal = _signal()
    padding = np.zeros(round(delay_ms * 16))
    result = _compare(signal, np.concatenate([padding, signal]))
    _assert_safe_contract(result)
    assert result["status"] == "measured"
    assert result["alignment"]["estimated_delay_ms"] == pytest.approx(delay_ms, abs=2.0)
    assert result["metrics"]["raw"]["normalized_rmse"] > 0.1
    assert result["metrics"]["aligned"]["normalized_rmse"] < 0.01
    assert result["alignment"]["overlap_ms"] == pytest.approx(4000.0, abs=3.0)


@pytest.mark.parametrize("delay_ms", [90.0, 180.0, 500.0])
def test_reference_later_has_negative_delay(delay_ms: float) -> None:
    signal = _signal()
    padding = np.zeros(round(delay_ms * 16))
    result = _compare(np.concatenate([padding, signal]), signal)
    _assert_safe_contract(result)
    assert result["status"] == "measured"
    assert result["alignment"]["estimated_delay_ms"] == pytest.approx(-delay_ms, abs=2.0)
    assert result["metrics"]["aligned"]["normalized_rmse"] < 0.01


def test_undeclared_gain_is_reported_but_not_corrected() -> None:
    signal = _signal()
    result = _compare(signal, signal * 0.5)
    _assert_safe_contract(result)
    assert result["status"] == "measured"
    assert result["alignment"]["gain_estimate"] == pytest.approx(0.5, abs=0.005)
    assert result["alignment"]["applied_gain"] == pytest.approx(1.0)
    assert result["metrics"]["aligned"]["normalized_rmse"] > 0.1


def test_declared_gain_is_corrected_without_changing_raw_diagnostic() -> None:
    signal = _signal()
    undeclared = _compare(signal, signal * 0.5)
    declared = _compare(signal, signal * 0.5, BaselineConfig(allow_gain=True))
    _assert_safe_contract(declared)
    assert declared["status"] == "measured"
    assert declared["alignment"]["gain_estimate"] == pytest.approx(0.5, abs=0.005)
    assert declared["alignment"]["applied_gain"] == pytest.approx(0.5, abs=0.005)
    assert declared["metrics"]["raw"] == undeclared["metrics"]["raw"]
    assert declared["metrics"]["aligned"]["normalized_rmse"] < 0.01


def test_sample_rate_mismatch_needs_declared_resampling() -> None:
    signal = _signal()
    lower_rate = resample_poly(signal, 1, 2)
    reference = _audio(signal, 16000)
    processed = _audio(lower_rate, 8000)
    withheld = compare_buffers(reference, processed)
    _assert_safe_contract(withheld)
    assert withheld["status"] == "withheld"
    assert withheld["reason_code"] == "resampling_not_declared"
    measured = compare_buffers(reference, processed, config=BaselineConfig(allow_resampling=True))
    _assert_safe_contract(measured)
    assert measured["status"] == "measured"
    assert measured["alignment"]["estimated_delay_ms"] == pytest.approx(0.0, abs=2.0)
    assert measured["alignment"]["correlation"] > 0.9


@pytest.mark.parametrize("value", [0.0, 0.125, -0.25])
@pytest.mark.parametrize("sample_rate_hz", [8000, 16000, 44100, 48000])
def test_silence_and_dc_are_withheld(value: float, sample_rate_hz: int) -> None:
    constant = np.full(4 * sample_rate_hz, value)
    result = compare_buffers(_audio(constant, sample_rate_hz), _audio(constant, sample_rate_hz))
    _assert_safe_contract(result)
    assert result["status"] == "withheld"
    assert result["reason_code"] == "insufficient_signal_energy"


def test_periodic_tone_is_withheld_as_ambiguous() -> None:
    time = np.arange(64000) / 16000
    periodic = 0.15 * np.sin(2 * np.pi * 440 * time)
    result = _compare(periodic, periodic)
    _assert_safe_contract(result)
    assert result["status"] == "withheld"
    assert result["reason_code"] == "ambiguous_alignment"
    assert result["alignment"]["ambiguous"] is True


def test_unrelated_signals_are_withheld() -> None:
    result = _compare(_signal(seed=21), _signal(seed=999))
    _assert_safe_contract(result)
    assert result["status"] == "withheld"
    assert result["reason_code"] == "weak_correspondence"


@pytest.mark.parametrize("defect", ["delete", "repeat"])
def test_baseline_never_claims_local_defect_detection(defect: str) -> None:
    signal = _signal()
    start, stop = 24000, 28800
    if defect == "delete":
        processed = np.concatenate([signal[:start], signal[stop:]])
    else:
        processed = np.concatenate([signal[:stop], signal[start:stop], signal[stop:]])
    result = _compare(signal, processed)
    _assert_safe_contract(result)
    # A numerical global measurement must never be presented as evidence that
    # the full recording is intact. Local events belong to the later M2 engine.
    assert result["events"] is None
    assert result["content_preservation_status"] == "not_assessed_by_global_baseline"


@pytest.mark.parametrize(
    "kwargs",
    [
        {"allow_gain": 1},
        {"allow_gain": "false"},
        {"allow_resampling": 0},
        {"allow_resampling": None},
        {"max_delay_ms": -1},
        {"max_delay_ms": 5000.1},
        {"max_delay_ms": float("nan")},
        {"max_delay_ms": float("inf")},
        {"max_delay_ms": True},
        {"max_delay_ms": "1000"},
        {"max_delay_ms": 10**1000},
    ],
)
def test_invalid_configuration_uses_stable_error(kwargs: dict) -> None:
    with pytest.raises(BaselineConfigError) as caught:
        config = BaselineConfig(**kwargs)
        _compare(_signal(), _signal(), config)
    assert caught.value.code == "invalid_configuration"


@pytest.mark.parametrize("delay_scalar", [np.float32(1000.0), np.int64(1000)])
def test_numpy_numeric_configuration_is_normalized_and_json_safe(delay_scalar) -> None:
    config = BaselineConfig(max_delay_ms=delay_scalar)
    result = _compare(_signal(), _signal(), config)
    _assert_safe_contract(result)
    assert result["status"] == "measured"
    assert type(config.max_delay_ms) is float
    assert type(result["configuration"]["max_delay_ms"]) is float
    assert result["configuration"]["max_delay_ms"] == pytest.approx(1000.0)


def test_overlap_centered_ncc_matches_direct_correlation_for_unequal_lengths() -> None:
    rng = np.random.default_rng(2209)
    reference = rng.normal(0.4, 0.1, 14000)
    processed = rng.normal(-0.3, 0.08, 17000)
    processed[93:14093] = 1.7 * reference - 0.7 + rng.normal(0.0, 0.002, 14000)
    lags, scores, starts, ends = _lag_scores(reference, processed, max_delay_ms=20.0)
    for lag in (-160, -79, 0, 93, 160):
        index = int(np.flatnonzero(lags == lag)[0])
        start, end = int(starts[index]), int(ends[index])
        direct = np.corrcoef(
            reference[start:end],
            processed[start + lag:end + lag],
        )[0, 1]
        assert scores[index] == pytest.approx(float(direct), abs=1e-12)


def test_zero_maximum_delay_is_supported() -> None:
    result = _compare(_signal(), _signal(), BaselineConfig(max_delay_ms=0.0))
    _assert_safe_contract(result)
    assert result["status"] == "measured"
    assert result["alignment"]["estimated_delay_ms"] == pytest.approx(0.0)


def test_delay_on_search_boundary_is_not_certified() -> None:
    signal = _signal()
    processed = np.concatenate([np.zeros(3840), signal])
    result = _compare(signal, processed, BaselineConfig(max_delay_ms=240.0))
    _assert_safe_contract(result)
    assert result["status"] == "withheld"
    assert result["reason_code"] == "delay_at_search_boundary"


def test_delay_outside_search_budget_is_withheld() -> None:
    signal = _signal()
    processed = np.concatenate([np.zeros(12000), signal])
    result = _compare(signal, processed, BaselineConfig(max_delay_ms=500.0))
    _assert_safe_contract(result)
    assert result["status"] == "withheld"


def test_buffer_comparison_does_not_mutate_decoded_audio() -> None:
    reference = _audio(_signal())
    processed = _audio(_signal() * 0.5)
    # The report is reproducible, and enabling normal-change handling must not
    # modify the caller's source buffers or contaminate a subsequent comparison.
    before = compare_buffers(reference, processed)
    compare_buffers(reference, processed, config=BaselineConfig(allow_gain=True))
    after = compare_buffers(reference, processed)
    assert before == after


def test_path_comparison_preserves_exact_file_hashes_and_content(tmp_path: Path) -> None:
    reference_bytes = encode_wav(_signal(), 16000)
    processed_bytes = encode_wav(_signal() * 0.5, 16000)
    reference_path = tmp_path / "reference.wav"
    processed_path = tmp_path / "processed.wav"
    reference_path.write_bytes(reference_bytes)
    processed_path.write_bytes(processed_bytes)
    result = compare_wavs(reference_path, processed_path, config=BaselineConfig(allow_gain=True))
    _assert_safe_contract(result)
    assert result["reference"]["sha256"] == hashlib.sha256(reference_bytes).hexdigest()
    assert result["processed"]["sha256"] == hashlib.sha256(processed_bytes).hexdigest()
    assert reference_path.read_bytes() == reference_bytes
    assert processed_path.read_bytes() == processed_bytes


def test_import_is_independent_of_voiceguard_and_model_runtimes() -> None:
    script = (
        "import sys; import audio_regression.baseline; "
        "forbidden = ('voiceguard', 'torch', 'onnxruntime', 'sherpa_onnx'); "
        "assert not any(k == p or k.startswith(p + '.') "
        "for k in sys.modules for p in forbidden)"
    )
    environment = dict(os.environ)
    source_path = str(Path(__file__).resolve().parents[1] / "src")
    previous_path = environment.get("PYTHONPATH")
    environment["PYTHONPATH"] = source_path + (os.pathsep + previous_path if previous_path else "")
    completed = subprocess.run(
        [sys.executable, "-c", script],
        check=False,
        capture_output=True,
        text=True,
        env=environment,
    )
    assert completed.returncode == 0, completed.stderr
