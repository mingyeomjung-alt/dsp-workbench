import json

import pytest

from audio_regression import handoff_cli
from test_reporting import sample_result


def _save(tmp_path, value, name="analysis.json"):
    path = tmp_path / name
    path.write_text(json.dumps(value, ensure_ascii=False, allow_nan=False), encoding="utf-8")
    return path


@pytest.mark.parametrize("command", ["generate", "compare", "analyze"])
def test_legacy_commands_delegate_arguments_and_exit_unchanged(monkeypatch, command):
    observed = []
    def original(arguments):
        observed.append(arguments)
        return 23
    monkeypatch.setattr(handoff_cli.legacy_cli, "main", original)
    arguments = [command, "--original-flag", "한국어 파일"]
    assert handoff_cli.main(arguments) == 23
    assert observed == [arguments]


def test_help_lists_new_commands_and_preserves_legacy_discoverability(capsys):
    with pytest.raises(SystemExit) as raised:
        handoff_cli.main(["--help"])
    assert raised.value.code == 0
    text = capsys.readouterr().out
    assert all(command in text for command in ("generate", "compare", "analyze", "report", "check"))


@pytest.mark.parametrize("kind,profile,expected", [
    ("clean", "basic", 0), ("delete", "basic", 1), ("repeat", "basic", 1),
    ("clean", "telephone", 2), ("delete", "telephone", 2),
])
def test_check_exit_policy_and_flags(tmp_path, capsys, kind, profile, expected):
    path = _save(tmp_path, sample_result(kind, profile))
    assert handoff_cli.main(["check", "--input", str(path)]) == expected
    value = json.loads(capsys.readouterr().out)
    assert value["exit_code"] == expected
    assert value["gate_state"] == {0: "clear_supported_temporal_check", 1: "review_required", 2: "blocked"}[expected]
    assert value["complete_audio_approval"] is False
    assert value["commercial_performance_validated"] is False
    assert value["probability_claims"] is False
    assert value["contract_valid"] is True


def test_withheld_and_error_checks_are_blocked(tmp_path, capsys):
    result = sample_result()
    result.update(status="withheld", content_preservation_status="withheld",
                  reason_code="insufficient_unambiguous_anchors", events=None)
    result.pop("alignment_segments")
    for index, value in enumerate((result, {"schema_version": 1, "status": "error", "reason_code": "file_read_error"})):
        path = _save(tmp_path, value, f"held{index}.json")
        assert handoff_cli.main(["check", "--input", str(path)]) == 2
        output = json.loads(capsys.readouterr().out)
        assert output["gate_state"] == "blocked" and output["exit_code"] == 2


@pytest.mark.parametrize("value", [
    {"schema_version": 2, "status": "analyzed"},
    {"schema_version": 1, "engine": "global_alignment_baseline_v1", "status": "measured",
     "content_preservation_status": "not_assessed_by_global_baseline", "events": None},
    {"schema_version": 1, "status": "error", "reason_code": "not_safe", "complete_audio_approval": True},
])
def test_wrong_schema_baseline_and_malformed_never_pass(tmp_path, capsys, value):
    path = _save(tmp_path, value)
    assert handoff_cli.main(["check", "--input", str(path)]) == 2
    output = json.loads(capsys.readouterr().out)
    assert output["gate_state"] == "blocked" and output["contract_valid"] is False
    assert output["complete_audio_approval"] is False
    assert output["policy"] == "safe_automated_temporal_check_v1"
    assert output["reason_code"]


@pytest.mark.parametrize("text", ["{", '{"schema_version":1,"schema_version":1}', '{"value":NaN}'])
def test_malformed_json_emits_structured_blocked_check(tmp_path, capsys, text):
    path = tmp_path / "invalid.json"
    path.write_text(text, encoding="utf-8")
    assert handoff_cli.main(["check", "--input", str(path)]) == 2
    output = json.loads(capsys.readouterr().out)
    assert output["status"] == "error" and output["gate_state"] == "blocked"
    assert output["contract_valid"] is False


def test_report_writes_new_utf8_html_and_structured_summary(tmp_path, capsys):
    path = _save(tmp_path, sample_result("repeat"), "분석.json")
    output = tmp_path / "결과.html"
    original = path.read_bytes()
    assert handoff_cli.main(["report", "--input", str(path), "--output", str(output)]) == 0
    value = json.loads(capsys.readouterr().out)
    assert value["status"] == "generated_html"
    assert "complete_audio_approval" not in value
    assert "반복 후보" in output.read_text(encoding="utf-8")
    assert path.read_bytes() == original


def test_report_existing_output_samepath_and_audio_file_are_preserved(tmp_path, capsys):
    path = _save(tmp_path, sample_result())
    existing = tmp_path / "existing.html"
    existing.write_bytes(b"original")
    audio = tmp_path / "raw.wav"
    audio.write_bytes(b"RIFF-original-input")
    for output in (path, existing, audio):
        original = output.read_bytes()
        assert handoff_cli.main(["report", "--input", str(path), "--output", str(output)]) == 3
        value = json.loads(capsys.readouterr().out)
        assert value == {"schema_version": 1, "status": "error", "reason_code": "output_exists"}
        assert output.read_bytes() == original


def test_report_invalid_input_writes_nothing(tmp_path, capsys):
    path = _save(tmp_path, {"schema_version": 99, "status": "analyzed"})
    output = tmp_path / "none.html"
    assert handoff_cli.main(["report", "--input", str(path), "--output", str(output)]) == 3
    assert json.loads(capsys.readouterr().out)["status"] == "error"
    assert not output.exists()


def test_missing_input_has_structured_errors_for_both_new_commands(tmp_path, capsys):
    missing = tmp_path / "none.json"
    assert handoff_cli.main(["check", "--input", str(missing)]) == 2
    check = json.loads(capsys.readouterr().out)
    assert check["gate_state"] == "blocked" and check["contract_valid"] is False
    assert handoff_cli.main(["report", "--input", str(missing), "--output", str(tmp_path / "none.html")]) == 3
    report = json.loads(capsys.readouterr().out)
    assert report["status"] == "error"
