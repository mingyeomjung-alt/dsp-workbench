"""Native-rate measurement UI semantics, with new owned PCM fixtures only."""

from copy import deepcopy
import json
from pathlib import Path
import stat
from types import SimpleNamespace

import numpy as np
import pytest

from audio_regression.audio import encode_wav
from audio_regression import fullband_cli, fullband_reporting
from audio_regression.fullband_contract import validate_fullband_result
from audio_regression.fullband_reporting import render_fullband_html, write_fullband_html
from audio_regression.fullband_runner import FullbandRunError, run_fullband_measurement
from audio_regression.pipeline_runner import PipelineRunError
from audio_regression.result_contract import ResultContractError


RATES = (8000, 16000, 44100, 48000)


def _pair(tmp_path, rate=8000, *, changed=True, silence=False, count_delta=0, other_rate=None):
    count = rate * 2 + 7
    if silence:
        pcm = np.zeros(count, dtype=np.int16)
    else:
        index = np.arange(count, dtype=np.int64)
        # Own deterministic non-constant PCM, independent of fixture pools.
        pcm = ((index * 137 + 581) % 22001 - 11000).astype(np.int16)
    other = pcm.astype(np.int32).copy()
    if changed:
        other[rate // 2 + 3] += 1
    if count_delta > 0:
        other = np.concatenate((other, np.zeros(count_delta, dtype=np.int32)))
    elif count_delta < 0:
        other = other[:count_delta]
    reference, processed = tmp_path / "reference.wav", tmp_path / "processed.wav"
    reference.write_bytes(encode_wav(pcm.astype(float) / 32768, rate))
    processed.write_bytes(encode_wav(other.astype(float) / 32768, other_rate or rate))
    return reference, processed


def _result(tmp_path, **kwargs):
    reference, processed = _pair(tmp_path, **kwargs)
    return run_fullband_measurement(reference, processed, tmp_path / "new_snapshot")


def _measure_args(reference, processed, output):
    return ["measure", "--reference", str(reference), "--processed", str(processed), "--output-dir", str(output)]


def _report_args(source, destination):
    return ["report", "--input", str(source), "--output", str(destination)]


@pytest.mark.parametrize("rate", RATES)
def test_changed_sample_is_measured_zero_not_a_quality_pass(tmp_path, capsys, rate):
    reference, processed = _pair(tmp_path, rate)
    before = (reference.read_bytes(), processed.read_bytes())
    output = tmp_path / "snapshot"
    assert fullband_cli.main(_measure_args(reference, processed, output)) == 0
    result = json.loads(capsys.readouterr().out)
    validate_fullband_result(result)
    assert result["status"] == "measured"
    assert result["summary"]["exit_code"] == 0
    assert result["summary"]["quality_verdict"] == "not_assessed"
    assert result["comparison"]["unequal_sample_count"] == 1
    assert result["comparison"]["first_changed_sample"] == rate // 2 + 3
    assert result["comparison"]["last_changed_sample"] == rate // 2 + 3
    assert result["comparison"]["maximum_abs_error_pcm16"] == 1
    assert result["comparison"]["changed_frames"] == [{
        "start_sample": rate // 2, "end_sample": rate * 6 // 10, "unequal_sample_count": 1,
    }]
    assert result["reference"]["sample_rate_hz"] == rate
    assert result["processed"]["sample_rate_hz"] == rate
    assert json.loads((output / "fullband_result.json").read_text(encoding="utf-8")) == result
    assert (reference.read_bytes(), processed.read_bytes()) == before
    for key in ("complete_audio_approval", "commercial_performance_validated", "fault_provenance_confirmed", "network_used"):
        assert result[key] is False
    html = render_fullband_html(result)
    assert "전대역 측정 완료 · 음질 판정 아님" in html
    assert "차이가 커도 계산이 끝나면 0" in html
    assert "환경 SNR 아님" in html
    assert "clear_supported" not in html and "합격</" not in html
    assert "변경 샘플이 있는 100 ms 프레임 · 1개" in html


@pytest.mark.parametrize("kind", ["rate", "count"])
def test_mismatch_withholds_only_pair_metrics_not_per_file_values(tmp_path, capsys, kind):
    options = {"rate": 16000, "other_rate": 8000} if kind == "rate" else {"count_delta": 3}
    reference, processed = _pair(tmp_path, **options)
    output = tmp_path / "snapshot"
    assert fullband_cli.main(_measure_args(reference, processed, output)) == 2
    result = json.loads(capsys.readouterr().out)
    assert result["status"] == "comparison_withheld"
    assert result["comparison"]["reason_code"] == f"sample_{kind}_mismatch"
    for key in ("unequal_sample_count", "first_changed_sample", "last_changed_sample",
                "maximum_abs_error_pcm16", "mean_square_error", "signal_to_residual_db",
                "correlation", "residual_bands", "changed_frames"):
        assert result["comparison"][key] is None
    assert result["reference_measurements"]["rms_dbfs"] is not None
    assert result["processed_measurements"]["rms_dbfs"] is not None
    assert result["reference_measurements"]["frames"]
    assert result["processed_measurements"]["frames"]
    html = render_fullband_html(result)
    assert "쌍 비교 보류 · 개별 파일 측정 유지" in html
    assert "원본 · 원래 샘플레이트 측정" in html
    assert "처리본 · 원래 샘플레이트 측정" in html
    assert "쌍 비교 수치와 차이 대역·변경 프레임은 null" in html
    assert "원시 차이의 대역 에너지</h3>" not in html


@pytest.mark.parametrize("rate", RATES)
def test_nyquist_clipping_and_unavailable_bands_are_not_zero_filled(tmp_path, rate):
    result = _result(tmp_path, rate=rate, changed=False)
    bands = result["reference_measurements"]["bands"]
    for band in bands:
        if band["lower_hz"] >= rate / 2:
            assert band["status"] == "not_available"
            assert band["mean_square"] is None and band["power_fraction"] is None
            assert band["effective_upper_hz"] is None
        else:
            assert band["effective_upper_hz"] == min(rate / 2, band["upper_hz"])
    html = render_fullband_html(result)
    assert "측정 가능한 무음 대역의 에너지 0과 같지 않습니다" in html
    if rate <= 16000:
        assert "지원되지 않음 · Nyquist 밖" in html
    else:
        assert "지원되지 않음 · Nyquist 밖" not in html
    assert "상단 포함" in html


def test_native_high_band_is_visible_without_resampling(tmp_path):
    rate = 48000
    pcm = np.rint(np.sin(2 * np.pi * 18000 * np.arange(rate * 2) / rate) * 10000).astype(np.int16)
    reference = tmp_path / "reference.wav"
    processed = tmp_path / "processed.wav"
    reference.write_bytes(encode_wav(pcm.astype(float) / 32768, rate))
    processed.write_bytes(reference.read_bytes())
    result = run_fullband_measurement(reference, processed, tmp_path / "snapshot")
    band = result["reference_measurements"]["bands"][-1]
    assert band["lower_hz"] == 16000
    assert band["power_fraction"] > 0.999
    assert result["configuration"]["resampling"] is False
    assert "16000–24000 Hz" in render_fullband_html(result)


def test_silence_and_constant_signal_nulls_have_explicit_meaning(tmp_path):
    result = _result(tmp_path, changed=False, silence=True)
    for field in ("reference_measurements", "processed_measurements"):
        assert result[field]["rms_dbfs"] is None
        assert result[field]["peak_dbfs"] is None
        assert result[field]["crest_factor"] is None
        assert result[field]["mean_square"] == 0
    comparison = result["comparison"]
    assert comparison["signal_to_residual_db"] is None
    assert comparison["signal_to_residual_status"] == "zero_residual"
    assert comparison["correlation"] is None
    assert comparison["correlation_status"] == "constant_signal"
    html = render_fullband_html(result)
    assert "차이 에너지가 0이므로 유한 dB 비율을 제공하지 않음" in html
    assert "상수 신호의 중심 분산이 0이므로 상관을 제공하지 않음" in html
    assert "미제공" in html and ">Infinity<" not in html and ">nan<" not in html


def test_zero_reference_with_nonzero_residual_is_not_infinite_snr(tmp_path):
    result = _result(tmp_path, changed=True, silence=True)
    assert result["comparison"]["mean_square_error"] > 0
    assert result["comparison"]["signal_to_residual_status"] == "zero_reference"
    assert result["comparison"]["signal_to_residual_db"] is None
    html = render_fullband_html(result)
    assert "원본 에너지가 0이므로 유한 dB 비율을 제공하지 않음" in html
    assert "환경 SNR 아님" in html


def test_rail_proxy_is_not_claimed_as_confirmed_clipping(tmp_path):
    rate = 8000
    pcm = np.zeros(rate * 2, dtype=np.int16)
    pcm[100:104] = 32767
    pcm[104:107] = -32768
    pcm[109] = 32767
    reference, processed = tmp_path / "reference.wav", tmp_path / "processed.wav"
    reference.write_bytes(encode_wav(pcm.astype(float) / 32768, rate))
    processed.write_bytes(reference.read_bytes())
    result = run_fullband_measurement(reference, processed, tmp_path / "snapshot")
    assert result["reference_measurements"]["rail_sample_count"] == 8
    assert result["reference_measurements"]["longest_same_rail_run_samples"] == 4
    html = render_fullband_html(result)
    assert "클리핑 가능성의 대리 지표이지 클리핑 발생·원인 확정이 아닙니다" in html


def test_report_reopens_only_json_and_new_output_not_artifacts(tmp_path, capsys, monkeypatch):
    result = _result(tmp_path)
    source = tmp_path / "stored.json"
    source.write_text(json.dumps(result), encoding="utf-8")
    destination = tmp_path / "report.html"
    original_open = Path.open
    opened = []

    def only_stored_and_destination(path, *args, **kwargs):
        opened.append(path)
        if path not in {source, destination}:
            raise AssertionError("Report reopened an audio, artifact, or trace.")
        return original_open(path, *args, **kwargs)

    monkeypatch.setattr(Path, "open", only_stored_and_destination)
    assert fullband_cli.main(_report_args(source, destination)) == 0
    emitted = json.loads(capsys.readouterr().out)
    assert emitted["status"] == "generated_fullband_html"
    assert emitted["quality_verdict"] == "not_assessed"
    assert set(opened) == {source, destination}
    # Rendering an already loaded object needs no filesystem operation at all.
    monkeypatch.setattr(Path, "open", lambda *args, **kwargs: pytest.fail("Unexpected file reopen"))
    html = render_fullband_html(result)
    assert "default-src 'none'" in html
    assert "<script" not in html and "<audio" not in html
    assert "src=" not in html and "href=" not in html and "fetch(" not in html
    assert str(tmp_path) not in html
    assert "input/reference.wav" not in html and "input/processed.wav" not in html


@pytest.mark.parametrize("mutation", [
    "unknown", "flag", "summary", "nan", "infinity", "false_zero", "frame", "band", "artifact",
])
def test_forged_or_nonfinite_result_creates_no_report(tmp_path, mutation):
    result = _result(tmp_path)
    result = deepcopy(result)
    if mutation == "unknown":
        result["private_data"] = {"path": "C:/caller-secret/<script>"}
    elif mutation == "flag":
        result["complete_audio_approval"] = True
    elif mutation == "summary":
        result["summary"]["quality_verdict"] = "pass"
    elif mutation == "nan":
        result["reference_measurements"]["rms_dbfs"] = float("nan")
    elif mutation == "infinity":
        result["comparison"]["correlation"] = float("inf")
    elif mutation == "false_zero":
        result["reference_measurements"]["bands"][-1]["mean_square"] = 0
    elif mutation == "frame":
        result["processed_measurements"]["frames"][0]["end_sample"] += 1
    elif mutation == "band":
        result["reference_measurements"]["bands"][0]["hidden"] = "caller-secret"
    else:
        result["artifacts"]["reference"] = "C:/caller-secret/<script>.wav"
    destination = tmp_path / "report.html"
    with pytest.raises(ResultContractError):
        write_fullband_html(result, destination)
    assert not destination.exists()


def test_saved_report_rejects_invalid_json_without_exposing_content(tmp_path, capsys):
    source = tmp_path / "caller-secret.json"
    source.write_text('{"schema_version":1,"schema_version":1,"private":"caller-secret"}', encoding="utf-8")
    destination = tmp_path / "output.html"
    assert fullband_cli.main(_report_args(source, destination)) == 3
    output = capsys.readouterr()
    emitted = json.loads(output.out)
    assert emitted["status"] == "error" and emitted["exit_code"] == 3
    assert emitted["quality_verdict"] == "not_assessed"
    assert "caller-secret" not in output.out and str(tmp_path) not in output.out
    assert "Traceback" not in output.out + output.err
    assert not destination.exists()


def test_missing_input_is_safe_error_three_and_does_not_create_output(tmp_path, capsys):
    source = tmp_path / "caller-secret.wav"
    destination = tmp_path / "snapshot"
    assert fullband_cli.main(_measure_args(source, source, destination)) == 3
    output = capsys.readouterr()
    emitted = json.loads(output.out)
    assert emitted["status"] == "error" and emitted["exit_code"] == 3
    assert emitted["complete_audio_approval"] is False
    assert "caller-secret" not in output.out and str(tmp_path) not in output.out
    assert not destination.exists()


def test_existing_snapshot_and_report_are_never_replaced(tmp_path, capsys):
    reference, processed = _pair(tmp_path)
    destination = tmp_path / "occupied"
    destination.mkdir()
    sentinel = destination / "sentinel.txt"
    sentinel.write_text("keep", encoding="utf-8")
    assert fullband_cli.main(_measure_args(reference, processed, destination)) == 3
    capsys.readouterr()
    assert sentinel.read_text(encoding="utf-8") == "keep"
    result = run_fullband_measurement(reference, processed, tmp_path / "new_snapshot")
    report = tmp_path / "report.html"
    write_fullband_html(result, report)
    before = report.read_bytes()
    with pytest.raises(FullbandRunError) as caught:
        write_fullband_html(result, report)
    assert caught.value.code == "output_exists"
    assert report.read_bytes() == before


def test_unsafe_report_parent_fails_closed(tmp_path, monkeypatch):
    result = _result(tmp_path)
    destination = tmp_path / "report.html"

    def unsafe(path):
        raise PipelineRunError("unsafe_output_parent")

    monkeypatch.setattr(fullband_reporting, "_normal_parents", unsafe)
    with pytest.raises(FullbandRunError) as caught:
        write_fullband_html(result, destination)
    assert caught.value.code == "unsafe_output_parent"
    assert not destination.exists()


def test_observable_windows_reparse_parent_is_rejected(tmp_path, monkeypatch):
    result = _result(tmp_path)
    destination = tmp_path / "report.html"
    original_lstat = Path.lstat

    def parent_reparse(path, *args, **kwargs):
        if path == tmp_path:
            return SimpleNamespace(st_mode=stat.S_IFDIR, st_file_attributes=0x400)
        return original_lstat(path, *args, **kwargs)

    monkeypatch.setattr(Path, "lstat", parent_reparse)
    with pytest.raises(FullbandRunError) as caught:
        write_fullband_html(result, destination)
    assert caught.value.code == "unsafe_output_parent"
    assert not destination.exists()


def test_non_directory_report_parent_and_output_alias_fail_closed(tmp_path, capsys):
    result = _result(tmp_path)
    source = tmp_path / "stored.json"
    source.write_text(json.dumps(result), encoding="utf-8")
    before = source.read_bytes()
    assert fullband_cli.main(_report_args(source, source)) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "output_exists"
    assert source.read_bytes() == before
    occupied = tmp_path / "not_directory"
    occupied.write_text("keep", encoding="utf-8")
    assert fullband_cli.main(_report_args(source, occupied / "report.html")) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "invalid_output_path"
    assert occupied.read_text(encoding="utf-8") == "keep"


def test_invalid_runner_response_and_unsafe_error_code_are_not_emitted(tmp_path, capsys, monkeypatch):
    reference, processed = _pair(tmp_path)
    destination = tmp_path / "snapshot"
    monkeypatch.setattr(fullband_cli, "run_fullband_measurement", lambda *args: {"private": "caller-secret"})
    assert fullband_cli.main(_measure_args(reference, processed, destination)) == 3
    output = capsys.readouterr().out
    assert json.loads(output)["status"] == "error" and "caller-secret" not in output

    def unsafe(*args):
        raise FullbandRunError("C:/caller-secret/path.wav")

    monkeypatch.setattr(fullband_cli, "run_fullband_measurement", unsafe)
    assert fullband_cli.main(_measure_args(reference, processed, destination)) == 3
    output = capsys.readouterr().out
    assert json.loads(output)["reason_code"] == "fullband_measurement_error"
    assert "caller-secret" not in output


@pytest.mark.parametrize("argv", [[], ["check"], ["pass"], ["measure"], ["report"]])
def test_no_pass_command_or_implicit_measurements(argv):
    with pytest.raises(SystemExit) as caught:
        fullband_cli.main(argv)
    assert caught.value.code == 2
