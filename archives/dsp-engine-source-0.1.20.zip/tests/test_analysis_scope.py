"""Request-local preparation reuse, isolation and unchanged public arrays."""

from concurrent.futures import ThreadPoolExecutor
from contextvars import copy_context
import importlib
import inspect

import numpy as np
import pytest

from audio_regression import analysis_scope as scopes
from audio_regression import profiles
from audio_regression.audio import WavAudio, AudioInputError, decode_wav, encode_wav
from audio_regression.engine import EngineConfig


def _audio(rate=16000, seed=847):
    samples = np.random.default_rng(seed).normal(0, .025, rate * 2)
    return decode_wav(encode_wav(samples, rate))


@pytest.fixture
def resampling_calls(monkeypatch):
    original = profiles.resample_poly
    calls = []

    def observed(*args, **kwargs):
        calls.append(scopes._owner())
        return original(*args, **kwargs)

    monkeypatch.setattr(profiles, "resample_poly", observed)
    return calls


@pytest.mark.parametrize("rate", [16000, 44100, 48000])
@pytest.mark.parametrize("profile", ["basic", "telephone"])
def test_reuses_work_but_returns_fresh_writable_arrays(rate, profile, resampling_calls):
    source = _audio(rate)
    expected = profiles.prepare_analysis(source, profile)
    resampling_calls.clear()

    @scopes.analysis_scope
    def inner(reference, processed):
        return profiles.prepare_analysis(reference, profile)

    @scopes.analysis_scope
    def outer(reference, processed):
        first = profiles.prepare_analysis(reference, profile)
        first[:] = .77
        second = inner(reference, processed)
        cached = scopes.cached_preparation(reference, profile)
        assert not cached.flags.writeable
        with pytest.raises(ValueError):
            cached.setflags(write=True)
        assert not np.shares_memory(second, cached)
        third = profiles.prepare_analysis(reference, profile)
        assert second.flags.writeable and third.flags.writeable
        assert not np.shares_memory(second, third)
        return second, third

    second, third = outer(source, source)
    assert len(resampling_calls) == 1
    np.testing.assert_array_equal(second, expected)
    np.testing.assert_array_equal(third, expected)
    assert scopes._active_scope.get() is None
    outer(source, source)
    assert len(resampling_calls) == 2


def test_direct_preparation_has_no_persistent_cache(resampling_calls):
    source = _audio()
    first, second = profiles.prepare_analysis(source), profiles.prepare_analysis(source)
    assert len(resampling_calls) == 2
    assert not np.shares_memory(first, second)
    assert first.flags.writeable and second.flags.writeable
    assert scopes.cached_preparation(source, "basic") is None


def test_basic_native_rate_does_not_retain_an_extra_array():
    source = _audio(8000)

    @scopes.analysis_scope
    def execute(reference, processed):
        first = profiles.prepare_analysis(reference)
        second = profiles.prepare_analysis(reference)
        assert not scopes._active_scope.get().prepared
        assert not np.shares_memory(first, second)
        np.testing.assert_array_equal(first, reference.samples)

    execute(source, source)


def test_profile_keys_and_same_digest_inputs_cannot_alias(resampling_calls):
    original = _audio()
    # Direct construction can supply an arbitrary well-formed container digest.
    other = WavAudio(_audio(seed=948).samples, 16000, original.sha256)
    expected_other = profiles.prepare_analysis(other)
    resampling_calls.clear()

    @scopes.analysis_scope
    def execute(reference, processed):
        basic = profiles.prepare_analysis(reference)
        telephone = profiles.prepare_analysis(reference, "telephone")
        actual_other = profiles.prepare_analysis(processed)
        assert len(scopes._active_scope.get().prepared) == 3
        assert not np.array_equal(basic, telephone)
        np.testing.assert_array_equal(actual_other, expected_other)

    execute(original, other)
    assert len(resampling_calls) == 3


def test_nested_different_pair_has_independent_scope_and_restores_parent(resampling_calls):
    source, other = _audio(), _audio(seed=949)

    @scopes.analysis_scope
    def inner(reference, processed):
        profiles.prepare_analysis(reference)
        return scopes._active_scope.get()

    @scopes.analysis_scope
    def outer(reference, processed):
        profiles.prepare_analysis(reference)
        parent = scopes._active_scope.get()
        child = inner(reference, other)
        assert parent is scopes._active_scope.get() and child is not parent
        assert child.prepared == {} and child.reference is None and child.processed is None
        profiles.prepare_analysis(reference)

    outer(source, source)
    assert len(resampling_calls) == 2


def test_exception_clears_cache_and_input_references_even_in_copied_context(resampling_calls):
    source = _audio()
    captured = []

    @scopes.analysis_scope
    def execute(reference, processed):
        profiles.prepare_analysis(reference)
        captured.append(copy_context())
        raise RuntimeError("fixture failure")

    with pytest.raises(RuntimeError, match="fixture failure"):
        execute(source, source)
    scope = captured[0].run(scopes._active_scope.get)
    assert scope.prepared == {} and scope.cached_bytes == 0
    assert scope.reference is None and scope.processed is None
    assert scopes._active_scope.get() is None
    profiles.prepare_analysis(source)
    assert len(resampling_calls) == 2


def test_copied_context_does_not_share_cache_between_threads(resampling_calls):
    source = _audio()

    @scopes.analysis_scope
    def child(reference, processed):
        return profiles.prepare_analysis(reference)

    @scopes.analysis_scope
    def parent(reference, processed):
        expected = profiles.prepare_analysis(reference)
        inherited = copy_context()
        with ThreadPoolExecutor(max_workers=1) as worker:
            actual = worker.submit(inherited.run, child, reference, processed).result()
        np.testing.assert_array_equal(actual, expected)
        profiles.prepare_analysis(reference)

    parent(source, source)
    assert len(resampling_calls) == 2
    assert len({owner[0] for owner in resampling_calls}) == 2


def test_task_identity_isolates_inherited_scope_without_starting_network_loop(monkeypatch, resampling_calls):
    source = _audio()
    task_slot = [None]
    # Exercise the actual ownership branch without opening the Windows event
    # loop's local self-pipe, which restricted environments may prohibit.
    monkeypatch.setattr(scopes.asyncio, "current_task", lambda: task_slot[0])

    @scopes.analysis_scope
    def child(reference, processed):
        first = profiles.prepare_analysis(reference)
        np.testing.assert_array_equal(first, profiles.prepare_analysis(reference))

    @scopes.analysis_scope
    def parent(reference, processed):
        profiles.prepare_analysis(reference)
        first_task, second_task = object(), object()
        try:
            task_slot[0] = first_task
            copy_context().run(child, source, source)
            task_slot[0] = second_task
            copy_context().run(child, source, source)
        finally:
            task_slot[0] = None
        profiles.prepare_analysis(reference)

    parent(source, source)
    assert len(resampling_calls) == 3
    assert len({owner[1] for owner in resampling_calls}) == 3


def test_retention_limit_is_nonsemantic(monkeypatch, resampling_calls):
    source = _audio()
    expected = profiles.prepare_analysis(source)
    resampling_calls.clear()
    monkeypatch.setattr(scopes, "_MAX_CACHED_BYTES", 1)

    @scopes.analysis_scope
    def execute(reference, processed):
        first = profiles.prepare_analysis(reference)
        second = profiles.prepare_analysis(reference)
        assert scopes._active_scope.get().prepared == {}
        np.testing.assert_array_equal(first, expected)
        np.testing.assert_array_equal(second, expected)

    execute(source, source)
    assert len(resampling_calls) == 2


def test_unrelated_input_is_not_retained_and_invalid_input_still_rejected(resampling_calls):
    source, other = _audio(), _audio(seed=950)

    @scopes.analysis_scope
    def execute(reference, processed):
        profiles.prepare_analysis(other)
        profiles.prepare_analysis(other)
        assert not scopes._active_scope.get().prepared
        with pytest.raises(AudioInputError):
            profiles.prepare_analysis(np.zeros(16000))
        with pytest.raises(profiles.AnalysisProfileError):
            profiles.prepare_analysis(reference, "invalid")

    execute(source, source)
    assert len(resampling_calls) == 2


@pytest.mark.parametrize("module, entry", [
    ("engine", "analyze_buffers"),
    *[(name, "analyze_buffers_with_trace") for name in (
        "robust_engine", "context_engine", "instrument_engine", "canonical_engine",
        "repeat_engine", "compound_engine", "compound_event_engine", "global_context_engine",
    )],
])
def test_all_raw_engine_entries_keep_inspected_signatures(module, entry):
    function = getattr(importlib.import_module(f"audio_regression.{module}"), entry)
    assert inspect.signature(function) == inspect.signature(function.__wrapped__)
    assert function.__name__ == function.__wrapped__.__name__


def test_real_candidate_entry_reuses_preparation_from_inherited_stage(monkeypatch, resampling_calls):
    from audio_regression import instrument_engine

    reference, processed = _audio(), _audio(8000)

    def inherited_stage(left, right, settings):
        profiles.prepare_analysis(left)
        profiles.prepare_analysis(right)
        return {"status": "withheld", "reason_code": "insufficient_unambiguous_anchors",
                "analysis": {}, "diagnostics": {}, "limitations": []}, {}

    monkeypatch.setattr(instrument_engine.context_engine, "analyze_buffers_with_trace", inherited_stage)
    monkeypatch.setattr(instrument_engine, "_landmarks", lambda *args: ([], 0))
    result, _ = instrument_engine.analyze_buffers_with_trace(
        reference, processed, EngineConfig(allow_resampling=True),
    )
    assert result["reason_code"] == "raw_landmark_insufficient_unique_anchors"
    assert len(resampling_calls) == 1  # The fallback prepares the same source again.
    assert scopes._active_scope.get() is None
