import copy
import hashlib
from html.parser import HTMLParser
from pathlib import Path

import pytest

from audio_regression.regression_suite_contract import (
    SuiteError, build_suite_summary, canonical_manifest_sha256, incomplete_case_delta,
    validate_suite_result,
)
from audio_regression.regression_suite_diff import compare_case_results
from audio_regression.regression_suite_reporting import render_suite_html, write_suite_html
from test_reporting import sample_result


def _analysis(kind):
    value = sample_result(kind)
    if kind == "withheld":
        value.update(status="withheld", content_preservation_status="withheld",
                     reason_code="insufficient_unambiguous_anchors", events=None)
        value.pop("alignment_segments")
    return value


def _sample_suite(pairs=(("clean", "delete"),)):
    declarations = []
    cases = []
    configuration = {"engine": "v1", "allow_gain": False, "allow_resampling": False,
                     "max_delay_ms": 1000.0, "resampling_model": None}
    for index, (baseline_kind, candidate_kind) in enumerate(pairs):
        baseline, candidate = _analysis(baseline_kind), _analysis(candidate_kind)
        baseline["processed"]["sha256"] = hashlib.sha256(f"{index}:baseline:{baseline_kind}".encode()).hexdigest()
        candidate["processed"]["sha256"] = hashlib.sha256(f"{index}:candidate:{candidate_kind}".encode()).hexdigest()
        name = f"case_{index + 1}"
        declaration = {
            "case_id": name,
            "source": {"path": f"{name}/source.wav", "sha256": "a" * 64},
            "baseline": {"path": f"{name}/baseline.wav", "sha256": baseline["processed"]["sha256"]},
            "candidate": {"path": f"{name}/candidate.wav", "sha256": candidate["processed"]["sha256"]},
            "configuration": copy.deepcopy(configuration),
        }
        declarations.append(declaration)
        cases.append({
            "case_id": name, "status": "completed", "reason_code": None,
            "baseline_analysis": baseline, "candidate_analysis": candidate,
            "delta": compare_case_results(baseline, candidate, configuration, "a" * 64),
        })
    manifest = {"schema_version": 1, "suite_id": "report_test", "baseline_version": "before",
                "candidate_version": "after", "cases": declarations}
    value = {
        "schema_version": 1, "engine": "audio_regression_suite_v1", "producer_version": "0.1.20",
        "manifest": manifest, "manifest_sha256": canonical_manifest_sha256(manifest),
        "execution_complete": True, "cases": cases,
        "input_integrity": {"status": "verified", "issues": []}, "summary": {},
        "complete_audio_approval": False, "commercial_performance_validated": False,
    }
    value["summary"] = build_suite_summary(value)
    return validate_suite_result(value)


class _Tags(HTMLParser):
    def __init__(self, text):
        super().__init__()
        self.elements = []
        self.feed(text)

    def handle_starttag(self, tag, attrs):
        self.elements.append((tag, dict(attrs)))


def test_static_report_has_hash_csp_no_network_assets_or_scripts():
    value = _sample_suite()
    text = render_suite_html(value)
    assert 'lang="ko"' in text and 'charset="utf-8"' in text
    tags = _Tags(text).elements
    assert not any(tag in {"script", "iframe", "img", "audio", "video", "link", "object", "embed"} for tag, _ in tags)
    assert not any(any(name.startswith("on") or name in {"style", "src", "srcset"} for name in attrs) for _, attrs in tags)
    assert all(attrs["href"].startswith("#case-") for _, attrs in tags if "href" in attrs)
    csp = next(attrs["content"] for tag, attrs in tags if tag == "meta" and attrs.get("http-equiv") == "Content-Security-Policy")
    style = text.partition("<style>")[2].partition("</style>")[0]
    import base64
    digest = base64.b64encode(hashlib.sha256(style.encode("utf-8")).digest()).decode("ascii")
    assert "default-src 'none'" in csp and f"style-src 'sha256-{digest}'" in csp
    assert "unsafe-inline" not in csp
    assert render_suite_html(value) == text


def test_current_gate_and_regression_state_are_distinct_for_persistent_candidates():
    value = _sample_suite((("delete", "delete"),))
    assert value["summary"]["exit_code"] == 1
    text = render_suite_html(value)
    assert "현재 새 출력 검사" in text and "기준 대비 변화" in text
    assert "현재 결함 후보 검토 필요" in text
    assert "신규 후보 미관측 · 품질 승인 아님" in text
    assert "기존 후보가 유지되면 신규 후보가 없어도 정상 통과로 바꾸지 않습니다" in text
    assert "기준 1 ↔ 새 출력 1" in text


def test_not_observed_now_never_claims_improvement():
    value = _sample_suite((("delete", "clean"),))
    text = render_suite_html(value)
    assert "이번 미관측 · not_observed_now" in text
    assert "이번 미관측은 실제 결함 수정·음질 개선의 확정이 아닙니다" in text
    assert "기준 출력도 오류를 포함할 수 있습니다" in text


def test_withheld_case_is_inconclusive_not_empty_new_events_success():
    value = _sample_suite((("clean", "withheld"),))
    assert value["summary"]["exit_code"] == 2
    text = render_suite_html(value)
    assert "버전 간 변화 비교 불가" in text
    assert "비교 불가 · 새 후보 없음으로 처리하지 않음" in text
    assert "공통 좌표 미확정" in text
    assert "판단 보류는 성공이 아니며" in text


def test_review_list_prioritizes_inconclusive_then_new_then_persistent():
    value = _sample_suite((("clean", "clean"), ("delete", "delete"),
                           ("clean", "delete"), ("clean", "withheld")))
    text = render_suite_html(value)
    assert text.index('href="#case-3"') < text.index('href="#case-2"') < text.index('href="#case-1"') < text.index('href="#case-0"')
    assert 'id="case-3"' in text and 'id="case-0"' in text


def test_error_case_with_partial_candidate_analysis_cannot_show_clear_gate():
    value = _sample_suite((("clean", "clean"),))
    case = value["cases"][0]
    case.update(status="error", reason_code="suite_case_analysis_error", delta=incomplete_case_delta())
    value["summary"] = build_suite_summary(value)
    validate_suite_result(value)
    text = render_suite_html(value)
    assert "실행 오류" in text and "현재 판단 보류·검사 오류" in text
    assert "suite_case_analysis_error" in text
    assert "모든 사례 순회 완료 · 분석 성공과 다름" in text


def test_untrusted_text_escaped_and_private_paths_redacted():
    value = _sample_suite()
    payload = '<script>alert("한국어 & 안전")</script>'
    value["manifest"]["baseline_version"] = payload
    value["manifest_sha256"] = canonical_manifest_sha256(value["manifest"])
    value["cases"][0]["candidate_analysis"]["limitations"].append(payload + " C:/private/data.wav")
    text = render_suite_html(value)
    assert "&lt;script&gt;" in text and "한국어 &amp; 안전" in text
    assert payload not in text and "C:/private/data.wav" not in text
    assert "[로컬 경로 생략]" in text
    assert not any(tag == "script" for tag, _ in _Tags(text).elements)


def test_report_does_not_reopen_paths_or_audio(monkeypatch):
    value = _sample_suite()

    def forbidden(*_args, **_kwargs):
        raise AssertionError("Stored report must never reopen a path.")

    monkeypatch.setattr(Path, "open", forbidden)
    assert "시험 묶음 회귀 검사" in render_suite_html(value)


@pytest.mark.parametrize("mutation", [
    lambda value: value["summary"].update(exit_code=0),
    lambda value: value.update(complete_audio_approval=True),
    lambda value: value["cases"][0]["delta"].update(new_candidates=[]),
    lambda value: value.update(engine="unknown"),
])
def test_invalid_saved_suite_rejected_before_output(tmp_path, mutation):
    value = _sample_suite()
    mutation(value)
    output = tmp_path / "report.html"
    with pytest.raises(SuiteError):
        write_suite_html(value, output)
    assert not output.exists()


def test_exclusive_report_write_preserves_existing_file(tmp_path):
    output = tmp_path / "report.html"
    output.write_text("keep", encoding="utf-8")
    with pytest.raises(FileExistsError):
        write_suite_html(_sample_suite(), output)
    assert output.read_text(encoding="utf-8") == "keep"


def test_report_file_is_utf8_and_no_input_mutation(tmp_path):
    value = _sample_suite()
    before = copy.deepcopy(value)
    output = tmp_path / "report.html"
    write_suite_html(value, output)
    assert output.read_text(encoding="utf-8") == render_suite_html(value)
    assert value == before
