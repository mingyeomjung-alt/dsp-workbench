"""Black-box development regressions from owned, deterministic DSP fixtures.

These samples are synthesized here, not copied from the one-use natural-audio
evaluation. Passing this file is not independent natural-audio accuracy.
"""

from __future__ import annotations

import json

import numpy as np
import pytest
from scipy.signal import resample_poly

import audio_regression.instrument_engine as candidate
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.engine import EngineConfig


RATE = 16000
DURATION_SECONDS = 6.0
EDIT_START_MS = 2300.0
EDIT_DURATION_MS = 400.0
DELAY_MS = 240.0


def _audio(values: np.ndarray, rate: int = RATE):
    return decode_wav(encode_wav(values, rate))


def _instrument() -> np.ndarray:
    """Slowly changing pitch and timbre, without a random-noise identifier."""
    t = np.arange(round(RATE * DURATION_SECONDS)) / RATE
    frequency = 409.0 + 12.0 * t + 1.4 * np.sin(2 * np.pi * .73 * t)
    phase = 2 * np.pi * np.cumsum(frequency) / RATE
    envelope = .6 + .15 * np.sin(2 * np.pi * .31 * t) + .12 * np.sin(2 * np.pi * .17 * t + .7)
    wave = envelope * (np.sin(phase) + .31 * np.sin(2 * phase + .2) + .16 * np.sin(3 * phase + .7))
    return wave * (.28 / np.max(np.abs(wave)))


def _percussion() -> np.ndarray:
    """Unique hit pitches/decays and unequal gaps; no identical periodic beat."""
    values = np.zeros(round(RATE * DURATION_SECONDS))
    starts = [.08, .57, 1.19, 1.88, 2.42, 3.04, 3.71, 4.26, 4.98, 5.52]
    for index, start in enumerate(starts):
        first = round(start * RATE)
        length = min(round(.42 * RATE), len(values) - first)
        t = np.arange(length) / RATE
        fundamental = 367 + 29 * index
        phase = 2 * np.pi * (fundamental * t + (35 + 7 * index) * t * t)
        attack = 1 - np.exp(-t / .002)
        decay = np.exp(-t / (.059 + .005 * index))
        hit = attack * decay * (np.sin(phase) + .43 * np.sin(2.71 * phase + .31))
        values[first:first + length] += hit * (.22 + .012 * index)
    return values * (.28 / np.max(np.abs(values)))


def _periodic_hits() -> np.ndarray:
    """Exactly repeated half-second blocks, intentionally lacking a unique map."""
    t = np.arange(RATE // 2) / RATE
    hit = (1 - np.exp(-t / .002)) * np.exp(-t / .06) * (
        np.sin(2 * np.pi * 421 * t) + .4 * np.sin(2 * np.pi * 997 * t)
    )
    return np.tile(hit, round(DURATION_SECONDS * 2)) * .2


def _pure_tone() -> np.ndarray:
    t = np.arange(round(RATE * DURATION_SECONDS)) / RATE
    return .2 * np.sin(2 * np.pi * 400 * t)


SOURCES = {"instrument": _instrument, "percussion": _percussion}


def _normal(source: np.ndarray, change: str):
    if change == "identity":
        return _audio(source), EngineConfig()
    if change == "gain":
        return _audio(source * .5), EngineConfig(allow_gain=True)
    if change == "delay":
        return _audio(np.concatenate((np.zeros(round(DELAY_MS * RATE / 1000)), source))), EngineConfig()
    if change == "resampling":
        return _audio(resample_poly(source, 1, 2), RATE // 2), EngineConfig(allow_resampling=True)
    raise ValueError(change)


def _edited(source: np.ndarray, kind: str) -> np.ndarray:
    first = round(EDIT_START_MS * RATE / 1000)
    last = round((EDIT_START_MS + EDIT_DURATION_MS) * RATE / 1000)
    if kind == "delete":
        return np.concatenate((source[:first], source[last:]))
    if kind == "repeat":
        return np.concatenate((source[:last], source[first:last], source[last:]))
    raise ValueError(kind)


def _checked_analysis(reference, processed, config: EngineConfig | None = None):
    original_samples = reference.samples.copy()
    processed_samples = processed.samples.copy()
    result, trace = candidate.analyze_buffers_with_trace(reference, processed, config)
    assert result["engine"] == "local_content_alignment_v4"
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    np.testing.assert_array_equal(reference.samples, original_samples)
    np.testing.assert_array_equal(processed.samples, processed_samples)
    json.dumps(result, allow_nan=False)
    json.dumps(trace, allow_nan=False)
    return result, trace


@pytest.mark.parametrize("source_name", tuple(SOURCES))
@pytest.mark.parametrize("change", ("identity", "gain", "delay", "resampling"))
def test_identifiable_owned_instruments_preserve_declared_normal_flow(source_name, change):
    reference = _audio(SOURCES[source_name]())
    processed, config = _normal(reference.samples, change)
    result, trace = _checked_analysis(reference, processed, config)
    assert result["status"] == "analyzed", (result, trace)
    assert result["reason_code"] is None
    assert result["events"] == []
    assert result["analysis"]["method"] == "raw_landmark_piecewise_alignment_with_global_uniqueness"


@pytest.mark.parametrize("source_name", tuple(SOURCES))
@pytest.mark.parametrize("kind", ("delete", "repeat"))
def test_identifiable_owned_instruments_report_one_supported_edit_on_correct_axes(source_name, kind):
    reference = _audio(SOURCES[source_name]())
    processed = _audio(_edited(reference.samples, kind))
    result, trace = _checked_analysis(reference, processed)
    assert result["status"] == "analyzed", (result, trace)
    assert len(result["events"]) == 1
    event = result["events"][0]
    assert event["type"] == kind
    if kind == "delete":
        interval = event["reference_interval_ms"]
        assert abs(event["processed_boundary_ms"] - EDIT_START_MS) <= 100
    else:
        interval = event["reference_source_interval_ms"]
        added = event["processed_added_interval_ms"]
        assert abs(added[0] - (EDIT_START_MS + EDIT_DURATION_MS)) <= 100
        assert abs(added[1] - (EDIT_START_MS + 2 * EDIT_DURATION_MS)) <= 100
        assert added[1] - added[0] == pytest.approx(EDIT_DURATION_MS, abs=10)
        assert event["copy_interval_convention"] == "canonical_later_adjacent_copy_not_edit_provenance"
    assert abs(interval[0] - EDIT_START_MS) <= 100
    assert abs(interval[1] - (EDIT_START_MS + EDIT_DURATION_MS)) <= 100
    assert interval[1] - interval[0] == pytest.approx(EDIT_DURATION_MS, abs=10)


@pytest.mark.parametrize("source_name", tuple(SOURCES))
@pytest.mark.parametrize("change", ("dropout", "replacement"))
def test_equal_duration_dropouts_and_replacements_are_not_repaired_into_clear(source_name, change):
    reference = _audio(SOURCES[source_name]())
    values = reference.samples.copy()
    first = round(EDIT_START_MS * RATE / 1000)
    last = round((EDIT_START_MS + EDIT_DURATION_MS) * RATE / 1000)
    values[first:last] = 0 if change == "dropout" else values[first:last][::-1]
    processed = _audio(values)
    result, trace = _checked_analysis(reference, processed)
    assert len(processed.samples) == len(reference.samples)
    assert processed.sample_rate_hz == reference.sample_rate_hz
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None
    assert result["reason_code"] is not None


@pytest.mark.parametrize("source_name", ("silence", "pure_tone", "identical_periodic_hits"))
def test_unidentifiable_or_periodic_content_stays_withheld(source_name):
    sources = {"silence": lambda: np.zeros(round(RATE * DURATION_SECONDS)),
               "pure_tone": _pure_tone, "identical_periodic_hits": _periodic_hits}
    reference = _audio(sources[source_name]())
    result, trace = _checked_analysis(reference, reference)
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None
    assert result["reason_code"] is not None
