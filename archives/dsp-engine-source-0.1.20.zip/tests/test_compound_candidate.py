"""Owned-only regressions for the exact compound-normal forward proof.

The analytic input is created in memory from the formula below. No recorded,
sealed-evaluation, or external-processor trial file is read. Unit injections
are explicitly labelled and never serve as natural-audio performance evidence.
"""

from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import json

import numpy as np
import pytest
from scipy.signal import resample_poly

from audio_regression import compound_gain, repeat_engine
import audio_regression.compound_engine as candidate
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.engine import EngineConfig, EngineConfigError


Q = 1 / 32768
ENGINE = "local_content_alignment_v7"
METHOD = "interval_gain_quantized_compound_normal_proof"
SETTINGS = EngineConfig(allow_gain=True, allow_resampling=True)


def _audio(values, rate):
    return decode_wav(encode_wav(values, rate))


def _owned_signal(*, quiet_tail=True, rate=16000):
    """New specified partials and chirp, not a reused natural signal segment."""
    time = np.arange(6 * rate, dtype=float) / rate
    phase = 2 * np.pi * (277 * time + 11 * time * time + .37 * np.sin(2.1 * time))
    loud = .17 * (np.sin(phase) + .19 * np.sin(1.71 * phase + .4)
                  + .11 * np.sin(2.27 * phase - .3))
    quiet = .55 * Q * np.sin(2 * np.pi * (2900 * time + 7 * time * time))
    return np.where(time < 4.1, loud, quiet) if quiet_tail else loud


@lru_cache(maxsize=None)
def _owned_pair(gain=.5011872336272722, lead_ms=240):
    reference = _audio(_owned_signal(), 16000)
    gained = _audio(reference.samples * gain, 16000)
    output = _audio(resample_poly(gained.samples, 1, 2), 8000)
    processed = _audio(np.concatenate((np.zeros(round(lead_ms * 8)), output.samples)), 8000)
    return reference, processed


@lru_cache(maxsize=None)
def _owned_baseline():
    reference, processed = _owned_pair()
    return repeat_engine.analyze_buffers_with_trace(reference, processed, SETTINGS)


def _checked(reference, processed, settings=SETTINGS):
    originals = reference.samples.copy(), processed.samples.copy()
    result, trace = candidate.analyze_buffers_with_trace(reference, processed, settings)
    assert result["engine"] == ENGINE
    assert result["analysis"]["method"] == METHOD
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    np.testing.assert_array_equal(reference.samples, originals[0])
    np.testing.assert_array_equal(processed.samples, originals[1])
    json.dumps(result, allow_nan=False)
    json.dumps(trace, allow_nan=False)
    return result, trace


def _preserved(result, baseline):
    for key in ("status", "reason_code", "events", "diagnostics", "alignment_segments",
                "configuration", "content_preservation_status"):
        if key in baseline:
            assert result[key] == baseline[key]
        else:
            assert key not in result


def _force_eligible_baseline(monkeypatch, reason="raw_landmark_unexplained_local_residual"):
    """Unit-only injection of an existing decision; never replace raw samples."""
    baseline, old_trace = _owned_baseline()
    baseline = deepcopy(baseline)
    baseline.update(status="withheld", content_preservation_status="withheld",
                    reason_code=reason, events=None)
    baseline.pop("alignment_segments", None)
    monkeypatch.setattr(candidate.repeat_engine, "analyze_buffers_with_trace",
                        lambda *args: (deepcopy(baseline), deepcopy(old_trace)))


def test_owned_gain_pcm_resample_delay_reproduces_v6_local_withholding_without_injection():
    reference, processed = _owned_pair()
    baseline, _ = _owned_baseline()
    assert baseline["status"] == "withheld", baseline
    assert baseline["reason_code"] in {
        "raw_landmark_unexplained_local_residual", "raw_landmark_unexplained_local_change"
    }, baseline
    assert np.count_nonzero(processed.samples[37000:]) > 0
    assert len(processed.samples) == len(reference.samples) // 2 + 1920


@pytest.mark.parametrize("gain", (.5011872336272722, .43, .71, 1.17))
@pytest.mark.parametrize("lead_ms", (0, 240))
def test_owned_exact_compound_path_is_analyzed_with_no_hidden_gain_input(gain, lead_ms):
    reference, processed = _owned_pair(gain, lead_ms)
    baseline, _ = repeat_engine.analyze_buffers_with_trace(reference, processed, SETTINGS)
    result, trace = _checked(reference, processed)
    assert result["status"] == "analyzed", (result, trace)
    assert result["reason_code"] is None
    assert result["events"] == []
    assert set(result["configuration"]) == {"profile", "allow_gain", "allow_resampling", "max_delay_ms"}
    if baseline["status"] == "analyzed":
        _preserved(result, baseline)
        assert trace["proof_path"] == "preserved_v6_result"
        assert trace["compound_proved"] is False
    else:
        assert trace["compound_attempted"] is True
        assert trace["compound_proved"] is True
        assert trace["proof_path"] == "compound_normal_exact_forward"
        assert trace["gain_search_trace"]["search_complete"] is True
        assert result["alignment_segments"][0]["processed_offset_ms"] == lead_ms


@pytest.mark.parametrize("mutation", (
    "one_quiet_lsb", "erase_quiet_tail", "reverse_quiet_tail", "short_dropout", "noise",
))
def test_all_sample_proof_cannot_clear_equal_length_mutations(mutation):
    reference, processed = _owned_pair()
    values = processed.samples.copy()
    if mutation == "one_quiet_lsb":
        values[41000] += Q
    elif mutation == "erase_quiet_tail":
        assert np.count_nonzero(values[37000:]) > 0
        values[37000:] = 0
    elif mutation == "reverse_quiet_tail":
        values[37000:] = values[37000:][::-1]
    elif mutation == "short_dropout":
        values[21000:21160] = 0
    else:
        values += .003 * np.random.default_rng(712031).uniform(-1, 1, len(values))
    assert not np.array_equal(values, processed.samples)
    result, trace = _checked(reference, _audio(values, 8000))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None
    assert trace["compound_proved"] is False


@pytest.mark.parametrize("kind", ("delete", "repeat"))
def test_new_normal_proof_never_clears_a_length_changing_edit(kind):
    reference, processed = _owned_pair()
    values = processed.samples
    first, last = 21000, 24200
    if kind == "delete":
        changed = np.concatenate((values[:first], values[last:]))
    else:
        changed = np.concatenate((values[:last], values[first:last], values[last:]))
    modified = _audio(changed, 8000)
    baseline, _ = repeat_engine.analyze_buffers_with_trace(reference, modified, SETTINGS)
    result, trace = _checked(reference, modified)
    _preserved(result, baseline)
    assert trace["compound_proved"] is False
    assert not (result["status"] == "analyzed" and result["events"] == [])


@pytest.mark.parametrize("mode", ("gain_after_src", "different_fir", "unfiltered_decimation"))
def test_different_transform_is_not_claimed_as_the_new_exact_path(mode):
    reference, _ = _owned_pair()
    gain = .5011872336272722
    if mode == "gain_after_src":
        down = _audio(resample_poly(reference.samples, 1, 2), 8000)
        values = _audio(down.samples * gain, 8000).samples
    elif mode == "different_fir":
        gained = _audio(reference.samples * gain, 16000)
        values = _audio(resample_poly(gained.samples, 1, 2, window=("kaiser", 8.0)), 8000).samples
    else:
        gained = _audio(reference.samples * gain, 16000)
        values = gained.samples[::2]
    processed = _audio(np.concatenate((np.zeros(1920), values)), 8000)
    supported = _owned_pair()[1]
    assert not np.array_equal(supported.samples, processed.samples)
    baseline, _ = repeat_engine.analyze_buffers_with_trace(reference, processed, SETTINGS)
    result, trace = _checked(reference, processed)
    _preserved(result, baseline)
    assert trace["compound_proved"] is False


def test_periodic_compound_waveform_cannot_earn_unique_context():
    time = np.arange(6 * 16000) / 16000
    reference = _audio(.18 * np.sin(2 * np.pi * 400 * time), 16000)
    gained = _audio(reference.samples * .43, 16000)
    processed = _audio(np.concatenate((np.zeros(1920), resample_poly(gained.samples, 1, 2))), 8000)
    result, trace = _checked(reference, processed)
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None
    assert trace["compound_proved"] is False


@pytest.mark.parametrize("settings", (
    EngineConfig(allow_gain=True), EngineConfig(allow_resampling=True), EngineConfig(),
))
def test_missing_existing_declaration_never_authorizes_new_proof(settings):
    reference, processed = _owned_pair()
    baseline, _ = repeat_engine.analyze_buffers_with_trace(reference, processed, settings)
    result, trace = _checked(reference, processed, settings)
    _preserved(result, baseline)
    assert trace["compound_attempted"] is False
    assert trace["compound_proved"] is False


def test_nonbasic_profile_is_not_silently_reinterpreted():
    reference, processed = _owned_pair()
    with pytest.raises(EngineConfigError):
        candidate.analyze_buffers_with_trace(reference, processed, EngineConfig(
            profile="telephone", allow_gain=True, allow_resampling=True))


@pytest.mark.parametrize("gain", (.5011872336272722, .43, .71, 1.17))
def test_solver_witness_reproduces_complete_pcm_output_not_merely_a_gain_estimate(gain):
    source = _audio(_owned_signal(quiet_tail=False), 16000).samples
    gained = _audio(source * gain, 16000)
    target = _audio(resample_poly(gained.samples, 1, 2), 8000).samples
    before = source.copy(), target.copy()
    witness, trace = compound_gain.solve_gain(source, target)
    assert witness is not None, trace
    assert np.isfinite(witness["gain"]) and witness["gain"] > 0
    assert trace["search_complete"] is True
    assert trace["reason_code"] == "compound_gain_exact_witness"
    assert 0 < trace["nodes_visited"] <= trace["max_nodes"]
    np.testing.assert_array_equal(witness["rendered"], target)
    np.testing.assert_array_equal(source, before[0])
    np.testing.assert_array_equal(target, before[1])
    # A witness gain need not equal the generating gain inside a PCM plateau.
    json.dumps(trace, allow_nan=False)


def test_solver_budget_exhaustion_never_yields_an_early_approval(monkeypatch):
    reference, processed = _owned_pair()
    monkeypatch.setattr(compound_gain, "MAX_NODES", 0)
    witness, trace = compound_gain.solve_gain(reference.samples, processed.samples[1920:])
    assert witness is None
    assert trace["nodes_visited"] == 0
    assert trace["search_complete"] is False
    assert trace["reason_code"] == "compound_gain_search_budget_exceeded"


@pytest.mark.parametrize("kind", ("empty", "length", "nan", "inf", "not_pcm", "complex", "boolean"))
def test_solver_invalid_inputs_fail_closed_with_finite_json_trace(kind):
    source = np.full(4000, 100 * Q)
    target = np.full(2000, 50 * Q)
    if kind == "empty":
        source = np.array([])
    elif kind == "length":
        target = target[:-1]
    elif kind == "nan":
        source[20] = np.nan
    elif kind == "inf":
        target[20] = np.inf
    elif kind == "not_pcm":
        source[20] += .2 * Q
    elif kind == "complex":
        source = source.astype(complex)
    else:
        source = np.ones(4000, dtype=bool)
    witness, trace = compound_gain.solve_gain(source, target)
    assert witness is None
    assert trace["reason_code"] == "compound_gain_invalid_pcm_input"
    assert trace["search_complete"] is True
    assert trace["nodes_visited"] == 0
    json.dumps(trace, allow_nan=False)


@pytest.mark.parametrize("endpoint", (-1., 32767 * Q))
def test_solver_target_endpoint_is_not_an_ordinary_half_lsb_bin(endpoint):
    source = np.full(4000, .25)
    target = np.full(2000, 50 * Q)
    target[20] = endpoint
    witness, trace = compound_gain.solve_gain(source, target)
    assert witness is None
    assert trace["reason_code"] == "compound_gain_target_endpoint_not_supported"
    assert trace["search_complete"] is True


@pytest.mark.parametrize("gain", (0., -1., float("nan"), float("inf"), 100.))
def test_solver_render_never_clips_or_normalizes_an_invalid_gain(gain):
    source = _audio(_owned_signal(quiet_tail=False), 16000).samples
    assert compound_gain._render(source, gain) is None


def test_solver_very_quiet_input_cannot_propose_a_gain_from_zero_information():
    source = np.zeros(4000)
    target = np.zeros(2000)
    witness, trace = compound_gain.solve_gain(source, target)
    assert witness is None
    assert trace["reason_code"] == "compound_gain_uninformative_reference"
    assert trace["nodes_visited"] == 0


def test_solver_dc_witness_does_not_override_engine_context_requirement():
    # This is a valid scalar transform, but constant content has no unique time
    # identity. The solver is not an analyzer and cannot approve the pair.
    reference = _audio(np.full(6 * 16000, .25), 16000)
    target = _audio(resample_poly(reference.samples * .5, 1, 2), 8000)
    witness, trace = compound_gain.solve_gain(reference.samples, target.samples)
    assert witness is not None, trace
    result, engine_trace = _checked(reference, target)
    assert result["status"] == "withheld", (result, engine_trace)
    assert engine_trace["compound_proved"] is False


@pytest.mark.parametrize("reason", (
    "resampling_not_declared", "non_silent_file_edge_change",
    "initial_delay_outside_declared_search", "raw_landmark_insufficient_unique_anchors",
    "raw_landmark_ambiguous_event_boundary", "insertion_not_supported_as_repetition",
))
def test_unit_policy_and_ambiguity_withholds_are_never_fallback_eligible(monkeypatch, reason):
    _force_eligible_baseline(monkeypatch, reason)
    monkeypatch.setattr(candidate.raw, "_landmarks",
                        lambda *args: pytest.fail("Ineligible reason must not start new context proof."))
    reference, processed = _owned_pair()
    result, trace = _checked(reference, processed)
    assert result["status"] == "withheld"
    assert result["reason_code"] == reason
    assert trace["compound_attempted"] is False
    assert trace["compound_proved"] is False


@pytest.mark.parametrize("offsets", ((1920, 1920), (0, 0, 0), (1920, 1920, 1928),
                                      (1920, 1920, 1920, 3520, 3520, 3520)))
def test_unit_incomplete_or_inconsistent_context_cannot_reach_gain_solver(monkeypatch, offsets):
    _force_eligible_baseline(monkeypatch)
    points = [{"reference_start": 640 * (index + 1), "width": 1920,
               "offset": offset, "correlation": 1., "rival_margin": .4}
              for index, offset in enumerate(offsets)]
    monkeypatch.setattr(candidate.raw, "_landmarks", lambda *args: (points, len(points)))
    monkeypatch.setattr(candidate, "solve_gain",
                        lambda *args: pytest.fail("Unique complete normal context is mandatory."))
    reference, processed = _owned_pair()
    result, trace = _checked(reference, processed)
    assert result["status"] == "withheld"
    assert trace["compound_proved"] is False
    assert trace["compound_failure"] == "unique_normal_context_not_supported"


@pytest.mark.parametrize("failure", ("wrong_sample", "wrong_length"))
def test_unit_solver_witness_is_independently_checked_against_every_output_sample(monkeypatch, failure):
    # Unit contract injection only: a malformed witness cannot become a pass.
    reference, processed = _owned_pair()
    wrong = processed.samples[1920:].copy()
    if failure == "wrong_sample":
        wrong[41000] += Q
    else:
        wrong = wrong[:-1]
    monkeypatch.setattr(candidate, "solve_gain", lambda *args: (
        {"gain": .5011872336272722, "rendered": wrong}, {"search_complete": True}))
    result, trace = _checked(reference, processed)
    assert result["status"] == "withheld"
    assert trace["compound_proved"] is False
    assert trace["compound_failure"] == "whole_output_exact_proof_failed"


def test_unit_gain_budget_exhaustion_does_not_clear_the_engine(monkeypatch):
    reference, processed = _owned_pair()
    monkeypatch.setattr(compound_gain, "MAX_NODES", 0)
    result, trace = _checked(reference, processed)
    assert result["status"] == "withheld"
    assert trace["compound_proved"] is False
    assert trace["gain_search_trace"]["nodes_visited"] == 0
    assert trace["gain_search_trace"]["search_complete"] is False


def test_solver_near_full_scale_source_can_be_legitimately_attenuated():
    source = _audio(_owned_signal(quiet_tail=False), 16000).samples.copy()
    source[10000], source[20000] = -1., 32767 * Q
    target = _audio(resample_poly(_audio(source * .25, 16000).samples, 1, 2), 8000).samples
    witness, trace = compound_gain.solve_gain(source, target)
    assert witness is not None, trace
    np.testing.assert_array_equal(witness["rendered"], target)


def test_solver_large_dc_does_not_change_fixed_forward_numeric_proof():
    samples = .75 + .025 * np.random.default_rng(782104).uniform(-1, 1, 4000)
    # Small direct-array solver unit: not an audio-quality performance corpus.
    source = np.rint(samples * 32768) / 32768
    gained = np.rint(source * .43 * 32768) / 32768
    target = np.rint(resample_poly(gained, 1, 2) * 32768) / 32768
    witness, trace = compound_gain.solve_gain(source, target)
    assert witness is not None, trace
    np.testing.assert_array_equal(witness["rendered"], target)
    json.dumps(trace, allow_nan=False)
