"""Invented v12 result certificates, not audio or accuracy measurements."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path

import pytest

from audio_regression.resampler_result_contract import (
    ENGINE, METHOD, MODEL, validate_resampler_analysis_result,
)
from audio_regression.result_contract import ResultContractError, validate_analysis_result


_SCHEMAS = Path(__file__).resolve().parents[1] / "src" / "audio_regression" / "schemas"


def _metadata(rate, count, digest):
    return {"sample_rate_hz": rate, "sample_count": count, "duration_ms": count * 1000 / rate,
            "channels": 1, "encoding": "pcm16", "rms": .1, "peak": .5, "sha256": digest * 64}


def _normal():
    return {
        "schema_version": 1, "engine": ENGINE, "status": "analyzed",
        "content_preservation_status": "no_supported_defect_candidates", "reason_code": None,
        "events": [], "complete_audio_approval": False, "commercial_performance_validated": False,
        "reference": _metadata(48000, 288000, "a"),
        "processed": _metadata(16000, 96000, "b"),
        "resampling_reference": _metadata(16000, 96000, "c"),
        "proof_kind": "exact_resampling_only",
        "configuration": {"profile": "basic", "allow_gain": False, "allow_resampling": True,
                          "max_delay_ms": 1000, "resampling_model": MODEL},
        "analysis": {"sample_rate_hz": 16000, "hop_ms": .0625, "method": METHOD,
                     "minimum_event_duration_ms": 50, "maximum_cumulative_edit_shift_ms": 2000,
                     "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {"normalized_path_cost": 0, "gain_estimate": 1, "applied_gain": 1,
                        "matched_normalized_rmse": 0, "matched_analysis_samples": 96000,
                        "anchor_run_count": 0, "minimum_local_correlation": None},
        "alignment_segments": [],
        "limitations": ["Named periodic resampling and post-edit explanation, not whole-audio approval."],
    }


def _short(kind="delete", length=100):
    value = _normal()
    delta = length if kind == "repeat" else -length
    value.update(proof_kind="native_short_event", content_preservation_status="defect_candidates")
    value["processed"] = _metadata(16000, round((6000 + delta) * 16), "b")
    evidence = {"boundary_correlation": 1, "offset_before_ms": 0, "offset_after_ms": delta}
    if kind == "delete":
        event = {"type": kind, "reference_interval_ms": [2000, 2000 + length],
                 "processed_boundary_ms": 2000, "evidence": evidence}
        left_end, right_start = 2000, 2000 + length
    else:
        evidence.update(copy_correlation=1, adjacent_copy_correlation=1)
        event = {"type": kind, "reference_source_interval_ms": [2000, 2000 + length],
                 "processed_added_interval_ms": [2000 + length, 2000 + 2 * length],
                 "copy_interval_convention": "canonical_later_adjacent_copy_not_edit_provenance",
                 "evidence": evidence}
        left_end = right_start = 2000 + length
    value["events"] = [event]
    value["diagnostics"].update(anchor_run_count=2,
        minimum_local_correlation=1,
        matched_analysis_samples=min(96000, value["processed"]["sample_count"]))
    value["alignment_segments"] = [
        {"reference_interval_ms": [0, left_end], "processed_offset_ms": 0,
         "anchor_correlations": [1, 1, 1]},
        {"reference_interval_ms": [right_start, 6000], "processed_offset_ms": delta,
         "anchor_correlations": [1, 1, 1]},
    ]
    return value


def _endpoint(location="head", length=100):
    value = _normal()
    value.update(proof_kind="native_endpoint_loss", content_preservation_status="defect_candidates")
    count = round((6000 - length) * 16)
    value["processed"] = _metadata(16000, count, "b")
    head = location == "head"
    offset = -length if head else 0
    value["events"] = [{"type": "delete", "location": location,
        "reference_interval_ms": [0, length] if head else [6000 - length, 6000],
        "processed_boundary_ms": 0 if head else 6000 - length,
        "evidence": {"retained_offset_ms": offset, "retained_context_correlation": 1,
                     "removed_sample_count": round(length * 16), "retained_native_samples": count,
                     "all_retained_native_samples_exact": True}}]
    value["diagnostics"].update(anchor_run_count=1, matched_analysis_samples=count,
                                minimum_local_correlation=1)
    value["alignment_segments"] = [{
        "reference_interval_ms": [length, 6000] if head else [0, 6000 - length],
        "processed_offset_ms": offset, "anchor_correlations": [1, 1, 1],
    }]
    return value


def _withheld(reason="resampler_no_exact_supported_postedit_proof"):
    value = _normal()
    value.update(status="withheld", content_preservation_status="withheld", events=None,
                 reason_code=reason, proof_kind="unproved", diagnostics={})
    value.pop("alignment_segments")
    if reason != "resampler_no_exact_supported_postedit_proof":
        value["resampling_reference"] = None
    if reason == "resampler_unsupported_input_path":
        value["reference"] = _metadata(16000, 96000, "a")
    return value


def _reject(value, code=None):
    with pytest.raises(ResultContractError) as caught:
        validate_analysis_result(value)
    if code is not None:
        assert caught.value.code == code


@pytest.mark.parametrize("factory", [_normal, _short, lambda: _short("repeat"),
                                     _endpoint, lambda: _endpoint("tail")])
def test_v12_keeps_raw_and_canonical_axes_distinct_without_mutation(factory):
    value = factory()
    before = deepcopy(value)
    assert validate_analysis_result(value) is value
    assert validate_resampler_analysis_result(value) is value
    assert value == before
    assert value["reference"]["sample_rate_hz"] == 48000
    assert value["resampling_reference"]["sample_rate_hz"] == 16000
    assert value["reference"]["sha256"] != value["resampling_reference"]["sha256"]


@pytest.mark.parametrize("reason", ["resampler_unsupported_input_path",
    "resampler_projection_out_of_range", "resampler_no_exact_supported_postedit_proof"])
def test_withheld_envelopes_cannot_claim_canonical_or_analyzed_evidence(reason):
    value = _withheld(reason)
    assert validate_analysis_result(value) is value
    value["events"] = []
    _reject(value, "inconsistent_result_status")


@pytest.mark.parametrize("path,replacement,code", [
    (("complete_audio_approval",), True, "invalid_approval_claim"),
    (("commercial_performance_validated",), True, "invalid_approval_claim"),
    (("proof_kind",), "guessed_resampling", "unsupported_resampling_proof_kind"),
    (("proof_kind",), "unproved", "inconsistent_result_status"),
    (("resampling_reference",), None, "missing_resampling_reference"),
    (("configuration", "resampling_model"), "scipy_any", "unsupported_resampler_configuration"),
    (("configuration", "resampling_model"), None, "unsupported_resampler_configuration"),
    (("configuration", "allow_resampling"), False, "unsupported_resampler_configuration"),
    (("configuration", "allow_resampling"), 1, "unsupported_resampler_configuration"),
    (("configuration", "allow_gain"), True, "unsupported_resampler_configuration"),
    (("configuration", "profile"), "telephone", "unsupported_profile"),
    (("analysis", "method"), "short_event_exact_pcm_forward_proof", "invalid_analysis_method"),
    (("analysis", "sample_rate_hz"), 8000, "invalid_analysis_method"),
    (("analysis", "hop_ms"), 10, "invalid_analysis_method"),
    (("analysis", "minimum_event_duration_ms"), 200, "invalid_analysis_method"),
    (("diagnostics", "matched_analysis_samples"), 288000, "inconsistent_matched_sample_count"),
    (("diagnostics", "anchor_run_count"), 1, "inconsistent_anchor_count"),
    (("diagnostics", "matched_normalized_rmse"), .001, "inconsistent_resampling_exact_metrics"),
    (("diagnostics", "minimum_local_correlation"), 1, "inconsistent_resampling_exact_metrics"),
    (("processed", "rms"), .09, "inconsistent_resampling_exact_metadata"),
    (("processed", "peak"), .49, "inconsistent_resampling_exact_metadata"),
])
def test_declared_model_axes_metrics_and_approval_claims_are_strict(path, replacement, code):
    value = _normal()
    node = value
    for key in path[:-1]:
        node = node[key]
    node[path[-1]] = replacement
    _reject(value, code)


def test_canonical_metadata_requires_actual_three_to_one_input_path_and_same_duration():
    for key, replacement in [("reference", _metadata(16000, 96000, "a")),
                             ("processed", _metadata(48000, 288000, "b")),
                             ("resampling_reference", _metadata(8000, 48000, "c")),
                             ("resampling_reference", _metadata(16000, 95999, "c")),
                             ("reference", _metadata(48000, 288001, "a"))]:
        value = _normal()
        value[key] = replacement
        _reject(value, "inconsistent_resampling_reference")


def test_native_kind_cannot_relabel_inherited_or_other_native_geometry():
    for value in [_short(), _endpoint()]:
        value["analysis"].update(sample_rate_hz=8000, hop_ms=10, minimum_event_duration_ms=200)
        _reject(value, "invalid_analysis_method")
    value = _short()
    value["proof_kind"] = "native_endpoint_loss"
    _reject(value)
    value = _endpoint()
    value["proof_kind"] = "native_short_event"
    _reject(value)
    for value in [_short(), _endpoint()]:
        value["proof_kind"] = "exact_resampling_only"
        _reject(value, "inconsistent_resampling_only_result")


def test_native_contracts_keep_all_sample_metrics_geometry_and_coverage_rules():
    mutations = [
        (_short(), ("events", 0, "reference_interval_ms"), [2000, 2100.01]),
        (_short(), ("diagnostics", "matched_analysis_samples"), 288000),
        (_short(), ("alignment_segments", 1, "reference_interval_ms"), [2100, 5900]),
        (_endpoint(), ("events", 0, "evidence", "removed_sample_count"), 4800),
        (_endpoint(), ("events", 0, "evidence", "all_retained_native_samples_exact"), False),
        (_endpoint(), ("diagnostics", "matched_normalized_rmse"), .001),
        (_endpoint(), ("alignment_segments", 0, "reference_interval_ms"), [100, 5900]),
    ]
    for value, path, replacement in mutations:
        node = value
        for key in path[:-1]:
            node = node[key]
        node[path[-1]] = replacement
        _reject(value)


def test_short_and_endpoint_duration_bounds_remain_separate():
    for length in (50, 100, 200):
        assert validate_analysis_result(_short(length=length))["proof_kind"] == "native_short_event"
    for length in (50, 100, 200, 1000, 2000):
        assert validate_analysis_result(_endpoint(length=length))["proof_kind"] == "native_endpoint_loss"
    for length in (49, 201, 1000):
        _reject(_short(length=length))
    for length in (49, 2001):
        _reject(_endpoint(length=length))


def test_withheld_projection_state_and_reason_must_agree():
    value = _withheld()
    value["resampling_reference"] = None
    _reject(value, "missing_resampling_reference")
    value = _withheld("resampler_projection_out_of_range")
    value["reference"] = _metadata(16000, 96000, "a")
    _reject(value, "inconsistent_resampling_reference")
    value = _withheld("resampler_unsupported_input_path")
    value["reference"] = _metadata(48000, 288000, "a")
    _reject(value, "inconsistent_resampling_reference")
    value = _withheld("resampler_projection_out_of_range")
    value["resampling_reference"] = _metadata(16000, 96000, "c")
    _reject(value, "inconsistent_resampling_reference")


def test_v12_review_reason_is_stage_scoped_and_old_v11_does_not_accept_v12_stage():
    reason = "resampler_no_exact_supported_postedit_proof"
    value = _withheld()
    value["review_diagnostics"] = {
        "schema_version": 1, "selected_engine": ENGINE, "result_status": "withheld",
        "primary_reason_code": reason, "trace_availability": "recorded", "diagnostic_only": True,
        "fault_provenance_confirmed": False, "stages": [{"engine": ENGINE, "outcome": "withheld",
            "reason_code": reason, "detail_reason_code": None}],
    }
    assert validate_analysis_result(value) is value
    value["review_diagnostics"]["stages"][0]["engine"] = "local_content_alignment_v11"
    _reject(value, "invalid_review_stage_reason")
    value["review_diagnostics"]["stages"][0]["engine"] = ENGINE
    value["review_diagnostics"]["stages"][0]["detail_reason_code"] = "short_event_nonunique_context"
    _reject(value, "invalid_review_stage_detail_reason")


def test_result_cannot_hide_trace_paths_new_fields_or_nonfinite_metrics():
    value = _normal()
    value["source_path"] = "private.wav"
    _reject(value, "unexpected_result_field")
    value = _normal()
    value["resampling_reference"]["rms"] = float("nan")
    _reject(value, "non_finite_metric")
    value = _normal()
    value["configuration"].pop("resampling_model")
    _reject(value, "missing_result_field")
    value = _withheld()
    value["alignment_segments"] = []
    _reject(value, "unexpected_result_field")


def test_tiny_v12_error_is_not_analyzed_or_projection_evidence():
    value = {"schema_version": 1, "engine": ENGINE, "status": "error", "reason_code": "invalid_input"}
    assert validate_analysis_result(value) is value
    value["proof_kind"] = "unproved"
    _reject(value, "unexpected_result_field")


@pytest.mark.parametrize("factory", [_normal, _short, _endpoint])
def test_analyzed_review_diagnostics_is_forbidden_by_python_and_v12_schema(factory):
    value = factory()
    value["review_diagnostics"] = {
        "schema_version": 1, "selected_engine": ENGINE, "result_status": "withheld",
        "primary_reason_code": "resampler_no_exact_supported_postedit_proof",
        "trace_availability": "unavailable", "diagnostic_only": True,
        "fault_provenance_confirmed": False, "stages": [],
    }
    _reject(value, "review_diagnostics_not_supported_for_status")
    schema = json.loads((_SCHEMAS / "analysis-result-v12.schema.json").read_text("utf-8"))
    assert schema["$defs"]["analyzed"]["not"] == {"required": ["review_diagnostics"]}


def test_v12_schema_is_self_contained_and_v11_bytes_are_frozen():
    schema = json.loads((_SCHEMAS / "analysis-result-v12.schema.json").read_text("utf-8"))
    assert schema["$id"].endswith(":v12")
    assert schema["$defs"]["analysis"]["properties"]["method"]["const"] == METHOD
    assert schema["$defs"]["configuration"]["properties"]["resampling_model"]["const"] == MODEL
    assert schema["$defs"]["reviewDiagnostics"]["properties"]["stages"]["maxItems"] == 12
    assert schema["$defs"]["common"]["additionalProperties"] is False
    def visit(node):
        if isinstance(node, dict):
            if "$ref" in node:
                assert node["$ref"].startswith("#/$defs/")
                assert node["$ref"].rsplit("/", 1)[1] in schema["$defs"]
            for child in node.values():
                visit(child)
        elif isinstance(node, list):
            for child in node:
                visit(child)
    visit(schema)
    assert hashlib.sha256((_SCHEMAS / "analysis-result-v11.schema.json").read_bytes()).hexdigest() == (
        "9f33910df93073701817674203a5711babff7c16ac397ea269157eb181cea5a5")
