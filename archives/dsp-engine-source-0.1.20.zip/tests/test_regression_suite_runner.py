"""Owned small fixtures exercise the suite runner, not population accuracy."""
from copy import deepcopy
import hashlib
import json

import numpy as np
import pytest
from scipy.signal import resample

from audio_regression import api
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.fixtures import generate_case
from audio_regression.regression_suite import load_suite_manifest, run_regression_suite
from audio_regression.regression_suite_contract import SuiteError, validate_suite_result


def _make(root, *, old="clean", new="clean", rate=8000):
    root.mkdir(exist_ok=True)
    source = generate_case(seed=613831, sample_rate_hz=rate, duration_seconds=4).reference_wav
    x = decode_wav(source).samples
    def raw(kind):
        if kind == "clean":
            return source
        if kind == "bad":
            return b"not a WAV"
        changed = np.concatenate((x[:rate], x[rate + rate // 10:]))
        if kind == "tamper":
            changed[-1] += 1 / 32768
        return encode_wav(changed, rate)
    files = {"source": source, "baseline": raw(old), "candidate": raw(new)}
    for role, content in files.items():
        (root / (role + ".wav")).write_bytes(content)
    case = {"case_id": "one", **{role: {"path": role + ".wav",
        "sha256": hashlib.sha256(content).hexdigest()} for role, content in files.items()},
        "configuration": {"engine": "v11", "allow_gain": False, "allow_resampling": False,
                          "max_delay_ms": 1000.0, "resampling_model": None}}
    manifest = {"schema_version": 1, "suite_id": "owned", "baseline_version": "approved-1",
                "candidate_version": "candidate-2", "cases": [case]}
    path = root / "manifest.json"
    path.write_text(json.dumps(manifest), encoding="utf-8")
    return path, manifest


@pytest.mark.parametrize("old,new,exit_code,new_count,persistent,missing", [
    ("clean", "clean", 0, 0, 0, 0),
    ("clean", "delete", 1, 1, 0, 0),
    ("delete", "delete", 1, 0, 1, 0),
    ("delete", "clean", 0, 0, 0, 1),
])
def test_actual_old_new_paths(tmp_path, old, new, exit_code, new_count, persistent, missing):
    path, manifest = _make(tmp_path, old=old, new=new)
    before = {p.name: p.read_bytes() for p in tmp_path.iterdir() if p.is_file()}
    result = run_regression_suite(path, tmp_path / "result")
    assert validate_suite_result(result) is result
    assert result["execution_complete"] is True
    assert result["input_integrity"] == {"status": "verified", "issues": []}
    assert result["summary"]["exit_code"] == exit_code
    assert result["summary"]["new_candidate_count"] == new_count
    assert result["summary"]["persistent_candidate_count"] == persistent
    assert result["summary"]["not_observed_now_count"] == missing
    assert json.loads((tmp_path / "result/suite_result.json").read_text(encoding="utf-8")) == result
    assert load_suite_manifest(path) == manifest
    assert all((tmp_path / name).read_bytes() == content for name, content in before.items())


def test_held_baseline_is_never_resolved_by_current_clear(tmp_path):
    path, _ = _make(tmp_path, old="tamper")
    result = run_regression_suite(path, tmp_path / "result")
    assert result["cases"][0]["baseline_analysis"]["status"] == "withheld"
    assert result["cases"][0]["delta"]["status"] == "inconclusive"
    assert result["summary"]["not_observed_now_count"] == 0
    assert result["summary"]["exit_code"] == 2


def test_invalid_wav_is_case_error_but_later_case_runs(tmp_path):
    path, manifest = _make(tmp_path, new="bad")
    later = deepcopy(manifest["cases"][0])
    later["case_id"] = "two"
    later["candidate"] = dict(later["source"])
    manifest["cases"].append(later)
    path.write_text(json.dumps(manifest), encoding="utf-8")
    result = run_regression_suite(path, tmp_path / "result")
    assert result["execution_complete"] is True
    assert [case["status"] for case in result["cases"]] == ["error", "completed"]
    assert result["summary"]["exit_code"] == 3


def test_expected_digest_mismatch_prevents_any_output(tmp_path):
    path, manifest = _make(tmp_path)
    manifest["cases"][0]["baseline"]["sha256"] = "0" * 64
    path.write_text(json.dumps(manifest), encoding="utf-8")
    with pytest.raises(SuiteError, match="suite_expected_hash_mismatch"):
        run_regression_suite(path, tmp_path / "result")
    assert not (tmp_path / "result").exists()


def test_duplicate_json_is_rejected_without_audio_access(tmp_path):
    path = tmp_path / "bad.json"
    path.write_text('{"schema_version":1,"schema_version":1}', encoding="utf-8")
    with pytest.raises(SuiteError, match="duplicate_json_key"):
        load_suite_manifest(path)


@pytest.mark.parametrize("role", ["source", "baseline", "candidate", "manifest"])
def test_original_change_after_analysis_blocks(tmp_path, monkeypatch, role):
    path, _ = _make(tmp_path)
    original = api.analyze_pair
    def changed(*args, **kwargs):
        result = original(*args, **kwargs)
        target = path if role == "manifest" else tmp_path / (role + ".wav")
        target.write_bytes(target.read_bytes() + b" ")
        return result
    monkeypatch.setattr(api, "analyze_pair", changed)
    result = run_regression_suite(path, tmp_path / "result")
    assert result["input_integrity"]["status"] == "failed"
    assert any(issue["role"] == role and issue["scope"] == "input"
               for issue in result["input_integrity"]["issues"])
    assert result["summary"]["exit_code"] == 3


def test_snapshot_change_is_detected_even_when_originals_are_unchanged(tmp_path, monkeypatch):
    path, _ = _make(tmp_path)
    original = api.analyze_pair
    def changed(source, processed, **kwargs):
        result = original(source, processed, **kwargs)
        processed.write_bytes(processed.read_bytes() + b" ")
        return result
    monkeypatch.setattr(api, "analyze_pair", changed)
    result = run_regression_suite(path, tmp_path / "result")
    assert any(issue["scope"] == "snapshot" for issue in result["input_integrity"]["issues"])
    assert result["summary"]["exit_code"] == 3


def test_interrupt_leaves_incomplete_run_not_a_pass(tmp_path, monkeypatch):
    path, manifest = _make(tmp_path)
    later = deepcopy(manifest["cases"][0])
    later["case_id"] = "two"
    manifest["cases"].append(later)
    path.write_text(json.dumps(manifest), encoding="utf-8")
    def interrupted(*args, **kwargs):
        raise KeyboardInterrupt
    monkeypatch.setattr(api, "analyze_pair", interrupted)
    result = run_regression_suite(path, tmp_path / "result")
    assert result["execution_complete"] is False
    assert result["cases"][1]["status"] == "not_run"
    assert result["summary"]["exit_code"] != 0


def test_unexpected_error_is_stable_and_does_not_echo_private_values(tmp_path, monkeypatch):
    path, _ = _make(tmp_path)
    def broken(*args, **kwargs):
        raise RuntimeError("private path and audio text")
    monkeypatch.setattr(api, "analyze_pair", broken)
    result = run_regression_suite(path, tmp_path / "result")
    assert result["cases"][0]["reason_code"] == "suite_analysis_execution_error"
    assert "private path" not in json.dumps(result)
    assert result["summary"]["exit_code"] == 3


def test_output_is_exclusive(tmp_path):
    path, _ = _make(tmp_path)
    folder = tmp_path / "result"
    folder.mkdir()
    (folder / "keep.txt").write_bytes(b"keep")
    with pytest.raises(SuiteError, match="suite_output_exists"):
        run_regression_suite(path, folder)
    assert (folder / "keep.txt").read_bytes() == b"keep"


def test_explicit_fft_canonical_axis_is_not_raw_sample_indices(tmp_path):
    path, manifest = _make(tmp_path, rate=48000)
    x = decode_wav((tmp_path / "source.wav").read_bytes()).samples
    y = np.rint(resample(x, len(x) // 3) * 32768) / 32768
    baseline = encode_wav(y, 16000)
    current = encode_wav(np.concatenate((y[:16000], y[17600:])), 16000)
    for role, raw in (("baseline", baseline), ("candidate", current)):
        (tmp_path / (role + ".wav")).write_bytes(raw)
        manifest["cases"][0][role]["sha256"] = hashlib.sha256(raw).hexdigest()
    manifest["cases"][0]["configuration"].update(engine="v12", allow_resampling=True,
        resampling_model="scipy_fft_periodic_48k_16k_pcm16_postedit_v1")
    path.write_text(json.dumps(manifest), encoding="utf-8")
    result = run_regression_suite(path, tmp_path / "result")
    case = result["cases"][0]
    assert case["delta"]["coordinate_axis"] == "canonical_reference_time_ms"
    assert case["candidate_analysis"]["reference"]["sample_rate_hz"] == 48000
    assert case["candidate_analysis"]["resampling_reference"]["sample_rate_hz"] == 16000
    assert result["summary"]["new_candidate_count"] == 1
    assert result["summary"]["exit_code"] == 1
