"""Recorded-coordinate fixtures only: no audio or independent accuracy claim."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path

import pytest

from audio_regression.check_policy import check_result
from audio_regression.event_lineage import (
    ENGINE, LineageError, build_event_lineage, derive_event_lineage_projection,
)
from audio_regression.saved_pipeline import _summary
from audio_regression.saved_pipeline_contract import validate_saved_pipeline_result
from test_pipeline_reporting import fixture as run_fixture
from test_saved_pipeline_contract import analysis, end_error, metadata, saved_fixture


def segment(start, stop, offset=0):
    return {"reference_interval_ms": [start, stop], "processed_offset_ms": offset,
            "anchor_correlations": [0.99, 0.99, 0.99]}


def _set_segments(result, segments):
    result["alignment_segments"] = segments
    result["diagnostics"]["anchor_run_count"] = len(segments)


def chain(*kinds):
    source = metadata()
    previous = source
    records = []
    for index, kind in enumerate(kinds, 1):
        delta = -400 if kind == "delete" else 400 if kind == "repeat" else 0
        output = metadata("bcdef012"[index - 1], previous["duration_ms"] + delta)
        pair = analysis(previous, output, "delete" if kind == "delete" else "clean")
        if kind == "repeat":
            pair["events"] = [{
                "type": "repeat", "reference_source_interval_ms": [2000, 2400],
                "processed_added_interval_ms": [2400, 2800],
                "copy_interval_convention": "canonical_later_adjacent_copy_not_edit_provenance",
                "evidence": {"boundary_correlation": .99, "copy_correlation": .99,
                             "adjacent_copy_correlation": .99,
                             "offset_before_ms": 0, "offset_after_ms": 400},
            }]
            pair["content_preservation_status"] = "defect_candidates"
            _set_segments(pair, [segment(0, 2400), segment(2400, previous["duration_ms"], 400)])
        elif kind == "delete":
            _set_segments(pair, [segment(0, 2000), segment(2400, previous["duration_ms"], -400)])
        else:
            _set_segments(pair, [segment(0, previous["duration_ms"])])
        records.append({
            "index": index, "label": f"기록 단계 {index}",
            "declaration": deepcopy(pair["configuration"]),
            "input": deepcopy(previous), "output": deepcopy(output),
            "input_snapshot": f"inputs/{index - 1:03d}.wav",
            "output_snapshot": f"inputs/{index:03d}.wav", "status": "analyzed",
            "analysis": pair, "check": check_result(pair), "reason_code": None,
            "analysis_artifact": f"stages/{index:03d}/analysis.json",
            "check_artifact": f"stages/{index:03d}/check.json", "runtime_ms": 1,
        })
        previous = output
    end = analysis(source, previous, "withheld")
    value = {
        "schema_version": 1, "engine": "audio_saved_pipeline_audit_v1", "status": "completed",
        "comparison_scope": "adjacent_stage_checks_and_end_to_end", "source": source,
        "stages": records,
        "end_to_end": {"status": "withheld", "analysis": end, "check": check_result(end),
                       "analysis_artifact": "end_to_end/analysis.json",
                       "check_artifact": "end_to_end/check.json"},
        "input_recheck": {"status": "unchanged", "file_indices": []}, "summary": None,
        "complete_audio_approval": False, "commercial_performance_validated": False,
        "network_used": False, "fault_provenance_confirmed": False, "caller_order_verified": False,
    }
    value["summary"] = _summary(value)
    validate_saved_pipeline_result(value)
    return value


def _refresh(value):
    for stage in value["stages"]:
        stage["check"] = check_result(stage["analysis"])
    value["summary"] = _summary(value)
    validate_saved_pipeline_result(value)
    return value


@pytest.mark.parametrize("factory", [run_fixture, saved_fixture])
def test_original_run_and_saved_audit_supported_without_mutation(factory):
    original = factory("delete")
    before = deepcopy(original)
    sidecar = build_event_lineage(original)
    assert sidecar["engine"] == ENGINE and sidecar["status"] == "generated"
    assert sidecar["projection"]["events"][0]["reference_query"] == {
        "kind": "interval", "interval_ms": [2000., 2400.]}
    assert sidecar["projection"]["events"][0]["processed_query"] == {
        "kind": "boundary", "time_ms": 2000.}
    assert original == before
    assert sidecar["source_result"] == original and sidecar["source_result"] is not original
    assert sidecar["projection"]["original_summary"] == original["summary"]
    assert sidecar["projection"]["summary"]["fully_projected_count"] == 1
    assert sidecar["coordinate_projection_only"] is True
    for key in ("artifact_authenticity_verified", "fault_provenance_confirmed",
                "caller_order_verified", "complete_audio_approval",
                "commercial_performance_validated", "network_used"):
        assert sidecar[key] is False


def test_source_hash_is_canonical_json_not_container_order_or_path_authenticity():
    value = chain("clean", "delete", "clean")
    sidecar = build_event_lineage(value)
    raw = json.dumps(value, ensure_ascii=False, sort_keys=True,
                     separators=(",", ":"), allow_nan=False).encode("utf-8")
    assert sidecar["source_result_sha256"] == hashlib.sha256(raw).hexdigest()
    reordered = dict(reversed(list(value.items())))
    assert build_event_lineage(reordered)["source_result_sha256"] == sidecar["source_result_sha256"]
    value["stages"][0]["label"] = "변경된 표시 이름"
    assert build_event_lineage(value)["source_result_sha256"] != sidecar["source_result_sha256"]


def test_sidecar_mutation_does_not_mutate_input_or_other_detached_views():
    value = chain("delete")
    sidecar = build_event_lineage(value)
    sidecar["source_result"]["source"]["sha256"] = "f" * 64
    sidecar["projection"]["source"]["sha256"] = "e" * 64
    sidecar["projection"]["original_summary"]["exit_code"] = 0
    assert value["source"]["sha256"] == "a" * 64
    assert value["summary"]["exit_code"] == 2


@pytest.mark.parametrize("kind", ["delete", "repeat"])
def test_event_projects_backward_to_original_and_forward_to_final(kind):
    value = chain("clean", kind, "clean")
    projection = build_event_lineage(value)["projection"]
    event = projection["events"][0]
    assert event["stage_index"] == 2 and event["event_index"] == 0
    assert event["source_projection"]["fragments"] == [event["reference_query"]]
    assert event["final_projection"]["fragments"] == [event["processed_query"]]
    backward = event["source_projection"]["hops"][0]
    forward = event["final_projection"]["hops"][0]
    assert (backward["stage_index"], backward["direction"], backward["input_sha256"],
            backward["output_sha256"]) == (1, "backward", "b" * 64, "a" * 64)
    assert (forward["stage_index"], forward["direction"], forward["input_sha256"],
            forward["output_sha256"]) == (3, "forward", "c" * 64, "d" * 64)
    assert projection["summary"] == {"observed_event_count": 1, "source_projected_count": 1,
        "final_projected_count": 1, "fully_projected_count": 1, "unresolved_event_count": 0}
    assert projection["end_to_end_event_count_not_attributed"] is None


def test_sequential_deletes_keep_distinct_source_coordinates():
    projection = build_event_lineage(chain("delete", "delete", "clean"))["projection"]
    first, second = projection["events"]
    assert first["source_projection"]["fragments"][0]["interval_ms"] == [2000, 2400]
    assert second["source_projection"]["fragments"][0]["interval_ms"] == [2400, 2800]
    assert len(first["final_projection"]["hops"]) == 2
    assert projection["summary"]["observed_event_count"] == 2


def test_same_offset_touching_segments_merge_without_interpolation():
    value = chain("clean", "delete")
    _set_segments(value["stages"][0]["analysis"], [segment(0, 2200), segment(2200, 6000)])
    projection = build_event_lineage(_refresh(value))["projection"]
    assert projection["events"][0]["source_projection"]["status"] == "mapped"


@pytest.mark.parametrize("gap", [1e-7, 1e-10, 1e-12])
def test_any_positive_recorded_alignment_gap_is_unresolved(gap):
    value = chain("clean", "delete")
    _set_segments(value["stages"][0]["analysis"], [segment(0, 2200), segment(2200 + gap, 6000)])
    side = build_event_lineage(_refresh(value))["projection"]["events"][0]["source_projection"]
    assert side["status"] == "unresolved" and side["reason_code"] == "unmapped_alignment_gap"
    assert side["fragments"] == [] and side["hops"][-1]["output_query"] is None


def test_conflicting_offset_at_boundary_is_not_selected_arbitrarily():
    value = chain("delete", "clean")
    pair = value["stages"][1]["analysis"]
    _set_segments(pair, [segment(0, 2000), segment(2000, 5580, 20)])
    side = build_event_lineage(_refresh(value))["projection"]["events"][0]["final_projection"]
    assert side["reason_code"] == "ambiguous_alignment" and side["fragments"] == []


def test_interval_crossing_offset_change_is_not_flattened_into_one_interval():
    value = chain("clean", "delete")
    _set_segments(value["stages"][0]["analysis"], [segment(0, 2200), segment(2200, 5980, 20)])
    side = build_event_lineage(_refresh(value))["projection"]["events"][0]["source_projection"]
    # The inverse-domain gap precedes the offset conflict; neither is filled.
    assert side["reason_code"] == "unmapped_alignment_gap"


def test_rounding_an_intermediate_coordinate_cannot_hide_a_tiny_difference():
    value = chain("clean", "delete")
    _set_segments(value["stages"][0]["analysis"], [segment(0, 5999, 1e-14)])
    side = build_event_lineage(_refresh(value))["projection"]["events"][0]["source_projection"]
    assert side["reason_code"] == "ambiguous_alignment"
    assert side["fragments"] == []


def test_eight_stage_chain_records_every_successful_hop():
    value = chain("clean", "clean", "clean", "delete", "clean", "clean", "clean", "clean")
    event = build_event_lineage(value)["projection"]["events"][0]
    assert [hop["stage_index"] for hop in event["source_projection"]["hops"]] == [3, 2, 1]
    assert [hop["stage_index"] for hop in event["final_projection"]["hops"]] == [5, 6, 7, 8]


@pytest.mark.parametrize("direction", ["forward", "backward"])
def test_broad_segment_contradicting_edit_cannot_map_even_far_away(direction):
    value = chain("repeat", "delete") if direction == "forward" else chain("delete", "delete")
    edited = value["stages"][1 if direction == "forward" else 0]["analysis"]
    edited["events"][0].update(reference_interval_ms=[1000, 1400], processed_boundary_ms=1000)
    _set_segments(edited, [segment(0, 5600)])
    event_index = 0 if direction == "forward" else 1
    side_name = "final_projection" if direction == "forward" else "source_projection"
    side = build_event_lineage(_refresh(value))["projection"]["events"][event_index][side_name]
    assert side["reason_code"] == "ambiguous_alignment" and side["fragments"] == []


@pytest.mark.parametrize("earlier", [True, False])
def test_intervening_withheld_stage_has_failure_hop_and_no_terminal_claim(earlier):
    value = chain("clean", "delete", "clean")
    index = 0 if earlier else 2
    record = value["stages"][index]
    pair = analysis(record["input"], record["output"], "withheld")
    record.update(status="withheld", analysis=pair, reason_code=pair["reason_code"])
    event = build_event_lineage(_refresh(value))["projection"]["events"][0]
    side = event["source_projection" if earlier else "final_projection"]
    assert side["status"] == "unresolved" and side["reason_code"] == "stage_not_analyzed"
    assert side["fragments"] == [] and side["hops"][-1]["reason_code"] == "stage_not_analyzed"


def test_prior_successful_hops_are_preserved_when_later_coverage_is_missing():
    value = chain("delete", "clean", "clean")
    _set_segments(value["stages"][2]["analysis"], [segment(0, 1000)])
    side = build_event_lineage(_refresh(value))["projection"]["events"][0]["final_projection"]
    assert len(side["hops"]) == 2
    assert side["hops"][0]["output_query"] == {"kind": "boundary", "time_ms": 2000}
    assert side["hops"][1]["reason_code"] == "unmapped_alignment_gap"
    assert side["fragments"] == []


def test_repeat_source_makes_forward_correspondence_nonunique_before_alignment_lookup():
    value = chain("delete", "repeat")
    side = build_event_lineage(value)["projection"]["events"][0]["final_projection"]
    assert side["reason_code"] == "repeated_content_multiple_correspondences"


def test_repeat_added_copy_is_not_mapped_back_to_claimed_source_ancestry():
    value = chain("repeat", "delete")
    second = value["stages"][1]["analysis"]["events"][0]
    second.update(reference_interval_ms=[2400, 2800], processed_boundary_ms=2400)
    _set_segments(value["stages"][1]["analysis"], [segment(0, 2400), segment(2800, 6400, -400)])
    side = build_event_lineage(_refresh(value))["projection"]["events"][1]["source_projection"]
    assert side["reason_code"] == "repeated_content_multiple_correspondences"


def test_declared_lost_audio_is_not_mapped_by_an_overbroad_recorded_segment():
    value = chain("repeat", "delete")
    later = value["stages"][1]["analysis"]
    later["events"][0].update(reference_interval_ms=[2500, 2900], processed_boundary_ms=2500)
    _set_segments(later, [segment(0, 6000)])
    side = build_event_lineage(_refresh(value))["projection"]["events"][0]["final_projection"]
    assert side["reason_code"] == "unmapped_alignment_gap"


def test_deleted_output_boundary_has_two_source_endpoints_even_if_one_anchor_missing():
    value = chain("delete", "delete")
    second = value["stages"][1]["analysis"]["events"][0]
    second.update(reference_interval_ms=[1800, 2200], processed_boundary_ms=1800)
    _set_segments(value["stages"][1]["analysis"], [segment(0, 1800), segment(2200, 5600, -400)])
    side = build_event_lineage(_refresh(value))["projection"]["events"][1]["source_projection"]
    assert side["reason_code"] == "ambiguous_alignment"


@pytest.mark.parametrize("recheck", [None, "changed", "unavailable"])
def test_incomplete_or_failed_integrity_blocks_even_direct_projections(recheck):
    value = chain("delete")
    if recheck is None:
        end_error(value)
    else:
        reason = "input_files_changed" if recheck == "changed" else "input_files_recheck_failed"
        value["input_recheck"] = {"status": recheck, "file_indices": [0]}
        end_error(value, reason)
    projection = build_event_lineage(_refresh(value))["projection"]
    assert projection["input_integrity"] == "failure_recorded"
    for name in ("source_projection", "final_projection"):
        side = projection["events"][0][name]
        assert side == {"status": "unresolved", "reason_code": "input_integrity_or_completion_unavailable",
                        "fragments": [], "hops": []}


def test_no_events_does_not_mean_audio_approval_or_unseen_end_to_end_events():
    sidecar = build_event_lineage(chain("clean", "clean"))
    assert sidecar["projection"]["events"] == []
    assert sidecar["projection"]["summary"]["observed_event_count"] == 0
    assert sidecar["projection"]["end_to_end_event_count_not_attributed"] is None
    assert sidecar["complete_audio_approval"] is False


def test_end_to_end_events_are_counted_not_silently_attributed_or_duplicated():
    value = saved_fixture("delete")
    projection = build_event_lineage(value)["projection"]
    assert projection["end_to_end_event_count_not_attributed"] == 1
    assert projection["summary"]["observed_event_count"] == 1
    assert projection["event_scope"] == "adjacent_stage_events_only"


@pytest.mark.parametrize("mutation", ["engine", "hash", "summary", "extra", "nan"])
def test_invalid_source_is_rejected_without_echoing_private_values(mutation):
    value = chain("delete")
    if mutation == "engine":
        value["engine"] = "audio_saved_pipeline_audit_v12"
    elif mutation == "hash":
        value["stages"][0]["input"]["sha256"] = "f" * 64
    elif mutation == "summary":
        value["summary"]["exit_code"] = 0
    elif mutation == "extra":
        value["secret"] = "PRIVATE_SOURCE_CONTENT"
    else:
        value["stages"][0]["runtime_ms"] = float("nan")
    with pytest.raises(LineageError) as error:
        build_event_lineage(value)
    assert error.value.code == "invalid_lineage_source_result"
    assert "PRIVATE_SOURCE_CONTENT" not in str(error.value)


def test_source_size_and_event_budgets_reject_instead_of_dropping(monkeypatch):
    import audio_regression.event_lineage as module
    value = chain("delete")
    monkeypatch.setattr(module, "MAX_SOURCE_RESULT_BYTES", 30)
    with pytest.raises(LineageError) as error:
        build_event_lineage(value)
    assert error.value.code == "source_result_too_large"
    monkeypatch.setattr(module, "MAX_SOURCE_RESULT_BYTES", 4 * 1024 * 1024)
    monkeypatch.setattr(module, "MAX_LINEAGE_EVENTS", 0)
    with pytest.raises(LineageError) as error:
        build_event_lineage(value)
    assert error.value.code == "lineage_event_budget_exceeded"


def test_actual_cross_stage_event_budget_rejects_more_than_256_observations():
    value = chain("clean", "clean", "clean")
    all_metadata = [value["source"]]
    for stage in value["stages"]:
        all_metadata.extend([stage["input"], stage["output"],
                             stage["analysis"]["reference"], stage["analysis"]["processed"]])
    all_metadata.extend([value["end_to_end"]["analysis"]["reference"],
                         value["end_to_end"]["analysis"]["processed"]])
    for item in all_metadata:
        item.update(sample_count=480000, duration_ms=30000)
    for stage in value["stages"]:
        pair = stage["analysis"]
        pair["events"] = [{"type": "delete", "reference_interval_ms": [i * 200, (i + 1) * 200],
                           "processed_boundary_ms": i * 200,
                           "evidence": {"boundary_correlation": .99, "offset_before_ms": 0,
                                        "offset_after_ms": -200}} for i in range(100)]
        pair["content_preservation_status"] = "defect_candidates"
        pair["diagnostics"]["matched_analysis_samples"] = 100000
        _set_segments(pair, [segment(0, 5000)])
    _refresh(value)
    with pytest.raises(LineageError) as error:
        build_event_lineage(value)
    assert error.value.code == "lineage_event_budget_exceeded"


def test_projection_helper_and_builder_are_identical_and_never_open_files(monkeypatch):
    value = chain("delete", "clean")
    def forbid(*args, **kwargs):
        raise AssertionError("No saved artifact may be opened")
    monkeypatch.setattr(Path, "open", forbid)
    monkeypatch.setattr("builtins.open", forbid)
    assert derive_event_lineage_projection(value) == build_event_lineage(value)["projection"]
