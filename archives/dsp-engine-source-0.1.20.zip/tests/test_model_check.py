"""New owned signal integration; no historic natural data or threshold tuning."""
from copy import deepcopy
import json

import numpy as np
import pytest

from audio_regression import api
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.model_check import ModelCheckError, load_model_plan, run_model_check
from audio_regression.model_contract import validate_model_result
from audio_regression.transform_models import render_models


def _pair(tmp_path, kind="polarity_invert", rate=8000, change=None):
    rng = np.random.default_rng(2026101459271)
    pcm = rng.integers(-5000, 5001, rate * 4, dtype=np.int32)
    original = encode_wav(pcm / 32768, rate)
    reference = tmp_path / "reference.wav"
    processed = tmp_path / "processed.wav"
    reference.write_bytes(original)
    expected = render_models(decode_wav(original), [{"kind": kind}])
    output = decode_wav(expected).samples.copy()
    if change == "sample":
        output[rate] += 1 / 32768
    elif change == "delete":
        output = np.concatenate((output[:rate * 2], output[int(rate * 2.4):]))
    processed.write_bytes(encode_wav(output, rate))
    return reference, processed, [{"kind": kind}]


@pytest.mark.parametrize("kind", ["polarity_invert", "fir_binomial_3", "pcm_quantize_12"])
@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
def test_exact_declared_output_and_snapshots_are_bound(tmp_path, kind, rate):
    left, right, models = _pair(tmp_path, kind, rate)
    old = (left.read_bytes(), right.read_bytes(), deepcopy(models))
    folder = tmp_path / "new_run"
    result = run_model_check(left, right, models, folder)
    assert result["summary"]["exit_code"] == 0
    assert result["comparison"] == {"exact_pcm16_match": True, "unequal_sample_count": 0,
                                    "maximum_abs_error_pcm16": 0}
    assert result["analysis"]["reference"] == result["expected"]
    assert result["analysis"]["processed"] == result["processed"]
    assert result["source"]["sample_count"] == result["expected"]["sample_count"]
    assert result["fault_provenance_confirmed"] is False
    assert validate_model_result(result) is result
    assert json.loads((folder / "model_result.json").read_text(encoding="utf-8")) == result
    assert old == (left.read_bytes(), right.read_bytes(), models)


def test_empty_temporal_candidates_cannot_clear_a_one_sample_residual(tmp_path):
    left, right, models = _pair(tmp_path, change="sample")
    result = run_model_check(left, right, models, tmp_path / "run")
    assert result["comparison"] == {"exact_pcm16_match": False, "unequal_sample_count": 1,
                                    "maximum_abs_error_pcm16": 1}
    assert result["analysis"]["events"] == []
    assert result["temporal_check"]["exit_code"] == 0
    assert result["summary"]["exit_code"] == 2
    assert result["summary"]["reason_code"] == "declared_model_unexplained_difference"


def test_deleted_expected_audio_is_not_a_model_match(tmp_path):
    left, right, models = _pair(tmp_path, change="delete")
    result = run_model_check(left, right, models, tmp_path / "run")
    assert result["comparison"] == {"exact_pcm16_match": False, "unequal_sample_count": None,
                                    "maximum_abs_error_pcm16": None}
    assert result["summary"]["exit_code"] in (1, 2)


def test_pcm_content_not_riff_byte_identity_defines_match(tmp_path):
    import struct
    left, right, models = _pair(tmp_path)
    wav = right.read_bytes()
    junk = b"JUNK" + struct.pack("<I", 4) + b"abcd"
    right.write_bytes(wav[:4] + struct.pack("<I", len(wav) - 8 + len(junk)) + wav[8:] + junk)
    result = run_model_check(left, right, models, tmp_path / "run")
    assert result["expected"]["sha256"] != result["processed"]["sha256"]
    assert result["comparison"]["exact_pcm16_match"] is True
    assert result["summary"]["exit_code"] == 0


def test_silence_child_withholding_is_not_cleared_by_exact_equality(tmp_path):
    left = tmp_path / "left.wav"
    right = tmp_path / "right.wav"
    left.write_bytes(encode_wav(np.zeros(24000), 8000))
    right.write_bytes(left.read_bytes())
    result = run_model_check(left, right, [{"kind": "fir_binomial_3"}], tmp_path / "run", engine="v9")
    assert result["comparison"]["exact_pcm16_match"] is True
    assert result["summary"]["exit_code"] == 2
    assert result["analysis"]["review_diagnostics"]["primary_reason_code"] == result["analysis"]["reason_code"]


@pytest.mark.parametrize("engine", ["v1", "v2", "v3", "v4", "v5", "v6", "v7", "v8", "v9"])
def test_selected_detector_unchanged_and_trace_preserved(tmp_path, engine):
    left, right, models = _pair(tmp_path)
    folder = tmp_path / "run"
    result = run_model_check(left, right, models, folder, engine=engine)
    child, trace = api.analyze_pair_with_trace(folder / "expected/output.wav", folder / "input/processed.wav",
                                              engine=engine)
    assert result["analysis"] == child
    if engine != "v1":
        assert json.loads((folder / "trace.json").read_text(encoding="utf-8")) == trace
    else:
        assert not (folder / "trace.json").exists()


@pytest.mark.parametrize("models", [[], [{"kind": "unknown"}], [{"kind": "polarity_invert", "code": "run"}]])
def test_invalid_model_plan_has_no_output(tmp_path, models):
    left, right, _ = _pair(tmp_path)
    with pytest.raises(ModelCheckError):
        run_model_check(left, right, models, tmp_path / "run")
    assert not (tmp_path / "run").exists()


def test_rate_change_not_silently_added_to_declared_model(tmp_path):
    left, right, models = _pair(tmp_path)
    right.write_bytes(encode_wav(np.zeros(32000), 16000))
    with pytest.raises(ModelCheckError, match="unsupported_model_rate_pair"):
        run_model_check(left, right, models, tmp_path / "run")
    assert not (tmp_path / "run").exists()


def test_existing_output_and_original_are_not_overwritten(tmp_path):
    left, right, models = _pair(tmp_path)
    old = left.read_bytes()
    with pytest.raises(ModelCheckError, match="output_directory_exists"):
        run_model_check(left, right, models, left)
    assert left.read_bytes() == old
    folder = tmp_path / "exists"
    folder.mkdir()
    sentinel = folder / "sentinel.txt"
    sentinel.write_text("preserve")
    with pytest.raises(ModelCheckError):
        run_model_check(left, right, models, folder)
    assert sentinel.read_text() == "preserve"


@pytest.mark.parametrize("target", ["named_source", "named_processed", "expected_snapshot", "processed_snapshot"])
def test_changed_inputs_or_snapshots_cannot_clear(tmp_path, monkeypatch, target):
    left, right, models = _pair(tmp_path)
    folder = tmp_path / "run"
    real = api.analyze_pair_with_trace
    def mutate(reference, processed, **kwargs):
        result = real(reference, processed, **kwargs)
        path = {"named_source": left, "named_processed": right,
                "expected_snapshot": reference, "processed_snapshot": processed}[target]
        path.write_bytes(b"changed")
        return result
    monkeypatch.setattr(api, "analyze_pair_with_trace", mutate)
    with pytest.raises(ModelCheckError, match="model_input_or_snapshot_changed_during_run"):
        run_model_check(left, right, models, folder)
    assert not (folder / "model_result.json").exists()
    assert (folder / "manifest_started.json").exists()
    assert json.loads((folder / "run_failed.json").read_text())["exit_code"] == 2


@pytest.mark.parametrize("text", ["{", '{"schema_version":1,"schema_version":1,"models":[]}',
                                  '{"schema_version":1,"models":NaN}', "\udcff"])
def test_bad_plan_text_is_rejected_without_private_text(tmp_path, text):
    path = tmp_path / "private_plan.json"
    path.write_bytes(text.encode("utf-8", errors="surrogatepass"))
    with pytest.raises(ModelCheckError) as caught:
        load_model_plan(path)
    assert "private_plan" not in str(caught.value)


def test_plan_loader_is_bounded(tmp_path):
    path = tmp_path / "plan.json"
    path.write_bytes(b" " * 65537)
    with pytest.raises(ModelCheckError, match="model_plan_too_large"):
        load_model_plan(path)


def test_initial_input_parent_reparse_rejected_before_output(tmp_path, monkeypatch):
    from audio_regression import model_check
    from audio_regression.pipeline_runner import PipelineRunError
    left, right, models = _pair(tmp_path)
    normal = model_check._normal_parents
    def reject(path):
        if path == left:
            raise PipelineRunError("unsafe_output_parent")
        normal(path)
    monkeypatch.setattr(model_check, "_normal_parents", reject)
    with pytest.raises(ModelCheckError):
        run_model_check(left, right, models, tmp_path / "run")
    assert not (tmp_path / "run").exists()


@pytest.mark.parametrize("target", ["named_source", "named_processed", "expected_snapshot", "processed_snapshot", "source_snapshot"])
def test_same_bytes_reparse_replacement_cannot_clear(tmp_path, monkeypatch, target):
    from types import SimpleNamespace
    from pathlib import Path
    import stat
    left, right, models = _pair(tmp_path)
    folder = tmp_path / "run"
    real_analysis, real_lstat = api.analyze_pair_with_trace, Path.lstat
    changed = {"path": None}
    def fake_lstat(path):
        if path == changed["path"]:
            return SimpleNamespace(st_mode=stat.S_IFREG, st_file_attributes=0x400)
        return real_lstat(path)
    def mutate(reference, processed, **kwargs):
        result = real_analysis(reference, processed, **kwargs)
        changed["path"] = {"named_source": left, "named_processed": right,
                           "expected_snapshot": reference, "processed_snapshot": processed,
                           "source_snapshot": folder / "input/source.wav"}[target]
        return result
    monkeypatch.setattr(Path, "lstat", fake_lstat)
    monkeypatch.setattr(api, "analyze_pair_with_trace", mutate)
    with pytest.raises(ModelCheckError, match="invalid_model_input_file"):
        run_model_check(left, right, models, folder)
    assert not (folder / "model_result.json").exists()
    assert json.loads((folder / "run_failed.json").read_text())["exit_code"] == 2


def test_report_unsafe_parent_creates_no_html(tmp_path, monkeypatch):
    from audio_regression import model_reporting
    from audio_regression.pipeline_runner import PipelineRunError
    left, right, models = _pair(tmp_path)
    result = run_model_check(left, right, models, tmp_path / "run")
    def reject(_):
        raise PipelineRunError("unsafe_output_parent")
    monkeypatch.setattr(model_reporting, "_normal_parents", reject)
    destination = tmp_path / "new.html"
    with pytest.raises(ModelCheckError, match="unsafe_model_report_path"):
        model_reporting.write_model_html(result, destination)
    assert not destination.exists()


def _mutate_inside_guard_read(monkeypatch, target, replacement):
    """Change an owned file after read(), before the guard's post-read stat."""
    from audio_regression import artifact_integrity
    observed = []
    real_fdopen = artifact_integrity.os.fdopen

    class ObservedRead:
        def __init__(self, stream):
            self.stream = stream

        def __enter__(self):
            self.stream.__enter__()
            return self

        def __exit__(self, *args):
            return self.stream.__exit__(*args)

        def fileno(self):
            return self.stream.fileno()

        def read(self, size):
            data = self.stream.read(size)
            if data and not observed:
                before = target.stat()
                target.write_bytes(replacement)
                # Ensure an observable timestamp change even on coarse clocks.
                artifact_integrity.os.utime(
                    target, ns=(before.st_atime_ns, before.st_mtime_ns + 1_000_000_000),
                )
                after = target.stat()
                observed.append((before.st_ino == after.st_ino,
                                 before.st_mtime_ns != after.st_mtime_ns))
            return data

    def opened(descriptor, *args, **kwargs):
        info = artifact_integrity.os.fstat(descriptor)
        stream = real_fdopen(descriptor, *args, **kwargs)
        if target.exists():
            named = target.stat()
            if (info.st_dev, info.st_ino) == (named.st_dev, named.st_ino):
                return ObservedRead(stream)
        return stream

    monkeypatch.setattr(artifact_integrity.os, "fdopen", opened)
    return observed


def test_guard_reads_unchanged_regular_bytes_exactly(tmp_path):
    from audio_regression.model_check import _checked_input_bytes
    left, _, _ = _pair(tmp_path)
    assert _checked_input_bytes(left) == left.read_bytes()


def test_same_inode_change_during_guard_read_is_rejected(tmp_path, monkeypatch):
    from audio_regression.model_check import _checked_input_bytes
    left, _, _ = _pair(tmp_path)
    changed = encode_wav(np.zeros(32000), 8000)
    observed = _mutate_inside_guard_read(monkeypatch, left, changed)
    with pytest.raises(ModelCheckError) as caught:
        _checked_input_bytes(left)
    assert caught.value.code == "model_input_changed_during_read"
    assert observed == [(True, True)]
    assert left.read_bytes() == changed


def test_guard_read_failure_retains_private_safe_code(tmp_path, monkeypatch):
    from audio_regression import artifact_integrity
    from audio_regression.model_check import _checked_input_bytes
    left, _, _ = _pair(tmp_path)

    def denied(*args):
        raise PermissionError("C:/caller-secret/private-audio.wav")

    monkeypatch.setattr(artifact_integrity.os, "open", denied)
    with pytest.raises(ModelCheckError) as caught:
        _checked_input_bytes(left)
    assert caught.value.code == "file_read_error"
    assert "caller-secret" not in str(caught.value)


def test_guard_retains_input_byte_limit_code(tmp_path):
    from audio_regression.audio import MAX_FILE_BYTES
    from audio_regression.model_check import _checked_input_bytes
    left = tmp_path / "oversized.wav"
    left.write_bytes(b"0" * (MAX_FILE_BYTES + 1))
    with pytest.raises(ModelCheckError) as caught:
        _checked_input_bytes(left)
    assert caught.value.code == "file_too_large"


def test_guard_rejects_observable_regular_file_hardlink(tmp_path, monkeypatch):
    from pathlib import Path
    from types import SimpleNamespace
    from audio_regression.model_check import _checked_input_bytes
    left, _, _ = _pair(tmp_path)
    real = Path.lstat

    def aliased(path):
        info = real(path)
        if path == left:
            return SimpleNamespace(st_mode=info.st_mode,
                                   st_file_attributes=getattr(info, "st_file_attributes", 0),
                                   st_nlink=2)
        return info

    monkeypatch.setattr(Path, "lstat", aliased)
    with pytest.raises(ModelCheckError) as caught:
        _checked_input_bytes(left)
    assert caught.value.code == "invalid_model_input_file"


@pytest.mark.parametrize("runner", ["model", "fullband"])
def test_actual_runner_never_completes_when_last_snapshot_changes_inside_read(tmp_path, monkeypatch, runner):
    from audio_regression.fullband_runner import FullbandRunError, run_fullband_measurement
    left, right, models = _pair(tmp_path)
    folder = tmp_path / "new_guard_run"
    target = folder / ("expected/output.wav" if runner == "model" else "input/processed.wav")
    changed = encode_wav(np.zeros(32000), 8000)
    observed = _mutate_inside_guard_read(monkeypatch, target, changed)
    error_type = ModelCheckError if runner == "model" else FullbandRunError
    with pytest.raises(error_type) as caught:
        if runner == "model":
            run_model_check(left, right, models, folder)
        else:
            run_fullband_measurement(left, right, folder)
    expected = ("model_input_changed_during_read" if runner == "model"
                else "fullband_input_changed_during_read")
    assert caught.value.code == expected
    assert observed == [(True, True)]
    assert not (folder / ("model_result.json" if runner == "model" else "fullband_result.json")).exists()
    failed = json.loads((folder / "run_failed.json").read_text(encoding="utf-8"))
    assert failed["reason_code"] == expected
    assert failed["exit_code"] == (2 if runner == "model" else 3)
    assert (folder / "manifest_started.json").exists()
