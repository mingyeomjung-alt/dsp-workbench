"""Fake-only compound event evaluation contracts; these tests never analyze a natural recording."""

from copy import deepcopy
import hashlib
import importlib.util
import json
from pathlib import Path
from types import SimpleNamespace

import pytest


TOOL = Path(__file__).resolve().parents[1] / "tools/compound_event_eval_execute.py"
SPEC = importlib.util.spec_from_file_location("compound_event_eval_execute_test_module", TOOL)
executor = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(executor)
STRICT_RESULT_VALIDATOR = executor.validate_analysis_result


def _write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value), encoding="utf-8")


def _hash(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


@pytest.fixture
def suite(tmp_path, monkeypatch):
    # Deliberate fake-only result injection. No natural recording is decoded;
    # the exact strict validator is tested separately without this injection.
    monkeypatch.setattr(executor, "validate_analysis_result", lambda value: value)
    workspace = tmp_path / "workspace"
    package = workspace / "dsp_engine/src/audio_regression"
    package.mkdir(parents=True)
    (package / "dummy.py").write_text("# frozen", encoding="utf-8")
    schema = package / "schemas/dummy.json"
    _write(schema, {"type": "object"})
    script = workspace / "dsp_engine/tools/compound_event_eval_execute.py"
    script.parent.mkdir(parents=True)
    script.write_text("# fake-only worker is never executed", encoding="utf-8")
    for relative in executor.REQUIRED_HELPERS:
        helper = workspace / relative
        helper.parent.mkdir(parents=True, exist_ok=True)
        helper.write_text("# frozen test-only helper", encoding="utf-8")
    monkeypatch.setattr(executor, "WORKSPACE", workspace)
    monkeypatch.setattr(executor, "PACKAGE", package)
    monkeypatch.setattr(executor, "__file__", str(script))
    root = workspace / "suite"
    root.mkdir()
    manifest, jobs, sources, selected = [], [], [], []
    conditions = [(n, True, "supported", []) for n in sorted(executor.NORMAL_CONDITIONS)]
    for duration in (200, 400, 750):
        conditions += [(f"delete_{duration}", False, "supported", [{"type": "delete", "reference_interval_ms": [4200.0, 4200.0 + duration], "processed_boundary_ms": 4440.0}]),
                       (f"repeat_{duration}", False, "supported", [{"type": "repeat", "reference_source_interval_ms": [4200.0, 4200.0 + duration], "processed_added_interval_ms": [4440.0 + duration, 4440.0 + 2 * duration]}])]
    conditions += [(n, False, "stress", []) for n in sorted(executor.STRESS_CONDITIONS)]
    for category in executor.CATEGORIES:
        for number in range(executor.SOURCE_COUNT_BY_CATEGORY[category]):
            group = f"{category}{number}"
            folder = root / group
            folder.mkdir()
            reference = folder / "reference.wav"
            reference.write_bytes(f"fake-reference-{group}-not-audio".encode())
            original = folder / "original.ogg"
            original.write_bytes(f"fake-original-{group}-not-audio".encode())
            identifier = f"Original {group}"
            selected.append({"group": group, "id": identifier})
            sources.append({"source_group": group, "category": category, "recording_id": identifier,
                            "identity_aliases": [executor.normalize_identity(identifier)],
                            "original_path": original.relative_to(root).as_posix(),
                            "original_sha256": _hash(original),
                            "prior_identifier_or_original_or_prepared_hash_overlap": False,
                            "preparation": {"excerpt_start_ms": 0.0, "excerpt_end_ms": 12000.0,
                                            "prepared": {"sha256": _hash(reference), "sample_count": 192000,
                                                         "sample_rate_hz": 16000, "duration_ms": 12000.0,
                                                         "channels": 1, "encoding": "pcm16"}}})
            for name, normal, scope, truth in conditions:
                processed = folder / f"{name}.wav"
                processed.write_bytes(f"fake-processed-{group}-{name}-not-audio".encode())
                gain = name in {"normal_gain", "normal_combined"} or name in executor.EVENT_CONDITIONS
                resampling = name in {"normal_resample", "normal_combined"} or name in executor.EVENT_CONDITIONS
                config = {"profile": "basic", "allow_gain": gain, "allow_resampling": resampling, "max_delay_ms": 1000.0}
                duration = 12000.0
                if name in {"normal_delay", "normal_combined"}:
                    duration = 12240.0
                elif name.startswith("delete_"):
                    duration = max(12000.0, 12240.0 - int(name.split("_")[1]))
                elif name.startswith("repeat_"):
                    duration = 12240.0 + int(name.split("_")[1])
                row = {"trial_id": hashlib.sha256(f"{group}:{name}".encode()).hexdigest()[:24],
                       "source_group": group, "category": category, "condition": name,
                       "scope": scope, "normal_trial": normal, "configuration": config,
                       "expected_events": truth, "input_duration_ms": duration,
                       "reference_path": reference.relative_to(root).as_posix(),
                       "processed_path": processed.relative_to(root).as_posix(),
                       "reference_sha256": _hash(reference), "processed_sha256": _hash(processed)}
                manifest.append(row)
                jobs.append({"trial_id": row["trial_id"], "reference_path": str(reference),
                             "processed_path": str(processed), "configuration": config})
    protocol = {"criteria": executor.CRITERIA, "methods": list(executor.ENGINES), "categories": list(executor.CATEGORIES),
                "source_count": 4, "pair_count": 56, "source_count_by_category": executor.SOURCE_COUNT_BY_CATEGORY,
                "profile": "basic", "bootstrap_resamples": 2000, "bootstrap_seed": 20261014,
                "final_uses": 1, "retune_after_results": False, "sources": sources,
                "post_result_case_exclusion_allowed": False, "first_excerpt_fixed": True}
    _write(root / "protocol.json", protocol)
    _write(root / "manifest.json", manifest)
    _write(root / "worker_jobs.json", jobs)
    _write(root / "runtime.json", {"fake_only": True})
    _write(root / "source_selection_before_download.json", {"sources": selected, "source_reselection_allowed": False})
    _write(root / "used_sources_before_selection.json", {"prior_recording_ids": ["old used music"],
                                                       "prior_audio_sha256": ["1" * 64], "prior_identity_aliases": ["old used music"]})
    def refreeze():
        paths = [script, package / "dummy.py", schema] + [workspace / name for name in executor.REQUIRED_HELPERS]
        frozen = {"final_uses": 1,
                  "code_sha256": {p.relative_to(workspace).as_posix(): _hash(p) for p in paths},
                  "dataset_sha256": {p.relative_to(root).as_posix(): _hash(p) for p in root.rglob("*")
                                     if p.is_file() and p.name not in {"freeze.json", "run_claim.json", "run_completed.json", "report.json"} and "outputs" not in p.parts}}
        _write(root / "freeze.json", frozen)
        return frozen
    return SimpleNamespace(root=root, manifest=manifest, jobs=jobs, freeze=refreeze(), refreeze=refreeze, script=script, protocol=protocol)


def _result(row, engine, *, held=False, extra=False):
    if row["scope"] == "stress" or held:
        return {"engine": "local_content_alignment_" + engine, "status": "withheld", "events": None}
    events = deepcopy(row["expected_events"])
    if extra:
        events.append({"type": "delete", "reference_interval_ms": [3000, 3400]})
    return {"engine": "local_content_alignment_" + engine, "status": "analyzed", "events": events}


def _trace(row, engine, result):
    if engine == "v1":
        return None
    trace = {"schema_version": 1, "engine": "local_content_alignment_" + engine,
             "analysis_engine": "local_content_alignment_" + engine,
             "method": executor.TRACE_METHODS[engine],
             "reference_sha256": row["reference_sha256"], "processed_sha256": row["processed_sha256"],
             "result_status": result["status"], "reason_code": result.get("reason_code"),
             "baseline_status": result["status"], "baseline_reason_code": result.get("reason_code")}
    if engine == "v7":
        trace.update(proof_path="preserved_v6_result", compound_attempted=False, compound_proved=False)
    else:
        trace.update(proof_path="preserved_v7_result", compound_event_attempted=False, compound_event_proved=False,
                     inherited_v7_trace=_trace(row, "v7", result))
    return trace


def _outputs(suite, *, baseline_hold=True, candidate_extra=False, secondary_hold=False):
    folder = suite.root / "outputs"
    folder.mkdir(exist_ok=True)
    for engine in executor.ENGINES:
        rows = []
        for index, row in enumerate(suite.manifest):
            result = _result(row, engine,
                             held=index == 0 and ((engine == "v1" and baseline_hold) or (engine == "v7" and secondary_hold)),
                             extra=engine == "v8" and candidate_extra and index == 5)
            rows.append({"trial_id": row["trial_id"], "runtime_ms": 50.0, "execution_error": False,
                         "result": result, "trace": _trace(row, engine, result)})
        path = folder / f"{engine}.jsonl"
        path.write_text("\n".join(json.dumps(r) for r in rows) + "\n", encoding="utf-8")


def test_fake_only_inputs_and_truth_free_jobs_are_valid(suite):
    executor.verify_freeze(suite.root)
    protocol, manifest, jobs = executor.validate_inputs(suite.root, suite.freeze)
    assert len(manifest) == len(jobs) == 56
    assert protocol["methods"] == ["v1", "v7", "v8"]
    assert all(set(j) == executor.JOB_KEYS for j in jobs)


@pytest.mark.parametrize("file", ["protocol.json", "manifest.json", "worker_jobs.json", "music0/reference.wav"])
def test_data_tampering_is_detected_before_claim(suite, file):
    (suite.root / file).write_bytes(b"changed")
    with pytest.raises(ValueError, match="changed"):
        executor.run_suite(suite.root)
    assert not (suite.root / "run_claim.json").exists()


def test_code_tampering_is_detected_before_claim(suite):
    suite.script.write_text("changed", encoding="utf-8")
    with pytest.raises(ValueError, match="changed"):
        executor.run_suite(suite.root)
    assert not (suite.root / "run_claim.json").exists()


def test_schema_omission_is_detected_before_claim(suite):
    frozen = deepcopy(suite.freeze)
    frozen["code_sha256"].pop("dsp_engine/src/audio_regression/schemas/dummy.json")
    _write(suite.root / "freeze.json", frozen)
    with pytest.raises(ValueError, match="schemas"):
        executor.run_suite(suite.root)
    assert not (suite.root / "run_claim.json").exists()


@pytest.mark.parametrize("mutation", ["truth", "escape", "criteria", "category", "count", "duplicate", "condition", "hash", "kind"])
def test_invalid_manifest_or_job_contract_is_rejected(suite, mutation):
    if mutation == "truth":
        suite.jobs[0]["expected_events"] = []
    elif mutation == "escape":
        suite.jobs[0]["reference_path"] = str(suite.root.parent / "other.wav")
    elif mutation == "criteria":
        wrong = deepcopy(executor.CRITERIA)
        wrong["event_recall_minimum"] = .5
        suite.protocol["criteria"] = wrong
    elif mutation == "category":
        suite.manifest[0]["category"] = "environment"
    elif mutation == "count":
        suite.manifest.pop()
    elif mutation == "condition":
        suite.manifest[0]["condition"] = "unregistered"
    elif mutation == "hash":
        suite.manifest[0]["reference_sha256"] = "0" * 64
    elif mutation == "kind":
        suite.manifest[5]["condition"] = "repeat_200"
    else:
        suite.manifest[1]["condition"] = suite.manifest[0]["condition"]
    _write(suite.root / "protocol.json", suite.protocol)
    _write(suite.root / "manifest.json", suite.manifest)
    _write(suite.root / "worker_jobs.json", suite.jobs)
    with pytest.raises(ValueError):
        executor.validate_inputs(suite.root, suite.refreeze())


@pytest.mark.parametrize("key,value", [("methods", ["v8", "v7", "v1"]), ("categories", ["music", "speech"]),
                                      ("source_count", True), ("pair_count", 84), ("bootstrap_seed", 3),
                                      ("bootstrap_resamples", 10), ("retune_after_results", True), ("final_uses", 2)])
def test_scope_and_policy_cannot_change(suite, key, value):
    suite.protocol[key] = value
    _write(suite.root / "protocol.json", suite.protocol)
    with pytest.raises(ValueError, match="scope"):
        executor.validate_inputs(suite.root, suite.refreeze())


def test_source_declaration_cannot_disagree_with_manifest(suite):
    suite.protocol["sources"][0]["source_group"] = "another"
    _write(suite.root / "protocol.json", suite.protocol)
    with pytest.raises(ValueError, match="declared|aliases"):
        executor.validate_inputs(suite.root, suite.refreeze())


def test_paired_improvement_with_all_gates_passed_can_be_scoped_adopted(suite):
    _outputs(suite, secondary_hold=True)
    report = executor.score_saved(suite.root, suite.manifest)
    assert report["decision"]["adopt"] is True
    assert report["decision"]["decision"] == "adopt_v8_candidate_for_scoped_offline_use_only"
    assert report["decision"]["statistically_proven_improvement"] is False
    assert report["paired_source_bootstrap"]["source_group_count"] == 4
    assert all(r["source_group_count"] == 4 for r in report["paired_source_bootstrap_by_category"].values())
    secondary = report["secondary_comparison_v8_vs_v7"]
    assert secondary["supported_outcome_success_difference"] == 1
    assert len(secondary["improved_trial_ids"]) == 1
    assert secondary["regressed_trial_ids"] == []


def test_tie_retains_default_and_false_positive_event_never_counts_correct(suite):
    _outputs(suite, baseline_hold=False, candidate_extra=True)
    report = executor.score_saved(suite.root, suite.manifest)
    assert report["decision"]["adopt"] is False
    assert report["engines"]["v8"]["supported_outcome_success_count"] == 43
    assert report["secondary_comparison_v8_vs_v7"]["regressed_trial_ids"]


def test_secondary_regression_blocks_adoption_even_when_primary_improves(suite):
    _outputs(suite)
    baseline = suite.root / "outputs/v1.jsonl"
    baseline_lines = baseline.read_text(encoding="utf-8").splitlines()
    baseline_item = json.loads(baseline_lines[2])
    baseline_item["result"] = _result(suite.manifest[2], "v1", held=True)
    baseline_lines[2] = json.dumps(baseline_item)
    baseline.write_text("\n".join(baseline_lines) + "\n", encoding="utf-8")
    path = suite.root / "outputs/v8.jsonl"
    lines = path.read_text(encoding="utf-8").splitlines()
    item = json.loads(lines[1])
    item["result"] = _result(suite.manifest[1], "v8", held=True)
    item["trace"] = _trace(suite.manifest[1], "v8", item["result"])
    lines[1] = json.dumps(item)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    report = executor.score_saved(suite.root, suite.manifest)
    assert report["decision"]["adopt"] is False
    assert report["engines"]["v8"]["supported_outcome_success_count"] > report["engines"]["v1"]["supported_outcome_success_count"]
    assert any(not c["passed"] for c in report["decision"]["criteria_checks"] if "vs_v7" in c["criterion"])


def test_abstention_is_missed_event_and_failed_normal_not_false_success(suite):
    rows = [{**row, "source_kind": row["category"], "profile": "basic", "runtime_ms": 50,
             "execution_error": False, "result": _result(row, "v8", held=True)} for row in suite.manifest]
    summary = executor.summarize(rows)
    assert summary["supported"]["overall"]["normal_coverage"] == 0
    assert summary["supported"]["overall"]["false_negative_events"] == 24
    assert summary["supported_outcome_success_count"] == 0
    assert executor.decide(summary, summary, summary)["adopt"] is False


@pytest.mark.parametrize("mutation", ["partial", "wrong_engine", "duplicate_key", "nonfinite", "bad_runtime", "error_clear"])
def test_invalid_outputs_cannot_score(suite, mutation):
    _outputs(suite)
    path = suite.root / "outputs/v8.jsonl"
    lines = path.read_text(encoding="utf-8").splitlines()
    first = json.loads(lines[0])
    if mutation == "partial":
        lines.pop()
    elif mutation == "wrong_engine":
        first["result"]["engine"] = "local_content_alignment_v1"
        lines[0] = json.dumps(first)
    elif mutation == "duplicate_key":
        lines[0] = lines[0][:-1] + ', "runtime_ms": 10}'
    elif mutation == "nonfinite":
        first["runtime_ms"] = float("nan")
        lines[0] = json.dumps(first)
    elif mutation == "bad_runtime":
        first["runtime_ms"] = True
        lines[0] = json.dumps(first)
    elif mutation == "error_clear":
        first["execution_error"] = True
        lines[0] = json.dumps(first)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    with pytest.raises(ValueError):
        executor.score_saved(suite.root, suite.manifest)


def test_worker_failure_consumes_claim_and_persists_no_adoption(suite, monkeypatch):
    monkeypatch.setattr(executor.subprocess, "run", lambda *a, **k: SimpleNamespace(returncode=9))
    report = executor.run_suite(suite.root)
    assert report["status"] == "incomplete"
    assert report["decision"]["adopt"] is False
    assert report["freeze_unchanged"] is True
    assert (suite.root / "run_claim.json").is_file()
    assert (suite.root / "run_completed.json").is_file()
    with pytest.raises(FileExistsError):
        executor.run_suite(suite.root)


def test_successful_mock_workers_save_all_raw_before_scoring_and_disallow_rerun(suite, monkeypatch):
    order = []
    original_score = executor.score_saved
    def fake_worker(command, **kwargs):
        engine = command[command.index("--worker-engine") + 1]
        order.append(engine)
        assert all(kwargs["env"][k] == "1" for k in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS"))
        if engine == "v8":
            _outputs(suite, secondary_hold=True)
        return SimpleNamespace(returncode=0)
    def score(root, manifest):
        assert order == ["v1", "v7", "v8"]
        assert all((root / "outputs" / f"{engine}.jsonl").is_file() for engine in executor.ENGINES)
        return original_score(root, manifest)
    monkeypatch.setattr(executor.subprocess, "run", fake_worker)
    monkeypatch.setattr(executor, "score_saved", score)
    report = executor.run_suite(suite.root)
    assert report["decision"]["adopt"] is True
    original = (suite.root / "report.json").read_bytes()
    with pytest.raises(FileExistsError):
        executor.run_suite(suite.root)
    assert (suite.root / "report.json").read_bytes() == original


def test_freeze_replacement_during_worker_is_detected(suite, monkeypatch):
    def fake_worker(command, **kwargs):
        if command[command.index("--worker-engine") + 1] == "v8":
            _outputs(suite)
            freeze = json.loads((suite.root / "freeze.json").read_text(encoding="utf-8"))
            freeze["post_result_change"] = True
            _write(suite.root / "freeze.json", freeze)
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(executor.subprocess, "run", fake_worker)
    report = executor.run_suite(suite.root)
    assert report["status"] == "incomplete"
    assert report["decision"]["adopt"] is False
    assert report["freeze_unchanged"] is False


def test_fake_worker_records_stable_code_and_not_private_exception_message(suite, monkeypatch):
    from audio_regression import api
    from audio_regression.audio import AudioInputError
    calls = []
    def no_audio(reference, processed, *, engine, **config):
        calls.append(engine)
        raise AudioInputError("unsupported_sample_rate", "private C:/recordings/user.wav")
    monkeypatch.setattr(api, "analyze_pair_with_trace", no_audio)
    output = suite.root / "fake-worker.jsonl"
    metadata = executor.worker_run(suite.root / "worker_jobs.json", output, "v8")
    assert calls == ["v8"] * 56
    assert metadata["execution_error_count"] == 56
    raw = output.read_text(encoding="utf-8")
    assert "private C:" not in raw
    result = json.loads(raw.splitlines()[0])["result"]
    assert result["exception_type"] == "AudioInputError"
    assert result["exception_reason_code"] == "unsupported_sample_rate"
    assert result["status"] == "withheld" and result["events"] is None


@pytest.mark.parametrize("reason", [None, "C:/private/file.wav", "BOOM", "a" * 129, 5])
def test_arbitrary_exception_details_are_not_machine_codes(reason):
    error = ValueError("private")
    error.code = reason
    assert executor._exception(error) == {"exception_type": "ValueError", "exception_reason_code": None}


def test_candidate_tie_with_v7_cannot_piggyback_v7_gain_over_v1(suite):
    _outputs(suite, baseline_hold=True, secondary_hold=False)
    report = executor.score_saved(suite.root, suite.manifest)
    assert report["decision"]["adopt"] is False
    checks = {check["criterion"]: check for check in report["decision"]["criteria_checks"]}
    assert checks["supported_outcome_improvement_vs_v1"]["passed"] is True
    assert checks["supported_outcome_improvement_vs_v7"]["passed"] is False
    assert checks["supported_outcome_improvement_vs_v7"]["observed"] == 0


def test_old_numeric_criteria_are_preserved_without_added_event_fp_gate():
    assert executor.CRITERIA["normal_coverage_minimum"] == .90
    assert executor.CRITERIA["event_precision_minimum"] == .90
    assert executor.CRITERIA["event_recall_minimum"] == .90
    assert executor.CRITERIA["normal_false_alarm_count_maximum"] == 0
    assert executor.CRITERIA["stress_false_clear_count_maximum"] == 0
    assert executor.CRITERIA["median_primary_boundary_error_maximum_ms"] == 100
    assert executor.CRITERIA["median_rtf_maximum"] == 1
    assert executor.CRITERIA["minimum_supported_outcome_improvements"] == 1
    assert "event_false_positive_count_maximum" not in executor.CRITERIA


def test_executor_uses_only_new_methods_and_four_music_groups():
    assert executor.ENGINES == ("v1", "v7", "v8")
    assert executor.CATEGORIES == ("music",)
    assert executor.SOURCE_COUNT == 4
    assert executor.PAIR_COUNT == 56
    assert executor.SOURCE_COUNT_BY_CATEGORY == {"music": 4}


def test_saved_output_strict_validator_is_called_for_every_nonerror_row(suite, monkeypatch):
    _outputs(suite, secondary_hold=True)
    calls = []
    monkeypatch.setattr(executor, "validate_analysis_result", lambda value: calls.append(value))
    report = executor.score_saved(suite.root, suite.manifest)
    assert len(calls) == 56 * 3
    assert {value["engine"] for value in calls} == {
        "local_content_alignment_v1", "local_content_alignment_v7", "local_content_alignment_v8"}
    assert report["decision"]["adopt"] is True


def test_real_strict_validator_rejects_fabricated_minimal_envelope(suite, monkeypatch):
    _outputs(suite)
    monkeypatch.setattr(executor, "validate_analysis_result", STRICT_RESULT_VALIDATOR)
    with pytest.raises(ValueError):
        executor.load_outputs(suite.root / "outputs/v8.jsonl", suite.manifest, "v8")


def test_repetition_stratum_retains_all_withheld_truth_events(suite):
    rows = [{**row, "source_kind": row["category"], "profile": "basic", "runtime_ms": 50,
             "execution_error": False, "result": _result(row, "v8", held=row["condition"].startswith("repeat_"))}
            for row in suite.manifest]
    summary = executor.summarize(rows)
    assert summary["by_event_type"]["repeat"]["trial_count"] == 12
    assert summary["by_event_type"]["repeat"]["false_negative_events"] == 12
    assert summary["by_event_type"]["repeat"]["event_recall"] == 0
    assert summary["by_event_type"]["delete"]["event_recall"] == 1
    assert summary["by_event_type"]["delete"]["trial_count"] == 12


@pytest.mark.parametrize("key, value", [("event_precision", .89), ("event_recall", .89),
                                       ("event_precision", None), ("event_recall", None)])
def test_repeat_specific_gate_cannot_be_masked_by_overall_pass(suite, key, value):
    _outputs(suite, secondary_hold=True)
    report = executor.score_saved(suite.root, suite.manifest)
    candidate = deepcopy(report["engines"]["v8"])
    candidate["by_event_type"]["repeat"][key] = value
    decision = executor.decide(candidate, report["engines"]["v1"], report["engines"]["v7"])
    assert decision["adopt"] is False
    checks = {item["criterion"]: item for item in decision["criteria_checks"]}
    assert checks[f"repeat.{key}"]["passed"] is False


def test_execution_error_rows_bypass_full_contract_but_remain_withheld(suite, monkeypatch):
    _outputs(suite)
    path = suite.root / "outputs/v8.jsonl"
    lines = path.read_text(encoding="utf-8").splitlines()
    first = json.loads(lines[0])
    first["execution_error"] = True
    first["result"] = {"status": "withheld", "events": None, "reason_code": "evaluation_execution_error",
                       "exception_type": "ValueError", "exception_reason_code": None}
    first["trace"] = None
    lines[0] = json.dumps(first)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    calls = []
    monkeypatch.setattr(executor, "validate_analysis_result", lambda value: calls.append(value))
    rows = executor.load_outputs(path, suite.manifest, "v8")
    assert len(calls) == 55
    assert rows[0]["execution_error"] is True
    assert rows[0]["result"]["status"] == "withheld"


@pytest.mark.parametrize("kind,key,value", [(kind, key, value)
                                           for kind in ("delete", "repeat")
                                           for key in ("event_precision", "event_recall")
                                           for value in (.89, None)])
def test_each_event_kind_has_its_own_fixed_gate(suite, kind, key, value):
    _outputs(suite, secondary_hold=True)
    report = executor.score_saved(suite.root, suite.manifest)
    candidate = deepcopy(report["engines"]["v8"])
    candidate["by_event_type"][kind][key] = value
    decision = executor.decide(candidate, report["engines"]["v1"], report["engines"]["v7"])
    assert decision["adopt"] is False
    assert next(c for c in decision["criteria_checks"] if c["criterion"] == f"{kind}.{key}")["passed"] is False


@pytest.mark.parametrize("relative", executor.REQUIRED_HELPERS)
def test_all_inherited_preparation_helpers_and_protocol_must_be_frozen(suite, relative):
    frozen = deepcopy(suite.freeze)
    frozen["code_sha256"].pop(relative)
    _write(suite.root / "freeze.json", frozen)
    with pytest.raises(ValueError, match="helpers"):
        executor.run_suite(suite.root)
    assert not (suite.root / "run_claim.json").exists()


@pytest.mark.parametrize("relative", sorted(executor.REQUIRED_DATA - {"protocol.json", "manifest.json", "worker_jobs.json"}))
def test_all_preselection_metadata_must_be_frozen(suite, relative):
    frozen = deepcopy(suite.freeze)
    frozen["dataset_sha256"].pop(relative)
    _write(suite.root / "freeze.json", frozen)
    with pytest.raises(ValueError, match="exclusions"):
        executor.run_suite(suite.root)
    assert not (suite.root / "run_claim.json").exists()


@pytest.mark.parametrize("mutation", ["prior_id", "prior_alias", "prior_original", "prior_reference",
                                      "duplicate_original", "duplicate_reference", "wrong_original_path",
                                      "reference_alias", "short_excerpt", "later_excerpt", "missing_alias"])
def test_used_source_and_alias_reuse_is_rejected_before_claim(suite, mutation):
    first, second = suite.protocol["sources"][:2]
    excluded = json.loads((suite.root / "used_sources_before_selection.json").read_text(encoding="utf-8"))
    if mutation == "prior_id":
        excluded["prior_recording_ids"].append(first["recording_id"])
    elif mutation == "prior_alias":
        excluded["prior_identity_aliases"].append("https://commons.wikimedia.org/wiki/File:ORIGINAL_music0.OGG")
    elif mutation == "prior_original":
        excluded["prior_audio_sha256"].append(first["original_sha256"])
    elif mutation == "prior_reference":
        excluded["prior_audio_sha256"].append(first["preparation"]["prepared"]["sha256"])
    elif mutation == "duplicate_original":
        second["original_sha256"], second["original_path"] = first["original_sha256"], first["original_path"]
    elif mutation == "duplicate_reference":
        second["preparation"]["prepared"]["sha256"] = first["preparation"]["prepared"]["sha256"]
    elif mutation == "wrong_original_path":
        first["original_path"] = second["original_path"]
    elif mutation == "reference_alias":
        suite.manifest[0]["reference_sha256"] = second["preparation"]["prepared"]["sha256"]
        suite.manifest[0]["reference_path"] = suite.manifest[14]["reference_path"]
        suite.jobs[0]["reference_path"] = suite.jobs[14]["reference_path"]
    elif mutation == "short_excerpt":
        first["preparation"]["prepared"]["sample_count"] = 191998
        first["preparation"]["prepared"]["duration_ms"] = 191998 / 16
    elif mutation == "later_excerpt":
        first["preparation"]["excerpt_start_ms"] = 1000
    else:
        first["identity_aliases"] = []
    _write(suite.root / "used_sources_before_selection.json", excluded)
    _write(suite.root / "protocol.json", suite.protocol)
    _write(suite.root / "manifest.json", suite.manifest)
    _write(suite.root / "worker_jobs.json", suite.jobs)
    suite.refreeze()
    with pytest.raises(ValueError):
        executor.run_suite(suite.root)
    assert not (suite.root / "run_claim.json").exists()


@pytest.mark.parametrize("mutation", ["delete_length", "delete_axis", "delete_boundary", "repeat_source",
                                      "repeat_added_axis", "duration", "configuration", "opaque_id"])
def test_truth_geometry_and_condition_declarations_are_prelocked(suite, mutation):
    row = next(r for r in suite.manifest if r["condition"] == ("repeat_400" if mutation.startswith("repeat") else "delete_400"))
    if mutation == "delete_length":
        row["expected_events"][0]["reference_interval_ms"][1] += 100
    elif mutation == "delete_axis":
        row["expected_events"][0]["reference_interval_ms"] = [4100.0, 4500.0]
    elif mutation == "delete_boundary":
        row["expected_events"][0]["processed_boundary_ms"] = 4200.0
    elif mutation == "repeat_source":
        row["expected_events"][0]["reference_source_interval_ms"] = [4100.0, 4500.0]
    elif mutation == "repeat_added_axis":
        row["expected_events"][0]["processed_added_interval_ms"] = [4440.0, 4840.0]
    elif mutation == "duration":
        row["input_duration_ms"] = 10.0
    elif mutation == "configuration":
        row["configuration"]["allow_gain"] = False
    else:
        row["trial_id"] = "delete_400"
        suite.jobs[suite.manifest.index(row)]["trial_id"] = row["trial_id"]
    _write(suite.root / "manifest.json", suite.manifest)
    _write(suite.root / "worker_jobs.json", suite.jobs)
    with pytest.raises(ValueError):
        executor.validate_inputs(suite.root, suite.refreeze())


@pytest.mark.parametrize("mutation", ["missing", "engine", "analysis_engine", "method", "reference_sha256",
                                      "processed_sha256", "result_status", "schema_version", "proved_flag",
                                      "proof_path", "nested_hash", "nested_baseline_status"])
def test_saved_v8_trace_identity_is_strict_and_cannot_be_scored(suite, mutation):
    _outputs(suite, secondary_hold=True)
    path = suite.root / "outputs/v8.jsonl"
    lines = path.read_text(encoding="utf-8").splitlines()
    item = json.loads(lines[0])
    trace = item["trace"]
    if mutation == "missing":
        item["trace"] = None
    elif mutation in {"engine", "analysis_engine"}:
        trace[mutation] = "local_content_alignment_v7"
    elif mutation == "method":
        trace["method"] = executor.TRACE_METHODS["v7"]
    elif mutation in {"reference_sha256", "processed_sha256"}:
        trace[mutation] = "0" * 64
    elif mutation == "result_status":
        trace["result_status"] = "withheld"
    elif mutation == "schema_version":
        trace["schema_version"] = True
    elif mutation == "proved_flag":
        trace["compound_event_proved"] = True
    elif mutation == "proof_path":
        trace["proof_path"] = "compound_event_exact_forward"
    elif mutation == "nested_hash":
        trace["inherited_v7_trace"]["reference_sha256"] = "0" * 64
    else:
        trace["inherited_v7_trace"]["result_status"] = "withheld"
    lines[0] = json.dumps(item)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    with pytest.raises(ValueError, match="trace|Trace"):
        executor.score_saved(suite.root, suite.manifest)


def test_timeout_is_counted_and_consumes_claim_without_retry_or_scoring(suite, monkeypatch):
    order = []
    def worker(command, **kwargs):
        engine = command[command.index("--worker-engine") + 1]
        order.append(engine)
        if engine == "v7":
            raise executor.subprocess.TimeoutExpired(command, kwargs["timeout"])
        return SimpleNamespace(returncode=0)
    monkeypatch.setattr(executor.subprocess, "run", worker)
    monkeypatch.setattr(executor, "score_saved", lambda *a: pytest.fail("Partial workers must not be truth-scored"))
    report = executor.run_suite(suite.root)
    assert order == ["v1", "v7", "v8"]
    assert report["status"] == "incomplete"
    assert report["execution_failure_count"] == report["worker_timeout_count"] == 1
    assert report["decision"]["adopt"] is False
    assert report["worker_failures"][0]["engine"] == "v7"
    with pytest.raises(FileExistsError):
        executor.run_suite(suite.root)


def test_worker_calls_trace_api_once_per_trial_and_never_reanalyzes(suite, monkeypatch):
    from audio_regression import api
    calls = []
    def analyze(reference, processed, *, engine, **config):
        index = len(calls)
        calls.append(engine)
        row = suite.manifest[index]
        result = _result(row, engine)
        return result, _trace(row, engine, result)
    monkeypatch.setattr(api, "analyze_pair_with_trace", analyze)
    monkeypatch.setattr(api, "analyze_pair", lambda *a, **k: pytest.fail("No second analysis is allowed"))
    output = suite.root / "trace-worker.jsonl"
    metadata = executor.worker_run(suite.root / "worker_jobs.json", output, "v8")
    assert calls == ["v8"] * 56
    rows = executor.load_outputs(output, suite.manifest, "v8")
    assert len(rows) == 56 and metadata["execution_error_count"] == 0
    assert all(r["trace"]["method"] == executor.TRACE_METHODS["v8"] for r in rows)


def test_trace_report_separates_new_event_proof_inherited_normal_and_budget_hold(suite):
    _outputs(suite, secondary_hold=True)
    path = suite.root / "outputs/v8.jsonl"
    lines = path.read_text(encoding="utf-8").splitlines()
    normal = json.loads(lines[0])
    nested = normal["trace"]["inherited_v7_trace"]
    nested.update(proof_path="compound_normal_exact_forward", compound_attempted=True, compound_proved=True)
    lines[0] = json.dumps(normal)
    event = json.loads(lines[5])
    event["trace"].update(proof_path="compound_event_exact_forward", compound_event_attempted=True,
                          compound_event_proved=True, event_proof_trace={"search_complete": True, "reason_code": None})
    lines[5] = json.dumps(event)
    held = json.loads(lines[6])
    held["result"] = _result(suite.manifest[6], "v8", held=True)
    held["result"]["reason_code"] = "raw_landmark_unexplained_local_residual"
    held["trace"] = _trace(suite.manifest[6], "v8", held["result"])
    held["trace"].update(compound_event_attempted=True,
                         compound_event_failure="compound_event_proof_budget_exceeded",
                         event_proof_trace={"search_complete": False, "reason_code": "compound_event_proof_budget_exceeded"})
    lines[6] = json.dumps(held)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    report = executor.score_saved(suite.root, suite.manifest)
    diagnostic = report["engines"]["v8"]["trace_diagnostics"]
    assert diagnostic["new_v8_event_proof_count"] == diagnostic["inherited_v7_normal_proof_count"] == 1
    assert diagnostic["withheld_budget_or_depth_count"] == 1
    assert diagnostic["compound_event_failures"] == {"compound_event_proof_budget_exceeded": 1}
    assert diagnostic["top_level_reason_codes"] == {"raw_landmark_unexplained_local_residual": 1}


def test_api_error_envelope_counts_as_execution_error_even_if_worker_did_not_raise(suite):
    _outputs(suite, secondary_hold=True)
    path = suite.root / "outputs/v1.jsonl"
    lines = path.read_text(encoding="utf-8").splitlines()
    item = json.loads(lines[0])
    item["result"] = {"engine": "local_content_alignment_v1", "status": "error", "events": None}
    lines[0] = json.dumps(item)
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    report = executor.score_saved(suite.root, suite.manifest)
    assert report["engines"]["v1"]["execution_error_count"] == 1
    assert report["execution_failure_count"] == 1
    assert report["decision"]["adopt"] is False


@pytest.mark.parametrize("name", ["Original_music0.ogg", " ORIGINAL music0.HQ.OGG ",
                                 "https://commons.wikimedia.org/wiki/File:Original_music0.ogg",
                                 "https://upload.wikimedia.org/test/Original%20music0.ogg"])
def test_identity_spelling_aliases_canonicalize_to_the_same_recording(name):
    assert executor.normalize_identity(name) == "original music0"


def test_even_a_passed_offline_gate_never_activates_a_new_default(suite):
    _outputs(suite, secondary_hold=True)
    decision = executor.score_saved(suite.root, suite.manifest)["decision"]
    assert decision["adopt"] is True
    assert decision["automatic_default_activation"] is False
    assert decision["default_engine_unchanged"] == "v1"


def test_all_method_modules_are_preloaded_before_first_api_timer_without_analysis(suite, monkeypatch):
    import builtins
    from audio_regression import api
    original_import = builtins.__import__
    observed, calls = [], []
    def track_import(name, globals=None, locals=None, fromlist=(), level=0):
        if name == "audio_regression" and set(fromlist) == {"engine", "compound_engine", "compound_event_engine"}:
            observed.append("preloaded_all_three_methods")
        return original_import(name, globals, locals, fromlist, level)
    def clock():
        observed.append("timer")
        return len(observed) / 1000
    def fake_analysis(reference, processed, *, engine, **configuration):
        assert observed.index("preloaded_all_three_methods") < observed.index("timer")
        row = suite.manifest[len(calls)]
        calls.append(engine)
        result = _result(row, engine)
        return result, _trace(row, engine, result)
    monkeypatch.setattr(builtins, "__import__", track_import)
    monkeypatch.setattr(executor.time, "perf_counter", clock)
    monkeypatch.setattr(api, "analyze_pair_with_trace", fake_analysis)
    monkeypatch.setattr(api, "analyze_pair", lambda *a, **k: pytest.fail("No real or repeated engine analysis is allowed"))
    output = suite.root / "import-timing-fake-worker.jsonl"
    metadata = executor.worker_run(suite.root / "worker_jobs.json", output, "v8")
    assert calls == ["v8"] * 56
    assert observed.count("preloaded_all_three_methods") == 1
    assert metadata["execution_error_count"] == 0
    assert metadata["timing_scope"] == "per_trial_API_file_read_analysis_and_contract_excluding_process_startup_and_imports"
