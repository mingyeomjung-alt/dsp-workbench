"""Exact DP regression against the frozen 0.1.9 dense implementation.

The independent oracle below is copied from alignment.py with source SHA-256
06fea24265ef6f9f59508b868a1b3b8259866e2cb3f842a1713e30efd9e250e0.
It intentionally keeps the old allocations and arithmetic, not shared helpers.
No natural or sealed evaluation data are read by these tests.
"""

import numpy as np
import pytest

import audio_regression.alignment as alignment
from audio_regression.features import FeatureTrack


def _dense_oracle(reference, processed, maximum_shift_frames):
    x, y = reference.features, processed.features
    n, m = len(x), len(y)
    gap_cost = 0.18
    costs = 1.0 - np.clip(x @ y.T, -1.0, 1.0)
    inactive_x = reference.frame_rms < 1e-5
    inactive_y = processed.frame_rms < 1e-5
    costs[inactive_x[:, None] & inactive_y[None, :]] = 0.0
    costs[inactive_x[:, None] ^ inactive_y[None, :]] = 0.8
    directions = np.full((n + 1, m + 1), 255, dtype=np.uint8)
    columns = np.arange(m + 1)
    previous = columns.astype(np.float64) * gap_cost
    previous[columns > maximum_shift_frames] = np.inf
    directions[0, :min(m, maximum_shift_frames) + 1] = 2
    for i in range(1, n + 1):
        diagonal = previous[:-1] + costs[i - 1]
        vertical = previous[1:] + gap_cost
        base = np.empty(m + 1, dtype=np.float64)
        base[0] = previous[0] + gap_cost
        base[1:] = np.minimum(diagonal, vertical)
        legal = np.abs(columns - i) <= maximum_shift_frames
        base[~legal] = np.inf
        current = np.minimum.accumulate(base - columns * gap_cost) + columns * gap_cost
        current[~legal] = np.inf
        choices = np.empty(m + 1, dtype=np.uint8)
        choices[0] = 1
        choices[1:] = np.where(diagonal <= vertical, 0, 1)
        choices[current < base - 1e-10] = 2
        choices[~np.isfinite(current)] = 255
        directions[i] = choices
        previous = current
    if not np.isfinite(previous[m]):
        return {"status": "withheld", "reason_code": "alignment_outside_search_band"}
    i, j = n, m
    reverse = []
    while i or j:
        direction = int(directions[i, j])
        if direction == 0:
            reverse.append(("match", i - 1, j - 1))
            i -= 1
            j -= 1
        elif direction == 1:
            reverse.append(("delete", i - 1, j))
            i -= 1
        elif direction == 2:
            reverse.append(("insert", i, j - 1))
            j -= 1
        else:
            return {"status": "withheld", "reason_code": "alignment_path_unavailable"}
    operations = list(reversed(reverse))
    runs = []
    for operation, i, j in operations:
        di, dj = (1, 1) if operation == "match" else ((1, 0) if operation == "delete" else (0, 1))
        if runs and runs[-1]["kind"] == operation:
            runs[-1]["reference_end_frame"] = i + di
            runs[-1]["processed_end_frame"] = j + dj
        else:
            runs.append({
                "kind": operation,
                "reference_start_frame": i,
                "reference_end_frame": i + di,
                "processed_start_frame": j,
                "processed_end_frame": j + dj,
            })
    return {
        "status": "aligned", "runs": runs,
        "normalized_path_cost": float(previous[m] / max(n, m)),
        "gap_cost": gap_cost, "maximum_shift_frames": maximum_shift_frames,
    }


def _track(values, rms=None):
    n = len(values)
    return FeatureTrack(
        values, np.arange(n, dtype=np.int64) * 80,
        np.full(n, 0.2) if rms is None else rms, 8000, 80, 320,
    )


@pytest.mark.parametrize("seed", range(30))
def test_random_tracks_preserve_exact_runs_and_cost(seed):
    rng = np.random.default_rng(seed)
    n, m = int(rng.integers(1, 140)), int(rng.integers(1, 140))
    x, y = rng.normal(size=(n, 24)), rng.normal(size=(m, 24))
    x /= np.linalg.norm(x, axis=1, keepdims=True)
    y /= np.linalg.norm(y, axis=1, keepdims=True)
    rms_x = rng.choice([0, 1e-6, 1e-5, 0.2], n)
    rms_y = rng.choice([0, 1e-6, 1e-5, 0.2], m)
    reference, processed = _track(x, rms_x), _track(y, rms_y)
    for band in (0, 1, 3, abs(n - m), max(n, m), max(n, m) + 11):
        assert alignment.edit_align(reference, processed, band) == _dense_oracle(reference, processed, band)


@pytest.mark.parametrize("n,m", [(1, 1), (1, 8), (8, 1), (31, 32), (32, 33), (65, 62)])
@pytest.mark.parametrize("mode", ["silent", "constant", "opposite", "gap_tie"])
def test_silence_and_exact_ties_preserve_dense_choice(n, m, mode):
    x, y = np.zeros((n, 24)), np.zeros((m, 24))
    if mode != "silent":
        x[:, 0], y[:, 0] = 1, -1 if mode == "opposite" else 1
    if mode == "gap_tie":
        # A match cost of 0.36 equals one insertion plus one deletion.
        y[:, 0] = 1 - 2 * 0.18
    rms = 0 if mode == "silent" else 0.2
    reference, processed = _track(x, np.full(n, rms)), _track(y, np.full(m, rms))
    for band in (0, 1, abs(n - m), max(n, m)):
        assert alignment.edit_align(reference, processed, band) == _dense_oracle(reference, processed, band)


@pytest.mark.parametrize("n,m", [(301, 297), (310, 300), (70, 1000), (3001, 2997)])
def test_large_and_odd_dot_product_shapes_remain_bit_exact(n, m):
    rng = np.random.default_rng(814 + n)
    x = rng.normal(size=(max(n, m), 24))
    x /= np.linalg.norm(x, axis=1, keepdims=True)
    rms = rng.choice([0, 1e-6, 1e-5, 0.2], max(n, m))
    reference, processed = _track(x[:n], rms[:n]), _track(x[:m], rms[:m])
    band = abs(n - m) + 2
    assert alignment.edit_align(reference, processed, band) == _dense_oracle(reference, processed, band)


def test_compact_direction_storage_and_in_place_cost_transform(monkeypatch):
    n, m, band = 240, 237, 5
    reference, processed = _track(np.ones((n, 24))), _track(np.ones((m, 24)))
    expected = _dense_oracle(reference, processed, band)
    full, clip, subtract = np.full, np.clip, np.subtract
    allocations, transformations = [], []

    def tracked_full(shape, value, *args, **kwargs):
        result = full(shape, value, *args, **kwargs)
        if result.dtype == np.uint8:
            allocations.append(result.shape)
        return result

    def tracked_clip(values, *args, **kwargs):
        transformations.append(("clip", kwargs.get("out") is values))
        return clip(values, *args, **kwargs)

    def tracked_subtract(first, second, *args, **kwargs):
        transformations.append(("subtract", kwargs.get("out") is second))
        return subtract(first, second, *args, **kwargs)

    monkeypatch.setattr(alignment.np, "full", tracked_full)
    monkeypatch.setattr(alignment.np, "clip", tracked_clip)
    monkeypatch.setattr(alignment.np, "subtract", tracked_subtract)
    assert alignment.edit_align(reference, processed, band) == expected
    assert allocations == [(n + 1, 2 * band + 1)]
    assert transformations == [("clip", True), ("subtract", True)]


def test_outside_band_is_withheld_without_direction_allocation(monkeypatch):
    reference, processed = _track(np.ones((30, 24))), _track(np.ones((40, 24)))
    expected = _dense_oracle(reference, processed, 2)
    full = np.full

    def reject_directions(shape, value, *args, **kwargs):
        if kwargs.get("dtype") == np.uint8:
            pytest.fail("An impossible endpoint must not allocate traceback storage.")
        return full(shape, value, *args, **kwargs)

    monkeypatch.setattr(alignment.np, "full", reject_directions)
    assert alignment.edit_align(reference, processed, 2) == expected


@pytest.mark.parametrize("band", [0.0, 0.5, 3.0, 3.2, np.float64(3.2), -1, -0.5,
                                  8.0, np.float64(8.5), np.inf, np.nan])
def test_direct_numeric_radius_keeps_old_result_or_exception_type(band):
    for n, m in ((8, 8), (5, 3), (3, 5)):
        reference, processed = _track(np.ones((n, 24))), _track(np.ones((m, 24)))
        try:
            expected = _dense_oracle(reference, processed, band)
        except Exception as error:
            with pytest.raises(type(error)):
                alignment.edit_align(reference, processed, band)
        else:
            assert alignment.edit_align(reference, processed, band) == expected
