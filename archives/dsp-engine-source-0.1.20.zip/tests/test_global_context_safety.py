"""Safety-only checks of the opt-in exhaustive global-context certificate.

All waveforms below are fresh analytic development signals. No recorded,
sealed, downloaded, or older example audio is loaded. Injected solver failures
are unit policy checks, not evidence of independent detection performance.
"""

from __future__ import annotations

from functools import lru_cache
import importlib
import json

import numpy as np
import pytest
from scipy.signal import resample_poly

from audio_regression.compound_gain import _pcm, _render, quantization_bound


Q = 1 / 32768
GAIN = .538711
START = 1952 * 8
LENGTH = 400 * 8
LEAD = 137


@lru_cache(maxsize=None)
def _fresh_source():
    """Previously unused incommensurate chirps; exactly PCM16 on creation."""
    time = np.arange(85440, dtype=float) / 16000
    phase = 2 * np.pi * (181 * time + 37.9 * time ** 2 + .009 * time ** 4
                        + .17 * np.sin(4.13 * time))
    modulation = .72 + .16 * np.cos(3.31 * time) + .09 * np.sin(7.17 * time)
    values = .155 * modulation * (np.sin(phase)
        + .31 * np.sin(1.491 * phase + .61)
        + .19 * np.cos(2.713 * phase - .93))
    return _pcm(values)


def _edit(source, kind, point=START, length=LENGTH):
    start, count = 2 * point, 2 * length
    if kind == "delete":
        return np.concatenate((source[:start], source[start + count:]))
    if kind == "repeat":
        return np.concatenate((source[:start], source[start - count:start], source[start:]))
    raise ValueError(kind)


def _pair(kind="delete", *, source=None, point=START, length=LENGTH,
          gain=GAIN, lead=LEAD):
    original = _fresh_source().copy() if source is None else _pcm(source)
    changed = _edit(original, kind, point, length)
    rendered = _render(changed, gain)
    assert rendered is not None
    return original, np.concatenate((np.zeros(lead), rendered))


@pytest.fixture
def proof_module():
    return importlib.import_module("audio_regression.global_context_proof")


def _checked(module, source, target, max_delay=2400):
    originals = source.copy(), target.copy()
    proof, trace = module.prove_event(source, target, max_delay)
    np.testing.assert_array_equal(source, originals[0])
    np.testing.assert_array_equal(target, originals[1])
    json.dumps(trace, allow_nan=False)
    if proof is not None:
        assert trace["search_complete"] is True
        assert trace["every_supported_geometry_checked"] is True
        actual = _render(_edit(source, proof["kind"], proof["point"], proof["length"]), proof["gain"])
        assert actual is not None
        np.testing.assert_array_equal(actual, target[proof["delay"]:])
        assert not np.any(target[:proof["delay"]])
    return proof, trace


@pytest.mark.parametrize("kind", ("delete", "repeat"))
@pytest.mark.parametrize("lead", (17, 137))
def test_non_ms_delay_is_not_rounded_out_of_exhaustive_geometry(proof_module, kind, lead):
    source, target = _pair(kind, lead=lead)
    proof, trace = _checked(proof_module, source, target)
    assert proof is not None, trace
    assert proof["delay"] == lead
    assert proof["length"] == LENGTH
    assert proof["kind"] == kind
    assert abs(proof["point"] - START) <= 160


@pytest.mark.parametrize("kind", ("delete", "repeat"))
def test_source_leading_zeros_are_not_assumed_to_be_added_delay(proof_module, kind):
    source = _fresh_source().copy()
    source[:120 * 16] = 0
    source, target = _pair(kind, source=source)
    assert np.flatnonzero(target)[0] > LEAD + 800
    proof, trace = _checked(proof_module, source, target)
    assert proof is not None, trace
    assert proof["delay"] == LEAD
    assert trace["delay_hypotheses_checked"] > 1


def test_delete_of_loudest_peak_does_not_inherit_original_peak_gain_cap(proof_module):
    source = _fresh_source().copy()
    source[2 * START:2 * (START + LENGTH)] *= 4
    source = _pcm(source)
    gain = 2.11317
    assert np.max(np.abs(gain * source)) > 1
    assert np.max(np.abs(gain * _edit(source, "delete"))) < 1
    source, target = _pair("delete", source=source, gain=gain)
    proof, trace = _checked(proof_module, source, target)
    assert proof is not None, trace
    assert proof["kind"] == "delete"
    assert proof["gain"] > 2


@pytest.mark.parametrize("kind,edge", (("delete", "first"), ("delete", "last"), ("repeat", "last")))
def test_file_edge_event_cannot_be_relabelled_as_identifiable_internal_event(proof_module, kind, edge):
    source = _fresh_source()
    count = len(source) // 2
    point = (0 if kind == "delete" else LENGTH) if edge == "first" else (
        count - LENGTH if kind == "delete" else count)
    source, target = _pair(kind, point=point)
    proof, trace = _checked(proof_module, source, target)
    assert proof is None, trace


def test_canonical_later_copy_of_first_source_span_is_not_endpoint_insertion(proof_module):
    # The source span starts at file zero, but the later added copy starts at
    # divider L. The preceding original span is real retained context, so this
    # is not the unsupported case of an insertion at file position zero.
    source, target = _pair("repeat", point=LENGTH)
    proof, trace = _checked(proof_module, source, target)
    assert proof is not None, trace
    assert proof["point"] == LENGTH
    assert proof["kind"] == "repeat"


@pytest.mark.parametrize("kind", ("delete", "repeat"))
def test_long_silent_source_interval_cannot_receive_localized_event_certificate(proof_module, kind):
    source = _fresh_source().copy()
    source[1400 * 16:3200 * 16] = 0
    source, target = _pair(kind, source=source)
    proof, trace = _checked(proof_module, source, target)
    assert proof is None, trace


@pytest.mark.parametrize("kind", ("delete", "repeat"))
def test_periodic_signal_cannot_identify_unique_internal_event(proof_module, kind):
    time = np.arange(85440, dtype=float) / 16000
    source, target = _pair(kind, source=.17 * np.sin(2 * np.pi * 500 * time))
    proof, trace = _checked(proof_module, source, target)
    assert proof is None, trace


def test_distant_identical_copy_source_remains_disallowed(proof_module):
    source = _fresh_source().copy()
    copied = source[2 * (START - LENGTH):2 * START].copy()
    source[3700 * 16:4100 * 16] = copied
    source, target = _pair("repeat", source=source)
    proof, trace = _checked(proof_module, source, target)
    assert proof is None, trace


@pytest.mark.parametrize("where", ("leading_prefix", "first_sample", "retained_mid", "quiet_tail", "last_sample"))
def test_one_pcm_lsb_anywhere_is_not_hidden_by_sparse_pruning(proof_module, where):
    source = _fresh_source().copy()
    source[4600 * 16:] = 4 * Q * np.sin(np.arange(len(source) - 4600 * 16) * .27)
    source, target = _pair("repeat", source=source)
    changed = target.copy()
    index = {"leading_prefix": 31, "first_sample": LEAD,
        "retained_mid": LEAD + 6001, "quiet_tail": LEAD + 41000,
        "last_sample": len(target) - 1}[where]
    changed[index] += Q
    assert not np.array_equal(changed, target)
    proof, trace = _checked(proof_module, source, changed)
    assert proof is None, trace


@pytest.mark.parametrize("mutation", ("unrelated", "reversed", "different_gain", "silent"))
def test_noncopy_insert_payload_cannot_get_same_gain_complete_copy_certificate(proof_module, mutation):
    source = _fresh_source().copy()
    payload = source[2 * (START - LENGTH):2 * START].copy()
    if mutation == "unrelated":
        payload = _pcm(.11 * np.random.default_rng(593144).uniform(-1, 1, len(payload)))
    elif mutation == "reversed":
        payload = payload[::-1]
    elif mutation == "different_gain":
        payload = _pcm(.7 * payload)
    else:
        payload[:] = 0
    edited = np.concatenate((source[:2 * START], payload, source[2 * START:]))
    actual = _render(edited, GAIN)
    assert actual is not None
    target = np.concatenate((np.zeros(LEAD), actual))
    proof, trace = _checked(proof_module, source, target)
    assert proof is None, trace


@pytest.mark.parametrize("change", ("gain_after_src", "other_fir", "negative_gain"))
def test_unsupported_forward_model_is_not_certified(proof_module, change):
    source = _fresh_source().copy()
    edited = _edit(source, "delete")
    if change == "gain_after_src":
        output = _pcm(GAIN * _pcm(resample_poly(edited, 1, 2)))
    elif change == "other_fir":
        output = _pcm(resample_poly(_pcm(GAIN * edited), 1, 2, window=("kaiser", 8.7)))
    else:
        output = _pcm(resample_poly(_pcm(-GAIN * edited), 1, 2))
    target = np.concatenate((np.zeros(LEAD), output))
    assert not np.array_equal(target, _pair()[1])
    proof, trace = _checked(proof_module, source, target)
    assert proof is None, trace


@pytest.mark.parametrize("budget", ("MAX_DELAY_HYPOTHESES", "MAX_GEOMETRY_TESTS", "MAX_GAIN_NODES", "MAX_EXACT_CANDIDATES"))
def test_zero_search_budget_cannot_return_partial_witness(proof_module, monkeypatch, budget):
    monkeypatch.setattr(proof_module, budget, 0)
    source, target = _pair()
    proof, trace = _checked(proof_module, source, target)
    assert proof is None
    assert trace["search_complete"] is False


def test_incomplete_gain_search_blocks_geometry_certificate(proof_module, monkeypatch):
    source, target = _pair()
    calls = []

    def incomplete(samples, observed):
        calls.append(len(samples))
        return {"gain": GAIN, "rendered": observed.copy()}, {
            "nodes_visited": 1, "search_complete": False,
            "reason_code": "unit_incomplete_gain_search"}

    monkeypatch.setattr(proof_module, "solve_gain", incomplete)
    proof, trace = _checked(proof_module, source, target)
    assert calls
    assert proof is None
    assert trace["search_complete"] is False
    assert "incomplete" in trace["reason_code"]


def test_an_earlier_exact_geometry_does_not_hide_later_incomplete_search(proof_module, monkeypatch):
    # Make two adjacent 1 ms deletion boundaries observationally equivalent.
    # Such a narrow cluster is within the supported position convention, but
    # every surviving geometry must still be solved before it can be reported.
    source = _fresh_source().copy()
    source[2 * (START + LENGTH):2 * (START + LENGTH) + 16] = source[2 * START:2 * START + 16]
    assert np.array_equal(_edit(source, "delete", START), _edit(source, "delete", START + 8))
    source, target = _pair(source=source)
    exact_calls = []

    def first_witness_then_incomplete(samples, observed):
        rendered = _render(samples, GAIN)
        if rendered is None or not np.array_equal(rendered, observed):
            return None, {"nodes_visited": 1, "search_complete": True}
        exact_calls.append(len(exact_calls))
        return {"gain": GAIN, "rendered": rendered}, {
            "nodes_visited": 1, "search_complete": len(exact_calls) == 1,
            "reason_code": "unit_later_exact_geometry_incomplete"}

    monkeypatch.setattr(proof_module, "solve_gain", first_witness_then_incomplete)
    proof, trace = _checked(proof_module, source, target)
    assert len(exact_calls) == 2
    assert trace["feasible_candidate_count"] == 1
    assert proof is None
    assert trace["search_complete"] is False
    assert trace["every_supported_geometry_checked"] is False


@pytest.mark.parametrize("failure", ("not_dict", "not_array", "wrong_sample", "wrong_length", "nan_gain", "wrong_gain"))
def test_untrusted_solver_witness_requires_independent_all_output_render(proof_module, monkeypatch, failure):
    source, target = _pair()

    def malformed(samples, observed):
        rendered = observed.copy()
        gain = GAIN
        if failure == "not_array":
            rendered = rendered.tolist()
        elif failure == "wrong_sample":
            rendered[10] += Q
        elif failure == "wrong_length":
            rendered = rendered[:-1]
        elif failure == "nan_gain":
            gain = float("nan")
        elif failure == "wrong_gain":
            gain = .731993
        witness = {"gain": gain, "rendered": rendered}
        if failure == "not_dict":
            witness = [witness]
        return witness, {
            "nodes_visited": 1, "search_complete": True}

    monkeypatch.setattr(proof_module, "solve_gain", malformed)
    proof, trace = _checked(proof_module, source, target)
    assert proof is None
    assert trace["search_complete"] is False


@pytest.mark.parametrize("gain", (.113971, .538711, 2.11317))
def test_outward_necessary_sample_intervals_retain_actual_supported_gain(proof_module, gain):
    source = _fresh_source().copy()
    source[0:91] = 0
    source[4600 * 16:] = _pcm(3 * Q * np.sin(np.arange(len(source) - 4600 * 16) * .31))
    target = _render(source, gain)
    assert target is not None
    reference = resample_poly(source, 1, 2)
    lower, upper = proof_module._sample_intervals(reference, target)
    assert np.all(lower <= gain)
    assert np.all(upper >= gain)
    # Necessary bounds are not a certificate: a changed low-information sample
    # can stay inside this envelope, while exact rendering must still reject it.
    changed = target.copy()
    changed[-51] += Q
    assert not np.array_equal(changed, target)


@pytest.mark.parametrize("sign", (-1, 1))
def test_exact_zero_reference_observation_above_fixed_envelope_has_no_gain(proof_module, sign):
    bound = quantization_bound()
    outside = np.ceil((bound + Q) / Q) * Q
    inside = np.floor(bound / Q) * Q
    reference = np.array([0.0, -0.0, 0.0])
    observed = np.array([0.0, sign * inside, sign * outside])
    lower, upper = proof_module._sample_intervals(reference, observed)
    assert lower[0] <= 1 <= upper[0]
    assert lower[1] <= 1 <= upper[1]
    assert lower[2] > upper[2]


@pytest.mark.parametrize("sign", (-1, 1))
def test_tiny_nonzero_interval_math_cannot_exclude_a_valid_finite_gain(proof_module, sign):
    # Unit numerical edge: these values need not be actual source PCM. A tiny
    # filtered reference with zero quantized output has no usable gain evidence.
    # Division overflow must not fabricate a pruning contradiction or NaN.
    reference = sign * np.array([np.nextafter(0.0, 1.0), np.finfo(float).tiny, Q / 32])
    observed = np.zeros(3)
    lower, upper = proof_module._sample_intervals(reference, observed)
    assert not np.any(np.isnan(lower))
    assert not np.any(np.isnan(upper))
    assert np.all(lower <= 1)
    assert np.all(upper >= 1)


@pytest.mark.parametrize("change", ("odd_source", "nan_source", "non_pcm_target", "negative_delay_limit"))
def test_invalid_supported_inputs_stop_without_positive_certificate(proof_module, change):
    source, target = _pair()
    maximum = 2400
    if change == "odd_source":
        source = source[:-1]
    elif change == "nan_source":
        source[5] = np.nan
    elif change == "non_pcm_target":
        target[200] += .13 * Q
    else:
        maximum = -1
    proof, trace = _checked(proof_module, source, target, maximum)
    assert proof is None, trace

