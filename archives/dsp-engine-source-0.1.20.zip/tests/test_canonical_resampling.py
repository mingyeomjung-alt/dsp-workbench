"""Owned-only regressions for exact canonical PCM resampling fallback.

These analytic samples are newly synthesized in this file. No sealed or
natural-audio evaluation input is loaded. Unit fault injections below are
explicitly labeled and are not natural-audio performance evidence.
"""

from __future__ import annotations

from copy import deepcopy
from functools import lru_cache
import json

import numpy as np
import pytest
from scipy.signal import resample_poly

import audio_regression.canonical_engine as candidate
from audio_regression import instrument_engine
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.engine import EngineConfig, EngineConfigError, _corr
from audio_regression.profiles import prepare_analysis


ENGINE = "local_content_alignment_v5"
METHOD = "exact_canonical_pcm_resampling_with_unique_context"
Q = 1 / 32768


def _audio(values, rate):
    return decode_wav(encode_wav(values, rate))


def _analytic_music(rate=16000, *, quiet_tail=True):
    """Variable musical partials followed by a newly specified quiet chirp."""
    time = np.arange(6 * rate) / rate
    phase = 2 * np.pi * (390 * time + 8 * time * time + 4 * np.sin(1.7 * time))
    loud = .15 * (np.sin(phase) + .22 * np.sin(1.503 * phase) + .13 * np.sin(2.13 * phase))
    if not quiet_tail:
        return loud
    quiet = .55 * Q * np.sin(2 * np.pi * (2900 * time + 3 * time * time))
    return np.where(time < 4.2, loud, quiet)


@lru_cache(maxsize=None)
def _owned_pair(rate=16000):
    reference = _audio(_analytic_music(rate), rate)
    # This is the exact canonical declared transform, computed from decoded
    # source PCM rather than from a hidden higher-precision original.
    processed = _audio(prepare_analysis(reference), 8000)
    return reference, processed


@lru_cache(maxsize=None)
def _owned_v4_failure():
    reference, processed = _owned_pair()
    return instrument_engine.analyze_buffers_with_trace(
        reference, processed, EngineConfig(allow_resampling=True)
    )


def _force_eligible_baseline(monkeypatch, *, reason="raw_landmark_unexplained_local_residual"):
    """Unit injection only: isolate candidate eligibility and safety gates."""
    result, trace = _owned_v4_failure()
    result, trace = deepcopy(result), deepcopy(trace)
    result.update(status="withheld", content_preservation_status="withheld",
                  reason_code=reason, events=None)
    result.pop("alignment_segments", None)
    trace.update(result_status="withheld", reason_code=reason)
    monkeypatch.setattr(candidate.instrument_engine, "analyze_buffers_with_trace",
                        lambda *args, **kwargs: (deepcopy(result), deepcopy(trace)))


def _checked(reference, processed, config=None):
    before_a, before_b = reference.samples.copy(), processed.samples.copy()
    result, trace = candidate.analyze_buffers_with_trace(reference, processed, config)
    assert result["engine"] == ENGINE
    assert result["analysis"]["method"] == METHOD
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    np.testing.assert_array_equal(reference.samples, before_a)
    np.testing.assert_array_equal(processed.samples, before_b)
    json.dumps(result, allow_nan=False)
    json.dumps(trace, allow_nan=False)
    return result, trace


def test_owned_exact_resample_reproduces_v4_false_rejection_without_injection():
    reference, processed = _owned_pair()
    a, b = prepare_analysis(reference), prepare_analysis(processed)
    low_a, low_b = a[36000:36960], b[36000:36960]
    assert _corr(low_a, low_b) < .90
    assert np.max(np.abs(b - a)) <= Q / 2
    baseline, trace = _owned_v4_failure()
    assert baseline["status"] == "withheld"
    assert baseline["reason_code"] == "raw_landmark_unexplained_local_residual"
    assert trace["landmarks_accepted"] >= 3
    assert len(trace["offset_groups"]) == 1
    assert trace["offset_groups"][0]["offset_samples"] == 0


def test_exact_declared_resample_is_proved_not_threshold_relaxed():
    reference, processed = _owned_pair()
    result, trace = _checked(reference, processed, EngineConfig(allow_resampling=True))
    assert result["status"] == "analyzed", (result, trace)
    assert result["reason_code"] is None
    assert result["events"] == []
    assert trace["proof_path"] == "canonical_resampling_exact_pcm"
    assert trace["low_information_block_count"] > 0
    assert trace["raw_minimum_local_correlation"] < .90
    assert result["diagnostics"]["minimum_local_correlation"] >= .90
    assert result["diagnostics"]["matched_normalized_rmse"] <= .08
    assert len(result["alignment_segments"]) == 1
    assert result["alignment_segments"][0]["processed_offset_ms"] == 0


@pytest.mark.parametrize("rate", (44100, 48000))
def test_canonical_output_quantization_bound_does_not_depend_on_rate_guess(rate):
    reference, processed = _owned_pair(rate)
    result, trace = _checked(reference, processed, EngineConfig(allow_resampling=True))
    assert result["status"] == "analyzed", (result, trace)
    assert result["events"] == []


@pytest.mark.parametrize("mutation", (
    "one_pcm_quantum", "zero_quiet_tail", "reversed_quiet_tail",
    "quiet_spike", "loud_short_dropout", "high_noise",
))
def test_exact_proof_cannot_clear_equal_length_content_mutations(mutation):
    reference, processed = _owned_pair()
    values = processed.samples.copy()
    if mutation == "one_pcm_quantum":
        values[40000] += Q
    elif mutation == "zero_quiet_tail":
        assert np.count_nonzero(values[35000:]) > 0
        values[35000:] = 0
    elif mutation == "reversed_quiet_tail":
        values[35000:] = values[35000:][::-1]
    elif mutation == "quiet_spike":
        values[40000] += 10 * Q
    elif mutation == "loud_short_dropout":
        values[24000:24160] = 0  # Twenty ms: never a supported edit repair.
    else:
        rng = np.random.default_rng(931024)
        values += .015 * rng.uniform(-1, 1, len(values))
    changed = _audio(values, 8000)
    result, trace = _checked(reference, changed, EngineConfig(allow_resampling=True))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None


@pytest.mark.parametrize("kind", ("delete", "repeat"))
def test_length_changing_edits_are_never_rescued_as_empty_event_results(kind):
    reference, _ = _owned_pair()
    first, last = 2300 * 16, 2700 * 16
    if kind == "delete":
        values = np.concatenate((reference.samples[:first], reference.samples[last:]))
    else:
        values = np.concatenate((reference.samples[:last], reference.samples[first:last],
                                 reference.samples[last:]))
    changed = _audio(resample_poly(values, 1, 2), 8000)
    config = EngineConfig(allow_resampling=True)
    baseline, _ = instrument_engine.analyze_buffers_with_trace(reference, changed, config)
    result, trace = _checked(reference, changed, config)
    assert result["status"] == baseline["status"], (result, trace)
    assert result["events"] == baseline["events"]
    assert trace["proof_path"] != "canonical_resampling_exact_pcm"


def test_allowed_gain_does_not_authorize_unproven_quantization_chain():
    reference, processed = _owned_pair()
    result, trace = _checked(reference, processed,
                             EngineConfig(allow_resampling=True, allow_gain=True))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None
    assert trace["proof_path"] != "canonical_resampling_exact_pcm"


def test_undeclared_resampling_keeps_existing_policy_withheld():
    reference, processed = _owned_pair()
    result, trace = _checked(reference, processed)
    assert result["status"] == "withheld", (result, trace)
    assert result["reason_code"] == "resampling_not_declared"
    assert result["events"] is None


@pytest.mark.parametrize("mode", ("same_rate_8k", "processed_16k"))
def test_injected_eligible_failure_still_obeys_supported_rate_direction(monkeypatch, mode):
    _force_eligible_baseline(monkeypatch)
    original, _ = _owned_pair()
    if mode == "same_rate_8k":
        reference = processed = _audio(prepare_analysis(original), 8000)
    else:
        reference = processed = original
    result, trace = _checked(reference, processed, EngineConfig(allow_resampling=True))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None


@pytest.mark.parametrize("offsets", ((0, 0), (8, 8, 8), (0, 0, 1600, 1600, 1600)))
def test_injected_exact_samples_do_not_bypass_unique_zero_offset_context(monkeypatch, offsets):
    _force_eligible_baseline(monkeypatch)
    reference, processed = _owned_pair()
    points = [{"reference_start": 640 * (index + 1), "width": 1920,
               "offset": offset, "correlation": 1., "rival_margin": .4}
              for index, offset in enumerate(offsets)]
    monkeypatch.setattr(candidate.instrument_engine, "_landmarks", lambda *args: (points, len(points)))
    result, trace = _checked(reference, processed, EngineConfig(allow_resampling=True))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None


@pytest.mark.parametrize("reason", (
    "raw_landmark_ambiguous_event_boundary", "insertion_not_supported_as_repetition",
    "raw_landmark_insufficient_unique_anchors", "event_outside_supported_duration",
))
def test_injected_ambiguity_and_policy_reasons_are_not_fallback_eligible(monkeypatch, reason):
    _force_eligible_baseline(monkeypatch, reason=reason)
    monkeypatch.setattr(candidate.instrument_engine, "_landmarks",
                        lambda *args: pytest.fail("Ineligible failures must not run new context proof."))
    reference, processed = _owned_pair()
    result, trace = _checked(reference, processed, EngineConfig(allow_resampling=True))
    assert result["status"] == "withheld", (result, trace)
    assert result["reason_code"] == reason
    assert result["events"] is None


def test_injected_periodic_exact_transform_cannot_earn_unique_context(monkeypatch):
    _force_eligible_baseline(monkeypatch)
    time = np.arange(6 * 16000) / 16000
    reference = _audio(.15 * np.sin(2 * np.pi * 400 * time), 16000)
    processed = _audio(prepare_analysis(reference), 8000)
    result, trace = _checked(reference, processed, EngineConfig(allow_resampling=True))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None


def test_long_periodic_repetition_stays_withheld_without_injection():
    rate = 16000
    time = np.arange(6 * rate) / rate
    reference = _audio(.15 * np.sin(2 * np.pi * 400 * time), rate)
    first, last = 2 * rate, int(3.5 * rate)
    repeated = np.concatenate((reference.samples[:last], reference.samples[first:last],
                                reference.samples[last:]))
    processed = _audio(resample_poly(repeated, 1, 2), 8000)
    result, trace = _checked(reference, processed, EngineConfig(allow_resampling=True))
    assert result["status"] == "withheld", (result, trace)
    assert result["events"] is None


def test_v4_success_is_preserved_without_claiming_new_resampling_proof():
    reference = _audio(_analytic_music(16000, quiet_tail=False), 16000)
    baseline, _ = instrument_engine.analyze_buffers_with_trace(reference, reference)
    assert baseline["status"] == "analyzed"
    result, trace = _checked(reference, reference)
    for key in ("status", "reason_code", "events", "diagnostics", "alignment_segments",
                "configuration", "content_preservation_status"):
        if key in baseline:
            assert result[key] == baseline[key]
    assert trace["proof_path"] != "canonical_resampling_exact_pcm"


def test_non_basic_profile_is_not_silently_reinterpreted():
    reference, processed = _owned_pair()
    with pytest.raises(EngineConfigError):
        candidate.analyze_buffers_with_trace(reference, processed,
                                              EngineConfig(profile="telephone", allow_resampling=True))
