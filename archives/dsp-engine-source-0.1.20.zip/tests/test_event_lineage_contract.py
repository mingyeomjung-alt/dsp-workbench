"""Stored lineage contract checks, not detector-accuracy measurements."""

import copy
import hashlib
import json
from pathlib import Path

import pytest

from audio_regression.check_policy import check_result
from audio_regression.event_lineage import LineageError, build_event_lineage
from audio_regression.event_lineage_contract import (
    MAX_LINEAGE_RESULT_BYTES, MAX_PIPELINE_SOURCE_BYTES,
    load_lineage_result, load_pipeline_for_lineage, validate_lineage_result,
    write_lineage_result,
)
from test_pipeline_reporting import analysis as recorded_analysis, fixture as native_fixture
from test_saved_pipeline_contract import saved_fixture


@pytest.mark.parametrize("factory", [native_fixture, saved_fixture])
@pytest.mark.parametrize("kind", ["clean", "delete", "withheld"])
def test_recomputed_contract_returns_original_without_mutation(factory, kind):
    source = factory(kind)
    before = copy.deepcopy(source)
    result = build_event_lineage(source)
    stored = copy.deepcopy(result)
    assert validate_lineage_result(result) is result
    assert source == before
    assert result == stored
    canonical = json.dumps(source, sort_keys=True, separators=(",", ":"),
                           ensure_ascii=False, allow_nan=False).encode("utf-8")
    assert result["source_result_sha256"] == hashlib.sha256(canonical).hexdigest()
    assert result["projection"]["original_summary"] == source["summary"]


@pytest.mark.parametrize("claim", [
    "artifact_authenticity_verified", "fault_provenance_confirmed", "caller_order_verified",
    "complete_audio_approval", "commercial_performance_validated", "network_used",
])
def test_forbidden_claims_never_validate(claim):
    result = build_event_lineage(native_fixture("delete"))
    result[claim] = True
    with pytest.raises(LineageError):
        validate_lineage_result(result)


@pytest.mark.parametrize("value", [None, [], "private content", 1, True, {}, {"source_result": None}])
def test_invalid_envelopes_reject_without_private_error_echo(value):
    with pytest.raises(LineageError) as caught:
        validate_lineage_result(value)
    assert "private content" not in str(caught.value)


def _replace(path, replacement):
    def mutation(result):
        current = result
        for part in path[:-1]:
            current = current[part]
        current[path[-1]] = replacement
    return mutation


@pytest.mark.parametrize("mutation", [
    _replace(["schema_version"], True),
    _replace(["schema_version"], 1.0),
    _replace(["engine"], "audio_pipeline_event_lineage_v2"),
    _replace(["status"], "analyzed"),
    _replace(["coordinate_projection_only"], 1),
    _replace(["source_result_sha256"], "0" * 64),
    _replace(["projection", "stage_count"], 1),
    _replace(["projection", "event_scope"], "root_cause_confirmed"),
    _replace(["projection", "input_integrity"], "failure_recorded"),
    _replace(["projection", "source", "sha256"], "f" * 64),
    _replace(["projection", "final"], None),
    _replace(["projection", "original_summary", "exit_code"], 0),
    _replace(["projection", "end_to_end_event_count_not_attributed"], 0),
    _replace(["projection", "events", 0, "stage_index"], 2),
    _replace(["projection", "events", 0, "event_index"], 1),
    _replace(["projection", "events", 0, "type"], "repeat"),
    _replace(["projection", "events", 0, "reference_query", "interval_ms"], [0, 400]),
    _replace(["projection", "events", 0, "processed_query", "time_ms"], 1999),
    _replace(["projection", "events", 0, "source_projection", "fragments"], []),
    _replace(["projection", "summary", "observed_event_count"], 0),
    _replace(["projection", "summary", "observed_event_count"], True),
    _replace(["projection", "summary", "observed_event_count"], 1.0),
    lambda result: result.update(untrusted_extra=True),
    lambda result: result["projection"]["events"].clear(),
    lambda result: result["source_result"]["stages"][0].update(runtime_ms=99.0),
])
def test_recomputation_rejects_projection_binding_and_type_tampering(mutation):
    result = build_event_lineage(native_fixture("delete"))
    mutation(result)
    with pytest.raises(LineageError):
        validate_lineage_result(result)


def test_validation_opens_no_audio_artifact_or_other_files(monkeypatch):
    result = build_event_lineage(saved_fixture("delete"))
    def forbidden(*_args, **_kwargs):
        raise AssertionError("The inert contract opened a file.")
    monkeypatch.setattr(Path, "open", forbidden)
    assert validate_lineage_result(result) is result


def test_unavailable_end_to_end_count_is_not_fabricated_zero():
    source = native_fixture("withheld")
    end = source["end_to_end"]
    end["analysis"] = recorded_analysis(source["source"], source["stages"][-1]["output"], "withheld")
    end["status"] = "withheld"
    end["check"] = check_result(end["analysis"])
    result = build_event_lineage(source)
    assert result["projection"]["end_to_end_event_count_not_attributed"] is None
    result["projection"]["end_to_end_event_count_not_attributed"] = 0
    with pytest.raises(LineageError):
        validate_lineage_result(result)


def test_multiple_fragment_claim_cannot_hide_correspondence_ambiguity():
    result = build_event_lineage(native_fixture("delete"))
    side = result["projection"]["events"][0]["source_projection"]
    side["fragments"].append(copy.deepcopy(side["fragments"][0]))
    with pytest.raises(LineageError):
        validate_lineage_result(result)


def test_binding_is_not_a_signature_or_authenticity_certificate():
    source = native_fixture("delete")
    first = build_event_lineage(source)
    source["stages"][0]["runtime_ms"] = 99.0
    # Anyone who can supply an otherwise valid saved result can rebuild this
    # public deterministic binding. A valid binding does not authenticate it.
    second = build_event_lineage(source)
    assert first["source_result_sha256"] != second["source_result_sha256"]
    assert validate_lineage_result(second) is second
    assert second["artifact_authenticity_verified"] is False
    assert second["fault_provenance_confirmed"] is False


@pytest.mark.parametrize("factory", [native_fixture, saved_fixture])
def test_roundtrip_loaders_and_exclusive_writer(tmp_path, factory):
    source = factory("delete")
    source_path = tmp_path / "source.json"
    source_path.write_text(json.dumps(source, ensure_ascii=False), encoding="utf-8")
    assert load_pipeline_for_lineage(source_path) == source
    result = build_event_lineage(source)
    target = tmp_path / "lineage.json"
    assert write_lineage_result(result, target) == target
    assert load_lineage_result(target) == result
    before = target.read_bytes()
    with pytest.raises(FileExistsError):
        write_lineage_result(result, target)
    assert target.read_bytes() == before


@pytest.mark.parametrize("raw,code", [
    (b'{"source_result":{},"source_result":{}}', "duplicate_json_key"),
    (b'{"source_result":NaN}', "non_finite_metric"),
    (b'{"source_result":Infinity}', "non_finite_metric"),
    (b'{"source_result":-Infinity}', "non_finite_metric"),
    (b'\xff', "invalid_lineage_json"),
    (b'{', "invalid_lineage_json"),
])
@pytest.mark.parametrize("loader", [load_lineage_result, load_pipeline_for_lineage])
def test_strict_loaders_reject_duplicate_nonfinite_and_invalid_utf8(tmp_path, raw, code, loader):
    path = tmp_path / "input.json"
    path.write_bytes(raw)
    with pytest.raises(LineageError) as caught:
        loader(path)
    assert caught.value.code == code


@pytest.mark.parametrize("loader,limit", [
    (load_lineage_result, MAX_LINEAGE_RESULT_BYTES),
    (load_pipeline_for_lineage, MAX_PIPELINE_SOURCE_BYTES),
])
def test_loaders_are_bounded(tmp_path, loader, limit):
    path = tmp_path / "large.json"
    path.write_bytes(b" " * (limit + 1))
    with pytest.raises(LineageError) as caught:
        loader(path)
    assert caught.value.code == "lineage_file_too_large"


def test_missing_file_error_never_discloses_path(tmp_path):
    private_path = tmp_path / "private-user-directory" / "secret-record.json"
    with pytest.raises(LineageError) as caught:
        load_lineage_result(private_path)
    assert caught.value.code == "lineage_file_read_error"
    assert "secret-record" not in str(caught.value)
    assert "private-user" not in str(caught.value)


def test_invalid_result_writer_does_not_create_file(tmp_path):
    target = tmp_path / "must-not-exist.json"
    result = build_event_lineage(native_fixture("delete"))
    result["projection"]["summary"]["observed_event_count"] = 999
    with pytest.raises(LineageError):
        write_lineage_result(result, target)
    assert not target.exists()


def test_schema_is_self_contained_and_new_envelope_is_closed():
    schema_path = Path(__file__).parents[1] / "src/audio_regression/schemas/pipeline-event-lineage-v1.schema.json"
    schema = json.loads(schema_path.read_text(encoding="utf-8"))
    assert schema["additionalProperties"] is False
    assert schema["properties"]["engine"] == {"const": "audio_pipeline_event_lineage_v1"}
    assert "Python" in schema["description"]
    assert "rebuild" in schema["description"]
    def visit(value):
        if type(value) is dict:
            if "$ref" in value:
                assert value["$ref"].startswith("#/$defs/")
            for item in value.values():
                visit(item)
        elif type(value) is list:
            for item in value:
                visit(item)
    visit(schema)
