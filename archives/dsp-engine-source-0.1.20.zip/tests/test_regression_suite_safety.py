"""Independent suite safety probes; owned inputs, not performance evidence."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path
import struct

import numpy as np
import pytest

from audio_regression.audio import encode_wav
from audio_regression.regression_suite_contract import (
    SuiteError, canonical_manifest_sha256, load_suite_manifest, normalize_suite_manifest,
)


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _inputs(root):
    """Small owned case; independent of demonstration files or old evidence."""
    root.mkdir()
    samples = np.random.default_rng(202610157899).integers(-7000, 7001, 4 * 8000) / 32768
    payload = encode_wav(samples, 8000)
    for role in ("source", "baseline", "candidate"):
        (root / (role + ".wav")).write_bytes(payload)
    manifest = {"schema_version": 1, "suite_id": "safety",
        "baseline_version": "baseline-A", "candidate_version": "candidate-B",
        "cases": [{"case_id": "one", **{role: {"path": role + ".wav", "sha256": _sha(payload)}
                    for role in ("source", "baseline", "candidate")},
                    "configuration": {"engine": "v11", "allow_gain": False, "allow_resampling": False,
                                      "max_delay_ms": 1000.0, "resampling_model": None}}]}
    path = root / "suite.json"
    _write(path, manifest)
    return path, manifest


def _write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")


@pytest.mark.parametrize("mutate", [
    lambda m: m["cases"].append({**deepcopy(m["cases"][0]), "case_id": "ONE"}),
    lambda m: m["cases"][0]["source"].update(path="../outside.wav"),
    lambda m: m["cases"][0]["baseline"].update(path="C:/secret.wav"),
    lambda m: m["cases"][0]["candidate"].update(path="audio/con.wav"),
    lambda m: m["cases"][0]["candidate"].update(path="audio/a.wav:stream"),
    lambda m: m["cases"][0]["configuration"].update(allow_gain=1),
    lambda m: m["cases"][0]["configuration"].update(resampling_model="guessed"),
    lambda m: m["cases"][0]["configuration"].update(engine="v12", allow_resampling=True),
    lambda m: m["cases"][0]["configuration"].update(max_delay_ms=float("nan")),
    lambda m: m.update(cases=m["cases"] * 21),
])
def test_manifest_rejects_ambiguous_or_unsafe_declaration_before_output(tmp_path, mutate):
    from audio_regression.regression_suite import run_regression_suite
    path, manifest = _inputs(tmp_path / "inputs")
    mutate(manifest)
    _write(path, manifest)
    with pytest.raises(SuiteError):
        run_regression_suite(path, tmp_path / "output")
    assert not (tmp_path / "output").exists()


@pytest.mark.parametrize("text", [
    '{"schema_version":1,"schema_version":1}',
    '{"schema_version":NaN}',
    '{"schema_version":Infinity}',
    '{"schema_version":-Infinity}',
])
def test_json_duplicates_and_nonfinite_are_not_silently_accepted(tmp_path, text):
    path = tmp_path / "manifest.json"
    path.write_text(text, encoding="utf-8")
    with pytest.raises(SuiteError):
        load_suite_manifest(path)


@pytest.mark.parametrize("role", ["source", "baseline", "candidate"])
def test_preexisting_input_change_fails_without_output_or_modifying_inputs(tmp_path, role):
    from audio_regression.regression_suite import run_regression_suite
    path, manifest = _inputs(tmp_path / "inputs")
    selected = path.parent / manifest["cases"][0][role]["path"]
    selected.write_bytes(selected.read_bytes() + b"changed-after-declaration")
    before = {p.name: _sha(p.read_bytes()) for p in path.parent.iterdir()}
    with pytest.raises(SuiteError):
        run_regression_suite(path, tmp_path / "output")
    assert not (tmp_path / "output").exists()
    assert before == {p.name: _sha(p.read_bytes()) for p in path.parent.iterdir()}


def test_normalization_is_detached_and_canonical_hash_is_order_independent(tmp_path):
    _path, manifest = _inputs(tmp_path / "inputs")
    clean = normalize_suite_manifest(manifest)
    assert canonical_manifest_sha256(clean) == canonical_manifest_sha256(dict(reversed(list(manifest.items()))))
    clean["cases"][0]["configuration"]["allow_gain"] = True
    assert manifest["cases"][0]["configuration"]["allow_gain"] is False


@pytest.fixture(scope="module")
def completed_suite(tmp_path_factory):
    from audio_regression.regression_suite import run_regression_suite
    root = tmp_path_factory.mktemp("independent_suite_safety")
    path, manifest = _inputs(root / "inputs")
    result = run_regression_suite(path, root / "output")
    return root, manifest, result


@pytest.mark.parametrize("mutation", ["input_hash", "manifest_hash", "delta", "summary", "approval", "analysis"])
def test_result_forgery_cannot_become_trusted_report(completed_suite, mutation):
    from audio_regression.regression_suite_contract import validate_suite_result
    _root, _manifest, actual = completed_suite
    value = deepcopy(actual)
    if mutation == "input_hash":
        value["manifest"]["cases"][0]["candidate"]["sha256"] = "0" * 64
    elif mutation == "manifest_hash":
        value["manifest_sha256"] = "0" * 64
    elif mutation == "delta":
        value["cases"][0]["delta"]["new_candidates"] = [0]
    elif mutation == "summary":
        value["summary"]["new_candidate_count"] += 1
    elif mutation == "approval":
        value["complete_audio_approval"] = True
    else:
        value["cases"][0]["candidate_analysis"]["processed"]["sha256"] = "0" * 64
    with pytest.raises(SuiteError):
        validate_suite_result(value)


def test_report_renders_plain_labels_without_script_or_audio_reopen(tmp_path, monkeypatch):
    from audio_regression.regression_suite import run_regression_suite
    from audio_regression.regression_suite_reporting import render_suite_html
    path, manifest = _inputs(tmp_path / "inputs")
    manifest["baseline_version"] = '<script>alert("baseline")</script>'
    manifest["candidate_version"] = '<img src=x onerror="alert(1)">'
    _write(path, manifest)
    result = run_regression_suite(path, tmp_path / "output")
    def forbidden(*_args, **_kwargs):
        raise AssertionError("Inert report must not reopen paths or audio")
    monkeypatch.setattr(Path, "open", forbidden)
    html = render_suite_html(result)
    assert '<script>alert("baseline")</script>' not in html
    assert '<img src=x onerror="alert(1)">' not in html
    assert "&lt;script&gt;" in html and "&lt;img" in html
    assert "http://" not in html and "https://" not in html


@pytest.mark.parametrize("kind", ["pcm24", "truncated"])
def test_unsupported_wav_is_case_error_and_next_case_is_still_processed(tmp_path, kind):
    from audio_regression.regression_suite import run_regression_suite
    from audio_regression.regression_suite_contract import validate_suite_result
    path, manifest = _inputs(tmp_path / "inputs")
    broken = deepcopy(manifest["cases"][0])
    broken["case_id"] = "broken"
    regular = path.parent / "candidate.wav"
    if kind == "truncated":
        payload = regular.read_bytes()[:-2]
    else:
        # A complete, correctly sized 24-bit RIFF is outside the PCM16 scope.
        payload_pcm = b"\0" * (4 * 8000 * 3)
        payload = (b"RIFF" + struct.pack("<I", 36 + len(payload_pcm)) + b"WAVEfmt "
                   + struct.pack("<IHHIIHH", 16, 1, 1, 8000, 24000, 3, 24)
                   + b"data" + struct.pack("<I", len(payload_pcm)) + payload_pcm)
    (path.parent / "broken.wav").write_bytes(payload)
    broken["candidate"] = {"path": "broken.wav", "sha256": _sha(payload)}
    manifest["cases"].insert(0, broken)
    _write(path, manifest)
    result = validate_suite_result(run_regression_suite(path, tmp_path / "output"))
    assert result["cases"][0]["status"] == "error"
    assert result["cases"][0]["delta"]["status"] == "inconclusive"
    assert result["cases"][0]["delta"]["not_observed_now"] == []
    assert result["cases"][1]["status"] == "completed"
    assert result["summary"]["exit_code"] != 0


def test_existing_result_and_input_collision_are_not_overwritten(tmp_path):
    from audio_regression.regression_suite import run_regression_suite
    path, _manifest = _inputs(tmp_path / "inputs")
    output = tmp_path / "output"
    output.mkdir()
    sentinel = output / "sentinel.txt"
    sentinel.write_bytes(b"existing-user-file")
    with pytest.raises((SuiteError, FileExistsError)):
        run_regression_suite(path, output)
    with pytest.raises((SuiteError, FileExistsError)):
        run_regression_suite(path, path.parent)
    assert sentinel.read_bytes() == b"existing-user-file"


@pytest.mark.parametrize("scope", ["input", "snapshot"])
def test_observable_midrun_input_or_snapshot_change_blocks_summary(tmp_path, monkeypatch, scope):
    from audio_regression import regression_suite as runner
    from audio_regression.regression_suite_contract import validate_suite_result
    path, _manifest = _inputs(tmp_path / "inputs")
    real = runner.api.analyze_pair
    changed = False
    def observe_then_change(source, processed, **options):
        nonlocal changed
        result = real(source, processed, **options)
        if not changed:
            target = path.parent / "candidate.wav" if scope == "input" else Path(processed)
            target.write_bytes(target.read_bytes() + b"observable-midrun-change")
            changed = True
        return result
    monkeypatch.setattr(runner.api, "analyze_pair", observe_then_change)
    result = validate_suite_result(runner.run_regression_suite(path, tmp_path / "output"))
    assert result["input_integrity"]["status"] == "failed"
    assert any(issue["scope"] == scope for issue in result["input_integrity"]["issues"])
    assert result["summary"]["exit_code"] != 0
    assert result["complete_audio_approval"] is False


def test_withheld_on_either_side_never_becomes_a_resolved_event(tmp_path):
    from audio_regression.regression_suite import run_regression_suite
    path, manifest = _inputs(tmp_path / "inputs")
    from audio_regression.audio import decode_wav
    values = decode_wav((path.parent / "source.wav").read_bytes()).samples
    candidate = values[800:].copy()
    candidate[len(candidate) // 2] += 1 / 32768
    held = encode_wav(candidate, 8000)
    (path.parent / "held.wav").write_bytes(held)
    held_spec = {"path": "held.wav", "sha256": _sha(held)}
    formerly_held = deepcopy(manifest["cases"][0])
    formerly_held.update(case_id="formerly-held", baseline=held_spec)
    newly_held = deepcopy(manifest["cases"][0])
    newly_held.update(case_id="newly-held", candidate=held_spec)
    manifest["cases"] = [formerly_held, newly_held]
    _write(path, manifest)
    result = run_regression_suite(path, tmp_path / "output")
    for case in result["cases"]:
        assert case["status"] == "completed"
        assert case["delta"] == {"status": "inconclusive", "reason_code": "analysis_not_comparable",
                                  "coordinate_axis": None, "new_candidates": [],
                                  "persistent_pairs": [], "not_observed_now": []}
    assert result["summary"]["inconclusive_case_count"] == 2
    assert result["summary"]["current_gate_state"] == "blocked"
    assert result["summary"]["regression_state"] == "inconclusive"
    assert result["summary"]["exit_code"] == 2


def test_disappearing_event_does_not_relabel_whole_audio_as_approved(tmp_path):
    from audio_regression.regression_suite import run_regression_suite
    from audio_regression.audio import decode_wav
    path, manifest = _inputs(tmp_path / "inputs")
    values = decode_wav((path.parent / "source.wav").read_bytes()).samples
    shortened = encode_wav(values[800:], 8000)
    (path.parent / "baseline.wav").write_bytes(shortened)
    manifest["cases"][0]["baseline"]["sha256"] = _sha(shortened)
    _write(path, manifest)
    result = run_regression_suite(path, tmp_path / "output")
    assert result["cases"][0]["delta"]["status"] == "compared"
    assert result["cases"][0]["delta"]["not_observed_now"] == [0]
    assert result["summary"]["current_gate_state"] == "clear_supported_temporal_check"
    assert result["summary"]["regression_state"] == "no_new_candidates_observed"
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False

