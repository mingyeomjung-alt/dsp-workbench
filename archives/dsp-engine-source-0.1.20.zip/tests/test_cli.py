import json

import numpy as np

from audio_regression.audio import encode_wav
from audio_regression.cli import main


def test_generate_and_compare_without_truth_access(tmp_path, capsys):
    folder = tmp_path / "clean"
    assert main(["generate", "--output-dir", str(folder), "--delay-ms", "240",
                 "--gain-db", "-6"]) == 0
    generated = json.loads(capsys.readouterr().out)
    assert generated["source_kind"] == "synthetic_test_signal"
    # Remove the truth to prove analysis works without an event answer key.
    (folder / "ground_truth.json").unlink()
    output = folder / "result.json"
    assert main(["compare", "--reference", str(folder / "reference.wav"),
                 "--processed", str(folder / "processed.wav"), "--declare-gain",
                 "--output", str(output)]) == 0
    result = json.loads(capsys.readouterr().out)
    assert result == json.loads(output.read_text(encoding="utf-8"))
    assert result["status"] == "measured"
    assert abs(result["alignment"]["estimated_delay_ms"] - 240) <= 1
    assert result["events"] is None
    assert result["content_preservation_status"] == "not_assessed_by_global_baseline"


def test_generation_refuses_existing_folder_and_preserves_contents(tmp_path, capsys):
    folder = tmp_path / "existing"
    folder.mkdir()
    sentinel = folder / "keep.txt"
    sentinel.write_text("original", encoding="utf-8")
    assert main(["generate", "--output-dir", str(folder)]) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "output_exists"
    assert sentinel.read_text(encoding="utf-8") == "original"
    assert not (folder / "reference.wav").exists()


def test_compare_refuses_to_replace_input_or_existing_output(tmp_path, capsys):
    original = encode_wav(np.random.default_rng(13).normal(0, .06, 24000), 8000)
    reference, processed = tmp_path / "ref.wav", tmp_path / "proc.wav"
    reference.write_bytes(original)
    processed.write_bytes(original)
    assert main(["compare", "--reference", str(reference), "--processed", str(processed),
                 "--output", str(reference)]) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "output_exists"
    assert reference.read_bytes() == original


def test_silence_is_withheld_and_can_be_saved(tmp_path, capsys):
    silence = encode_wav(np.zeros(24000), 8000)
    reference, processed = tmp_path / "ref.wav", tmp_path / "proc.wav"
    reference.write_bytes(silence)
    processed.write_bytes(silence)
    output = tmp_path / "withheld.json"
    assert main(["compare", "--reference", str(reference), "--processed", str(processed),
                 "--output", str(output)]) == 2
    result = json.loads(capsys.readouterr().out)
    assert result["reason_code"] == "insufficient_signal_energy"
    assert json.loads(output.read_text(encoding="utf-8")) == result


def test_missing_file_is_structured_error(tmp_path, capsys):
    assert main(["compare", "--reference", str(tmp_path / "none.wav"),
                 "--processed", str(tmp_path / "none2.wav")]) == 3
    assert json.loads(capsys.readouterr().out)["status"] == "error"


def test_invalid_generation_writes_no_directory(tmp_path, capsys):
    target = tmp_path / "invalid"
    assert main(["generate", "--output-dir", str(target), "--delay-ms", "-30"]) == 3
    assert json.loads(capsys.readouterr().out)["status"] == "error"
    assert not target.exists()


def test_config_error_is_not_mislabeled_as_generation_error(tmp_path, capsys):
    assert main(["compare", "--reference", str(tmp_path / "none.wav"),
                 "--processed", str(tmp_path / "none2.wav"),
                 "--max-delay-ms", "nan"]) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "invalid_configuration"


def test_analyze_localizes_deletion_without_ground_truth(tmp_path, capsys):
    folder = tmp_path / "delete"
    assert main(["generate", "--output-dir", str(folder), "--kind", "delete"]) == 0
    capsys.readouterr()
    (folder / "ground_truth.json").unlink()
    output = folder / "events.json"
    assert main(["analyze", "--reference", str(folder / "reference.wav"),
                 "--processed", str(folder / "processed.wav"), "--output", str(output)]) == 0
    result = json.loads(capsys.readouterr().out)
    assert result == json.loads(output.read_text(encoding="utf-8"))
    assert result["content_preservation_status"] == "defect_candidates"
    assert result["events"][0]["type"] == "delete"
    assert abs(result["events"][0]["reference_interval_ms"][0] - 2000) <= 100
    assert result["complete_audio_approval"] is False


def test_analyze_silence_is_withheld_and_saved(tmp_path, capsys):
    path = tmp_path / "silence.wav"
    path.write_bytes(encode_wav(np.zeros(24000), 8000))
    output = tmp_path / "withheld.json"
    assert main(["analyze", "--reference", str(path), "--processed", str(path),
                 "--output", str(output)]) == 2
    result = json.loads(capsys.readouterr().out)
    assert result["status"] == "withheld"
    assert result["events"] is None
    assert json.loads(output.read_text(encoding="utf-8")) == result


def test_analyze_refuses_to_overwrite_inputs(tmp_path, capsys):
    path = tmp_path / "source.wav"
    original = encode_wav(np.random.default_rng(319).normal(0, .06, 24000), 8000)
    path.write_bytes(original)
    assert main(["analyze", "--reference", str(path), "--processed", str(path),
                 "--output", str(path)]) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "output_exists"
    assert path.read_bytes() == original


def test_analyze_invalid_delay_is_stable_configuration_error(tmp_path, capsys):
    assert main(["analyze", "--reference", str(tmp_path / "missing1.wav"),
                 "--processed", str(tmp_path / "missing2.wav"), "--max-delay-ms", "nan"]) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "invalid_configuration"
