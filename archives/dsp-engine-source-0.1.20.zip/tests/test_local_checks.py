"""Mocked orchestration tests: never recursively start the selected regression."""
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
from types import SimpleNamespace
import xml.etree.ElementTree as ET

import pytest


TOOL = Path(__file__).absolute().parents[1] / "tools" / "run_local_checks.py"
SPEC = importlib.util.spec_from_file_location("dsp_local_checks", TOOL)
checks = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(checks)


def source_fixture(tmp_path):
    source = tmp_path / "source"
    package = source / "src" / "audio_regression"
    package.mkdir(parents=True)
    (package / "__init__.py").write_text("# fixture\n", encoding="utf-8")
    (package / "schemas").mkdir()
    (package / "schemas" / "fixture.json").write_text("{}", encoding="utf-8")
    (source / "tests").mkdir()
    for name in checks.SELECTED_TEST_FILES:
        (source / "tests" / name).write_text("# never executed in orchestration tests\n", encoding="utf-8")
    (source / "tools").mkdir()
    (source / "tools" / "run_local_checks.py").write_text("# fixture checker\n", encoding="utf-8")
    (source / "tools" / "other.py").write_text("# tracked, not executed\n", encoding="utf-8")
    for name in checks.ROOT_CONFIG_FILES:
        (source / name).write_text("# fixture config\n", encoding="utf-8")
    (source / "tests/fixtures/results").mkdir(parents=True)
    for name in checks.SYNTHETIC_RESULT_FILES:
        (source / "tests/fixtures/results" / name).write_bytes(b"{}")
    return source


def junit_bytes(*, missing=None, skipped=None, failed=None, error=None, unknown=None, forged=False):
    root = ET.Element("testsuites")
    suite = ET.SubElement(root, "testsuite", tests="0" if forged else str(len(checks.SELECTED_TEST_FILES)), failures="999" if forged else "0")
    for name in checks.SELECTED_TEST_FILES:
        if name == missing:
            continue
        case = ET.SubElement(suite, "testcase", classname="tests." + Path(name).stem, name="test_fixture")
        if name == skipped:
            ET.SubElement(case, "skipped")
        if name == failed:
            ET.SubElement(case, "failure")
        if name == error:
            ET.SubElement(case, "error")
    if unknown:
        ET.SubElement(suite, "testcase", classname=unknown, name="private_test")
    return ET.tostring(root)


def fake_run(monkeypatch, raw=None, *, returncode=0, change=None, timeout=False, capture=None):
    def execute(argv, **kwargs):
        if capture is not None:
            capture.update(argv=argv, kwargs=kwargs)
        if change:
            change()
        if timeout:
            raise subprocess.TimeoutExpired(argv, 1)
        output = Path(argv[argv.index("--junitxml") + 1])
        if raw is not None:
            output.write_bytes(raw)
        kwargs["stdout"].write(b"local pytest output\n")
        kwargs["stderr"].write(b"local pytest stderr\n")
        return SimpleNamespace(returncode=returncode)
    monkeypatch.setattr(checks.subprocess, "run", execute)


def test_selection_is_fixed_unique_previous_plus_candidate_integration():
    assert len(checks.SELECTED_TEST_FILES) == len(set(checks.SELECTED_TEST_FILES)) == 58
    assert checks.SELECTED_TEST_FILES[35:39] == ("test_artifact_integrity.py", "test_artifact_cli.py", "test_local_checks.py", "test_pipeline_snapshot_recheck.py")
    assert checks.SELECTED_TEST_FILES[-1] == "test_regression_suite_safety.py"
    assert all(name.startswith("test_") and name.endswith(".py") for name in checks.SELECTED_TEST_FILES)


def test_verified_selection_without_artifact_is_explicitly_not_requested(tmp_path, monkeypatch):
    source = source_fixture(tmp_path)
    output = tmp_path / "output"
    fake_run(monkeypatch, junit_bytes(forged=True))
    result = checks.run_checks(source, output)
    assert result["exit_code"] == 0
    assert result["status"] == "verified_selected_regression"
    assert result["tests"]["tests"] == result["tests"]["passed"] == 58
    assert result["tests"]["failures"] == 0  # Ignore forged suite header.
    assert result["artifact_verification"] == {"status": "not_requested", "result": None, "verification_passes": 0}
    assert result["source_integrity"]["status"] == "verified"
    assert json.loads((output / "check_summary.json").read_text(encoding="utf-8")) == result
    before = (output / "source_manifest_before.json").read_bytes()
    assert result["source_integrity"]["manifest_sha256"] == hashlib.sha256(before).hexdigest()
    for flag in ("network_used", "full_suite_reexecuted", "complete_audio_approval", "commercial_performance_validated",
                 "authenticity_verified", "execution_provenance_verified"):
        assert result[flag] is False
    assert result["quality_verdict"] == "not_assessed"


def test_child_is_explicit_local_current_interpreter_not_shell_and_env_is_clean(tmp_path, monkeypatch):
    source = source_fixture(tmp_path)
    captured = {}
    for name in ("PYTEST_ADDOPTS", "PYTEST_PLUGINS", "PYTHONHOME", "PYTHONSTARTUP", "PYTHONPATH"):
        monkeypatch.setenv(name, "malicious override")
    fake_run(monkeypatch, junit_bytes(), capture=captured)
    assert checks.run_checks(source, tmp_path / "output")["exit_code"] == 0
    argv, options = captured["argv"], captured["kwargs"]
    assert argv[:4] == [checks.sys.executable, "-B", "-m", "pytest"]
    assert "--noconftest" in argv and "--import-mode=importlib" in argv
    assert "pythonpath=" in argv  # Checked source path is supplied intact via environment, not ini shlex.
    assert argv[-58:] == [str(source / "tests" / name) for name in checks.SELECTED_TEST_FILES]
    assert options["shell"] is False and options["check"] is False and options["cwd"] == source
    assert options["timeout"] == 600
    env = options["env"]
    assert env["PYTHONPATH"] == os.pathsep.join((str(source / "src"), str(source / "tests")))
    for name in ("PYTEST_ADDOPTS", "PYTEST_PLUGINS", "PYTHONHOME", "PYTHONSTARTUP"):
        assert name not in env
    for name in ("PYTHONDONTWRITEBYTECODE", "PYTEST_DISABLE_PLUGIN_AUTOLOAD", "OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS",
                 "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS"):
        assert env[name] == "1"
    assert env["TMP"] == env["TEMP"] == env["TMPDIR"] == str(tmp_path / "output" / "temporary")
    assert not any(word in argv for word in ("pip", "build", "download", "evaluate", "seal"))


@pytest.mark.parametrize("arguments", [
    {"artifact_root": "root"}, {"artifact_manifest": "manifest"}, {"artifact_manifest_sha256": "a" * 64},
    {"artifact_root": "root", "artifact_manifest": "manifest"},
    {"artifact_root": "root", "artifact_manifest_sha256": "a" * 64},
    {"artifact_manifest": "manifest", "artifact_manifest_sha256": "a" * 64},
])
def test_artifact_arguments_all_or_none(tmp_path, arguments):
    result = checks.run_checks(source_fixture(tmp_path), tmp_path / "output", **arguments)
    assert result["exit_code"] == 3 and result["reason_code"] == "artifact_arguments_incomplete"
    assert not (tmp_path / "output").exists()


@pytest.mark.parametrize("digest", ["", "A" * 64, "a" * 63, True, None, "a" * 64 + "\n"])
def test_invalid_external_manifest_digest_rejected(tmp_path, digest):
    result = checks.run_checks(source_fixture(tmp_path), tmp_path / "output", artifact_root="root",
                              artifact_manifest="manifest", artifact_manifest_sha256=digest)
    assert result["exit_code"] == 3
    assert not (tmp_path / "output").exists()


def test_requested_artifact_verified_separately_and_bound(tmp_path, monkeypatch):
    source = source_fixture(tmp_path)
    calls = []
    verification = {"status": "verified", "file_count": 2, "manifest_sha256": "a" * 64}
    monkeypatch.setattr(checks, "_artifact", lambda *args: calls.append(args) or verification)
    fake_run(monkeypatch, junit_bytes())
    result = checks.run_checks(source, tmp_path / "output", artifact_root="kept_root", artifact_manifest="kept_manifest",
                              artifact_manifest_sha256="a" * 64)
    assert calls == [(source, "kept_root", "kept_manifest", "a" * 64)] * 2
    assert result["exit_code"] == 0 and result["artifact_verification"] == {"status": "verified", "result": verification, "verification_passes": 2}


def test_artifact_failure_retains_record_but_never_starts_pytest(tmp_path, monkeypatch):
    source = source_fixture(tmp_path)
    def fail(*args):
        raise checks.LocalCheckError("artifact_file_mismatch")
    monkeypatch.setattr(checks, "_artifact", fail)
    monkeypatch.setattr(checks.subprocess, "run", lambda *a, **k: pytest.fail("must not run after artifact mismatch"))
    result = checks.run_checks(source, tmp_path / "output", artifact_root="root", artifact_manifest="manifest",
                              artifact_manifest_sha256="a" * 64)
    assert result["exit_code"] == 2 and result["status"] == "artifact_verification_error"
    assert result["reason_code"] == "artifact_file_mismatch"
    assert result["artifact_verification"]["status"] == "error" and result["tests"] is None
    assert (tmp_path / "output" / "check_summary.json").exists()


@pytest.mark.parametrize("verification", [None, {}, {"status": "withheld"}, {"status": "failed"}])
def test_artifact_unverified_return_cannot_be_pass(tmp_path, monkeypatch, verification):
    source = source_fixture(tmp_path)
    monkeypatch.setattr(checks, "_artifact", lambda *args: verification)
    result = checks.run_checks(source, tmp_path / "output", artifact_root="root", artifact_manifest="manifest",
                              artifact_manifest_sha256="a" * 64)
    assert result["exit_code"] == 2 and result["artifact_verification"]["status"] == "error"


@pytest.mark.parametrize("raw", [junit_bytes(missing="test_api.py"), junit_bytes(skipped="test_api.py"), b"<testsuites/>"])
def test_zero_missing_or_all_skipped_file_collection_cannot_be_pass(tmp_path, monkeypatch, raw):
    fake_run(monkeypatch, raw)
    result = checks.run_checks(source_fixture(tmp_path), tmp_path / "output")
    assert result["exit_code"] == 2 and result["reason_code"] == "selected_test_coverage_incomplete"


def test_skips_with_a_non_skipped_test_in_same_file_are_allowed(tmp_path, monkeypatch):
    root = ET.fromstring(junit_bytes())
    case = ET.SubElement(root[0], "testcase", classname="tests.test_api", name="test_windows_skip")
    ET.SubElement(case, "skipped")
    fake_run(monkeypatch, ET.tostring(root))
    result = checks.run_checks(source_fixture(tmp_path), tmp_path / "output")
    assert result["exit_code"] == 0 and result["tests"]["skipped"] == 1


@pytest.mark.parametrize("raw,returncode", [(junit_bytes(failed="test_api.py"), 0),
                                           (junit_bytes(error="test_api.py"), 0), (junit_bytes(), 1)])
def test_testcase_failure_or_pytest_failure_exit_is_failure(tmp_path, monkeypatch, raw, returncode):
    fake_run(monkeypatch, raw, returncode=returncode)
    result = checks.run_checks(source_fixture(tmp_path), tmp_path / "output")
    assert result["exit_code"] == 1 and result["status"] == "selected_regression_failed"


@pytest.mark.parametrize("returncode", [2, 3, 4, 5, -1, True, None])
def test_execution_exit_codes_cannot_be_pass(tmp_path, monkeypatch, returncode):
    fake_run(monkeypatch, junit_bytes(), returncode=returncode)
    result = checks.run_checks(source_fixture(tmp_path), tmp_path / "output")
    assert result["exit_code"] == 3


@pytest.mark.parametrize("raw", [
    b"<testsuites><oops>", b"<!DOCTYPE testsuites [<!ENTITY secret 'x'>]><testsuites/>",
    b"<!ENTITY secret 'x'><testsuites/>", "<!DOCTYPE x><testsuites/>".encode("utf-16"),
    b"<foreign/>", junit_bytes(unknown="private.test_unselected"),
])
def test_invalid_or_unsafe_junit_is_error(tmp_path, monkeypatch, raw):
    fake_run(monkeypatch, raw)
    result = checks.run_checks(source_fixture(tmp_path), tmp_path / "output")
    assert result["exit_code"] == 3


def test_ambiguous_case_outcomes_rejected(tmp_path, monkeypatch):
    root = ET.fromstring(junit_bytes(failed="test_api.py"))
    ET.SubElement(root[0][0], "skipped")
    fake_run(monkeypatch, ET.tostring(root))
    result = checks.run_checks(source_fixture(tmp_path), tmp_path / "output")
    assert result["reason_code"] == "ambiguous_junit_outcome" and result["exit_code"] == 3


def test_collection_error_not_hidden_by_summary_headers(tmp_path, monkeypatch):
    root = ET.fromstring(junit_bytes())
    ET.SubElement(root[0], "error")
    fake_run(monkeypatch, ET.tostring(root))
    result = checks.run_checks(source_fixture(tmp_path), tmp_path / "output")
    assert result["tests"]["errors"] == 1 and result["exit_code"] == 1


@pytest.mark.parametrize("relative", ["src/audio_regression/__init__.py", "tests/test_api.py", "tools/other.py", "pyproject.toml",
                                      "src/audio_regression/schemas/fixture.json", "tools/run_local_checks.py",
                                      "tests/fixtures/results/synthetic_basic_clean.json"])
def test_changed_source_configs_tools_schemas_or_selected_tests_are_not_pass(tmp_path, monkeypatch, relative):
    source = source_fixture(tmp_path)
    fake_run(monkeypatch, junit_bytes(), change=lambda: (source / relative).write_bytes(b"changed source"))
    result = checks.run_checks(source, tmp_path / "output")
    assert result["exit_code"] == 2 and result["source_integrity"]["status"] == "changed"
    assert result["reason_code"] == "source_changed_during_checks"


def test_new_code_or_removed_source_is_detected(tmp_path, monkeypatch):
    source = source_fixture(tmp_path)
    fake_run(monkeypatch, junit_bytes(), change=lambda: (source / "src/audio_regression/new.py").write_bytes(b"new"))
    assert checks.run_checks(source, tmp_path / "new_output")["exit_code"] == 2
    fake_run(monkeypatch, junit_bytes(), change=lambda: (source / "tests/test_api.py").unlink())
    assert checks.run_checks(source, tmp_path / "removed_output")["exit_code"] == 2


def test_old_examples_evaluations_and_snapshots_are_not_read(tmp_path, monkeypatch):
    source = source_fixture(tmp_path)
    for relative in ("evaluations/private.wav", "examples/private.wav", "source_snapshots/old.py"):
        path = source / relative
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(b"old evidence remains")
    original = checks._read
    def bounded_read(path, limit):
        assert not {"evaluations", "examples", "source_snapshots"}.intersection(path.parts)
        return original(path, limit)
    monkeypatch.setattr(checks, "_read", bounded_read)
    fake_run(monkeypatch, junit_bytes())
    assert checks.run_checks(source, tmp_path / "output")["exit_code"] == 0
    assert (source / "evaluations/private.wav").read_bytes() == b"old evidence remains"


def test_preexisting_output_preserved(tmp_path):
    source = source_fixture(tmp_path)
    output = tmp_path / "output"
    output.mkdir()
    (output / "keep").write_bytes(b"unchanged")
    result = checks.run_checks(source, output)
    assert result["exit_code"] == 3 and result["reason_code"] == "output_directory_exists"
    assert list(output.iterdir()) == [output / "keep"] and (output / "keep").read_bytes() == b"unchanged"


@pytest.mark.parametrize("relative", ["", "src/new", "tests/new", "tools/new", "examples/new"])
def test_output_overlapping_source_is_rejected(tmp_path, relative):
    source = source_fixture(tmp_path)
    result = checks.run_checks(source, source / relative)
    assert result["exit_code"] == 3 and result["reason_code"] == "source_output_overlap"


@pytest.mark.parametrize("timeout", [0, -1, 601, True, None, float("nan"), float("inf")])
def test_invalid_timeout_has_no_output(tmp_path, timeout):
    result = checks.run_checks(source_fixture(tmp_path), tmp_path / "output", timeout_seconds=timeout)
    assert result["exit_code"] == 3 and result["reason_code"] == "invalid_local_check_timeout"
    assert not (tmp_path / "output").exists()


def test_timeout_retains_before_after_and_safe_reason(tmp_path, monkeypatch):
    fake_run(monkeypatch, junit_bytes(), timeout=True)
    result = checks.run_checks(source_fixture(tmp_path), tmp_path / "output", timeout_seconds=1)
    assert result["exit_code"] == 3 and result["reason_code"] == "local_check_timeout"
    assert result["source_integrity"]["status"] == "verified"
    assert (tmp_path / "output/source_manifest_after.json").exists()


def test_unknown_exception_does_not_leak_private_path(tmp_path, monkeypatch):
    source = source_fixture(tmp_path)
    def fail(*a, **kw):
        raise RuntimeError("C:/private/person/audio.wav confidential content")
    monkeypatch.setattr(checks.subprocess, "run", fail)
    result = checks.run_checks(source, tmp_path / "output")
    assert result["exit_code"] == 3 and result["reason_code"] == "local_check_execution_error"
    assert "confidential" not in json.dumps(result) and "C:/private" not in json.dumps(result)


def test_missing_selected_file_fails_before_creating_output(tmp_path):
    source = source_fixture(tmp_path)
    (source / "tests/test_api.py").unlink()
    result = checks.run_checks(source, tmp_path / "output")
    assert result["exit_code"] == 3 and not (tmp_path / "output").exists()


def test_large_source_file_fails_closed(tmp_path, monkeypatch):
    source = source_fixture(tmp_path)
    monkeypatch.setattr(checks, "MAX_SOURCE_FILE_BYTES", 1)
    assert checks.run_checks(source, tmp_path / "output")["exit_code"] == 3


def test_junit_size_bound(tmp_path, monkeypatch):
    source = source_fixture(tmp_path)
    monkeypatch.setattr(checks, "MAX_JUNIT_BYTES", 8)
    fake_run(monkeypatch, junit_bytes())
    result = checks.run_checks(source, tmp_path / "output")
    assert result["exit_code"] == 3 and result["reason_code"] == "local_check_file_too_large"


@pytest.mark.parametrize("target", ["source", "source_parent", "test", "output_parent"])
def test_observable_links_are_rejected(tmp_path, target):
    source = source_fixture(tmp_path)
    link = tmp_path / "link"
    try:
        if target == "test":
            original = source / "tests/test_api.py"
            original.unlink()
            original.symlink_to(source / "tests/test_cli.py")
            result = checks.run_checks(source, tmp_path / "output")
        else:
            link.symlink_to(source if target == "source" else tmp_path, target_is_directory=True)
            result = checks.run_checks(link if target == "source" else link / "source" if target == "source_parent" else source,
                                      link / "output" if target == "output_parent" else tmp_path / "output")
    except OSError:
        pytest.skip("Windows link creation is not available")
    assert result["exit_code"] == 3


def test_main_emits_only_safe_summary_json(tmp_path, monkeypatch, capsys):
    source = source_fixture(tmp_path)
    fake_run(monkeypatch, junit_bytes())
    assert checks.main(["--source-dir", str(source), "--output-dir", str(tmp_path / "output")]) == 0
    output = capsys.readouterr()
    value = json.loads(output.out)
    assert value["status"] == "verified_selected_regression" and output.err == ""
    assert str(tmp_path) not in output.out and "local pytest output" not in output.out


def test_optional_root_configs_need_not_exist(tmp_path, monkeypatch):
    source = source_fixture(tmp_path)
    (source / "constraints-offline.txt").unlink()
    (source / "constraints-build.txt").unlink()
    fake_run(monkeypatch, junit_bytes())
    result = checks.run_checks(source, tmp_path / "output")
    assert result["exit_code"] == 0
    paths = [item["path"] for item in json.loads((tmp_path / "output/source_manifest_before.json").read_text())["files"]]
    assert "pyproject.toml" in paths and "constraints-offline.txt" not in paths


def test_read_valid_rewritten_file_on_actual_runtime(tmp_path):
    path = tmp_path / "actual_read.txt"
    path.write_bytes(b"first")
    path.write_bytes(b"second")
    assert checks._read(path, 100) == b"second"


def test_artifact_module_loading_cannot_write_source_bytecode(tmp_path, monkeypatch):
    source = source_fixture(tmp_path)
    module = source / "src/audio_regression/artifact_integrity.py"
    module.write_text("def verify_artifact_manifest(root, manifest, *, expected_manifest_sha256):\n"
                      "    return {'status':'verified'}\n", encoding="utf-8")
    monkeypatch.setattr(checks.sys, "dont_write_bytecode", False)
    assert checks._artifact(source, "root", "manifest", "a" * 64) == {"status": "verified"}
    assert not (module.parent / "__pycache__").exists()


@pytest.mark.parametrize("relative", ["", "inside", "../output_parent"])
def test_artifact_output_overlap_rejected_before_any_writes(tmp_path, relative):
    source = source_fixture(tmp_path)
    retained = tmp_path / "retained"
    retained.mkdir()
    output = retained if not relative else retained / "inside" if relative == "inside" else tmp_path
    result = checks.run_checks(source, output, artifact_root=retained, artifact_manifest="manifest",
                              artifact_manifest_sha256="a" * 64)
    assert result["exit_code"] == 3
    assert result["reason_code"] in {"artifact_output_overlap", "source_output_overlap"}
    assert list(retained.iterdir()) == []


def test_artifact_modified_during_pytest_is_rejected(tmp_path, monkeypatch):
    source = source_fixture(tmp_path)
    calls = []
    def verify(*args):
        calls.append(args)
        if len(calls) > 1:
            raise checks.LocalCheckError("artifact_file_mismatch")
        return {"status": "verified"}
    monkeypatch.setattr(checks, "_artifact", verify)
    fake_run(monkeypatch, junit_bytes())
    result = checks.run_checks(source, tmp_path / "output", artifact_root="root", artifact_manifest="manifest",
                              artifact_manifest_sha256="a" * 64)
    assert result["exit_code"] == 2 and result["status"] == "artifact_verification_error"
    assert result["artifact_verification"]["verification_passes"] == 1
    assert result["source_integrity"]["status"] == "verified"


def test_invalid_cli_arguments_do_not_echo_private_values(capsys):
    assert checks.main(["--private", "C:/private/person/audio.wav"]) == 3
    captured = capsys.readouterr()
    result = json.loads(captured.out)
    assert result["reason_code"] == "invalid_local_check_arguments" and captured.err == ""
    assert "C:/private" not in captured.out and "--private" not in captured.out
