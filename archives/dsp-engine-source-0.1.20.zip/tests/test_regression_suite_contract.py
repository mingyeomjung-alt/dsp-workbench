"""Stored declarations/certificates only, not detector performance claims."""

from copy import deepcopy
import hashlib
import json
from pathlib import Path

import pytest

from audio_regression.regression_suite_contract import (
    SuiteError, build_suite_summary, canonical_manifest_sha256, incomplete_case_delta,
    load_suite_manifest, load_suite_result, normalize_suite_manifest, validate_suite_result,
)
from audio_regression.regression_suite_diff import compare_case_results
from test_reporting import sample_result


def manifest():
    return {
        "schema_version": 1, "suite_id": "suite_1", "baseline_version": "release 1",
        "candidate_version": "release 2", "cases": [{
            "case_id": "voice_1", "source": {"path": "audio/source.wav", "sha256": "a" * 64},
            "baseline": {"path": "audio/before.wav", "sha256": "b" * 64},
            "candidate": {"path": "audio/after.wav", "sha256": "c" * 64},
            "configuration": {"engine": "v1", "allow_gain": False, "allow_resampling": False,
                              "max_delay_ms": 1000, "resampling_model": None},
        }],
    }


def suite(baseline_kind="clean", candidate_kind="delete"):
    declaration = manifest()
    baseline, candidate = sample_result(baseline_kind), sample_result(candidate_kind)
    candidate["processed"]["sha256"] = "c" * 64
    record = {"case_id": "voice_1", "status": "completed", "reason_code": None,
              "baseline_analysis": baseline, "candidate_analysis": candidate,
              "delta": compare_case_results(baseline, candidate, declaration["cases"][0]["configuration"], "a" * 64)}
    value = {"schema_version": 1, "engine": "audio_regression_suite_v1", "producer_version": "0.1.20",
             "manifest": declaration, "manifest_sha256": canonical_manifest_sha256(declaration),
             "execution_complete": True, "cases": [record],
             "input_integrity": {"status": "verified", "issues": []}, "summary": {},
             "complete_audio_approval": False, "commercial_performance_validated": False}
    value["summary"] = build_suite_summary(value)
    return value


def test_manifest_is_inert_detached_ordered_and_canonical(monkeypatch):
    value = manifest()
    original = deepcopy(value)
    monkeypatch.setattr(Path, "open", lambda *_args, **_kwargs: pytest.fail("Normalizer opened a path"))
    normalized = normalize_suite_manifest(value)
    normalized["cases"][0]["case_id"] = "private_copy"
    assert value == original
    canonical = json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False,
                           separators=(",", ":")).encode("utf-8")
    assert canonical_manifest_sha256(value) == hashlib.sha256(canonical).hexdigest()


@pytest.mark.parametrize("path", [
    "../a.wav", "/a.wav", "C:/a.wav", "a\\b.wav", "a//b.wav", "a/./b.wav", "a/../b.wav",
    "CON.wav", "a/NUL.wav", "com9.wav", "LPT1.wav", "COM¹.wav", "lpt³.wav", "con .wav",
    "a:b.wav", "a?.wav", "a*.wav", 'a".wav', "a>.wav", "a|.wav", "a\n.wav", "a\u202e.wav",
    "a /b.wav", "a./b.wav", "a.mp3", "a.wav ", "e\u0301.wav", "./a.wav", "a" * 101 + ".wav",
])
def test_portable_wav_paths_reject_unsafe_names(path):
    value = manifest()
    value["cases"][0]["source"]["path"] = path
    with pytest.raises(SuiteError) as caught:
        normalize_suite_manifest(value)
    assert caught.value.code == "invalid_suite_audio_path"
    assert path not in str(caught.value)


@pytest.mark.parametrize("path", ["a.wav", "한국어/실제 파일.WAV", "nested/path/input.wav", "é.wav"])
def test_portable_normalized_unicode_wav_paths_are_valid(path):
    value = manifest()
    value["cases"][0]["source"]["path"] = path
    assert normalize_suite_manifest(value) == value


@pytest.mark.parametrize("mutation", [
    lambda v: v.update(extra=True), lambda v: v.update(schema_version=True),
    lambda v: v.update(schema_version=1.0), lambda v: v.update(suite_id="../private"),
    lambda v: v.update(baseline_version=""), lambda v: v.update(candidate_version="bad\nversion"),
    lambda v: v.update(candidate_version=" " + "v"), lambda v: v.update(cases=[]),
    lambda v: v.update(cases=[deepcopy(v["cases"][0])] * 21),
    lambda v: v["cases"].append({**deepcopy(v["cases"][0]), "case_id": "VOICE_1"}),
    lambda v: v["cases"][0]["source"].update(sha256="A" * 64),
    lambda v: v["cases"][0]["configuration"].update(profile="basic"),
    lambda v: v["cases"][0]["configuration"].update(engine="v8"),
    lambda v: v["cases"][0]["configuration"].update(allow_gain=1),
    lambda v: v["cases"][0]["configuration"].update(max_delay_ms=True),
    lambda v: v["cases"][0]["configuration"].update(max_delay_ms=float("nan")),
    lambda v: v["cases"][0]["configuration"].update(max_delay_ms=float("inf")),
    lambda v: v["cases"][0]["configuration"].update(max_delay_ms=5000.1),
    lambda v: v["cases"][0]["configuration"].update(resampling_model="invented"),
])
def test_strict_manifest_types_identity_and_configuration(mutation):
    value = manifest()
    mutation(value)
    with pytest.raises(SuiteError):
        normalize_suite_manifest(value)


def test_twenty_distinct_cases_allowed_but_casefold_collision_not_allowed():
    value = manifest()
    value["cases"] = [{**deepcopy(value["cases"][0]), "case_id": f"case_{n}"} for n in range(20)]
    assert len(normalize_suite_manifest(value)["cases"]) == 20
    value["cases"][-1]["case_id"] = "CASE_0"
    with pytest.raises(SuiteError, match="duplicate_suite_case_id"):
        normalize_suite_manifest(value)


def test_v12_model_is_an_explicit_exact_declaration():
    from audio_regression.resampler_result_contract import MODEL
    value = manifest()
    config = value["cases"][0]["configuration"]
    config.update(engine="v12", allow_gain=False, allow_resampling=True, resampling_model=MODEL)
    assert normalize_suite_manifest(value) == value
    for key, wrong in (("allow_gain", True), ("allow_resampling", False), ("resampling_model", None)):
        invalid = deepcopy(value)
        invalid["cases"][0]["configuration"][key] = wrong
        with pytest.raises(SuiteError, match="invalid_suite_resampling_declaration"):
            normalize_suite_manifest(invalid)


@pytest.mark.parametrize("before,after,code", [("clean", "clean", 0), ("clean", "delete", 1),
                                                ("delete", "delete", 1), ("delete", "clean", 0)])
def test_saved_suite_recomputes_both_axes_without_mutation(before, after, code, monkeypatch):
    value = suite(before, after)
    original = deepcopy(value)
    monkeypatch.setattr(Path, "open", lambda *_args, **_kwargs: pytest.fail("Validator opened a path"))
    assert validate_suite_result(value) is value
    assert value == original
    assert value["summary"]["exit_code"] == code
    assert value["summary"]["regression_state"] == ("new_candidates" if before == "clean" and after == "delete" else "no_new_candidates_observed")


@pytest.mark.parametrize("mutation", [
    lambda v: v.update(complete_audio_approval=True), lambda v: v.update(commercial_performance_validated=True),
    lambda v: v.update(schema_version=True), lambda v: v.update(engine="audio_regression_suite_v2"),
    lambda v: v.update(manifest_sha256="0" * 64), lambda v: v.update(execution_complete=False),
    lambda v: v["summary"].update(exit_code=0), lambda v: v["summary"].update(new_candidate_count=True),
    lambda v: v["cases"][0]["delta"].update(new_candidates=[]),
    lambda v: v["cases"][0]["delta"].update(new_candidates=[False]),
    lambda v: v["cases"][0].update(case_id="VOICE_1"),
    lambda v: v["cases"][0]["candidate_analysis"]["processed"].update(sha256="d" * 64),
    lambda v: v["cases"][0]["baseline_analysis"]["reference"].update(sha256="d" * 64),
    lambda v: v["cases"][0]["baseline_analysis"]["configuration"].update(max_delay_ms=5),
    lambda v: v["input_integrity"].update(status="failed"),
])
def test_saved_suite_tampering_rejected(mutation):
    value = suite()
    mutation(value)
    with pytest.raises(SuiteError):
        validate_suite_result(value)


def test_same_digest_cannot_describe_different_audio_metadata():
    value = suite()
    value["manifest"]["cases"][0]["candidate"]["sha256"] = "b" * 64
    value["manifest_sha256"] = canonical_manifest_sha256(value["manifest"])
    value["cases"][0]["candidate_analysis"]["processed"]["sha256"] = "b" * 64
    with pytest.raises(SuiteError, match="conflicting_suite_audio_metadata"):
        validate_suite_result(value)


def test_error_case_can_be_visited_but_never_clear_and_not_run_cannot_complete():
    value = suite()
    case = value["cases"][0]
    case.update(status="error", reason_code="invalid_wav", baseline_analysis=None,
                candidate_analysis=None, delta=incomplete_case_delta())
    value["summary"] = build_suite_summary(value)
    assert validate_suite_result(value)["summary"]["exit_code"] == 3
    case.update(status="not_run", reason_code="case_not_run")
    value["execution_complete"] = False
    value["summary"] = build_suite_summary(value)
    assert validate_suite_result(value)["summary"]["exit_code"] == 2
    value["execution_complete"] = True
    value["summary"] = build_suite_summary(value)
    with pytest.raises(SuiteError, match="inconsistent_suite_completion_flag"):
        validate_suite_result(value)


def test_integrity_failure_overrides_complete_analysis_and_cannot_be_erased():
    value = suite("clean", "clean")
    value["input_integrity"] = {"status": "failed", "issues": [
        {"case_id": "voice_1", "role": "source", "scope": "input", "reason_code": "suite_input_changed"}]}
    value["summary"] = build_suite_summary(value)
    assert validate_suite_result(value)["summary"]["exit_code"] == 3
    value["input_integrity"]["issues"].append(deepcopy(value["input_integrity"]["issues"][0]))
    with pytest.raises(SuiteError, match="duplicate_suite_integrity_issue"):
        validate_suite_result(value)


@pytest.mark.parametrize("loader,factory", [(load_suite_manifest, manifest), (load_suite_result, suite)])
def test_strict_saved_json_roundtrip_and_duplicate_rejection(tmp_path, loader, factory):
    path = tmp_path / "record.json"
    value = factory()
    path.write_text(json.dumps(value, ensure_ascii=False), encoding="utf-8")
    assert loader(path) == value
    text = path.read_text(encoding="utf-8").replace('"schema_version": 1', '"schema_version": 1, "schema_version": 1', 1)
    path.write_text(text, encoding="utf-8")
    with pytest.raises(SuiteError, match="duplicate_suite_json_key"):
        loader(path)


@pytest.mark.parametrize("loader", [load_suite_manifest, load_suite_result])
def test_loaders_reject_directory_without_opening_as_regular_file(tmp_path, loader):
    with pytest.raises(SuiteError):
        loader(tmp_path)


def test_schema_documents_are_valid_json_and_explicitly_bounded():
    schemas = Path(__file__).resolve().parents[1] / "src/audio_regression/schemas"
    for filename in ("regression-suite-manifest-v1.schema.json", "regression-suite-result-v1.schema.json"):
        schema = json.loads((schemas / filename).read_text(encoding="utf-8"))
        assert schema["additionalProperties"] is False
        assert schema["properties"]["cases"]["maxItems"] == 20
