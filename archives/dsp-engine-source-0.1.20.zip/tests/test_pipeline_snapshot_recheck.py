"""Fresh local mutation regressions, not DSP accuracy or workflow-value tests.

Fast tests return self-authored contract-valid diagnostics and mutate snapshots
only after the analyzer has produced its last result. Two integration checks
also use the actual default pair API. No recorded or sealed audio is reused.
"""

from copy import deepcopy
import hashlib
import json
from pathlib import Path

import numpy as np
import pytest

from audio_regression import api, pipeline_runner, saved_pipeline
from audio_regression.artifact_integrity import ArtifactVerificationError
from audio_regression.audio import encode_wav, read_wav
from audio_regression.pipeline_reporting import validate_pipeline_result
from audio_regression.result_contract import validate_analysis_result
from audio_regression.saved_pipeline_contract import validate_saved_pipeline_result


@pytest.fixture
def source_bytes():
    rate, count = 16000, 96000
    rng = np.random.default_rng(20261015581)
    time = np.arange(count) / rate
    noise = np.convolve(rng.standard_normal(count), [.1, .2, .4, .2, .1], mode="same")
    envelope = np.interp(np.linspace(0, 52, count), np.arange(53), rng.uniform(.3, 1, 53))
    tone = np.sin(2 * np.pi * (260 * time + 65 * time**3))
    signal = envelope * (noise + .2 * tone)
    return encode_wav(signal * (.22 / np.max(np.abs(signal))), rate)


def _clear(reference, processed, **configuration):
    """A valid wiring stub, not a detector decision or signal-quality score."""
    first, last = read_wav(reference).metadata(), read_wav(processed).metadata()
    end = min(first["duration_ms"], last["duration_ms"])
    return validate_analysis_result({
        "schema_version": 1, "engine": "local_content_alignment_v1", "status": "analyzed",
        "content_preservation_status": "no_supported_defect_candidates", "reason_code": None,
        "events": [], "complete_audio_approval": False, "commercial_performance_validated": False,
        "reference": first, "processed": last, "configuration": deepcopy(configuration),
        "analysis": {"sample_rate_hz": 8000, "hop_ms": 10.0,
            "method": "constrained_edit_alignment_with_raw_anchors",
            "minimum_event_duration_ms": 200, "maximum_cumulative_edit_shift_ms": 2000,
            "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {"normalized_path_cost": 0.0, "gain_estimate": 1.0,
            "applied_gain": 1.0, "matched_normalized_rmse": 0.0,
            "matched_analysis_samples": round(end * 8), "anchor_run_count": 1,
            "minimum_local_correlation": 1.0},
        "limitations": ["Fresh contract-only wiring stub, not performance evidence."],
        "alignment_segments": [{"reference_interval_ms": [0.0, end],
            "processed_offset_ms": 0.0, "anchor_correlations": [1.0, 1.0, 1.0]}],
    })


def _concern(reference, processed, mode, **configuration):
    if mode == "error":
        return {"schema_version": 1, "status": "error", "reason_code": "analysis_execution_error"}
    result = _clear(reference, processed, **configuration)
    if mode == "withheld":
        result.pop("alignment_segments")
        result.update(status="withheld", content_preservation_status="withheld",
                      events=None, reason_code="ambiguous_alignment", diagnostics={})
    elif mode == "candidate":
        result.update(content_preservation_status="defect_candidates", events=[{
            "type": "delete", "reference_interval_ms": [1000.0, 1400.0],
            "processed_boundary_ms": 1000.0,
            "evidence": {"boundary_correlation": 1.0, "offset_before_ms": 0.0,
                         "offset_after_ms": -400.0}}])
        result["alignment_segments"] = [
            {"reference_interval_ms": [0.0, 1000.0], "processed_offset_ms": 0.0,
             "anchor_correlations": [1.0, 1.0, 1.0]},
            {"reference_interval_ms": [1400.0, 6000.0], "processed_offset_ms": -400.0,
             "anchor_correlations": [1.0, 1.0, 1.0]}]
        result["diagnostics"]["anchor_run_count"] = 2
    return validate_analysis_result(result)


def _setup(tmp_path, source_bytes, kind):
    source = tmp_path / "private-original.wav"
    source.write_bytes(source_bytes)
    output = tmp_path / "fresh-audit"
    if kind == "native":
        module = pipeline_runner
        named = [source]
        snapshots = [output / "input/source.wav", output / "stages/001/output.wav",
                     output / "stages/002/output.wav"]

        def run():
            return module.run_pipeline(source, [
                {"kind": "gain", "gain_db": 0, "label": "first"},
                {"kind": "gain", "gain_db": 0, "label": "second"}], output)
    else:
        module = saved_pipeline
        named = [source, tmp_path / "private-middle.wav", tmp_path / "private-final.wav"]
        for path in named[1:]:
            path.write_bytes(source_bytes)
        manifest = tmp_path / "manifest.json"
        manifest.write_text(json.dumps({"schema_version": 1, "source": source.name,
            "stages": [{"label": label, "output": path.name,
                "declaration": {"allow_gain": False, "allow_resampling": False}}
                for path, label in zip(named[1:], ("first", "second"))]}), encoding="utf-8")
        snapshots = [output / f"inputs/{index:03d}.wav" for index in range(3)]

        def run():
            return module.audit_saved_pipeline(manifest, output)
    return module, named, snapshots, output, run


def _assert_blocked(result, kind, reason, *, indices=None):
    assert result["status"] == "incomplete"
    assert result["summary"]["exit_code"] == 2
    assert result["summary"]["gate_state"] == "blocked"
    assert result["end_to_end"]["status"] == "error"
    assert result["end_to_end"]["analysis"]["reason_code"] == reason
    if indices is not None:
        assert result["input_recheck"]["file_indices"] == indices
    for field in ("complete_audio_approval", "commercial_performance_validated",
                  "network_used", "fault_provenance_confirmed"):
        assert result[field] is False
    validator = validate_pipeline_result if kind == "native" else validate_saved_pipeline_result
    assert validator(result) is result
    assert "private-original" not in json.dumps(result)
    assert "private-middle" not in json.dumps(result)


@pytest.mark.parametrize("kind", ["native", "saved"])
@pytest.mark.parametrize("position", [0, 1, 2], ids=["source-copy", "middle-copy", "final-copy"])
@pytest.mark.parametrize("action", ["change", "remove"])
def test_late_snapshot_mutation_blocks_clear_result(tmp_path, source_bytes, monkeypatch, kind, position, action):
    module, named, snapshots, output, run = _setup(tmp_path, source_bytes, kind)
    calls = 0

    def compare(reference, processed, **configuration):
        nonlocal calls
        calls += 1
        result = _clear(reference, processed, **configuration)
        if calls == 3:
            if action == "change":
                snapshots[position].write_bytes(b"observed private copy mutation")
            else:
                snapshots[position].unlink()
        return result

    monkeypatch.setattr(module.api, "analyze_pair", compare)
    result = run()
    reason = ("snapshot_changed_during_run" if action == "change" else "snapshot_recheck_failed")
    if kind == "saved":
        reason = "input_files_changed" if action == "change" else "input_files_recheck_failed"
    _assert_blocked(result, kind, reason, indices=[position] if kind == "saved" else None)
    assert calls == 3
    assert result["summary"]["failed_stage"] is None
    assert result["summary"]["first_concern"]["scope"] == "end_to_end"
    assert all(path.read_bytes() == source_bytes for path in named)
    if kind == "saved":
        assert result["input_recheck"]["status"] == ("changed" if action == "change" else "unavailable")
    assert (output / "end_to_end/analysis.json").is_file()
    if action == "change":
        assert snapshots[position].read_bytes() == b"observed private copy mutation"
    else:
        assert not snapshots[position].exists()


@pytest.mark.parametrize("kind", ["native", "saved"])
@pytest.mark.parametrize("position", [0, 1, 2], ids=["source-copy", "middle-copy", "final-copy"])
@pytest.mark.parametrize("failure", ["read_error", "unsafe_alias"])
def test_late_snapshot_recheck_unavailable_never_clears(tmp_path, source_bytes, monkeypatch, kind, position, failure):
    module, _, snapshots, _, run = _setup(tmp_path, source_bytes, kind)
    reader = module._read_regular

    def guarded(path, *args, **kwargs):
        if path == snapshots[position]:
            if failure == "read_error":
                raise OSError("private read failure C:/private-path")
            raise ArtifactVerificationError("unsafe_artifact_path")
        return reader(path, *args, **kwargs)

    monkeypatch.setattr(module, "_read_regular", guarded)
    monkeypatch.setattr(module.api, "analyze_pair", _clear)
    result = run()
    reason = "snapshot_recheck_failed" if kind == "native" else "input_files_recheck_failed"
    _assert_blocked(result, kind, reason, indices=[position] if kind == "saved" else None)
    assert "private-path" not in json.dumps(result)
    assert all(path.read_bytes() == source_bytes for path in snapshots)
    if kind == "saved":
        assert result["input_recheck"]["status"] == "unavailable"


@pytest.mark.parametrize("kind", ["native", "saved"])
def test_unchanged_snapshots_remain_clear(tmp_path, source_bytes, monkeypatch, kind):
    module, named, snapshots, _, run = _setup(tmp_path, source_bytes, kind)
    monkeypatch.setattr(module.api, "analyze_pair", _clear)
    result = run()
    assert result["status"] == "completed"
    assert result["summary"]["exit_code"] == 0
    assert result["summary"]["first_concern"] is None
    assert all(path.read_bytes() == source_bytes for path in [*named, *snapshots])
    if kind == "saved":
        assert result["input_recheck"] == {"status": "unchanged", "file_indices": []}


@pytest.mark.parametrize("kind", ["native", "saved"])
@pytest.mark.parametrize("mode", ["candidate", "withheld", "error"])
def test_snapshot_failure_preserves_earliest_stage_concern(tmp_path, source_bytes, monkeypatch, kind, mode):
    module, _, snapshots, _, run = _setup(tmp_path, source_bytes, kind)
    calls = 0

    def compare(reference, processed, **configuration):
        nonlocal calls
        calls += 1
        result = (_concern(reference, processed, mode, **configuration) if calls == 1
                  else _clear(reference, processed, **configuration))
        if calls == (1 if mode == "error" else 3):
            snapshots[0].write_bytes(b"late snapshot mutation")
        return result

    monkeypatch.setattr(module.api, "analyze_pair", compare)
    result = run()
    reason = "snapshot_changed_during_run" if kind == "native" else "input_files_changed"
    _assert_blocked(result, kind, reason, indices=[0] if kind == "saved" else None)
    assert result["summary"]["first_concern"] == {
        "scope": "stage", "stage_index": 1, "stage_label": "first",
        "category": {"candidate": "defect_candidates", "withheld": "withheld",
                     "error": "execution_error"}[mode]}
    assert result["summary"]["failed_stage"] == (1 if mode == "error" else None)


def test_named_native_source_change_retains_existing_reason_priority(tmp_path, source_bytes, monkeypatch):
    module, named, snapshots, _, run = _setup(tmp_path, source_bytes, "native")
    calls = 0

    def compare(reference, processed, **configuration):
        nonlocal calls
        calls += 1
        result = _clear(reference, processed, **configuration)
        if calls == 3:
            snapshots[1].write_bytes(b"private middle changed")
            named[0].write_bytes(b"named source changed")
        return result

    monkeypatch.setattr(module.api, "analyze_pair", compare)
    result = run()
    _assert_blocked(result, "native", "source_changed_during_run")
    assert named[0].read_bytes() == b"named source changed"


def test_saved_named_and_private_failures_merge_sorted_unique_indices(tmp_path, source_bytes, monkeypatch):
    module, named, snapshots, _, run = _setup(tmp_path, source_bytes, "saved")
    calls = 0
    reader = module._read_regular

    def guarded(path, *args, **kwargs):
        if path == snapshots[2]:
            raise OSError("private copy cannot be rechecked")
        return reader(path, *args, **kwargs)

    def compare(reference, processed, **configuration):
        nonlocal calls
        calls += 1
        result = _clear(reference, processed, **configuration)
        if calls == 3:
            named[1].write_bytes(b"named middle changed")
            snapshots[1].write_bytes(b"private middle changed")
        return result

    monkeypatch.setattr(module, "_read_regular", guarded)
    monkeypatch.setattr(module.api, "analyze_pair", compare)
    result = run()
    _assert_blocked(result, "saved", "input_files_recheck_failed", indices=[1, 2])
    assert result["input_recheck"]["status"] == "unavailable"


@pytest.mark.parametrize("kind", ["native", "saved"])
def test_actual_default_api_late_middle_mutation_is_blocked(tmp_path, source_bytes, monkeypatch, kind):
    module, named, snapshots, _, run = _setup(tmp_path, source_bytes, kind)
    actual = api.analyze_pair
    calls = 0

    def compare(reference, processed, **configuration):
        nonlocal calls
        calls += 1
        result = actual(reference, processed, **configuration)
        assert result["status"] == "analyzed" and result["events"] == []
        if calls == 3:
            snapshots[1].write_bytes(b"observed mutation after actual pair analysis")
        return result

    monkeypatch.setattr(module.api, "analyze_pair", compare)
    result = run()
    reason = "snapshot_changed_during_run" if kind == "native" else "input_files_changed"
    _assert_blocked(result, kind, reason, indices=[1] if kind == "saved" else None)
    assert calls == 3
    assert all(hashlib.sha256(path.read_bytes()).digest() == hashlib.sha256(source_bytes).digest()
               for path in named)
