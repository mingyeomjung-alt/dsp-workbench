"""Owned synthetic CLI/report tests for the explicit-model surface only."""

from copy import deepcopy
import json
from pathlib import Path

import numpy as np
import pytest

from audio_regression import model_cli
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.model_check import ModelCheckError, run_model_check
from audio_regression.model_reporting import render_model_html, write_model_html
from audio_regression.result_contract import ResultContractError
from audio_regression.transform_models import render_models


def _pair(tmp_path, models=None, change=None, rate=8000):
    models = models or [{"kind": "polarity_invert"}]
    rng = np.random.default_rng(2026101460707)
    original = encode_wav(rng.integers(-4700, 4701, rate * 4) / 32768, rate)
    reference, processed = tmp_path / "model_input.wav", tmp_path / "actual.wav"
    reference.write_bytes(original)
    samples = decode_wav(render_models(decode_wav(original), models)).samples.copy()
    if change == "sample":
        samples[rate] += 1 / 32768
    elif change == "delete":
        samples = np.concatenate((samples[:rate * 2], samples[int(rate * 2.4):]))
    elif change == "repeat":
        samples = np.concatenate((samples[:rate * 2], samples[int(rate * 1.6):rate * 2], samples[rate * 2:]))
    processed.write_bytes(encode_wav(samples, rate))
    plan = tmp_path / "plan.json"
    plan.write_text(json.dumps({"schema_version": 1, "models": models}), encoding="utf-8")
    return reference, processed, plan, models


def _compare_args(reference, processed, plan, output, engine=None):
    args = ["compare", "--reference", str(reference), "--processed", str(processed),
            "--plan", str(plan), "--output-dir", str(output)]
    return args + ["--engine", engine] if engine is not None else args


@pytest.mark.parametrize("kind", ["polarity_invert", "fir_binomial_3", "pcm_quantize_12"])
def test_compare_cli_writes_full_valid_result_and_preserves_inputs(tmp_path, capsys, kind):
    reference, processed, plan, _ = _pair(tmp_path, [{"kind": kind}])
    old = (reference.read_bytes(), processed.read_bytes(), plan.read_bytes())
    output = tmp_path / "run"
    assert model_cli.main(_compare_args(reference, processed, plan, output)) == 0
    result = json.loads(capsys.readouterr().out)
    assert json.loads((output / "model_result.json").read_text(encoding="utf-8")) == result
    assert result["summary"]["gate_state"] == "clear_declared_model_check"
    assert result["comparison"]["exact_pcm16_match"] is True
    assert result["analysis"]["engine"] == "local_content_alignment_v1"
    assert result["analysis"]["reference"] == result["expected"]
    assert result["complete_audio_approval"] is False
    assert old == (reference.read_bytes(), processed.read_bytes(), plan.read_bytes())


@pytest.mark.parametrize("engine", [f"v{index}" for index in range(1, 10)])
def test_explicit_cli_engine_and_saved_check(tmp_path, capsys, engine):
    reference, processed, plan, _ = _pair(tmp_path)
    output = tmp_path / "run"
    assert model_cli.main(_compare_args(reference, processed, plan, output, engine)) == 0
    result = json.loads(capsys.readouterr().out)
    assert result["analysis"]["engine"] == "local_content_alignment_" + engine
    assert result["artifacts"]["trace"] == (None if engine == "v1" else "trace.json")
    assert model_cli.main(["check", "--input", str(output / "model_result.json")]) == 0
    summary = json.loads(capsys.readouterr().out)
    assert summary["contract_valid"] is True
    assert summary["reason_code"] == "declared_model_matched"


def test_one_pcm_unit_residual_remains_blocked_even_if_temporal_child_clear(tmp_path, capsys):
    reference, processed, plan, _ = _pair(tmp_path, change="sample")
    output = tmp_path / "run"
    assert model_cli.main(_compare_args(reference, processed, plan, output)) == 2
    result = json.loads(capsys.readouterr().out)
    assert result["analysis"]["events"] == []
    assert result["temporal_check"]["exit_code"] == 0
    assert result["summary"]["reason_code"] == "declared_model_unexplained_difference"
    html = render_model_html(result)
    assert html.index("모델 비교 · 최상위 판정") < html.index("지원 범위의 시간적 결함 후보 없음")
    assert 'data-model-gate="blocked"' in html
    assert "상단의 모델 비교 판정이 우선합니다" in html
    assert model_cli.main(["check", "--input", str(output / "model_result.json")]) == 2
    assert json.loads(capsys.readouterr().out)["gate_state"] == "blocked"


@pytest.mark.parametrize("change", ["delete", "repeat"])
def test_temporal_event_axes_use_expected_signal_not_model_input(tmp_path, capsys, change):
    reference, processed, plan, _ = _pair(tmp_path, change=change)
    output = tmp_path / "run"
    assert model_cli.main(_compare_args(reference, processed, plan, output)) == 1
    result = json.loads(capsys.readouterr().out)
    html = render_model_html(result)
    assert "기대 신호 시간축" in html and "실제 처리본 시간축" in html
    assert "원본 시간축" not in html and "원본 삭제" not in html
    assert "길이 불일치 · 미계산" in html
    assert "None" not in html
    assert model_cli.main(["check", "--input", str(output / "model_result.json")]) == 1
    assert json.loads(capsys.readouterr().out)["gate_state"] == "review_required"


@pytest.mark.parametrize("engine", ["v1", "v9"])
def test_exact_silence_does_not_hide_withheld_reason(tmp_path, capsys, engine):
    reference, processed, plan, _ = _pair(tmp_path)
    reference.write_bytes(encode_wav(np.zeros(24000), 8000))
    processed.write_bytes(reference.read_bytes())
    output = tmp_path / "run"
    assert model_cli.main(_compare_args(reference, processed, plan, output, engine)) == 2
    result = json.loads(capsys.readouterr().out)
    html = render_model_html(result)
    assert result["comparison"]["exact_pcm16_match"] is True
    assert "시간 비교 판단 보류" in html
    assert "최종 판단 보류 사유" in html
    assert "최상위 판정" in html
    if engine == "v9":
        assert "저장된 추가 검사 기록" in html


def test_model_plan_order_is_presented_in_saved_order_and_fixed_parameters(tmp_path):
    models = [{"kind": "pcm_quantize_12"}, {"kind": "fir_binomial_3"}, {"kind": "polarity_invert"}]
    reference, processed, _, _ = _pair(tmp_path, models)
    result = run_model_check(reference, processed, models, tmp_path / "run")
    html = render_model_html(result)
    assert html.index("고정 PCM12 양자화") < html.index("고정 3탭 FIR") < html.index("극성 반전")
    assert "1샘플 군지연" in html and "끝 꼬리 미추가" in html
    assert "매 단계마다 PCM16 ties-to-even" in html
    assert "범위 초과를 클리핑으로 숨기지" in html


def test_high_rate_metadata_does_not_claim_fullband_quality_measurement(tmp_path):
    reference, processed, _, models = _pair(tmp_path, rate=48000)
    result = run_model_check(reference, processed, models, tmp_path / "run")
    html = render_model_html(result)
    assert "48,000" in html
    assert "8 kHz 대역 제한 시간 비교" in html
    assert "전대역 음질 분석이 아닙니다" in html


def test_rendering_is_inert_and_standalone_using_validated_saved_data(tmp_path, monkeypatch):
    reference, processed, _, models = _pair(tmp_path)
    result = run_model_check(reference, processed, models, tmp_path / "run")
    old = deepcopy(result)
    def forbidden(*args, **kwargs):
        raise AssertionError("No audio, trace, or artifact file may be opened.")
    monkeypatch.setattr(Path, "open", forbidden)
    monkeypatch.setattr(model_cli, "run_model_check", forbidden)
    html = render_model_html(result)
    assert result == old
    assert "Content-Security-Policy" in html
    for marker in ("<script", "<audio", "<iframe", "<img", "<link", "href=", "src=", "file://"):
        assert marker not in html.lower()
    assert str(tmp_path) not in html


def test_report_and_check_only_open_saved_json_and_new_report(tmp_path, capsys, monkeypatch):
    reference, processed, _, models = _pair(tmp_path)
    folder = tmp_path / "run"
    run_model_check(reference, processed, models, folder)
    payload, html = folder / "model_result.json", tmp_path / "new.html"
    real_open = Path.open
    opened = []
    def allowed_open(path, *args, **kwargs):
        assert path in {payload, html}
        opened.append(path)
        return real_open(path, *args, **kwargs)
    def forbidden(*args, **kwargs):
        raise AssertionError("Stored operations must not rerun the model or analysis.")
    monkeypatch.setattr(Path, "open", allowed_open)
    monkeypatch.setattr(model_cli, "run_model_check", forbidden)
    assert model_cli.main(["report", "--input", str(payload), "--output", str(html)]) == 0
    report_summary = json.loads(capsys.readouterr().out)
    assert report_summary["status"] == "generated_model_html"
    assert str(tmp_path) not in json.dumps(report_summary)
    assert model_cli.main(["check", "--input", str(payload)]) == 0
    assert json.loads(capsys.readouterr().out)["contract_valid"] is True
    assert opened == [payload, html, payload]


@pytest.mark.parametrize("command,exit_code", [("check", 2), ("report", 3)])
@pytest.mark.parametrize("text", ["{", '{"schema_version":1,"schema_version":1}',
                                  '{"private":"C:\\\\Users\\\\secret","score":NaN}'])
def test_invalid_saved_result_never_passes_or_writes_html(tmp_path, capsys, command, exit_code, text):
    payload = tmp_path / "private.json"
    payload.write_text(text, encoding="utf-8")
    output = tmp_path / "report.html"
    args = [command, "--input", str(payload)]
    if command == "report":
        args += ["--output", str(output)]
    assert model_cli.main(args) == exit_code
    error = json.loads(capsys.readouterr().out)
    assert error["gate_state"] == "blocked"
    assert error["exit_code"] == exit_code
    assert error["contract_valid"] is False
    assert str(tmp_path) not in json.dumps(error) and "secret" not in json.dumps(error)
    assert not output.exists()


@pytest.mark.parametrize("plan_text", ["{", '{"schema_version":1,"models":[]}',
                                       '{"schema_version":1,"models":[{"kind":"shell","command":"private"}]}'])
def test_bad_plan_rejected_before_output_creation(tmp_path, capsys, plan_text):
    reference, processed, plan, _ = _pair(tmp_path)
    plan.write_text(plan_text, encoding="utf-8")
    output = tmp_path / "run"
    assert model_cli.main(_compare_args(reference, processed, plan, output)) == 3
    error = json.loads(capsys.readouterr().out)
    assert error["gate_state"] == "blocked"
    assert not output.exists()
    assert "private" not in json.dumps(error)


def test_invalid_input_is_a_nonprivate_compare_error(tmp_path, capsys):
    reference, processed, plan, _ = _pair(tmp_path)
    reference.write_bytes(b"secret malformed audio")
    output = tmp_path / "run"
    assert model_cli.main(_compare_args(reference, processed, plan, output)) == 3
    error = json.loads(capsys.readouterr().out)
    assert error["reason_code"] == "invalid_wav"
    assert "secret" not in json.dumps(error) and str(tmp_path) not in json.dumps(error)
    assert not output.exists()


def test_existing_outputs_and_result_path_preserved(tmp_path, capsys):
    reference, processed, plan, _ = _pair(tmp_path)
    folder = tmp_path / "existing"
    folder.mkdir()
    sentinel = folder / "keep.txt"
    sentinel.write_text("preserve", encoding="utf-8")
    assert model_cli.main(_compare_args(reference, processed, plan, folder)) == 3
    assert sentinel.read_text(encoding="utf-8") == "preserve"
    capsys.readouterr()
    result = run_model_check(reference, processed, [{"kind": "polarity_invert"}], tmp_path / "run")
    payload = tmp_path / "run/model_result.json"
    old = payload.read_bytes()
    assert model_cli.main(["report", "--input", str(payload), "--output", str(payload)]) == 3
    assert payload.read_bytes() == old
    assert json.loads(capsys.readouterr().out)["reason_code"] == "output_exists"
    html = tmp_path / "report.html"
    write_model_html(result, html)
    old = html.read_bytes()
    assert model_cli.main(["report", "--input", str(payload), "--output", str(html)]) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "output_exists"
    assert html.read_bytes() == old


@pytest.mark.parametrize("change", ["summary", "analysis_axis", "claim", "plan"])
def test_malformed_saved_model_contract_is_not_rendered(tmp_path, change):
    reference, processed, _, models = _pair(tmp_path)
    result = run_model_check(reference, processed, models, tmp_path / "run")
    if change == "summary":
        result["summary"]["exit_code"] = 2
    elif change == "analysis_axis":
        result["analysis"]["reference"] = result["source"]
    elif change == "claim":
        result["complete_audio_approval"] = True
    else:
        result["model_plan"]["models"][0]["path"] = "C:/Users/private/model.py"
    with pytest.raises(ResultContractError):
        write_model_html(result, tmp_path / "new.html")
    assert not (tmp_path / "new.html").exists()


@pytest.mark.parametrize("failure", [RuntimeError("C:/Users/private/file"),
                                     IndexError("private internal failure"),
                                     ModelCheckError("private/path")])
def test_unexpected_compare_errors_do_not_leak_exception_text(tmp_path, capsys, monkeypatch, failure):
    reference, processed, plan, _ = _pair(tmp_path)
    def broken(*args, **kwargs):
        raise failure
    monkeypatch.setattr(model_cli, "run_model_check", broken)
    assert model_cli.main(_compare_args(reference, processed, plan, tmp_path / "out")) == 3
    rendered = capsys.readouterr().out
    assert "private" not in rendered and "Traceback" not in rendered
    assert json.loads(rendered)["gate_state"] == "blocked"


def test_help_and_argument_errors_are_normal_argparse_codes(tmp_path, capsys):
    with pytest.raises(SystemExit) as help_exit:
        model_cli.main(["--help"])
    assert help_exit.value.code == 0
    assert "audio-transform-check" in capsys.readouterr().out
    with pytest.raises(SystemExit) as bad_exit:
        model_cli.main(["compare", "--engine", "v99"])
    assert bad_exit.value.code == 2
    assert "Traceback" not in capsys.readouterr().err
