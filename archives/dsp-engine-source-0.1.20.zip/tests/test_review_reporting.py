"""Stored synthetic diagnostic explanations; no detector or natural corpus."""

from copy import deepcopy
from html.parser import HTMLParser
import json
from pathlib import Path

import pytest

from audio_regression.check_policy import check_result
from audio_regression.pipeline_reporting import load_pipeline_result, render_pipeline_html
from audio_regression.reporting import render_html, write_html_report
from audio_regression.result_contract import ResultContractError, load_analysis_result
from audio_regression.review_presenter import render_review_diagnostics
from audio_regression.saved_pipeline_contract import load_saved_pipeline_result
from audio_regression.saved_pipeline_reporting import render_saved_pipeline_html


ENGINE = "local_content_alignment_v3"
PRIMARY = "unexplained_matched_signal_change"
PRIOR = "insufficient_unambiguous_anchors"


def pair(*, version="v3", primary=PRIMARY, availability="recorded", legacy=False):
    metadata = {
        "sample_rate_hz": 16000, "sample_count": 96000, "duration_ms": 6000.0,
        "channels": 1, "encoding": "pcm16", "rms": .05, "peak": .2,
        "sha256": "a" * 64,
    }
    result = {
        "schema_version": 1, "engine": "local_content_alignment_" + version,
        "status": "withheld", "content_preservation_status": "withheld",
        "reason_code": primary, "events": None, "complete_audio_approval": False,
        "commercial_performance_validated": False,
        "reference": metadata, "processed": {**metadata, "sha256": "b" * 64},
        "configuration": {"profile": "basic", "allow_gain": True,
                          "allow_resampling": False, "max_delay_ms": 1000.0},
        "analysis": {"sample_rate_hz": 8000, "hop_ms": 10.0,
                     "method": ("constrained_edit_alignment_with_raw_anchors" if version == "v1" else
                                "constrained_edit_alignment_with_bounded_active_context_bridge"),
                     "minimum_event_duration_ms": 200, "maximum_cumulative_edit_shift_ms": 2000,
                     "diagnostic_rules_not_calibrated_probabilities": True},
        "diagnostics": {}, "limitations": ["새 합성 저장 결과 · 전체 음질은 평가 범위 밖"],
    }
    if not legacy:
        stages = [
            {"engine": "local_content_alignment_v1", "outcome": "withheld",
             "reason_code": PRIOR, "detail_reason_code": None},
            {"engine": "local_content_alignment_v2", "outcome": "not_attempted",
             "reason_code": None, "detail_reason_code": None},
            {"engine": ENGINE, "outcome": "attempted_without_proof_detail",
             "reason_code": None, "detail_reason_code": None},
        ]
        result["review_diagnostics"] = {
            "schema_version": 1, "selected_engine": result["engine"],
            "result_status": "withheld", "primary_reason_code": primary,
            "trace_availability": availability, "diagnostic_only": True,
            "fault_provenance_confirmed": False,
            "stages": stages if availability == "recorded" else [],
        }
    return result


def pipeline(*, saved=False, legacy=False):
    analysis = pair(legacy=legacy)
    reference, processed = deepcopy(analysis["reference"]), deepcopy(analysis["processed"])
    check = check_result(analysis)
    stage = {
        "index": 1, "label": "음량 조절", "input": reference, "output": processed,
        "status": "withheld", "analysis": analysis, "check": check,
        "input_snapshot": "inputs/000.wav" if saved else "input/source.wav",
        "output_snapshot": "inputs/001.wav" if saved else "stages/001/output.wav",
        "analysis_artifact": "stages/001/analysis.json", "check_artifact": "stages/001/check.json",
        "reason_code": PRIMARY, "runtime_ms": 1.0,
    }
    if saved:
        stage["declaration"] = deepcopy(analysis["configuration"])
    else:
        stage["operation"] = {"kind": "gain", "label": stage["label"], "gain_db": 0.0}
    result = {
        "schema_version": 1,
        "engine": ("audio_saved_pipeline_audit_v3" if saved else "audio_pipeline_regression_v3"),
        "status": "completed", "source": deepcopy(reference),
        "comparison_scope": "adjacent_stage_checks_and_end_to_end", "stages": [stage],
        "end_to_end": {
            "status": "withheld", "analysis": deepcopy(analysis), "check": deepcopy(check),
            "analysis_artifact": "end_to_end/analysis.json", "check_artifact": "end_to_end/check.json",
        },
        "summary": {
            "gate_state": "blocked", "exit_code": 2,
            "first_concern": {"scope": "stage", "stage_index": 1,
                              "stage_label": stage["label"], "category": "withheld"},
            "planned_stage_count": 1,
            "checked_stage_count" if saved else "executed_stage_count": 1,
            "failed_stage": None,
        },
        "complete_audio_approval": False, "commercial_performance_validated": False,
        "network_used": False, "fault_provenance_confirmed": False,
    }
    if saved:
        result.update(input_recheck={"status": "unchanged", "file_indices": []},
                      caller_order_verified=False)
    return result


class Tags(HTMLParser):
    def __init__(self, html):
        super().__init__()
        self.elements = []
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        self.elements.append((tag, dict(attrs)))


def assert_static(html):
    assert not any(tag in {"script", "iframe", "audio", "video", "img", "link", "a"}
                   for tag, _ in Tags(html).elements)
    assert not any(any(key.startswith("on") for key in attrs)
                   for _, attrs in Tags(html).elements)


def test_final_reason_and_recorded_stage_outcomes_are_distinct_and_not_mutated():
    result = pair()
    original = deepcopy(result)
    html = render_html(result)
    assert result == original
    assert html == render_html(result)
    assert 'data-review-primary-reason="' + PRIMARY + '"' in html
    primary, recorded = html.split('<details open class="review-stages">', 1)
    assert PRIMARY in primary and PRIOR not in primary
    assert PRIOR in recorded
    assert 'data-review-outcome="withheld"' in recorded
    assert 'data-review-outcome="not_attempted"' in recorded
    assert 'data-review-outcome="attempted_without_proof_detail"' in recorded
    assert "미시도는 검사 실패나 결함 판정을 뜻하지 않습니다" in recorded
    assert "성공·실패 여부를 추가로 추정하지 않습니다" in recorded
    assert "다음 확인:" in html and "최종 판단 보류 사유" in html
    assert "결함의 실제 발생 원인은 아닙니다" in html
    assert "지원 범위의 시간적 결함 후보 없음" not in html
    assert check_result(result)["exit_code"] == 2
    assert_static(html)


@pytest.mark.parametrize("availability", ["not_recorded", "unavailable"])
def test_absent_records_do_not_become_failed_proof_or_unattempted_stage(availability):
    result = pair(availability=availability)
    html = render_html(result)
    assert 'data-review-primary-reason="' + PRIMARY + '"' in html
    assert "미시도나 증명 실패라고 판단하지 않습니다" in html if availability == "not_recorded" else (
        "실패했다거나 수행되지 않았다는 뜻은 아닙니다" in html)
    assert "data-review-stage=" not in html
    assert check_result(result)["exit_code"] == 2


def test_legacy_withheld_receives_static_explanation_without_inventing_records():
    result = pair(version="v1", legacy=True)
    html = render_html(result)
    assert "최종 판단 보류 사유" in html and "다음 확인:" in html
    assert "추가 검사 기록 미제공" in html
    assert "미시도나 증명 실패라고 판단하지 않습니다" in html
    assert "data-review-stage=" not in html
    assert "선택한 개선 후보" not in html
    assert check_result(result)["exit_code"] == 2


def test_legacy_minimal_error_keeps_a_reasonable_error_envelope():
    error = {"schema_version": 1, "status": "error", "reason_code": "file_read_error"}
    html = render_html(error)
    assert "분석 오류 · 판단 불가" in html and "file_read_error" in html
    assert "추가 검사 기록" not in html
    assert "data-review-primary-reason=" not in html
    assert "지원 범위의 시간적 결함 후보 없음" not in html
    assert render_review_diagnostics(error) == ""


def test_unknown_final_reason_remains_unknown_instead_of_guessed_cause():
    result = pair(primary="future_withheld_reason")
    html = render_html(result)
    assert 'data-review-primary-reason="future_withheld_reason"' in html
    assert "future_withheld_reason" in html
    assert "다음 확인:" in html
    assert check_result(result)["exit_code"] == 2
    assert_static(html)


def test_presenter_escapes_untrusted_text_and_redacts_local_paths_defensively():
    result = pair(primary='<script>alert("x")</script> C:\\private\\recording.wav /opt/private/audio.wav')
    html = render_review_diagnostics(result)
    assert "&lt;script&gt;" in html and "&quot;x&quot;" in html
    assert "C:\\private" not in html and "/opt/private" not in html
    assert "[로컬 경로 생략]" in html
    assert_static(html)
    with pytest.raises(ResultContractError):
        render_html(result)


def test_invalid_addendum_is_rejected_before_creating_a_shareable_report(tmp_path):
    result = pair()
    result["review_diagnostics"]["stages"][0]["reason_code"] = '<svg onload="x">'
    target = tmp_path / "invalid.html"
    with pytest.raises(ResultContractError):
        write_html_report(result, target)
    assert not target.exists()


@pytest.mark.parametrize("saved", [False, True])
@pytest.mark.parametrize("legacy", [False, True])
def test_native_and_saved_reports_share_review_details_without_audio_or_trace_reads(tmp_path, monkeypatch, saved, legacy):
    result = pipeline(saved=saved, legacy=legacy)
    target = tmp_path / "result.json"
    target.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    loaded = (load_saved_pipeline_result if saved else load_pipeline_result)(target)
    original = deepcopy(loaded)
    # Loading the saved JSON is authorized; rendering may not open anything.
    def forbidden(*args, **kwargs):
        raise AssertionError("Report attempted to reopen a file.")
    monkeypatch.setattr(Path, "open", forbidden)
    html = (render_saved_pipeline_html if saved else render_pipeline_html)(loaded)
    assert loaded == original
    assert html.count('data-review-primary-reason="' + PRIMARY + '"') == 2
    assert "추가 검사 기록 미제공" in html if legacy else "추가 증명 미확보" in html
    assert "존재를 확인하지" in html
    assert loaded["summary"]["exit_code"] == 2
    assert "caller_order_verified: false" in html if saved else "처음 관찰된 지점은 원인 확정이 아닙니다" in html
    assert_static(html)


def test_analysis_json_loader_preserves_addendum_without_reading_references(tmp_path):
    result = pair()
    target = tmp_path / "withheld.json"
    target.write_text(json.dumps(result, ensure_ascii=False), encoding="utf-8")
    loaded = load_analysis_result(target)
    assert loaded == result
    html = render_html(loaded)
    assert "최종 판단 보류 사유" in html and "추가 증명 미확보" in html
    assert not (tmp_path / "trace.json").exists()


def test_recorded_stage_detail_is_labeled_as_local_detail_not_primary_cause():
    result = pair()
    result["review_diagnostics"]["stages"][0]["detail_reason_code"] = "insufficient_signal_variation"
    html = render_html(result)
    primary, recorded = html.split('<details open class="review-stages">', 1)
    assert "insufficient_signal_variation" not in primary
    assert "기록된 세부 사유:" in recorded and "insufficient_signal_variation" in recorded
    assert check_result(result)["exit_code"] == 2


def test_empty_recorded_projection_does_not_invent_stage_outcome():
    result = pair()
    result["review_diagnostics"]["stages"] = []
    html = render_html(result)
    assert "개별 추가 검사 상태가 기록되지 않았습니다" in html
    assert "data-review-stage=" not in html
    assert check_result(result)["exit_code"] == 2
