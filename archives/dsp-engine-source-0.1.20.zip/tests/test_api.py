import pytest

from audio_regression.api import analyze_pair
from audio_regression.audio import AudioInputError
from audio_regression.engine import EngineConfigError
from audio_regression.fixtures import generate_case


@pytest.mark.parametrize("kind", ["clean", "delete", "repeat"])
def test_local_facade_preserves_audio_and_returns_contract(tmp_path, kind):
    case = generate_case(kind, seed=47112)
    ref, proc = tmp_path / "reference.wav", tmp_path / "processed.wav"
    ref.write_bytes(case.reference_wav)
    proc.write_bytes(case.processed_wav)
    result = analyze_pair(ref, proc)
    assert result["schema_version"] == 1
    assert result["engine"] == "local_content_alignment_v1"
    assert result["complete_audio_approval"] is False
    assert result["commercial_performance_validated"] is False
    assert ref.read_bytes() == case.reference_wav
    assert proc.read_bytes() == case.processed_wav


def test_input_failure_is_never_converted_to_clear(tmp_path):
    with pytest.raises(AudioInputError):
        analyze_pair(tmp_path / "missing.wav", tmp_path / "also_missing.wav")


def test_unknown_profile_is_rejected_without_reading_audio(tmp_path):
    with pytest.raises(EngineConfigError):
        analyze_pair(tmp_path / "missing.wav", tmp_path / "missing2.wav", profile="unknown")
