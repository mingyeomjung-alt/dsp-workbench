"""Cold-source handoff checks; no natural corpus, download, or detector run."""

import ast
import importlib.util
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import sys

import pytest


ROOT = Path(__file__).absolute().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "release_source_handoff", ROOT / "tools" / "build_handoff.py"
)
handoff = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(handoff)


@pytest.fixture
def staged(tmp_path):
    stage = tmp_path / "source"
    stage.mkdir()
    inventory = handoff.stage_source(ROOT, stage)
    handoff.verify_stage(stage, inventory)
    return stage, {entry["path"] for entry in inventory}


def _strings(path):
    return [node.value for node in ast.walk(ast.parse(path.read_text(encoding="utf-8")))
            if isinstance(node, ast.Constant) and isinstance(node.value, str)]


def test_every_source_tool_referenced_by_packaged_tests_is_staged(staged):
    stage, files = staged
    tool_names = {path.name for path in (ROOT / "tools").glob("*.py")}
    referenced = set()
    for path in (stage / "tests").glob("*.py"):
        if path.name == Path(__file__).name:
            # This audit also lists deliberately excluded files as test data.
            continue
        for value in _strings(path):
            filename = value.replace("\\", "/").rsplit("/", 1)[-1]
            if filename in tool_names:
                referenced.add("tools/" + filename)
    assert referenced <= files, "Packaged tests require omitted source tools: " + str(sorted(referenced - files))
    assert {"tools/build_handoff.py", "tools/independent_eval_execute.py",
            "tools/instrument_eval_execute.py", "tools/global_context_eval_execute.py"} <= referenced


def test_packaged_tests_do_not_depend_on_excluded_workspace_examples(staged):
    stage, _ = staged
    external = []
    for path in (stage / "tests").glob("*.py"):
        if path.name == Path(__file__).name:
            # These literals are inspection patterns, not fixture reads.
            continue
        values = _strings(path)
        if path.name == "test_result_contract.py":
            # Only the explicitly optional read-only public-artifact test may
            # refer to the historical examples. Its absent archive case skips.
            tree = ast.parse(path.read_text(encoding="utf-8"))
            function = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
                            and node.name == "test_optional_saved_public_results_validate_read_only")
            assert isinstance(function.body[0], ast.If)
            guard = function.body[0].test
            assert isinstance(guard, ast.Compare) and isinstance(guard.left, ast.Name)
            assert guard.left.id == "path" and isinstance(guard.ops[0], ast.Is)
            assert isinstance(guard.comparators[0], ast.Constant) and guard.comparators[0].value is None
            call = function.body[0].body[0].value
            assert isinstance(call, ast.Call) and isinstance(call.func, ast.Attribute)
            assert isinstance(call.func.value, ast.Name) and call.func.value.id == "pytest"
            assert call.func.attr == "skip"
            required_helper = next(node for node in tree.body if isinstance(node, ast.FunctionDef)
                                   and node.name == "_result")
            assert "OPTIONAL_PUBLIC" not in ast.unparse(required_helper)
            assert "examples" not in ast.unparse(required_helper)
            declaration = next(node for node in tree.body if isinstance(node, ast.Assign)
                               and any(isinstance(target, ast.Name) and target.id == "DEVELOPMENT"
                                       for target in node.targets))
            assert "examples" not in ast.unparse(declaration.value)
            assert "fixtures" in ast.unparse(declaration.value)
            assert "results" in ast.unparse(declaration.value)
            continue
        if any("examples/m2_20261012" in value or "examples\\m2_20261012" in value for value in values):
            external.append(path.name)
        elif "examples" in values and "m2_20261012" in values:
            external.append(path.name)
    assert not external, "Tests need private workspace examples instead of packaged synthetic JSON: " + str(external)


def test_exact_synthetic_json_contract_fixtures_are_staged_without_media(staged):
    stage, files = staged
    prefix = "tests/fixtures/results/"
    expected = {prefix + f"synthetic_{profile}_{kind}.json"
                for profile in ("basic", "telephone") for kind in ("clean", "delete", "repeat")}
    expected.add(prefix + "synthetic_global_baseline.json")
    assert {value for value in files if value.startswith("tests/fixtures/")} == expected
    for relative in expected:
        value = json.loads((stage / relative).read_text(encoding="utf-8"))
        assert set(value) <= {"schema_version", "engine", "status", "content_preservation_status",
                             "reason_code", "events", "complete_audio_approval", "commercial_performance_validated",
                             "reference", "processed", "configuration", "analysis", "diagnostics", "limitations",
                             "alignment_segments", "alignment", "metrics"}
        assert set(value["reference"]) == {"sample_rate_hz", "sample_count", "duration_ms", "channels",
                                          "encoding", "rms", "peak", "sha256"}
        assert set(value["processed"]) == set(value["reference"])
        assert value["reference"]["duration_ms"] == 6000.0
        assert value["reference"]["sha256"] == "9883364e39a7a3e6cb042f41c2bc28c584c45afa1cbecb797f2cdedf0fdcb5b7"


def test_tool_imports_and_package_resolve_only_to_the_staged_source(staged, tmp_path):
    stage, _ = staged
    code = """import importlib.util, pathlib, sys
root = pathlib.Path(sys.argv[1])
for name in ('build_handoff', 'independent_eval_execute', 'instrument_eval_execute', 'global_context_eval_execute'):
    spec = importlib.util.spec_from_file_location('cold_' + name, root / 'tools' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
import audio_regression
assert pathlib.Path(audio_regression.__file__).absolute().is_relative_to(root / 'src')
print('staged-imports-only')
"""
    environment = os.environ.copy()
    environment["PYTHONPATH"] = str(stage / "src")
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    environment["PYTEST_DISABLE_PLUGIN_AUTOLOAD"] = "1"
    completed = subprocess.run(
        [sys.executable, "-c", code, str(stage)], cwd=tmp_path,
        env=environment, capture_output=True, text=True, timeout=30,
    )
    assert completed.returncode == 0, completed.stderr
    assert completed.stdout.strip() == "staged-imports-only"


def test_staged_snapshot_excludes_audio_models_secrets_and_generated_binaries(staged):
    _, files = staged
    forbidden_suffixes = {".wav", ".ogg", ".flac", ".mp3", ".m4a", ".onnx", ".pt", ".pth",
                          ".pem", ".key", ".exe", ".dll", ".pyd", ".pyc"}
    forbidden_parts = {"evaluations", "examples", "source_snapshots", "deliverables",
                       ".private_audio", ".third_party", ".venv", "voiceguard", "__pycache__"}
    assert not [value for value in files if Path(value).suffix.lower() in forbidden_suffixes]
    assert not [value for value in files if forbidden_parts & set(Path(value).parts)]
    assert all(not Path(value).is_absolute() and ".." not in Path(value).parts for value in files)


@pytest.mark.parametrize("relative", [
    "tests/fixtures/results/private_extra.json",
    "tests/fixtures/results/reference.wav",
    "tests/fixtures/results/.private.json",
    "tests/fixtures/elsewhere/synthetic_basic_clean.json",
    "tests/fixtures/results/nested/synthetic_basic_clean.json",
    "tools/prepare_independent_dsp_eval.py",
])
def test_public_source_fixture_allowlist_does_not_expand_to_private_data_or_download_tools(relative):
    assert handoff._allowed(PurePosixPath(relative)) is False
