"""Pair/truth geometry only: no final seeds and no detector evaluations."""

import ast
import json
import math
from pathlib import Path

import numpy as np
import pytest

from audio_regression.audio import WavAudio, decode_wav, encode_wav
from audio_regression.evaluation_data import build_trials, make_confirmation_signal
from audio_regression.profiles import telephone_transform_samples


def _reference(rate=16000, seconds=6.0):
    # These development-only seeds are not the root's reserved confirmation seeds.
    return make_confirmation_signal(seed=12345, duration_seconds=seconds, rate=rate)


def _trials(reference=None):
    return build_trials(reference or _reference(), source_group="development_source", source_kind="synthetic_development")


def test_fixed_matrix_configs_and_grouping_are_json_safe_except_audio_bytes():
    trials = _trials()
    assert len(trials) == 22
    assert len({trial["trial_id"] for trial in trials}) == len(trials)
    assert {trial["source_group"] for trial in trials} == {
        "development_source", "stress_periodic_600hz_4s", "stress_silent_4s",
    }
    supported = [trial for trial in trials if trial["scope"] == "supported"]
    assert len(supported) == 16
    assert {trial["source_group"] for trial in supported} == {"development_source"}
    expected = {"normal_clean", "normal_delay240_gain_minus6db"} | {
        f"{edit}_{length}ms" for edit in ("delete", "repeat") for length in (200, 400, 750)
    }
    for profile in ("basic", "telephone"):
        assert {trial["condition"] for trial in supported if trial["profile"] == profile} == expected
    for trial in trials:
        settings = trial["configuration"]
        assert set(settings) == {"profile", "allow_gain", "allow_resampling", "max_delay_ms"}
        assert settings["profile"] == trial["profile"]
        assert settings["allow_gain"] is (trial["condition"] == "normal_delay240_gain_minus6db")
        assert settings["allow_resampling"] is (trial["profile"] == "telephone")
        assert settings["max_delay_ms"] == 1000.0
        json.dumps({key: value for key, value in trial.items() if not key.endswith("_wav")}, allow_nan=False)


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
@pytest.mark.parametrize("seconds", [4.0, 6.0001, 12.0])
def test_supported_basic_geometry_and_exact_pcm_survival(rate, seconds):
    reference = _reference(rate, seconds)
    trials = _trials(reference)
    basic = [trial for trial in trials if trial["scope"] == "supported" and trial["profile"] == "basic"]
    start = round(0.35 * len(reference.samples))
    for trial in basic:
        source = decode_wav(trial["reference_wav"])
        target = decode_wav(trial["processed_wav"])
        np.testing.assert_array_equal(source.samples, reference.samples)
        assert source.sample_rate_hz == target.sample_rate_hz == rate
        assert len(reference.samples) - start - round(0.750 * rate) >= math.ceil(0.500 * rate)
        assert start >= math.ceil(0.500 * rate)
        if trial["condition"] == "normal_clean":
            assert trial["reference_wav"] == trial["processed_wav"]
            assert trial["expected_events"] == []
        elif trial["condition"] == "normal_delay240_gain_minus6db":
            delay = round(0.240 * rate)
            assert np.all(target.samples[:delay] == 0.0)
            expected = decode_wav(encode_wav(reference.samples * 10 ** (-6 / 20), rate))
            np.testing.assert_array_equal(target.samples[delay:], expected.samples)
            assert trial["expected_events"] == []
        else:
            event = trial["expected_events"][0]
            length = round(int(trial["condition"].split("_")[1][:-2]) * rate / 1000)
            end = start + length
            if event["type"] == "delete":
                assert event == {
                    "type": "delete", "reference_interval_ms": [start * 1000 / rate, end * 1000 / rate],
                    "processed_boundary_ms": start * 1000 / rate,
                }
                np.testing.assert_array_equal(target.samples, np.concatenate((reference.samples[:start], reference.samples[end:])))
            else:
                assert event == {
                    "type": "repeat", "reference_source_interval_ms": [start * 1000 / rate, end * 1000 / rate],
                    "processed_added_interval_ms": [end * 1000 / rate, (end + length) * 1000 / rate],
                }
                np.testing.assert_array_equal(target.samples, np.concatenate((reference.samples[:end], reference.samples[start:end], reference.samples[end:])))


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
def test_telephone_transform_changes_rate_not_truth_axes(rate):
    trials = _trials(_reference(rate=rate))
    basic = {trial["condition"]: trial for trial in trials if trial["scope"] == "supported" and trial["profile"] == "basic"}
    for trial in trials:
        if trial["profile"] != "telephone":
            continue
        counterpart = basic[trial["condition"]]
        assert trial["reference_wav"] == counterpart["reference_wav"]
        assert trial["expected_events"] == counterpart["expected_events"]
        target = decode_wav(trial["processed_wav"])
        assert target.sample_rate_hz == 8000
        expected = encode_wav(telephone_transform_samples(decode_wav(counterpart["processed_wav"])), 8000)
        assert trial["processed_wav"] == expected
        assert trial["configuration"]["allow_resampling"] is (rate != 8000)


def test_stress_remains_separate_from_supported_defects_and_normal_pairs():
    reference = _reference()
    stress = {trial["condition"]: trial for trial in _trials(reference) if trial["scope"] == "stress"}
    assert len(stress) == 6
    for trial in stress.values():
        assert trial["profile"] == "basic"
        assert trial["expected_events"] == []
        assert trial["expected_handling"] == "withheld"
    start = round(0.35 * len(reference.samples))
    replaced = decode_wav(stress["stress_zero_replacement400ms"]["processed_wav"]).samples
    assert len(replaced) == len(reference.samples)
    np.testing.assert_array_equal(replaced[:start], reference.samples[:start])
    assert np.all(replaced[start:start + 6400] == 0.0)
    np.testing.assert_array_equal(replaced[start + 6400:], reference.samples[start + 6400:])
    inserted = decode_wav(stress["stress_unrelated_insert400ms"]["processed_wav"]).samples
    assert len(inserted) == len(reference.samples) + 6400
    np.testing.assert_array_equal(inserted[:start], reference.samples[:start])
    np.testing.assert_array_equal(inserted[start + 6400:], reference.samples[start:])
    assert not np.array_equal(inserted[start:start + 6400], reference.samples[start:start + 6400])
    for side in ("start", "end"):
        crop = decode_wav(stress[f"stress_crop_{side}300ms"]["processed_wav"]).samples
        expected = reference.samples[4800:] if side == "start" else reference.samples[:-4800]
        np.testing.assert_array_equal(crop, expected)
    for name in ("stress_periodic_tone4s", "stress_silent_pair4s"):
        trial = stress[name]
        assert trial["source_kind"] == "synthetic_stress_signal"
        assert trial["reference_wav"] == trial["processed_wav"]
        assert decode_wav(trial["reference_wav"]).metadata()["duration_ms"] == 4000.0
    assert np.count_nonzero(decode_wav(stress["stress_silent_pair4s"]["reference_wav"]).samples) == 0


def test_pair_creation_is_deterministic_and_never_modifies_input():
    reference = _reference()
    before = reference.samples.copy()
    assert _trials(reference) == _trials(reference)
    np.testing.assert_array_equal(reference.samples, before)
    assert make_confirmation_signal(17).sha256 == make_confirmation_signal(17).sha256
    assert make_confirmation_signal(17).sha256 != make_confirmation_signal(18).sha256


def test_fixed_stress_content_keeps_canonical_group_across_other_originals():
    first = _trials()
    second = build_trials(make_confirmation_signal(19), source_group="another_source", source_kind="generated")
    for name in ("stress_periodic_tone4s", "stress_silent_pair4s"):
        left = next(trial for trial in first if trial["condition"] == name)
        right = next(trial for trial in second if trial["condition"] == name)
        assert left["source_group"] == right["source_group"]
        assert left["reference_wav"] == right["reference_wav"]
        assert left["processed_wav"] == right["processed_wav"]
        assert left["trial_id"] != right["trial_id"]


def test_fixed_stress_groups_do_not_claim_independence_from_resampling():
    low = _trials(_reference(rate=8000))
    high = _trials(_reference(rate=16000))
    for name in ("stress_periodic_tone4s", "stress_silent_pair4s"):
        assert next(trial for trial in low if trial["condition"] == name)["source_group"] == next(
            trial for trial in high if trial["condition"] == name
        )["source_group"]


@pytest.mark.parametrize("rate", [8000, 16000, 44100, 48000])
def test_confirmation_family_has_headroom_and_is_pcm16_nonperiodic(rate):
    audio = _reference(rate)
    assert audio.sample_rate_hz == rate
    assert audio.metadata()["duration_ms"] == 6000.0
    assert 0.179 <= np.max(np.abs(audio.samples)) <= 0.181
    np.testing.assert_array_equal(audio.samples * 32768, np.rint(audio.samples * 32768))
    assert not np.array_equal(audio.samples[:rate], audio.samples[rate:2 * rate])


@pytest.mark.parametrize("kwargs", [
    {"seed": True}, {"seed": -1}, {"seed": 2**64}, {"seed": 1.0},
    {"duration_seconds": True}, {"duration_seconds": 3.99}, {"duration_seconds": 12.01},
    {"duration_seconds": float("nan")}, {"duration_seconds": float("inf")},
    {"duration_seconds": 10**1000}, {"duration_seconds": "6"},
    {"rate": True}, {"rate": 16000.0}, {"rate": 22050},
])
def test_generator_rejects_invalid_contract(kwargs):
    settings = {"seed": 17, **kwargs}
    with pytest.raises(ValueError):
        make_confirmation_signal(**settings)


@pytest.mark.parametrize("kwargs", [
    {"reference": None}, {"source_group": ""}, {"source_group": "\nsecret"},
    {"source_group": "a" * 257}, {"source_kind": None}, {"source_kind": " "},
])
def test_builder_rejects_invalid_reference_or_metadata(kwargs):
    settings = {"reference": _reference(), "source_group": "dev", "source_kind": "generated", **kwargs}
    with pytest.raises(ValueError):
        build_trials(**settings)


@pytest.mark.parametrize("seconds", [2.0, 3.999, 12.001, 30.0])
def test_builder_rejects_otherwise_valid_audio_outside_fixed_evaluation_window(seconds):
    reference = WavAudio(np.zeros(round(seconds * 8000)), 8000, "0" * 64)
    with pytest.raises(ValueError):
        _trials(reference)


def test_builder_imports_no_detector_or_m1_generator():
    import audio_regression.evaluation_data as module
    tree = ast.parse(Path(module.__file__).read_text(encoding="utf-8"))
    imports = [node.module for node in ast.walk(tree) if isinstance(node, ast.ImportFrom)]
    assert not any(name and name.rsplit(".", 1)[-1] in {"engine", "baseline", "alignment", "features", "fixtures"} for name in imports)
