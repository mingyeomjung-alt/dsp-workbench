"""Owned-signal safety regressions; no sealed or natural-audio inputs.

The tie-selection injection below is intentionally a unit-level adversarial
path. It verifies fail-closed behavior even if a different equally scored
boundary is returned, not a natural-audio performance improvement.
"""

from __future__ import annotations

from copy import deepcopy

import numpy as np
import pytest

from audio_regression import context_engine
import audio_regression.instrument_engine as candidate
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.engine import EngineConfig


RATE = 8000


def _audio(values):
    return decode_wav(encode_wav(values, RATE))


def _owned_periodic_gap():
    rng = np.random.default_rng(480127)
    prefix = .12 * rng.normal(size=3 * RATE)
    suffix = .12 * rng.normal(size=3 * RATE)
    time = np.arange(2 * RATE) / RATE
    middle = .18 * np.sin(2 * np.pi * 400 * time)
    reference = _audio(np.concatenate((prefix, middle, suffix)))
    first, last = 4 * RATE, 4 * RATE + 3200
    processed = _audio(np.concatenate((reference.samples[:first], reference.samples[last:])))
    return reference, processed


def _forced_baseline(reference, reason):
    baseline, _ = context_engine.analyze_buffers_with_trace(reference, reference)
    baseline = deepcopy(baseline)
    baseline.update(status="withheld", content_preservation_status="withheld",
                    reason_code=reason, events=None)
    baseline.pop("alignment_segments", None)
    return baseline


def test_periodic_gap_between_unique_contexts_is_not_an_identifiable_deletion():
    reference, processed = _owned_periodic_gap()
    result, trace = candidate.analyze_buffers_with_trace(reference, processed)
    assert trace["fallback_attempted"] is True
    assert result["status"] == "withheld"
    assert result["events"] is None


def test_different_equally_scored_boundary_tie_stays_explicitly_ambiguous(monkeypatch):
    reference, processed = _owned_periodic_gap()
    original_boundary = candidate._boundary

    def choose_another_equal_peak(*args):
        observed = original_boundary(*args)
        assert observed is not None
        _, _, candidates = observed
        # 3,400 ms is inside the uniquely anchored retained spans. The true
        # synthetic cut was at 4,000 ms, but periodic content admits many exact
        # alternatives; no one of them is an identifiable temporal location.
        selected = next((point, score) for point, score in candidates if point == 3400 * 8)
        return selected[0], selected[1], candidates

    monkeypatch.setattr(candidate, "_boundary", choose_another_equal_peak)
    result, trace = candidate.analyze_buffers_with_trace(reference, processed)
    assert trace["fallback_attempted"] is True
    assert result["status"] == "withheld"
    assert result["reason_code"] == "raw_landmark_ambiguous_event_boundary"
    assert result["events"] is None


def test_group_total_spread_cannot_exceed_old_anchor_budget(monkeypatch):
    rng = np.random.default_rng(712830)
    reference = _audio(.1 * rng.normal(size=6 * RATE))
    baseline = _forced_baseline(reference, "insufficient_unambiguous_anchors")
    monkeypatch.setattr(candidate.context_engine, "analyze_buffers_with_trace",
                        lambda *args: (deepcopy(baseline), {}))
    points = [{"reference_start": start, "width": 1920, "offset": offset,
               "correlation": 1., "rival_margin": .4}
              for start, offset in zip((640, 1280, 1920), (0, -24, 24), strict=True)]
    monkeypatch.setattr(candidate, "_landmarks", lambda *args: (points, 3))
    result, _ = candidate.analyze_buffers_with_trace(reference, reference)
    assert result["status"] == "withheld"
    assert result["reason_code"] == "raw_landmark_unstable_group_offsets"


def test_short_dropout_cannot_hide_inside_global_average_residual():
    rng = np.random.default_rng(391647)
    reference = .1 * rng.normal(size=6 * RATE)
    processed = reference.copy()
    processed[24000:24160] = 0  # Twenty milliseconds, not a supported edit.
    average = np.sqrt(np.sum((processed - reference) ** 2) / np.sum(reference ** 2))
    assert average < .08
    assert candidate._window_consistent(reference, processed, 1.) is False
    _, reason = candidate._prove_matches(reference, processed, [(0, len(reference), 0)], EngineConfig())
    assert reason == "raw_landmark_unexplained_local_residual"


def test_edit_crossing_partial_match_cannot_become_a_landmark():
    rng = np.random.default_rng(521791)
    reference = .1 * rng.normal(size=6 * RATE)
    processed = reference.copy()
    processed[7200:7360] = 0
    landmarks, _ = candidate._landmarks(reference, processed, 24000, False)
    # Every configured window at this fixed grid position contains the change.
    assert all(point["reference_start"] != 6400 for point in landmarks)


@pytest.mark.parametrize("reason", (
    "resampling_not_declared", "non_silent_file_edge_change",
    "event_outside_supported_duration", "initial_delay_outside_declared_search",
    "cumulative_edit_shift_outside_budget", "insufficient_signal_variation",
))
def test_policy_withheld_reasons_are_not_eligible_for_fallback(monkeypatch, reason):
    rng = np.random.default_rng(718239)
    reference = _audio(.1 * rng.normal(size=3 * RATE))
    baseline = _forced_baseline(reference, reason)
    monkeypatch.setattr(candidate.context_engine, "analyze_buffers_with_trace",
                        lambda *args: (deepcopy(baseline), {}))
    monkeypatch.setattr(candidate, "_landmarks",
                        lambda *args: pytest.fail("Policy withholding must not run raw correspondence."))
    result, trace = candidate.analyze_buffers_with_trace(reference, reference)
    assert trace["fallback_attempted"] is False
    assert result["status"] == "withheld"
    assert result["reason_code"] == reason


@pytest.mark.parametrize("second_reference_gain", (.5, 1.))
def test_copy_payload_with_another_reference_occurrence_is_not_globally_unique(second_reference_gain):
    rng = np.random.default_rng(892141)
    reference = .1 * rng.normal(size=6 * RATE)
    first, length = 2 * RATE, 3200
    payload = reference[first:first + length].copy()
    other = 4 * RATE
    reference[other:other + length] = payload * second_reference_gain
    processed = np.concatenate((reference[:first + length], payload, reference[first + length:]))
    # A local search near the edit could hide the second reference occurrence.
    # Whole-reference NCC rivals must keep both gain-equivalent sources visible.
    copied = candidate._whole_adjacent_copy(reference, processed, first + length, length, 0, True)
    assert copied is None


def test_copy_matching_only_the_trimmed_middle_is_not_supported_repetition():
    rng = np.random.default_rng(413908)
    reference = .1 * rng.normal(size=6 * RATE)
    first, length = 2 * RATE, 3200
    payload = reference[first:first + length].copy()
    counterfeit = payload.copy()
    counterfeit[-160:] = .1 * rng.normal(size=160)
    # The full NCC remains above .90 and the trimmed middle is identical, but
    # the last twenty milliseconds of the copied payload are unrelated.
    assert .90 < candidate._corr(payload, counterfeit) < .99
    np.testing.assert_array_equal(payload[320:-320], counterfeit[320:-320])
    processed = np.concatenate((reference[:first + length], counterfeit, reference[first + length:]))
    copied = candidate._whole_adjacent_copy(reference, processed, first + length, length, 0, False)
    assert copied is None


def test_unique_complete_payload_copy_has_exact_source_and_added_gap():
    rng = np.random.default_rng(851234)
    reference = .1 * rng.normal(size=6 * RATE)
    first, length = 2 * RATE, 3200
    payload = reference[first:first + length]
    processed = np.concatenate((reference[:first + length], payload, reference[first + length:]))
    copied = candidate._whole_adjacent_copy(reference, processed, first + length, length, 0, False)
    assert copied is not None
    source, added, evidence = copied
    assert source == first
    assert added == source + length
    assert evidence["correlation"] >= .90
    assert evidence["adjacent_copy_correlation"] >= .90
