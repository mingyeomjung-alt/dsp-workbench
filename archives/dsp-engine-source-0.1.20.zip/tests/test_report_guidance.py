"""Contextual report guidance from saved diagnostics, without opening audio."""

import copy
from html.parser import HTMLParser
from pathlib import Path
import re

import pytest

from audio_regression.check_policy import check_result
from audio_regression.pipeline_reporting import _checkpoint, render_pipeline_html
from audio_regression.saved_pipeline_reporting import render_saved_pipeline_html
from test_pipeline_reporting import (
    analysis as pipeline_analysis,
    failed_fixture as pipeline_failed,
    fixture as pipeline_fixture,
)
from test_saved_pipeline_reporting import (
    analysis as saved_analysis,
    failed_fixture as saved_failed,
    fixture as saved_fixture,
    metadata,
)


class Sections(HTMLParser):
    """Extract visible section text and tags, without executing HTML."""

    def __init__(self, html):
        super().__init__()
        self.sections = []
        self.tags = []
        self._depth = 0
        self._current = None
        self._title_depth = 0
        self.feed(html)

    def handle_starttag(self, tag, attrs):
        self.tags.append((tag, dict(attrs)))
        if tag == "section":
            if self._depth == 0:
                self._current = {"title": [], "text": []}
            self._depth += 1
        if self._current is not None and tag == "h2":
            self._title_depth += 1

    def handle_endtag(self, tag):
        if tag == "h2" and self._title_depth:
            self._title_depth -= 1
        if tag == "section":
            self._depth -= 1
            if self._depth == 0:
                self.sections.append({
                    name: " ".join(" ".join(parts).split())
                    for name, parts in self._current.items()
                })
                self._current = None

    def handle_data(self, value):
        if self._current is not None:
            self._current["text"].append(value)
            if self._title_depth:
                self._current["title"].append(value)


def section(html, title):
    matches = [item["text"] for item in Sections(html).sections if item["title"] == title]
    assert len(matches) == 1, (title, matches)
    return matches[0]


def after_next_action(text):
    assert "다음 확인" in text
    return text.split("다음 확인", 1)[1]


REPORTERS = [
    pytest.param(pipeline_fixture, render_pipeline_html, pipeline_failed, id="runner"),
    pytest.param(saved_fixture, render_saved_pipeline_html, saved_failed, id="saved-audit"),
]


def second_stage_delete(factory):
    """Move the existing stored deletion to stage two; no detector is invoked."""
    value = factory("delete")
    first, second = value["stages"]
    first_output = metadata("b")
    first["output"] = first_output
    first["label"] = "외부 처리 1"
    second["label"] = "외부 처리 2"
    second["input"] = copy.deepcopy(first_output)
    if "operation" in first:
        operation = first["operation"]
        first["operation"] = {"kind": "gain", "label": first["label"], "gain_db": 0.0}
        second["operation"] = {**operation, "label": second["label"]}
        make_analysis = pipeline_analysis
    else:
        make_analysis = saved_analysis
    first_result = make_analysis(first["input"], first_output)
    first.update(status="analyzed", analysis=first_result, check=check_result(first_result), reason_code=None)
    second_result = make_analysis(second["input"], second["output"], "delete")
    if "operation" in second:
        second_result["configuration"]["allow_gain"] = False
    event = second_result["events"][0]
    # Different reference/output coordinates guard against treating both axes as
    # a single shared clock. These are validated saved records, not audio edits.
    event["reference_interval_ms"] = [2200.0, 2600.0]
    event["processed_boundary_ms"] = 2000.0
    event["evidence"].update(offset_before_ms=-200.0, offset_after_ms=-600.0)
    second_result["alignment_segments"] = [{
        "reference_interval_ms": [200.0, 2200.0], "processed_offset_ms": -200.0,
        "anchor_correlations": [.99, .99, .99],
    }]
    second.update(status="analyzed", analysis=second_result, check=check_result(second_result), reason_code=None)
    value["summary"]["first_concern"].update(stage_index=2, stage_label=second["label"])
    return value


@pytest.mark.parametrize("factory,render,failed", REPORTERS)
def test_stage_two_guidance_names_actual_previous_output_and_independent_clocks(factory, render, failed):
    value = second_stage_delete(factory)
    html = render(value)
    text = section(html, "02 외부 처리 2")
    assert "시간축과 비교 대상" in text
    assert "01 단계 · 외부 처리 1 출력" in text
    assert "02 단계 · 외부 처리 2 출력" in text
    assert value["stages"][1]["input_snapshot"] in text
    assert value["stages"][1]["output_snapshot"] in text
    assert "시작" in text and "초" in text
    assert ("직전" in text or "바로 앞" in text) and "원본" in text
    action = after_next_action(text)
    assert "2.2–2.6초" in action and "2초 전후" in action
    assert "01 단계 · 외부 처리 1 출력" in action
    assert "02 단계 · 외부 처리 2 출력" in action
    # The machine-readable event table remains in milliseconds for auditability.
    assert "2,200–2,600 ms" in text and "대응 경계 2,000 ms" in text


@pytest.mark.parametrize("factory,render,failed", REPORTERS)
def test_first_stage_and_end_guidance_distinguish_source_from_final_output(factory, render, failed):
    value = factory("delete")
    html = render(value)
    first = value["stages"][0]
    text = section(html, f'01 {first["label"]}')
    assert "시간축과 비교 대상" in text
    assert "원본" in text and first["input_snapshot"] in text
    assert f'01 단계 · {first["label"]} 출력' in text
    end = next(item["text"] for item in Sections(html).sections if item["title"].startswith("별도 검사"))
    last = value["stages"][-1]
    assert "시간축과 비교 대상" in end and "원본" in end
    assert f'최종 출력 · 02 단계 · {last["label"]} 출력' in end
    assert first["input_snapshot"] in end and last["output_snapshot"] in end
    assert "2–2.4초" in after_next_action(text)
    assert "2초 전후" in after_next_action(text)


@pytest.mark.parametrize("factory,render,failed", REPORTERS)
def test_first_concern_summary_gives_action_without_searching_stage_details(factory, render, failed):
    value = second_stage_delete(factory)
    text = section(render(value), "처음 관찰된 우려 지점")
    action = after_next_action(text)
    assert "01 단계 · 외부 처리 1 출력" in action
    assert "02 단계 · 외부 처리 2 출력" in action
    assert "2.2–2.6초" in action and "2초 전후" in action


def test_repeat_guidance_uses_source_and_canonical_added_interval_not_edit_history():
    value = saved_fixture("repeat")
    html = render_saved_pipeline_html(value)
    text = section(html, "01 외부 처리 1")
    action = after_next_action(text)
    assert "2–2.4초" in action and "2.4–2.8초" in action
    assert "원본" in action and "01 단계 · 외부 처리 1 출력" in action
    assert "복사" in action
    assert "편집" in action and ("확정" in action or "아닙" in action)
    assert "2,000–2,400 ms" in text and "2,400–2,800 ms" in text


@pytest.mark.parametrize("factory,render,failed", REPORTERS)
def test_clear_guidance_does_not_turn_no_candidate_into_whole_quality_approval(factory, render, failed):
    value = factory()
    html = render(value)
    for stage in value["stages"]:
        text = section(html, f'{stage["index"]:02d} {stage["label"]}')
        action = after_next_action(text)
        assert "전체 음질" in action
        assert "승인" in action and any(word in action for word in ("아닙", "뜻하지", "승인하지"))
        assert not re.search(r"\d+(?:\.\d+)?–\d+(?:\.\d+)?초", action)


@pytest.mark.parametrize("factory,render,failed", REPORTERS)
def test_withheld_guidance_explains_no_localized_interval_is_available(factory, render, failed):
    value = factory("withheld")
    first = value["stages"][0]
    text = section(render(value), f'01 {first["label"]}')
    action = after_next_action(text)
    assert "insufficient_unambiguous_anchors" in text
    assert "보류" in action or "확정" in action
    assert "입력" in action or "설정" in action or "사유" in action
    assert not re.search(r"\d+(?:\.\d+)?(?:–\d+(?:\.\d+)?)?초", action)


@pytest.mark.parametrize("factory,render,failed", REPORTERS)
def test_error_and_not_run_guidance_never_invents_event_intervals(factory, render, failed):
    value = failed()
    html = render(value)
    for stage in value["stages"]:
        text = section(html, f'{stage["index"]:02d} {stage["label"]}')
        action = after_next_action(text)
        assert "오류" in action or "수행" in action or "실행" in action or "미분석" in action
        assert not re.search(r"\d+(?:\.\d+)?(?:–\d+(?:\.\d+)?)?초", action)


def test_guidance_paths_and_labels_remain_escaped_inert_text():
    value = saved_fixture("repeat")
    stage = value["stages"][0]
    payload = '<img onerror="x"> & <script>x</script>'
    unsafe_path = 'snapshots/<img onerror="x"> & name.wav'
    html = _checkpoint(
        stage["analysis"], stage["check"],
        reference_name=payload, processed_name=payload,
        reference_snapshot=unsafe_path, processed_snapshot=unsafe_path,
    )
    assert payload not in html and unsafe_path not in html
    assert "&lt;img" in html and "&lt;script&gt;" in html and "&amp;" in html
    assert "<code>" in html and "시간축과 비교 대상" in html and "다음 확인" in html
    tags = Sections(html).tags
    assert not any(tag in {"a", "script", "audio", "video", "img", "iframe", "object", "embed", "form"}
                   for tag, _ in tags)
    assert not any(key.startswith("on") or key in {"href", "src"} for _, attrs in tags for key in attrs)


@pytest.mark.parametrize("factory,render,failed", REPORTERS)
def test_contextual_guidance_preserves_escaped_stage_labels_everywhere(factory, render, failed):
    value = second_stage_delete(factory)
    payload = '<script>x</script><img onerror="x"> &'
    stage = value["stages"][0]
    stage["label"] = payload
    if "operation" in stage:
        stage["operation"]["label"] = payload
    html = render(value)
    stage_two = section(html, "02 외부 처리 2")
    assert payload in stage_two  # HTMLParser decodes escaped visible text.
    assert payload not in html and "&lt;script&gt;" in html
    assert not any(tag in {"a", "script", "img", "audio"} for tag, _ in Sections(html).tags)


@pytest.mark.parametrize("factory,render,failed", REPORTERS)
def test_rendering_guidance_is_deterministic_nonmutating_and_never_opens_audio(factory, render, failed, monkeypatch):
    from audio_regression import api, audio, engine

    def forbidden(*args, **kwargs):
        pytest.fail("Report guidance attempted file access or audio analysis.")

    for module, name in [(api, "analyze_pair"), (audio, "read_wav"), (audio, "decode_wav"),
                         (engine, "analyze_buffers"), (engine, "analyze_wavs")]:
        monkeypatch.setattr(module, name, forbidden)
    monkeypatch.setattr(Path, "open", forbidden)
    value = second_stage_delete(factory)
    before = copy.deepcopy(value)
    html = render(value)
    assert html == render(value)
    assert value == before
    assert "시간축과 비교 대상" in html and "다음 확인" in html
