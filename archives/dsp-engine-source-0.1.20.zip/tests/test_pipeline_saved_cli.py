import json

import pytest

from audio_regression import pipeline_cli
from audio_regression.audio import decode_wav
from audio_regression.fixtures import generate_case
from audio_regression.pipeline_transforms import execute_stage


def _inputs(tmp_path, defect=None):
    raw = generate_case("clean", seed=58891).reference_wav
    (tmp_path / "original.wav").write_bytes(raw)
    order = list(range(15))
    if defect == "delete":
        order.remove(5)
    elif defect == "repeat":
        order.insert(6, 5)
    middle, _ = execute_stage(decode_wav(raw), {"kind": "split_join", "segment_ms": 400, "order": order})
    last, _ = execute_stage(decode_wav(middle), {"kind": "gain", "gain_db": -6})
    (tmp_path / "middle.wav").write_bytes(middle)
    (tmp_path / "last.wav").write_bytes(last)
    manifest = tmp_path / "manifest.json"
    manifest.write_text(json.dumps({
        "schema_version": 1, "source": "original.wav", "stages": [
            {"label": "저장된 중간 출력", "output": "middle.wav", "declaration": {"allow_gain": False, "allow_resampling": False}},
            {"label": "후속 음량 변경", "output": "last.wav", "declaration": {"allow_gain": True, "allow_resampling": False}},
        ],
    }), encoding="utf-8")
    return manifest


@pytest.mark.parametrize("defect,expected", [(None, 0), ("delete", 1), ("repeat", 1)])
def test_saved_audit_cli_preserves_files_and_prior_concern(tmp_path, capsys, defect, expected):
    manifest = _inputs(tmp_path, defect)
    originals = {path: path.read_bytes() for path in tmp_path.glob("*.wav")}
    output = tmp_path / "audit"
    assert pipeline_cli.main(["audit", "--manifest", str(manifest), "--output-dir", str(output)]) == expected
    summary = json.loads(capsys.readouterr().out)
    assert summary["caller_order_verified"] is False
    assert summary["complete_audio_approval"] is False
    assert summary["input_recheck"] == {"status": "unchanged", "file_indices": []}
    if defect:
        assert summary["first_concern"]["stage_index"] == 1
    assert (output / "audit_result.json").is_file()
    assert (output / "audit_report.html").is_file()
    assert all(path.read_bytes() == raw for path, raw in originals.items())


def test_saved_report_is_exclusive_and_does_not_reanalyse(tmp_path, capsys, monkeypatch):
    manifest = _inputs(tmp_path)
    output = tmp_path / "audit"
    assert pipeline_cli.main(["audit", "--manifest", str(manifest), "--output-dir", str(output)]) == 0
    capsys.readouterr()

    def forbidden(*args, **kwargs):
        pytest.fail("Stored audit-report must not analyse audio again.")

    monkeypatch.setattr(pipeline_cli, "audit_saved_pipeline", forbidden)
    report = tmp_path / "new_report.html"
    assert pipeline_cli.main(["audit-report", "--input", str(output / "audit_result.json"), "--output", str(report)]) == 0
    capsys.readouterr()
    before = report.read_bytes()
    assert pipeline_cli.main(["audit-report", "--input", str(output / "audit_result.json"), "--output", str(report)]) == 3
    assert json.loads(capsys.readouterr().out)["reason_code"] == "output_exists"
    assert report.read_bytes() == before


@pytest.mark.parametrize("bad", [
    '{"schema_version":1,"schema_version":1,"source":"original.wav","stages":[]}',
    '{"schema_version":99,"source":"original.wav","stages":[]}',
    '{"schema_version":1,"source":"../original.wav","stages":[]}',
    '{"schema_version":1,"source":"original.wav","stages":[{"command":"unsafe"}]}',
])
def test_bad_saved_manifest_never_creates_output(tmp_path, capsys, bad):
    manifest = tmp_path / "manifest.json"
    manifest.write_text(bad, encoding="utf-8")
    output = tmp_path / "audit"
    assert pipeline_cli.main(["audit", "--manifest", str(manifest), "--output-dir", str(output)]) == 3
    assert json.loads(capsys.readouterr().out)["gate_state"] == "blocked"
    assert not output.exists()


def test_audit_refuses_existing_directory(tmp_path, capsys):
    manifest = _inputs(tmp_path)
    output = tmp_path / "audit"
    output.mkdir()
    sentinel = output / "sentinel.txt"
    sentinel.write_text("keep", encoding="utf-8")
    assert pipeline_cli.main(["audit", "--manifest", str(manifest), "--output-dir", str(output)]) == 3
    assert json.loads(capsys.readouterr().out)["gate_state"] == "blocked"
    assert sentinel.read_text(encoding="utf-8") == "keep"


def test_native_result_is_not_mislabelled_as_saved_audit(tmp_path, capsys):
    manifest = _inputs(tmp_path)
    plan = tmp_path / "native_plan.json"
    plan.write_text('{"schema_version":1,"stages":[{"kind":"gain","gain_db":-6}]}', encoding="utf-8")
    output = tmp_path / "native"
    assert pipeline_cli.main(["run", "--source", str(tmp_path / "original.wav"), "--plan", str(plan), "--output-dir", str(output)]) == 0
    capsys.readouterr()
    report = tmp_path / "incorrect_report.html"
    assert pipeline_cli.main(["audit-report", "--input", str(output / "run_result.json"), "--output", str(report)]) == 3
    assert json.loads(capsys.readouterr().out)["gate_state"] == "blocked"
    assert not report.exists()
