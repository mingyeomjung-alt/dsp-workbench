"""Explicit M2 endpoint-loss facade/CLI checks, not customer accuracy."""
from copy import deepcopy
import hashlib
import json

import numpy as np
import pytest

from audio_regression.api import analyze_pair, analyze_pair_with_trace
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.check_policy import check_result
from audio_regression.engine import EngineConfigError
from audio_regression.fixtures import generate_case
from audio_regression.handoff_cli import main
from audio_regression.reporting import render_html
from audio_regression.result_contract import ResultContractError, validate_analysis_result


def pair(tmp_path, side, *, damage=False, internal=False):
    wav = generate_case(seed=202610157851, duration_seconds=4).reference_wav
    x = decode_wav(wav).samples
    length = 1600
    y = x[length:] if side == "head" else x[:-length]
    if internal:
        y = np.concatenate((x[:16000], x[17600:]))
    if damage:
        y = y.copy()
        y[len(y) // 2] += 1 / 32768
    reference, processed = tmp_path / "reference.wav", tmp_path / "processed.wav"
    reference.write_bytes(wav)
    processed.write_bytes(encode_wav(y, 16000))
    return reference, processed


@pytest.mark.parametrize("side", ["head", "tail"])
def test_opt_in_endpoint_api_has_one_real_retained_side(tmp_path, side):
    original, processed = pair(tmp_path, side)
    hashes = [hashlib.sha256(p.read_bytes()).hexdigest() for p in (original, processed)]
    result, trace = analyze_pair_with_trace(original, processed, engine="v11")
    assert result == analyze_pair(original, processed, engine="v11")
    assert validate_analysis_result(result) is result
    assert result["status"] == "analyzed" and result["engine"] == "local_content_alignment_v11"
    event = result["events"][0]
    assert event["location"] == side and event["type"] == "delete"
    assert event["reference_interval_ms"] == ([0, 100] if side == "head" else [3900, 4000])
    assert event["processed_boundary_ms"] == (0 if side == "head" else 3900)
    assert "offset_before_ms" not in event["evidence"] and "offset_after_ms" not in event["evidence"]
    assert event["evidence"]["all_retained_native_samples_exact"] is True
    assert len(result["alignment_segments"]) == result["diagnostics"]["anchor_run_count"] == 1
    assert trace["endpoint_loss_proved"] is True
    assert check_result(result)["exit_code"] == 1
    assert hashes == [hashlib.sha256(p.read_bytes()).hexdigest() for p in (original, processed)]
    assert analyze_pair(original, original)["engine"] == "local_content_alignment_v1"


@pytest.mark.parametrize("side", ["head", "tail"])
def test_untouched_side_single_sample_damage_never_passes(tmp_path, side):
    original, processed = pair(tmp_path, side, damage=True)
    result, trace = analyze_pair_with_trace(original, processed, engine="v11")
    assert result["status"] == "withheld" and result["events"] is None
    assert trace["endpoint_loss_proved"] is False
    assert check_result(result)["gate_state"] == "blocked"
    review = result["review_diagnostics"]
    assert review["trace_availability"] == "recorded"
    assert review["stages"][-1]["engine"] == "local_content_alignment_v11"


def test_internal_M1_candidate_keeps_native_method_and_geometry(tmp_path):
    original, processed = pair(tmp_path, "head", internal=True)
    old, _ = analyze_pair_with_trace(original, processed, engine="v10")
    result, trace = analyze_pair_with_trace(original, processed, engine="v11")
    assert trace["endpoint_loss_attempted"] is False
    assert trace["proof_path"] == "preserved_v10_result"
    assert result["events"] == old["events"]
    assert result["analysis"] == old["analysis"]
    assert result["diagnostics"] == old["diagnostics"]
    assert "location" not in result["events"][0]


def test_cli_check_and_report_distinguish_endpoint_loss(tmp_path, capsys):
    original, processed = pair(tmp_path, "head")
    output, report = tmp_path / "result.json", tmp_path / "report.html"
    assert main(["analyze", "--engine", "v11", "--reference", str(original),
                 "--processed", str(processed), "--output", str(output)]) == 0
    capsys.readouterr()
    assert main(["check", "--input", str(output)]) == 1
    assert json.loads(capsys.readouterr().out)["complete_audio_approval"] is False
    assert main(["report", "--input", str(output), "--output", str(report)]) == 0
    capsys.readouterr()
    text = report.read_text(encoding="utf-8")
    assert "시작부분 누락 후보" in text and "보존된 한쪽 문맥" in text
    assert "이벤트 이전 오프셋" not in text and "이벤트 이후 오프셋" not in text
    old = report.read_bytes()
    assert main(["report", "--input", str(output), "--output", str(report)]) == 3
    assert old == report.read_bytes()


@pytest.mark.parametrize("mutation", ["side", "missing_side_evidence", "full_approval"])
def test_endpoint_result_cannot_forge_geometry_or_two_sided_evidence(tmp_path, mutation):
    original, processed = pair(tmp_path, "tail")
    result = deepcopy(analyze_pair(original, processed, engine="v11"))
    if mutation == "side":
        result["events"][0]["location"] = "head"
    elif mutation == "missing_side_evidence":
        result["events"][0]["evidence"]["offset_before_ms"] = 0
    else:
        result["complete_audio_approval"] = True
    with pytest.raises(ResultContractError):
        validate_analysis_result(result)


@pytest.mark.parametrize("kwargs", [{"profile": "telephone"}, {"engine": "v13"}])
def test_bad_edge_configuration_before_audio_read(kwargs):
    with pytest.raises(EngineConfigError):
        analyze_pair("missing.wav", "also-missing.wav", **{"engine": "v11", **kwargs})
