"""Save owned development pairs and v5/v6 proof traces, without external audio.

Regenerates an analytic recipe, never opens old trial or sealed inputs. Output
must be absent. No external processors, network, restored audio or publication.
"""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.signal import resample_poly

import audio_regression
from audio_regression.api import analyze_pair_with_trace
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.check_policy import check_result
from audio_regression.reporting import write_html_report


def _json_new(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def _pcm(values, rate):
    return decode_wav(encode_wav(values, rate)).samples


def _owned_signal():
    t = np.arange(8 * 16000) / 16000
    f = 311 + 17 * t + 2.3 * np.sin(2 * np.pi * .61 * t)
    phase = 2 * np.pi * np.cumsum(f) / 16000
    envelope = .57 + .13 * np.sin(2 * np.pi * .29 * t) + .09 * np.sin(2 * np.pi * .11 * t + .8)
    values = envelope * (np.sin(phase) + .27 * np.sin(2 * phase + .3) + .13 * np.sin(3 * phase + .9))
    source = _pcm(values * (.28 / np.max(np.abs(values))), 16000)
    gained = _pcm(source * .5, 16000)
    down = _pcm(resample_poly(gained, 1, 2), 8000)
    return _pcm(np.concatenate((np.zeros(1920), down)), 8000)


def run(output: Path):
    if output.exists():
        raise FileExistsError("Existing development output is never replaced.")
    output.mkdir(parents=False)
    values = _owned_signal()
    first, last = 21120, 24320
    fake = values[first:last].copy()
    fake[-160:] = .1 * np.random.default_rng(28546).normal(size=160)
    cases = {"normal": values,
             "delete": np.concatenate((values[:first], values[last:])),
             "repeat": np.concatenate((values[:last], values[first:last], values[last:])),
             "counterfeit": np.concatenate((values[:last], fake, values[last:]))}
    rows = []
    for name, target in cases.items():
        folder = output / name
        folder.mkdir()
        a, b = folder / "reference.wav", folder / "processed.wav"
        a.write_bytes(encode_wav(values, 8000))
        b.write_bytes(encode_wav(target, 8000))
        hashes = [hashlib.sha256(p.read_bytes()).hexdigest() for p in (a, b)]
        for engine in ("v5", "v6"):
            result, trace = analyze_pair_with_trace(a, b, engine=engine)
            gate = check_result(result)
            _json_new(folder / (engine + ".json"), result)
            _json_new(folder / (engine + "_trace.json"), trace)
            write_html_report(result, folder / (engine + ".html"))
            expected = "withheld" if name == "counterfeit" or (name == "repeat" and engine == "v5") else "analyzed"
            rows.append({"case": name, "engine": engine, "status": result["status"],
                         "reason_code": result["reason_code"], "events": result["events"],
                         "check_exit_code": gate["exit_code"], "expectation_met": result["status"] == expected,
                         "proof_count": trace.get("candidate_proofs_attempted"),
                         "feasible_geometry_clusters": trace.get("feasible_geometry_cluster_count")})
        if hashes != [hashlib.sha256(p.read_bytes()).hexdigest() for p in (a, b)]:
            raise RuntimeError("Input changed during analysis.")
    summary = {"schema_version": 1, "package_version": audio_regression.__version__,
               "owned_development_only": True, "independent_accuracy_established": False,
               "old_saved_trial_or_sealed_inputs_read": False, "input_unchanged": True,
               "expectations_met": sum(r["expectation_met"] for r in rows), "total": len(rows), "rows": rows}
    _json_new(output / "summary.json", summary)
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args(argv)
    summary = run(args.output_dir)
    print(json.dumps({"summary": str(args.output_dir / "summary.json"),
                      "expectations_met": summary["expectations_met"], "total": summary["total"]}))
    return 0 if summary["expectations_met"] == summary["total"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
