"""Copy primary installed dependency notices to a new, explicit local directory.

This collects notices, not dependency binaries, model weights, audio or keys.
No remote requests and no overwrites. Original notice bytes and hashes survive.
"""

import argparse
import hashlib
import importlib.metadata as metadata
import json
from pathlib import Path


def collect(output: Path) -> dict:
    target = output.resolve()
    if target.exists():
        raise FileExistsError("Notice destination already exists.")
    sources = []
    for name in ("numpy", "scipy"):
        distribution = metadata.distribution(name)
        for member in distribution.files or ():
            relative = Path(str(member))
            if any(part == ".." for part in relative.parts):
                continue
            lowered = relative.name.lower()
            if ("license" not in lowered and "copying" not in lowered and "notice" not in lowered):
                continue
            candidate = Path(distribution.locate_file(member))
            if not candidate.is_file() or candidate.is_symlink():
                continue
            # Recorded distribution files only; reject large/non-text surprises.
            payload = candidate.read_bytes()
            if len(payload) > 2_000_000:
                raise ValueError("An installed notice exceeds the size limit.")
            payload.decode("utf-8")
            sources.append((name, distribution.version, relative, payload))
    if not all(any(item[0] == name for item in sources) for name in ("numpy", "scipy")):
        raise ValueError("Complete installed dependency notice roots were not found.")
    target.mkdir(parents=True, exist_ok=False)
    inventory = []
    for name, version, relative, payload in sources:
        archive_name = Path(name) / relative
        if archive_name.suffix.lower() not in {".txt", ".md", ".json"}:
            archive_name = archive_name.with_name(archive_name.name + ".txt")
        destination = target / archive_name
        destination.parent.mkdir(parents=True, exist_ok=True)
        with destination.open("xb") as stream:
            stream.write(payload)
        inventory.append({"distribution": name, "version": version,
                          "installed_member": relative.as_posix(),
                          "copied_member": archive_name.as_posix(),
                          "sha256": hashlib.sha256(payload).hexdigest()})
    result = {"schema_version": 1, "scope": "installed_notice_files_not_dependencies_or_legal_clearance",
              "notice_count": len(inventory), "records": inventory}
    with (target / "inventory.json").open("x", encoding="utf-8") as stream:
        json.dump(result, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    result = collect(args.output_dir)
    print(json.dumps({"status": "collected", "notice_count": result["notice_count"]}))


if __name__ == "__main__":
    main()
