"""Generate new owned event/compound examples; never read consumed audio.

No numeric gain is passed to the detector. No network or processor execution.
Outputs must be new. Baseline abstention is not event-detection success.
"""
import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.signal import resample_poly

import audio_regression
from audio_regression.api import analyze_pair_with_trace
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.check_policy import check_result
from audio_regression.reporting import write_html_report

Q = 1 / 32768


def _pcm(values, rate):
    return decode_wav(encode_wav(values, rate)).samples


def _source():
    t = np.arange(8 * 16000) / 16000
    phase = 2 * np.pi * (313 * t + 17 * t * t + .41 * np.sin(1.9 * t))
    loud = .16 * (np.sin(phase) + .23 * np.sin(1.63 * phase + .7)
                  + .13 * np.sin(2.39 * phase - .5))
    quiet = .8 * Q * np.sin(2 * np.pi * (2837 * t + 13 * t * t))
    return _pcm(np.where(t < 6.4, loud, quiet), 16000)


def _integration_source():
    """Reproduce the separate newly defined integration equation, not new evidence."""
    t = np.arange(9 * 16000) / 16000
    phase = 2 * np.pi * (313 * t + 17 * t * t + .23 * np.sin(1.9 * t))
    loud = .16 * (np.sin(phase) + .21 * np.sin(1.43 * phase + .3)
                  + .13 * np.sin(2.19 * phase - .2)) * (.72 + .20 * np.sin(.83 * t) ** 2)
    quiet = .55 * Q * np.sin(2 * np.pi * (2730 * t + 9 * t * t))
    return _pcm(np.where(t < 7, loud, quiet), 16000)


def _process(values, gain=.527381421, leading_samples=1408):
    gained = _pcm(values * gain, 16000)
    output = _pcm(resample_poly(gained, 1, 2), 8000)
    return np.concatenate((np.zeros(leading_samples), output))


def _new_json(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def _event_matches(result, name):
    if result["status"] != "analyzed" or len(result["events"]) != 1:
        return False
    event = result["events"][0]
    duration = 600 if name.endswith("600ms") else 400
    lead = 240 if duration == 600 else 176
    if name.startswith("delete_"):
        return (event["type"] == "delete"
                and all(abs(a - b) <= 20 for a, b in zip(event["reference_interval_ms"], [3000, 3000 + duration]))
                and abs(event["processed_boundary_ms"] - (3000 + lead)) <= 20)
    return (event["type"] == "repeat"
            and all(abs(a - b) <= 20 for a, b in zip(event["reference_source_interval_ms"], [3000, 3000 + duration]))
            and all(abs(a - b) <= 20 for a, b in zip(event["processed_added_interval_ms"],
                                                [3000 + duration + lead, 3000 + 2 * duration + lead])))


def run(output):
    if output.exists():
        raise FileExistsError("Existing output is never replaced.")
    output.mkdir(parents=False)
    reference = _source()
    deleted = np.concatenate((reference[:48000], reference[54400:]))
    repeated = np.concatenate((reference[:54400], reference[48000:54400], reference[54400:]))
    corrupt = _process(deleted)
    assert np.count_nonzero(corrupt[-8000:]) > 0
    corrupt[-8000:] = 0
    noise_t = np.arange(6400) / 16000
    # This is an internal 400ms source fragment, not a standalone input WAV.
    inserted = np.minimum(np.rint(.11 * np.sin(2 * np.pi * (773 * noise_t + 43 * noise_t * noise_t)) * 32768), 32767) / 32768
    unknown = np.concatenate((reference[:54400], inserted, reference[54400:]))
    multiple = np.concatenate((reference[:48000], reference[54400:80000], reference[86400:]))
    targets = {"normal": _process(reference), "delete_400ms": _process(deleted),
             "repeat_400ms": _process(repeated), "delete_with_quiet_erasure": corrupt,
             "unknown_insert": _process(unknown), "two_deletions": _process(multiple),
             "start_truncation": _process(reference[6400:])}
    cases = {name: (reference, samples) for name, samples in targets.items()}
    secondary = _integration_source()
    for kind in ("delete", "repeat"):
        edited = (np.concatenate((secondary[:48000], secondary[57600:])) if kind == "delete" else
                  np.concatenate((secondary[:57600], secondary[48000:57600], secondary[57600:])))
        cases[kind + "_600ms"] = (secondary, _process(edited, 10 ** (-6 / 20), 1920))
    event_cases = {"delete_400ms", "repeat_400ms", "delete_600ms", "repeat_600ms"}
    rows = []
    for name, (case_reference, samples) in cases.items():
        folder = output / name
        folder.mkdir()
        a, b = folder / "reference.wav", folder / "processed.wav"
        a.write_bytes(encode_wav(case_reference, 16000))
        b.write_bytes(encode_wav(samples, 8000))
        hashes = [hashlib.sha256(p.read_bytes()).hexdigest() for p in (a, b)]
        for engine in ("v7", "v8"):
            result, trace = analyze_pair_with_trace(a, b, engine=engine, allow_gain=True, allow_resampling=True)
            _new_json(folder / (engine + ".json"), result)
            _new_json(folder / (engine + "_trace.json"), trace)
            write_html_report(result, folder / (engine + ".html"))
            if name == "normal":
                met = result["status"] == "analyzed" and not result["events"]
            elif name in event_cases:
                met = _event_matches(result, name) if engine == "v8" else (
                    result["status"] == "withheld" or _event_matches(result, name))
            else:
                met = result["status"] == "withheld"
            rows.append({"case": name, "engine": engine, "status": result["status"],
                         "reason_code": result["reason_code"], "events": result["events"],
                         "expected_behavior_met": met, "check_exit_code": check_result(result)["exit_code"],
                         "truth_event_detected": _event_matches(result, name)
                            if name in event_cases else None,
                         "proof_path": trace.get("proof_path"),
                         "event_proved": trace.get("compound_event_proved")})
        if hashes != [hashlib.sha256(p.read_bytes()).hexdigest() for p in (a, b)]:
            raise RuntimeError("An input changed during analysis.")
    summary = {"schema_version": 1, "package_version": audio_regression.__version__,
               "owned_development_only": True, "original_signal_formulas": 2, "conditions": len(cases),
               "second_formula_reproduces_new_integration_fixture_not_independent_evidence": True,
               "numeric_gain_passed_to_detector": False, "old_saved_trials_or_sealed_inputs_read": False,
               "input_unchanged": True, "independent_accuracy_established": False,
               "expected_behaviors_met": sum(row["expected_behavior_met"] for row in rows),
               "total": len(rows), "rows": rows}
    _new_json(output / "summary.json", summary)
    print(json.dumps({"summary": str(output / "summary.json"),
                      "expected_behaviors_met": summary["expected_behaviors_met"], "total": summary["total"]}))
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args(argv)
    result = run(args.output_dir)
    return 0 if result["expected_behaviors_met"] == result["total"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
