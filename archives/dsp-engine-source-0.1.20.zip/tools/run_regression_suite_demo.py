"""Owned 20-case suite exercise; not real-world accuracy or a release approval.

The expected changes are declared before the runner executes. Every WAV is
generated locally from a new deterministic seed. No private recording, public
dataset, external API, or old benchmark is consumed. Existing outputs are never
overwritten. The engine remains the user's explicit v11 choice in this demo.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

import numpy as np

from audio_regression.audio import decode_wav, encode_wav
from audio_regression.fixtures import generate_case


RATE = 8000
SEED = 202610157801
CONFIGURATION = {"engine": "v11", "allow_gain": False, "allow_resampling": False,
                 "max_delay_ms": 1000.0, "resampling_model": None}
EXPECTED_SUMMARY = {"case_count": 20, "completed_count": 20, "error_count": 0, "not_run_count": 0,
                    "new_candidate_count": 9, "persistent_candidate_count": 3,
                    "not_observed_now_count": 4, "inconclusive_case_count": 5,
                    "current_gate_state": "blocked", "regression_state": "inconclusive", "exit_code": 2}


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _save(path: Path, value: object) -> None:
    with path.open("x", encoding="utf-8", newline="\n") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def _edit(values: np.ndarray, kind: str, at_ms: int = 2000, duration_ms: int = 100) -> np.ndarray:
    at, count = at_ms * RATE // 1000, duration_ms * RATE // 1000
    if kind == "identity":
        return values.copy()
    if kind == "delete":
        return np.concatenate((values[:at], values[at + count:]))
    if kind == "repeat":
        return np.concatenate((values[:at], values[at - count:at], values[at:]))
    if kind == "head":
        return values[count:].copy()
    if kind == "tail":
        return values[:-count].copy()
    if kind == "one_lsb_head":
        changed = values[count:].copy()
        changed[len(changed) // 2] += 1 / 32768
        return changed
    raise ValueError("Unknown owned fixture operation")


def create_demo_inputs(output: Path) -> dict:
    """Create exactly 20 independently seeded owned cases and locked expectations."""
    if output.exists():
        raise ValueError("Use a new output directory; existing evidence is preserved")
    output.mkdir(parents=True)
    audio = output / "audio"
    audio.mkdir()
    # case, baseline operation, candidate operation, parameters, expected state.
    # Error/withheld cases explicitly expect no inferred improvement.
    specs = [
        ("clear", "identity", "identity", {}, "compared", 0, 0, 0),
        ("new-delete", "identity", "delete", {}, "compared", 1, 0, 0),
        ("new-repeat", "identity", "repeat", {}, "compared", 1, 0, 0),
        ("persistent-delete", "delete", "delete", {}, "compared", 0, 1, 0),
        ("persistent-repeat", "repeat", "repeat", {}, "compared", 0, 1, 0),
        ("delete-not-observed", "delete", "identity", {}, "compared", 0, 0, 1),
        ("repeat-not-observed", "repeat", "identity", {}, "compared", 0, 0, 1),
        ("new-head-loss", "identity", "head", {}, "compared", 1, 0, 0),
        ("new-tail-loss", "identity", "tail", {}, "compared", 1, 0, 0),
        ("shifted-delete", "delete", "delete", {"candidate_at_ms": 3000}, "compared", 1, 0, 1),
        ("changed-event-type", "delete", "repeat", {}, "compared", 1, 0, 1),
        ("candidate-one-lsb", "identity", "one_lsb_head", {}, "inconclusive", 0, 0, 0),
        ("baseline-one-lsb", "one_lsb_head", "identity", {}, "inconclusive", 0, 0, 0),
        ("both-one-lsb", "one_lsb_head", "one_lsb_head", {}, "inconclusive", 0, 0, 0),
        ("periodic-ambiguity", "identity", "head", {"periodic": True}, "inconclusive", 0, 0, 0),
        ("new-200ms-delete", "identity", "delete", {"duration_ms": 200}, "compared", 1, 0, 0),
        ("persistent-head-loss", "head", "head", {"duration_ms": 500}, "compared", 0, 1, 0),
        ("new-50ms-delete", "identity", "delete", {"duration_ms": 50}, "compared", 1, 0, 0),
        ("new-200ms-repeat", "identity", "repeat", {"duration_ms": 200}, "compared", 1, 0, 0),
        # Overlapping, non-identical source witnesses cannot establish whether
        # an event grew, was replaced, or reflects a different explanation.
        ("changed-endpoint-loss", "head", "head", {"candidate_duration_ms": 200}, "inconclusive", 0, 0, 0),
    ]
    cases, expectations = [], {}
    for index, (case_id, baseline_kind, candidate_kind, options, status, new, persistent, absent) in enumerate(specs):
        values = decode_wav(generate_case(seed=SEED + index, duration_seconds=6,
                                         sample_rate_hz=RATE).reference_wav).samples
        if options.get("periodic"):
            values = np.tile(values[:800], 60)
        baseline = _edit(values, baseline_kind, duration_ms=options.get("duration_ms", 100))
        candidate = _edit(values, candidate_kind,
                          at_ms=options.get("candidate_at_ms", 2000),
                          duration_ms=options.get("candidate_duration_ms", options.get("duration_ms", 100)))
        payloads = {"source": encode_wav(values, RATE), "baseline": encode_wav(baseline, RATE),
                    "candidate": encode_wav(candidate, RATE)}
        case = {"case_id": case_id, "configuration": dict(CONFIGURATION)}
        for role, payload in payloads.items():
            relative = f"audio/{index:02d}-{case_id}-{role}.wav"
            path = output / relative
            with path.open("xb") as stream:
                stream.write(payload)
            case[role] = {"path": relative, "sha256": _sha(path)}
        cases.append(case)
        expectations[case_id] = {"status": status, "new_count": new, "persistent_count": persistent,
                                 "not_observed_now_count": absent,
                                 "error_expected": False}
    manifest = {"schema_version": 1, "suite_id": "owned-regression-demo-20",
                "baseline_version": "owned-baseline-A", "candidate_version": "owned-candidate-B", "cases": cases}
    _save(output / "suite.json", manifest)
    _save(output / "protocol.json", {"schema_version": 1,
        "created_at": datetime.now(timezone.utc).isoformat(), "seed_start": SEED,
        "case_count": 20, "locked_before_execution": True, "manifest_sha256": _sha(output / "suite.json"),
        "scope": "Owned synthetic native v11 PCM16 8kHz examples; unsupported WAVs are separate safety tests",
        "cases_independent_real_world_accuracy_trials": False,
        "customer_recordings_datasets_or_sealed_old_benchmarks_used": False,
        "expectations": expectations, "expected_summary": EXPECTED_SUMMARY})
    return {"manifest": manifest, "expectations": expectations}


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, required=True, help="New evidence directory")
    parser.add_argument("--inputs-only", action="store_true", help="Create fixtures without executing")
    parser.add_argument("--preservation-root", type=Path,
                        help="Optional workspace containing the frozen 0.1.19 SDK and Windows artifacts")
    return parser


def _engine_freeze() -> dict[str, str]:
    """Bind existing detectors and their schemas, not the new suite implementation."""
    import audio_regression
    package = Path(audio_regression.__file__).parent
    names = ("api.py", "audio.py", "engine.py", "profiles.py", "baseline.py", "fixtures.py",
             "analysis_scope.py", "robust_engine.py", "context_engine.py", "instrument_engine.py",
             "canonical_engine.py", "repeat_engine.py", "compound_engine.py", "compound_gain.py",
             "compound_event_engine.py", "compound_event_proof.py", "global_context_engine.py",
             "short_event_engine.py", "edge_event_engine.py", "resampler_engine.py",
             "result_contract.py", "short_event_result_contract.py", "edge_event_result_contract.py",
             "resampler_result_contract.py", "endpoint_mapping.py", "reporting.py", "check_policy.py")
    freeze = {name: _sha(package / name) for name in names}
    freeze.update({"schemas/" + path.name: _sha(path)
                   for path in sorted((package / "schemas").glob("analysis-result-*.schema.json"))})
    return freeze


def preservation_audit(root: Path | None) -> dict:
    """Verify actual prior bytes against pinned completed-release digests."""
    if root is None:
        return {"status": "not_requested", "old_artifacts_modified": False}
    pinned = {
        "dsp_engine/deliverables/workbench_release_20261015_v3/dist/audio_regression_engine-0.1.19-py3-none-any.whl":
            "3de1580f5339ac8a42830352502a44dc919d6528c2017720d6797c1119c0eb22",
        "dsp_engine/deliverables/workbench_release_20261015_v3/dsp-source.zip":
            "bc3e5130b76abbc078e60fbd57f7b4108fb8ecd1ccd62be1818c73810e5cbb9d",
        "dsp_engine/deliverables/windows_portable_20261015_v2/DSPWorkbench-0.1.19-win1-x64.zip":
            "148b8c4156258dc4374a3e5f05085cd0d6b8c735c3cde4542862e03cbfb0ef7a",
        "dsp_engine/deliverables/windows_portable_20261015_v2/app/DSPWorkbench/DSPWorkbench.exe":
            "06e42fa68fdbe90503e591835673471b559fe26a4669bdc23013c99ada28a906",
    }
    artifacts = {relative: {"expected_sha256": expected, "actual_sha256": _sha(root / relative)}
                 for relative, expected in pinned.items()}
    import audio_regression
    current = Path(audio_regression.__file__).parent
    frozen = root / "dsp_engine/deliverables/workbench_release_20261015_v3/source/src/audio_regression"
    payload = {}
    # A new package version is intentional; detector, schema and Workbench bytes
    # stay unchanged. New suite-only files have no predecessor and are excluded.
    for previous in sorted(frozen.rglob("*")):
        if previous.suffix not in {".py", ".json", ".html", ".js", ".css"} or "__pycache__" in previous.parts:
            continue
        relative = previous.relative_to(frozen)
        if relative.as_posix() == "__init__.py":
            continue
        now = current / relative
        payload[relative.as_posix()] = {"frozen_sha256": _sha(previous), "current_sha256": _sha(now)}
    okay = (all(item["actual_sha256"] == item["expected_sha256"] for item in artifacts.values())
            and all(item["frozen_sha256"] == item["current_sha256"] for item in payload.values()))
    return {"status": "verified" if okay else "mismatch", "artifacts": artifacts,
            "existing_package_payload": payload, "old_artifacts_modified": not okay}


def run_demo(output: Path, *, preservation_root: Path | None = None) -> dict:
    from audio_regression.regression_suite import run_regression_suite
    from audio_regression.regression_suite_contract import validate_suite_result
    from audio_regression.regression_suite_reporting import write_suite_html
    created = create_demo_inputs(output)
    engine_before = _engine_freeze()
    prior_before = preservation_audit(preservation_root)
    _save(output / "preservation_before.json", {"engine_sha256": engine_before, "prior_release": prior_before})
    actual = validate_suite_result(run_regression_suite(output / "suite.json", output / "run"))
    write_suite_html(actual, output / "run" / "suite_report.html")
    checks = []
    for case in actual["cases"]:
        expected = created["expectations"][case["case_id"]]
        delta = case["delta"]
        observed = {"status": delta["status"], "new_count": len(delta["new_candidates"]),
                    "persistent_count": len(delta["persistent_pairs"]),
                    "not_observed_now_count": len(delta["not_observed_now"]),
                    "error_expected": case["status"] == "error"}
        checks.append({"case_id": case["case_id"], "expected": expected,
                       "observed": observed, "matches": expected == observed})
    hashes_preserved = all(_sha(output / case[role]["path"]) == case[role]["sha256"]
                           for case in created["manifest"]["cases"]
                           for role in ("source", "baseline", "candidate"))
    prior_after = preservation_audit(preservation_root)
    preservation_okay = prior_after["status"] in {"verified", "not_requested"} and prior_before == prior_after
    summary_matches = actual["summary"] == EXPECTED_SUMMARY
    okay = (all(row["matches"] for row in checks) and summary_matches and hashes_preserved
            and engine_before == _engine_freeze() and preservation_okay)
    summary = {"schema_version": 1,
        "status": "owned_example_and_preservation_checks_passed" if okay else "owned_example_checks_failed",
        "case_count": len(checks), "analysis_calls_expected": 40,
        "matching_expectations": sum(row["matches"] for row in checks), "checks": checks,
        "suite_summary": actual["summary"], "expected_suite_summary_matches": summary_matches,
        "all_60_input_file_hashes_preserved": hashes_preserved,
        "existing_engine_and_schema_hashes_preserved": engine_before == _engine_freeze(),
        "prior_release_before_after": prior_after,
        "real_world_accuracy_customer_utility_or_commercial_readiness_established": False,
        "external_network_download_publication_or_delivery_performed": False}
    _save(output / "summary.json", summary)
    return summary


def main(argv: list[str] | None = None) -> int:
    arguments = _parser().parse_args(argv)
    if arguments.inputs_only:
        created = create_demo_inputs(arguments.output)
        print(json.dumps({"status": "inputs_created", "cases": len(created["manifest"]["cases"])}))
        return 0
    summary = run_demo(arguments.output, preservation_root=arguments.preservation_root)
    print(json.dumps({"status": summary["status"], "matching_expectations": summary["matching_expectations"],
                      "case_count": summary["case_count"]}))
    return 0 if summary["status"] == "owned_example_and_preservation_checks_passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
