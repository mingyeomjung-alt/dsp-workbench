"""Development examples of auditing saved WAV stages, not accuracy evidence."""

import argparse
import hashlib
import json
import os
from pathlib import Path

import numpy as np

from audio_regression.audio import decode_wav, encode_wav
from audio_regression.fixtures import generate_case
from audio_regression.pipeline_transforms import execute_stage
from audio_regression.saved_pipeline import audit_saved_pipeline
from audio_regression.saved_pipeline_contract import validate_saved_pipeline_result
from audio_regression.saved_pipeline_reporting import write_saved_pipeline_html


def _new_bytes(path, raw):
    with path.open("xb") as stream:
        stream.write(raw)


def _new_json(path, value):
    _new_bytes(path, (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8"))


def run(output):
    target = Path(os.path.abspath(output))
    if os.path.lexists(target):
        raise FileExistsError("Development output directory already exists.")
    target.mkdir(parents=True, exist_ok=False)
    original = generate_case("clean", seed=58891).reference_wav
    resampled, _ = execute_stage(decode_wav(original), {"kind": "resample", "target_rate_hz": 8000})
    quieter, _ = execute_stage(decode_wav(resampled), {"kind": "gain", "gain_db": -6})
    records = []
    for case in ("normal", "deleted_chunk", "repeated_chunk", "silent_stage"):
        folder = target / case
        folder.mkdir()
        inputs = folder / "supplied"
        inputs.mkdir()
        order = list(range(15))
        if case == "deleted_chunk":
            order.remove(5)
        elif case == "repeated_chunk":
            order.insert(6, 5)
        if case == "silent_stage":
            middle = encode_wav(np.zeros(48000), 8000)
        else:
            middle, _ = execute_stage(decode_wav(quieter), {"kind": "split_join", "segment_ms": 400, "order": order})
        final, _ = execute_stage(decode_wav(middle), {"kind": "gain", "gain_db": -3})
        raw_files = [original, resampled, quieter, middle, final]
        file_names = ["source.wav", "resampled.wav", "quieter.wav", "assembled.wav", "final.wav"]
        for name, raw in zip(file_names, raw_files):
            _new_bytes(inputs / name, raw)
        declarations = [(False, True), (True, False), (False, False), (True, False)]
        labels = ["저장된 리샘플링 출력", "저장된 음량 변경 출력", "저장된 합치기 출력", "저장된 후속 출력"]
        manifest = {"schema_version": 1, "source": "supplied/source.wav", "stages": [
            {"label": label, "output": "supplied/" + name,
             "declaration": {"allow_gain": gain, "allow_resampling": rate}}
            for label, name, (gain, rate) in zip(labels, file_names[1:], declarations)
        ]}
        manifest_path = folder / "saved_manifest.json"
        _new_json(manifest_path, manifest)
        result = audit_saved_pipeline(manifest_path, folder / "audit")
        validate_saved_pipeline_result(result)
        write_saved_pipeline_html(result, folder / "audit/audit_report.html")
        concern = result["summary"]["first_concern"]
        observed = (result["summary"]["exit_code"], None if concern is None else concern["stage_index"])
        expected = {"normal": (0, None), "deleted_chunk": (1, 3), "repeated_chunk": (1, 3), "silent_stage": (2, 3)}[case]
        if observed != expected:
            raise ValueError("Development observation mismatch for " + case + ": " + str(observed))
        if not all((inputs / name).read_bytes() == raw for name, raw in zip(file_names, raw_files)):
            raise ValueError("A supplied development WAV changed during audit.")
        records.append({"case": case, "summary": result["summary"], "input_recheck": result["input_recheck"],
                        "result": case + "/audit/audit_result.json", "report": case + "/audit/audit_report.html"})
    summary = {"schema_version": 1, "source_sha256": hashlib.sha256(original).hexdigest(),
               "evidence_scope": "development_usage_examples_not_independent_accuracy",
               "original_files_preserved": True, "caller_order_verified": False,
               "commercial_performance_validated": False, "final_confirmation_replayed": False,
               "records": records}
    _new_json(target / "demo_summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False))
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    run(parser.parse_args().output_dir)
