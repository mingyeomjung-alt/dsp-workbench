"""Fetch one hash-pinned official-linked FFmpeg build for an internal trial.

No installation, PATH edit, administrator request, or distribution is performed.
Only selected flat files are extracted after the entire archive hash is checked.
Failed directories remain occupied and are never reused automatically.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import stat
from urllib.parse import urlsplit
from urllib.request import HTTPRedirectHandler, Request, build_opener
import zipfile


URL = "https://www.gyan.dev/ffmpeg/builds/packages/ffmpeg-9.0.2-essentials_build.zip"
EXPECTED_SHA256 = "60f467265b1e312373dbcd92200c2618a74850f98d3d078e94296bb3fa2047ba"
MAX_ARCHIVE_BYTES = 140_000_000


class _SamePrimaryHost(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        parts = urlsplit(newurl)
        if parts.scheme != "https" or parts.hostname != "www.gyan.dev":
            raise ValueError("Download redirect left the preselected primary HTTPS host.")
        return super().redirect_request(req, fp, code, msg, headers, newurl)


def _new_json(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, allow_nan=False, indent=2)
        stream.write("\n")


def run(output_dir):
    target = Path(os.path.abspath(output_dir))
    if os.path.lexists(target):
        raise FileExistsError("Local tool preparation directory already exists.")
    if any(p.is_symlink() for p in target.parents):
        raise ValueError("Tool preparation cannot traverse link parents.")
    target.mkdir(parents=True, exist_ok=False)
    record = {"schema_version": 1, "status": "started", "requested_url": URL,
              "expected_sha256": EXPECTED_SHA256,
              "source_selection": "FFmpeg official download page links Gyan Windows builds",
              "official_download_page": "https://ffmpeg.org/download.html",
              "build_page": "https://www.gyan.dev/ffmpeg/builds/",
              "hash_page": URL + ".sha256", "license": "GPL-3.0 build, retained internal only",
              "installed": False, "path_environment_modified": False,
              "redistribution_performed": False, "maximum_archive_bytes": MAX_ARCHIVE_BYTES,
              "archive_hash_verified_before_extraction": False, "extracted": []}
    _new_json(target / "preparation_started.json", record)
    try:
        archive = target / "ffmpeg-9.0.2-essentials_build.zip"
        request = Request(URL, headers={"User-Agent": "LocalDSPInternalIntegration/1.0"})
        digest, received = hashlib.sha256(), 0
        with build_opener(_SamePrimaryHost()).open(request, timeout=30) as response:
            final = urlsplit(response.geturl())
            if final.scheme != "https" or final.hostname != "www.gyan.dev":
                raise ValueError("Unexpected final primary download host.")
            record["final_url"] = response.geturl()
            declared = response.headers.get("Content-Length")
            if declared is not None and int(declared) > MAX_ARCHIVE_BYTES:
                raise ValueError("Archive exceeds its fixed size limit.")
            with archive.open("xb") as stream:
                while True:
                    chunk = response.read(min(65536, MAX_ARCHIVE_BYTES - received + 1))
                    if not chunk:
                        break
                    received += len(chunk)
                    if received > MAX_ARCHIVE_BYTES:
                        raise ValueError("Archive exceeds its fixed size limit.")
                    digest.update(chunk)
                    stream.write(chunk)
        record.update(bytes=received, archive_sha256=digest.hexdigest())
        if digest.hexdigest() != EXPECTED_SHA256:
            raise ValueError("Archive SHA-256 differs from the preselected official build hash.")
        record["archive_hash_verified_before_extraction"] = True
        with zipfile.ZipFile(archive) as bundle:
            selected = []
            for info in bundle.infolist():
                # ZipInfo normalizes native separators on Windows. Inspect
                # its original archive name before that normalization too.
                raw_name = info.orig_filename
                parts = raw_name.split("/")
                if ("\\" in raw_name or any(p in {"", ".", ".."} for p in parts)
                        or len(parts) < 2):
                    if not info.is_dir():
                        raise ValueError("Archive contains an unsafe member name.")
                    continue
                base = parts[-1]
                name = "ffmpeg.exe" if len(parts) == 3 and parts[-2:] == ["bin", "ffmpeg.exe"] else (
                    base if len(parts) == 2 and base.lower() in {"license", "license.txt", "readme", "readme.txt"} else None)
                if name is not None:
                    limit = 200_000_000 if name == "ffmpeg.exe" else 2_000_000
                    mode = info.external_attr >> 16
                    if stat.S_ISLNK(mode) or info.file_size > limit or info.is_dir():
                        raise ValueError("Selected member is unsafe or oversized.")
                    selected.append((info, name, limit))
            if sum(name == "ffmpeg.exe" for _, name, _ in selected) != 1:
                raise ValueError("Archive lacks one unambiguous FFmpeg executable.")
            if not any(name.lower().startswith("license") for _, name, _ in selected):
                raise ValueError("Build license notice is missing.")
            for info, name, limit in selected:
                destination = target / name
                member_digest, count = hashlib.sha256(), 0
                with bundle.open(info) as source, destination.open("xb") as output:
                    while True:
                        chunk = source.read(min(65536, limit - count + 1))
                        if not chunk:
                            break
                        count += len(chunk)
                        if count > limit:
                            raise ValueError("Extracted member exceeds its fixed size limit.")
                        member_digest.update(chunk)
                        output.write(chunk)
                record["extracted"].append({"archive_member": info.filename, "local_file": name,
                                             "bytes": count, "sha256": member_digest.hexdigest()})
        record.update(status="completed", executable="ffmpeg.exe")
        _new_json(target / "preparation_result.json", record)
        return record
    except Exception as exc:
        record.update(status="incomplete", error_type=type(exc).__name__)
        _new_json(target / "preparation_result.json", record)
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    print(json.dumps(run(parser.parse_args().output_dir), ensure_ascii=False, allow_nan=False))
