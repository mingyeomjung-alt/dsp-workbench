"""Twelve fresh native-rate usage examples with scalar PCM mathematics.

This is generated development evidence, not natural-audio accuracy, quality
approval, or a provenance demonstration. A separate integer WAV writer and
Python integer/Fraction formulas define truth before measurements execute.
No production measure function defines truth; no earlier detector runs,
natural audio, sealed audio, external files or network are used.
"""

from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import random
import struct

from audio_regression import __version__
from audio_regression.fullband_runner import run_fullband_measurement
from audio_regression.fullband_reporting import write_fullband_html


SEED = 2026101459517
RATES = (8000, 16000, 44100, 48000)
EDGES = (0, 250, 500, 1000, 2000, 4000, 8000, 16000, 24000)
SCALE = 32768


def _new_bytes(path: Path, raw: bytes) -> None:
    with path.open("xb") as stream:
        stream.write(raw)


def _new_json(path: Path, value: object) -> None:
    _new_bytes(path, (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8"))


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _wave(pcm: list[int], rate: int) -> bytes:
    """Canonical PCM16 RIFF writer independent of production WAV encoding."""
    if rate not in RATES or not 2 * rate <= len(pcm) <= 30 * rate:
        raise ValueError("Generated PCM is outside the fixed input geometry.")
    if any(type(value) is not int or not -32768 <= value <= 32767 for value in pcm):
        raise ValueError("Generated values are not signed PCM16 integers.")
    payload = struct.pack(f"<{len(pcm)}h", *pcm)
    return (b"RIFF" + struct.pack("<I", 36 + len(payload)) + b"WAVEfmt "
            + struct.pack("<IHHIIHH", 16, 1, 1, rate, 2 * rate, 2, 16)
            + b"data" + struct.pack("<I", len(payload)) + payload)


def _source(rate: int, count: int, offset: int = 0) -> list[int]:
    rng = random.Random(SEED + rate + offset)
    return [rng.randrange(-4000, 4001) for _ in range(count)]


def _rail_truth(pcm: list[int]) -> tuple[int, int]:
    count, longest, current, previous = 0, 0, 0, None
    for value in pcm:
        if value == -32768 or value == 32767:
            count += 1
            current = current + 1 if previous == value else 1
            longest = max(longest, current)
            previous = value
        else:
            current, previous = 0, None
    return count, longest


def _audio_truth(pcm: list[int], rate: int) -> dict:
    count = len(pcm)
    dc = float(Fraction(sum(pcm), count * SCALE))
    mean_square = float(Fraction(sum(value * value for value in pcm), count * SCALE * SCALE))
    peak = max(abs(value) for value in pcm) / SCALE
    rail_count, longest = _rail_truth(pcm)
    frame_size = rate // 10
    frames = []
    for start in range(0, count, frame_size):
        end = min(start + frame_size, count)
        segment = pcm[start:end]
        frames.append({
            "start_sample": start, "end_sample": end,
            "mean_square": float(Fraction(sum(value * value for value in segment), len(segment) * SCALE * SCALE)),
            "peak": max(abs(value) for value in segment) / SCALE,
        })
    return {
        "dc_offset": dc, "mean_square": mean_square,
        "rms_dbfs": 10 * math.log10(mean_square) if mean_square else None,
        "peak_dbfs": 20 * math.log10(peak) if peak else None,
        "crest_factor": peak / math.sqrt(mean_square) if mean_square else None,
        "rail_sample_count": rail_count, "rail_sample_fraction": rail_count / count,
        "longest_same_rail_run_samples": longest,
        "frame_size_samples": frame_size, "frames": frames,
    }


def _pair_truth(left: list[int], left_rate: int, right: list[int], right_rate: int) -> dict:
    reason = ("sample_rate_mismatch" if left_rate != right_rate else
              "sample_count_mismatch" if len(left) != len(right) else None)
    nulls = {
        "unequal_sample_count": None, "first_changed_sample": None, "last_changed_sample": None,
        "maximum_abs_error_pcm16": None, "mean_square_error": None,
        "signal_to_residual_db": None, "correlation": None,
        "residual_bands": None, "changed_frames": None,
    }
    if reason:
        return {"status": "withheld", "reason_code": reason, **nulls,
                "signal_to_residual_status": "not_comparable", "correlation_status": "not_comparable"}
    count = len(left)
    residual = [actual - source for source, actual in zip(left, right)]
    changed_indices = [index for index, value in enumerate(residual) if value]
    mean_square = float(Fraction(sum(value * value for value in residual), count * SCALE * SCALE))
    reference_power = float(Fraction(sum(value * value for value in left), count * SCALE * SCALE))
    if mean_square == 0:
        ratio, ratio_status = None, "zero_residual"
    elif reference_power == 0:
        ratio, ratio_status = None, "zero_reference"
    else:
        ratio = 10 * (math.log10(reference_power) - math.log10(mean_square))
        ratio_status = "finite"
    # Exact integer moments avoid cancellation from rounded normalized DC.
    sum_left, sum_right = sum(left), sum(right)
    variance_left = count * sum(value * value for value in left) - sum_left * sum_left
    variance_right = count * sum(value * value for value in right) - sum_right * sum_right
    if variance_left == 0 or variance_right == 0:
        correlation, correlation_status = None, "constant_signal"
    else:
        covariance = count * sum(source * actual for source, actual in zip(left, right)) - sum_left * sum_right
        correlation = max(-1.0, min(1.0, covariance / math.sqrt(variance_left * variance_right)))
        correlation_status = "defined"
    changed_frames = []
    frame_size = left_rate // 10
    for start in range(0, count, frame_size):
        end = min(start + frame_size, count)
        unequal = sum(value != 0 for value in residual[start:end])
        if unequal:
            changed_frames.append({"start_sample": start, "end_sample": end, "unequal_sample_count": unequal})
    return {
        "status": "measured", "reason_code": None,
        "unequal_sample_count": len(changed_indices),
        "first_changed_sample": changed_indices[0] if changed_indices else None,
        "last_changed_sample": changed_indices[-1] if changed_indices else None,
        "maximum_abs_error_pcm16": max(abs(value) for value in residual),
        "mean_square_error": mean_square, "signal_to_residual_db": ratio,
        "signal_to_residual_status": ratio_status,
        "correlation": correlation, "correlation_status": correlation_status,
        "changed_frames": changed_frames,
    }


def _cases():
    for rate in RATES:
        pcm = _source(rate, 2 * rate + 17)
        yield {"case": f"identity_{rate}", "reference_pcm": pcm, "reference_rate": rate,
               "processed_pcm": list(pcm), "processed_rate": rate, "expected_exit_code": 0,
               "condition": "unchanged_native_pcm_with_final_partial_frame"}
    rate, count = 48000, 96000
    low_period = [round(400 * math.sin(2 * math.pi * index / 48)) for index in range(48)]
    low = [low_period[index % 48] for index in range(count)]
    carrier = [1000, 0, -1000, 0]
    yield {"case": "high_band_removed_48k", "reference_pcm": [value + carrier[index % 4] for index, value in enumerate(low)],
           "reference_rate": rate, "processed_pcm": low, "processed_rate": rate, "expected_exit_code": 0,
           "condition": "exact_12khz_carrier_removed_from_rounded_1khz_integer_tone",
           "residual_band_truth": {"lower_hz": 8000, "upper_hz": 16000,
                                   "mean_square": float(Fraction(1000 * 1000, 2 * SCALE * SCALE)),
                                   "power_fraction": 1.0}}
    yield {"case": "dc_change_16k", "reference_pcm": [0] * 32000, "reference_rate": 16000,
           "processed_pcm": [1000] * 32000, "processed_rate": 16000, "expected_exit_code": 0,
           "condition": "zero_to_constant_dc_not_ambient_noise"}
    pcm = _source(16000, 32017, 3)
    yield {"case": "gain_change_16k", "reference_pcm": pcm, "reference_rate": 16000,
           "processed_pcm": [value * 2 for value in pcm], "processed_rate": 16000, "expected_exit_code": 0,
           "condition": "bounded_integer_gain_two_no_compensation"}
    pcm = [0] * 16017
    pcm[10:13] = [32767] * 3
    pcm[20:25] = [-32768] * 5
    pcm[-2:] = [32767] * 2
    actual = list(pcm)
    actual[10] = 0
    actual[20] = -32767
    actual[100:104] = [-32768] * 4
    actual[-1] = -32768
    yield {"case": "rails_changed_8k", "reference_pcm": pcm, "reference_rate": 8000,
           "processed_pcm": actual, "processed_rate": 8000, "expected_exit_code": 0,
           "condition": "known_endpoint_occupancy_and_same_sign_runs_not_clipping_cause"}
    pcm = _source(44100, 88217, 9)
    actual = list(pcm)
    actual[-1] += 1
    yield {"case": "last_one_lsb_44100", "reference_pcm": pcm, "reference_rate": 44100,
           "processed_pcm": actual, "processed_rate": 44100, "expected_exit_code": 0,
           "condition": "one_lsb_only_at_last_native_sample"}
    yield {"case": "silence_8k", "reference_pcm": [0] * 16000, "reference_rate": 8000,
           "processed_pcm": [0] * 16000, "processed_rate": 8000, "expected_exit_code": 0,
           "condition": "digital_silence_measurement_not_temporal_acceptance"}
    yield {"case": "rate_mismatch_16_to_8", "reference_pcm": _source(16000, 32017, 10), "reference_rate": 16000,
           "processed_pcm": _source(8000, 16017, 11), "processed_rate": 8000, "expected_exit_code": 2,
           "condition": "independent_generated_rates_no_resampling_or_pair_comparison"}
    pcm = _source(8000, 16017, 12)
    yield {"case": "length_mismatch_8k", "reference_pcm": pcm, "reference_rate": 8000,
           "processed_pcm": pcm + [0], "processed_rate": 8000, "expected_exit_code": 2,
           "condition": "one_added_tail_sample_no_alignment_or_pair_comparison"}


def _assert_matches(actual: object, expected: object) -> None:
    if type(expected) is dict:
        if type(actual) is not dict or any(key not in actual for key in expected):
            raise ValueError("Generated scalar truth structure did not match.")
        for key, value in expected.items():
            _assert_matches(actual[key], value)
    elif type(expected) is list:
        if type(actual) is not list or len(actual) != len(expected):
            raise ValueError("Generated scalar truth frame count did not match.")
        for actual_item, expected_item in zip(actual, expected):
            _assert_matches(actual_item, expected_item)
    elif type(expected) is float:
        if type(actual) is not float or not math.isfinite(actual) or not math.isclose(actual, expected, rel_tol=1e-11, abs_tol=1e-24):
            raise ValueError("Generated scalar truth number did not match.")
    elif type(actual) is not type(expected) or actual != expected:
        raise ValueError("Generated scalar truth exact value did not match.")


def _assert_bands(bands: list[dict], rate: int, power: float) -> None:
    if len(bands) != 8:
        raise ValueError("Generated spectral band count did not match.")
    for index, band in enumerate(bands):
        lower, upper = EDGES[index:index + 2]
        if band["lower_hz"] != lower or band["upper_hz"] != upper:
            raise ValueError("Generated spectral edges did not match.")
        if lower >= rate / 2:
            if (band["status"] != "not_available" or band["effective_upper_hz"] is not None
                    or band["mean_square"] is not None or band["power_fraction"] is not None
                    or band["upper_inclusive"] is not False):
                raise ValueError("Generated unavailable spectral band did not match.")
        elif (band["status"] != "available" or band["effective_upper_hz"] != min(upper, rate / 2)
              or band["upper_inclusive"] is not (min(upper, rate / 2) == rate / 2)):
            raise ValueError("Generated available spectral band did not match.")
    total = sum(band["mean_square"] for band in bands if band["status"] == "available")
    if not math.isclose(total, power, rel_tol=1e-12, abs_tol=1e-27):
        raise ValueError("Generated scalar full-record energy did not match spectral partition.")
    if power == 0 and any(band["power_fraction"] != 0 for band in bands if band["status"] == "available"):
        raise ValueError("Generated silence spectral fractions did not match.")


def run(output_dir: str | Path) -> dict:
    target = Path(os.path.abspath(output_dir))
    if os.path.lexists(target):
        raise FileExistsError("Generated development output directory already exists.")
    target.mkdir(parents=True, exist_ok=False)
    _new_json(target / "manifest_started.json", {
        "schema_version": 1, "status": "started", "seed": SEED, "planned_scenarios": 12,
        "fixture_source": "fresh_owned_python_integer_pcm_independent_wave_writer_and_fraction_truth",
        "expectations_fixed_before_measurement": True, "natural_or_sealed_audio_replayed": False,
        "network_used": False, "existing_detector_or_model_runs": 0,
        "legacy_pipeline_model_or_analysis_api_calls": 0,
        "evidence_scope": "development_mathematical_usage_examples_not_quality_accuracy",
    })
    records = []
    for case in _cases():
        folder = target / case["case"]
        folder.mkdir()
        supplied = folder / "supplied"
        supplied.mkdir()
        source_raw = _wave(case["reference_pcm"], case["reference_rate"])
        processed_raw = _wave(case["processed_pcm"], case["processed_rate"])
        _new_bytes(supplied / "reference.wav", source_raw)
        _new_bytes(supplied / "processed.wav", processed_raw)
        truth = {
            "schema_version": 1, "case": case["case"], "condition": case["condition"],
            "reference_rate_hz": case["reference_rate"], "processed_rate_hz": case["processed_rate"],
            "reference_sample_count": len(case["reference_pcm"]), "processed_sample_count": len(case["processed_pcm"]),
            "expected_exit_code": case["expected_exit_code"],
            "reference_sha256": _sha(source_raw), "processed_sha256": _sha(processed_raw),
            "reference_measurements": _audio_truth(case["reference_pcm"], case["reference_rate"]),
            "processed_measurements": _audio_truth(case["processed_pcm"], case["processed_rate"]),
            "comparison": _pair_truth(case["reference_pcm"], case["reference_rate"], case["processed_pcm"], case["processed_rate"]),
            "residual_band_truth": case.get("residual_band_truth"),
            "oracle_is_independent_of_production_measurements": True,
            "expectation_written_before_measurement": True,
        }
        _new_json(folder / "fixture_truth.json", truth)
        result = run_fullband_measurement(supplied / "reference.wav", supplied / "processed.wav", folder / "measurement")
        write_fullband_html(result, folder / "measurement" / "report.html")
        _assert_matches(result["reference_measurements"], truth["reference_measurements"])
        _assert_matches(result["processed_measurements"], truth["processed_measurements"])
        _assert_matches(result["comparison"], truth["comparison"])
        _assert_bands(result["reference_measurements"]["bands"], case["reference_rate"], truth["reference_measurements"]["mean_square"])
        _assert_bands(result["processed_measurements"]["bands"], case["processed_rate"], truth["processed_measurements"]["mean_square"])
        if result["comparison"]["status"] == "measured":
            _assert_bands(result["comparison"]["residual_bands"], case["reference_rate"], truth["comparison"]["mean_square_error"])
        if result["summary"]["exit_code"] != case["expected_exit_code"]:
            raise ValueError("Generated fixed measurement completion did not match.")
        if (result["summary"]["quality_verdict"] != "not_assessed"
                or result["complete_audio_approval"] is not False
                or result["commercial_performance_validated"] is not False):
            raise ValueError("Generated measurement result claimed an unsupported quality verdict.")
        if case.get("residual_band_truth"):
            expected = case["residual_band_truth"]
            selected = [band for band in result["comparison"]["residual_bands"] if band["lower_hz"] == expected["lower_hz"]]
            if len(selected) != 1:
                raise ValueError("Generated exact carrier band did not match.")
            _assert_matches(selected[0], expected)
            if any(band["mean_square"] > 1e-27 for band in result["comparison"]["residual_bands"]
                   if band["status"] == "available" and band["lower_hz"] != expected["lower_hz"]):
                raise ValueError("Generated exact carrier had unexpected out-of-band power.")
        snapshots = folder / "measurement" / "input"
        if (supplied.joinpath("reference.wav").read_bytes() != source_raw
                or supplied.joinpath("processed.wav").read_bytes() != processed_raw
                or snapshots.joinpath("reference.wav").read_bytes() != source_raw
                or snapshots.joinpath("processed.wav").read_bytes() != processed_raw):
            raise ValueError("Generated supplied input or retained snapshot changed.")
        records.append({
            "case": case["case"], "condition": case["condition"],
            "expected_exit_code": case["expected_exit_code"], "observed_exit_code": result["summary"]["exit_code"],
            "scalar_truth_matched": True, "input_and_snapshot_hashes_verified": True,
            "reference_sha256": _sha(source_raw), "processed_sha256": _sha(processed_raw),
            "result": f'{case["case"]}/measurement/fullband_result.json',
            "report": f'{case["case"]}/measurement/report.html', "truth": f'{case["case"]}/fixture_truth.json',
            "comparison_status": result["comparison"]["status"],
            "comparison_reason_code": result["comparison"]["reason_code"],
            "signal_to_residual_status": result["comparison"]["signal_to_residual_status"],
            "correlation_status": result["comparison"]["correlation_status"],
            "high_frequency_known_tone_verified": bool(case.get("residual_band_truth")),
            "quality_verdict": result["summary"]["quality_verdict"],
        })
        print(json.dumps({"scenario_completed": case["case"], "measurements_completed": len(records)}, ensure_ascii=False), flush=True)
    if len(records) != 12:
        raise ValueError("Generated fixed scenario count did not complete.")
    codes = Counter(record["observed_exit_code"] for record in records)
    summary = {
        "schema_version": 1, "version": __version__, "seed": SEED,
        "status": "completed_owned_development_measurements", "scenario_count": 12,
        "measurement_run_count": 12, "static_report_count": 12,
        "measurement_completion_counts": {"pair_measured_no_quality_verdict": codes[0], "pair_comparison_withheld": codes[2]},
        "all_expected_outcomes_observed": True, "all_scalar_truth_matched": True,
        "input_and_retained_snapshot_bytes_and_hashes_unchanged": True,
        "full_record_band_parseval_matches_independent_scalar_energy": True,
        "high_frequency_12khz_removed_carrier_measured_above_4khz": True,
        "final_native_one_lsb_difference_preserved": True,
        "zero_and_constant_undefined_metrics_retained_as_null": True,
        "mismatched_geometry_comparison_withheld_individual_measurements_retained": True,
        "oracle_is_independent_of_production_measurements": True,
        "truth_written_before_measurement": True, "network_used": False,
        "natural_or_sealed_audio_replayed": False, "existing_detector_or_model_runs": 0,
        "legacy_pipeline_model_or_analysis_api_calls": 0,
        "exit_code_0_meaning": "measurement_completed_no_quality_verdict",
        "independent_quality_accuracy_evidence": False, "complete_audio_approval": False,
        "commercial_performance_validated": False, "fault_provenance_confirmed": False,
        "records": records,
    }
    _new_json(target / "summary.json", summary)
    files = []
    for path in sorted(target.rglob("*")):
        if path.is_file():
            raw = path.read_bytes()
            files.append({"path": path.relative_to(target).as_posix(), "size_bytes": len(raw), "sha256": _sha(raw)})
    _new_json(target / "artifact_manifest.json", {"schema_version": 1, "files": files,
                                              "manifest_excludes_only_itself": True, "network_used": False})
    print(json.dumps({"status": summary["status"], "scenario_count": 12, "hash_bound_artifacts": len(files)}, ensure_ascii=False), flush=True)
    return summary


def main() -> int:
    parser = argparse.ArgumentParser(description="Fresh independent-oracle native-rate DSP examples; no quality verdict.")
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()
    run(args.output_dir)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
