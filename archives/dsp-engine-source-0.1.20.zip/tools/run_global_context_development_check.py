"""Fresh owned sparse-prefix equations; no consumed or personal audio is read.

Truth is recorded before analysis and never passed to the DSP kernel. These are
development examples, not an independent music accuracy benchmark.
"""
import argparse
import hashlib
import json
from pathlib import Path
import time

import numpy as np
from scipy.signal import resample_poly

from audio_regression import __version__
from audio_regression.api import analyze_pair_with_trace
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.check_policy import check_result
from audio_regression.evaluation_metrics import score_trial
from audio_regression.reporting import write_html_report


def _pcm(values, rate=16000):
    return decode_wav(encode_wav(values, rate)).samples


def _source(index):
    duration = 8 if index == 0 else 9
    t = np.arange(duration * 16000) / 16000
    start = 3.86 if index == 0 else 4.06
    phase = 2 * np.pi * ((437 + 62 * index) * t + (31 + 8 * index) * t * t
                         + .23 * np.sin((1.37 + .31 * index) * t))
    signal = .12 * (np.sin(phase) + .19 * np.sin(1.71 * phase + .37)
                    + .11 * np.sin(2.43 * phase - .59)) * (.71 + .21 * np.sin(.91 * t) ** 2)
    return _pcm(np.where(t < start, 0, signal))


def _process(values, gain, delay):
    return np.concatenate((np.zeros(delay), _pcm(resample_poly(_pcm(values * gain), 1, 2), 8000)))


def _edit(source, first, count, kind):
    end = first + count
    return (np.concatenate((source[:first], source[end:])) if kind == "delete" else
            np.concatenate((source[:end], source[first:end], source[end:])))


def _cases():
    for index in range(2):
        source = _source(index)
        gain, delay = ((.4632197, 320) if index == 0 else (.6173813, 448))
        point = 64000 if index == 0 else 67200
        yield f"formula_{index + 1}_normal", source, _process(source, gain, delay), [], "normal"
        durations = (200, 400, 750) if index == 0 else (400,)
        for ms in durations:
            count = ms * 16
            for kind in ("delete", "repeat"):
                truth = ([{"type": "delete", "reference_interval_ms": [point / 16, point / 16 + ms],
                           "processed_boundary_ms": point / 16 + delay / 8}] if kind == "delete" else
                         [{"type": "repeat", "reference_source_interval_ms": [point / 16, point / 16 + ms],
                           "processed_added_interval_ms": [point / 16 + ms + delay / 8,
                                                           point / 16 + 2 * ms + delay / 8]}])
                yield (f"formula_{index + 1}_{kind}_{ms}", source,
                       _process(_edit(source, point, count, kind), gain, delay), truth, "event")
    source = _source(0)
    gain, delay, first, count = .4632197, 320, 64000, 6400
    deleted = _edit(source, first, count, "delete")
    # The removed 400ms is entirely zero and observationally compatible with
    # declared normal alignment; it is not an observable active-edge defect.
    yield "start_truncation", source, _process(source[6400:], gain, delay), [], "normal_silent_edge_trim"
    yield "end_truncation", source, _process(source[:-6400], gain, delay), [], "stress"
    t = np.arange(count) / 16000
    # Internal fragment, not a standalone file: keep the public 2s WAV limit.
    fragment = np.minimum(np.rint(.085 * np.sin(2 * np.pi * (883 * t + 77 * t * t)) * 32768), 32767) / 32768
    inserted = np.concatenate((source[:first + count], fragment, source[first + count:]))
    yield "unknown_insertion", source, _process(inserted, gain, delay), [], "stress"
    multiple = np.concatenate((source[:first], source[first + count:96000], source[102400:]))
    yield "two_deletions", source, _process(multiple, gain, delay), [], "stress"
    corrupted = _process(deleted, gain, delay)
    corrupted[-1600:] = 0
    yield "retained_tail_erasure", source, corrupted, [], "stress"
    periodic = _pcm(.12 * np.sin(2 * np.pi * 250 * np.arange(8 * 16000) / 16000))
    yield "periodic_copy", periodic, _process(_edit(periodic, first, count, "repeat"), gain, delay), [], "stress"
    silent = np.zeros(8 * 16000)
    yield "silent_delete", silent, _process(_edit(silent, first, count, "delete"), gain, delay), [], "stress"
    # Additional targeted DEVELOPMENT variants, not replacements or independent
    # evidence. Prefix STD is below the old raw-window entry floor but above
    # the fixed quantization-resolution floor after gain. No detector tuning.
    for index in range(2):
        source = _source(index).copy()
        point = 64000 if index == 0 else 67200
        source[:point] = _pcm(source[:point] * .0035)
        gain, delay, count = .8313743, 48, 6400
        for kind in ("delete", "repeat"):
            truth = ([{"type": "delete", "reference_interval_ms": [point / 16, point / 16 + 400],
                       "processed_boundary_ms": point / 16 + delay / 8}] if kind == "delete" else
                     [{"type": "repeat", "reference_source_interval_ms": [point / 16, point / 16 + 400],
                       "processed_added_interval_ms": [point / 16 + 400 + delay / 8,
                                                       point / 16 + 800 + delay / 8]}])
            yield (f"formula_{index + 1}_low_information_prefix_{kind}_400", source,
                   _process(_edit(source, point, count, kind), gain, delay), truth, "event")


def _new_json(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def run(output):
    output = output.absolute()
    if output.exists():
        raise FileExistsError("A new output directory is required.")
    output.mkdir(parents=False)
    manifest = []
    for index, (name, source, target, truth, scope) in enumerate(_cases()):
        trial = f"p{index:02d}"
        folder = output / trial
        folder.mkdir()
        for filename, samples, rate in (("a.wav", source, 16000), ("b.wav", target, 8000)):
            with (folder / filename).open("xb") as stream:
                stream.write(encode_wav(samples, rate))
        manifest.append({"trial_id": trial, "case": name, "scope": scope, "expected_events": truth,
                         "input_sha256": [hashlib.sha256((folder / n).read_bytes()).hexdigest() for n in ("a.wav", "b.wav")]})
    _new_json(output / "manifest_before_analysis.json", manifest)
    rows = []
    for item in manifest:
        folder = output / item["trial_id"]
        for engine in ("v8", "v9"):
            start = time.perf_counter()
            result, trace = analyze_pair_with_trace(folder / "a.wav", folder / "b.wav", engine=engine,
                                                    allow_gain=True, allow_resampling=True)
            runtime_ms = (time.perf_counter() - start) * 1000
            _new_json(folder / (engine + ".json"), result)
            _new_json(folder / (engine + "_trace.json"), trace)
            write_html_report(result, folder / (engine + ".html"))
            score = score_trial(item["expected_events"], result)
            if item["scope"] == "stress":
                met = result["status"] == "withheld"
            else:
                met = (not score["withheld"] and score["false_positive_events"] == 0
                       and score["false_negative_events"] == 0)
            rows.append({"trial_id": item["trial_id"], "case": item["case"], "scope": item["scope"],
                         "engine": engine, "status": result["status"], "reason_code": result["reason_code"],
                         "events": result["events"], "runtime_ms": runtime_ms,
                         "expected_behavior_met": met, "score": score,
                         "check_exit_code": check_result(result)["exit_code"],
                         "proof_path": trace["proof_path"],
                         "new_global_context_proof": trace.get("global_context_proved", False)})
        if item["input_sha256"] != [hashlib.sha256((folder / n).read_bytes()).hexdigest() for n in ("a.wav", "b.wav")]:
            raise RuntimeError("An input changed during analysis.")
        print(json.dumps({"completed_condition": item["case"], "total": len(manifest)}), flush=True)
    summary = {"schema_version": 1, "package_version": __version__, "owned_development_only": True,
               "original_signal_formulas": 2, "development_source_variants": 4,
               "low_information_prefix_variant_factor": .0035,
               "conditions": len(manifest), "total": len(rows),
               "numeric_gain_or_truth_passed_to_detector": False,
               "old_audio_or_sealed_inputs_read": False, "input_unchanged": True,
               "independent_accuracy_established": False,
               "candidate_expected_behaviors_met": sum(r["expected_behavior_met"] for r in rows if r["engine"] == "v9"),
               "candidate_total": len(manifest), "rows": rows}
    _new_json(output / "summary.json", summary)
    print(json.dumps({"summary": str(output / "summary.json"),
                      "candidate_met": summary["candidate_expected_behaviors_met"], "candidate_total": len(manifest)}), flush=True)
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    arguments = parser.parse_args()
    result = run(arguments.output_dir)
    raise SystemExit(0 if result["candidate_expected_behaviors_met"] == result["candidate_total"] else 2)
