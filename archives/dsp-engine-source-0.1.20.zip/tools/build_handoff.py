"""Build a narrow, offline DSP wheel in an explicitly new local directory.

The source allowlist is deliberately independent of the surrounding workspace.
No source installation, evaluation, download, deletion, or overwrite is performed.
Failed builds retain their newly created output for inspection.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import subprocess
import sys
import tomllib
import zipfile


PROJECT_NAME = "audio-regression-engine"
PACKAGE = "audio_regression"
ROOT_DOCUMENTS = frozenset({
    "pyproject.toml", "README.md", "HANDOFF.md", "constraints.txt",
    "constraints-offline.txt", "constraints-build.txt", "DEPENDENCY_NOTICES.md",
    "THIRD_PARTY_NOTICES.md",
    "PIPELINE.md",
    "SAVED_PIPELINE.md",
    "ROBUSTNESS.md",
    "CONTEXT.md",
    "INSTRUMENT.md",
    "CANONICAL.md",
    "REPEAT.md",
    "COMPOUND.md",
    "COMPOUND_EVENTS.md",
    "GLOBAL_CONTEXT.md",
    "RELEASE.md",
    "TRANSFORMS.md",
    "FULLBAND.md",
    "CHECKS.md",
    "Start-DSP.cmd",
})
WORKBENCH_ASSETS = frozenset({"index.html", "app.css", "app.js"})
REPRODUCTION_TOOLS = frozenset({
    "build_handoff.py", "collect_dependency_notices.py", "run_handoff_demo.py",
    "run_pipeline_demo.py",
    "run_saved_pipeline_demo.py",
    "run_instrument_development_check.py",
    "independent_eval_execute.py", "instrument_eval_execute.py", "repeat_eval_execute.py",
    "run_external_pipeline_trial.py", "prepare_local_ffmpeg_trial.py",
    "run_repeat_development_check.py",
    "run_compound_development_check.py",
    "run_compound_event_development_check.py",
    "run_global_context_development_check.py",
    "compound_event_eval_execute.py",
    "global_context_eval_execute.py",
    "run_transform_model_demo.py",
    "run_fullband_demo.py",
    "run_local_checks.py",
    "run_scoped_adoption_check.py",
    "run_regression_suite_demo.py",
})
EXCLUDED_PARTS = frozenset({
    "__pycache__", "build", "dist", "evaluations", "examples", "tests", "tools",
    "voiceguard", "personalwav", "model_keys", "private_audio", "node_modules",
})
SYNTHETIC_TEST_RESULTS = frozenset({
    "synthetic_basic_clean.json", "synthetic_basic_delete.json", "synthetic_basic_repeat.json",
    "synthetic_telephone_clean.json", "synthetic_telephone_delete.json", "synthetic_telephone_repeat.json",
    "synthetic_global_baseline.json",
})
BUILD_ONLY_TESTS = frozenset({"test_windows_portable.py", "test_windows_entry.py"})


class HandoffError(ValueError):
    """A source, destination, or built artifact failed a handoff safety check."""


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _linked(path: Path) -> bool:
    info = path.lstat()
    # Junctions and other Windows reparse points also require rejection.
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0)
        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    )


def _safe_existing(path: Path, *, directory: bool = False) -> Path:
    if ".." in path.parts:
        raise HandoffError("Filesystem paths must not contain parent traversal.")
    path = path.absolute()
    for component in reversed((path, *path.parents)):
        if _linked(component):
            raise HandoffError("Links or reparse points are not permitted: " + str(component))
    info = path.stat()
    if directory:
        if not stat.S_ISDIR(info.st_mode):
            raise HandoffError("Expected an existing directory: " + str(path))
    elif not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise HandoffError("Expected a regular file with one link: " + str(path))
    # The sandbox may deny Win32 final-path resolution of newly created files.
    # Absolute normalization is sufficient after validating every ancestor.
    return path


def _safe_relative(value: str) -> PurePosixPath:
    path = PurePosixPath(value)
    if (not value or "\\" in value or ":" in value or path.is_absolute()
            or any(part in {"", ".", ".."} for part in value.split("/"))):
        raise HandoffError("Unsafe relative artifact path: " + value)
    return path


def _notice_name(path: Path | PurePosixPath) -> bool:
    return (path.suffix.lower() in {".txt", ".md", ".json"}
            or path.name.upper().startswith(("LICENSE", "COPYING", "NOTICE", "AUTHORS", "COPYRIGHT")))


def _allowed(relative: PurePosixPath) -> bool:
    parts = relative.parts
    if len(parts) == 4 and parts[:3] == ("tests", "fixtures", "results"):
        return parts[3] in SYNTHETIC_TEST_RESULTS
    if len(parts) == 2 and parts[0] == "tools":
        return parts[1] in REPRODUCTION_TOOLS
    if len(parts) == 2 and parts[0] == "tests":
        return (relative.suffix == ".py" and not relative.name.startswith(".")
                and relative.name not in BUILD_ONLY_TESTS)
    if any(part.startswith(".") or part.lower() in EXCLUDED_PARTS for part in parts):
        return False
    if len(parts) == 1:
        return parts[0] in ROOT_DOCUMENTS
    if parts[0] == "dependency_notices":
        return _notice_name(relative)
    if parts[:2] != ("src", PACKAGE):
        return False
    if len(parts) == 4 and parts[2] == "workbench_assets":
        return parts[3] in WORKBENCH_ASSETS
    if len(parts) == 4 and parts[2] == "schemas":
        return relative.suffix == ".json"
    return relative.suffix == ".py" and "schemas" not in parts[2:]


def _selected_sources(source: Path) -> list[Path]:
    selected = []
    for name in sorted(ROOT_DOCUMENTS):
        path = source / name
        if os.path.lexists(path):
            selected.append(_safe_existing(path))
    for name in sorted(REPRODUCTION_TOOLS):
        path = source / "tools" / name
        if os.path.lexists(path):
            selected.append(_safe_existing(path))
    tests = source / "tests"
    if os.path.lexists(tests):
        _safe_existing(tests, directory=True)
        for path in sorted(tests.iterdir()):
            if _allowed(PurePosixPath(path.relative_to(source).as_posix())):
                selected.append(_safe_existing(path))
        fixtures = tests / "fixtures" / "results"
        if os.path.lexists(fixtures):
            _safe_existing(fixtures, directory=True)
            for name in sorted(SYNTHETIC_TEST_RESULTS):
                path = fixtures / name
                if os.path.lexists(path):
                    selected.append(_safe_existing(path))
    for folder in (source / "src" / PACKAGE, source / "dependency_notices"):
        if not os.path.lexists(folder):
            continue
        _safe_existing(folder, directory=True)
        for current, dirs, files in os.walk(folder, followlinks=False):
            current_path = Path(current)
            retained = []
            for name in sorted(dirs):
                if name.startswith(".") or name.lower() in EXCLUDED_PARTS:
                    continue
                child = current_path / name
                _safe_existing(child, directory=True)
                if folder.name == PACKAGE and name not in {"schemas", "workbench_assets"} and not (child / "__init__.py").is_file():
                    # Only actual nested Python packages qualify as DSP source.
                    continue
                retained.append(name)
            dirs[:] = retained
            for name in sorted(files):
                path = current_path / name
                relative = PurePosixPath(path.relative_to(source).as_posix())
                if _allowed(relative):
                    selected.append(_safe_existing(path))
    return sorted(selected, key=lambda item: item.relative_to(source).as_posix())


def _validate_project(source: Path) -> dict:
    metadata = tomllib.loads((source / "pyproject.toml").read_text(encoding="utf-8"))
    build = metadata.get("build-system", {})
    project = metadata.get("project", {})
    setup = metadata.get("tool", {}).get("setuptools", {})
    if build.get("build-backend") != "setuptools.build_meta" or "backend-path" in build:
        raise HandoffError("Only the installed setuptools.build_meta backend is permitted.")
    if not build.get("requires") or any(
        not requirement.startswith("setuptools") or "@" in requirement or ":" in requirement
        for requirement in build["requires"]
    ):
        raise HandoffError("Build requirements must use the installed setuptools only.")
    if project.get("name") != PROJECT_NAME or project.get("dynamic"):
        raise HandoffError("The handoff requires static audio-regression-engine metadata.")
    if not re.fullmatch(r"[A-Za-z0-9_.+]+", project.get("version", "")):
        raise HandoffError("The project requires a static package version.")
    if setup.get("packages", {}).get("find", {}).get("where") != ["src"]:
        raise HandoffError("Package discovery must be confined to src.")
    if setup.get("py-modules") or setup.get("data-files"):
        raise HandoffError("Additional modules and data-files are not in the DSP allowlist.")
    if any(key in setup for key in ("cmdclass", "ext-modules", "package-dir", "dynamic")):
        raise HandoffError("Custom setuptools hooks and external source paths are not permitted.")
    readme = project.get("readme")
    if isinstance(readme, str) and readme != "README.md":
        raise HandoffError("Project readme must use the staged README.md.")
    if isinstance(readme, dict) and readme.get("file", "README.md") != "README.md":
        raise HandoffError("Project readme must use the staged README.md.")
    if isinstance(project.get("license"), dict) and "file" in project["license"]:
        raise HandoffError("External license files are not part of this source allowlist.")
    for target in project.get("scripts", {}).values():
        if not isinstance(target, str) or not target.startswith(PACKAGE + "."):
            raise HandoffError("Console entry points must belong to audio_regression.")
    return project


def _destination(output: Path, destination: Path, source: Path) -> Path:
    if ".." in output.parts or ".." in destination.parts:
        raise HandoffError("Destination paths must not contain parent traversal.")
    base = _safe_existing(destination, directory=True)
    parent = _safe_existing(output.absolute().parent, directory=True)
    resolved = parent / output.name
    if resolved == base or not resolved.is_relative_to(base):
        raise HandoffError("Output must be a new child of the explicit destination.")
    protected = (source / "src", source / "tests", source / "tools", source / "dependency_notices")
    deliverables = source / "deliverables"
    if (resolved == source or source.is_relative_to(resolved)
            or any(resolved == folder or resolved.is_relative_to(folder) for folder in protected)
            or (resolved.is_relative_to(source) and
                (resolved == deliverables or not resolved.is_relative_to(deliverables)))):
        raise HandoffError("Output must not overlap DSP input directories or their ancestors.")
    if os.path.lexists(resolved):
        raise HandoffError("Output already exists; a new output directory is required.")
    return resolved


def _write_new(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    _safe_existing(path.parent, directory=True)
    with path.open("xb") as stream:
        stream.write(data)


def _json_new(path: Path, value: object) -> None:
    _write_new(path, (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8"))


def stage_source(source: Path, stage: Path) -> list[dict]:
    """Copy only regular allowlisted files, recording the exact input bytes."""
    inventory = []
    for path in _selected_sources(source):
        relative = path.relative_to(source).as_posix()
        data = path.read_bytes()
        # Reject a concurrent source replacement before copying any changed target.
        _safe_existing(path)
        _write_new(stage / relative, data)
        inventory.append({"path": relative, "bytes": len(data), "sha256": _sha256(data)})
    return inventory


def verify_stage(stage: Path, inventory: list[dict]) -> None:
    """Fail closed if staged inputs disappeared, changed, or gained extra files."""
    expected = {entry["path"]: entry for entry in inventory}
    actual = {path.relative_to(stage).as_posix() for path in _selected_sources(stage)}
    if actual != set(expected):
        raise HandoffError("Staged source inventory changed.")
    for folder in (stage / "src" / PACKAGE, stage / "dependency_notices", stage / "tools", stage / "tests"):
        if not folder.exists():
            continue
        _safe_existing(folder, directory=True)
        for current, dirs, files in os.walk(folder, followlinks=False):
            for name in dirs:
                _safe_existing(Path(current) / name, directory=True)
            for name in files:
                path = _safe_existing(Path(current) / name)
                if path.relative_to(stage).as_posix() not in expected:
                    raise HandoffError("Unexpected file in staged input: " + path.relative_to(stage).as_posix())
    for relative, entry in expected.items():
        path = _safe_existing(stage / relative)
        data = path.read_bytes()
        if len(data) != entry["bytes"] or _sha256(data) != entry["sha256"]:
            raise HandoffError("Staged source bytes changed: " + relative)


def verify_source(source: Path, inventory: list[dict]) -> None:
    """Detect original project edits during staging or wheel construction."""
    expected = {entry["path"]: entry for entry in inventory}
    actual = {path.relative_to(source).as_posix() for path in _selected_sources(source)}
    if actual != set(expected):
        raise HandoffError("Original DSP source inventory changed during the build.")
    for relative, entry in expected.items():
        data = _safe_existing(source / relative).read_bytes()
        if len(data) != entry["bytes"] or _sha256(data) != entry["sha256"]:
            raise HandoffError("Original DSP source bytes changed during the build: " + relative)


def installed_dependency_inventory() -> list[dict]:
    """Describe installed versions; never resolve, download, or install a package."""
    rows = []
    for name in ("setuptools", "pip", "numpy", "scipy", "pytest"):
        try:
            distribution = importlib.metadata.distribution(name)
        except importlib.metadata.PackageNotFoundError:
            rows.append({"name": name, "installed": False})
            continue
        notices = []
        for relative in distribution.files or ():
            path = PurePosixPath(str(relative).replace("\\", "/"))
            in_metadata_notices = any(part.endswith(".dist-info") for part in path.parts) and "licenses" in path.parts
            named_notice = "LICENSE" in path.name.upper() or path.name.upper().startswith(("COPYING", "NOTICE", "AUTHORS", "COPYRIGHT"))
            if _notice_name(path) and (in_metadata_notices or named_notice):
                candidate = Path(distribution.locate_file(relative))
                if candidate.is_file():
                    data = _safe_existing(candidate).read_bytes()
                    notices.append({"path": path.as_posix(), "bytes": len(data), "sha256": _sha256(data)})
        rows.append({"name": name, "installed": True, "version": distribution.version,
                     "notices": sorted(notices, key=lambda item: item["path"])})
    return rows


def copy_runtime_notices(output: Path, dependencies: list[dict]) -> list[dict]:
    """Copy complete installed NumPy/SciPy notice files, including bundled notices."""
    copied = []
    for dependency in dependencies:
        if dependency["name"] not in {"numpy", "scipy"}:
            continue
        if not dependency["installed"] or not dependency["notices"]:
            raise HandoffError("Installed runtime notices are unavailable: " + dependency["name"])
        distribution = importlib.metadata.distribution(dependency["name"])
        for notice in dependency["notices"]:
            relative = _safe_relative(notice["path"])
            source = _safe_existing(Path(distribution.locate_file(str(relative))))
            data = source.read_bytes()
            if _sha256(data) != notice["sha256"]:
                raise HandoffError("An installed dependency notice changed.")
            target = PurePosixPath("dependency_notices") / (dependency["name"] + "-" + dependency["version"]) / relative
            _safe_relative(target.as_posix())
            _write_new(output / str(target), data)
            copied.append({"path": target.as_posix(), "bytes": len(data), "sha256": _sha256(data)})
    return copied


def inspect_wheel(wheel: Path, stage: Path, source_inventory: list[dict], version: str) -> list[dict]:
    """Require exact DSP payload bytes and ordinary wheel metadata only."""
    expected = {entry["path"][4:]: entry for entry in source_inventory if entry["path"].startswith("src/")}
    dist_info = "audio_regression_engine-" + version.replace("-", "_") + ".dist-info"
    allowed_metadata = {"METADATA", "WHEEL", "entry_points.txt", "top_level.txt", "RECORD"}
    entries, seen, payload = [], set(), set()
    with zipfile.ZipFile(_safe_existing(wheel)) as archive:
        for member in archive.infolist():
            relative = _safe_relative(member.filename)
            name = relative.as_posix()
            if name in seen or stat.S_ISLNK(member.external_attr >> 16) or member.is_dir():
                raise HandoffError("Wheel contains a duplicate, link, or directory entry.")
            seen.add(name)
            data = archive.read(member)
            if name in expected:
                if _sha256(data) != expected[name]["sha256"]:
                    raise HandoffError("Wheel source bytes differ: " + name)
                payload.add(name)
            elif (relative.parts[0] == dist_info and len(relative.parts) == 2
                  and relative.parts[1] in allowed_metadata):
                if relative.name == "top_level.txt" and data.decode("utf-8").split() != [PACKAGE]:
                    raise HandoffError("Wheel advertises an additional top-level package.")
            elif (relative.parts[0] == dist_info and len(relative.parts) >= 3
                  and relative.parts[1] == "licenses" and _notice_name(relative)):
                pass
            else:
                raise HandoffError("Wheel contains a non-DSP file: " + name)
            entries.append({"path": name, "bytes": len(data), "sha256": _sha256(data)})
    if payload != set(expected):
        raise HandoffError("Wheel is missing staged DSP code or schemas.")
    for required in ("METADATA", "WHEEL", "RECORD"):
        if dist_info + "/" + required not in seen:
            raise HandoffError("Wheel metadata is incomplete.")
    verify_stage(stage, source_inventory)
    return sorted(entries, key=lambda entry: entry["path"])


def build_handoff(source: Path, output: Path, destination: Path, *, source_snapshot: bool = False,
                  runtime_notices: bool = False) -> dict:
    source = _safe_existing(source, directory=True)
    # Validate and enumerate before creating anything in the destination.
    selected = _selected_sources(source)
    required = {source / "pyproject.toml", source / "README.md", source / "src" / PACKAGE / "__init__.py"}
    if not required.issubset(selected):
        raise HandoffError("DSP project metadata, README, and package initializer are required.")
    project = _validate_project(source)
    output = _destination(output, destination, source)
    dependencies = installed_dependency_inventory()
    for name in ("setuptools", "pip"):
        if not any(row["name"] == name and row["installed"] for row in dependencies):
            raise HandoffError("The existing interpreter must provide " + name + ".")
    output.mkdir(exist_ok=False)
    stage = output / "source"
    stage.mkdir()
    inventory = stage_source(source, stage)
    verify_stage(stage, inventory)
    verify_source(source, inventory)
    dist = output / "dist"
    dist.mkdir()
    environment = {key: value for key, value in os.environ.items()
                   if not key.startswith("PIP_") and key not in {"PYTHONPATH", "PYTHONHOME"}}
    environment.update({"PIP_CONFIG_FILE": os.devnull, "PIP_NO_INDEX": "1",
                        "PIP_DISABLE_PIP_VERSION_CHECK": "1", "PYTHONDONTWRITEBYTECODE": "1"})
    command = [sys.executable, "-I", "-m", "pip", "wheel", "--no-deps", "--no-build-isolation",
               "--no-index", "--no-cache-dir", "--disable-pip-version-check", "--wheel-dir", str(dist), str(stage)]
    result = subprocess.run(command, cwd=output, env=environment, capture_output=True, text=True,
                            encoding="utf-8", errors="replace", check=False)
    _write_new(output / "build.log", (result.stdout + result.stderr).encode("utf-8"))
    if result.returncode:
        raise HandoffError("Offline wheel build failed; the new output and build.log were retained.")
    wheels = list(dist.glob("*.whl"))
    if len(wheels) != 1:
        raise HandoffError("Expected exactly one newly built DSP wheel.")
    wheel_entries = inspect_wheel(wheels[0], stage, inventory, project["version"])
    verify_source(source, inventory)
    notices = copy_runtime_notices(output, dependencies) if runtime_notices else []
    snapshot = None
    if source_snapshot:
        snapshot = output / "dsp-source.zip"
        with zipfile.ZipFile(snapshot, "x", compression=zipfile.ZIP_DEFLATED) as archive:
            for entry in inventory:
                archive.write(_safe_existing(stage / entry["path"]), entry["path"])
        verify_stage(stage, inventory)
    verify_source(source, inventory)
    report = {
        "format_version": 1, "project": PROJECT_NAME, "version": project["version"],
        "offline": True, "dependencies_bundled_in_wheel": False,
        "build_interpreter": {"version": sys.version.split()[0], "implementation": sys.implementation.name},
        "build_options": ["--no-deps", "--no-build-isolation", "--no-index", "--no-cache-dir"],
        "source_inventory": inventory, "installed_dependencies": dependencies,
        "wheel": {"path": wheels[0].relative_to(output).as_posix(), "sha256": _sha256(wheels[0].read_bytes()),
                  "bytes": wheels[0].stat().st_size, "inventory": wheel_entries},
        "runtime_notices": notices,
        "source_snapshot": None if snapshot is None else {
            "path": snapshot.name, "sha256": _sha256(snapshot.read_bytes()), "bytes": snapshot.stat().st_size},
        "retained_build_artifacts": "source/build and source/*.egg-info may contain setuptools-generated DSP artifacts only",
        "scope": "private local DSP handoff; no own-code license or publication permission is assigned",
    }
    _json_new(output / "inventory.json", report)
    _write_new(output / "SHA256SUMS.txt", (report["wheel"]["sha256"] + "  " + report["wheel"]["path"] + "\n"
               + ("" if snapshot is None else report["source_snapshot"]["sha256"] + "  " + snapshot.name + "\n")).encode("utf-8"))
    return report


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--source-dir", type=Path, default=Path(__file__).absolute().parents[1])
    parser.add_argument("--output-dir", type=Path, required=True, help="An absent final directory; existing output is never replaced.")
    parser.add_argument("--destination", type=Path, help="Existing permitted parent; defaults to output-dir.parent.")
    parser.add_argument("--source-snapshot", action="store_true", help="Archive only the explicit staged DSP source allowlist.")
    parser.add_argument("--copy-runtime-notices", action="store_true", help="Copy installed NumPy/SciPy complete notice files into this new handoff.")
    args = parser.parse_args(argv)
    try:
        report = build_handoff(args.source_dir, args.output_dir, args.destination or args.output_dir.parent,
                               source_snapshot=args.source_snapshot, runtime_notices=args.copy_runtime_notices)
    except (HandoffError, OSError, zipfile.BadZipFile, tomllib.TOMLDecodeError) as error:
        print(json.dumps({"status": "error", "message": str(error)}, ensure_ascii=False))
        return 3
    print(json.dumps({"status": "built", "inventory": str(args.output_dir / "inventory.json"),
                      "wheel": report["wheel"]["path"], "sha256": report["wheel"]["sha256"]}, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
