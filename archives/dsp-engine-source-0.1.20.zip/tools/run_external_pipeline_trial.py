"""One append-only internal FFmpeg integration trial using owned test audio.

This is not a customer workflow, natural-audio evaluation, or ROI study. It
never reads sealed evaluation files and does not fetch or install an executable.
An explicitly supplied local FFmpeg or one already on PATH is required.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

import numpy as np

import audio_regression
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.pipeline_transforms import execute_stage
from audio_regression.saved_pipeline import audit_saved_pipeline
from audio_regression.saved_pipeline_contract import load_saved_pipeline_result, validate_saved_pipeline_result
from audio_regression.saved_pipeline_reporting import write_saved_pipeline_html


RATE = 16000
DURATION_SECONDS = 8
CASES = ("normal", "delete_400ms", "repeat_400ms")
LABELS = ("Gain -6 dB", "Resample 16 to 8 kHz", "Leading delay 240 ms",
          "Assembly output", "Following unity-gain output")
DECLARATIONS = ((True, False), (False, True), (False, False),
                (False, False), (True, False))
FILES = ("source.wav", "gain.wav", "resample.wav", "delay.wav",
         "assembled.wav", "final.wav")


class ExternalTrialError(ValueError):
    """A stable failure code; completed and partial artifacts stay on disk."""

    def __init__(self, code):
        self.code = code
        super().__init__(code)


def _new_bytes(path, raw):
    with path.open("xb") as stream:
        stream.write(raw)


def _new_json(path, value):
    _new_bytes(path, (json.dumps(value, ensure_ascii=False, allow_nan=False,
                                indent=2) + "\n").encode("utf-8"))


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _owned_signal():
    """Deterministic synthetic harmonic signal, not disguised natural audio."""
    t = np.arange(RATE * DURATION_SECONDS, dtype=float) / RATE
    frequency = 311 + 17 * t + 2.3 * np.sin(2 * np.pi * .61 * t)
    phase = 2 * np.pi * np.cumsum(frequency) / RATE
    envelope = .57 + .13 * np.sin(2 * np.pi * .29 * t) + .09 * np.sin(2 * np.pi * .11 * t + .8)
    values = envelope * (np.sin(phase) + .27 * np.sin(2 * phase + .3)
                         + .13 * np.sin(3 * phase + .9))
    return values * (.28 / np.max(np.abs(values)))


def _plan():
    return {"schema_version": 1, "engine": "v4", "profile": "basic",
            "source": {"kind": "owned_synthetic_harmonic_signal", "rate_hz": RATE,
                       "duration_seconds": DURATION_SECONDS,
                       "formula_id": "external_pipeline_chirp_311hz_v1"},
            "cases": list(CASES), "stages": list(LABELS),
            "fault_source_interval_ms": [2400, 2800],
            "fault_delayed_input_interval_ms": [2640, 3040],
            "expected_first_concern": {"normal": None, "delete_400ms": 4, "repeat_400ms": 4},
            "earlier_concerns_must_remain_sticky": True,
            "expected_behavior_not_supplied_to_analyzer": True,
            "allowed_scope": "internal_external_processor_integration_not_customer_value",
            "independent_evaluation": False, "sealed_evaluation_replayed": False,
            "commercial_performance_validated": False, "customer_contacted": False}


def _find_ffmpeg(value=None):
    raw = os.fspath(value) if value is not None else shutil.which("ffmpeg")
    if raw is None:
        return None
    path = Path(os.path.abspath(raw))
    if path.is_symlink() or not path.is_file():
        raise ExternalTrialError("invalid_local_ffmpeg")
    return path


def _subprocess(command, *, timeout):
    # An argument vector, no shell, no stdin, no network or implicit overwrite.
    try:
        return subprocess.run(command, shell=False, stdin=subprocess.DEVNULL,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              check=False, timeout=timeout,
                              creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    except subprocess.TimeoutExpired:
        raise ExternalTrialError("external_processor_timeout") from None
    except OSError:
        raise ExternalTrialError("external_processor_execution_error") from None


def _version(executable):
    command = [str(executable), "-nostdin", "-version"]
    outcome = _subprocess(command, timeout=10)
    text = outcome.stdout[:16384].decode("utf-8", errors="replace")
    if outcome.returncode != 0 or not text.startswith("ffmpeg version "):
        raise ExternalTrialError("unrecognized_ffmpeg_version")
    return {"command": command, "returncode": outcome.returncode,
            "version_output": text, "executable_sha256": _sha(executable)}


def _ffmpeg_command(executable, source, destination, stage, case):
    command = [str(executable), "-nostdin", "-n", "-hide_banner", "-loglevel", "error",
               "-i", str(source)]
    if stage == 1:
        command += ["-af", "volume=-6dB"]
    elif stage == 2:
        command += ["-af", "aresample=8000:dither_method=none", "-ar", "8000"]
    elif stage == 3:
        command += ["-af", "adelay=1920S:all=1"]
    elif stage == 4 and case == "delete_400ms":
        command += ["-filter_complex", (
            "[0:a]asplit=2[a][b];[a]atrim=end_sample=21120,asetpts=PTS-STARTPTS[x];"
            "[b]atrim=start_sample=24320,asetpts=PTS-STARTPTS[y];"
            "[x][y]concat=n=2:v=0:a=1[out]"), "-map", "[out]"]
    elif stage == 4 and case == "repeat_400ms":
        command += ["-filter_complex", (
            "[0:a]asplit=3[a][b][c];[a]atrim=end_sample=24320,asetpts=PTS-STARTPTS[x];"
            "[b]atrim=start_sample=21120:end_sample=24320,asetpts=PTS-STARTPTS[y];"
            "[c]atrim=start_sample=24320,asetpts=PTS-STARTPTS[z];"
            "[x][y][z]concat=n=3:v=0:a=1[out]"), "-map", "[out]"]
    else:
        command += ["-af", "volume=0dB" if stage == 5 else "anull"]
    command += ["-vn", "-ac", "1", "-c:a", "pcm_s16le", "-f", "wav", str(destination)]
    return command


def _transform(executable, source, destination, stage, case, journal):
    if os.path.lexists(destination):
        raise ExternalTrialError("external_output_exists")
    input_hash = _sha(source)
    command = _ffmpeg_command(executable, source, destination, stage, case)
    start = time.perf_counter()
    result = _subprocess(command, timeout=30)
    record = {"stage_index": stage, "command": command, "returncode": result.returncode,
              "input_sha256": input_hash, "output_sha256": None,
              "runtime_ms": (time.perf_counter() - start) * 1000,
              "stderr": result.stderr[:10000].decode("utf-8", errors="replace")}
    if result.returncode == 0 and destination.is_file():
        decode_wav(destination.read_bytes())
        record["output_sha256"] = _sha(destination)
    journal.write((json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n").encode("utf-8"))
    journal.flush()
    if _sha(source) != input_hash:
        raise ExternalTrialError("external_input_changed")
    if result.returncode != 0 or record["output_sha256"] is None:
        raise ExternalTrialError("external_processor_failed")
    return record


def _native_stage(raw, stage, case):
    audio = decode_wav(raw)
    if stage in (1, 2, 5):
        spec = {"kind": "gain", "gain_db": -6 if stage == 1 else 0}
        if stage == 2:
            spec = {"kind": "resample", "target_rate_hz": 8000}
        return execute_stage(audio, spec)[0]
    if stage == 3:
        return encode_wav(np.concatenate((np.zeros(1920), audio.samples)), 8000)
    values = audio.samples
    if case == "delete_400ms":
        values = np.concatenate((values[:21120], values[24320:]))
    elif case == "repeat_400ms":
        values = np.concatenate((values[:24320], values[21120:24320], values[24320:]))
    return encode_wav(values, 8000)


def _manifest():
    return {"schema_version": 1, "source": "supplied/source.wav", "stages": [
        {"label": label, "output": "supplied/" + name,
         "declaration": {"allow_gain": gain, "allow_resampling": rate}}
        for label, name, (gain, rate) in zip(LABELS, FILES[1:], DECLARATIONS, strict=True)]}


def _audit(folder):
    manifest_path = folder / "saved_manifest.json"
    _new_json(manifest_path, _manifest())
    start = time.perf_counter()
    result = audit_saved_pipeline(manifest_path, folder / "audit", engine="v4")
    elapsed = (time.perf_counter() - start) * 1000
    validate_saved_pipeline_result(result)
    write_saved_pipeline_html(result, folder / "audit/audit_report.html")
    return result, elapsed


def _observation(result, case):
    expected_stage = None if case == "normal" else 4
    concern = result["summary"]["first_concern"]
    stage = None if concern is None else concern["stage_index"]
    code = result["summary"]["exit_code"]
    expected_code = 0 if case == "normal" else 1
    analysis = result["stages"][3]["analysis"]
    coordinates = _event_matches(analysis, case)
    return {"summary": result["summary"], "input_recheck": result["input_recheck"],
            "expected_behavior_met": result["status"] == "completed" and stage == expected_stage
            and code == expected_code and result["input_recheck"]["status"] == "unchanged"
            and coordinates,
            "supported_event_coordinates_met": coordinates,
            "following_stage_clear": result["stages"][-1]["check"] is not None
            and result["stages"][-1]["check"]["exit_code"] == 0,
            "stage_statuses": [s["status"] for s in result["stages"]],
            "stage_gate_states": [None if s["check"] is None else s["check"]["gate_state"]
                                  for s in result["stages"]]}


def _event_matches(analysis, case):
    if analysis is None or analysis.get("status") != "analyzed":
        return False
    events = analysis.get("events")
    if case == "normal":
        return events == []
    if type(events) is not list or len(events) != 1:
        return False
    event = events[0]
    if case == "delete_400ms":
        return (event.get("type") == "delete"
                and event.get("reference_interval_ms") == [2640.0, 3040.0]
                and event.get("processed_boundary_ms") == 2640.0)
    return (event.get("type") == "repeat"
            and event.get("reference_source_interval_ms") == [2640.0, 3040.0]
            and event.get("processed_added_interval_ms") == [3040.0, 3440.0])


def _wave_difference(left, right):
    a, b = decode_wav(left), decode_wav(right)
    if a.sample_rate_hz != b.sample_rate_hz or a.samples.size != b.samples.size:
        return {"same_rate_and_sample_count": False, "rms_difference": None, "peak_difference": None}
    delta = a.samples - b.samples
    return {"same_rate_and_sample_count": True,
            "rms_difference": float(np.sqrt(np.mean(delta * delta))),
            "peak_difference": float(np.max(np.abs(delta))),
            "byte_identical": left == right}


def verify_saved_trial(output_dir):
    """Check existing trial artifacts without transforming or analyzing audio.

    Exact coordinates derive from the already recorded assembly instructions;
    this is artifact verification, not a new independent performance estimate.
    The original summary is retained byte-for-byte, including failed expectations.
    """
    target = Path(os.path.abspath(output_dir))
    summary_path = target / "trial_summary.json"
    old_hash = _sha(summary_path)
    summary = json.loads(summary_path.read_text("utf-8"))
    records = []
    for case in CASES:
        for kind in ("external", "native"):
            folder = target / case / kind
            result_path = folder / "audit/audit_result.json"
            result = load_saved_pipeline_result(result_path)
            expected = [result["source"]] + [s["output"] for s in result["stages"]]
            current = [decode_wav((folder / "supplied" / name).read_bytes()).metadata() for name in FILES]
            if expected != current or result["source"]["sha256"] != summary["source_sha256"]:
                raise ExternalTrialError("trial_input_or_metadata_changed")
            records.append({"case": case, "processor": kind,
                            "result_sha256": _sha(result_path), **_observation(result, case)})
    if _sha(summary_path) != old_hash:
        raise ExternalTrialError("trial_summary_changed_during_verification")
    verification = {"schema_version": 1, "status": "completed", "analysis_replayed": False,
                    "external_processing_replayed": False, "original_summary_sha256": old_hash,
                    "input_metadata_and_hashes_verified": True,
                    "contract_checked_audits": len(records), "records": records,
                    "expected_behavior_count": sum(row["expected_behavior_met"] for row in records),
                    "total_audits": len(records), "customer_workflow_value_validated": False,
                    "independent_evaluation": False, "sealed_evaluation_replayed": False}
    _new_json(target / "trial_verification.json", verification)
    return verification


def run(output_dir, ffmpeg_path=None):
    target = Path(os.path.abspath(output_dir))
    if os.path.lexists(target):
        raise ExternalTrialError("output_directory_exists")
    # No link traversal for generated files; existing directories are never removed.
    if any(parent.is_symlink() for parent in target.parents):
        raise ExternalTrialError("unsafe_output_parent")
    target.mkdir(parents=True, exist_ok=False)
    _new_json(target / "trial_plan.json", _plan())
    summary = {"schema_version": 1, "status": "started", "package_version": audio_regression.__version__,
               "engine": "v4", "case_count": 0, "records": [], "network_used": False,
               "independent_evaluation": False, "sealed_evaluation_replayed": False,
               "customer_contacted": False, "customer_workflow_value_validated": False,
               "commercial_performance_validated": False, "external_pipeline_executed": False,
               "internal_integration_expectations_met": False}
    try:
        executable = _find_ffmpeg(ffmpeg_path)
        if executable is None:
            summary.update(status="blocked", reason_code="local_ffmpeg_unavailable",
                           requirement="Supply an already installed local FFmpeg executable; no binary was downloaded.")
            _new_json(target / "trial_summary.json", summary)
            return summary
        _new_json(target / "external_processor.json", _version(executable))
        original = encode_wav(_owned_signal(), RATE)
        summary["source_sha256"] = hashlib.sha256(original).hexdigest()
        for case in CASES:
            folder = target / case
            external, native = folder / "external", folder / "native"
            for path in (external / "supplied", native / "supplied"):
                path.mkdir(parents=True)
                _new_bytes(path / FILES[0], original)
            commands = []
            with (external / "processor_commands.jsonl").open("xb") as journal:
                for stage in range(1, 6):
                    left, right = FILES[stage - 1], FILES[stage]
                    commands.append(_transform(executable, external / "supplied" / left,
                                               external / "supplied" / right, stage, case, journal))
                    _new_bytes(native / "supplied" / right,
                               _native_stage((native / "supplied" / left).read_bytes(), stage, case))
            summary["external_pipeline_executed"] = True
            record = {"case": case, "processor_command_count": len(commands), "external": None,
                      "native": None, "per_stage_waveform_difference": []}
            for name in FILES[1:]:
                record["per_stage_waveform_difference"].append({"file": name, **_wave_difference(
                    (external / "supplied" / name).read_bytes(), (native / "supplied" / name).read_bytes())})
            for label, path in (("external", external), ("native", native)):
                result, elapsed = _audit(path)
                record[label] = {**_observation(result, case), "audit_runtime_ms": elapsed,
                                 "result": f"{case}/{label}/audit/audit_result.json",
                                 "report": f"{case}/{label}/audit/audit_report.html"}
            summary["records"].append(record)
            summary["case_count"] += 1
        summary.update(status="completed", reason_code=None,
                       internal_integration_expectations_met=all(
                           row[kind]["expected_behavior_met"] for row in summary["records"]
                           for kind in ("external", "native")))
        _new_json(target / "trial_summary.json", summary)
        return summary
    except Exception as exc:
        summary.update(status="incomplete", reason_code=getattr(exc, "code", "internal_trial_error"))
        _new_json(target / "trial_summary.json", summary)
        raise


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--ffmpeg-path", type=Path)
    parser.add_argument("--verify-results-only", action="store_true")
    options = parser.parse_args()
    result = verify_saved_trial(options.output_dir) if options.verify_results_only else run(
        options.output_dir, options.ffmpeg_path)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    if options.verify_results_only:
        raise SystemExit(0)
    raise SystemExit(0 if result["status"] == "completed" and result["internal_integration_expectations_met"] else 2)
