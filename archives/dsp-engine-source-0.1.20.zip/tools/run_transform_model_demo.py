"""Fresh independent-oracle usage examples, not natural-audio accuracy evidence.

The observed processing is implemented below with Python integer/Fraction
arithmetic, not with the production transform renderer. Results are from 21
owned synthetic scenarios, each with v1 and explicit v9. Baseline comparison
uses the current public unmodified original-to-observed API; it is a feature
demonstration, not an independent model-performance comparison.
"""

from __future__ import annotations

import argparse
from collections import Counter
from fractions import Fraction
import hashlib
import json
import math
import os
from pathlib import Path
import struct

import numpy as np

from audio_regression import __version__
from audio_regression.api import analyze_pair
from audio_regression.check_policy import check_result
from audio_regression.model_check import run_model_check
from audio_regression.model_reporting import write_model_html
from audio_regression.reporting import write_html_report


SEED = 2026101459301
RATES = (8000, 16000, 44100, 48000)
ENGINES = ("v1", "v9")
KINDS = ("polarity_invert", "fir_binomial_3", "pcm_quantize_12")


def _new_bytes(path: Path, raw: bytes) -> None:
    with path.open("xb") as stream:
        stream.write(raw)


def _new_json(path: Path, value: object) -> None:
    _new_bytes(path, (json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n").encode("utf-8"))


def _sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _wave(pcm: list[int], rate: int) -> bytes:
    """Independent canonical PCM16 RIFF writer for already-integral values."""
    if not 2 * rate <= len(pcm) <= 30 * rate:
        raise ValueError("Owned fixture exceeds the bounded duration contract.")
    if any(type(value) is not int or not -32768 <= value <= 32767 for value in pcm):
        raise ValueError("Owned fixture is not representable PCM16.")
    payload = np.asarray(pcm, dtype="<i2").tobytes()
    return (
        b"RIFF" + struct.pack("<I", 36 + len(payload)) + b"WAVEfmt "
        + struct.pack("<IHHIIHH", 16, 1, 1, rate, 2 * rate, 2, 16)
        + b"data" + struct.pack("<I", len(payload)) + payload
    )


def _source_pcm(rate: int) -> list[int]:
    """New bounded chirps with irregular envelope; no existing audio input."""
    rng = np.random.default_rng(SEED + rate)
    count = 4 * rate
    time = np.arange(count, dtype=np.float64) / rate
    anchor = max(2, round(rate * 0.043))
    points = np.arange(0, count + anchor, anchor)
    envelope = np.interp(np.arange(count), points, rng.uniform(0.4, 0.9, len(points)))
    phase_a = 2 * math.pi * (227 * time + 147 * time * time)
    phase_b = 2 * math.pi * (1711 * time - 83 * time * time + 0.03 * np.sin(1.73 * time))
    values = envelope * (2100 * np.sin(phase_a + 0.31) + 1100 * np.sin(phase_b - 0.19))
    values += rng.normal(0, 107, count)
    pcm = np.rint(values).astype(np.int32).tolist()
    if max(abs(value) for value in pcm) >= 5000:
        raise ValueError("Owned source exceeded its fixed headroom.")
    return pcm


def _oracle(pcm: list[int], kinds: tuple[str, ...]) -> list[int]:
    """Scalar forward formula and exact rational ties-to-even, step by step."""
    values = list(pcm)
    for kind in kinds:
        if kind == "polarity_invert":
            values = [-value for value in values]
        elif kind == "fir_binomial_3":
            old = values
            values = [round(Fraction(value + 2 * (old[index - 1] if index else 0)
                                     + (old[index - 2] if index >= 2 else 0), 4))
                      for index, value in enumerate(old)]
        elif kind == "pcm_quantize_12":
            values = [16 * round(Fraction(value, 16)) for value in values]
        else:
            raise ValueError("Unknown owned oracle operation.")
        if any(not -32768 <= value <= 32767 for value in values):
            raise ValueError("Owned oracle output is outside PCM16.")
    return values


def _cases():
    for rate in RATES:
        pcm = _source_pcm(rate)
        for kind in KINDS:
            yield {
                "case": f"normal_{kind}_{rate}", "rate": rate, "source_pcm": pcm,
                "actual_pcm": _oracle(pcm, (kind,)), "models": (kind,),
                "allowed_exit_codes": (0,), "condition": "normal_declared_model",
            }
        kinds = ("fir_binomial_3", "pcm_quantize_12")
        yield {
            "case": f"normal_fir_then_pcm12_{rate}", "rate": rate, "source_pcm": pcm,
            "actual_pcm": _oracle(pcm, kinds), "models": kinds,
            "allowed_exit_codes": (0,), "condition": "normal_ordered_models",
        }

    rate = 16000
    pcm = _source_pcm(rate)
    expected = _oracle(pcm, ("polarity_invert",))
    one_sample = list(expected)
    one_sample[2 * rate + 37] += 1
    yield {
        "case": "polarity_one_pcm16_sample_changed", "rate": rate, "source_pcm": pcm,
        "actual_pcm": one_sample, "models": ("polarity_invert",),
        "allowed_exit_codes": (2,), "condition": "unexpected_one_pcm16_sample",
    }
    start = round(1.6 * rate)
    count = round(0.4 * rate)
    end = start + count
    yield {
        "case": "polarity_delete_400ms", "rate": rate, "source_pcm": pcm,
        "actual_pcm": expected[:start] + expected[end:], "models": ("polarity_invert",),
        "allowed_exit_codes": (1, 2), "condition": "post_model_internal_delete",
        "truth": {"type": "delete", "reference_interval_samples": [start, end],
                  "processed_boundary_sample": start},
    }
    yield {
        "case": "polarity_adjacent_repeat_400ms", "rate": rate, "source_pcm": pcm,
        "actual_pcm": expected[:end] + expected[start:end] + expected[end:],
        "models": ("polarity_invert",), "allowed_exit_codes": (1, 2),
        "condition": "post_model_adjacent_copy_repeat",
        "truth": {"type": "repeat", "reference_source_interval_samples": [start, end],
                  "processed_added_interval_samples": [end, end + count]},
    }
    yield {
        "case": "digital_silence_exact_pcm", "rate": rate, "source_pcm": [0] * (4 * rate),
        "actual_pcm": [0] * (4 * rate), "models": ("polarity_invert",),
        "allowed_exit_codes": (2,), "condition": "exact_pcm_but_temporal_signal_unusable",
    }
    yield {
        "case": "incorrect_fir_declaration_for_polarity", "rate": rate,
        "source_pcm": pcm, "actual_pcm": expected, "models": ("fir_binomial_3",),
        "allowed_exit_codes": (2,), "condition": "incorrect_declared_model",
    }


def run(output_dir: str | Path) -> dict:
    target = Path(os.path.abspath(output_dir))
    if os.path.lexists(target):
        raise FileExistsError("Owned development output directory already exists.")
    target.mkdir(parents=True, exist_ok=False)
    _new_json(target / "manifest_started.json", {
        "schema_version": 1, "status": "started", "seed": SEED,
        "fixture_source": "fresh_owned_pcm_and_independent_scalar_fraction_oracle",
        "natural_or_sealed_audio_replayed": False, "network_used": False,
        "planned_scenarios": 21, "planned_model_runs": 42, "planned_baseline_runs": 42,
        "allowed_results_fixed_before_observation": True,
        "evidence_scope": "development_usage_examples_not_independent_accuracy",
    })
    records = []
    for case in _cases():
        folder = target / case["case"]
        folder.mkdir()
        supplied = folder / "supplied"
        supplied.mkdir()
        source_raw = _wave(case["source_pcm"], case["rate"])
        actual_raw = _wave(case["actual_pcm"], case["rate"])
        expected_raw = _wave(_oracle(case["source_pcm"], case["models"]), case["rate"])
        _new_bytes(supplied / "source.wav", source_raw)
        _new_bytes(supplied / "actual.wav", actual_raw)
        plan = {"schema_version": 1, "models": [{"kind": kind} for kind in case["models"]]}
        _new_json(folder / "model_plan.json", plan)
        _new_json(folder / "fixture_truth.json", {
            "condition": case["condition"], "source_rate_hz": case["rate"],
            "allowed_model_exit_codes": list(case["allowed_exit_codes"]),
            "truth": case.get("truth"), "source_sha256": _sha(source_raw),
            "actual_sha256": _sha(actual_raw), "oracle_expected_sha256": _sha(expected_raw),
            "oracle_is_independent_of_production_renderer": True,
            "expectation_written_before_analysis": True,
        })
        for engine in ENGINES:
            engine_dir = folder / engine
            engine_dir.mkdir()
            result = run_model_check(supplied / "source.wav", supplied / "actual.wav",
                                     plan["models"], engine_dir / "model", engine=engine)
            write_model_html(result, engine_dir / "model" / "report.html")
            observed = result["summary"]["exit_code"]
            if observed not in case["allowed_exit_codes"]:
                raise ValueError("Owned fixed expected model outcome was not observed.")
            if (engine_dir / "model" / "expected" / "output.wav").read_bytes() != expected_raw:
                raise ValueError("Production rendering did not match the independent scalar oracle.")
            if case["condition"] == "unexpected_one_pcm16_sample":
                if (result["comparison"]["unequal_sample_count"] != 1
                        or result["comparison"]["maximum_abs_error_pcm16"] != 1):
                    raise ValueError("The known one-sample residual was not retained.")
            if case["condition"] == "exact_pcm_but_temporal_signal_unusable":
                if result["comparison"]["exact_pcm16_match"] is not True:
                    raise ValueError("Exact digital silence was not retained as a PCM match.")
            baseline_dir = engine_dir / "baseline"
            baseline_dir.mkdir()
            baseline = analyze_pair(supplied / "source.wav", supplied / "actual.wav", engine=engine)
            baseline_check = check_result(baseline)
            _new_json(baseline_dir / "analysis.json", baseline)
            _new_json(baseline_dir / "check.json", baseline_check)
            write_html_report(baseline, baseline_dir / "report.html")
            if ((supplied / "source.wav").read_bytes() != source_raw
                    or (supplied / "actual.wav").read_bytes() != actual_raw):
                raise ValueError("An owned supplied input changed during analysis.")
            records.append({
                "case": case["case"], "condition": case["condition"], "engine": engine,
                "sample_rate_hz": case["rate"], "model_plan": plan,
                "allowed_model_exit_codes": list(case["allowed_exit_codes"]),
                "expected_outcome_observed": True, "production_render_matches_scalar_oracle": True,
                "source_and_actual_bytes_and_hashes_unchanged": True,
                "source_sha256": _sha(source_raw), "actual_sha256": _sha(actual_raw),
                "expected_sha256": _sha(expected_raw), "comparison": result["comparison"],
                "model_summary": result["summary"], "child_temporal_check": result["temporal_check"],
                "child_status": result["analysis"]["status"],
                "child_event_types": [event["type"] for event in (result["analysis"].get("events") or [])],
                "baseline_status": baseline["status"], "baseline_check": baseline_check,
                "model_result": f'{case["case"]}/{engine}/model/model_result.json',
                "model_report": f'{case["case"]}/{engine}/model/report.html',
                "baseline_result": f'{case["case"]}/{engine}/baseline/analysis.json',
                "baseline_report": f'{case["case"]}/{engine}/baseline/report.html',
            })
        print(json.dumps({"scenario_completed": case["case"], "model_runs_completed": len(records)}, ensure_ascii=False), flush=True)
    if len(records) != 42:
        raise ValueError("Owned demonstration did not complete its fixed run count.")
    codes = Counter(record["model_summary"]["exit_code"] for record in records)
    baseline_codes = Counter(record["baseline_check"]["exit_code"] for record in records)
    summary = {
        "schema_version": 1, "version": __version__, "seed": SEED,
        "status": "completed_owned_development_examples", "scenario_count": 21,
        "model_run_count": 42, "baseline_run_count": 42, "all_expected_outcomes_observed": True,
        "production_render_matches_independent_scalar_oracle": True,
        "input_source_and_actual_bytes_and_hashes_unchanged": True,
        "model_gate_counts": {"matched": codes[0], "review": codes[1], "blocked": codes[2]},
        "baseline_gate_counts": {"clear_supported_temporal_check": baseline_codes[0],
                                 "review": baseline_codes[1], "blocked": baseline_codes[2]},
        "baseline_withheld_count": sum(record["baseline_status"] == "withheld" for record in records),
        "empty_child_events_never_override_model_pcm_mismatch": True,
        "digital_silence_exact_pcm_does_not_clear_temporal_withholding": True,
        "expectations_fixed_before_each_analysis": True,
        "actual_processing_generated_with_production_renderer": False,
        "natural_or_sealed_audio_replayed": False, "network_used": False,
        "independent_performance_validated": False, "commercial_performance_validated": False,
        "complete_audio_approval": False, "fault_provenance_confirmed": False,
        "accuracy_or_speed_improvement_claimed": False,
        "evidence_scope": "synthetic_usage_examples_not_natural_audio_accuracy",
        "baseline_comparison_scope": "current_public_original_to_actual_feature_comparison_only",
        "records": records,
    }
    _new_json(target / "demo_summary.json", summary)
    print(json.dumps({key: value for key, value in summary.items() if key != "records"}, ensure_ascii=False), flush=True)
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path,
                        help="New exclusive directory for owned inputs, results, and offline reports.")
    run(parser.parse_args().output_dir)
