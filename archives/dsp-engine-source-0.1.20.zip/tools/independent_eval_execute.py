"""One-use v1/v3 comparison on a separately prepared, hash-frozen corpus.

This tool never builds audio, chooses excerpts, tunes an engine, or retries a
consumed evaluation. Worker jobs contain file paths/configuration, never truth.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time

from audio_regression.evaluation_metrics import aggregate_trials, paired_group_bootstrap, score_trial


WORKSPACE = Path(__file__).resolve().parents[2]
PACKAGE = WORKSPACE / "dsp_engine/src/audio_regression"
ENGINES = ("v1", "v3")
CATEGORIES = ("speech", "music", "effects")
CRITERIA = {
    "normal_coverage_minimum": .90,
    "normal_false_alarm_count_maximum": 0,
    "event_precision_minimum": .90,
    "event_recall_minimum": .90,
    "median_primary_boundary_error_maximum_ms": 100.0,
    "median_rtf_maximum": 1.0,
    "stress_false_clear_count_maximum": 0,
    "minimum_supported_outcome_improvements": 1,
    "no_category_normal_coverage_decrease": True,
    "no_category_event_recall_decrease": True,
    "no_category_normal_false_alarm_increase": True,
}
JOB_KEYS = {"trial_id", "reference_path", "processed_path", "configuration"}
CONFIG_KEYS = {"profile", "allow_gain", "allow_resampling", "max_delay_ms"}


def _read(path: Path):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError("Duplicate JSON object key.")
            result[key] = value
        return result
    return json.loads(path.read_text(encoding="utf-8"), object_pairs_hook=unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON.")))


def _new_json(path: Path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def _sha(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _inside(root: Path, relative: str):
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
        raise ValueError("Frozen paths must be nonempty relative paths.")
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()) or not path.is_file():
        raise ValueError("Frozen file is missing or escapes its root.")
    return path


def verify_freeze(suite_root: Path):
    root = suite_root.resolve()
    freeze = _read(root / "freeze.json")
    if not isinstance(freeze, dict) or freeze.get("final_uses") != 1 or isinstance(freeze.get("final_uses"), bool):
        raise ValueError("Evaluation freeze must allow exactly one use.")
    for key, base in (("code_sha256", WORKSPACE), ("dataset_sha256", root)):
        mapping = freeze.get(key)
        if not isinstance(mapping, dict) or not mapping:
            raise ValueError("Code/data hashes must be nonempty objects.")
        for relative, digest in mapping.items():
            if not isinstance(digest, str) or len(digest) != 64 or _sha(_inside(base, relative)) != digest:
                raise ValueError("Frozen code or data changed.")
    if not {"protocol.json", "manifest.json", "worker_jobs.json"} <= set(freeze["dataset_sha256"]):
        raise ValueError("Protocol, manifest and truth-free jobs must be frozen.")
    required_code = {p.relative_to(WORKSPACE).as_posix() for p in PACKAGE.glob("*.py")}
    required_code.add(Path(__file__).resolve().relative_to(WORKSPACE).as_posix())
    if not required_code <= {Path(name).as_posix() for name in freeze["code_sha256"]}:
        raise ValueError("Freeze does not cover the engine tree and executor.")
    return freeze


def _configuration(config):
    from audio_regression.engine import EngineConfig
    if not isinstance(config, dict) or set(config) != CONFIG_KEYS or config.get("profile") != "basic":
        raise ValueError("Only the complete basic configuration is supported.")
    EngineConfig(**config)


def validate_inputs(root: Path, freeze: dict):
    protocol = _read(root / "protocol.json")
    if protocol.get("criteria") != CRITERIA:
        raise ValueError("Criteria differ from the pre-result fixed policy.")
    manifest, jobs = _read(root / "manifest.json"), _read(root / "worker_jobs.json")
    if not isinstance(manifest, list) or len(manifest) != 84 or not isinstance(jobs, list) or len(jobs) != 84:
        raise ValueError("The corpus must contain exactly 84 paired trials.")
    seen, conditions, groups, counts = set(), set(), {}, Counter()
    for row, job in zip(manifest, jobs, strict=True):
        if not isinstance(row, dict) or not isinstance(job, dict) or set(job) != JOB_KEYS:
            raise ValueError("Worker jobs must contain paths/configuration/opaque ID only.")
        trial_id, group, category = row.get("trial_id"), row.get("source_group"), row.get("category")
        if not isinstance(trial_id, str) or not trial_id or trial_id in seen or job["trial_id"] != trial_id:
            raise ValueError("Trial IDs must be unique and identically ordered.")
        if not isinstance(group, str) or not group or category not in CATEGORIES:
            raise ValueError("Invalid original-source grouping.")
        if group in groups and groups[group] != category:
            raise ValueError("A source group cannot change category.")
        groups[group] = category
        scope, normal = row.get("scope"), row.get("normal_trial")
        if scope not in {"supported", "stress"} or type(normal) is not bool:
            raise ValueError("Invalid trial scope or normal flag.")
        if not isinstance(row.get("condition"), str) or not row["condition"]:
            raise ValueError("Condition must be declared before results.")
        if (group, row["condition"]) in conditions:
            raise ValueError("A source cannot repeat a condition.")
        conditions.add((group, row["condition"]))
        truth = row.get("expected_events")
        score_trial(truth, {"status": "withheld", "events": None})
        if (scope == "stress" and (normal or truth)) or (scope == "supported" and normal != (not truth)):
            raise ValueError("Truth and normal/stress declarations disagree.")
        if scope == "supported" and not normal and len(truth) != 1:
            raise ValueError("Each supported event case must have one truth event.")
        duration = row.get("input_duration_ms")
        if isinstance(duration, bool) or not isinstance(duration, (float, int)) or not math.isfinite(duration) or duration <= 0:
            raise ValueError("Input duration must be finite and positive.")
        _configuration(row.get("configuration"))
        if job["configuration"] != row["configuration"]:
            raise ValueError("Job configuration differs from the manifest.")
        for key in ("reference_path", "processed_path"):
            manifest_path = _inside(root, row.get(key))
            actual = Path(job[key]).resolve()
            if not Path(job[key]).is_absolute() or actual != manifest_path:
                raise ValueError("Worker input must be the exact frozen in-suite file.")
            relative = manifest_path.relative_to(root).as_posix()
            if relative not in freeze["dataset_sha256"]:
                raise ValueError("Audio input is not frozen.")
            recorded_hash = row.get(key.replace("_path", "_sha256"))
            if recorded_hash is not None and recorded_hash != freeze["dataset_sha256"][relative]:
                raise ValueError("Manifest input hash differs from freeze.")
        seen.add(trial_id)
        counts[(group, "stress" if scope == "stress" else "normal" if normal else "event")] += 1
    if len(groups) != 6 or Counter(groups.values()) != Counter({c: 2 for c in CATEGORIES}):
        raise ValueError("Exactly two original groups per category are required.")
    if any(counts[(g, kind)] != count for g in groups for kind, count in (("normal", 5), ("event", 6), ("stress", 3))):
        raise ValueError("Each source needs five normal, six event and three stress cases.")
    return protocol, manifest, jobs


def worker_run(jobs_path: Path, output_path: Path, engine: str):
    if engine not in ENGINES:
        raise ValueError("Worker engine must be v1 or v3.")
    # Imports are outside every timing interval; no audio is used for warmup.
    from audio_regression.api import analyze_pair
    from audio_regression import engine as _v1, context_engine as _v3
    from audio_regression.evaluation_worker import peak_resident_bytes
    jobs = _read(jobs_path)
    if not isinstance(jobs, list) or any(not isinstance(j, dict) or set(j) != JOB_KEYS for j in jobs):
        raise ValueError("Worker jobs contain unsupported fields, possibly truth.")
    errors = 0
    with output_path.open("x", encoding="utf-8") as stream:
        for index, job in enumerate(jobs):
            start = time.perf_counter()
            try:
                result = analyze_pair(job["reference_path"], job["processed_path"], engine=engine, **job["configuration"])
                execution_error = False
            except Exception as exc:
                errors += 1
                execution_error = True
                result = {"status": "withheld", "events": None, "reason_code": "evaluation_execution_error",
                          "exception_type": type(exc).__name__}
            runtime_ms = (time.perf_counter() - start) * 1000
            stream.write(json.dumps({"trial_id": job["trial_id"], "runtime_ms": runtime_ms,
                                     "execution_error": execution_error, "result": result}, allow_nan=False) + "\n")
            stream.flush()
            if (index + 1) % 16 == 0 or index + 1 == len(jobs):
                print(json.dumps({"engine": engine, "completed": index + 1, "total": len(jobs)}), flush=True)
    metadata = {"engine": engine, "trial_count": len(jobs), "execution_error_count": errors,
                "timing_scope": "per_trial_API_file_read_analysis_and_contract_excluding_process_startup_and_imports",
                "peak_process_resident_bytes": peak_resident_bytes(),
                "memory_scope": "whole_method_worker_including_imports_and_jobs",
                "thread_environment": {key: os.environ.get(key) for key in
                                       ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS")}}
    _new_json(output_path.with_suffix(".metadata.json"), metadata)
    return metadata


def load_outputs(output_path: Path, manifest: list[dict], engine: str):
    rows = []
    for line in output_path.read_text(encoding="utf-8").splitlines():
        item = json.loads(line)
        if not isinstance(item, dict) or set(item) != {"trial_id", "runtime_ms", "execution_error", "result"}:
            raise ValueError("Worker output has invalid fields.")
        rows.append(item)
    if len(rows) != len(manifest) or any(a["trial_id"] != b["trial_id"] for a, b in zip(rows, manifest, strict=True)):
        raise ValueError("Worker output is missing, duplicated or out of order.")
    joined = []
    for row, item in zip(manifest, rows, strict=True):
        if type(item["execution_error"]) is not bool:
            raise ValueError("Worker error flag is invalid.")
        if not item["execution_error"] and item["result"].get("engine") != "local_content_alignment_" + engine:
            raise ValueError("Worker result engine mismatch.")
        joined.append({**row, **item, "source_kind": row["category"], "profile": "basic"})
    return joined


def summarize(rows: list[dict]):
    supported = [r for r in rows if r["scope"] == "supported"]
    aggregate = aggregate_trials(supported)
    stress = [r for r in rows if r["scope"] == "stress"]
    outcome_success = sum(_supported_success(r) for r in supported)
    return {"supported": aggregate, "supported_outcome_success_count": outcome_success,
            "execution_error_count": sum(r["execution_error"] for r in rows),
            "stress": {"trial_count": len(stress), "false_clear_count": sum(
                r["result"].get("status") == "analyzed" and r["result"].get("events") == [] for r in stress),
                "withheld_count": sum(r["result"].get("status") == "withheld" for r in stress),
                "review_count": sum(r["result"].get("status") == "analyzed" and bool(r["result"].get("events")) for r in stress)},
            "by_source": {g: aggregate_trials([r for r in supported if r["source_group"] == g])["overall"]
                          for g in sorted({r["source_group"] for r in supported})}}


def _supported_success(row):
    scored = score_trial(row["expected_events"], row["result"])
    return (not scored["withheld"] and scored["false_positive_events"] == 0
            and scored["false_negative_events"] == 0 and not row["execution_error"])


def decide(candidate: dict, baseline: dict):
    checks = []
    def check(name, passed, value):
        checks.append({"criterion": name, "passed": bool(passed), "observed": value})
    check("no_execution_errors", candidate["execution_error_count"] == 0 and baseline["execution_error_count"] == 0,
          {"v3": candidate["execution_error_count"], "v1": baseline["execution_error_count"]})
    check("stress_false_clear", candidate["stress"]["trial_count"] == 18 and candidate["stress"]["false_clear_count"] == 0,
          candidate["stress"])
    for category in ("overall",) + CATEGORIES:
        c = candidate["supported"]["overall"] if category == "overall" else candidate["supported"]["by_source_kind"].get(category, {})
        b = baseline["supported"]["overall"] if category == "overall" else baseline["supported"]["by_source_kind"].get(category, {})
        for key, threshold, direction in (("normal_coverage", .90, "minimum"), ("event_precision", .90, "minimum"),
                                          ("event_recall", .90, "minimum"), ("median_primary_boundary_error_ms", 100.0, "maximum"),
                                          ("median_rtf", 1.0, "maximum")):
            value = c.get(key)
            valid = value is not None and (value >= threshold if direction == "minimum" else value <= threshold)
            check(f"{category}.{key}", valid, value)
        check(f"{category}.normal_false_alarm_count", c.get("normal_false_alarm_count") == 0, c.get("normal_false_alarm_count"))
        for key, direction in (("normal_coverage", "higher"), ("event_recall", "higher"), ("normal_false_alarm_count", "lower")):
            cv, bv = c.get(key), b.get(key)
            check(f"{category}.nonregression.{key}", cv is not None and bv is not None and (cv >= bv if direction == "higher" else cv <= bv),
                  {"v3": cv, "v1": bv})
    improvement = candidate["supported_outcome_success_count"] - baseline["supported_outcome_success_count"]
    check("supported_outcome_improvement", improvement >= 1, improvement)
    passed = all(c["passed"] for c in checks)
    return {"adopt": passed, "decision": "adopt_v3_for_basic_supported_temporal_check" if passed else "retain_v1_default",
            "criteria_checks": checks, "commercial_performance_validated": False,
            "population_accuracy_established": False, "statistically_proven_improvement": False,
            "scope": "six_new_recordings_fixed_transformations_prototype_policy_only"}


def score_saved(root: Path, manifest: list[dict]):
    rows = {engine: load_outputs(root / "outputs" / f"{engine}.jsonl", manifest, engine) for engine in ENGINES}
    summaries = {engine: summarize(items) for engine, items in rows.items()}
    supported = {engine: [r for r in items if r["scope"] == "supported"] for engine, items in rows.items()}
    bootstrap = paired_group_bootstrap(supported["v3"], supported["v1"], resamples=2000, seed=20261013)
    per_category = {c: paired_group_bootstrap([r for r in supported["v3"] if r["category"] == c],
                     [r for r in supported["v1"] if r["category"] == c], resamples=2000, seed=20261013)
                    for c in CATEGORIES}
    return {"schema_version": 1, "status": "completed", "engines": summaries,
            "decision": decide(summaries["v3"], summaries["v1"]),
            "paired_source_bootstrap": bootstrap, "paired_source_bootstrap_by_category": per_category,
            "limitations": ["Only six original recordings, with two per category.",
                            "Transformed conditions are dependent observations, not new originals.",
                            "Group-bootstrap intervals are descriptive, not population accuracy evidence.",
                            "No real user pipeline, stereo, full-band quality, long-file or streaming claim.",
                            "Engine worker order is fixed v1 then v3; filesystem caching may affect measured costs."]}


def run_suite(suite_root: Path):
    root = suite_root.resolve()
    freeze = verify_freeze(root)
    protocol, manifest, jobs = validate_inputs(root, freeze)
    freeze_digest = _sha(root / "freeze.json")
    # Never remove this claim, including when a worker or subsequent scoring fails.
    _new_json(root / "run_claim.json", {"schema_version": 1, "claimed_at_utc": datetime.now(timezone.utc).isoformat(),
              "freeze_sha256": freeze_digest, "engines": list(ENGINES), "final_uses": 1,
              "automatic_retry_allowed": False})
    try:
        outputs = root / "outputs"
        outputs.mkdir(exist_ok=False)
        env = os.environ.copy()
        env.update({key: "1" for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS")})
        env["PYTHONPATH"] = str(PACKAGE.parent)
        for engine in ENGINES:
            command = [sys.executable, str(Path(__file__).resolve()), "--worker-engine", engine,
                       "--jobs", str(root / "worker_jobs.json"), "--output", str(outputs / f"{engine}.jsonl")]
            completed = subprocess.run(command, env=env, cwd=WORKSPACE, check=False, timeout=1800)
            if completed.returncode != 0:
                raise RuntimeError("An isolated engine worker did not complete.")
        report = score_saved(root, manifest)  # Truth is joined only after all raw results are saved.
        if _sha(root / "freeze.json") != freeze_digest or verify_freeze(root) != freeze:
            raise ValueError("The freeze declaration changed during execution.")
        report["freeze_unchanged"] = True
    except Exception as exc:
        try:
            unchanged = _sha(root / "freeze.json") == freeze_digest and verify_freeze(root) == freeze
        except Exception:
            unchanged = False
        report = {"schema_version": 1, "status": "incomplete", "freeze_unchanged": unchanged,
                  "decision": {"adopt": False, "decision": "retain_v1_default"},
                  "execution_failure": {"exception_type": type(exc).__name__, "message": str(exc)},
                  "automatic_retry_allowed": False}
    _new_json(root / "report.json", report)
    _new_json(root / "run_completed.json", {"schema_version": 1, "completed_at_utc": datetime.now(timezone.utc).isoformat(),
              "status": report["status"], "report_sha256": _sha(root / "report.json"),
              "adopt": report["decision"]["adopt"], "automatic_retry_allowed": False})
    print(json.dumps({"status": report["status"], "decision": report["decision"]["decision"],
                      "report": str(root / "report.json")}, ensure_ascii=False), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite-dir", type=Path)
    parser.add_argument("--worker-engine", choices=ENGINES)
    parser.add_argument("--jobs", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.worker_engine is not None:
        if args.jobs is None or args.output is None or args.suite_dir is not None:
            parser.error("Worker mode requires jobs/output only.")
        worker_run(args.jobs, args.output, args.worker_engine)
        return 0
    if args.suite_dir is None or args.jobs is not None or args.output is not None:
        parser.error("Evaluation mode requires suite-dir only.")
    result = run_suite(args.suite_dir)
    return 0 if result["status"] == "completed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
