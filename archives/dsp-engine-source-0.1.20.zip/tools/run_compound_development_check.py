"""Save owned-only compound-transform development cases and exact proof traces.

No natural evaluation input, numeric gain argument to the detector, network,
external processor, source mutation or publication. Output must be absent.
"""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.signal import resample_poly

import audio_regression
from audio_regression.api import analyze_pair_with_trace
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.check_policy import check_result
from audio_regression.reporting import write_html_report

Q = 1 / 32768


def _pcm(values, rate):
    return decode_wav(encode_wav(values, rate)).samples


def _owned_source():
    t = np.arange(6 * 16000) / 16000
    phase = 2 * np.pi * (277 * t + 11 * t * t + .37 * np.sin(2.1 * t))
    loud = .17 * (np.sin(phase) + .19 * np.sin(1.71 * phase + .4) + .11 * np.sin(2.27 * phase - .3))
    quiet = .55 * Q * np.sin(2 * np.pi * (2900 * t + 7 * t * t))
    return _pcm(np.where(t < 4.1, loud, quiet), 16000)


def _target(values):
    gained = _pcm(values * .5011872336272722, 16000)
    converted = _pcm(resample_poly(gained, 1, 2), 8000)
    return np.concatenate((np.zeros(1920), converted))


def _new_json(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def run(output):
    if output.exists():
        raise FileExistsError("Existing output is never replaced.")
    output.mkdir(parents=False)
    values = _owned_source()
    normal = _target(values)
    erased = normal.copy()
    assert np.count_nonzero(erased[1920 + 35000:]) > 0
    erased[1920 + 35000:] = 0
    mutated = normal.copy()
    mutated[1920 + 40000] += Q
    deleted = np.concatenate((values[:2300 * 16], values[2700 * 16:]))
    repeated = np.concatenate((values[:2700 * 16], values[2300 * 16:2700 * 16], values[2700 * 16:]))
    cases = {"normal_compound": normal, "quiet_tail_erased": erased, "one_quiet_sample_changed": mutated,
             "deleted_400ms": _target(deleted), "repeated_400ms": _target(repeated)}
    rows = []
    for name, target in cases.items():
        folder = output / name
        folder.mkdir()
        a, b = folder / "reference.wav", folder / "processed.wav"
        a.write_bytes(encode_wav(values, 16000))
        b.write_bytes(encode_wav(target, 8000))
        hashes = [hashlib.sha256(p.read_bytes()).hexdigest() for p in (a, b)]
        for engine in ("v6", "v7"):
            result, trace = analyze_pair_with_trace(a, b, engine=engine, allow_gain=True, allow_resampling=True)
            _new_json(folder / (engine + ".json"), result)
            _new_json(folder / (engine + "_trace.json"), trace)
            write_html_report(result, folder / (engine + ".html"))
            expected = "analyzed" if name == "normal_compound" and engine == "v7" else "withheld"
            rows.append({"case": name, "engine": engine, "status": result["status"],
                         "reason_code": result["reason_code"], "events": result["events"],
                         "expectation_met": result["status"] == expected,
                         "check_exit_code": check_result(result)["exit_code"],
                         "new_compound_proved": trace.get("compound_proved"),
                         "exact_output_sample_count": trace.get("exact_output_sample_count"),
                         "gain_search_nodes": trace.get("gain_search_trace", {}).get("nodes_visited")})
        if hashes != [hashlib.sha256(p.read_bytes()).hexdigest() for p in (a, b)]:
            raise RuntimeError("An input changed during analysis.")
    summary = {"schema_version": 1, "package_version": audio_regression.__version__,
               "owned_development_only": True, "original_signal_formulas": 1,
               "normal_only_scope": True, "event_detection_improved": False,
               "old_saved_trials_or_sealed_inputs_read": False, "input_unchanged": True,
               "numeric_gain_passed_to_detector": False, "independent_accuracy_established": False,
               "expectations_met": sum(r["expectation_met"] for r in rows), "total": len(rows), "rows": rows}
    _new_json(output / "summary.json", summary)
    print(json.dumps({"summary": str(output / "summary.json"),
                      "expectations_met": summary["expectations_met"], "total": len(rows)}))
    return summary


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args(argv)
    result = run(args.output_dir)
    return 0 if result["expectations_met"] == result["total"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
