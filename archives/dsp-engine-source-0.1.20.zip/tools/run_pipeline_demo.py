"""Reproducible development pipelines; never independent accuracy evidence.

Stages operate on audio, not known event labels. Only this demo checks the
expected observation stage AFTER execution. It never feeds truth to a detector.
"""

import argparse
import hashlib
import json
from pathlib import Path

from audio_regression.fixtures import generate_case
from audio_regression.pipeline_runner import run_pipeline
from audio_regression.pipeline_reporting import validate_pipeline_result, write_pipeline_html


def _new_json(path: Path, value: dict):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def run(output: Path) -> dict:
    target = output.resolve()
    if target.exists():
        raise FileExistsError("Demo directory already exists.")
    target.mkdir(parents=True, exist_ok=False)
    source = target / "source.wav"
    case = generate_case("clean", seed=55247)
    with source.open("xb") as stream:
        stream.write(case.reference_wav)
    common = [
        {"kind": "resample", "label": "리샘플링", "target_rate_hz": 8000},
        {"kind": "gain", "label": "음량 변경", "gain_db": -6},
    ]
    order = list(range(15))
    plans = {
        "normal": common + [{"kind": "split_join", "label": "정상 구간 합치기", "segment_ms": 400}],
        "deleted_chunk": common + [
            {"kind": "split_join", "label": "구간 합치기", "segment_ms": 400,
             "order": [index for index in order if index != 5]},
            {"kind": "gain", "label": "후속 음량 변경", "gain_db": -3},
        ],
        "repeated_chunk": common + [
            {"kind": "split_join", "label": "구간 합치기", "segment_ms": 400,
             "order": order[:6] + [5] + order[6:]},
            {"kind": "gain", "label": "후속 음량 변경", "gain_db": -3},
        ],
        "execution_error": [
            {"kind": "gain", "label": "첫 음량 변경", "gain_db": -3},
            {"kind": "split_join", "label": "잘못된 구간 참조", "segment_ms": 400, "order": [999]},
            {"kind": "gain", "label": "실행되지 않을 단계", "gain_db": -3},
        ],
    }
    records = []
    for name, stages in plans.items():
        _new_json(target / (name + "_plan.json"), {"schema_version": 1, "stages": stages})
        result = run_pipeline(source, stages, target / name)
        validate_pipeline_result(result)
        write_pipeline_html(result, target / name / "run_report.html")
        expected = {"normal": (0, None), "deleted_chunk": (1, 3),
                    "repeated_chunk": (1, 3), "execution_error": (2, 2)}[name]
        first = result["summary"]["first_concern"]
        observed = (result["summary"]["exit_code"], None if first is None else first["stage_index"])
        if observed != expected:
            raise ValueError(f"Development pipeline observation mismatch for {name}: {observed}")
        records.append({"case": name, "status": result["status"],
                        "summary": result["summary"], "result": f"{name}/run_result.json",
                        "report": f"{name}/run_report.html"})
    if source.read_bytes() != case.reference_wav:
        raise ValueError("Source audio changed during demonstration.")
    summary = {"schema_version": 1,
               "evidence_scope": "development_usage_examples_not_independent_accuracy",
               "source_sha256": hashlib.sha256(case.reference_wav).hexdigest(),
               "original_audio_preserved": True, "commercial_performance_validated": False,
               "final_confirmation_replayed": False, "records": records}
    _new_json(target / "demo_summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False))
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    run(parser.parse_args().output_dir)
