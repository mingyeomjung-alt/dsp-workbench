"""One-use v1/v3/v4 evaluation of a fresh, hash-frozen four-source corpus.

Preparation, source selection and engine tuning are deliberately absent. Jobs
contain no truth. Every raw worker result is saved before scoring begins. This
small, transformed corpus can decide a scoped candidate, not general accuracy.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time

from audio_regression.evaluation_metrics import aggregate_trials, paired_group_bootstrap, score_trial


WORKSPACE = Path(__file__).resolve().parents[2]
PACKAGE = WORKSPACE / "dsp_engine/src/audio_regression"
ENGINES = ("v1", "v3", "v4")
CATEGORIES = ("music", "effects")
SOURCE_COUNT = 4
PAIR_COUNT = 56
BOOTSTRAP_RESAMPLES = 2000
BOOTSTRAP_SEED = 20261013
CRITERIA = {
    "normal_coverage_minimum": .90,
    "normal_false_alarm_count_maximum": 0,
    "event_precision_minimum": .90,
    "event_recall_minimum": .90,
    "median_primary_boundary_error_maximum_ms": 100.0,
    "median_rtf_maximum": 1.0,
    "stress_false_clear_count_maximum": 0,
    "minimum_supported_outcome_improvements": 1,
    "no_category_normal_coverage_decrease": True,
    "no_category_event_recall_decrease": True,
    "no_category_normal_false_alarm_increase": True,
}
JOB_KEYS = {"trial_id", "reference_path", "processed_path", "configuration"}
CONFIG_KEYS = {"profile", "allow_gain", "allow_resampling", "max_delay_ms"}
NORMAL_CONDITIONS = {"normal_identity", "normal_gain", "normal_resample", "normal_delay", "normal_combined"}
EVENT_CONDITIONS = {f"{kind}_{duration}" for kind in ("delete", "repeat") for duration in (200, 400, 750)}
STRESS_CONDITIONS = {"stress_silent", "stress_dropout", "stress_reversal"}
CONDITIONS = NORMAL_CONDITIONS | EVENT_CONDITIONS | STRESS_CONDITIONS


def _loads(value: str):
    def unique(pairs):
        result = {}
        for key, item in pairs:
            if key in result:
                raise ValueError("Duplicate JSON object key.")
            result[key] = item
        return result
    return json.loads(value, object_pairs_hook=unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON.")))


def _read(path: Path):
    return _loads(path.read_text(encoding="utf-8"))


def _new_json(path: Path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def _sha(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _inside(root: Path, relative: str):
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
        raise ValueError("Frozen paths must be nonempty relative paths.")
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()) or not path.is_file():
        raise ValueError("Frozen file is missing or escapes its root.")
    return path


def verify_freeze(suite_root: Path):
    root = suite_root.resolve()
    freeze = _read(root / "freeze.json")
    if not isinstance(freeze, dict) or type(freeze.get("final_uses")) is not int or freeze["final_uses"] != 1:
        raise ValueError("Evaluation freeze must allow exactly one use.")
    for key, base in (("code_sha256", WORKSPACE), ("dataset_sha256", root)):
        mapping = freeze.get(key)
        if not isinstance(mapping, dict) or not mapping:
            raise ValueError("Code/data hashes must be nonempty objects.")
        for relative, digest in mapping.items():
            if not isinstance(digest, str) or re.fullmatch(r"[0-9a-f]{64}", digest) is None or _sha(_inside(base, relative)) != digest:
                raise ValueError("Frozen code or data changed.")
    if not {"protocol.json", "manifest.json", "worker_jobs.json"} <= set(freeze["dataset_sha256"]):
        raise ValueError("Protocol, manifest and truth-free jobs must be frozen.")
    required = {p.relative_to(WORKSPACE).as_posix() for p in PACKAGE.rglob("*.py")}
    required.update(p.relative_to(WORKSPACE).as_posix() for p in (PACKAGE / "schemas").glob("*.json"))
    required.add(Path(__file__).resolve().relative_to(WORKSPACE).as_posix())
    if not required <= {Path(name).as_posix() for name in freeze["code_sha256"]}:
        raise ValueError("Freeze does not cover the engine tree, schemas and executor.")
    return freeze


def _configuration(config):
    from audio_regression.engine import EngineConfig
    if not isinstance(config, dict) or set(config) != CONFIG_KEYS or config.get("profile") != "basic":
        raise ValueError("Only the complete basic configuration is supported.")
    EngineConfig(**config)


def _protocol(protocol):
    if not isinstance(protocol, dict):
        raise ValueError("Protocol must be an object.")
    # Canonical JSON distinguishes bool/int and otherwise equal Python values.
    if json.dumps(protocol.get("criteria"), sort_keys=True) != json.dumps(CRITERIA, sort_keys=True):
        raise ValueError("Criteria differ from the pre-result fixed policy.")
    expected = {"methods": list(ENGINES), "categories": list(CATEGORIES), "source_count": SOURCE_COUNT,
                "pair_count": PAIR_COUNT, "source_count_by_category": {c: 2 for c in CATEGORIES},
                "profile": "basic", "bootstrap_resamples": BOOTSTRAP_RESAMPLES,
                "bootstrap_seed": BOOTSTRAP_SEED, "final_uses": 1, "retune_after_results": False}
    for key, value in expected.items():
        if json.dumps(protocol.get(key), sort_keys=True) != json.dumps(value, sort_keys=True):
            raise ValueError("Protocol scope, method order or one-use policy changed.")
    sources = protocol.get("sources")
    if not isinstance(sources, list) or len(sources) != SOURCE_COUNT or any(not isinstance(s, dict) for s in sources):
        raise ValueError("Four original sources must be declared before execution.")
    declared = {(s.get("source_group"), s.get("category")) for s in sources
                if isinstance(s.get("source_group"), str) and s["source_group"] and s.get("category") in CATEGORIES}
    if len(declared) != SOURCE_COUNT or len({g for g, _ in declared}) != SOURCE_COUNT:
        raise ValueError("Source declarations must have unique valid groups/categories.")
    return declared


def validate_inputs(root: Path, freeze: dict):
    protocol = _read(root / "protocol.json")
    declared = _protocol(protocol)
    manifest, jobs = _read(root / "manifest.json"), _read(root / "worker_jobs.json")
    if not isinstance(manifest, list) or len(manifest) != PAIR_COUNT or not isinstance(jobs, list) or len(jobs) != PAIR_COUNT:
        raise ValueError("The corpus must contain exactly 56 paired trials.")
    seen, conditions, groups, counts = set(), set(), {}, Counter()
    for row, job in zip(manifest, jobs, strict=True):
        if not isinstance(row, dict) or not isinstance(job, dict) or set(job) != JOB_KEYS:
            raise ValueError("Worker jobs must contain paths/configuration/opaque ID only.")
        trial_id, group, category = row.get("trial_id"), row.get("source_group"), row.get("category")
        if not isinstance(trial_id, str) or not trial_id or trial_id in seen or job["trial_id"] != trial_id:
            raise ValueError("Trial IDs must be unique and identically ordered.")
        if not isinstance(group, str) or not group or category not in CATEGORIES:
            raise ValueError("Invalid original-source grouping.")
        if group in groups and groups[group] != category:
            raise ValueError("A source group cannot change category.")
        groups[group] = category
        scope, normal, condition = row.get("scope"), row.get("normal_trial"), row.get("condition")
        if scope not in {"supported", "stress"} or type(normal) is not bool or condition not in CONDITIONS:
            raise ValueError("Invalid fixed condition, trial scope or normal flag.")
        if (group, condition) in conditions:
            raise ValueError("A source cannot repeat a condition.")
        conditions.add((group, condition))
        if normal != (condition in NORMAL_CONDITIONS) or (scope == "stress") != (condition in STRESS_CONDITIONS):
            raise ValueError("Fixed condition disagrees with normal/stress declarations.")
        truth = row.get("expected_events")
        score_trial(truth, {"status": "withheld", "events": None})
        if (scope == "stress" and (normal or truth)) or (scope == "supported" and normal != (not truth)):
            raise ValueError("Truth and normal/stress declarations disagree.")
        if scope == "supported" and not normal:
            if len(truth) != 1 or truth[0]["type"] != condition.split("_")[0]:
                raise ValueError("Each supported event case needs one matching truth event.")
        duration = row.get("input_duration_ms")
        if isinstance(duration, bool) or not isinstance(duration, (float, int)) or not math.isfinite(duration) or duration <= 0:
            raise ValueError("Input duration must be finite and positive.")
        _configuration(row.get("configuration"))
        if job["configuration"] != row["configuration"]:
            raise ValueError("Job configuration differs from the manifest.")
        for key in ("reference_path", "processed_path"):
            manifest_path = _inside(root, row.get(key))
            if not isinstance(job[key], str) or not Path(job[key]).is_absolute() or Path(job[key]).resolve() != manifest_path:
                raise ValueError("Worker input must be the exact frozen in-suite file.")
            relative = manifest_path.relative_to(root).as_posix()
            if relative not in freeze["dataset_sha256"]:
                raise ValueError("Audio input is not frozen.")
            if row.get(key.replace("_path", "_sha256")) != freeze["dataset_sha256"][relative]:
                raise ValueError("Manifest input hash differs from freeze.")
        seen.add(trial_id)
        counts[(group, "stress" if scope == "stress" else "normal" if normal else "event")] += 1
    if set(groups.items()) != declared or Counter(groups.values()) != Counter({c: 2 for c in CATEGORIES}):
        raise ValueError("Exactly two declared original groups per category are required.")
    if any(counts[(g, kind)] != count for g in groups for kind, count in (("normal", 5), ("event", 6), ("stress", 3))):
        raise ValueError("Each source needs five normal, six event and three stress cases.")
    return protocol, manifest, jobs


def _exception(exc: Exception):
    # Do not persist arbitrary exception messages or file paths as reason codes.
    reason = getattr(exc, "code", None)
    if not isinstance(reason, str) or re.fullmatch(r"[a-z][a-z0-9_]{0,127}", reason) is None:
        reason = None
    return {"exception_type": type(exc).__name__, "exception_reason_code": reason}


def worker_run(jobs_path: Path, output_path: Path, engine: str):
    if engine not in ENGINES:
        raise ValueError("Worker engine must be v1, v3 or v4.")
    from audio_regression.api import analyze_pair
    from audio_regression import engine as _v1, context_engine as _v3, instrument_engine as _v4
    from audio_regression.evaluation_worker import peak_resident_bytes
    jobs = _read(jobs_path)
    if not isinstance(jobs, list) or len(jobs) != PAIR_COUNT or any(not isinstance(j, dict) or set(j) != JOB_KEYS for j in jobs):
        raise ValueError("Worker jobs contain unsupported fields or trial count, possibly truth.")
    if len({j.get("trial_id") for j in jobs}) != len(jobs) or any(not isinstance(j.get("trial_id"), str) or not j["trial_id"] for j in jobs):
        raise ValueError("Worker IDs must be unique nonempty strings.")
    for job in jobs:
        _configuration(job["configuration"])
        if any(not isinstance(job[k], str) or not Path(job[k]).is_absolute() for k in ("reference_path", "processed_path")):
            raise ValueError("Worker paths must be absolute strings.")
    errors = 0
    with output_path.open("x", encoding="utf-8") as stream:
        for index, job in enumerate(jobs):
            start = time.perf_counter()
            try:
                result = analyze_pair(job["reference_path"], job["processed_path"], engine=engine, **job["configuration"])
                execution_error = False
            except Exception as exc:
                errors += 1
                execution_error = True
                result = {"status": "withheld", "events": None, "reason_code": "evaluation_execution_error", **_exception(exc)}
            runtime_ms = (time.perf_counter() - start) * 1000
            stream.write(json.dumps({"trial_id": job["trial_id"], "runtime_ms": runtime_ms,
                                     "execution_error": execution_error, "result": result}, allow_nan=False) + "\n")
            stream.flush()
            if (index + 1) % 16 == 0 or index + 1 == len(jobs):
                print(json.dumps({"engine": engine, "completed": index + 1, "total": len(jobs)}), flush=True)
    metadata = {"engine": engine, "trial_count": len(jobs), "execution_error_count": errors,
                "timing_scope": "per_trial_API_file_read_analysis_and_contract_excluding_process_startup_and_imports",
                "peak_process_resident_bytes": peak_resident_bytes(),
                "memory_scope": "whole_method_worker_including_imports_and_jobs",
                "thread_environment": {key: os.environ.get(key) for key in
                                       ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS")}}
    _new_json(output_path.with_suffix(".metadata.json"), metadata)
    return metadata


def load_outputs(output_path: Path, manifest: list[dict], engine: str):
    rows = []
    for line in output_path.read_text(encoding="utf-8").splitlines():
        item = _loads(line)
        if not isinstance(item, dict) or set(item) != {"trial_id", "runtime_ms", "execution_error", "result"}:
            raise ValueError("Worker output has invalid fields.")
        rows.append(item)
    if len(rows) != len(manifest) or any(a["trial_id"] != b["trial_id"] for a, b in zip(rows, manifest, strict=True)):
        raise ValueError("Worker output is missing, duplicated or out of order.")
    joined = []
    for row, item in zip(manifest, rows, strict=True):
        runtime = item["runtime_ms"]
        if isinstance(runtime, bool) or not isinstance(runtime, (int, float)) or not math.isfinite(runtime) or runtime < 0:
            raise ValueError("Worker runtime must be finite and nonnegative.")
        if type(item["execution_error"]) is not bool or not isinstance(item["result"], dict):
            raise ValueError("Worker error flag or result is invalid.")
        if not item["execution_error"] and item["result"].get("engine") != "local_content_alignment_" + engine:
            raise ValueError("Worker result engine mismatch.")
        if item["execution_error"] and (item["result"].get("status") != "withheld" or item["result"].get("events") is not None):
            raise ValueError("Execution errors must remain withheld.")
        joined.append({**row, **item, "source_kind": row["category"], "profile": "basic"})
    return joined


def _supported_success(row):
    scored = score_trial(row["expected_events"], row["result"])
    return (not scored["withheld"] and scored["false_positive_events"] == 0
            and scored["false_negative_events"] == 0 and not row["execution_error"])


def summarize(rows: list[dict]):
    supported = [r for r in rows if r["scope"] == "supported"]
    stress = [r for r in rows if r["scope"] == "stress"]
    return {"supported": aggregate_trials(supported),
            "supported_outcome_success_count": sum(_supported_success(r) for r in supported),
            "execution_error_count": sum(r["execution_error"] for r in rows),
            "stress": {"trial_count": len(stress), "false_clear_count": sum(
                r["result"].get("status") == "analyzed" and r["result"].get("events") == [] for r in stress),
                "withheld_count": sum(r["result"].get("status") == "withheld" for r in stress),
                "review_count": sum(r["result"].get("status") == "analyzed" and bool(r["result"].get("events")) for r in stress)},
            "by_source": {g: aggregate_trials([r for r in supported if r["source_group"] == g])["overall"]
                          for g in sorted({r["source_group"] for r in supported})}}


def decide(candidate: dict, baseline: dict, secondary: dict):
    checks = []
    def check(name, passed, value):
        checks.append({"criterion": name, "passed": bool(passed), "observed": value})
    check("no_execution_errors", all(s["execution_error_count"] == 0 for s in (candidate, baseline, secondary)),
          {e: s["execution_error_count"] for e, s in zip(ENGINES, (baseline, secondary, candidate), strict=True)})
    check("stress_false_clear", candidate["stress"]["trial_count"] == SOURCE_COUNT * 3 and candidate["stress"]["false_clear_count"] == 0,
          candidate["stress"])
    for category in ("overall",) + CATEGORIES:
        def stratum(summary):
            return summary["supported"]["overall"] if category == "overall" else summary["supported"]["by_source_kind"].get(category, {})
        c = stratum(candidate)
        for key, policy_key, direction in (
            ("normal_coverage", "normal_coverage_minimum", "minimum"),
            ("event_precision", "event_precision_minimum", "minimum"),
            ("event_recall", "event_recall_minimum", "minimum"),
            ("median_primary_boundary_error_ms", "median_primary_boundary_error_maximum_ms", "maximum"),
            ("median_rtf", "median_rtf_maximum", "maximum"),
        ):
            value, threshold = c.get(key), CRITERIA[policy_key]
            valid = value is not None and (value >= threshold if direction == "minimum" else value <= threshold)
            check(f"{category}.{key}", valid, value)
        check(f"{category}.normal_false_alarm_count", c.get("normal_false_alarm_count") == 0, c.get("normal_false_alarm_count"))
        for comparison_engine, comparison in (("v1", baseline), ("v3", secondary)):
            b = stratum(comparison)
            for key, direction in (("normal_coverage", "higher"), ("event_recall", "higher"), ("normal_false_alarm_count", "lower")):
                cv, bv = c.get(key), b.get(key)
                check(f"{category}.nonregression_vs_{comparison_engine}.{key}",
                      cv is not None and bv is not None and (cv >= bv if direction == "higher" else cv <= bv),
                      {"v4": cv, comparison_engine: bv})
    improvement = candidate["supported_outcome_success_count"] - baseline["supported_outcome_success_count"]
    check("supported_outcome_improvement_vs_v1", improvement >= CRITERIA["minimum_supported_outcome_improvements"], improvement)
    passed = all(c["passed"] for c in checks)
    return {"adopt": passed,
            "decision": "adopt_v4_candidate_for_scoped_offline_use_only" if passed else "keep_v1_default",
            "criteria_checks": checks, "commercial_performance_validated": False,
            "population_accuracy_established": False, "statistically_proven_improvement": False,
            "scope": "four_new_instrument_music_recordings_fixed_transformations_offline_policy_only"}


def _bootstrap(candidate, baseline):
    return {"overall": paired_group_bootstrap(candidate, baseline, resamples=BOOTSTRAP_RESAMPLES, seed=BOOTSTRAP_SEED),
            "by_category": {c: paired_group_bootstrap([r for r in candidate if r["category"] == c],
                                  [r for r in baseline if r["category"] == c],
                                  resamples=BOOTSTRAP_RESAMPLES, seed=BOOTSTRAP_SEED) for c in CATEGORIES}}


def score_saved(root: Path, manifest: list[dict]):
    rows = {engine: load_outputs(root / "outputs" / f"{engine}.jsonl", manifest, engine) for engine in ENGINES}
    summaries = {engine: summarize(items) for engine, items in rows.items()}
    supported = {engine: [r for r in items if r["scope"] == "supported"] for engine, items in rows.items()}
    v1_bootstrap, v3_bootstrap = _bootstrap(supported["v4"], supported["v1"]), _bootstrap(supported["v4"], supported["v3"])
    secondary = {"candidate": "v4", "baseline": "v3",
                 "supported_outcome_success_difference": summaries["v4"]["supported_outcome_success_count"] - summaries["v3"]["supported_outcome_success_count"],
                 "improved_trial_ids": [c["trial_id"] for c, b in zip(supported["v4"], supported["v3"], strict=True)
                                        if _supported_success(c) and not _supported_success(b)],
                 "regressed_trial_ids": [c["trial_id"] for c, b in zip(supported["v4"], supported["v3"], strict=True)
                                         if not _supported_success(c) and _supported_success(b)],
                 "paired_source_bootstrap": v3_bootstrap["overall"],
                 "paired_source_bootstrap_by_category": v3_bootstrap["by_category"]}
    return {"schema_version": 1, "status": "completed", "engines": summaries,
            "decision": decide(summaries["v4"], summaries["v1"], summaries["v3"]),
            "paired_source_bootstrap": v1_bootstrap["overall"],
            "paired_source_bootstrap_by_category": v1_bootstrap["by_category"],
            "secondary_comparison_v4_vs_v3": secondary,
            "limitations": ["Only four original recordings, with two per category.",
                            "Effects here are instrument/percussion recordings, not general environmental audio.",
                            "Transformed conditions are dependent observations, not new originals.",
                            "Group-bootstrap intervals are descriptive, not population accuracy evidence.",
                            "No speech, real user pipeline, stereo, full-band quality, long-file or streaming claim.",
                            "Engine worker order is fixed v1 then v3 then v4; filesystem caching may affect measured costs."]}


def run_suite(suite_root: Path):
    root = suite_root.resolve()
    freeze = verify_freeze(root)
    protocol, manifest, jobs = validate_inputs(root, freeze)
    freeze_digest = _sha(root / "freeze.json")
    _new_json(root / "run_claim.json", {"schema_version": 1, "claimed_at_utc": datetime.now(timezone.utc).isoformat(),
              "freeze_sha256": freeze_digest, "engines": list(ENGINES), "final_uses": 1,
              "automatic_retry_allowed": False})
    try:
        outputs = root / "outputs"
        outputs.mkdir(exist_ok=False)
        env = os.environ.copy()
        env.update({key: "1" for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS")})
        env["PYTHONPATH"] = str(PACKAGE.parent)
        for engine in ENGINES:
            command = [sys.executable, str(Path(__file__).resolve()), "--worker-engine", engine,
                       "--jobs", str(root / "worker_jobs.json"), "--output", str(outputs / f"{engine}.jsonl")]
            completed = subprocess.run(command, env=env, cwd=WORKSPACE, check=False, timeout=1800)
            if completed.returncode != 0:
                raise RuntimeError("An isolated engine worker did not complete.")
        report = score_saved(root, manifest)
        if _sha(root / "freeze.json") != freeze_digest or verify_freeze(root) != freeze:
            raise ValueError("The freeze declaration changed during execution.")
        report["freeze_unchanged"] = True
    except Exception as exc:
        try:
            unchanged = _sha(root / "freeze.json") == freeze_digest and verify_freeze(root) == freeze
        except Exception:
            unchanged = False
        report = {"schema_version": 1, "status": "incomplete", "freeze_unchanged": unchanged,
                  "decision": {"adopt": False, "decision": "keep_v1_default"},
                  "execution_failure": _exception(exc), "automatic_retry_allowed": False}
    _new_json(root / "report.json", report)
    _new_json(root / "run_completed.json", {"schema_version": 1, "completed_at_utc": datetime.now(timezone.utc).isoformat(),
              "status": report["status"], "report_sha256": _sha(root / "report.json"),
              "adopt": report["decision"]["adopt"], "automatic_retry_allowed": False})
    print(json.dumps({"status": report["status"], "decision": report["decision"]["decision"],
                      "report": str(root / "report.json")}, ensure_ascii=False), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite-dir", type=Path)
    parser.add_argument("--worker-engine", choices=ENGINES)
    parser.add_argument("--jobs", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.worker_engine is not None:
        if args.jobs is None or args.output is None or args.suite_dir is not None:
            parser.error("Worker mode requires jobs/output only.")
        worker_run(args.jobs, args.output, args.worker_engine)
        return 0
    if args.suite_dir is None or args.jobs is not None or args.output is not None:
        parser.error("Evaluation mode requires suite-dir only.")
    result = run_suite(args.suite_dir)
    return 0 if result["status"] == "completed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
