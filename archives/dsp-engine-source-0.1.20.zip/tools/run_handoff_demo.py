"""Create development-only examples of the local library, report and safe gate.

No final-confirmation files, personal audio or external services are used.
Existing output directories are never replaced; partial failures remain visible.
"""

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np

from audio_regression.api import analyze_pair
from audio_regression.audio import encode_wav
from audio_regression.check_policy import check_result
from audio_regression.fixtures import generate_case
from audio_regression.profiles import telephone_transform_samples
from audio_regression.audio import decode_wav
from audio_regression.reporting import write_html_report


def _json(path: Path, value: dict):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def run(output: Path):
    target = output.resolve()
    if target.exists():
        raise FileExistsError("Demo destination already exists.")
    target.mkdir(parents=True, exist_ok=False)
    records = []
    for label in ("clean", "delete", "repeat", "withheld_silence", "telephone_clean"):
        directory = target / label
        directory.mkdir()
        case = generate_case(label if label in {"clean", "delete", "repeat"} else "clean", seed=48147)
        ref_bytes, proc_bytes = case.reference_wav, case.processed_wav
        configuration = {"profile": "basic"}
        if label == "withheld_silence":
            ref_bytes = proc_bytes = encode_wav(np.zeros(96000), 16000)
        elif label == "telephone_clean":
            ref_audio = decode_wav(ref_bytes)
            proc_bytes = encode_wav(telephone_transform_samples(ref_audio), 8000)
            configuration = {"profile": "telephone", "allow_resampling": True}
        reference, processed = directory / "reference.wav", directory / "processed.wav"
        for path, payload in ((reference, ref_bytes), (processed, proc_bytes)):
            with path.open("xb") as stream:
                stream.write(payload)
        result = analyze_pair(reference, processed, **configuration)
        gate = check_result(result)
        _json(directory / "result.json", result)
        _json(directory / "check.json", gate)
        write_html_report(result, directory / "report.html")
        if reference.read_bytes() != ref_bytes or processed.read_bytes() != proc_bytes:
            raise ValueError("A demo input was modified.")
        records.append({"case": label, "status": result["status"],
                        "gate_state": gate["gate_state"], "exit_code": gate["exit_code"],
                        "result": f"{label}/result.json", "report": f"{label}/report.html",
                        "reference_sha256": hashlib.sha256(ref_bytes).hexdigest(),
                        "processed_sha256": hashlib.sha256(proc_bytes).hexdigest()})
    summary = {"schema_version": 1, "evidence_scope": "development_usage_examples_not_independent_accuracy",
               "external_api_used": False, "personal_audio_used": False,
               "commercial_performance_validated": False, "records": records}
    _json(target / "summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False))
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    run(parser.parse_args().output_dir)
