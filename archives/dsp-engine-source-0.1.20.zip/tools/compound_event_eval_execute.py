"""One-use, truth-blind v1/v7/v8 evaluation of four newly locked music sources.

This executor never selects sources, prepares audio, tunes models or changes the
default engine. Every raw method worker is retained before any truth is scored.
The small transformed corpus supports only its predeclared offline decision.
"""

from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import unicodedata
from urllib.parse import unquote

from audio_regression.evaluation_metrics import aggregate_trials, paired_group_bootstrap, score_trial
from audio_regression.result_contract import validate_analysis_result


WORKSPACE = Path(__file__).resolve().parents[2]
PACKAGE = WORKSPACE / "dsp_engine/src/audio_regression"
ENGINES = ("v1", "v7", "v8")
CATEGORIES = ("music",)
SOURCE_COUNT = 4
SOURCE_COUNT_BY_CATEGORY = {"music": 4}
PAIR_COUNT = 56
BOOTSTRAP_RESAMPLES = 2000
BOOTSTRAP_SEED = 20261014
WORKER_TIMEOUT_SECONDS = 1800
CRITERIA = {
    "normal_coverage_minimum": .90,
    "normal_false_alarm_count_maximum": 0,
    "event_precision_minimum": .90,
    "event_recall_minimum": .90,
    "delete_event_precision_minimum": .90,
    "delete_event_recall_minimum": .90,
    "repeat_event_precision_minimum": .90,
    "repeat_event_recall_minimum": .90,
    "median_primary_boundary_error_maximum_ms": 100.0,
    "median_rtf_maximum": 1.0,
    "stress_false_clear_count_maximum": 0,
    "minimum_supported_outcome_improvements": 1,
    "no_category_normal_coverage_decrease": True,
    "no_category_event_recall_decrease": True,
    "no_category_normal_false_alarm_increase": True,
}
JOB_KEYS = {"trial_id", "reference_path", "processed_path", "configuration"}
CONFIG_KEYS = {"profile", "allow_gain", "allow_resampling", "max_delay_ms"}
NORMAL_CONDITIONS = {"normal_identity", "normal_gain", "normal_resample", "normal_delay", "normal_combined"}
EVENT_CONDITIONS = {f"{kind}_{duration}" for kind in ("delete", "repeat") for duration in (200, 400, 750)}
STRESS_CONDITIONS = {"stress_silent", "stress_dropout", "stress_reversal"}
CONDITIONS = NORMAL_CONDITIONS | EVENT_CONDITIONS | STRESS_CONDITIONS
REQUIRED_DATA = {"protocol.json", "manifest.json", "worker_jobs.json", "runtime.json",
                 "source_selection_before_download.json", "used_sources_before_selection.json"}
REQUIRED_HELPERS = ("dsp_engine/tools/prepare_compound_event_eval.py",
                    "dsp_engine/tools/prepare_independent_dsp_eval.py",
                    "dsp_engine/tools/run_public_saved_check.py", "dsp_engine/pyproject.toml",
                    "docs/dsp_compound_event_adoption_protocol.md")
TRACE_METHODS = {"v7": "interval_gain_quantized_compound_normal_proof",
                 "v8": "exact_quantized_compound_event_forward_proof"}


def _loads(value: str):
    def unique(pairs):
        result = {}
        for key, item in pairs:
            if key in result:
                raise ValueError("Duplicate JSON object key.")
            result[key] = item
        return result
    return json.loads(value, object_pairs_hook=unique,
                      parse_constant=lambda _: (_ for _ in ()).throw(ValueError("Nonfinite JSON.")))


def _read(path: Path):
    return _loads(path.read_text(encoding="utf-8"))


def _new_json(path: Path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def _sha(path: Path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _digest(value):
    return isinstance(value, str) and re.fullmatch(r"[0-9a-f]{64}", value) is not None


def _inside(root: Path, relative: str):
    if not isinstance(relative, str) or not relative or Path(relative).is_absolute():
        raise ValueError("Frozen paths must be nonempty relative paths.")
    path = (root / relative).resolve()
    if not path.is_relative_to(root.resolve()) or not path.is_file():
        raise ValueError("Frozen file is missing or escapes its root.")
    return path


def _canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, allow_nan=False)


def normalize_identity(value):
    """Conservative Commons filename/URL spelling equivalence, not audio identity."""
    if not isinstance(value, str) or not value.strip():
        raise ValueError("Source identities must be nonempty strings.")
    decoded = unicodedata.normalize("NFKC", unquote(value)).strip().casefold()
    decoded = decoded.split("?", 1)[0].split("#", 1)[0].replace("\\", "/").rsplit("/", 1)[-1]
    if decoded.startswith("file:"):
        decoded = decoded[5:]
    suffixes = (".ogg", ".wav", ".mp3", ".flac", ".m4a", ".opus", ".hq")
    while any(decoded.endswith(suffix) for suffix in suffixes):
        suffix = next(s for s in suffixes if decoded.endswith(s))
        decoded = decoded[:-len(suffix)]
    return " ".join(decoded.replace("_", " ").split())


_identity = normalize_identity


def verify_freeze(suite_root: Path):
    root = suite_root.resolve()
    freeze = _read(root / "freeze.json")
    if not isinstance(freeze, dict) or type(freeze.get("final_uses")) is not int or freeze["final_uses"] != 1:
        raise ValueError("Evaluation freeze must allow exactly one use.")
    for key, base in (("code_sha256", WORKSPACE), ("dataset_sha256", root)):
        mapping = freeze.get(key)
        if not isinstance(mapping, dict) or not mapping:
            raise ValueError("Code/data hashes must be nonempty objects.")
        for relative, digest in mapping.items():
            if not _digest(digest) or _sha(_inside(base, relative)) != digest:
                raise ValueError("Frozen code or data changed.")
    if not REQUIRED_DATA <= set(freeze["dataset_sha256"]):
        raise ValueError("Protocol, manifest, jobs, runtime, selection and prior-source exclusions must be frozen.")
    required = {p.relative_to(WORKSPACE).as_posix() for p in PACKAGE.rglob("*.py")}
    required.update(p.relative_to(WORKSPACE).as_posix() for p in (PACKAGE / "schemas").glob("*.json"))
    required.add(Path(__file__).resolve().relative_to(WORKSPACE).as_posix())
    required.update(REQUIRED_HELPERS)
    if not required <= {Path(name).as_posix() for name in freeze["code_sha256"]}:
        raise ValueError("Freeze does not cover all inherited engines, schemas, executor and preparation helpers.")
    return freeze


def _configuration(config):
    from audio_regression.engine import EngineConfig
    if not isinstance(config, dict) or set(config) != CONFIG_KEYS or config.get("profile") != "basic":
        raise ValueError("Only the complete basic configuration is supported.")
    EngineConfig(**config)


def _protocol(protocol):
    if not isinstance(protocol, dict):
        raise ValueError("Protocol must be an object.")
    if _canonical(protocol.get("criteria")) != _canonical(CRITERIA):
        raise ValueError("Criteria differ from the pre-result fixed policy.")
    expected = {"methods": list(ENGINES), "categories": list(CATEGORIES), "source_count": SOURCE_COUNT,
                "pair_count": PAIR_COUNT, "source_count_by_category": SOURCE_COUNT_BY_CATEGORY,
                "profile": "basic", "bootstrap_resamples": BOOTSTRAP_RESAMPLES,
                "bootstrap_seed": BOOTSTRAP_SEED, "final_uses": 1, "retune_after_results": False,
                "post_result_case_exclusion_allowed": False, "first_excerpt_fixed": True}
    for key, value in expected.items():
        if _canonical(protocol.get(key)) != _canonical(value):
            raise ValueError("Protocol scope, method order or one-use policy changed.")
    sources = protocol.get("sources")
    if not isinstance(sources, list) or len(sources) != SOURCE_COUNT or any(not isinstance(s, dict) for s in sources):
        raise ValueError("Four original sources must be declared before execution.")
    declared = {(s.get("source_group"), s.get("category")) for s in sources
                if isinstance(s.get("source_group"), str) and s["source_group"] and s.get("category") in CATEGORIES}
    if len(declared) != SOURCE_COUNT or len({g for g, _ in declared}) != SOURCE_COUNT:
        raise ValueError("Source declarations must have unique valid groups/categories.")
    return declared


def _sources(root, protocol, freeze):
    excluded = _read(root / "used_sources_before_selection.json")
    selection = _read(root / "source_selection_before_download.json")
    if not isinstance(excluded, dict) or not isinstance(selection, dict):
        raise ValueError("Selection and exclusions must be prelocked metadata objects.")
    identifiers, hashes = excluded.get("prior_recording_ids"), excluded.get("prior_audio_sha256")
    prior_aliases = excluded.get("prior_identity_aliases")
    if (not isinstance(identifiers, list) or not isinstance(hashes, list)
            or not isinstance(prior_aliases, list)
            or any(not isinstance(i, str) or not i for i in identifiers + prior_aliases) or any(not _digest(h) for h in hashes)):
        raise ValueError("Prior source identifiers and hashes must be explicit valid lists.")
    selected = selection.get("sources")
    if not isinstance(selected, list) or len(selected) != SOURCE_COUNT or any(not isinstance(s, dict) for s in selected):
        raise ValueError("Four sources must have been locked before download.")
    locked = {(s.get("group"), _identity(s.get("id"))) for s in selected}
    locked_aliases = {s.get("group"): {_identity(s[k]) for k in ("id", "title", "audio_url", "license_url")
                                           if isinstance(s.get(k), str) and s[k]} for s in selected}
    if len(locked) != SOURCE_COUNT or selection.get("source_reselection_allowed") is not False:
        raise ValueError("Source selection is not a unique no-substitution lock.")
    used_ids = {_identity(value) for value in identifiers + prior_aliases}
    used_hashes = set(hashes)
    sources, ids, originals, prepared = {}, set(), set(), set()
    for source in protocol["sources"]:
        group, identifier = source["source_group"], _identity(source.get("recording_id"))
        declared_aliases = source.get("identity_aliases")
        if (not isinstance(declared_aliases, list) or not declared_aliases
                or any(not isinstance(a, str) or not a for a in declared_aliases)):
            raise ValueError("Each source must retain its prelocked normalized identity aliases.")
        aliases = {_identity(a) for a in declared_aliases}
        if aliases != locked_aliases.get(group) or identifier not in aliases:
            raise ValueError("Source aliases differ from the pre-download identities.")
        original_hash = source.get("original_sha256")
        metadata = source.get("preparation", {}).get("prepared", {})
        if not isinstance(metadata, dict):
            raise ValueError("Prepared source metadata is required.")
        reference_hash = metadata.get("sha256")
        original = _inside(root, source.get("original_path"))
        original_relative = original.relative_to(root).as_posix()
        if (not _digest(original_hash) or not _digest(reference_hash)
                or freeze["dataset_sha256"].get(original_relative) != original_hash):
            raise ValueError("Original source path/hash must match the frozen original.")
        if (aliases & used_ids or original_hash in used_hashes or reference_hash in used_hashes
                or aliases & ids or original_hash in originals or reference_hash in prepared):
            raise ValueError("Used or duplicate source identity/original/prepared hash is forbidden.")
        if (group, identifier) not in locked or source.get("prior_identifier_or_original_or_prepared_hash_overlap") is not False:
            raise ValueError("Protocol source identity differs from the pre-download lock or exclusion check.")
        samples = metadata.get("sample_count")
        if (type(samples) is not int or samples != 192000
                or metadata.get("sample_rate_hz") != 16000 or metadata.get("channels") != 1
                or metadata.get("encoding") != "pcm16"
                or _canonical(metadata.get("duration_ms")) != _canonical(samples / 16)):
            raise ValueError("Reference must be the fixed 12 second mono PCM16 16k first excerpt.")
        if (source.get("preparation", {}).get("excerpt_start_ms") != 0
                or source.get("preparation", {}).get("excerpt_end_ms") != 12000):
            raise ValueError("First excerpt cannot be reselected.")
        sources[group] = {"reference_sha256": reference_hash, "samples": samples, "duration_ms": samples / 16}
        ids.update(aliases)
        originals.add(original_hash)
        prepared.add(reference_hash)
    return sources


def _geometry(row, source):
    condition = row["condition"]
    samples, duration = source["samples"], source["duration_ms"]
    begin = round(samples * .35)
    delay_ms = 240.0
    gain = condition in {"normal_gain", "normal_combined"} or condition in EVENT_CONDITIONS
    resampling = condition in {"normal_resample", "normal_combined"} or condition in EVENT_CONDITIONS
    required_configuration = {"profile": "basic", "allow_gain": gain, "allow_resampling": resampling, "max_delay_ms": 1000.0}
    if _canonical(row["configuration"]) != _canonical(required_configuration):
        raise ValueError("Condition-specific declarations differ from the locked transformation.")
    truth = []
    processed_duration = duration
    if condition in EVENT_CONDITIONS:
        kind, length = condition.split("_")
        length = int(length)
        end = begin + length * 16
        if begin < 8000 or samples - end < 8000:
            raise ValueError("Fixed event must retain 500ms context on both sides.")
        start_ms, end_ms = begin / 16, end / 16
        if kind == "delete":
            truth = [{"type": "delete", "reference_interval_ms": [start_ms, end_ms], "processed_boundary_ms": start_ms + delay_ms}]
            processed_duration = math.ceil((samples - length * 16) / 2) / 8 + delay_ms
        else:
            truth = [{"type": "repeat", "reference_source_interval_ms": [start_ms, end_ms],
                      "processed_added_interval_ms": [end_ms + delay_ms, end_ms + length + delay_ms]}]
            processed_duration = math.ceil((samples + length * 16) / 2) / 8 + delay_ms
    elif condition == "normal_resample":
        processed_duration = math.ceil(samples / 2) / 8
    elif condition == "normal_combined":
        processed_duration = math.ceil(samples / 2) / 8 + delay_ms
    elif condition == "normal_delay":
        processed_duration = duration + delay_ms
    if _canonical(row["expected_events"]) != _canonical(truth):
        raise ValueError("Truth does not match prelocked edit length, axis and delay geometry.")
    if _canonical(row["input_duration_ms"]) != _canonical(max(duration, processed_duration)):
        raise ValueError("Timing denominator does not match the fixed input pair duration.")


def validate_inputs(root: Path, freeze: dict):
    protocol = _read(root / "protocol.json")
    declared = _protocol(protocol)
    sources = _sources(root, protocol, freeze)
    manifest, jobs = _read(root / "manifest.json"), _read(root / "worker_jobs.json")
    if not isinstance(manifest, list) or len(manifest) != PAIR_COUNT or not isinstance(jobs, list) or len(jobs) != PAIR_COUNT:
        raise ValueError("The corpus must contain exactly 56 paired trials.")
    seen, conditions, groups, counts = set(), set(), {}, Counter()
    for row, job in zip(manifest, jobs, strict=True):
        if not isinstance(row, dict) or not isinstance(job, dict) or set(job) != JOB_KEYS:
            raise ValueError("Worker jobs must contain paths/configuration/opaque ID only.")
        trial_id, group, category = row.get("trial_id"), row.get("source_group"), row.get("category")
        if (not isinstance(trial_id, str) or re.fullmatch(r"[a-zA-Z0-9_-]{1,64}", trial_id) is None
                or trial_id in seen or job["trial_id"] != trial_id or any(c in trial_id.casefold() for c in CONDITIONS)):
            raise ValueError("Trial IDs must be unique ordered opaque identifiers.")
        if group not in sources or category not in CATEGORIES:
            raise ValueError("Invalid original-source grouping.")
        if group in groups and groups[group] != category:
            raise ValueError("A source group cannot change category.")
        groups[group] = category
        scope, normal, condition = row.get("scope"), row.get("normal_trial"), row.get("condition")
        if scope not in {"supported", "stress"} or type(normal) is not bool or condition not in CONDITIONS:
            raise ValueError("Invalid fixed condition, trial scope or normal flag.")
        if (group, condition) in conditions:
            raise ValueError("A source cannot repeat a condition.")
        conditions.add((group, condition))
        if normal != (condition in NORMAL_CONDITIONS) or (scope == "stress") != (condition in STRESS_CONDITIONS):
            raise ValueError("Fixed condition disagrees with normal/stress declarations.")
        truth = row.get("expected_events")
        score_trial(truth, {"status": "withheld", "events": None})
        _configuration(row.get("configuration"))
        _geometry(row, sources[group])
        if _canonical(job["configuration"]) != _canonical(row["configuration"]):
            raise ValueError("Job configuration differs from the manifest.")
        for key in ("reference_path", "processed_path"):
            manifest_path = _inside(root, row.get(key))
            if not isinstance(job[key], str) or not Path(job[key]).is_absolute() or Path(job[key]).resolve() != manifest_path:
                raise ValueError("Worker input must be the exact frozen in-suite file.")
            relative = manifest_path.relative_to(root).as_posix()
            if relative not in freeze["dataset_sha256"]:
                raise ValueError("Audio input is not frozen.")
            if row.get(key.replace("_path", "_sha256")) != freeze["dataset_sha256"][relative]:
                raise ValueError("Manifest input hash differs from freeze.")
        if row["reference_sha256"] != sources[group]["reference_sha256"]:
            raise ValueError("Every condition must use its declared prepared reference, not another source alias.")
        seen.add(trial_id)
        counts[(group, "stress" if scope == "stress" else "normal" if normal else "event")] += 1
    if set(groups.items()) != declared or Counter(groups.values()) != Counter(SOURCE_COUNT_BY_CATEGORY):
        raise ValueError("Exactly four declared original music groups are required.")
    if any(counts[(g, kind)] != count for g in groups for kind, count in (("normal", 5), ("event", 6), ("stress", 3))):
        raise ValueError("Each source needs five normal, six event and three stress cases.")
    return protocol, manifest, jobs


def _exception(exc: Exception):
    reason = getattr(exc, "code", None)
    if not isinstance(reason, str) or re.fullmatch(r"[a-z][a-z0-9_]{0,127}", reason) is None:
        reason = None
    return {"exception_type": type(exc).__name__, "exception_reason_code": reason}


def worker_run(jobs_path: Path, output_path: Path, engine: str):
    if engine not in ENGINES:
        raise ValueError("Worker engine must be v1, v7 or v8.")
    from audio_regression.api import analyze_pair_with_trace
    # Match the predeclared timing scope: lazy candidate-module imports must
    # finish before even the first trial's API timer, without invoking engines.
    from audio_regression import engine as _v1, compound_engine as _v7, compound_event_engine as _v8
    from audio_regression.evaluation_worker import peak_resident_bytes
    jobs = _read(jobs_path)
    if not isinstance(jobs, list) or len(jobs) != PAIR_COUNT or any(not isinstance(j, dict) or set(j) != JOB_KEYS for j in jobs):
        raise ValueError("Worker jobs contain unsupported fields or trial count, possibly truth.")
    if len({j.get("trial_id") for j in jobs}) != len(jobs) or any(not isinstance(j.get("trial_id"), str) or not j["trial_id"] for j in jobs):
        raise ValueError("Worker IDs must be unique nonempty strings.")
    for job in jobs:
        _configuration(job["configuration"])
        if any(not isinstance(job[k], str) or not Path(job[k]).is_absolute() for k in ("reference_path", "processed_path")):
            raise ValueError("Worker paths must be absolute strings.")
    errors = 0
    with output_path.open("x", encoding="utf-8") as stream:
        for index, job in enumerate(jobs):
            start = time.perf_counter()
            try:
                result, trace = analyze_pair_with_trace(job["reference_path"], job["processed_path"], engine=engine, **job["configuration"])
                execution_error = False
            except Exception as exc:
                errors += 1
                execution_error = True
                result = {"status": "withheld", "events": None, "reason_code": "evaluation_execution_error", **_exception(exc)}
                trace = None
            runtime_ms = (time.perf_counter() - start) * 1000
            stream.write(json.dumps({"trial_id": job["trial_id"], "runtime_ms": runtime_ms,
                                     "execution_error": execution_error, "result": result, "trace": trace}, allow_nan=False) + "\n")
            stream.flush()
            if (index + 1) % 16 == 0 or index + 1 == len(jobs):
                print(json.dumps({"engine": engine, "completed": index + 1, "total": len(jobs)}), flush=True)
    metadata = {"engine": engine, "trial_count": len(jobs), "execution_error_count": errors,
                "timing_scope": "per_trial_API_file_read_analysis_and_contract_excluding_process_startup_and_imports",
                "peak_process_resident_bytes": peak_resident_bytes(),
                "memory_scope": "whole_method_worker_including_imports_and_jobs",
                "thread_environment": {key: os.environ.get(key) for key in
                                       ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS")}}
    _new_json(output_path.with_suffix(".metadata.json"), metadata)
    return metadata


def _validate_trace(trace, row, result, engine):
    if engine == "v1":
        if trace is not None:
            raise ValueError("Baseline v1 does not expose an analysis trace.")
        return
    identity = "local_content_alignment_" + engine
    if (not isinstance(trace, dict) or type(trace.get("schema_version")) is not int or trace["schema_version"] != 1
            or trace.get("engine") != identity or trace.get("analysis_engine") != identity
            or trace.get("method") != TRACE_METHODS[engine]
            or trace.get("reference_sha256") != row["reference_sha256"]
            or trace.get("processed_sha256") != row["processed_sha256"]
            or trace.get("result_status") != result.get("status")
            or trace.get("reason_code") != result.get("reason_code")):
        raise ValueError("Saved trace engine, method, hashes or result identity mismatch.")
    attempted, proved = (("compound_attempted", "compound_proved") if engine == "v7"
                         else ("compound_event_attempted", "compound_event_proved"))
    if type(trace.get(attempted)) is not bool or type(trace.get(proved)) is not bool:
        raise ValueError("Trace proof flags must be booleans.")
    preserved = "preserved_v6_result" if engine == "v7" else "preserved_v7_result"
    forward = "compound_normal_exact_forward" if engine == "v7" else "compound_event_exact_forward"
    if (trace.get("proof_path") not in {preserved, forward}
            or trace[proved] != (trace["proof_path"] == forward)
            or (trace[proved] and (not trace[attempted] or result["status"] != "analyzed"))):
        raise ValueError("Trace proof path and completion flags disagree.")
    if engine == "v8":
        inherited = trace.get("inherited_v7_trace")
        _validate_trace(inherited, row,
                        {"status": trace.get("baseline_status"), "reason_code": trace.get("baseline_reason_code")}, "v7")


def load_outputs(output_path: Path, manifest: list[dict], engine: str):
    rows = []
    for line in output_path.read_text(encoding="utf-8").splitlines():
        item = _loads(line)
        if not isinstance(item, dict) or set(item) != {"trial_id", "runtime_ms", "execution_error", "result", "trace"}:
            raise ValueError("Worker output has invalid fields.")
        rows.append(item)
    if len(rows) != len(manifest) or any(a["trial_id"] != b["trial_id"] for a, b in zip(rows, manifest, strict=True)):
        raise ValueError("Worker output is missing, duplicated or out of order.")
    joined = []
    for row, item in zip(manifest, rows, strict=True):
        runtime = item["runtime_ms"]
        if isinstance(runtime, bool) or not isinstance(runtime, (int, float)) or not math.isfinite(runtime) or runtime < 0:
            raise ValueError("Worker runtime must be finite and nonnegative.")
        if type(item["execution_error"]) is not bool or not isinstance(item["result"], dict):
            raise ValueError("Worker error flag or result is invalid.")
        if not item["execution_error"]:
            if item["result"].get("engine") != "local_content_alignment_" + engine:
                raise ValueError("Worker result engine mismatch.")
            # The inert strict validator follows the actual v7/v8 wrapper
            # inheritance and validates each exact engine/method identity.
            validate_analysis_result(item["result"])
            _validate_trace(item["trace"], row, item["result"], engine)
        else:
            result = item["result"]
            if (set(result) != {"status", "events", "reason_code", "exception_type", "exception_reason_code"}
                    or result.get("status") != "withheld" or result.get("events") is not None
                    or result.get("reason_code") != "evaluation_execution_error"
                    or not isinstance(result.get("exception_type"), str)
                    or (result.get("exception_reason_code") is not None
                        and re.fullmatch(r"[a-z][a-z0-9_]{0,127}", str(result["exception_reason_code"])) is None)):
                raise ValueError("Execution errors must use the fixed withheld exception envelope.")
            if item["trace"] is not None:
                raise ValueError("Execution exceptions cannot fabricate a completed engine trace.")
        item = {**item, "execution_error": item["execution_error"] or item["result"].get("status") == "error"}
        joined.append({**row, **item, "source_kind": row["category"], "profile": "basic"})
    return joined


def _supported_success(row):
    scored = score_trial(row["expected_events"], row["result"])
    return (not scored["withheld"] and scored["false_positive_events"] == 0
            and scored["false_negative_events"] == 0 and not row["execution_error"])


def _trace_summary(rows):
    traced = [r for r in rows if isinstance(r.get("trace"), dict)]
    event_proof_rows = [r for r in traced if r["trace"].get("proof_path") == "compound_event_exact_forward"
                        and r["trace"].get("compound_event_proved") is True]
    inherited_normal = [r for r in traced if r["trace"].get("proof_path") == "preserved_v7_result"
                        and r["trace"].get("inherited_v7_trace", {}).get("proof_path") == "compound_normal_exact_forward"
                        and r["trace"].get("inherited_v7_trace", {}).get("compound_proved") is True]
    def reasons(key):
        return dict(Counter(r["trace"][key] for r in traced if isinstance(r["trace"].get(key), str)))
    proof_reasons = Counter(r["trace"].get("event_proof_trace", {}).get("reason_code") for r in traced
                            if isinstance(r["trace"].get("event_proof_trace", {}).get("reason_code"), str))
    budget_rows = [r for r in traced if r["result"].get("status") == "withheld"
                   and any("budget" in str(code) or "depth" in str(code) for code in
                           (r["trace"].get("compound_event_failure"),
                            r["trace"].get("event_proof_trace", {}).get("reason_code"),
                            r["trace"].get("event_proof_trace", {}).get("incomplete_gain_search_reason")))]
    return {"trace_count": len(traced), "proof_paths": dict(Counter(r["trace"].get("proof_path") for r in traced)),
            "new_v8_event_proof_count": len(event_proof_rows),
            "new_v8_event_proof_trial_ids": [r["trial_id"] for r in event_proof_rows],
            "inherited_v7_normal_proof_count": len(inherited_normal),
            "inherited_v7_normal_proof_trial_ids": [r["trial_id"] for r in inherited_normal],
            "new_v7_normal_proof_count": sum(r["trace"].get("proof_path") == "compound_normal_exact_forward" for r in traced),
            "event_attempt_count": sum(r["trace"].get("compound_event_attempted") is True for r in traced),
            "compound_event_failures": reasons("compound_event_failure"),
            "compound_normal_failures": reasons("compound_failure"),
            "event_proof_reason_codes": dict(proof_reasons),
            "withheld_budget_or_depth_count": len(budget_rows),
            "withheld_budget_or_depth_trial_ids": [r["trial_id"] for r in budget_rows],
            "top_level_reason_codes": dict(Counter(r["result"]["reason_code"] for r in rows
                                                   if isinstance(r["result"].get("reason_code"), str)))}


def summarize(rows: list[dict]):
    supported = [r for r in rows if r["scope"] == "supported"]
    stress = [r for r in rows if r["scope"] == "stress"]
    return {"supported": aggregate_trials(supported),
            "supported_outcome_success_count": sum(_supported_success(r) for r in supported),
            "execution_error_count": sum(r["execution_error"] for r in rows),
            "trace_diagnostics": _trace_summary(rows),
            "stress": {"trial_count": len(stress), "false_clear_count": sum(
                r["result"].get("status") == "analyzed" and r["result"].get("events") == [] for r in stress),
                "withheld_count": sum(r["result"].get("status") == "withheld" for r in stress),
                "review_count": sum(r["result"].get("status") == "analyzed" and bool(r["result"].get("events")) for r in stress)},
            "by_source": {g: aggregate_trials([r for r in supported if r["source_group"] == g])["overall"]
                          for g in sorted({r["source_group"] for r in supported})},
            "by_event_type": {kind: aggregate_trials([
                r for r in supported if any(event["type"] == kind for event in r["expected_events"])
            ])["overall"] for kind in ("repeat", "delete")}}


def decide(candidate: dict, baseline: dict, secondary: dict):
    checks = []
    def check(name, passed, value):
        checks.append({"criterion": name, "passed": bool(passed), "observed": value})
    check("no_execution_errors", all(s["execution_error_count"] == 0 for s in (candidate, baseline, secondary)),
          {e: s["execution_error_count"] for e, s in zip(ENGINES, (baseline, secondary, candidate), strict=True)})
    check("stress_false_clear", candidate["stress"]["trial_count"] == SOURCE_COUNT * 3 and candidate["stress"]["false_clear_count"] == 0,
          candidate["stress"])
    for category in ("overall",) + CATEGORIES:
        def stratum(summary):
            return summary["supported"]["overall"] if category == "overall" else summary["supported"]["by_source_kind"].get(category, {})
        c = stratum(candidate)
        for key, policy_key, direction in (
            ("normal_coverage", "normal_coverage_minimum", "minimum"),
            ("event_precision", "event_precision_minimum", "minimum"),
            ("event_recall", "event_recall_minimum", "minimum"),
            ("median_primary_boundary_error_ms", "median_primary_boundary_error_maximum_ms", "maximum"),
            ("median_rtf", "median_rtf_maximum", "maximum"),
        ):
            value, threshold = c.get(key), CRITERIA[policy_key]
            valid = value is not None and (value >= threshold if direction == "minimum" else value <= threshold)
            check(f"{category}.{key}", valid, value)
        check(f"{category}.normal_false_alarm_count", c.get("normal_false_alarm_count") == 0, c.get("normal_false_alarm_count"))
        for comparison_engine, comparison in (("v1", baseline), ("v7", secondary)):
            b = stratum(comparison)
            for key, direction in (("normal_coverage", "higher"), ("event_recall", "higher"), ("normal_false_alarm_count", "lower")):
                cv, bv = c.get(key), b.get(key)
                check(f"{category}.nonregression_vs_{comparison_engine}.{key}",
                      cv is not None and bv is not None and (cv >= bv if direction == "higher" else cv <= bv),
                      {"v8": cv, comparison_engine: bv})
    for name, comparison in (("v1", baseline), ("v7", secondary)):
        improvement = candidate["supported_outcome_success_count"] - comparison["supported_outcome_success_count"]
        check(f"supported_outcome_improvement_vs_{name}", improvement >= CRITERIA["minimum_supported_outcome_improvements"], improvement)
    for kind in ("delete", "repeat"):
        for key in ("event_precision", "event_recall"):
            value = candidate["by_event_type"][kind].get(key)
            check(f"{kind}.{key}", value is not None and value >= CRITERIA[f"{kind}_{key}_minimum"], value)
    passed = all(c["passed"] for c in checks)
    return {"adopt": passed,
            "decision": "adopt_v8_candidate_for_scoped_offline_use_only" if passed else "keep_v1_default",
            "automatic_default_activation": False, "default_engine_unchanged": "v1",
            "criteria_checks": checks, "commercial_performance_validated": False,
            "population_accuracy_established": False, "statistically_proven_improvement": False,
            "scope": "four_new_music_recordings_fixed_transformations_offline_policy_only"}


def _bootstrap(candidate, baseline):
    return {"overall": paired_group_bootstrap(candidate, baseline, resamples=BOOTSTRAP_RESAMPLES, seed=BOOTSTRAP_SEED),
            "by_category": {c: paired_group_bootstrap([r for r in candidate if r["category"] == c],
                                  [r for r in baseline if r["category"] == c],
                                  resamples=BOOTSTRAP_RESAMPLES, seed=BOOTSTRAP_SEED) for c in CATEGORIES}}


def score_saved(root: Path, manifest: list[dict]):
    rows = {engine: load_outputs(root / "outputs" / f"{engine}.jsonl", manifest, engine) for engine in ENGINES}
    summaries = {engine: summarize(items) for engine, items in rows.items()}
    supported = {engine: [r for r in items if r["scope"] == "supported"] for engine, items in rows.items()}
    primary, secondary_bootstrap = _bootstrap(supported["v8"], supported["v1"]), _bootstrap(supported["v8"], supported["v7"])
    secondary = {"candidate": "v8", "baseline": "v7",
                 "supported_outcome_success_difference": summaries["v8"]["supported_outcome_success_count"] - summaries["v7"]["supported_outcome_success_count"],
                 "improved_trial_ids": [c["trial_id"] for c, b in zip(supported["v8"], supported["v7"], strict=True)
                                        if _supported_success(c) and not _supported_success(b)],
                 "regressed_trial_ids": [c["trial_id"] for c, b in zip(supported["v8"], supported["v7"], strict=True)
                                         if not _supported_success(c) and _supported_success(b)],
                 "paired_source_bootstrap": secondary_bootstrap["overall"],
                 "paired_source_bootstrap_by_category": secondary_bootstrap["by_category"]}
    return {"schema_version": 1, "status": "completed", "engines": summaries,
            "decision": decide(summaries["v8"], summaries["v1"], summaries["v7"]),
            "paired_source_bootstrap": primary["overall"],
            "paired_source_bootstrap_by_category": primary["by_category"],
            "secondary_comparison_v8_vs_v7": secondary,
            "execution_failure_count": sum(s["execution_error_count"] for s in summaries.values()),
            "worker_timeout_count": 0,
            "limitations": ["Only four original music recordings.",
                            "Transformed conditions are dependent observations, not new originals.",
                            "Group-bootstrap intervals are descriptive, not population accuracy evidence.",
                            "No speech, real user pipeline, stereo, full-band quality, long-file or streaming claim.",
                            "Engine worker order is fixed v1 then v7 then v8; filesystem caching may affect costs.",
                            "A scoped adoption recommendation does not activate a new default engine."]}


def run_suite(suite_root: Path):
    root = suite_root.resolve()
    freeze = verify_freeze(root)
    protocol, manifest, jobs = validate_inputs(root, freeze)
    freeze_digest = _sha(root / "freeze.json")
    _new_json(root / "run_claim.json", {"schema_version": 1, "claimed_at_utc": datetime.now(timezone.utc).isoformat(),
              "freeze_sha256": freeze_digest, "engines": list(ENGINES), "final_uses": 1,
              "automatic_retry_allowed": False})
    failures = []
    try:
        outputs = root / "outputs"
        outputs.mkdir(exist_ok=False)
        env = os.environ.copy()
        env.update({key: "1" for key in ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS")})
        env["PYTHONPATH"] = str(PACKAGE.parent)
        for engine in ENGINES:
            command = [sys.executable, str(Path(__file__).resolve()), "--worker-engine", engine,
                       "--jobs", str(root / "worker_jobs.json"), "--output", str(outputs / f"{engine}.jsonl")]
            try:
                completed = subprocess.run(command, env=env, cwd=WORKSPACE, check=False, timeout=WORKER_TIMEOUT_SECONDS)
                if completed.returncode != 0:
                    failures.append({"engine": engine, "failure": "worker_nonzero_exit", "returncode": completed.returncode})
            except subprocess.TimeoutExpired:
                failures.append({"engine": engine, "failure": "worker_timeout", "timeout_seconds": WORKER_TIMEOUT_SECONDS})
            except Exception as exc:
                failures.append({"engine": engine, "failure": "worker_launch_exception", **_exception(exc)})
        if failures:
            raise RuntimeError("One or more isolated engine workers did not complete.")
        # This is the first truth-scoring call; all three raw files already exist.
        report = score_saved(root, manifest)
        if _sha(root / "freeze.json") != freeze_digest or verify_freeze(root) != freeze:
            raise ValueError("The freeze declaration changed during execution.")
        report["freeze_unchanged"] = True
    except Exception as exc:
        try:
            unchanged = _sha(root / "freeze.json") == freeze_digest and verify_freeze(root) == freeze
        except Exception:
            unchanged = False
        report = {"schema_version": 1, "status": "incomplete", "freeze_unchanged": unchanged,
                  "decision": {"adopt": False, "decision": "keep_v1_default", "automatic_default_activation": False},
                  "execution_failure": _exception(exc), "worker_failures": failures,
                  "execution_failure_count": max(1, len(failures)),
                  "worker_timeout_count": sum(f["failure"] == "worker_timeout" for f in failures),
                  "automatic_retry_allowed": False}
    _new_json(root / "report.json", report)
    _new_json(root / "run_completed.json", {"schema_version": 1, "completed_at_utc": datetime.now(timezone.utc).isoformat(),
              "status": report["status"], "report_sha256": _sha(root / "report.json"),
              "adopt": report["decision"]["adopt"], "automatic_retry_allowed": False})
    print(json.dumps({"status": report["status"], "decision": report["decision"]["decision"],
                      "report": str(root / "report.json")}, ensure_ascii=False), flush=True)
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--suite-dir", type=Path)
    parser.add_argument("--worker-engine", choices=ENGINES)
    parser.add_argument("--jobs", type=Path)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    if args.worker_engine is not None:
        if args.jobs is None or args.output is None or args.suite_dir is not None:
            parser.error("Worker mode requires jobs/output only.")
        worker_run(args.jobs, args.output, args.worker_engine)
        return 0
    if args.suite_dir is None or args.jobs is not None or args.output is not None:
        parser.error("Evaluation mode requires suite-dir only.")
    result = run_suite(args.suite_dir)
    return 0 if result["status"] == "completed" else 2


if __name__ == "__main__":
    raise SystemExit(main())
