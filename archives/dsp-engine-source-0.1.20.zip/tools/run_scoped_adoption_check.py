"""Fixed private M5 comparison, never commercial or natural-audio accuracy.

Compare declared narrow candidates with the frozen v9 engine and directly run
FFmpeg PCM-MD5 plus duration and global-correlation alternatives on identical
new owned synthetic files. The alternatives keep their actual non-localizing
outputs; no undocumented pass threshold or invented event list is added.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
from html import escape
import json
from pathlib import Path
import re
import subprocess
import time

import numpy as np
from scipy.signal import resample

import audio_regression
from audio_regression.api import analyze_pair_with_trace
from audio_regression.audio import decode_wav, encode_wav, read_wav
from audio_regression.baseline import BaselineConfig, compare_wavs
from audio_regression.check_policy import check_result
from audio_regression.fixtures import generate_case
from audio_regression.reporting import render_html


MODEL = "scipy_fft_periodic_48k_16k_pcm16_postedit_v1"
RATES = (8000, 16000, 44100, 48000)


def _sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _save(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as output:
        json.dump(value, output, ensure_ascii=False, indent=2, allow_nan=False)
        output.write("\n")


def _pcm(values):
    rounded = np.rint(values * 32768)
    if np.any(rounded < -32768) or np.any(rounded > 32767):
        raise ValueError("The owned producer exceeds PCM16 without clipping")
    return rounded / 32768


def _ffmpeg_digest(executable, path):
    completed = subprocess.run(
        [str(executable), "-hide_banner", "-nostdin", "-v", "error", "-i", str(path),
         "-map", "0:a:0", "-c:a", "pcm_s16le", "-f", "md5", "-"],
        stdin=subprocess.DEVNULL, capture_output=True, check=True, timeout=20)
    match = re.fullmatch(rb"MD5=([0-9a-f]{32})\s*", completed.stdout)
    if match is None:
        raise ValueError("Unexpected comparator output")
    return match.group(1).decode("ascii")


def run(output, ffmpeg, expected_digest):
    if output.exists() or not ffmpeg.is_file() or ffmpeg.is_symlink():
        raise ValueError("Use a new output and explicitly supplied regular FFmpeg")
    if not re.fullmatch(r"[0-9a-f]{64}", expected_digest) or _sha(ffmpeg) != expected_digest:
        raise ValueError("The comparator executable does not match the declared digest")
    ffmpeg_version = subprocess.run([str(ffmpeg), "-hide_banner", "-version"], stdin=subprocess.DEVNULL,
                                   capture_output=True, check=True, timeout=10).stdout.decode("utf-8", "replace").splitlines()[0]
    output.mkdir(parents=True)
    (output / "audio").mkdir()
    (output / "results").mkdir()
    jobs = []

    def add(group, kind, x, y, rate, target_rate, expected=None, options=None):
        index = len(jobs)
        reference, processed = (output / "audio" / f"{index:03d}-{axis}.wav" for axis in ("r", "p"))
        reference.write_bytes(encode_wav(x, rate))
        processed.write_bytes(encode_wav(y, target_rate))
        jobs.append({"id": index, "group": group, "kind": kind, "reference": reference.name,
                     "processed": processed.name, "expected": expected, "options": options or {}})

    def targets(group, x, canonical, source_rate, target_rate):
        point = 2 * target_rate
        for duration in (50, 100, 200):
            size = target_rate * duration // 1000
            assert size * 1000 == duration * target_rate
            add(group, "delete", x, np.concatenate((canonical[:point], canonical[point+size:])),
                source_rate, target_rate, {"type": "delete", "reference_interval_ms": [2000, 2000+duration],
                                           "processed_boundary_ms": 2000})
            add(group, "repeat", x, np.concatenate((canonical[:point], canonical[point-size:point], canonical[point:])),
                source_rate, target_rate, {"type": "repeat", "reference_source_interval_ms": [2000-duration, 2000],
                                           "processed_added_interval_ms": [2000, 2000+duration]})
        for duration in (50, 500, 2000):
            size = target_rate * duration // 1000
            total = len(canonical) * 1000 / target_rate
            for side in ("head", "tail"):
                values = canonical[size:] if side == "head" else canonical[:-size]
                add(group, side, x, values, source_rate, target_rate,
                    {"type": "delete", "location": side,
                     "reference_interval_ms": [0, duration] if side == "head" else [total-duration, total],
                     "processed_boundary_ms": 0 if side == "head" else total-duration})

    for rate in RATES:
        x = decode_wav(generate_case(seed=202610155041 + rate, duration_seconds=6, sample_rate_hz=rate).reference_wav).samples
        targets("native", x, x, rate, rate)
        add("native_normal", "identity", x, x, rate, rate)
        add("native_normal", "gain", x, _pcm(x*.5), rate, rate, options={"allow_gain": True})
        add("native_normal", "zero_delay", x, np.concatenate((np.zeros(rate//10), x)), rate, rate)
        damaged = x[rate//10:].copy()
        damaged[len(damaged)//2] += 1/32768
        add("negative", "native_retained_one_LSB", x, damaged, rate, rate)
        period = np.tile(np.array([.125, 0, -.125, 0]), (6*rate+3)//4)[:6*rate]
        add("negative", "periodic_endpoint_ambiguity", period, period[rate//5:], rate, rate)
    for base in range(2):
        x = decode_wav(generate_case(seed=202610155177 + base, duration_seconds=6, sample_rate_hz=48000).reference_wav).samples
        if base:
            x = x[:-3]
        canonical = _pcm(resample(x, len(x)//3))
        targets("fft", x, canonical, 48000, 16000)
        add("fft_normal", "exact_fft", x, canonical, 48000, 16000)
        damaged = canonical.copy()
        damaged[-1] += 1/32768
        add("fft_negative", "one_LSB_after_FFT", x, damaged, 48000, 16000)
    # Bind all supported algorithm modules and old schemas before any scoring.
    package = Path(audio_regression.__file__).parent
    names = ("api.py", "audio.py", "profiles.py", "engine.py", "baseline.py", "fixtures.py",
             "analysis_scope.py", "robust_engine.py", "context_engine.py", "instrument_engine.py",
             "canonical_engine.py", "repeat_engine.py", "compound_engine.py", "compound_gain.py",
             "compound_event_engine.py", "compound_event_proof.py", "global_context_engine.py",
             "short_event_engine.py", "edge_event_engine.py", "resampler_engine.py",
             "result_contract.py", "short_event_result_contract.py", "edge_event_result_contract.py",
             "resampler_result_contract.py", "review_contract.py", "review_diagnostics.py",
             "endpoint_mapping.py", "reporting.py", "check_policy.py")
    frozen = {name: _sha(package / name) for name in names}
    frozen.update({"schemas/"+path.name: _sha(path) for path in sorted((package / "schemas").glob("analysis-result-*.json"))})
    audio_hashes = {path.name: _sha(path) for path in (output / "audio").iterdir()}
    _save(output / "protocol.json", {"schema_version": 1, "sdk_version": audio_regression.__version__,
        "scope": "six new owned synthetic bases and dependent transformations, opt-in scoped adoption only",
        "source_sha256": frozen, "audio_sha256": audio_hashes, "jobs": jobs,
        "acceptance": {"native_event_geometries": 48, "fft_event_geometries": 24,
                       "no_target_event_condition_may_clear": True, "negative_conditions_all_blocked": 10,
                       "native_normal_status_events_match_v9": True, "fft_normal_exact": 2,
                       "default_remains_v1": True, "no_threshold_retuning": True},
        "comparators": {"ffmpeg_pcm_md5": {"actual_executable_version": ffmpeg_version, "sha256": expected_digest,
             "purpose": "Decoded PCM equality, not event localization or transformation tolerance",
             "redistributed": False, "primary_source": "https://ffmpeg.org/ffmpeg-formats.html#md5"},
             "duration_delta": {"purpose": "Net duration difference, not missing/copy provenance or location"},
             "global_xcorr": {"purpose": "Existing measured global lag/correlation, no invented defect list or pass threshold"},
             "deltawave": {"executed": False, "reason": "Not installed; no fabricated competitor benchmark or superiority claim",
                           "primary_source": "https://deltaw.org/mydoc_quickstart.html"}},
        "sealed_music_or_customer_audio_replayed": False, "natural_audio_accuracy_or_competitor_superiority_claim": False})
    rows, digest_cache = [], {}
    for job in jobs:
        reference, processed = (output / "audio" / job[name] for name in ("reference", "processed"))
        target = job["group"] in {"native", "fft"}
        fft = job["group"].startswith("fft")
        options = {**job["options"], **({"allow_resampling": True} if fft else {})}
        candidate = "v12" if fft else "v11"
        engines = ("v9", candidate) if target or job["group"].endswith("normal") else (candidate,)
        for engine in engines:
            started = time.perf_counter()
            result, trace = analyze_pair_with_trace(reference, processed, engine=engine, **options,
                **({"resampling_model": MODEL} if engine == "v12" else {}))
            correct = False
            if target and result["status"] == "analyzed" and len(result["events"]) == 1:
                correct = all(result["events"][0].get(key) == value for key, value in job["expected"].items())
            row = {"job_id": job["id"], "group": job["group"], "kind": job["kind"], "engine": engine,
                   "status": result["status"], "reason_code": result["reason_code"],
                   "gate_state": check_result(result)["gate_state"], "correct_event_geometry": correct,
                   "elapsed_seconds": time.perf_counter()-started}
            rows.append(row)
            _save(output / "results" / f"{job['id']:03d}-{engine}.json", {"measurement": row, "result": result, "trace": trace})
            if engine == candidate and target and job["id"] in (0, 6, 68):
                with (output / f"example-{job['id']:03d}.html").open("x", encoding="utf-8") as stream:
                    stream.write(render_html(result))
        if job["group"] in {"native", "native_normal"}:
            for path in (reference, processed):
                digest_cache.setdefault(path.name, _ffmpeg_digest(ffmpeg, path))
            r, p = read_wav(reference), read_wav(processed)
            global_result = compare_wavs(reference, processed, BaselineConfig(**job["options"]))
            _save(output / "results" / f"{job['id']:03d}-direct-alternatives.json", {
                "ffmpeg_pcm_md5_equal": digest_cache[reference.name] == digest_cache[processed.name],
                "duration_delta_ms": p.metadata()["duration_ms"]-r.metadata()["duration_ms"],
                "global_comparator": global_result, "no_event_localization_claimed": True})
    assert frozen == {name: _sha(package / name) for name in frozen}
    assert audio_hashes == {path.name: _sha(path) for path in (output / "audio").iterdir()}
    counts = {}
    for engine, group in (("v11", "native"), ("v12", "fft"), ("v9", "native"), ("v9", "fft")):
        selected = [row for row in rows if row["engine"] == engine and row["group"] == group]
        counts[engine+"_"+group] = {"total": len(selected), "correct_geometry": sum(row["correct_event_geometry"] for row in selected),
             "incorrect_clear": sum(row["gate_state"] == "clear_supported_temporal_check" for row in selected)}
    assert counts["v11_native"] == {"total": 48, "correct_geometry": 48, "incorrect_clear": 0}
    assert counts["v12_fft"] == {"total": 24, "correct_geometry": 24, "incorrect_clear": 0}
    negatives = [row for row in rows if row["group"] in {"negative", "fft_negative"}]
    assert len(negatives) == 10 and all(row["gate_state"] == "blocked" for row in negatives)
    for job in [job for job in jobs if job["group"] == "native_normal"]:
        old = json.loads((output / "results" / f"{job['id']:03d}-v9.json").read_text(encoding="utf-8"))["result"]
        new = json.loads((output / "results" / f"{job['id']:03d}-v11.json").read_text(encoding="utf-8"))["result"]
        assert all(old[key] == new[key] for key in ("status", "events", "reason_code"))
    normal_fft = [row for row in rows if row["group"] == "fft_normal" and row["engine"] == "v12"]
    assert len(normal_fft) == 2 and all(row["gate_state"] == "clear_supported_temporal_check" for row in normal_fft)
    summary = {"schema_version": 1, "completed_at": datetime.now(timezone.utc).isoformat(),
               "status": "scoped_opt_in_adoption_criteria_met_not_default_promotion_or_commercial_accuracy",
               "sdk_version": audio_regression.__version__, "owned_base_count": 6, "analyses": len(rows),
               "candidate_results": counts, "negative_conditions_blocked": 10, "normal_native_preserved": 12,
               "normal_fft_exact": 2, "direct_alternative_pairs_executed": 60,
               "alternative_event_geometry_support_in_this_test": False,
               "adopted": {"v10": "native short-edit component retained inside opt-in v11",
                           "v11": "opt-in same-rate native short edit/endpoint extensions with preserved legacy fallback",
                           "v12": "opt-in explicit fixed FFT48to16 model and exact postedit only"},
               "default_engine": "v1", "default_changed": False,
               "independent_natural_audio_customer_utility_or_competitor_superiority_verified": False,
               "source_and_inputs_preserved": True}
    _save(output / "comparison.json", {"summary": summary, "trials": rows})
    table = "".join(f'<tr><td>{escape(key)}</td><td>{value["correct_geometry"]}/{value["total"]}</td><td>{value["incorrect_clear"]}</td></tr>' for key, value in counts.items())
    report = ('<!doctype html><html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
              '<meta http-equiv="Content-Security-Policy" content="default-src \'none\';style-src \'unsafe-inline\'">'
              '<title>DSP 추가 기능의 한정 채택 비교</title><style>body{font:16px/1.7 system-ui;max-width:1000px;margin:40px auto;padding:0 24px;color:#1b2d43}table{border-collapse:collapse;width:100%}td,th{padding:12px;border-bottom:1px solid #dde4eb;text-align:left}aside{background:#fff6e7;padding:20px;border-radius:12px}</style>'
              '<h1>추가 기능의 한정 채택 비교</h1><aside>새 자체 합성 원본 6개의 종속 변형 결과입니다. 실제 사용자 정확도·수요·경쟁 제품 우위를 증명하지 않습니다. 기본 v1은 유지하고 지원 범위를 명시한 선택형 기능으로만 채택합니다.</aside>'
              '<h2>동일 파일에서 확인한 사건 좌표</h2><table><tr><th>방식·조건</th><th>정확한 좌표</th><th>잘못된 정상 통과</th></tr>'+table+'</table>'
              '<p>추가 손상·모호한 조건 10개 모두 보류. 기존 정상 조건 12개 유지. 정확한 FFT 정상 출력 2개 확인.</p>'
              '<h2>직접 실행한 대안 방식</h2><p>같은 원본·처리본 60쌍에서 FFmpeg PCM-MD5, 길이 차이, 전역 교차상관을 실제로 실행했습니다. 변경·순시간 차이·전역 지연 수치는 각각 유용하지만, 이 대안 출력에 없는 삭제·반복 구간이나 승인 판정을 만들어 비교하지 않았습니다.</p>'
              '<p>PCM 동일성 검사는 정상 음량·지연 변화도 차이로 표시합니다. 이것은 그 도구의 오류가 아니라 검사 목적의 차이입니다. Workbench 역시 전체 음질·비트 동일성 도구의 대체재는 아닙니다.</p>'
              '<p>DeltaWave는 설치·실행하지 않아 성능 우위를 주장하지 않습니다. 상용 경쟁 제품을 이겼다는 결론은 없습니다.</p>'
              '<p><a href="https://ffmpeg.org/ffmpeg-formats.html#md5">FFmpeg MD5 공식 문서</a> · <a href="https://deltaw.org/mydoc_quickstart.html">DeltaWave 공식 안내</a></p></html>')
    with (output / "comparison.html").open("x", encoding="utf-8") as stream:
        stream.write(report)
    print(json.dumps(summary))
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--ffmpeg", type=Path, required=True)
    parser.add_argument("--expected-ffmpeg-sha256", required=True)
    args = parser.parse_args()
    run(args.output_dir.absolute(), args.ffmpeg.absolute(), args.expected_ffmpeg_sha256)
