"""Save the fixed owned-synthetic v3/v4 development comparison, offline.

No natural/sealed audio, answer key, or expected result is sent to the detector.
This reuses development signal specifications and is not an independent eval.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path
import time

import numpy as np
from scipy.signal import resample_poly

import audio_regression
from audio_regression.api import analyze_pair_with_trace
from audio_regression.audio import decode_wav, encode_wav
from audio_regression.check_policy import check_result
from audio_regression.reporting import write_html_report


RATE, COUNT = 16000, 96000


def _instrument():
    t = np.arange(COUNT) / RATE
    frequency = 409 + 12 * t + 1.4 * np.sin(2 * np.pi * .73 * t)
    phase = 2 * np.pi * np.cumsum(frequency) / RATE
    envelope = .6 + .15 * np.sin(2 * np.pi * .31 * t) + .12 * np.sin(2 * np.pi * .17 * t + .7)
    values = envelope * (np.sin(phase) + .31 * np.sin(2 * phase + .2) + .16 * np.sin(3 * phase + .7))
    return values * (.28 / np.max(np.abs(values)))


def _percussion():
    values = np.zeros(COUNT)
    for index, onset in enumerate((.08, .57, 1.19, 1.88, 2.42, 3.04, 3.71, 4.26, 4.98, 5.52)):
        first = round(onset * RATE)
        length = min(round(.42 * RATE), COUNT - first)
        t = np.arange(length) / RATE
        phase = 2 * np.pi * ((367 + 29 * index) * t + (35 + 7 * index) * t * t)
        hit = (1 - np.exp(-t / .002)) * np.exp(-t / (.059 + .005 * index)) * (
            np.sin(phase) + .43 * np.sin(2.71 * phase + .31))
        values[first:first + length] += hit * (.22 + .012 * index)
    return values * (.28 / np.max(np.abs(values)))


def _json_new(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2, allow_nan=False)
        stream.write("\n")


def _wav_new(path, values, rate):
    data = encode_wav(values, rate)
    with path.open("xb") as stream:
        stream.write(data)
    return data


def _cases():
    first, last = round(2.3 * RATE), round(2.7 * RATE)
    for source, make in (("instrument", _instrument), ("percussion", _percussion)):
        values = decode_wav(encode_wav(make(), RATE)).samples
        for change in ("identity", "gain", "delay", "resample", "delete", "repeat", "dropout", "replacement"):
            target, rate, declaration = values.copy(), RATE, {}
            expected_type = change if change in {"delete", "repeat"} else None
            expected_status = "withheld" if change in {"dropout", "replacement"} else "analyzed"
            if change == "gain":
                target *= .5
                declaration["allow_gain"] = True
            elif change == "delay":
                target = np.concatenate((np.zeros(3840), target))
            elif change == "resample":
                target, rate = resample_poly(target, 1, 2), 8000
                declaration["allow_resampling"] = True
            elif change == "delete":
                target = np.concatenate((target[:first], target[last:]))
            elif change == "repeat":
                target = np.concatenate((target[:last], target[first:last], target[last:]))
            elif change == "dropout":
                target[first:last] = 0
            elif change == "replacement":
                target[first:last] = target[first:last][::-1]
            category = "event" if expected_type else "safety" if expected_status == "withheld" else "normal"
            yield source, change, category, values, target, rate, declaration, expected_status, expected_type
    t = np.arange(COUNT) / RATE
    hit_t = np.arange(RATE // 2) / RATE
    block = (1 - np.exp(-hit_t / .002)) * np.exp(-hit_t / .06) * (
        np.sin(2 * np.pi * 421 * hit_t) + .4 * np.sin(2 * np.pi * 997 * hit_t))
    for source, values in (("silence", np.zeros(COUNT)), ("pure_tone", .2 * np.sin(2 * np.pi * 400 * t)),
                           ("identical_hits", np.tile(block, 12) * .2)):
        yield source, "identity", "safety", values, values, RATE, {}, "withheld", None


def _expected(result, status, event_type):
    if result["status"] != status:
        return False
    if status == "withheld":
        return result["events"] is None
    if event_type is None:
        return result["events"] == []
    if len(result["events"]) != 1 or result["events"][0]["type"] != event_type:
        return False
    event = result["events"][0]
    interval = event["reference_interval_ms"] if event_type == "delete" else event["reference_source_interval_ms"]
    if abs(interval[0] - 2300) > 100 or abs(interval[1] - 2700) > 100 or abs(interval[1] - interval[0] - 400) > 10:
        return False
    if event_type == "delete":
        return abs(event["processed_boundary_ms"] - 2300) <= 100
    return all(abs(a - b) <= 100 for a, b in zip(event["processed_added_interval_ms"], (2700, 3100), strict=True))


def run(output, require_installed=False):
    package_path = Path(audio_regression.__file__).resolve()
    if require_installed and (audio_regression.__version__ != "0.1.2" or "site-packages" not in package_path.parts):
        raise RuntimeError("An installed 0.1.2 wheel is required.")
    output.mkdir(parents=True, exist_ok=False)
    records = []
    totals = {engine: {kind: {"correct": 0, "total": 0} for kind in ("normal", "event", "safety")}
              for engine in ("v3", "v4")}
    for index, (source, change, category, reference, processed, rate, declaration, status, event_type) in enumerate(_cases(), 1):
        folder = output / f"case_{index:02d}"
        folder.mkdir()
        reference_path, processed_path = folder / "reference.wav", folder / "processed.wav"
        original = _wav_new(reference_path, reference, RATE)
        target = _wav_new(processed_path, processed, rate)
        engines = {}
        for engine in ("v3", "v4"):
            start = time.perf_counter()
            result, trace = analyze_pair_with_trace(reference_path, processed_path, engine=engine, **declaration)
            elapsed = (time.perf_counter() - start) * 1000
            check = check_result(result)
            matched = _expected(result, status, event_type)
            totals[engine][category]["total"] += 1
            totals[engine][category]["correct"] += matched
            _json_new(folder / f"{engine}_analysis.json", result)
            _json_new(folder / f"{engine}_trace.json", trace)
            _json_new(folder / f"{engine}_check.json", check)
            write_html_report(result, folder / f"{engine}_report.html")
            engines[engine] = {"status": result["status"], "reason_code": result["reason_code"],
                               "events": result["events"], "expected_behavior_met": matched,
                               "elapsed_ms": elapsed, "proof_path": trace.get("proof_path")}
        assert reference_path.read_bytes() == original and processed_path.read_bytes() == target
        records.append({"id": index, "source": source, "change": change, "category": category, "engines": engines})
    summary = {"schema_version": 1, "status": "completed", "version": audio_regression.__version__,
               "package_path": str(package_path), "case_count": len(records), "totals": totals, "records": records,
               "same_development_signal_specifications_reused": True, "independent_evaluation": False,
               "sealed_evaluation_replayed": False, "population_accuracy_established": False,
               "commercial_performance_validated": False, "browser_visual_inspection_verified": False}
    _json_new(output / "summary.json", summary)
    if not all(row["engines"]["v4"]["expected_behavior_met"] for row in records):
        raise RuntimeError("Development expectation failed; all new outputs are preserved.")
    return summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--require-installed", action="store_true")
    args = parser.parse_args()
    report = run(args.output_dir, args.require_installed)
    print(json.dumps({"status": report["status"], "cases": report["case_count"],
                      "totals": report["totals"], "summary": str(args.output_dir / "summary.json")}, ensure_ascii=False))
