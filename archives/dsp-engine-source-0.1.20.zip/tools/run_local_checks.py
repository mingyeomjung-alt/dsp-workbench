"""Run the fixed, source-local contract regression without rebuilding evidence.

This is not the full suite, an evaluation, an installer, or an audio gate.  A
successful run binds the selected source bytes before/after subprocess execution
and optionally checks an existing artifact manifest against a caller-held hash.
Existing outputs and source/evaluation files are never rewritten by this tool.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
import subprocess
import sys
import types
import xml.etree.ElementTree as ET


SELECTED_TEST_FILES = (
    "test_api.py", "test_audio_input_contract.py", "test_build_handoff.py",
    "test_check_policy.py", "test_cli.py", "test_cli_error_contract.py",
    "test_context_contracts.py", "test_fullband_contract.py", "test_fullband_metrics.py",
    "test_fullband_runner.py", "test_fullband_surface.py", "test_handoff_cli.py",
    "test_instrument_contracts.py", "test_mobile_timeline.py", "test_model_check.py",
    "test_model_contract.py", "test_model_surface.py", "test_pipeline_cli.py",
    "test_pipeline_reporting.py", "test_pipeline_runner.py", "test_pipeline_saved_cli.py",
    "test_pipeline_transforms.py", "test_profiles.py", "test_release_sources.py",
    "test_reporting.py", "test_result_contract.py", "test_review_api.py",
    "test_review_contract.py", "test_review_projection.py", "test_review_reporting.py",
    "test_robust_contracts.py", "test_saved_pipeline.py", "test_saved_pipeline_contract.py",
    "test_saved_pipeline_reporting.py", "test_transform_models.py",
    "test_artifact_integrity.py", "test_artifact_cli.py", "test_local_checks.py",
    "test_pipeline_snapshot_recheck.py",
    "test_short_event_engine.py", "test_short_event_contract.py", "test_short_event_integration.py",
    "test_edge_event_engine.py", "test_edge_event_contract.py", "test_edge_event_integration.py",
    "test_resampler_engine.py", "test_resampler_contract.py", "test_resampler_integration.py",
    "test_event_lineage.py", "test_event_lineage_contract.py", "test_event_lineage_integration.py",
    "test_m5_pipeline_integration.py",
    "test_regression_suite_contract.py", "test_regression_suite_diff.py",
    "test_regression_suite_runner.py", "test_regression_suite_cli.py",
    "test_regression_suite_reporting.py", "test_regression_suite_safety.py",
)
ROOT_CONFIG_FILES = (
    "pyproject.toml", "constraints.txt", "constraints-offline.txt", "constraints-build.txt",
)
SYNTHETIC_RESULT_FILES = (
    "synthetic_basic_clean.json", "synthetic_basic_delete.json", "synthetic_basic_repeat.json",
    "synthetic_telephone_clean.json", "synthetic_telephone_delete.json", "synthetic_telephone_repeat.json",
    "synthetic_global_baseline.json",
)
MAX_SOURCE_FILE_BYTES = 8 * 1024 * 1024
MAX_SOURCE_FILES = 2048
MAX_JUNIT_BYTES = 16 * 1024 * 1024
MAX_TEST_CASES = 100000
_CODE = re.compile(r"[a-z][a-z0-9_]{0,127}\Z")
_HASH = re.compile(r"[0-9a-f]{64}\Z")


class LocalCheckError(ValueError):
    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__("Local selected checks could not complete: " + code + ".")


def _path(value: str | Path) -> Path:
    try:
        raw = os.fspath(value)
        if type(raw) is not str or not raw or ".." in Path(raw).parts:
            raise LocalCheckError("invalid_local_check_path")
        return Path(os.path.abspath(raw))
    except (TypeError, ValueError, OSError):
        raise LocalCheckError("invalid_local_check_path") from None


def _linked(info: os.stat_result) -> bool:
    return stat.S_ISLNK(info.st_mode) or bool(
        getattr(info, "st_file_attributes", 0)
        & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0x400)
    )


def _parents(path: Path) -> None:
    for parent in reversed(path.parents):
        try:
            info = parent.lstat()
        except FileNotFoundError:
            continue
        if _linked(info) or not stat.S_ISDIR(info.st_mode):
            raise LocalCheckError("unsafe_local_check_parent")


def _normal(path: Path, *, directory: bool = False) -> os.stat_result:
    _parents(path)
    try:
        info = path.lstat()
    except OSError:
        raise LocalCheckError("local_check_file_unavailable") from None
    if _linked(info):
        raise LocalCheckError("unsafe_local_check_file")
    if directory:
        if not stat.S_ISDIR(info.st_mode):
            raise LocalCheckError("invalid_local_check_directory")
    elif not stat.S_ISREG(info.st_mode) or info.st_nlink != 1:
        raise LocalCheckError("unsafe_local_check_file")
    return info


def _identity(info: os.stat_result) -> tuple:
    return (*_cross_identity(info), info.st_ctime_ns)


def _cross_identity(info: os.stat_result) -> tuple:
    # Python 3.12 Windows lstat ctime denotes creation while fstat ctime can
    # denote metadata change. Keep ctime within each API, never across APIs.
    return info.st_dev, info.st_ino, info.st_mode, info.st_nlink, info.st_size, info.st_mtime_ns


def _read(path: Path, limit: int) -> bytes:
    before = _normal(path)
    if before.st_size > limit:
        raise LocalCheckError("local_check_file_too_large")
    try:
        with path.open("rb") as stream:
            opened = os.fstat(stream.fileno())
            raw = stream.read(limit + 1)
            finished = os.fstat(stream.fileno())
        after = _normal(path)
    except OSError:
        raise LocalCheckError("local_check_file_read_error") from None
    if len(raw) > limit:
        raise LocalCheckError("local_check_file_too_large")
    if not (_identity(before) == _identity(after) and _identity(opened) == _identity(finished)
            and _cross_identity(before) == _cross_identity(opened) == _cross_identity(after)):
        raise LocalCheckError("local_check_file_changed_during_read")
    return raw


def _new(path: Path, raw: bytes) -> None:
    _parents(path)
    try:
        with path.open("xb") as stream:
            stream.write(raw)
    except OSError:
        raise LocalCheckError("local_check_output_write_error") from None


def _json_bytes(value: object) -> bytes:
    return (json.dumps(value, ensure_ascii=False, allow_nan=False, indent=2) + "\n").encode("utf-8")


def _manifest(source: Path) -> dict:
    """Inventory only package code/schema, config, selected tests and tool code."""
    _normal(source, directory=True)
    paths = {"pyproject.toml"}
    paths.update(name for name in ROOT_CONFIG_FILES if os.path.lexists(source / name))
    paths.update("tests/" + name for name in SELECTED_TEST_FILES)
    paths.update("tests/fixtures/results/" + name for name in SYNTHETIC_RESULT_FILES)
    package = source / "src" / "audio_regression"
    _normal(package, directory=True)
    for parent, directories, files in os.walk(package, followlinks=False):
        base = Path(parent)
        _normal(base, directory=True)
        directories[:] = [name for name in directories if name != "__pycache__"]
        for name in directories:
            if name.startswith("."):
                raise LocalCheckError("unexpected_source_directory")
            _normal(base / name, directory=True)
        for name in files:
            path = base / name
            relative = path.relative_to(source).as_posix()
            if path.suffix == ".py" or (path.suffix == ".json" and "schemas" in path.relative_to(package).parts):
                paths.add(relative)
    tools = source / "tools"
    _normal(tools, directory=True)
    paths.add("tools/run_local_checks.py")
    for path in tools.iterdir():
        if path.name.endswith(".py"):
            paths.add(path.relative_to(source).as_posix())
    if len(paths) > MAX_SOURCE_FILES:
        raise LocalCheckError("source_manifest_too_large")
    entries = []
    for relative in sorted(paths):
        raw = _read(source / relative, MAX_SOURCE_FILE_BYTES)
        entries.append({"path": relative, "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest()})
    return {"schema_version": 1, "scope": "explicit_selected_source_inventory", "files": entries}


def _junit(path: Path) -> dict:
    raw = _read(path, MAX_JUNIT_BYTES)
    # Decode before screening: UTF-16 DTD syntax must not evade a byte search.
    try:
        text = raw.decode("utf-8")
    except UnicodeError:
        raise LocalCheckError("invalid_junit_encoding") from None
    if re.search(r"<!\s*(?:DOCTYPE|ENTITY)\b", text, re.IGNORECASE):
        raise LocalCheckError("unsafe_junit_xml")
    try:
        root = ET.fromstring(text)
    except (ET.ParseError, ValueError, RecursionError):
        raise LocalCheckError("invalid_junit_xml") from None
    if root.tag not in {"testsuites", "testsuite"}:
        raise LocalCheckError("invalid_junit_root")
    selected = {Path(name).stem: name for name in SELECTED_TEST_FILES}
    totals = {"tests": 0, "passed": 0, "failures": 0, "errors": 0, "skipped": 0}
    coverage = {name: {"tests": 0, "non_skipped": 0} for name in SELECTED_TEST_FILES}
    for element in root.iter():
        if element.tag == "testsuite":
            for child in element:
                if child.tag == "error":
                    totals["errors"] += 1  # Collection failures are not testcase children.
        if element.tag != "testcase":
            continue
        totals["tests"] += 1
        if totals["tests"] > MAX_TEST_CASES:
            raise LocalCheckError("junit_testcase_limit")
        pieces = element.get("classname", "").split(".")
        matching = [selected[piece] for piece in pieces if piece in selected]
        if len(matching) != 1:
            raise LocalCheckError("unexpected_junit_test_source")
        name = matching[0]
        outcomes = [child.tag for child in element if child.tag in {"failure", "error", "skipped"}]
        if len(outcomes) > 1:
            raise LocalCheckError("ambiguous_junit_outcome")
        outcome = outcomes[0] if outcomes else "passed"
        totals[{"failure": "failures", "error": "errors", "skipped": "skipped", "passed": "passed"}[outcome]] += 1
        coverage[name]["tests"] += 1
        if outcome != "skipped":
            coverage[name]["non_skipped"] += 1
    totals["collected_files"] = [name for name in SELECTED_TEST_FILES if coverage[name]["tests"]]
    totals["non_skipped_files"] = [name for name in SELECTED_TEST_FILES if coverage[name]["non_skipped"]]
    return totals


def _artifact(source: Path, root: object, manifest: object, digest: str) -> dict:
    # Load the exact snapshotted module, not a possibly installed namesake.
    module_path = source / "src" / "audio_regression" / "artifact_integrity.py"
    _normal(module_path)
    # SourceFileLoader can write a .pyc even though child bytecode is disabled.
    # Compile the checked bytes directly, so the parent never writes in source.
    module = types.ModuleType("_local_checks_artifact_integrity")
    module.__file__ = str(module_path)
    exec(compile(_read(module_path, MAX_SOURCE_FILE_BYTES), str(module_path), "exec"), module.__dict__)
    return module.verify_artifact_manifest(root, manifest, expected_manifest_sha256=digest)


def _base_summary() -> dict:
    return {
        "schema_version": 1, "engine": "local_selected_checks_v1", "status": "error",
        "reason_code": None, "exit_code": 3,
        "selected_test_files": list(SELECTED_TEST_FILES), "selected_test_file_count": len(SELECTED_TEST_FILES),
        "full_suite_reexecuted": False, "tests": None,
        "source_integrity": {"status": "not_verified", "file_count": None, "manifest_sha256": None},
        "artifact_verification": {"status": "not_requested", "result": None, "verification_passes": 0},
        "artifacts": {"source_manifest_before": None, "source_manifest_after": None,
                      "junit_xml": None, "stdout_log": None, "stderr_log": None},
        "network_used": False, "quality_verdict": "not_assessed", "complete_audio_approval": False,
        "commercial_performance_validated": False, "authenticity_verified": False,
        "execution_provenance_verified": False,
    }


def _reason(error: Exception) -> str:
    code = getattr(error, "code", None)
    return code if type(code) is str and _CODE.fullmatch(code) else "local_check_execution_error"


def run_checks(source_dir: str | Path, output_dir: str | Path, *, artifact_root=None,
               artifact_manifest=None, artifact_manifest_sha256=None, timeout_seconds=600) -> dict:
    """Check the fixed local selection once; retain a fresh, bounded run record."""
    result = _base_summary()
    output = None
    started = False
    before = None
    source = None
    artifact_verified = False
    try:
        supplied = (artifact_root is not None, artifact_manifest is not None, artifact_manifest_sha256 is not None)
        if any(supplied) and not all(supplied):
            raise LocalCheckError("artifact_arguments_incomplete")
        if all(supplied) and (type(artifact_manifest_sha256) is not str or not _HASH.fullmatch(artifact_manifest_sha256)):
            raise LocalCheckError("invalid_artifact_manifest_sha256")
        if type(timeout_seconds) not in {int, float} or not 1 <= timeout_seconds <= 600:
            raise LocalCheckError("invalid_local_check_timeout")
        source, output = _path(source_dir), _path(output_dir)
        _normal(source, directory=True)
        if output == source or source in output.parents or output in source.parents:
            raise LocalCheckError("source_output_overlap")
        if all(supplied):
            retained_root = _path(artifact_root)
            if output == retained_root or retained_root in output.parents or output in retained_root.parents:
                raise LocalCheckError("artifact_output_overlap")
        if os.path.lexists(output):
            raise LocalCheckError("output_directory_exists")
        _parents(output)
        before = _manifest(source)
        output.parent.mkdir(parents=True, exist_ok=True)
        _parents(output)
        output.mkdir(exist_ok=False)
        started = True
        _new(output / "manifest_started.json", _json_bytes({"schema_version": 1,
             "engine": result["engine"], "status": "started", "selected_test_files": list(SELECTED_TEST_FILES),
             "full_suite_reexecuted": False, "network_used": False, "quality_verdict": "not_assessed"}))
        _new(output / "source_manifest_before.json", _json_bytes(before))
        result["artifacts"]["source_manifest_before"] = "source_manifest_before.json"
        if all(supplied):
            try:
                verification = _artifact(source, artifact_root, artifact_manifest, artifact_manifest_sha256)
                result["artifact_verification"] = {"status": "verified", "result": verification, "verification_passes": 1}
                if not isinstance(verification, dict) or verification.get("status") != "verified":
                    raise LocalCheckError("artifact_verification_not_verified")
                artifact_verified = True
            except Exception as error:
                result["artifact_verification"] = {"status": "error", "result": None, "verification_passes": 0}
                result.update(status="artifact_verification_error", reason_code=_reason(error), exit_code=2)
                raise LocalCheckError("artifact_check_stopped") from None
        temporary = output / "temporary"
        temporary.mkdir()
        env = os.environ.copy()
        for name in ("PYTEST_ADDOPTS", "PYTEST_PLUGINS", "PYTHONHOME", "PYTHONSTARTUP"):
            env.pop(name, None)
        env.update(PYTHONDONTWRITEBYTECODE="1", PYTEST_DISABLE_PLUGIN_AUTOLOAD="1",
                   PYTHONSAFEPATH="1", PYTHONPATH=os.pathsep.join((str(source / "src"), str(source / "tests"))),
                   OMP_NUM_THREADS="1", OPENBLAS_NUM_THREADS="1", MKL_NUM_THREADS="1",
                   NUMEXPR_NUM_THREADS="1", VECLIB_MAXIMUM_THREADS="1",
                   TMP=str(temporary), TEMP=str(temporary), TMPDIR=str(temporary))
        command = [sys.executable, "-B", "-m", "pytest", "-q", "-p", "no:cacheprovider",
                   "--noconftest", "--confcutdir", str(source / "tests"), "--import-mode=importlib",
                   "-c", str(source / "pyproject.toml"), "-o", "addopts=", "-o", "pythonpath=",
                   "--basetemp", str(output / "pytest_tmp"), "--junitxml", str(output / "tests.xml")]
        command.extend(str(source / "tests" / name) for name in SELECTED_TEST_FILES)
        # Log streams are private local files rather than unlimited in-memory captures.
        _parents(output / "stdout.log")
        with (output / "stdout.log").open("xb") as stdout, (output / "stderr.log").open("xb") as stderr:
            result["artifacts"].update(stdout_log="stdout.log", stderr_log="stderr.log")
            try:
                completed = subprocess.run(command, cwd=source, env=env, shell=False, check=False,
                                           timeout=timeout_seconds, stdout=stdout, stderr=stderr)
            except subprocess.TimeoutExpired:
                raise LocalCheckError("local_check_timeout") from None
        if type(completed.returncode) is not int:
            raise LocalCheckError("invalid_pytest_returncode")
        if completed.returncode not in {0, 1}:
            raise LocalCheckError("pytest_execution_error")
        result["tests"] = _junit(output / "tests.xml")
        result["artifacts"]["junit_xml"] = "tests.xml"
        if completed.returncode == 1 or result["tests"]["failures"] or result["tests"]["errors"]:
            result.update(status="selected_regression_failed", reason_code="selected_tests_failed", exit_code=1)
        elif (result["tests"]["tests"] == 0 or len(result["tests"]["non_skipped_files"]) != len(SELECTED_TEST_FILES)):
            result.update(status="selected_regression_withheld", reason_code="selected_test_coverage_incomplete", exit_code=2)
        else:
            result.update(status="verified_selected_regression", reason_code=None, exit_code=0)
    except Exception as error:
        if not (isinstance(error, LocalCheckError) and error.code == "artifact_check_stopped"):
            result.update(status="error", reason_code=_reason(error), exit_code=3)
    finally:
        if started and output is not None and source is not None and before is not None:
            if artifact_verified:
                try:
                    verification_after = _artifact(source, artifact_root, artifact_manifest, artifact_manifest_sha256)
                    if (not isinstance(verification_after, dict) or verification_after.get("status") != "verified"
                            or verification_after != result["artifact_verification"]["result"]):
                        raise LocalCheckError("artifact_changed_during_checks")
                    result["artifact_verification"]["verification_passes"] = 2
                except Exception as error:
                    result["artifact_verification"]["status"] = "error"
                    result.update(status="artifact_verification_error", reason_code=_reason(error), exit_code=2)
            try:
                after = _manifest(source)
                _new(output / "source_manifest_after.json", _json_bytes(after))
                result["artifacts"]["source_manifest_after"] = "source_manifest_after.json"
                equal = before == after
                result["source_integrity"] = {"status": "verified" if equal else "changed",
                    "file_count": len(before["files"]), "manifest_sha256": hashlib.sha256(_json_bytes(before)).hexdigest()}
                if not equal:
                    result.update(status="source_integrity_mismatch", reason_code="source_changed_during_checks", exit_code=2)
            except Exception as error:
                result["source_integrity"]["status"] = "not_verified"
                result.update(status="source_integrity_withheld", reason_code=_reason(error), exit_code=2)
            try:
                _new(output / "check_summary.json", _json_bytes(result))
            except Exception:
                result.update(status="error", reason_code="local_check_summary_write_error", exit_code=3)
    return result


def main(argv=None) -> int:
    class SafeParser(argparse.ArgumentParser):
        def error(self, message):
            raise LocalCheckError("invalid_local_check_arguments")
    parser = SafeParser(description="Fixed local selected checks; never audio approval.")
    parser.add_argument("--source-dir", required=True)
    parser.add_argument("--output-dir", required=True)
    parser.add_argument("--artifact-root")
    parser.add_argument("--artifact-manifest")
    parser.add_argument("--artifact-manifest-sha256")
    try:
        args = parser.parse_args(argv)
        result = run_checks(args.source_dir, args.output_dir, artifact_root=args.artifact_root,
                            artifact_manifest=args.artifact_manifest, artifact_manifest_sha256=args.artifact_manifest_sha256)
    except Exception as error:
        result = _base_summary()
        result["reason_code"] = _reason(error)
    print(json.dumps(result, ensure_ascii=False, allow_nan=False))
    return result["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
