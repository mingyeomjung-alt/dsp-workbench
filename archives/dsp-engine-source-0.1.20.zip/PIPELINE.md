# 오디오 처리 단계별 DSP 회귀검사

0.1.19에서는 `run --engine v10` / `--engine v11`도 명시적으로 선택할 수 있다. 기본은 v1이며 기존 계획·판정 누적은 유지한다. 내장 리샘플러는 기존 polyphase 방식이므로 FFT 전용 v12를 선택하지 못한다. v12는 [명시적 schema2 저장 단계 검사](SAVED_PIPELINE.md)로 사용한다. 새 v10/v11 실행 결과에는 별도 `pipeline-result-candidates-v1.schema.json`과 Python 의미 검증기를 적용하며 기존 v1~v9 스키마는 바꾸지 않는다.

저장한 실행 결과는 화면의 ‘단계 좌표 추적’ 또는 `audio-pipeline-check lineage --input run_result.json --output lineage.json`으로 사건별 원본·최종 좌표에 연결한다. 이후 `lineage-report --input lineage.json --output lineage.html`로 정적 보고서를 만든다. 두 명령의 종료 코드 0은 생성 완료일 뿐 기존 파이프라인 통과가 아니며 오디오·참조 경로를 다시 열지 않는다.

같은 원본을 여러 오디오 처리 단계에 통과시키고, 어느 단계에서 처음 시간적 결함 후보나 판단 보류가 관측됐는지 조사하는 로컬 실행기다. 리샘플링·고정 음량 변경·구간 나누기와 합치기를 직접 수행하며, 기존 DSP 엔진은 변경하지 않는다. 음성 등록·화자 인증·콜센터 서비스가 아니다.

## 실행 흐름

원본 스냅샷을 보존한 뒤 각 단계의 입력·출력 WAV와 설정·해시·분석·자동 검사 결과를 기록한다. 인접 단계 비교뿐 아니라 원본과 최종 출력도 확인한다. 앞에서 결함 후보나 보류가 발생하면 나중 단계가 정상이어도 전체 검사를 통과시키지 않는다. 처음 관측된 단계는 조사 시작점이며 실제 원인을 확정한 결과가 아니다. 최종 비교에서만 이상이 관측되면 특정 단계에 원인을 임의 배정하지 않는다.

이 실행기는 명시된 기본 처리 세 종류만 실행한다. 외부 명령·임의 Python 코드·네트워크·학습 모델을 실행하지 않는다. 실제 고객 파이프라인에 임의 플러그인을 연결하는 기능은 이번 범위에 포함하지 않는다.

이미 만들어진 단계별 WAV를 검사하는 기능은 별도의 [저장 단계 검사](SAVED_PIPELINE.md)다. 이 페이지의 `run`은 내장 처리를 실행하고, `audit`은 외부 처리 코드를 실행하지 않은 채 사용자가 저장한 파일을 조사한다.

기본값은 동결된 v1이다. 별도 [정합 개선 후보](ROBUSTNESS.md)를 선택하려면 명령에 `--engine v2`, Python 호출에 `engine="v2"`를 추가한다. v2 결과·추적 파일은 버전으로 구분하고 보류·경고의 누적 정책은 동일하게 유지한다.

저음량 구간의 제한된 활성 문맥 연결은 [v3 후보](CONTEXT.md)를 `--engine v3` 또는 `engine="v3"`로 선택한다. 기존 v1·v2를 대체하지 않으며 동일한 파일 보존·보류 정책을 유지한다.

## 계획 파일

UTF-8 JSON으로 1~8개 단계를 지정한다. 다음은 내용을 보존하는 정상 처리 계획이다.

```json
{
  "schema_version": 1,
  "stages": [
    {"kind": "resample", "label": "리샘플링", "target_rate_hz": 8000},
    {"kind": "gain", "label": "음량 변경", "gain_db": -6},
    {"kind": "split_join", "label": "구간 합치기", "segment_ms": 400}
  ]
}
```

리샘플링은 8·16·44.1·48 kHz, 음량 변경은 유한한 -60~20 dB를 입력한다. 실제 계산에서 PCM 범위를 벗어나면 자동 제한·정규화로 숨기지 않고 실패 처리한다. `split_join`은 200~30000 ms 구간으로 나눈 뒤 원래 샘플 순서대로 모든 구간을 합친다. 선택적 `order`는 0부터 시작하는 구간 인덱스 배열(최대 2000개)로, 실제 합치기 코드의 구간 누락·중복을 재현하는 데 사용할 수 있다. 이 설정이나 정답 구간은 DSP 검출기로 전달하지 않는다. 검출기는 두 WAV와 허용된 이득·리샘플링 선언만 받는다.

입력과 각 단계 출력은 기존 PCM16 모노 WAV·2~30초·파일당 최대 10 MB 계약을 지킨다. 범위를 벗어나는 출력, 잘못된 구간 인덱스와 실제 계산 실패는 통과가 아니라 실행 오류다. 모든 정합이 식별 가능한 것은 아니며 작은 변화나 미지원 처리는 보류·검출 한계가 남는다. 사건 후보가 없어도 전체 음질 정상이나 정확한 전사가 보장되지 않는다.

## 명령과 Python 호출

소스 작업 공간 루트에서 새 모듈을 실행할 수 있다.

```powershell
$env:PYTHONPATH = (Resolve-Path -LiteralPath 'dsp_engine\src').Path
.\.venv\Scripts\python.exe -m audio_regression.pipeline_cli run --source source.wav --plan plan.json --output-dir my_new_run
```

최신 소스를 설치한 환경에서는 `audio-pipeline-check run`을 사용한다. 이전 M4 wheel에는 새 파이프라인 명령이 없으므로 최신 인계물 또는 현재 소스를 설치해야 한다. 별도 실행 파일을 호출할 때는 위 명령의 `python -m audio_regression.pipeline_cli` 부분을 설치된 `audio-pipeline-check`로 바꾼다.

```python
from audio_regression.pipeline_runner import run_pipeline
from audio_regression.pipeline_reporting import write_pipeline_html

result = run_pipeline("source.wav", [
    {"kind": "gain", "gain_db": -6},
    {"kind": "split_join", "segment_ms": 400},
], "my_new_run")
write_pipeline_html(result, "my_new_run/review.html")
raise SystemExit(result["summary"]["exit_code"])
```

## 결과와 보관

| 코드 | 의미 |
| --- | --- |
| run 0 | 모든 필요한 시간적 검사가 완료됐고 지원 범위의 후보 없음 |
| run 1 | 결함 후보가 관측돼 검토 필요 |
| run 2 | 보류 또는 일부 실행 실패로 통과 차단 |
| run / report 3 | 잘못된 계획·입력·출력·명세 또는 파일 처리 오류 |

`run_result.json`에 단계별 결과, 최초 관측, 원본·최종 비교와 전체 상태를 저장한다. `run_report.html`은 결과를 읽는 정적 보고서다. HTML 생성은 추가 분석이나 오디오 업로드를 수행하지 않는다. 기존 결과에서 새 보고서만 만들려면 다음 명령을 사용한다.

```powershell
audio-pipeline-check report --input my_new_run/run_result.json --output new_report.html
```

출력 경로는 존재하지 않는 새 디렉터리여야 한다. 원본과 기존 결과를 덮어쓰거나 오류 후 자동 삭제·재시도하지 않는다. 중간 오류의 스냅샷과 기록은 남으며, 기록을 저장할 수 없는 파일 시스템 장애까지 완전한 보고서가 남는다고 보장하지 않는다.

0.1.15부터 종료 전에 원래 입력과 분석용 원본 사본, 메타데이터를 확보한 각 단계 출력 WAV를 다시 확인한다. 사본의 내용 변경은 `snapshot_changed_during_run`, 누락·읽기 실패·관측 가능한 링크나 하드링크는 `snapshot_recheck_failed`로 전체 실행을 `incomplete / blocked`로 처리한다. 원래 입력도 변경됐으면 기존 `source_changed_during_run`이 우선한다. 앞 단계의 최초 우려와 실패 단계는 보존한다. 이 확인은 파일 잠금이나 원자적 캡처가 아니며 종료 후 변경이나 일시 변경 후 복원은 보장 범위가 아니다.

출력 폴더에는 원본 사본과 단계별 실제 오디오가 들어 있다. 사용 권한이 있는 파일만 입력하고 로컬 자료로 보관한다. 공유할 때 오디오·메타데이터·해시를 함께 확인해야 한다. wheel과 소스 인계 스냅샷에 이 실행 오디오는 포함하지 않는다. 화면 렌더링 검수는 별도 확인이며 구조·상태 시험을 시각 검수로 대체하지 않는다.

## 개발 예제 재현

```powershell
$env:PYTHONPATH = (Resolve-Path -LiteralPath 'dsp_engine\src').Path
.\.venv\Scripts\python.exe dsp_engine/tools/run_pipeline_demo.py --output-dir dsp_engine/examples/my_new_pipeline_demo
```

정상 처리, 합치기 단계의 400 ms 삭제·중복, 실행 오류와 이후 미실행을 자체 생성 신호로 확인한다. 기대 단계는 검출 후에 예제 도구가 점검하며 검출 입력으로 사용하지 않는다. 예제 성공은 자연음 정확도·고객 조사 시간 절감·판매 수요의 증명이 아니다. 기존 M3 최종 자료를 재사용하거나 기준값을 튜닝하지 않는다.
